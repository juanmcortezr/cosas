#!/bin/sh
# $1 : nombre del Integration Server
IN=$1
echo "########## show properties #########"
mqsireadbar -b iqbf3-fiscalizacion-accionescontrol-esbapp-1.0.0.bar -r
# detener a la fuerza una application
# mqsistopmsgflow IB9NODE -e IS_DAIA_01 -k iqbf3-fiscalizacion-accionescontrol-esbapp -w 30 -f restartExecutionGroup
echo "########## override properties #########"
mqsiapplybaroverride -b iqbf3-fiscalizacion-accionescontrol-esbapp-1.0.0.bar -r -p iqbf3-fiscalizacion-accionescontrol-esbapp-1.0.0.properties
#mqsiapplybaroverride -b iqbf3-fiscalizacion-accionescontrol-esbapp.bar -r -p iqbf3-fiscalizacion-accionescontrol-esbapp-1.0.0.properties -o iqbf3-fiscalizacion-accionescontrol-esbapp-1.0.0.bar
#echo "########## deploy ##########"
#mqsideploy $1 -e IS_DAIA_01 -a /tmpbar/iqbf3-fiscalizacion-accionescontrol-esbapp-1.0.0.bar
#mqsideploy IIBV1007 -e IS1 -a iqbf3-fiscalizacion-accionescontrol-esbapp.bar
#echo "########## start application ##########"
#mqsistartmsgflow $1 -e IS_DAIA_01 -k iqbf3-fiscalizacion-accionescontrol-esbapp
#mqsistartmsgflow IIBV1007 -e IS1 -k iqbf3-fiscalizacion-accionescontrol-esbapp
