package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model;

import java.util.Date;

public class Parametro {

	private String 	codParametro;
	private String 	codParametroTrim;
	private String 	codModulo; 
	private String 	codTipo;
	private String 	codArgumento;
	private String 	codArgumentoTrim;
	private String 	descLarga;
	private String 	descCorta;
	private String 	descAbreviatura;
	private String 	codEstado;
	private Date 	fecModif;
	private String 	codUsumodif;
	private String	numLocal; 				//filtro de titulares



	public Parametro() 													{		super();}

	/*
	 * Constructor para el listado de tipo de novimientos
	 */

	public Parametro(String codParametro) 								{		super();
																				this.codParametro = codParametro;}

	/*
	 * Constructor para el listado de tipo de novimientos con filtro
	 */

	public Parametro(String codParametro, String codArgumento,
			String descCorta) 											{		super();
																				this.codParametro = codParametro;
																				this.codArgumento = codArgumento;
																				this.descCorta = descCorta;}

	public String getCodParametro() 									{		return codParametro;}

	public void setCodParametro(String codParametro) 					{		this.codParametro = codParametro;}

	public String getCodModulo() 										{		return codModulo;}

	public void setCodModulo(String codModulo) 							{		this.codModulo = codModulo;}

	public String getCodTipo() 											{		return codTipo;}

	public void setCodTipo(String codTipo) 								{		this.codTipo = codTipo;}

	public String getCodArgumento() 									{		return codArgumento;}

	public void setCodArgumento(String codArgumento) 					{		this.codArgumento = codArgumento;}

	public String getDescLarga() 										{		return descLarga;}

	public void setDescLarga(String descLarga) 							{		this.descLarga = descLarga;}

	public String getDescCorta() 										{		return descCorta;}

	public void setDescCorta(String descCorta) 							{		this.descCorta = descCorta;}

	public String getDescAbreviatura() 									{		return descAbreviatura;}

	public void setDescAbreviatura(String descAbreviatura) 				{		this.descAbreviatura = descAbreviatura;}

	public String getCodEstado() 										{		return codEstado;}

	public void setCodEstado(String codEstado) 							{		this.codEstado = codEstado;}

	public Date getFecModif() 											{		return fecModif;}

	public void setFecModif(Date fecModif) 								{		this.fecModif = fecModif;}

	public String getCodUsumodif() 										{		return codUsumodif;}

	public void setCodUsumodif(String codUsumodif) 						{		this.codUsumodif = codUsumodif;}

	public String getNumLocal() 										{		return numLocal;}
	
	public void setNumLocal(String numLocal) 							{		this.numLocal = numLocal;}

	public String getCodParametroTrim() {
		return codParametroTrim;
	}

	public void setCodParametroTrim(String codParametroTrim) {
		this.codParametroTrim = codParametroTrim;
	}

	public String getCodArgumentoTrim() {
		return codArgumentoTrim;
	}

	public void setCodArgumentoTrim(String codArgumentoTrim) {
		this.codArgumentoTrim = codArgumentoTrim;
	}
}
