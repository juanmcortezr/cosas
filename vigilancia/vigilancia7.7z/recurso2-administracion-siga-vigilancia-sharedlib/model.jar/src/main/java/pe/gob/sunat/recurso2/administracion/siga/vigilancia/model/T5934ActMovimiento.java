package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model;

public class T5934ActMovimiento {

	private Integer num_movim;
    private String ind_confirma;
    private String obs_confirma;
    
    private Integer numSolicitud;
    private String motivoMov;
    private String codMarqAct;
        
    private String descConformidad;
    private Integer numMovim;
    private String nroRegistro;
    
	public Integer getNum_movim() {
		return num_movim;
	}
	public void setNum_movim(Integer camposRegistrar) {
		num_movim = camposRegistrar;
	}
	public String getInd_confirma() {
		return ind_confirma;
	}
	public void setInd_confirma(String indConfirma) {
		ind_confirma = indConfirma;
	}
	public String getObs_confirma() {
		return obs_confirma;
	}
	public void setObs_confirma(String obsConfirma) {
		obs_confirma = obsConfirma;
	}
	public void setNumSolicitud(Integer numSolicitud) {
		this.numSolicitud = numSolicitud;
	}
	public Integer getNumSolicitud() {
		return numSolicitud;
	}
	public void setMotivoMov(String motivoMov) {
		this.motivoMov = motivoMov;
	}
	public String getMotivoMov() {
		return motivoMov;
	}
	public void setCodMarqAct(String codMarqAct) {
		this.codMarqAct = codMarqAct;
	}
	public String getCodMarqAct() {
		return codMarqAct;
	}
	public void setDescConformidad(String descConformidad) {
		this.descConformidad = descConformidad;
	}
	public String getDescConformidad() {
		return descConformidad;
	}
	public void setNumMovim(Integer numMovim) {
		this.numMovim = numMovim;
	}
	public Integer getNumMovim() {
		return numMovim;
	}
	public void setNroRegistro(String nroRegistro) {
		this.nroRegistro = nroRegistro;
	}
	public String getNroRegistro() {
		return nroRegistro;
	}
    
}
