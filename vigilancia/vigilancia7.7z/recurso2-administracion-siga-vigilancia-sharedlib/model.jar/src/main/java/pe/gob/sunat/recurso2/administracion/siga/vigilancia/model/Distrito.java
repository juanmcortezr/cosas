package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model;

public class Distrito {
	private String codiDepaDpt; 
	private String codiProvTpr;
	private String nombDistTdi;
	private String codiDistTdi;

	public Distrito() 											{		super();}



	public String getCodiDepaDpt() 								{		return codiDepaDpt;}
	public void setCodiDepaDpt(String codiDepaDpt) 				{		this.codiDepaDpt = codiDepaDpt;}
	public String getCodiProvTpr() 								{		return codiProvTpr;}
	public void setCodiProvTpr(String codiProvTpr) 				{		this.codiProvTpr = codiProvTpr;}
	public String getNombDistTdi() 								{		return nombDistTdi;}
	public void setNombDistTdi(String nombDistTdi) 				{		this.nombDistTdi = nombDistTdi;}
	public String getCodiDistTdi() 								{		return codiDistTdi;}
	public void setCodiDistTdi(String codiDistTdi) 				{		this.codiDistTdi = codiDistTdi;}


}
