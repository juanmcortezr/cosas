package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.constantes.VigilanciaConstantes;

/**
 * Bienes patrimoniales en activos fijos
 * tipo: lectura
 * @author wrodriguezre
 *
 */
public class ActivoFijo extends Parametro{

	private String 	codiMarqAct; 			//codigo de bien patrimonial
	private String 	descActiAct; 			//descripcion
	private String 	nroSeriAct;				//numero de serie
	private String 	areaRespAct;
	private String 	codiEmpAct; 			//lectura del empleado
	private String  nombCortPer;			//nombre corto
	private String	numeroRegistroAlterno;
	private String	nombreCortoCustodio;	//colaborador en custodia
	private String  numeroRegistroAlternoCustodio;

	private Integer numLocalAct; 			//lectura del num local
	private String	nomLocalAct;			//name del local

	private String 	estaAlmaAct; 			//estado de conservacion
	private String  estaAlmaActValo;		//valor en tablas de estado de conservacion
	private String 	codiMarcMar;			//marca
	private String 	modeActiAct;			//modelo
	private String 	marca;

	private String 	modelo;
	private String 	coloAutoAct;			//color
	private String 	codMatBie;				//material
	private String 	numUltInv;				//numero de inventario
	private String 	codSituAct; 			//estado
	private String	situacion;				//mensaje de estado

	private String 	situActiAct;			//situacion
	private Date 	fechIngrAct; 			//fecha de ingreso
	private Date	fecMovUlt; 				//fecha fin
	private Date 	fecUltInv; 				//fecha inventario
	private Date	fecAsigAct;				//fecha de asignacion

	private String	inveScanAct;			//key de inventario
	private String	flagEtiqAct;			//etiqueta
	private String	codiAnteAct; 			//codigo anterior
	private Date	fecGaraFin;				//fecha garantia

	private String descDepeTde;				//descripcion dependencia
	private String unidadOrganizacional;

	private Integer numSolicitudAct;
	private String	codEmplCust;

	//cus010
	private String descMarcMar;
	private String estado;
	private String color;
	private String material;

	private List<String> listaEstados;

	//INICIO JMCR
	private String origen;
	private String descOrigenAsignacion;
	private Integer numSolicitudUltimo;
	private String codTipAuto;
	private String codExAduana;
	private String dimeActiAct;
	private Integer numMovimiento;
	private String descConformidad;
    private String numSeriFor;
    private String numDocuFor;
    private Integer numLocalDest;
	private String numGuiaRemision;
	
	//************************/
	private String capaActiAct;
	private String numVidaUtil;
	private String numRucGara;
	private String nroContCco;
	private String nroOrdeOco;			//NRO_ORDE_OCO
	private String codOrden;
	private String numRucCon;
	private String valoCompAct;
	private String fechRegiAct;
	
	private String indAutor;
	private String descIndAutor;
	private String obsAutoriza;
	private String descIndAprob;
	private String obsApruebaDet;
	
	private String fechIngAct; // fech_ingr_act
	private String numMesesGara; // num_meses_gara
	private String fecVidaUtil; // FEC_VIDA_UTIL
	private String fechPecoPec;  // FECH_PECO_PEC
	private String fecAsigActString;				//fecha de asignacion en string
	

	private String indRegularizar;

	public String getIndRegularizar() {
		return indRegularizar;
	}
	public void setIndRegularizar(String indRegularizar) {
		this.indRegularizar = indRegularizar;
	}
	public String getFechIngAct() {
		return fechIngAct;
	}
	public void setFechIngAct(String fechIngAct) {
		this.fechIngAct = fechIngAct;
	}
	public String getNumMesesGara() {
		return numMesesGara;
	}
	public void setNumMesesGara(String numMesesGara) {
		this.numMesesGara = numMesesGara;
	}
	public String getFecVidaUtil() {
		return fecVidaUtil;
	}
	public void setFecVidaUtil(String fecVidaUtil) {
		this.fecVidaUtil = fecVidaUtil;
	}
	public String getFechPecoPec() {
		return fechPecoPec;
	}
	public void setFechPecoPec(String fechPecoPec) {
		this.fechPecoPec = fechPecoPec;
	}
	public String getIndAutor() {
		return indAutor;
	}
	public void setIndAutor(String indAutor) {
		this.indAutor = indAutor;
	}
	public String getDescIndAutor() {
		return descIndAutor;
	}
	public void setDescIndAutor(String descIndAutor) {
		this.descIndAutor = descIndAutor;
	}
	public String getObsAutoriza() {
		return obsAutoriza;
	}
	public void setObsAutoriza(String obsAutoriza) {
		this.obsAutoriza = obsAutoriza;
	}
	public String getDescIndAprob() {
		return descIndAprob;
	}
	public void setDescIndAprob(String descIndAprob) {
		this.descIndAprob = descIndAprob;
	}
	public String getObsApruebaDet() {
		return obsApruebaDet;
	}
	public void setObsApruebaDet(String obsApruebaDet) {
		this.obsApruebaDet = obsApruebaDet;
	}
	public String getFechRegiAct() {
		return fechRegiAct;
	}
	public void setFechRegiAct(String fechRegiAct) {
		this.fechRegiAct = fechRegiAct;
	}
	public String getValoCompAct() {
		return valoCompAct;
	}
	public void setValoCompAct(String valoCompAct) {
		this.valoCompAct = valoCompAct;
	}
	public String getNumRucCon() {
		return numRucCon;
	}
	public void setNumRucCon(String numRucCon) {
		this.numRucCon = numRucCon;
	}
	public String getCapaActiAct() {return capaActiAct; }
	public void setCapaActiAct(String capaActiAct) {
		this.capaActiAct = capaActiAct;
	}
	public String getNumVidaUtil() {return numVidaUtil;	}
	public void setNumVidaUtil(String numVidaUtil) {
		this.numVidaUtil = numVidaUtil;
	}
	public String getNumRucGara() {	return numRucGara;}
	public void setNumRucGara(String numRucGara) {
		this.numRucGara = numRucGara;
	}
	public String getNroContCco() {	return nroContCco;}
	public void setNroContCco(String nroContCco) {
		this.nroContCco = nroContCco;
	}
	public String getNroOrdeOco() {	return nroOrdeOco;}
	public void setNroOrdeOco(String nroOrdeOco) {
		this.nroOrdeOco = nroOrdeOco;
	}
	public String getCodOrden() {return codOrden;}
	public void setCodOrden(String codOrden) {
		this.codOrden = codOrden;
	}
	//************************/
    //NVL(af.COD_TIPO_AUTO,' ') as codTipAuto,
    //(SELECT desc_larga FROM t01parametro WHERE cod_parametro = '3081' AND cod_argumento = af.colo_auto_act) AS coloAutoAct,
    //NVL(af.COD_EX_ADUANA,' ') as codExAduana,
    //NVL(af.NUM_ULT_INV,' ') as numUltInv,
    //NVL(af.DIME_ACTI_ACT,' ') as dimeActiAct

	//FIN JMCR

	public ActivoFijo() 												{		super();}


	public String getCodiMarqAct() 										{		return codiMarqAct;}
	public void setCodiMarqAct(String codiMarqAct) 						{		this.codiMarqAct = codiMarqAct;}
	public String getDescActiAct() 										{		return descActiAct;}
	public void setDescActiAct(String descActiAct) 						{		this.descActiAct = descActiAct;}
	public String getNroSeriAct() 										{		return nroSeriAct;}
	public void setNroSeriAct(String nroSeriAct) 						{		this.nroSeriAct = nroSeriAct;}
	public String getAreaRespAct() 										{		return areaRespAct;}
	public void setAreaRespAct(String areaRespAct) 						{		this.areaRespAct = areaRespAct;}
	public String getCodiEmpAct() 										{		return codiEmpAct;}
	public void setCodiEmpAct(String codiEmpAct) 						{		this.codiEmpAct = codiEmpAct;}
	public Integer getNumLocalAct() 									{		return numLocalAct;}
	public void setNumLocalAct(Integer numLocalAct) 					{		this.numLocalAct = numLocalAct;}
	public String getEstaAlmaAct() 										{		return estaAlmaAct;}
	public void setEstaAlmaAct(String estaAlmaAct) 						{		this.estaAlmaAct = estaAlmaAct;}
	public String getCodiMarcMar() 										{		return codiMarcMar;}
	public void setCodiMarcMar(String codiMarcMar) 						{		this.codiMarcMar = codiMarcMar;}
	public String getModeActiAct() 										{		return modeActiAct;}
	public void setModeActiAct(String modeActiAct) 						{		this.modeActiAct = modeActiAct;}
	public String getColoAutoAct() 										{		return coloAutoAct;}
	public void setColoAutoAct(String coloAutoAct) 						{		this.coloAutoAct = coloAutoAct;}
	public String getCodMatBie() 										{		return codMatBie;}
	public void setCodMatBie(String codMatBie) 							{		this.codMatBie = codMatBie;}
	public String getNumUltInv() 										{		return numUltInv;}
	public void setNumUltInv(String numUltInv) 							{		this.numUltInv = numUltInv;}
	public String getCodSituAct() 										{		return codSituAct;}
	public void setCodSituAct(String codSituAct) 						{		this.codSituAct = codSituAct;}
	public String getSituActiAct() 										{		return situActiAct;}
	public void setSituActiAct(String situActiAct) 						{		this.situActiAct = situActiAct;}
	public Date getFechIngrAct() 										{		return fechIngrAct;}
	public void setFechIngrAct(Date fechIngrAct) 						{		this.fechIngrAct = fechIngrAct;}
	public Date getFecMovUlt() 											{		return fecMovUlt;}
	public void setFecMovUlt(Date fecMovUlt) 							{		this.fecMovUlt = fecMovUlt;}
	public Date getFecUltInv() 											{		return fecUltInv;}
	public void setFecUltInv(Date fecUltInv) 							{		this.fecUltInv = fecUltInv;}
	public String getFlagEtiqAct() 										{		return flagEtiqAct;}
	public void setFlagEtiqAct(String flagEtiqAct) 						{		this.flagEtiqAct = flagEtiqAct;}
	public String getCodiAnteAct() 										{		return codiAnteAct;}
	public void setCodiAnteAct(String codiAnteAct) 						{		this.codiAnteAct = codiAnteAct;}
	public Date getFecGaraFin() 										{		return fecGaraFin;}
	public void setFecGaraFin(Date fecGaraFin) 							{		this.fecGaraFin = fecGaraFin;}
	public String getInveScanAct() 										{		return inveScanAct;}
	public void setInveScanAct(String inveScanAct) 						{		this.inveScanAct = inveScanAct;}
	public String getNomLocalAct() 										{		return nomLocalAct;}
	public void setNomLocalAct(String nomLocalAct) 						{		this.nomLocalAct = nomLocalAct;}
	public Date getFecAsigAct() 										{		return fecAsigAct;}
	public void setFecAsigAct(Date fecAsigAct) 							{		this.fecAsigAct = fecAsigAct;}
	public String getNombCortPer() 										{		return nombCortPer;}
	public void setNombCortPer(String nombCortPer) 						{		this.nombCortPer = nombCortPer;}
	public String getNumeroRegistroAlterno() 							{		return numeroRegistroAlterno;}
	public void setNumeroRegistroAlterno(String numeroRegistroAlterno) 	{		this.numeroRegistroAlterno = numeroRegistroAlterno;}
	public String getNombreCortoCustodio() 								{		return nombreCortoCustodio;}
	public void setNombreCortoCustodio(String nombreCortoCustodio) 		{		this.nombreCortoCustodio = nombreCortoCustodio;}
	public String getNumeroRegistroAlternoCustodio() 					{		return numeroRegistroAlternoCustodio;}
	public void setNumeroRegistroAlternoCustodio(String numeroRegistroAlternoCustodio){		this.numeroRegistroAlternoCustodio = numeroRegistroAlternoCustodio;}
	public String getDescDepeTde() 										{		return descDepeTde;}
	public void setDescDepeTde(String descDepeTde) 						{		this.descDepeTde = descDepeTde;}
	public String getUnidadOrganizacional() 							{		return unidadOrganizacional;}
	public void setUnidadOrganizacional(String unidadOrganizacional) 	{		this.unidadOrganizacional = unidadOrganizacional;}
	public Integer getNumSolicitudAct() 								{		return numSolicitudAct;}
	public void setNumSolicitudAct(Integer numSolicitudAct) 			{		this.numSolicitudAct = numSolicitudAct;}
	public String getSituacion() 										{		return situacion;}
	public void setSituacion(String situacion) 							{		this.situacion = situacion;}
	public String getCodEmplCust() 										{		return codEmplCust;}
	public void setCodEmplCust(String codEmplCust) 						{		this.codEmplCust = codEmplCust;}
	public String getMarca() 											{		return marca;}
	public void setMarca(String marca) 									{		this.marca = marca;}
	public String getModelo() 											{		return modelo;}
	public void setModelo(String modelo) 								{		this.modelo = modelo;}
	public String getDescMarcMar() 										{		return descMarcMar;}
	public void setDescMarcMar(String descMarcMar) 						{		this.descMarcMar = descMarcMar;}
	public String getEstado() 											{		return estado;}
	public void setEstado(String estado) 								{		this.estado = estado;}
	public String getColor() 											{		return color;}
	public void setColor(String color) 									{		this.color = color;}
	public String getMaterial() 										{		return material;}
	public void setMaterial(String material) 							{		this.material = material;}


	public List<String> getListaEstados() {
		return listaEstados;
	}


	public void setListaEstados(List<String> listaEstados) {
		this.listaEstados = listaEstados;
	}

	public List<String> getListaEstadosBuenoRegular(){
		List<String> listaEstadosConservacion = new ArrayList<String>();
		listaEstadosConservacion.add(VigilanciaConstantes.ESTADO_CONSERVACION_BUENO);
		listaEstadosConservacion.add(VigilanciaConstantes.ESTADO_CONSERVACION_REGULAR);
		return listaEstadosConservacion;
	}

	public void setDescOrigenAsignacion(String descOrigenAsignacion) {
		this.descOrigenAsignacion = descOrigenAsignacion;
	}


	public String getDescOrigenAsignacion() {
		return descOrigenAsignacion;
	}


	public void setNumSolicitudUltimo(Integer numSolicitudUltimo) {
		this.numSolicitudUltimo = numSolicitudUltimo;
	}


	public Integer getNumSolicitudUltimo() {
		return numSolicitudUltimo;
	}


	public void setCodTipAuto(String codTipAuto) {
		this.codTipAuto = codTipAuto;
	}


	public String getCodTipAuto() {
		return codTipAuto;
	}


	public void setCodExAduana(String codExAduana) {
		this.codExAduana = codExAduana;
	}


	public String getCodExAduana() {
		return codExAduana;
	}


	public void setDimeActiAct(String dimeActiAct) {
		this.dimeActiAct = dimeActiAct;
	}


	public String getDimeActiAct() {
		return dimeActiAct;
	}


	public void setNumMovimiento(Integer numMovimiento) {
		this.numMovimiento = numMovimiento;
	}


	public Integer getNumMovimiento() {
		return numMovimiento;
	}


	public void setDescConformidad(String descConformidad) {
		this.descConformidad = descConformidad;
	}


	public String getDescConformidad() {
		return descConformidad;
	}


	public void setEstaAlmaActValo(String estaAlmaActValo) {
		this.estaAlmaActValo = estaAlmaActValo;
	}


	public String getEstaAlmaActValo() {
		return estaAlmaActValo;
	}


	public void setOrigen(String origen) {
		this.origen = origen;
	}


	public String getOrigen() {
		return origen;
	}


	public void setNumGuiaRemision(String numGuiaRemision) {
		this.numGuiaRemision = numGuiaRemision;
	}


	public String getNumGuiaRemision() {
		return numGuiaRemision;
	}


	public void setNumSeriFor(String numSeriFor) {
		this.numSeriFor = numSeriFor;
	}


	public String getNumSeriFor() {
		return numSeriFor;
	}


	public void setNumDocuFor(String numDocuFor) {
		this.numDocuFor = numDocuFor;
	}


	public String getNumDocuFor() {
		return numDocuFor;
	}


	public void setNumLocalDest(Integer numLocalDest) {
		this.numLocalDest = numLocalDest;
	}


	public Integer getNumLocalDest() {
		return numLocalDest;
	}
	
	public String getFecAsigActString() {
		return fecAsigActString;
	}
	public void setFecAsigActString(String fecAsigActString) {
		this.fecAsigActString = fecAsigActString;
	}

	public String getBienMovFrec() {
		return bienMovFrec;
	}
	public void setBienMovFrec(String bienMovFrec) {
		this.bienMovFrec = bienMovFrec;
	}

	public String bienMovFrec;
}
