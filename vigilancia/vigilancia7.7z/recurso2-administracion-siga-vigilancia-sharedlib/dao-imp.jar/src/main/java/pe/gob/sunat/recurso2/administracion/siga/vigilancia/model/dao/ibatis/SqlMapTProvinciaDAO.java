package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ibatis;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Provincia;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.TProvinciaDAO;

/**
 * Implementación del DAO para acceder y modificar la información de la
 * entidad locales
 * 
 * @author walter rodriguez
 * @version 1.0
 */
public class SqlMapTProvinciaDAO extends SqlMapClientDaoSupport implements
		TProvinciaDAO {

	@SuppressWarnings("unchecked")
	public List<Provincia> getProvincias(String departamento) {
		return (List<Provincia>) getSqlMapClientTemplate().queryForList(
				"Provincia.selectByPrimaryKey", departamento);
	}

}