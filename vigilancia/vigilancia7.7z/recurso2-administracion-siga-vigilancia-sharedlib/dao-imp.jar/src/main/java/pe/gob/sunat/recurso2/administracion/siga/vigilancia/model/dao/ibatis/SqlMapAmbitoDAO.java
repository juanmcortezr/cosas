package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;

import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.AmbitoConfiguradoBean;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.AmbitoDAO;

/**
 * SqlMapAmbitoDAO
 * 
 * @author framirez
 * @since 11/09/2015
 * @version 1.0
 */
public class SqlMapAmbitoDAO extends SqlMapClientDaoSupport implements
		AmbitoDAO {

	protected final Log log = LogFactory.getLog(getClass());
	
	@SuppressWarnings("unchecked")
	@Override
	public List<AmbitoConfiguradoBean> getAmbitosConfigurado(HashMap<String,Object> parametros) {
		return (List<AmbitoConfiguradoBean>) getSqlMapClientTemplate() 
				.queryForList("ambito.selectAmbitoConfigurado",parametros);
	}

	@Override
	public void insertAmbitosConfigurado(AmbitoConfiguradoBean bean) {
		getSqlMapClientTemplate().insert("ambito.insertByCierreLocal", bean);
	}

	@Override
	public Integer updateAmbitosConfigurado(AmbitoConfiguradoBean bean) {
		log.debug("FRAMIREZ ENTRO A SQLMAP....");
		Integer updateAmbitos = null;
		if (bean.getFecCierre() == null) {
			log.debug("FECHA NULL....");
			updateAmbitos = getSqlMapClientTemplate().update(
					"ambito.updateByReinicioLocal", bean);
		} else {
			log.debug("FECHA NO NULA....");
			updateAmbitos = getSqlMapClientTemplate().update(
					"ambito.updateByCierreLocal", bean);
		}
		return updateAmbitos;
	}

	@Override
	public JRBeanCollectionDataSource obtenerConexion() {
	
		//List contohs = SqlMapClient.  .queryForList("contoh.selectAllContoh");
		
		@SuppressWarnings("unchecked")
		List<AmbitoConfiguradoBean> results = (List<AmbitoConfiguradoBean>) getSqlMapClientTemplate()
				.queryForList("ambito.selectAmbitoConfigurado");   
				//getSqlMapClientTemplate().queryForList("from com.acme.Sale");
		JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(results);
		return ds;
	}
}
