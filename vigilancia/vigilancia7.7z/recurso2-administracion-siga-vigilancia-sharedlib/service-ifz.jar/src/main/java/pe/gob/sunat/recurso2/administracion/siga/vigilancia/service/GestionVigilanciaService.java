package pe.gob.sunat.recurso2.administracion.siga.vigilancia.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActSolTra;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActSolTraDet;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Tdependencias;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActivoFijo;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.InmLocalTdepe;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Inmueble;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.MaestroPersona;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.util.ServiceException;

public interface GestionVigilanciaService {
	
	void enviarNotificacionRegistroComprobanteRetencion(String ruc,
			String nombreRazon, String correo, String asunto, String contenido)
			throws Exception;
	
	public List<Inmueble> recuperarListaDeLocales(Inmueble param);
	
	public List<InmLocalTdepe> recuperarListaLocalesPorUuoo(InmLocalTdepe param);
	
	List<ActivoFijo> consultarBienesAsignados(String nroRegistro,
			String codPatrimonial, String uuoo, Integer numLocalOrigen);
	
	ActivoFijo selectByPrimaryKeyInventario(String codPatrimonial,String codEmpleado, String flagEstadoBienConformidad);
	
	MaestroPersona obtenerPersonaxRegistro(String cod_reg);
	
	List<MaestroPersona> buscarColaboradores(Map parmSearch);
	
	public MaestroPersona maestroPersona (String numRegistro);
	
	public java.sql.Date obtenerDiasUtiles(Date fecha, Integer dias);

	List<Tdependencias> buscarUUOOs(Map parmSearch);

	MaestroPersona getSelectColaboradorDestinatario(String registroAlterno);

	ActivoFijo recuperarBienPorCodigoBien(String codPatrimonial);

	List<ActivoFijo> recuperarListaBienes(ActivoFijo param);

	Long obtenerSecuenciaSolicitud();
	
	Long obtenerSecuenciaMovimiento();
	
	String obtenerCodigoSolicitud(Map<String, Object> param);

	void registrarSolicitudVigilancia(ActSolTra solicitud,
			List<ActSolTraDet> listaDetallesSolicitud);

	void actualizarSolicitudVigilancia(ActSolTra solicitud);

	List<ActSolTraDet> recuperarListaDetallesSolicitud(ActSolTraDet param);

	List<ActSolTra> recuperarListaSolicitudes(ActSolTra param);

	MaestroPersona getEmpleado(String numRegistro) throws ServiceException;

	List<MaestroPersona>recuperarUuooResponsableDelegado(MaestroPersona param);
}
