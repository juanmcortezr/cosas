package pe.gob.sunat.recurso2.administracion.siga.vigilancia.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.T5934ActMovimiento;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.dao.AccesoDAO;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActSolTra;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActSolTraDet;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActivoFijo;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.InmLocalTdepe;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Inmueble;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.MaestroPersona;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Tdependencias;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ActMovTraDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ActSolTraDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ActSolTraDetDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ActivoFijoDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.InmLocalTdepeDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.InmuebleDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.MaestroPersonaDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.SysRegistroArchivosFisicoDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.T01ParametroDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.T5934ActMovimientoDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.TdependenciasDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.service.GestionVigilanciaService;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.constantes.VigilanciaConstantes;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.util.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.firma.model.bean.Dependencia;
import pe.gob.sunat.recurso2.administracion.siga.mensajeria.model.bean.SysMensajeriaBean;
import pe.gob.sunat.recurso2.administracion.siga.mensajeria.model.bean.SysMensajeriaDestinosBean;
import pe.gob.sunat.recurso2.administracion.siga.mensajeria.service.RegistroMensajeriaService;

@Service("financiera.utiles.comprobanteRetencionService")
public class GestionVigilanciaServiceImpl implements GestionVigilanciaService {

	private SysRegistroArchivosFisicoDAO sysRegistroArchivosFisicoDAO;

	private T01ParametroDAO t01ParametroDAO;

	private TdependenciasDAO tdependenciasDAO;

	private AccesoDAO accesoDAO;

	private InmuebleDAO inmuebleDAO;

	private InmLocalTdepeDAO inmLocalTdepeDAO;

	private ActivoFijoDAO activoFijoDAO;

	private T5934ActMovimientoDAO actMovimientoDAO;

	private MaestroPersonaDAO maestroPersonaDAO;

	private RegistroGeneralService registroGeneralService;

	private RegistroMensajeriaService registroMensajeriaService;
	
	private ActSolTraDAO actSolTraDAO;
	
	private ActSolTraDetDAO actSolTraDetDAO;
	
	private ActMovTraDAO actMovTraDAO;
	
	protected final Log log = LogFactory.getLog(getClass());

	@Override
	public MaestroPersona getEmpleado(String numRegistro) throws ServiceException {
		
		MaestroPersona empleado = new MaestroPersona();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("numeroRegistro", numRegistro);
		
		List<MaestroPersona> listaEmpleados = maestroPersonaDAO.getEmpleadoPorRegistroNombre(param);
		if (!listaEmpleados.isEmpty()) {
			empleado = listaEmpleados.get(0);
		}
		
		return empleado;
	}
	
	public List<Inmueble> recuperarListaDeLocales(Inmueble param) {

		return inmuebleDAO.selectListaLocales(param);
	}

	public List<InmLocalTdepe> recuperarListaLocalesPorUuoo(InmLocalTdepe param) {

		return inmLocalTdepeDAO.selectJoinLocalesPorUnidad(param);
	}

	private Long createMessage(String codigoMessage, String subjectMessage,
			String bodyMessage) throws Exception {

		SysMensajeriaBean mensaje = new SysMensajeriaBean();
		mensaje.setCodigoMensaje(codigoMessage);
		mensaje.setAsunto(subjectMessage);
		mensaje.setMensaje(bodyMessage);
		mensaje.setRemitenteEmail("");
		mensaje.setRemitenteFirma("");
		mensaje.setRemitenteNombre("");
		Long numberMessage = registroMensajeriaService.crearMensaje(mensaje);
		return numberMessage;
	}

	/**
	 * Metodo que permite agregar destinatario al correo.
	 * 
	 * @author Jorge Ponce.
	 * @param numberMessage
	 *            :numero del correo.
	 * @param email
	 *            :correo del destinatario.
	 * @param nombreColaborador
	 *            :nombre del destinatario o colaborador.
	 * @param tipoMessage
	 *            :tipo mensaje (PARA - CC - BCC).
	 */
	private void addAddresSee(Long numberMessage, String email,
			String nombreColaborador, String tipoMessage) throws Exception {

		SysMensajeriaDestinosBean destino = new SysMensajeriaDestinosBean();
		destino.setNroMensaje(numberMessage);
		destino.setDestinoEmail(email);
		destino.setDestinoNombre(nombreColaborador);
		destino.setTipoDestino(tipoMessage);
		registroMensajeriaService.addDestino(destino);
	}

	/**
	 * Metodo que permite enviar el correo.
	 * 
	 * @author Jorge Ponce.
	 * @param numberMessage
	 *            :numero del correo.
	 */
	private void sendMessage(Long numberMessage) throws Exception {
		registroMensajeriaService.sendMensaje(numberMessage);
	}

	@Override
	public void enviarNotificacionRegistroComprobanteRetencion(String ruc,
			String nombreRazon, String correo, String asunto, String contenido)
			throws Exception {

		try {
			Long numberMessage = createMessage(
					VigilanciaConstantes.CODIGO_NOTIFICACION_CAJACHICA, asunto,
					contenido);
			addAddresSee(numberMessage, correo, nombreRazon, "PARA");
			sendMessage(numberMessage);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	public List<ActivoFijo> consultarBienesAsignados(String nroRegistro,
			String codPatrimonial, String uuoo, Integer numLocalOrigen) {
		ActivoFijo actFijo = new ActivoFijo();

		actFijo.setNumeroRegistroAlterno(nroRegistro);
		actFijo.setCodiMarqAct(codPatrimonial);
		actFijo.setUnidadOrganizacional(uuoo);
		actFijo.setNumLocalAct(numLocalOrigen);

		T5934ActMovimiento actMovimientoQuery = new T5934ActMovimiento();
		T5934ActMovimiento actMovimiento;

		List<ActivoFijo> bienPatrimonial = activoFijoDAO
				.consultarBienesAsignados(actFijo);
		for (ActivoFijo activo : bienPatrimonial) {
			activo.setDescOrigenAsignacion("-");
			activo.setNumSolicitudUltimo(-1);

			actMovimientoQuery.setCodMarqAct(activo.getCodiMarqAct());
			List<T5934ActMovimiento> actMovimientoList = actMovimientoDAO
					.getParamsSolicitudes(actMovimientoQuery);

			if (actMovimientoList.size() > 0) {
				actMovimiento = actMovimientoList.get(0);
				if (actMovimiento.getMotivoMov() != null) {
					activo.setDescOrigenAsignacion(actMovimiento.getMotivoMov());
				}

				if (actMovimiento.getNumSolicitud() != null) {
					activo.setNumSolicitudUltimo(actMovimiento
							.getNumSolicitud());
				}
			}
		}
		log.info("solicitado: " + new Date());

		return bienPatrimonial;
	}
	
	@Override
	public ActivoFijo recuperarBienPorCodigoBien(String codPatrimonial){
		
		ActivoFijo actFijo=new ActivoFijo();		
		actFijo.setCodiMarqAct(codPatrimonial);		
		ActivoFijo bienPatrimonial=activoFijoDAO.selectByPrimaryKey(actFijo);
		
		return bienPatrimonial;
	}
	
	@Override
	public List<ActivoFijo> recuperarListaBienes(ActivoFijo param) {
		
		List<ActivoFijo> bienesPatrimoniales = activoFijoDAO.listByParameter(param);
		return bienesPatrimoniales;
	}

	public ActivoFijo selectByPrimaryKeyInventario(String codPatrimonial,
			String codEmpleado, String flagEstadoBienConformidad) {

		ActivoFijo actFijo = new ActivoFijo();
		actFijo.setCodiMarqAct(codPatrimonial);
		actFijo.setCodiEmpAct(codEmpleado);
		actFijo.setMarca(flagEstadoBienConformidad);
		ActivoFijo bienPatrimonial = activoFijoDAO
				.selectByPrimaryKeyInventario(actFijo);

		return bienPatrimonial;
	}

	@Override
	public MaestroPersona obtenerPersonaxRegistro(String cod_reg) {
		return maestroPersonaDAO.obtenerPersonaxRegistro(cod_reg);
	}

	@Override
	public List<MaestroPersona> buscarColaboradores(Map parmSearch) {
		List<MaestroPersona> lsMaestro = (List<MaestroPersona>) maestroPersonaDAO
				.buscarMaestroPersonal(parmSearch);
		return lsMaestro;
	}

	@Override
	public MaestroPersona maestroPersona(String numRegistro) {
		HashMap<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("loginUsuario", numRegistro);// el login del usuario.
		MaestroPersona empleado = maestroPersonaDAO.getEmpleadoPorUsuario(paramSearch);
		return empleado;
	}
	
	@Override
	public MaestroPersona getSelectColaboradorDestinatario(String registroAlterno) {
		MaestroPersona mper=new MaestroPersona();
		MaestroPersona respuesta=new MaestroPersona();
		mper.setNumeroRegistroAlterno(registroAlterno);
		respuesta=maestroPersonaDAO.getColaboradorDestinatario(mper);
		return respuesta;
	}

	@Override
	public java.sql.Date obtenerDiasUtiles(Date fecha, Integer dias) {

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("fecha", fecha);
		paramMap.put("dias", dias);
		java.sql.Date diasUtiles = activoFijoDAO.obtenerDiasUtiles(paramMap);

		return diasUtiles;
	}
	
	@Override
	public List<Tdependencias> buscarUUOOs(Map parmSearch) {
		List<Tdependencias> lsDependencia = (List<Tdependencias>) tdependenciasDAO.buscarUUOOs(parmSearch);
//		for( Dependencia  obj:   lsDependencia ){
//			log.debug("Desc UUOO: "+ obj.getDescdepetde());
//			log.debug("Cod UUOO: "+ obj.getCodUnidadOrganizacional());
//			log.debug("Abreviatura UUOO: "+ obj.getAbreviatura());
//		}
		
		return lsDependencia;
	}
	
	@Override
	public List<ActSolTra> recuperarListaSolicitudes(ActSolTra param) {
		
		List<ActSolTra> lista = (List<ActSolTra>) actSolTraDAO.listByParameter(param);
		return lista;
	}
	
	@Override
	public List<ActSolTraDet> recuperarListaDetallesSolicitud(ActSolTraDet param) {
		
		List<ActSolTraDet> lista = (List<ActSolTraDet>) actSolTraDetDAO.listByParameter(param);
		return lista;
	}
	
	@Override
	public Long obtenerSecuenciaSolicitud() {

		Long secuencia = actSolTraDAO.getSequence();
		return secuencia;
	}
	
	@Override
	public Long obtenerSecuenciaMovimiento() {

		Long secuencia = actMovTraDAO.getSequence();
		return secuencia;
	}
	
	@Override
	public String obtenerCodigoSolicitud(Map<String, Object> param) {
				
		String secuencia = actSolTraDAO.getCodigoSolicitud(param);
		return secuencia;
	}
	
	@Override
	public void registrarSolicitudVigilancia(ActSolTra solicitud, List<ActSolTraDet> listaDetallesSolicitud) {
		
		actSolTraDAO.insertSelective(solicitud);
		
		for (ActSolTraDet detalleSolicitud : listaDetallesSolicitud) {
			actSolTraDetDAO.insertSelective(detalleSolicitud);
		}
	}
	
	@Override
	public void actualizarSolicitudVigilancia(ActSolTra solicitud) {
		
		actSolTraDAO.updateByPrimaryKeySelective(solicitud);
	}
	
	@Override
	public List<MaestroPersona> recuperarUuooResponsableDelegado(MaestroPersona param) {
		
		List<MaestroPersona> listaRespuesta = maestroPersonaDAO.selectUuooResponsableDelegado(param);
		return listaRespuesta;
	}
	
	/**
	 * Aspecto ejecutado antes de la ejecucion del servicio de grabacion
	 * */
	private void before(String user) throws ServiceException {

		log.info("metodo AccesoAdvice.before(...) iniciado.");
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codVariable", "USER");
		parametros.put("valVariable", user);
		log.info("datos a enviar para setear entorno:" + parametros);
		accesoDAO.setearVariableEntorno(parametros);
		log.info("metodo AccesoAdvice.before(...) terminado.");
	}

	/**
	 * Aspecto ejecutado luego de la ejecucion del servicio de grabacion
	 * */
	private void after() throws ServiceException {

		log.info("Iniciando metodo AccesoAdvice.after(...) para limpiar la variable de sesion");
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codVariable", "USER");
		accesoDAO.limpiarVariableEntorno(parametros);
		log.info("metodo AccesoAdvice.after(...) terminado.");
	}

	public T01ParametroDAO getT01ParametroDAO() {
		return t01ParametroDAO;
	}

	public void setT01ParametroDAO(T01ParametroDAO t01ParametroDAO) {
		this.t01ParametroDAO = t01ParametroDAO;
	}

	public SysRegistroArchivosFisicoDAO getSysRegistroArchivosFisicoDAO() {
		return sysRegistroArchivosFisicoDAO;
	}

	public void setSysRegistroArchivosFisicoDAO(
			SysRegistroArchivosFisicoDAO sysRegistroArchivosFisicoDAO) {
		this.sysRegistroArchivosFisicoDAO = sysRegistroArchivosFisicoDAO;
	}

	public AccesoDAO getAccesoDAO() {
		return accesoDAO;
	}

	public void setAccesoDAO(AccesoDAO accesoDAO) {
		this.accesoDAO = accesoDAO;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(
			RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public RegistroMensajeriaService getRegistroMensajeriaService() {
		return registroMensajeriaService;
	}

	public void setRegistroMensajeriaService(
			RegistroMensajeriaService registroMensajeriaService) {
		this.registroMensajeriaService = registroMensajeriaService;
	}

	public TdependenciasDAO getTdependenciasDAO() {
		return tdependenciasDAO;
	}

	public void setTdependenciasDAO(TdependenciasDAO tdependenciasDAO) {
		this.tdependenciasDAO = tdependenciasDAO;
	}

	public InmuebleDAO getInmuebleDAO() {
		return inmuebleDAO;
	}

	public void setInmuebleDAO(InmuebleDAO inmuebleDAO) {
		this.inmuebleDAO = inmuebleDAO;
	}

	public InmLocalTdepeDAO getInmLocalTdepeDAO() {
		return inmLocalTdepeDAO;
	}

	public void setInmLocalTdepeDAO(InmLocalTdepeDAO inmLocalTdepeDAO) {
		this.inmLocalTdepeDAO = inmLocalTdepeDAO;
	}

	public ActivoFijoDAO getActivoFijoDAO() {
		return activoFijoDAO;
	}

	public void setActivoFijoDAO(ActivoFijoDAO activoFijoDAO) {
		this.activoFijoDAO = activoFijoDAO;
	}

	public T5934ActMovimientoDAO getActMovimientoDAO() {
		return actMovimientoDAO;
	}

	public void setActMovimientoDAO(T5934ActMovimientoDAO actMovimientoDAO) {
		this.actMovimientoDAO = actMovimientoDAO;
	}

	public MaestroPersonaDAO getMaestroPersonaDAO() {
		return maestroPersonaDAO;
	}

	public void setMaestroPersonaDAO(MaestroPersonaDAO maestroPersonaDAO) {
		this.maestroPersonaDAO = maestroPersonaDAO;
	}

	public ActSolTraDAO getActSolTraDAO() {
		return actSolTraDAO;
	}

	public void setActSolTraDAO(ActSolTraDAO actSolTraDAO) {
		this.actSolTraDAO = actSolTraDAO;
	}

	public ActSolTraDetDAO getActSolTraDetDAO() {
		return actSolTraDetDAO;
	}

	public void setActSolTraDetDAO(ActSolTraDetDAO actSolTraDetDAO) {
		this.actSolTraDetDAO = actSolTraDetDAO;
	}

	public ActMovTraDAO getActMovTraDAO() {
		return actMovTraDAO;
	}

	public void setActMovTraDAO(ActMovTraDAO actMovTraDAO) {
		this.actMovTraDAO = actMovTraDAO;
	}
}