package pe.gob.sunat.recurso2.administracion.siga.vigilancia.registro.web.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.archivo.model.bean.RegistroArchivosFisicoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.firma.model.bean.T5282Archbin;
import pe.gob.sunat.recurso2.administracion.siga.firma.service.ConsultaFirmaService;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.service.GestionVigilanciaService;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.util.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActivoFijo;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.SysRegistroArchivosFisico;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Tdependencias;

public class RegistroVigilanciaController extends MultiActionController {
	
	private String jsonView;
	private JsonSerializer jsonSerializer;
	
	private RegistroGeneralService registroGeneralService;
	private RegistroPersonalService registroPersonalService;
	private RegistroDependenciasService registroDependenciasService;

	private RegistroArchivosService registroArchivosService;
	private GestionVigilanciaService gestionVigilanciaService;
	private ConsultaFirmaService consultaFirmaService;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	/**
     * Carga la Pagina de la consulta
     * @param HttpServletRequest request
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */  
	public ModelAndView iniciarRegistro(HttpServletRequest request, HttpServletResponse response) {
		
		log.debug("debug Inicio - ConsultaSolicitudController.iniciarConsulta");
		
		ModelAndView modelAndView;
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		String pagina = "";
		String mensajeError = "";
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		try {

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			List<T01ParametroBean> listaTipoMovimiento;
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cod_par", "0025");
			params.put("cod_mod", "MUEB");
			params.put("cod_tipo", "D");
			
			listaTipoMovimiento = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);

			List<T01ParametroBean> listaClaseMovimiento;
			
			params = new HashMap<String, Object>();
			params.put("cod_par", "0026");
			params.put("cod_mod", "MUEB");
			params.put("cod_tipo", "D");
			
			listaClaseMovimiento = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);

			List<T01ParametroBean> listaEstado;
			
			params = new HashMap<String, Object>();
			params.put("cod_par", "0028");
			params.put("cod_mod", "MUEB");
			params.put("cod_tipo", "D");
			
			listaEstado = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			
			params = new HashMap<String, Object>();
			params.put("codigovigilante", usuarioBean.getLogin());
			
			//addOption("selEstado", 'T', "TODOS");
			
			//listaEstados = jQuery.parseJSON(listaEstadosString);
			//for (var i = 0; i < listaEstados.length; i++) {
			//	addOption("selEstado", $.trim(listaEstados[i].cod_argumento), $.trim(listaEstados[i].nom_largo));
			//}
			
			if (log.isDebugEnabled())log.debug("getApeMaterno:"		+usuarioBean.getApeMaterno());
			if (log.isDebugEnabled())log.debug("getApePaterno:"		+usuarioBean.getApePaterno());
			if (log.isDebugEnabled())log.debug("getCodDepend:"		+usuarioBean.getCodDepend());
			if (log.isDebugEnabled())log.debug("getCodUO:"			+usuarioBean.getCodUO());
			if (log.isDebugEnabled())log.debug("getCorreo:"			+usuarioBean.getCorreo());
			if (log.isDebugEnabled())log.debug("getLogin:"			+usuarioBean.getLogin());
			if (log.isDebugEnabled())log.debug("getNombreCompleto:"	+usuarioBean.getNombreCompleto());
			if (log.isDebugEnabled())log.debug("getNombres:"		+usuarioBean.getNombres());
			if (log.isDebugEnabled())log.debug("getNroRegistro:"	+usuarioBean.getNroRegistro());
			if (log.isDebugEnabled())log.debug("getTicket:"			+usuarioBean.getTicket());
			
			java.sql.Date fechaLimite = gestionVigilanciaService.obtenerDiasUtiles(new Date(), 2);
			
			respuesta.put("listaTipoMovimiento", jsonSerializer.serialize(listaTipoMovimiento));
			respuesta.put("listaClaseMovimiento", jsonSerializer.serialize(listaClaseMovimiento));
			respuesta.put("listaEstado", jsonSerializer.serialize(listaEstado));
			respuesta.put("datosUsuario", jsonSerializer.serialize(usuarioBean));
			
			pagina = "paginaRegistroVigilancia";
		}
		catch(Exception e){
			log.error(e.getMessage(), e);
			pagina = "paginaErrorSistema";
			mensajeError = "A ocurrido un inconveniente por favor comuniquese con el Administrador." + e.getMessage();
		}
		finally{
			respuesta.put("mensajeError", mensajeError);
			modelAndView = new ModelAndView(pagina,respuesta);
			log.debug("Fin ConsultaSolicitudController.iniciarConsulta");
		}
		
		return modelAndView;
	}
	
	/*
	public ModelAndView descargarArchivo(HttpServletRequest request, HttpServletResponse response) throws ServiceException {

		ModelAndView modelAndView = null;
		
		if (log.isDebugEnabled()) {log.debug("debug Inicio - ConsultaSolicitudController.descargarArchivo");}
		Map<String, Object> params = new HashMap<String, Object>();
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		try {
			String numArchivo = StringUtils.trim(request.getParameter("numArchivo"));

			boolean existeArchivo = false;
			
			BigDecimal codDocautNumber;
			try {
				codDocautNumber = new BigDecimal(numArchivo);
			}
			catch (Exception e) {
				log.debug("error en conversion de numero");
				codDocautNumber = BigDecimal.valueOf(-1.0);
			}
			
			log.debug("numArchivo " + numArchivo);
			params.put("numArchivo", numArchivo);
			
			byte[] bytes = new byte[1024];
			String nombre = "";
			
			T5282Archbin archivo = consultaFirmaService.recuperarDocumentoPdfFirmado(codDocautNumber);
			bytes = archivo.getArcDatos();
			nombre = archivo.getDesNombreAlternativo();
			existeArchivo = true;
				
			log.debug("nombre del archivo: " + nombre);
			
			if (existeArchivo) {
				if (!(nombre.contains(".pdf") || nombre.contains(".PDF"))) {
					nombre = nombre + ".pdf";
				}
				
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment;filename="+nombre);
	
				OutputStream os = response.getOutputStream();
	
				os.write(bytes);
	
				os.flush();
				os.close();
			}
			
			return modelAndView;
		}
		catch(Exception ex){
			log.error("Error en ConsultaSolicitudController.descargarArchivo: " + ex.getMessage(), ex);

			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", "Ocurrio un error inesperado: " + ex.getMessage());
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
		finally{
			if (log.isDebugEnabled()){ log.debug("Fin - ConsultaSolicitudController.descargarArchivo");}
		}
	}

	public ModelAndView recuperarSolicitudes(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarSolicitudes");
			
			List<ReciboProvisional> listaSolicitudes = this.consultarSolicitudesRecibo(request, response);						
			respuesta.put("listaSolicitudes", listaSolicitudes);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("mensajeError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			respuesta.put(""mensajeError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarSolicitudes");
		}
		
		return modelAndView;
	}
	*/
	
	public String getJsonView() {
		return jsonView;
	}

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public JsonSerializer getJsonSerializer() {
		return jsonSerializer;
	}

	public void setJsonSerializer(JsonSerializer jsonSerializer) {
		this.jsonSerializer = jsonSerializer;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(
			RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public ConsultaFirmaService getConsultaFirmaService() {
		return consultaFirmaService;
	}

	public void setConsultaFirmaService(ConsultaFirmaService consultaFirmaService) {
		this.consultaFirmaService = consultaFirmaService;
	}

	public GestionVigilanciaService getGestionVigilanciaService() {
		return gestionVigilanciaService;
	}

	public void setGestionVigilanciaService(GestionVigilanciaService gestionVigilanciaService) {
		this.gestionVigilanciaService = gestionVigilanciaService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(
			RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroDependenciasService getRegistroDependenciasService() {
		return registroDependenciasService;
	}

	public void setRegistroDependenciasService(
			RegistroDependenciasService registroDependenciasService) {
		this.registroDependenciasService = registroDependenciasService;
	}
}