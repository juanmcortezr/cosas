	function iniciarVentanaBuscarColaboradorForm(){
		iniciarTablaColaboradores();
		asignarEventosColaborador();
		$('#ventanaBuscarColaborador').on('shown.bs.modal', function () {
			$(window).triggerHandler('resize.jqGrid');
			$("#txtColaboradorParm").val("");
			$("#txtColaboradorParm").focus();
		});
		
		//formulario de búsqueda de colaboradores
	    $("#buscarColaboradorForm").submit(function(e){
	        e.preventDefault();
	        buscarJqGridColaboradores();
	    });
		
	}
	
	function asignarEventosColaborador(){
		addEventElement("btnAceptarColaborador", "click", clickBtnAceptarColaborador);
		addEventElement("btnCancelarFindColaborador", "click", clickBtnCancelarFindColaborador);
		addEventElement("btnBuscarColaborador", "click", clickBtnBuscarColaborador);
	}
	
	function clickBtnAceptarColaborador(e){	aceptarColaboradorCallback();};
	function clickBtnBuscarColaborador(e){ buscarJqGridColaboradores(); };
	function clickBtnCancelarFindColaborador(e){ $('#ventanaBuscarColaborador').modal('hide');}; 
   	   	
   	
	var aceptarColaboradorCallback = function() {
   		var codEmpleado = $("#tblColaboradores").jqGrid('getGridParam','selrow');
   		if(codEmpleado!=null){
   			var datosEmpleado = $("#tblColaboradores").jqGrid('getRowData', codEmpleado);
   			cargarColaboradorSeleccionado(datosEmpleado);
   			$('#ventanaBuscarColaborador').modal('hide');
   		}else{
   			bootbox.dialog({message: "Debe seleccionar un colaborador.",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
   		}
   	};
   	

   		//CONSTRUIR GRID//
   	function iniciarTablaColaboradores(){
		var tblColaboradores = $("#tblColaboradores");
		var heightJqGrid = 180;
		setStyleElement("divColaboradoresTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, false));
		if (tblColaboradores) {
			var divColaboradoresTable = $("#divColaboradoresTable");
			var widthTable = divColaboradoresTable.width();
			
			tblColaboradores.jqGrid({
				width: widthTable,
				height: heightJqGrid,
				datatype : "local",
				shrinkToFit: false,
				forceFit:true,
				cmTemplate: { sortable: true, title: false },
				//colNames:['Num. Reg.','Apellidos y Nombres','UUOO','UUOO','Nombre UUOO','C&oacute;digo ','codiDepeTde'],
				colNames:['Num. Reg.','Apellidos y Nombres','UUOO','codDep','codEmp','codDepTde','estaEmp'],
				colModel:[
							{name:'numeroRegistroAlterno',index:'numeroRegistroAlterno', width:80},
							{name:'nomEmpPer',index:'nomEmpPer', width:400},
							{name:'codUnidadOrganizacionalGrilla',index:'codUnidadOrganizacionalGrilla',width:400},
							
							//{name:'codUnidadOrganizacional',index:'codUnidadOrganizacional',width:(0*widthTable/20), hidden: true},
							{name:'unidadOrganizacional',index:'unidadOrganizacional', width: 0, hidden: true},
							{name:'codiEmplPer',key: true,index:'codiEmplPer', width:0, hidden: true},
							{name:'codiDepeTde',key: true,index:'codiDepeTde', width:0, hidden: true},
							{name:'estaTrabPer',key: true,index:'estaTrabPer', width:0, hidden: true}
				], 
				rowNum: 10,
				rowList: [10, 20, 30],
				pager : "#pagerColaboradoresTable",
				autowidth: true,
				sortname: 'id',
				viewrecords: true,
				sortorder: 'desc',
				altRows: true,
				multiselect: false,
				multiboxonly: true,
				headertitles: true,
				hidegrid: false,
				recordpos:'left',
				pagerpos:'right',
				viewrecords : true,
				loadui: "disable",
				ondblClickRow: function(rowid) {
					aceptarColaboradorCallback();
				}
			});
			
			tblColaboradores.clearGridData();
		}
		 $(window).on('resize.jqGrid', function () {
			var offset = 50;
			var w = tblColaboradores.closest('.panel').width();
			tblColaboradores.jqGrid('setGridWidth', w-offset);
		});
   	}
		
   	//When you press buscar in Colaboradores==
	function buscarJqGridColaboradores(){
		var tipoBuscarColaborador=$('#tipoBuscarColaborador').val();
		var parmBuscaColaborador=$('#txtColaboradorParm').val();
		var paramRestringirUuoo=$('#hdnUuooSolicitante').val();
			
		if ( $.trim(tipoBuscarColaborador)==""  || $.trim(tipoBuscarColaborador)=="0" ){
			bootbox.dialog({message: "Debe seleccionar el criterio de b&uacute;squeda.",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
			return;	
		}
		if ( $.trim(parmBuscaColaborador)==""){
			bootbox.dialog({message: "Debe ingresar el texto a buscar.",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
			return;	
		}
			
		var ajax_data ={
			"tipoBuscaColaborador"		:	tipoBuscarColaborador,
			"parmBuscaColaborador"	 	:	parmBuscaColaborador,
			"paramRestringirUuoo"		:	paramRestringirUuoo
		};
		
		$("#tblColaboradores").jqGrid('clearGridData');	
		
		$.ajax({	
		    url: CONTEXT_PATH+"/consulta.htm?action=getCargaColaboradores",				
			data: ajax_data,
			type: "post",
			timeout: "60000",
			dataType: "json",               
			success: function(respuesta) { 
				var listColaboradores=respuesta.listColaboradores;
				var esColaboradorInactivo = respuesta.esColaboradorInactivo;
				var esColaboradorNoExiste = respuesta.esColaboradorNoExiste;
					
					if ( esColaboradorInactivo == 'si' ) {
						bootbox.dialog({message: "N&deg; de Registro de Colaborador no est&aacute; activo",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
					} else if ( esColaboradorNoExiste == 'si' ) {
						bootbox.dialog({message: "N&deg; de Registro de Colaborador no existe, verifique",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
					} else {
						// lo que estaba antes
						if(listColaboradores.length==0) {
							bootbox.dialog({message: "No se encontraron colaboradores para su criterio de b&uacute;squeda.",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
						} else{
							for(var i=0;i<listColaboradores.length;i++){
								var c= listColaboradores[i];
								var datarow = {
									numeroRegistroAlterno:c.numeroRegistroAlterno,
									nomEmpPer:c.nomEmpPer,
									codUnidadOrganizacional:c.codUnidadOrganizacional,
									codUnidadOrganizacionalGrilla:c.codUnidadOrganizacional+" - "+c.unidadOrganizacional,
									unidadOrganizacional:c.unidadOrganizacional,
									codiEmplPer:c.codiEmplPer,
									codiDepeTde:c.codiDepeTde,
									estaTrabPer:c.estaTrabPer
								};
								var su=jQuery("#tblColaboradores").jqGrid('addRowData',c.codiEmplPer,datarow);
							}
							
							$("#tblColaboradores").trigger("reloadGrid");	
						}
					}
					
				},
				complete: function (data, status) {
				},
				error:function (xhr, ajaxOptions, thrownError) {}			 
			});
	   	};

	   	
	   	var buscarColaborador = function(numRegistro){
			if ($.trim(numRegistro)==""){
				alert('Debe Ingresar Numero de Registro');
				return;	
			}
			
			var ajax_data ={"parmBuscaColaborador":numRegistro};
			
			$.ajax({	
			    url: CONTEXT_PATH+"/consulta.htm?action=getColaboradorPorRegistro",				
				data: ajax_data,
				type: "post",
				timeout: "60000",
				dataType: "json",
				success: function(respuesta) { 
					var colaborador=respuesta.colaborador;
					if (colaborador.numero_registro){
						alert('El registro de colaborador no existe');
					}else{
						buscarColaboradorCallBack( colaborador.numero_registro, colaborador.nombre_completo,colaborador.codigoEmpleado);
					}

				},
				complete: function (data, status) {},
				error:function (xhr, ajaxOptions, thrownError) {}			 
			});
	   	};
		 