//Funciones de busqueda de locales al iniciar

var _callbackLocalSeleccionado = null; 
var _callbackGeneraLista = null;
var _numNivel = null;

//Muestra la interface de locales a seleccionar
//numNivel: Nivel al que debe limitarse la búsqueda, ni no se tiene límites entonces asignar null
//callbackLocalSeleccionado, función ejecutada una vez que el usuario ha seleccionado un local
//callbackGeneraLista, función ejecutada para restringir a una lista de códigos de locales los resultados de la búsqueda, por ejemplo 10,1000,100,255,1022
//Si la función es nula o no genera una lista devolverá todos los locales. 
var mostrarInterfaceLocales = function(numNivel,callbackLocalSeleccionado,callbackGeneraLista){
	_numNivel = numNivel;
	_callbackLocalSeleccionado = callbackLocalSeleccionado;
	_callbackGeneraLista = callbackGeneraLista
	
	setNivelDeLocal(numNivel);//aquí se reinician los desplegables de ubigeo
	var mensaje = getTextoNivelSeccionadoLocal(numNivel);
	$("#txtMensajeFiltroLocal").val(mensaje);
	$('#ventanaBuscarLocal').modal('show');
};

var reiniciarDesplegablesUbigeo = function(){

	$.ajax({
		url: CONTEXT_PATH+"/consulta.htm?action=getDepartamentos", 
		type: "post",
		timeout: "60000",
		dataType: "json",
		success: function(respuesta) {
			//llenando departamentos
			var departamentos=respuesta.listDepartamentos;
			$('#cmbDepartamentos').empty();
			$('#cmbProvincias').empty();
			$('#cmbDistritos').empty();
		
			$('#cmbDepartamentos').append('<option value="" selected>TODOS</option>');
			$('#cmbProvincias').append('<option value="" selected>TODOS</option>');
			$('#cmbDistritos').append('<option value="" selected>TODOS</option>');
		
			//manejo de filtros
			$('#filtro').val('');
			var grid = $("#grid-table-locales");
			grid[0].p.search = false;
		
			$.each(departamentos, function(i, item){
				$('#cmbDepartamentos').append($('<option>', { value: item.codiDepaDpt, text : item.nombDptoDpt	}));						
			});
		},
		error:function (xhr, ajaxOptions, thrownError) {}
	});
};


//Lena la lista de locales deacuerso a la lista
var llenarListaInicial = function(){

	//1. Limpiamos la lista
	$("#grid-table-locales").jqGrid('clearGridData');

	//2. Reiniciamos los desplegables de ubigeo
	reiniciarDesplegablesUbigeo();
	
	var listaLocales =  ""; 
	if(_callbackGeneraLista!=null){
		listaLocales = _callbackGeneraLista(); 
	}
	
	var ajax_data ={"numNivel":getNivelSeccionadoLocal(),"listaLocales":listaLocales};//Se selecciona un determinado nivel al iniciar
	$.ajax({	
	    url: CONTEXT_PATH+"/consulta.htm?action=listarLocales",				
		type: "post",
		timeout: "60000",
		dataType: "json",
		data:ajax_data,
		success: function(respuesta) { 
			var listLocales=respuesta.locales;
			//dporrasc
			//$("#grid-table-locales").jqGrid('clearGridData');
			for(var i=0;i<listLocales.length;i++){
				var s = listLocales[i];
				var datarow = {
						numLocal:s.numLocal,
						codLocal:s.codLocal,
						nomLocal:s.nomLocal,
						dirLocal:s.desDireccion,
						ubigeo:s.codUbigeo,
						departamento:s.desDepartamento,
						provincia:s.desProvincia,
						distrito:s.desDistrito	};
				var su=jQuery("#grid-table-locales").jqGrid('addRowData',parseInt(s.numLocal),datarow);
			}
			$("#grid-table-locales").trigger("reloadGrid");
		},
		error:function (xhr, ajaxOptions, thrownError) {}			 
	});
};


var setNivelDeLocal = function(numNivel){
	//configurarBusquedaLocales()
	//Habilitamos todo
	$('#jstree_locales').jstree(true).enable_node('nodsede');
	$('#jstree_locales').jstree(true).enable_node('nodedificio');
	$('#jstree_locales').jstree(true).enable_node('nodpiso');
	//Deseleccionamos todos los nodos.
	$('#jstree_locales').jstree(true).deselect_node('nodsede');
	$('#jstree_locales').jstree(true).deselect_node('nodedificio');
	$('#jstree_locales').jstree(true).deselect_node('nodpiso');
	
	if(numNivel!=null){
		if(numNivel==1){
			$('#jstree_locales').jstree(true).select_node('nodsede');
			$('#jstree_locales').jstree(true).disable_node('nodedificio');
			$('#jstree_locales').jstree(true).disable_node('nodpiso');  
		}else if(numNivel==2){
			$('#jstree_locales').jstree(true).disable_node('nodsede');
			$('#jstree_locales').jstree(true).select_node('nodedificio');
			$('#jstree_locales').jstree(true).disable_node('nodpiso');  
		}else if(numNivel==3){
			$('#jstree_locales').jstree(true).disable_node('nodsede');
			$('#jstree_locales').jstree(true).disable_node('nodedificio');
			$('#jstree_locales').jstree(true).select_node('nodpiso');  
		}
	}else{
		$('#jstree_locales').jstree(true).select_node('nodsede');
	}
};


var getNivelSeccionadoLocal = function(){
	if($('#jstree_locales').jstree(true).is_selected('nodsede'))return 1;
	if($('#jstree_locales').jstree(true).is_selected('nodedificio'))return 2;
	if($('#jstree_locales').jstree(true).is_selected('nodpiso'))return 3;
	return 0;
};


var getTextoNivelSeccionadoLocal = function(numNivel){
	if(numNivel!=null){
		if(numNivel==1)return $('#jstree_locales').jstree(true).get_text('nodsede');
		if(numNivel==2)return $('#jstree_locales').jstree(true).get_text('nodedificio');
		if(numNivel==3)return $('#jstree_locales').jstree(true).get_text('nodpiso');	
	}else{
		return $('#jstree_locales').jstree(true).get_text('nodsede');
	}
};



//Obtiene la info del local dado su código de local
var getInfoLocal = function(numLocal){
	
	var infoLocal = null;
	var ajax_data ={"numLocal":numLocal};
	$.ajax({
		url: CONTEXT_PATH+"/consulta.htm?action=getLocal", 
		type: "post",
		timeout: "60000",
		dataType: "json",
		data:ajax_data,
		async: false, 
		success: function(respuesta) {
			infoLocal=respuesta.local;
		},
		error:function (xhr, ajaxOptions, thrownError) {}
	});
	return infoLocal;
};


//Este método debe ejecutarse al final de la instrucción de inicio jQuery(function($) {...});
var configurarBusquedaLocales = function(){
	//1. Configuramos el árbol
	$('#jstree_locales').jstree();
	
	$("#jstree_locales").bind(
	    "select_node.jstree", function(evt, data){
	    	$("#txtMensajeFiltroLocal").val(data.node.text);
	    	llenarListaInicial();
	    }
	);
	
	jQuery("#grid-table-locales").jqGrid({
		datatype: "local",
		height: 180,
		width: 830, //1270
		shrinkToFit: false,
		cmTemplate: { sortable: true },
		colNames:['Num.','C&oacute;digo.','Nombre Local.','Direcci&oacute;n ', 'Ubigeo','Departamento','Provincia','Distrito'],
		colModel:[
			{name:'numLocal',key: true,index:'numLocal', width:80},
			{name:'codLocal',index:'codLocal', width:120},
			{name:'nomLocal',index:'nomLocal',width:400},
			{name:'dirLocal',index:'dirLocal', width:400},
			{name:'ubigeo',index:'ubigeo', width:80},
			{name:'departamento',index:'departamento', width:110},
			{name:'provincia',index:'provincia', width:100},
			{name:'distrito',index:'distrito', width:150}
		], 
		//scrollOffset: 0,
		viewrecords : true,
		recordpos:'left',
		pagerpos:'right',
		altRows: true,
		multiselect: false,
        multiboxonly: true,
        headertitles: true,
        hidegrid: false,
		rowNum:50,
		rowList:[50,100,150],
		pager : "#grid-pager-locales",
		caption: "Locales encontrados",
		ondblClickRow: function(rowid) {
			aceptarLocalCallback();
		},		
	});
	
	//Al mostrar la página de búsqueda de locales
	//DPORRASC
	/*
	$('#ventanaBuscarLocal').on('shown.bs.modal', function () {
		$(window).triggerHandler('resize.jqGrid');
	});
	*/
	
	//configuramos que la búsqueda de un local especifico se realice al pulsar el botón
	$("#formSearchLocales").submit(function(event){
		event.preventDefault(); 

		var searchFiler = $("#filtro").val();
		var grid = $("#grid-table-locales");
		var f;
		if (searchFiler.length === 0) {
		   grid[0].p.search = false;
		   $.extend(grid[0].p.postData,{filters:""});
		}
		f = {groupOp:"OR",rules:[]};
		f.rules.push({field:"numLocal",op:"cn",data:searchFiler.toUpperCase()});
		f.rules.push({field:"codLocal",op:"cn",data:searchFiler.toUpperCase()});
		f.rules.push({field:"nomLocal",op:"cn",data:searchFiler.toUpperCase()});
		f.rules.push({field:"dirLocal",op:"cn",data:searchFiler.toUpperCase()});
		f.rules.push({field:"ubigeo",op:"cn",data:searchFiler.toUpperCase()});
		f.rules.push({field:"departamento",op:"cn",data:searchFiler.toUpperCase()});
		f.rules.push({field:"provincia",op:"cn",data:searchFiler.toUpperCase()});
		f.rules.push({field:"distrito",op:"cn",data:searchFiler.toUpperCase()});
		 
		grid[0].p.search = true;
		$.extend(grid[0].p.postData,{filters:JSON.stringify(f)});
		grid.trigger("reloadGrid",[{page:1,current:true}]);
	});
	
	
	//Al cambiar el desplegable de departamentos.
	$('#cmbDepartamentos').change(function(e){

		var ajx_dpto=$.trim($("#cmbDepartamentos").val());
		var ajax_data ={"codDepartamento":ajx_dpto};
		$.ajax({   
			url: CONTEXT_PATH+"/consulta.htm?action=getProvincias",
			data: ajax_data,
			type: "post",
			timeout: "60000",
			dataType: "json",
			success: function(respuesta){	
				$('#cmbProvincias').empty();	
				$('#cmbDistritos').empty();
				$('#cmbProvincias').append('<option value="">TODOS</option>');
				$('#cmbDistritos').append('<option value="">TODOS</option>');
				var provincias=respuesta.listProvincias;
				if(provincias!=null){
					$.each(provincias, function(i, item){
						$('#cmbProvincias').append($('<option>', { 
							  value: item.codiProvTpr,
							  text : item.nombProvTpr 
						}));						
					});	
				}
			},
			error:function (xhr, ajaxOptions, thrownError) {	}
		});
	});
	
	
	//Al cambiar el desplegable de provincias.
	$('#cmbProvincias').change(function(e){

		var ajx_dpto=$.trim($("#cmbDepartamentos").val());
		var ajx_prov=$.trim($("#cmbProvincias").val());
		var ajax_data ={"codDepartamento":ajx_dpto,"codProvincia":ajx_prov};
		   			
		$.ajax({   
			url: CONTEXT_PATH+"/consulta.htm?action=getDistritos",
			data: ajax_data,				
			type: "post",
			timeout: "60000",
			dataType: "json",
			success: function(respuesta){				
				$('#cmbDistritos').empty();
				$('#cmbDistritos').append('<option value="">TODOS</option>');
	   		   	var distritos=respuesta.listDistritos;		  
	   		   	if(distritos!=null){
		   		   	$.each(distritos, function(i, item){
	   					$('#cmbDistritos').append($('<option>', { 
	   						  value: item.codiDistTdi,
	   						  text : item.nombDistTdi 
	   					}));
		   			});	
	   		   	}
	   		},
	   		error:function (xhr, ajaxOptions, thrownError) {}
	   	});
			
	});


	//Al buscar los locales de un determinado ubigeo
	$('#btnBuscarLocal').click(function(e){
		
		var departamento=$('#cmbDepartamentos').val();
		var provincia=$('#cmbProvincias').val();	
		var distrito=$('#cmbDistritos').val();
		if ($.trim(departamento)==""){
			bootbox.dialog({message: "Para realizar la b&uacute;squeda debe seleccionar como m&iacute;nimo el Departamento.",title: "Error",
  			  buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
			$('#cmbDepartamentos').focus();
			return;	
		}

		var numNivel = _numNivel;
		if(numNivel==null){
			numNivel = getNivelSeccionadoLocal();
		}

		var listaLocales =  ""; 
		if(_callbackGeneraLista!=null){
			listaLocales = _callbackGeneraLista(); 
		}
	
		var ajax_data ={"codDepartamento":	departamento,"codProvincia":provincia,"codDistrito":distrito,numNivel:numNivel,"listaLocales":listaLocales};

		$.ajax({	
		    url: CONTEXT_PATH+"/consulta.htm?action=listarLocales",				
			data: ajax_data,
			type: "post",
			timeout: "60000",
			dataType: "json",               
			success: function(respuesta) { 
				var listLocales=respuesta.locales;
				//DPORRASC
				$("#grid-table-locales").jqGrid('clearGridData');
				if(listLocales.length==0){
					bootbox.dialog({message: "No se encontraron locales para su criterio de b&uacute;squeda.",title: "Error",
			  			  buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
				}else{
					for(var i=0;i<listLocales.length;i++){
						var s = listLocales[i];
						var datarow = {
								numLocal:s.numLocal,
								codLocal:s.codLocal,
								nomLocal:s.nomLocal,
								dirLocal:s.desDireccion,
								ubigeo:s.codUbigeo,
								departamento:s.desDepartamento,
								provincia:s.desProvincia,
								distrito:s.desDistrito};
						var su=jQuery("#grid-table-locales").jqGrid('addRowData',parseInt(s.numLocal),datarow);
					}
					$("#grid-table-locales").trigger("reloadGrid");	
				}
			},
			error:function (xhr, ajaxOptions, thrownError) {}			 
		});
	});
	
	
	//Al cancelar la búsqueda de locales
	$('#btnCancelarFindPersona').click(function(e){
		$('#ventanaBuscarLocal').modal('hide');
	});
	
	
	var aceptarLocalCallback = function() {
		var numLocalSeleccionado = $("#grid-table-locales").jqGrid('getGridParam','selrow');
		if(numLocalSeleccionado!=null){
			_callbackLocalSeleccionado(numLocalSeleccionado);
			$('#ventanaBuscarLocal').modal('hide');
		}else{
			bootbox.dialog({
    			   message: "Debe seleccionar un local.",title: "Error",
    			   buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
		}		
	}
	
	//Al pulsar el botón de aceptar local.
	$('#btnAceptarLocal').click(function(e){
		aceptarLocalCallback();
	});
	
	
};