package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao;

import java.util.HashMap;
import java.util.List;

import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.AmbitoConfiguradoBean;

/**
 * AmbitoDAO - DAO para el manejo de los Ambitos
 * 
 * @author framirez
 * @since 11/09/2015
 * @version 1.0
 */
public interface AmbitoDAO {

	/**
	 * Listar Ambitos Configurados
	 * 
	 * @author framirez
	 * @since 11/09/2015
	 * @version 1.0
	 * @return Lista AmbitoConfiguradoBean
	 */
	List<AmbitoConfiguradoBean> getAmbitosConfigurado(HashMap<String,Object> parametros);

	/**
	 * Insertar En Ambito - t6600invambitoloc
	 * 
	 * @author framirez
	 * @since 14/09/2015
	 * @version 1.0
	 */
	void insertAmbitosConfigurado(AmbitoConfiguradoBean bean);

	/**
	 * Actualizar En Ambito - t6600invambitoloc
	 * 
	 * @author framirez
	 * @since 14/09/2015
	 * @version 1.0
	 */
	Integer updateAmbitosConfigurado(AmbitoConfiguradoBean bean);
	
	JRBeanCollectionDataSource obtenerConexion();
}
