package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao;

import java.util.List;
import java.util.Map;

//import org.springframework.dao.DataAccessException;


import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.T01Parametro;

public interface T01ParametroDAO {
	//ae96 : Agregar funcionalidad obtener detalles de un parametro
	public  List<T01Parametro> listarDetallesParametro(Map<String, Object> params); 
	
}
