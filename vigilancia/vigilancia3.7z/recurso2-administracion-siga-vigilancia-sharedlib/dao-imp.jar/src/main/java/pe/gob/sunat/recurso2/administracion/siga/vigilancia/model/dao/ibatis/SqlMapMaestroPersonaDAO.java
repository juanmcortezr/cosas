package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ibatis;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.MaestroPersona;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.MaestroPersonaDAO;




/**
 * Implementación del Maestro de persona
 * asignados
 * 
 * @author walter rodriguez 
 * @version 1.0
 */
public class SqlMapMaestroPersonaDAO extends SqlMapClientDaoSupport implements MaestroPersonaDAO {
	protected final Log log = LogFactory.getLog(getClass());
	
	public SqlMapMaestroPersonaDAO(){
		super();
	}


	@SuppressWarnings("unchecked")
	public List<MaestroPersona> getListPersona(MaestroPersona codiDepeTde){
		return (List<MaestroPersona>)getSqlMapClientTemplate().queryForList("Maestro.selectByPrimaryKey", codiDepeTde);
	}

	
	public MaestroPersona getEmpleado(MaestroPersona unidadOrganizacional){
		return (MaestroPersona) getSqlMapClientTemplate().queryForObject("Maestro.selectEmpleadoByParametro", unidadOrganizacional);
	}
	
	public MaestroPersona getEmpleadoWithRegimenAndUuoo(MaestroPersona params){
		return (MaestroPersona) getSqlMapClientTemplate().queryForObject("Maestro.selectEmpleadoByParametroWithRegimenAndUuoo", params);
	}

	
	public MaestroPersona getColaboradorDestinatario(MaestroPersona registroAlterno){
		MaestroPersona respuesta;
		respuesta=(MaestroPersona) getSqlMapClientTemplate().queryForObject("Maestro.selectEmpleadoByParametro", registroAlterno);
		return respuesta;																														
	}

	
	@SuppressWarnings("unchecked")
	public MaestroPersona getEmpleadoPorUsuario(HashMap<String,Object> paramSearch) {
		List<MaestroPersona> empleados = getSqlMapClientTemplate().queryForList("Maestro.selectEmpleadoByUsuario", paramSearch);
		if ( CollectionUtils.isNotEmpty(empleados) ) {
			return empleados.get(0);
		}
		return null;
	}


	@SuppressWarnings("unchecked")
	public List<MaestroPersona> listParamInputLog(MaestroPersona loginUsuario) {
		return  getSqlMapClientTemplate().queryForList("Maestro.dataInputLog", loginUsuario);
	}

	
	@SuppressWarnings("unchecked")
	public List<MaestroPersona> getAnioExpediente() {
		return  getSqlMapClientTemplate().queryForList("Maestro.anioInputLog");
	}

	
	public String crearExpediente(Map<String, Object> parametros) {
		getSqlMapClientTemplate().queryForList("Maestro.crearExpedienteSolicitud", parametros);
		String numExpediente=(String)parametros.get("expediente");
		return 	 numExpediente.trim();
	}


	public MaestroPersona getCodigoEmpleado(MaestroPersona registroAlterno) {							
		return (MaestroPersona) getSqlMapClientTemplate().queryForObject("Maestro.selectCodigoEmpleado", registroAlterno);
	}


	@Override
	public String getRegimenLaboralByCodEmplPer(Map<String, Object> parametro) {
		String regimenLaboral = "";
		regimenLaboral = (String) getSqlMapClientTemplate().queryForObject("Maestro.selectRegimenLaboral", parametro);
				//.queryForList("Maestro.selectRegimenLaboral", parametro);
		return regimenLaboral;
	}


	@Override
	public List<MaestroPersona> buscarMaestroPersonal(
			Map<String, Object> paramSearch) {
		return  getSqlMapClientTemplate().queryForList("Maestro.selectConsulta",paramSearch);
	}


	@Override
	public MaestroPersona obtenerPersonaxRegistro(String codRegistro) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("cod_reg", codRegistro);
		return (MaestroPersona) getSqlMapClientTemplate().queryForObject("Maestro.obtenerPersonaxRegistro", paramSearch);
	}


}