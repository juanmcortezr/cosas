function getDetalleBien(item){
	var codBienPatrimonial=item;
	//enviar al control y mostrar el poput de detalle
	var ajax_data ={"codBien":codBienPatrimonial};
		
	$.ajax({   
		url: CONTEXT_PATH+"/consulta.htm?action=getDetalleBien",
		data: ajax_data,				
		type: "post",
		timeout: "60000",
		dataType: "json",
		success: function(respuesta){		
			var item=respuesta.detalleBienAsignado;
						
			$('#txtdetbienCodigoBien').val(item.codiMarqAct);			
			$('#txtdetbienCodigoAnterior').val(item.codiAnteAct);			
			$('#txtdetbienEstadoBien').val(item.situActiAct);//codSituAct  
			$('#txtdetbienSituacionBien').val(item.codSituAct); 			
			$('#txtdetbienFechaIngresoBien').val(item.fechIngrAct);			
			$('#txtdetbienDescripcionBien').val(item.descActiAct);			
			$('#txtdetbienCodOficinaBien').val(item.unidadOrganizacional);			
			$('#txtdetbienNameOficinaLocal').val(item.descDepeTde);			
			$('#txtdetbienNombreLocalBien').val(item.nomLocalAct);			
			$('#txtdetbienFechaFinBien').val(item.fecAsigAct); 			
			$('#txtdetbienResponsableBien').val(item.nombCortPer); 				
			$('#txtdetbienColaboradorCustodiaBien').val(item.nombreCortoCustodio);
			$('#txtdetbienNumeroInventario').val(item.numUltInv);
			$('#txtdetbienEtiqueta').val(item.flagEtiqAct);
			$('#txtFechaInventarioBien').val(item.fecUltInv);
			$('#txtdetbienFechaInventarioBien').val(item.inveScanAct);			
			$('#txtdetbienNumeroSerie').val(item.nroSeriAct);
			$('#txtdetbienEstadoConservacion').val(item.estaAlmaAct);
			$('#txtdetbienColorBien').val(item.coloAutoAct);								
			$('#txtdetbienMarcaBien').val(item.marca);			
			$('#txtdetbienMaterialBien').val(item.codMatBie);
			$('#txtdetbienModeloBien').val(item.modelo); 
			$('#txtdetbienFechaGarantia').val(item.fecGaraFin);
			$('#txtdetbienMedida').val(item.dimeActiAct);
			//
			$('#txtcapaActiAct').val(item.capaActiAct);
			$('#txtnumVidaUtil').val(item.numVidaUtil);
			//$('#txtnumRucGara').val(item.numRucGara);
			$('#txtnumRucCon').val(item.numRucCon);
			$('#txtnroContCco').val(item.nroContCco);
			$('#txtnroOrdeOco').val(item.nroOrdeOco);
			$('#txtcodOrden').val(item.codOrden);
			$('#txtvaloCompAct').val(item.valoCompAct);
			
			$('#txtfechIngAct').val(item.fechIngAct); //Fecha Cierre
			$('#txtnumMesesGara ').val(item.numMesesGara ); //Meses de garantia
			$('#txtfecVidaUtil').val(item.fecVidaUtil); //Fecha vida util
			//$('#txtfechPecoPec').val(item.fechPecoPec); //fecha primera asignacion
			$('#txtfechPecoPec').val(item.fecAsigActString); //fecha de asignacion del bien
		},
	    error:function (xhr, ajaxOptions, thrownError) {}
	});																
		//mostrar el modal de detalle
	$('#windowDetalleBien').modal('show');
	
}


function getDetalleBienInventario(item, flagEstadoBienConformidad){
	var codBienPatrimonial=item;
	//enviar al control y mostrar el poput de detalle
	var ajax_data ={"codBien":codBienPatrimonial , "flagEstadoBienConformidad":flagEstadoBienConformidad};
		
	$.ajax({   
		url: CONTEXT_PATH+"/consulta.htm?action=getDetalleBienInventario",
		data: ajax_data,				
		type: "post",
		timeout: "60000",
		dataType: "json",
		success: function(respuesta){		
			var item=respuesta.detalleBienAsignado;
			debugger;			
			$('#txtdetbienCodigoBien').val(item.codiMarqAct);			
			$('#txtdetbienCodigoAnterior').val(item.codiAnteAct);			
			$('#txtdetbienEstadoBien').val(item.situActiAct);//codSituAct  
			$('#txtdetbienSituacionBien').val(item.codSituAct); 			
			$('#txtdetbienFechaIngresoBien').val(item.fechIngrAct);			
			$('#txtdetbienDescripcionBien').val(item.descActiAct);			
			$('#txtdetbienCodOficinaBien').val(item.unidadOrganizacional);			
			$('#txtdetbienNameOficinaLocal').val(item.descDepeTde);			
			$('#txtdetbienNombreLocalBien').val(item.nomLocalAct);			
			$('#txtdetbienFechaFinBien').val(item.fecAsigAct); 			
			$('#txtdetbienResponsableBien').val(item.nombCortPer); 				
			$('#txtdetbienColaboradorCustodiaBien').val(item.nombreCortoCustodio);
			$('#txtdetbienNumeroInventario').val(item.numUltInv);
			$('#txtdetbienEtiqueta').val(item.flagEtiqAct);
			$('#txtFechaInventarioBien').val(item.fecUltInv);
			$('#txtdetbienFechaInventarioBien').val(item.inveScanAct);			
			$('#txtdetbienNumeroSerie').val(item.nroSeriAct);
			$('#txtdetbienEstadoConservacion').val(item.estaAlmaAct);
			$('#txtdetbienColorBien').val(item.coloAutoAct);								
			$('#txtdetbienMarcaBien').val(item.marca);			
			$('#txtdetbienMaterialBien').val(item.codMatBie);
			$('#txtdetbienModeloBien').val(item.modelo); 
			$('#txtdetbienFechaGarantia').val(item.fecGaraFin);
			$('#txtdetbienMedida').val(item.dimeActiAct);
			//
			$('#txtcapaActiAct').val(item.capaActiAct);
			$('#txtnumVidaUtil').val(item.numVidaUtil);
			//$('#txtnumRucGara').val(item.numRucGara);
			$('#txtnumRucCon').val(item.numRucCon);
			$('#txtnroContCco').val(item.nroContCco);
			$('#txtnroOrdeOco').val(item.nroOrdeOco);
			$('#txtcodOrden').val(item.codOrden);
			$('#txtvaloCompAct').val(item.valoCompAct);
			
			$('#txtfechIngAct').val(item.fechIngAct); //Fecha Cierre
			$('#txtnumMesesGara ').val(item.numMesesGara ); //Meses de garantia
			$('#txtfecVidaUtil').val(item.fecVidaUtil); //Fecha vida util
			//$('#txtfechPecoPec').val(item.fechPecoPec); //fecha primera asignacion
			$('#txtfechPecoPec').val(item.fecAsigActString); //fecha de asignacion del bien
		},
	    error:function (xhr, ajaxOptions, thrownError) {}
	});																
		//mostrar el modal de detalle
	$('#windowDetalleBien').modal('show');
	
}