	
	function iniciarVentanaBuscarUUOOForm(){
		iniciarTablaUUOOs();
		asignarEventosUuoo();
		$('#ventanaBuscarUUOO').on('shown.bs.modal', function () {
			$(window).triggerHandler('resize.jqGrid');
			$("#txtUUOOParm").val("");
			$("#txtUUOOParm").focus();
		});
		
		//formulario de búsqueda de UUOOs
		$("#buscarUUOOForm").submit(function(e){
	        e.preventDefault();
	        buscarJqGridUUOOs();
	    });
		
	}
	
	function asignarEventosUuoo(){
		addEventElement("btnAceptarUUOO", "click", clickBtnAceptarUUOO);
		addEventElement("btnCancelarFindUUOO", "click", clickBtnCancelarFindUUOO);
		addEventElement("btnBuscarUUOO", "click", clickBtnBuscarUUOO);
	}
	
	function clickBtnBuscarUUOO(e){ buscarJqGridUUOOs();};
	function clickBtnAceptarUUOO(e){ aceptarUUOOCallback();	};
	function clickBtnCancelarFindUUOO(e){ $('#ventanaBuscarUUOO').modal('hide'); }; 
	
	//CONSTRUIR GRID//
	function iniciarTablaUUOOs(){
		//formulario de búsqueda de UUOOs
		var tblUUOOs = $("#tblUUOOs");
		var heightJqGrid = 180;
		setStyleElement("divUUOOsTable", "height", obtenerHeightJqGridDiv(heightJqGrid, 1, false));
		if (tblUUOOs) {
			var divUUOOsTable = $("#divUUOOsTable");
			var widthTable = divUUOOsTable.width();
		
			tblUUOOs.jqGrid({
				datatype: "local",
				height: heightJqGrid,
				width: widthTable,	
				shrinkToFit: false,
				forceFit:true,
				cmTemplate: { sortable: true, title: false },
				colNames:['UUOO','Nombre UUOO','codiDepeTde'],
				colModel:[
				        {name:'codUnidadOrganizacional',index:'codUnidadOrganizacional',width:150},
						{name:'descdepetde',index:'descdepetde',width:650},
						{name:'codiDepeTde',key: true,index:'codiDepeTde', width:0, hidden: true}
					], 
				viewrecords : true,
				recordpos:'left',
				pagerpos:'right',
				altRows: true,
				multiselect: false,
				multiboxonly: true,
				headertitles: true,
				hidegrid: false,
				rowNum:10,
				rowList:[10,20,30],
				pager : "#pagerUUOOsTable",
				autowidth: true,
				loadui: "disable",
				ondblClickRow: function(rowid) {
					aceptarUUOOCallback(); //Doble clic para agregara la grilla
				}
			});
			
			tblUUOOs.clearGridData();
		}
		$(window).on('resize.jqGrid', function () {
			var offset = 50;
			var w = tblUUOOs.closest('.panel').width();
			tblUUOOs.jqGrid('setGridWidth', w-offset);
		});
   	}
	
	//Doble clic para agregar a la grilla
	var aceptarUUOOCallback = function() {
		var codDependencia = $("#tblUUOOs").jqGrid('getGridParam','selrow');
		if(codDependencia!=null){
			var datosDependencia = $("#tblUUOOs").jqGrid('getRowData', codDependencia);
			cargarUUOOSeleccionado(datosDependencia);
			$('#ventanaBuscarUUOO').modal('hide');
		}else{
			bootbox.dialog({message: "Debe seleccionar un UUOO.",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
		}
   	};
   	
	function cargarUUOOSeleccionado(uuoo){
		$("#txtUUOO").val(uuoo.codUnidadOrganizacional);
		$("#txtDesUUOO").val(uuoo.descdepetde); 
	};


   	//When you press buscar in UUOOs====
	function buscarJqGridUUOOs(){
		//$('#tblUUOOs.loading').show();
		var tipoBuscarUUOO=$('#tipoBuscarUUOO').val();
		var parmBuscaUUOO=$('#txtUUOOParm').val();	
		
		if ( $.trim(tipoBuscarUUOO)==""  || $.trim(tipoBuscarUUOO)=="0" ){
			bootbox.dialog({message: "Debe seleccionar el criterio de b&uacute;squeda.",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
			return;	
		}
		if ( $.trim(parmBuscaUUOO)==""){
			bootbox.dialog({message: "Debe ingresar el texto a buscar.",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
			return;	
		}
		
		var ajax_data ={
			"tipoBuscaUUOO"		:	tipoBuscarUUOO,
			"parmBuscaUUOO"	 	:	parmBuscaUUOO
		};
		$("#tblUUOOs").jqGrid('clearGridData');	
		
		$.ajax({	
		    url: CONTEXT_PATH+"/consulta.htm?action=getCargaUUOOs",				
			data: ajax_data,
			type: "post",
			timeout: "60000",
			dataType: "json",
			success: function(respuesta) { 
				var listUUOOs=respuesta.listUUOOs;
				// lo que estaba antes
					if(listUUOOs.length==0) {
						bootbox.dialog({message: "No se encontraron UUOOs para su criterio de b&uacute;squeda.",buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
					} else{
						for(var i=0;i<listUUOOs.length;i++){
							var c= listUUOOs[i];
							var datarow = {
								codUnidadOrganizacional:c.codUnidadOrganizacional,
								descdepetde:c.descdepetde,
								codiDepeTde:c.codiDepeTde
							};
							var su=jQuery("#tblUUOOs").jqGrid('addRowData',c.codiDepeTde,datarow);
						}
						
						$("#tblUUOOs").trigger("reloadGrid");	
					}
			},
			complete: function (data, status) {
			},
			error:function (xhr, ajaxOptions, thrownError) {}			 
		});
	};

	   	
	var buscarUUOO = function(numRegistro){
		if ($.trim(numRegistro)==""){
			alert('Debe Ingresar Numero de Registro');
			return;	
		}
		
		var ajax_data ={"parmBuscaUUOO":numRegistro};
		
		$.ajax({	
		    url: CONTEXT_PATH+"/Inventario.htm?action=getUUOOPorRegistro",				
			data: ajax_data,
			type: "post",
			timeout: "60000",
			dataType: "json",               
			success: function(respuesta) { 
					var UUOO=respuesta.UUOO;
					if (UUOO.numero_registro){
						alert('El registro de UUOO no existe');
					}else{
						buscarUUOOCallBack( UUOO.numero_registro, UUOO.nombre_completo,UUOO.codigoEmpleado);
					}
				},
			complete: function (data, status) {},
			error:function (xhr, ajaxOptions, thrownError) {}			 
		});
   	};
		 