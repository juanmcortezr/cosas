package pe.gob.sunat.recurso2.administracion.siga.vigilancia.registro.web.controller;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.firma.model.bean.T5282Archbin;
import pe.gob.sunat.recurso2.administracion.siga.firma.service.ConsultaFirmaService;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.service.GestionVigilanciaService;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.service.LocalService;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.util.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActSolTra;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActSolTraDet;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActivoFijo;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.InmLocalTdepe;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Inmueble;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.MaestroPersona;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.SysRegistroArchivosFisico;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Tdependencias;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.constantes.VigilanciaConstantes;

public class ConsultaVigilanciaController extends MultiActionController {
	
	private String jsonView;
	private JsonSerializer jsonSerializer;
	
	private RegistroGeneralService registroGeneralService;
	private RegistroPersonalService registroPersonalService;
	private RegistroDependenciasService registroDependenciasService;
	
	private RegistroArchivosService registroArchivosService;
	private GestionVigilanciaService gestionVigilanciaService;
	private ConsultaFirmaService consultaFirmaService;
	
	private LocalService localService;
	
	protected final Log log = LogFactory.getLog(getClass());	
	
	
	public ModelAndView iniciarConsulta(HttpServletRequest request, HttpServletResponse response) {
		
		log.debug("debug Inicio - ConsultaSolicitudController.iniciarConsulta");
		
		ModelAndView modelAndView;
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		String pagina = "";
		String mensajeError = "";
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		try {
			
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			List<T01ParametroBean> listaTipoMovimiento;
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cod_par", "0025");
			params.put("cod_mod", "MUEB");
			params.put("cod_tipo", "D");
			
			listaTipoMovimiento = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);

			List<T01ParametroBean> listaClaseMovimiento;
			
			params = new HashMap<String, Object>();
			params.put("cod_par", "0026");
			params.put("cod_mod", "MUEB");
			params.put("cod_tipo", "D");
			
			listaClaseMovimiento = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			
			List<T01ParametroBean> listaEstado;
			
			params = new HashMap<String, Object>();
			params.put("cod_par", "0028");
			params.put("cod_mod", "MUEB");
			params.put("cod_tipo", "D");
			
			String codEstadoInicial = VigilanciaConstantes.SOLICITUD_REGISTRADA;//registrado
			String descEstado = "";
			listaEstado = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			for (T01ParametroBean estado : listaEstado) {
				if (codEstadoInicial.trim().equals(estado.getCod_argumento().trim())) {
					descEstado = estado.getNom_largo();
				}
			}
			
			String registro = usuarioBean.getNroRegistro();
			MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxRegistro(registro);
			DependenciaBean dependencia = registroDependenciasService.obtenerDependenciaXcod(colaborador.getCodigoDependencia());
			MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(dependencia.getCodEmpleado());
			
			InmLocalTdepe inmLocalTdepeParam = new InmLocalTdepe();
			inmLocalTdepeParam.setCodDepeTde(dependencia.getCod_dep());
			List<InmLocalTdepe> localesDependencia = gestionVigilanciaService.recuperarListaLocalesPorUuoo(inmLocalTdepeParam);
			
			if (log.isDebugEnabled())log.debug("getApeMaterno:"		+usuarioBean.getApeMaterno());
			if (log.isDebugEnabled())log.debug("getApePaterno:"		+usuarioBean.getApePaterno());
			if (log.isDebugEnabled())log.debug("getCodDepend:"		+usuarioBean.getCodDepend());
			if (log.isDebugEnabled())log.debug("getCodUO:"			+usuarioBean.getCodUO());
			if (log.isDebugEnabled())log.debug("getCorreo:"			+usuarioBean.getCorreo());
			if (log.isDebugEnabled())log.debug("getLogin:"			+usuarioBean.getLogin());
			if (log.isDebugEnabled())log.debug("getNombreCompleto:"	+usuarioBean.getNombreCompleto());
			if (log.isDebugEnabled())log.debug("getNombres:"		+usuarioBean.getNombres());
			if (log.isDebugEnabled())log.debug("getNroRegistro:"	+usuarioBean.getNroRegistro());
			if (log.isDebugEnabled())log.debug("getTicket:"			+usuarioBean.getTicket());
			
			respuesta.put("login", usuarioBean.getLogin());
			respuesta.put("colaborador", jsonSerializer.serialize(colaborador));
			respuesta.put("dependencia", jsonSerializer.serialize(dependencia));
			respuesta.put("autorizador", jsonSerializer.serialize(autorizador));
			respuesta.put("localesDependencia", jsonSerializer.serialize(localesDependencia).toString().replaceAll("\\\\", "\\\\\\\\"));
			
			respuesta.put("listaTipoMovimiento", jsonSerializer.serialize(listaTipoMovimiento));
			respuesta.put("listaClaseMovimiento", jsonSerializer.serialize(listaClaseMovimiento));
			respuesta.put("listaEstado", jsonSerializer.serialize(listaEstado));
			
			respuesta.put("codEstadoSolicitud", codEstadoInicial);
			respuesta.put("descEstadoSolicitud", descEstado);
			respuesta.put("datosUsuario", jsonSerializer.serialize(usuarioBean));
			
			pagina = "paginaConsultaVigilancia";
		}
		catch(Exception e){
			log.error(e.getMessage(), e);
			pagina = "paginaErrorSistema";
			mensajeError = "A ocurrido un inconveniente por favor comuniquese con el Administrador." + e.getMessage();
		}
		finally{
			respuesta.put("mensajeError", mensajeError);
			modelAndView = new ModelAndView(pagina,respuesta);
			log.debug("Fin ConsultaSolicitudController.iniciarConsulta");
		}
		
		return modelAndView;
	}
	
	
	/**
	 * @author arosalesa	
	 * @return Devuelve los resultados despues de presionar buscar en la consulta de bienes asignados general
	 * @throws Exception
	 */
	public ModelAndView getConsultarBienesAsignados(HttpServletRequest request,HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		List<ActivoFijo> bienesFiltrados=null;
		
		try {
			log.debug("Iniciando control patrimonial -- getConsultarBienesAsignados");			
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			request.getSession().setAttribute("usuarioBean", usuarioBean);
			
			String nroRegistro=(request.getParameter("nroRegistro")==null?"":request.getParameter("nroRegistro"))   ;
			String codPatrimonial=(request.getParameter("codPatrimonial")==null?"":request.getParameter("codPatrimonial"))   ;
			String uuoo=(request.getParameter("uuoo")==null?"":request.getParameter("uuoo"))   ;			
			String strNumLocalOrigen=(request.getParameter("numLocalOrigen")==null?"":request.getParameter("numLocalOrigen"))   ;
			
			Integer numLocalOrigen= null;			
			try{ 
				numLocalOrigen= Integer.valueOf(Integer.parseInt(strNumLocalOrigen));
			}
			catch(NumberFormatException e ){
				numLocalOrigen=null;
			}
			
			if (nroRegistro.isEmpty() && codPatrimonial.isEmpty() && uuoo.isEmpty() && numLocalOrigen==null ){
				bienesFiltrados= new ArrayList<ActivoFijo>();
			}
			else{
				bienesFiltrados = gestionVigilanciaService.consultarBienesAsignados(nroRegistro,codPatrimonial,uuoo,numLocalOrigen);		
				if (bienesFiltrados==null)
					bienesFiltrados= new ArrayList<ActivoFijo>();
			}
			
			respuesta.put("lista", bienesFiltrados);
			
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

	
	public ModelAndView getConsultarBienesAsignadosColaborador(HttpServletRequest request,HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		List<ActivoFijo> bienesFiltrados=null;
		
		try {
			log.debug("Iniciando control patrimonial -- getConsultarBienesAsignados");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			request.getSession().setAttribute("usuarioBean", usuarioBean);

			ActivoFijo param = new ActivoFijo();
			
			String selBuscarBienes = (request.getParameter("selBuscarBienes")==null?"":request.getParameter("selBuscarBienes"));
			String txtBuscarBienes = (request.getParameter("txtBuscarBienes")==null?"":request.getParameter("txtBuscarBienes"));
			if ("C".equals(selBuscarBienes)) {
				param.setCodiMarcMar(txtBuscarBienes);
			}
			else if ("D".equals(selBuscarBienes)) {
				param.setDescActiAct(txtBuscarBienes);
			}
			
			String nroRegistroAsignado = (request.getParameter("txtRegistroAsignado")==null?"":request.getParameter("txtRegistroAsignado"));
			nroRegistroAsignado = nroRegistroAsignado.toUpperCase();
			MaestroPersonalBean colaboradorAsignado = registroPersonalService.obtenerPersonaxRegistro(nroRegistroAsignado);
			if (colaboradorAsignado == null)
				colaboradorAsignado = new MaestroPersonalBean();
			
			String codigoAsignado = colaboradorAsignado.getCodigoEmpleado();
			param.setCodiEmpAct(codigoAsignado);
			
			String strNumLocalOrigen = (request.getParameter("selLocalOrigen")==null?"":request.getParameter("selLocalOrigen"));Integer numLocalOrigen= null;
			log.debug("pregunta en getConsultarBienesAsignados: " + selBuscarBienes + " 2: " + txtBuscarBienes + " 3: " + nroRegistroAsignado + " 4: " + strNumLocalOrigen + " 5: " + nroRegistroAsignado + " 6: " + codigoAsignado);
			try{
				numLocalOrigen= Integer.valueOf(Integer.parseInt(strNumLocalOrigen));
			}
			catch(NumberFormatException e ){
				numLocalOrigen=null;
			}
			param.setNumLocalAct(numLocalOrigen);
			
			//param.setBienMovFrec("1");//solo tiene que ser un valor distinto a nulo para que se filtre por bienes de movimiento frecuente
			
			if (codigoAsignado.isEmpty() && numLocalOrigen == null && selBuscarBienes.isEmpty()){
				bienesFiltrados= new ArrayList<ActivoFijo>();
			}
			else{
				bienesFiltrados = gestionVigilanciaService.recuperarListaBienes(param);		
				if (bienesFiltrados == null)
					bienesFiltrados = new ArrayList<ActivoFijo>();
			}
			
			respuesta.put("error", "0"); 
			respuesta.put("lista", bienesFiltrados);
			
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

	/**
	 * @author arosalesa	
	 * @return Devuelve datos de un bien de acuerdo a su codigo patrimonial
	 * @throws Exception
	 */	 
	public ModelAndView getDetalleBien(HttpServletRequest request,HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		ActivoFijo detalleBienAsignado=null;
		try {
			log.debug("Iniciando control patrimonial -- getDetalleBien");
			String codBienAsignado=request.getParameter("codBien");
			detalleBienAsignado = gestionVigilanciaService.recuperarBienPorCodigoBien(codBienAsignado);
			respuesta.put("detalleBienAsignado", detalleBienAsignado);
			
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * @author arosalesa	
	 * @return Devuelve datos de un bien de acuerdo a su codigo patrimonial
	 * @throws Exception
	 */	 
	public ModelAndView getDetalleBienInventario(HttpServletRequest request,HttpServletResponse response) {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		MaestroPersona colaborador = gestionVigilanciaService.maestroPersona(usuarioBean.getNroRegistro());
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		ActivoFijo detalleBienAsignado=null;
		try {
			log.debug("Iniciando control patrimonial -- getDetalleBien");
			String codBienAsignado=request.getParameter("codBien");
			String flagEstadoBienConformidad=request.getParameter("flagEstadoBienConformidad");
			detalleBienAsignado = gestionVigilanciaService.selectByPrimaryKeyInventario(codBienAsignado, colaborador.getCodiEmplPer(),flagEstadoBienConformidad);
			respuesta.put("detalleBienAsignado", detalleBienAsignado);
			
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	public ModelAndView getCargaColaboradores(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		Map<String, Object> parmSearch = new HashMap<String, Object>();
		ModelAndView viewPage = null;

		try {
			String tipoBuscaColaborador = request.getParameter("tipoBuscaColaborador");
			String parmBuscaColaborador = StringUtils.trimToEmpty(request.getParameter("parmBuscaColaborador")).toUpperCase();
			String paramRestringirUuoo = request.getParameter("paramRestringirUuoo");

			parmSearch.put("esta_trab_per", VigilanciaConstantes.ESTADO_EMPLEADO_ACTIVO); // busca activos (como estaba antes)

			if (tipoBuscaColaborador.equals("1")) {
				// busqueda por codigo de registro
				parmSearch.put("cod_reg", "%" + parmBuscaColaborador + "%");

			} else if (tipoBuscaColaborador.equals("2")) {
				parmSearch.put("nom_per", '%' + parmBuscaColaborador + "%");
			} else if (tipoBuscaColaborador.equals("3")) {
				parmSearch.put("uuoo", '%' + parmBuscaColaborador + "%");
			}
			
			if (paramRestringirUuoo != null) {
				parmSearch.put("uuoo", paramRestringirUuoo);
			}

			List<MaestroPersona> listColaboradores = (List<MaestroPersona>) gestionVigilanciaService .buscarColaboradores(parmSearch);

			// caso especial, si busca por tipo de registro y no hay resultado, buscarlo como inactivo para mostrar en pantalla.
			/*if (StringUtils.equals(tipoBuscaColaborador, "1") && CollectionUtils.isEmpty(listColaboradores)) {

				// busca como inactivo
				parmSearch.put("esta_trab_per", Constantes.ESTADO_EMPLEADO_INACTIVO);
				listColaboradores = (List<MaestroPersona>) tomaDeInventarioService.buscarColaboradores(parmSearch);

				if ( CollectionUtils.isNotEmpty(listColaboradores) ) {
					respuesta.put("esColaboradorInactivo", "si");
				} else {
					respuesta.put("esColaboradorNoExiste", "si");
				}
			}*/

			respuesta.put("listColaboradores", listColaboradores);

		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	public ModelAndView getColaboradorPorRegistro(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		try {
			String parmBuscaColaborador = (request.getParameter("parmBuscaColaborador").isEmpty() ? null : request.getParameter("parmBuscaColaborador"));
			MaestroPersona colaborador = (MaestroPersona) gestionVigilanciaService.obtenerPersonaxRegistro(parmBuscaColaborador);
			if (colaborador == null) {
				colaborador = new MaestroPersona();
				colaborador.setNumeroRegistroAlterno("-1");
			}
			respuesta.put("colaborador", colaborador);
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	
	
	public ModelAndView getCargaUUOOs(HttpServletRequest request, HttpServletResponse response) {
		if (log.isDebugEnabled()){ log.debug("debug Inicio - InventarioController.getCargaUUOOs");}
		Map<String, Object> respuesta = new HashMap<String, Object>();
		Map<String, Object> parmSearch = new HashMap<String, Object>();
		ModelAndView viewPage = null;
	
		try {
			String tipoBuscaUUOO = request.getParameter("tipoBuscaUUOO");
			log.debug("tipoBuscaUUOO>>>: "+tipoBuscaUUOO);
			
			String parmBuscaUUOO = StringUtils.trimToEmpty(request.getParameter("parmBuscaUUOO")).toUpperCase();
			log.debug("parmBuscaUUOO>>>: "+parmBuscaUUOO);
			
			if (tipoBuscaUUOO.equals("1")) {
				parmSearch.put("codUnidadOrganizacional", "%" + parmBuscaUUOO + "%");
			} else if (tipoBuscaUUOO.equals("2")) {
				parmSearch.put("descdepetde", '%' + parmBuscaUUOO + "%");
			} 
			//List<MaestroPersona> listColaboradores = (List<MaestroPersona>) tomaDeInventarioService.buscarColaboradores(parmSearch);
			List<Tdependencias> listUUOOs = (List<Tdependencias>) gestionVigilanciaService.buscarUUOOs(parmSearch);
			
			respuesta.put("listUUOOs", listUUOOs);
	
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		finally{
			if (log.isDebugEnabled()){ log.debug("debug Inicio - InventarioController.getCargaUUOOs");}
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

	
	/*public ModelAndView iniciarAsignacion(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ModelAndView view = null;
		
		try {
			log.debug("Iniciando asignacion de locales...");
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, VigilanciaConstantes.USUARIO_BEAN_NAME);
			log.debug("Usuario bean del local:"+usuarioBean.getNroRegistro()+", codigo de la unidad organizacional:"+usuarioBean.getCodUO());
			Map<String, Object> respuesta = new HashMap<String, Object>();
			respuesta.put("dependencias", localService.listarUnidadesOrganizacionalesPorUUOOdeJefe(usuarioBean.getCodUO()));
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		view = new ModelAndView("localDependenciaForm",respuesta);
		return view;
	}*/
	
	
	public ModelAndView listarLocales(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String,Object> resultado = new HashMap<String,Object>();
		
		try {
			Integer numNivel = new Integer(request.getParameter("numNivel"));
			String codDepartamento = request.getParameter("codDepartamento");
			String codProvincia = request.getParameter("codProvincia");
			String codDistrito = request.getParameter("codDistrito");
			String listaLocales = request.getParameter("listaLocales");
			Map<String,Object> parametros = new HashMap<String,Object>();
			parametros.put("numNivel",numNivel);
			parametros.put("codDepartamento",StringUtils.isBlank(codDepartamento)?null:codDepartamento);
			parametros.put("codProvincia",StringUtils.isBlank(codProvincia)?null:codProvincia);
			parametros.put("codDistrito",StringUtils.isBlank(codDistrito)?null:codDistrito);
			parametros.put("listaLocales",StringUtils.isBlank(listaLocales)?null:listaLocales);
			resultado.put("locales",localService.listarLocalesAll(parametros));
		}
		catch (Exception e) {
			resultado.put("error", "1"); 
			resultado.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(),resultado);
	}
	
	
	public ModelAndView listarLocalesPorDependencia(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String,Object> resultado = new HashMap<String,Object>();
		
		try {
			String codDependencia = request.getParameter("codDependencia");
			List<Inmueble> locales = localService.listarLocalesPorUnidadOrganizacional(codDependencia);
			resultado.put("locales",locales);
		}
		catch (Exception e) {
			resultado.put("error", "1"); 
			resultado.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(), resultado);
	}
	
	
	public ModelAndView listarCodigosDeLocalPorUsuarioYUnidad(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String,Object> resultado = new HashMap<String,Object>();
		String listaCodigos="";
		//DPORRASC
		try {
			Map<String,Object> parametros = new HashMap<String,Object>();
			String numeroRegistro = StringUtils.trimToNull( request.getParameter("numeroRegistro"));
			String codigoUUOO =  StringUtils.trimToNull(request.getParameter("codigoUUOO"));
			
			//parametros.put("numeroRegistro",StringUtils.isBlank(numeroRegistro)?null:numeroRegistro);
			//parametros.put("codigoUUOO",StringUtils.isBlank(codigoUUOO)?null:codigoUUOO);
			if(numeroRegistro!=null ||codigoUUOO!=null ){
				parametros.put("numeroRegistro",numeroRegistro);
				parametros.put("codigoUUOO",codigoUUOO);
				
				listaCodigos = localService.listarCodigosDeLocalPorUsuarioYUnidad(parametros);
				
			}
			resultado.put("listaCodigos", listaCodigos);
		}
		catch (Exception e) {
			resultado.put("error", "1"); 
			resultado.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(),resultado);
	}
	
	
	public ModelAndView listarCodigosDeLocalPorUsuarioYDeposito(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String,Object> resultado = new HashMap<String,Object>();
		
		try {
			Map<String,Object> parametros = new HashMap<String,Object>();
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, VigilanciaConstantes.USUARIO_BEAN_NAME);
			Integer codDeposito = new Integer(request.getParameter("codDeposito"));
			parametros.put("codDeposito",codDeposito);
			parametros.put("numeroRegistro",usuarioBean.getNroRegistro());
			String listaCodigos = localService.listarCodigosDeLocalPorUsuarioYDeposito(parametros);
			resultado.put("listaCodigos",listaCodigos);
		}
		catch (Exception e) {
			resultado.put("error", "1"); 
			resultado.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(),resultado);
	}
	
	
	public ModelAndView listarCodigosDeLocalPorUsuarioYDepositoTraslado(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String,Object> resultado = new HashMap<String,Object>();
		
		try {
			Map<String,Object> parametros = new HashMap<String,Object>();
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, VigilanciaConstantes.USUARIO_BEAN_NAME);
			Integer codDeposito = new Integer(request.getParameter("codDeposito"));
			
			String numLocalDistintoString = request.getParameter("numLocalDistinto");
			if(!"".equals(numLocalDistintoString.trim())){//Si es distinto a vacio
				Integer numLocalDistinto = new Integer(numLocalDistintoString.trim());
				parametros.put("numLocalDistinto",numLocalDistinto);
			}
			
			parametros.put("codDeposito",codDeposito);
			parametros.put("numeroRegistro",usuarioBean.getNroRegistro());
			String listaCodigos = localService.listarCodigosDeLocalPorUsuarioYDepositoTraslado(parametros);
			resultado.put("listaCodigos",listaCodigos);
		}
		catch (Exception e) {
			resultado.put("error", "1"); 
			resultado.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(),resultado);
	}
	
	
	public ModelAndView listarCodigosDeLocalPorColaboradorDestinatario(HttpServletRequest request, HttpServletResponse response) {
		log.debug("listarCodigosDeLocalPorColaboradorDestinatario");
		Map<String,Object> resultado = new HashMap<String,Object>();
		
		try {
			Map<String,Object> parametros = new HashMap<String,Object>();
			String numeroRegistroColabDestino = request.getParameter("numeroRegistroColabDestino");
			parametros.put("numeroRegistroColabDestino", numeroRegistroColabDestino.toUpperCase());
			String listaCodigos = localService.listarCodigosDeLocalPorColaboradorDestinatario(parametros);
			resultado.put("listaCodigos", listaCodigos);
		}
		catch (Exception e) {
			resultado.put("error", "1"); 
			resultado.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(),resultado);
	}
	
	public ModelAndView listarCodigosDeLocalPorColaboradorDestinatarioFiltro(HttpServletRequest request, HttpServletResponse response) {
		log.debug("listarCodigosDeLocalPorColaboradorDestinatarioFiltro-emarchena");
		Map<String,Object> resultado = new HashMap<String,Object>();
		
		try {
			Map<String,Object> parametros = new HashMap<String,Object>();
			String numeroRegistroColabDestino = request.getParameter("numeroRegistroColabDestino");
			String codLocalOrigen = request.getParameter("codLocalOrigen");
			String numLocalFindNoAsignacionOrigen = request.getParameter("numLocalFindNoAsignacionOrigen");
			
			log.debug("codLocalOrigen"+ codLocalOrigen);
			log.debug("codLocalOrigen"+ numLocalFindNoAsignacionOrigen);
			parametros.put("numeroRegistroColabDestino", numeroRegistroColabDestino.toUpperCase());
			parametros.put("numLocalOrigen", numLocalFindNoAsignacionOrigen);
			String listaCodigos = localService.listarCodigosDeLocalPorColaboradorDestinatarioFiltro(parametros);
			resultado.put("listaCodigos", listaCodigos);
		}
		catch (Exception e) {
			resultado.put("error", "1"); 
			resultado.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(),resultado);
	}
	
	
	public ModelAndView listarCodigosDeLocalPorInventariador(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String,Object> resultado = new HashMap<String,Object>();
		
		try {
			Map<String,Object> parametros = new HashMap<String,Object>();
			String codPersonal = request.getParameter("codPersonaInventario");
			Integer numNivel = new Integer(request.getParameter("numNivel"));
			parametros.put("codPersonal",codPersonal);
			parametros.put("numNivel",numNivel);
			String listaCodigos = localService.listarCodigosDeLocalPorInventariador(parametros);
			resultado.put("listaCodigos",listaCodigos);
		}
		catch (Exception e) {
			resultado.put("error", "1"); 
			resultado.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(), resultado);
	}
	
	public ModelAndView validaLocalInventario(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String,Object> resultado = new HashMap<String,Object>();
		
		try {
			//Map<String,Object> parametros = new HashMap<String,Object>();
			String codInventario = request.getParameter("codInventario");
			Integer numLocal = new Integer(request.getParameter("numLocal"));
			String codPersInv = request.getParameter("codPersInv");
			String mensajeError = localService.validarInventarioLocal(codInventario, numLocal,codPersInv);
			resultado.put("mensajeError", mensajeError);//si es null todo es ok.
		}
		catch (Exception e) {
			resultado.put("error", "1"); 
			resultado.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(), resultado);
	}
	
	/**
     * Recuperar Contacto de Patrimonio .
     * @param  request
     * @param  response 
     * @return ModelAndView 
     **/
	public ModelAndView recuperarPersonaJson(HttpServletRequest request, HttpServletResponse response) {
		if (log.isDebugEnabled()){ log.debug("debug Inicio - SolicitudMovimientoPersonalController.recuperarPersonaJson");}
		Map<String, Object> params = new HashMap<String, Object>();
		Map<String, Object> data = new HashMap<String, Object>();
		try {
			MaestroPersona personal=new MaestroPersona();
			String txtNroRegistro = StringUtils.trim(request.getParameter("txtNroRegistro"));
			log.debug("Numero Registro:" + txtNroRegistro);
			params.put("cod_reg", txtNroRegistro);
			//personal=registroPersonalService.obtenerPersonaxRegistro(cod_reg);
			personal = gestionVigilanciaService.getSelectColaboradorDestinatario(txtNroRegistro.toUpperCase());
			
			if (personal !=null){
				//data.put("cod_contacto", personal.getCodiEmplPer());
				data.put("personal", personal);
				data.put("personaNombre",personal.getNombCortPer());
				data.put("error", "0");
			}else{
				//data.put("nom_contacto",messageSource.getMessage("error.registrarRqnp.contacto" , null, Locale.getDefault()));
				data.put("error", "1");
				//data.put("cod_contacto","-1");
				//data.put("mensaje", messageSource.getMessage("error.registrarRqnp.contacto" , null, Locale.getDefault()));	
			}
			
		}
		catch(Exception ex){
			log.error("Error en SolicitudMovimientoPersonalController.recuperarPersonaJson: " + ex.getMessage(), ex);
		}
		finally{
			if (log.isDebugEnabled()){ log.debug("Fin - RqnpController.recuperarPersonaJson");}
		}
		return new ModelAndView(getJsonView(), data) ;
	}
	
	/*public ModelAndView grabarLocales(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String,Object> resultado = new HashMap<String,Object>();
		
		try {
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, Constantes.USUARIO_BEAN_NAME);
			resultado.put("actualizado","0");
			String codDependencia = request.getParameter("codDependencia");
			String data = request.getParameter("data");
			
			//data = data+"numLocal:"+fila.numLocal+",indPrincipal:"+fila.indPrincipal+",indAsignado:"+fila.indAsignado+";";
			String[] locales = data.split(";");
			List<LocalDependencia> localesArray = new ArrayList<LocalDependencia>();
			
			for(String local:locales){
				String[] dataLocal = local.split(",");
				LocalDependencia localObject = new LocalDependencia();
				localObject.setIndDel("0");
				localObject.setFecRegis(new Date());
				localObject.setCodUsuRegis(usuarioBean.getNroRegistro());
				localObject.setFecModif(new Date());
				localObject.setCodUsuModif(usuarioBean.getNroRegistro());
				localObject.setNumLocal(Integer.parseInt(dataLocal[0]));
				
				localObject.setIndPrincipal(dataLocal[1]);//1:principal, en otros
				
				//1:cuando la fila grilla esta en modo editable, true cuando esta en modo no editable
				if("1".equals(localObject.getIndPrincipal()) || "true".equals(localObject.getIndPrincipal()))localObject.setIndPrincipal("1");
				else localObject.setIndPrincipal("0");
				
				localObject.setCodEstado(dataLocal[2]);
				localObject.setCodDependencia(codDependencia);
				localesArray.add(localObject);
			}
			
			AuditoriaUtil.set(usuarioBean);//Seteamos el usuario que va a servir como el registrador.
			localService.registrarActualizarLocales(localesArray);//Servicio de registro
			resultado.put("actualizado","1");
		}
		catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}
		
		return new ModelAndView(getJsonView(), resultado);
	}*/
	
	
	/**
	 * @author ccaciquey	
	 * @return Devuelve la lista completa de departamentos
	 * @throws Exception
	 */					
	public ModelAndView getLocal(HttpServletRequest request,HttpServletResponse response) {
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		try {
			Integer numLocal = new Integer(request.getParameter("numLocal"));
			Inmueble local = localService.getLocal(numLocal);
			if (local != null) {
				respuesta.put("numLocal", numLocal);
				respuesta.put("local", local);
				respuesta.put("error", "0");
			}
			else {
				respuesta.put("error", "1");
				respuesta.put("mensajeError", "local buscado no existe.");
			}
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * @author ccaciquey	
	 * @return Devuelve la lista completa de departamentos
	 * @throws Exception
	 */					
	public ModelAndView getDepartamentos(HttpServletRequest request,HttpServletResponse response) {
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		try {
			respuesta.put("listDepartamentos", localService.getDepartamentos());
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * @author ccaciquey	
	 * @return Devuelve la lista completa de provincias dado el departamento
	 * @throws Exception
	 */					
	public ModelAndView getProvincias(HttpServletRequest request,HttpServletResponse response) {
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		try {    
			String codDepartamento = request.getParameter("codDepartamento");
			if(!"".equals(codDepartamento)){
				respuesta.put("listProvincias", localService.getProvincias(codDepartamento));	
			}
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	/**
	 * @author ccaciquey	
	 * @return Devuelve la lista completa de distritos dado el código de departamento y de provincias
	 * @throws Exception
	 */					
	public ModelAndView getDistritos(HttpServletRequest request,HttpServletResponse response) {
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		try {
			String codDepartamento = request.getParameter("codDepartamento");
			String codProvincia = request.getParameter("codProvincia");
			if(!"".equals(codProvincia)){
				respuesta.put("listDistritos", localService.getDistritos(codDepartamento,codProvincia));
			}
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	
	public ModelAndView descargarArchivoFirmado(HttpServletRequest request, HttpServletResponse response) throws ServiceException {

		ModelAndView modelAndView = null;
		
		if (log.isDebugEnabled()) {log.debug("debug Inicio - ConsultaSolicitudController.descargarArchivo");}
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		try {
			String numSolicitudString = StringUtils.trim(request.getParameter("numSolicitud"));
			BigDecimal numSolicitud = new BigDecimal(numSolicitudString);
			
			ActSolTra param = new ActSolTra();
			param.setNumSolicitud(numSolicitud);
			
			List<ActSolTra> listaSolicitudes = gestionVigilanciaService.recuperarListaSolicitudes(param);
			ActSolTra solicitud = listaSolicitudes.get(0);

			boolean existeArchivo = false;
			
			BigDecimal codDocautNumber =  solicitud.getCodDocaut();
			if (codDocautNumber == null) {
				codDocautNumber = BigDecimal.valueOf(-1.0);
			}
			
			log.debug("numArchivo " + codDocautNumber);
			
			byte[] bytes = new byte[1024];
			String nombre = "";
			
			T5282Archbin archivo = consultaFirmaService.recuperarDocumentoPdfFirmado(codDocautNumber);
			bytes = archivo.getArcDatos();
			nombre = archivo.getDesNombreAlternativo();
			existeArchivo = true;
				
			log.debug("nombre del archivo: " + nombre);
			
			if (existeArchivo) {
				if (!(nombre.contains(".pdf") || nombre.contains(".PDF"))) {
					nombre = nombre + ".pdf";
				}
				
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment;filename="+nombre);
	
				OutputStream os = response.getOutputStream();
	
				os.write(bytes);
	
				os.flush();
				os.close();
			}
			
			return modelAndView;
		}
		catch(Exception ex){
			log.error("Error en ConsultaSolicitudController.descargarArchivo: " + ex.getMessage(), ex);

			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + ex.getMessage());
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
		finally{
			if (log.isDebugEnabled()){ log.debug("Fin - ConsultaSolicitudController.descargarArchivo");}
		}

	}

	public String getJsonView() {
		return jsonView;
	}

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public JsonSerializer getJsonSerializer() {
		return jsonSerializer;
	}

	public void setJsonSerializer(JsonSerializer jsonSerializer) {
		this.jsonSerializer = jsonSerializer;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(
			RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public ConsultaFirmaService getConsultaFirmaService() {
		return consultaFirmaService;
	}

	public void setConsultaFirmaService(ConsultaFirmaService consultaFirmaService) {
		this.consultaFirmaService = consultaFirmaService;
	}

	public GestionVigilanciaService getGestionVigilanciaService() {
		return gestionVigilanciaService;
	}

	public void setGestionVigilanciaService(GestionVigilanciaService gestionVigilanciaService) {
		this.gestionVigilanciaService = gestionVigilanciaService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(
			RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroDependenciasService getRegistroDependenciasService() {
		return registroDependenciasService;
	}

	public void setRegistroDependenciasService(
			RegistroDependenciasService registroDependenciasService) {
		this.registroDependenciasService = registroDependenciasService;
	}
	
	public LocalService getLocalService() {
		return localService;
	}
	
	public void setLocalService(LocalService localService) {
		this.localService = localService;
	}
}