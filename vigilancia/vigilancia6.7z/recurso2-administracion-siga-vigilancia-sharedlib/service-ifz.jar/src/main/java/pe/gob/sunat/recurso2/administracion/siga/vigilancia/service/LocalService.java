package pe.gob.sunat.recurso2.administracion.siga.vigilancia.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Departamento;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Tdependencias;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Distrito;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.InmLocalTdepe;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Provincia;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Inmueble;

public interface LocalService {

	List<Tdependencias> listarUnidadesOrganizacionalesPorUUOOdeJefe(String codUnidadOrganizacionalJefe);
	List<Inmueble> listarLocalesPorUnidadOrganizacional(String codUnidadOrganizacional);
	//void registrarActualizarLocales(List<InmLocalTdepe> localesDependencia);
	List<Tdependencias> listarUnidadesOrganizacionalesPorCodigoJefe(String codJefe);
	Tdependencias getDependencia(String codDependencia);
	
	List<Departamento> getDepartamentos();
	List<Provincia> getProvincias(String codDepartamento);
	List<Distrito> getDistritos(String codDepartamento, String codProvincia);
	
	Inmueble getLocal(Integer numLocal);
	
	List<Inmueble> listarLocalesAll(Map<String,Object> parametros);
	
	String listarCodigosDeLocalPorUsuarioYUnidad(Map<String,Object> parametros);
	String listarCodigosDeLocalPorUsuarioYDeposito(Map<String,Object> parametros);

	String listarCodigosDeLocalPorUsuarioYDepositoTraslado(Map<String,Object> parametros);
	String listarCodigosDeLocalPorColaboradorDestinatario(Map<String,Object> parametros);
	String listarCodigosDeLocalPorColaboradorDestinatarioFiltro(Map<String,Object> parametros);
	
	/**
	 * Listar Locales para Cierre de Inventario Local en base al Codigo de Inventario
	 * y el Codigo de Ambito
	 * 
	 * @author framirez
	 * @since 11/09/2015
	 * @version 1.0
	 * @param Map parametro
	 * @return Lista Inmueble - Locales
	 */
	List<Inmueble> listLocalByInventarioAmbito(Map<String, Object> parametro);

	/**
	 * Cerrar Local
	 * 
	 * @author framirez
	 * @since 14/09/2015
	 * @version 1.0
	 * @param Map parametro
	 */
	void cerrarLocal(Map<String, Object> parametro);

	/**
	 * Reiniciar Local
	 * 
	 * @author framirez
	 * @since 14/09/2015
	 * @version 1.0
	 * @param Map parametro
	 */
	void reiniciarLocal(Map<String, Object> parametro);

	String listarCodigosDeLocalPorInventariador(Map<String,Object> parametros);
	
	String validarInventarioLocal(String codInventario, Integer numLocal, String codPersInv);
	public List<String> localesPorAmbito(Map<String, Object> parametro);
	
}
