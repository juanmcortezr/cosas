package pe.gob.sunat.recurso2.administracion.siga.vigilancia.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.AmbitoConfiguradoBean;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Departamento;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Distrito;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.InmLocalTdepe;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Provincia;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Inmueble;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Tdependencias;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.AmbitoDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.InmLocalTdepeDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.InmuebleDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.TDepartamentoDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.TdependenciasDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.TDistritoDAO;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.TProvinciaDAO;

public class LocalServiceImpl implements LocalService{


	protected final Log log = LogFactory.getLog(getClass());

	private InmuebleDAO inmuebleDAO;
	private InmLocalTdepeDAO inmLocalTdepeDAO;
	private TdependenciasDAO tdependenciasDAO;
	
	private TDepartamentoDAO departamentoDAO;
	private TProvinciaDAO provinciaDAO;
	private TDistritoDAO distritoDAO;
	private AmbitoDAO ambitoDAO; //FRAMIREZ 14/09/2015 
	

	public List<Tdependencias> listarUnidadesOrganizacionalesPorUUOOdeJefe(
			String codUnidadOrganizacionalJefe) {
		log.debug("Obteniendo listado de unidades organizacionales para la unidad organizacional:"+codUnidadOrganizacionalJefe);
		// TODO Auto-generated method stub
		Map<String,Object> parametros = new HashMap<String,Object>();

		String ultimo = String.valueOf(codUnidadOrganizacionalJefe.charAt(5));
		log.debug("ultimo digito de la unidad organizacional:"+ultimo);
		if(!"0".equals(ultimo)){
			parametros.put("codUnidadOrganizacional",codUnidadOrganizacionalJefe);
		}else{
			//Si el codigo de la uuoo termina en cero buscamos
			int indice = -1;
			char[] arreglo = codUnidadOrganizacionalJefe.toCharArray();
			for(int i=arreglo.length-1;i>=0;i--){
				if(arreglo[i]!='0'){
					indice = i+1;
					break;
				}
			}
			
			if(indice>=0)codUnidadOrganizacionalJefe = codUnidadOrganizacionalJefe.substring(0,indice);
			parametros.put("codUnidadOrganizacional",codUnidadOrganizacionalJefe);
		}
		
		
		log.debug("Parametros de busqueda de local:"+parametros);
		return tdependenciasDAO.listarDependencias(parametros);
	}

	public List<Inmueble> listarLocalesPorUnidadOrganizacional(
			String codUnidadOrganizacional) {
		List<Inmueble> locales = inmuebleDAO.listarLocalesPorDependencia(codUnidadOrganizacional);
	for(Inmueble local:locales){
		//formateamos para la grilla el indicador de local
		if("1".equals(local.getIndPrincipal()))local.setIndPrincipal("true");
		else local.setIndPrincipal("false");
	}

		return locales;
	}

	/*public void registrarActualizarLocales(List<InmLocalTdepe> localesDependencia){
		//1. Verificar si ya existe el par dependencia,local
		//2 si existe actualizar, sino insertar.
		for(InmLocalTdepe ld:localesDependencia){
			ld.setCodLocalDependencia(new Integer(0));//max + 1 en bd
			int cantidad = localDependenciaDAO.countLocalDependencia(ld.getCodDependencia(), ld.getNumLocal().intValue());
			if(cantidad>0){
				//Update
				localDependenciaDAO.updateLocalDependencia(ld);//ya tiene la clave de update.
			}else{
				//Insert
				//falta insertar
				localDependenciaDAO.insertSelective(ld);//ya tiene la clave de update.
			}
		}

	}*/

	public InmuebleDAO getLocalDAO() {
		return inmuebleDAO;
	}

	public void setLocalDAO(InmuebleDAO localDAO) {
		this.inmuebleDAO = localDAO;
	}

	public InmLocalTdepeDAO getLocalDependenciaDAO() {
		return inmLocalTdepeDAO;
	}

	public void setLocalDependenciaDAO(InmLocalTdepeDAO localDependenciaDAO) {
		this.inmLocalTdepeDAO = localDependenciaDAO;
	}

	public TdependenciasDAO getDependenciaDAO() {
		return tdependenciasDAO;
	}

	public void setDependenciaDAO(TdependenciasDAO dependenciaDAO) {
		this.tdependenciasDAO = dependenciaDAO;
	}

	public List<Tdependencias> listarUnidadesOrganizacionalesPorCodigoJefe(
			String codJefe) {
		log.debug("Obteniendo listado de unidades organizacionales por codigo de jefe:"+codJefe);
		Map<String,Object> parametros = new HashMap<String,Object>();
		parametros.put("codJefe",codJefe);
		log.debug("Parametros de busqueda:"+parametros);
		return tdependenciasDAO.listarDependenciasJefe(parametros);
	}

	@Override
	public Tdependencias getDependencia(String codDependencia) {
		// TODO Auto-generated method stub
		Tdependencias d = new Tdependencias();
		d.setCodidepetde(codDependencia);
		return tdependenciasDAO.selectByPrimaryKey(d);
	}

	@Override
	public List<Departamento> getDepartamentos() {
		return departamentoDAO.getDepartamentos();
	}

	@Override
	public List<Provincia> getProvincias(String codDepartamento) {
		return provinciaDAO.getProvincias(codDepartamento);
	}

	@Override
	public List<Distrito> getDistritos(String codDepartamento,
			String codProvincia) {
		Distrito distritoSearch = new Distrito();
		distritoSearch.setCodiDepaDpt(codDepartamento);
		distritoSearch.setCodiProvTpr(codProvincia);
		return distritoDAO.getDistritos(distritoSearch);
	}
	

	public TDepartamentoDAO getDepartamentoDAO() {
		return departamentoDAO;
	}

	public void setDepartamentoDAO(TDepartamentoDAO departamentoDAO) {
		this.departamentoDAO = departamentoDAO;
	}

	public TProvinciaDAO getProvinciaDAO() {
		return provinciaDAO;
	}

	public void setProvinciaDAO(TProvinciaDAO provinciaDAO) {
		this.provinciaDAO = provinciaDAO;
	}

	public TDistritoDAO getDistritoDAO() {
		return distritoDAO;
	}

	public void setDistritoDAO(TDistritoDAO distritoDAO) {
		this.distritoDAO = distritoDAO;
	}

	@Override
	public Inmueble getLocal(Integer numLocal) {
		
		return inmuebleDAO.selectByPrimaryKey(new BigDecimal(numLocal.intValue()));
	}

	
	@Override
	public List<Inmueble> listarLocalesAll(Map<String,Object> parametros) {
		// TODO Auto-generated method stub
		return inmuebleDAO.listarLocalesAll(parametros);
	}

	@Override
	public String listarCodigosDeLocalPorUsuarioYUnidad(
			Map<String, Object> parametros) {
		List<Integer> codigosList = inmuebleDAO.listarCodigosDeLocalPorUsuarioYUnidad(parametros);
		String listaRetorno = StringUtils.join(codigosList.toArray(),',');
		return listaRetorno;
	}

	@Override
	public String listarCodigosDeLocalPorUsuarioYDeposito(
			Map<String, Object> parametros) {
		List<Integer> codigosList = inmuebleDAO.listarCodigosDeLocalPorUsuarioYDeposito(parametros);
		String listaRetorno = StringUtils.join(codigosList.toArray(),',');
		return listaRetorno;
	}


	
	@Override
	public String listarCodigosDeLocalPorColaboradorDestinatario(
			Map<String, Object> parametros) {
		log.debug("listarCodigosDeLocalPorColaboradorDestinatario");
		List<Integer> codigosList = inmuebleDAO.listarCodigosDeLocalPorColaboradorDestinatario(parametros);
		String listaRetorno = StringUtils.join(codigosList.toArray(),',');
		return listaRetorno;
	}

	@Override
	public String listarCodigosDeLocalPorColaboradorDestinatarioFiltro(
			Map<String, Object> parametros) {
		log.debug("listarCodigosDeLocalPorColaboradorDestinatarioFiltro-emarchena");
		List<Integer> codigosList = inmuebleDAO.listarCodigosDeLocalPorColaboradorDestinatarioFiltro(parametros);
		String listaRetorno = StringUtils.join(codigosList.toArray(),',');
		return listaRetorno;
	}
	
	@Override
	public String listarCodigosDeLocalPorUsuarioYDepositoTraslado(
			Map<String, Object> parametros) {
		List<Integer> codigosList = inmuebleDAO.listarCodigosDeLocalPorUsuarioYDepositoTraslado(parametros);
		String listaRetorno = StringUtils.join(codigosList.toArray(),',');
		return listaRetorno;
	}

	@Override
	public String listarCodigosDeLocalPorInventariador(
			Map<String, Object> parametros) {
		List<Integer> codigosList = inmuebleDAO.listarCodigosDeLocalPorInventariador(parametros);
		String listaRetorno = StringUtils.join(codigosList.toArray(),',');
		return listaRetorno;
	}

	@Override
	public List<Inmueble> listLocalByInventarioAmbito(Map<String, Object> parametro) {
		log.debug("Obteniendo listado de Locales para Cierre de Inventario por Local");
		return inmuebleDAO.listLocalByInventarioAmbito(parametro);
	}
	
	
	public List<String> localesPorAmbito(Map<String, Object> parametro) {
		return inmuebleDAO.localesPorAmbito(parametro);
	}

	@Override
	public void cerrarLocal(Map<String, Object> parametro) {
		log.debug("Cerrando Locales");
		List<Inmueble> listaLocales = inmuebleDAO.listLocalByInventarioAmbitoNumLocal(parametro);
		String codigoInventario = (String) parametro.get("codigoInventario");
		String codigoAmbito = (String) parametro.get("codigoAmbito");

		log.debug("ListaLocales OBTENIDA");
		for(Inmueble lista : listaLocales){
			// PREPARAR BEAN
			AmbitoConfiguradoBean bean = new AmbitoConfiguradoBean();
			bean.setCodigoAmbito(codigoAmbito);
			bean.setNumLocal(lista.getNumLocal().intValue());
			bean.setIndEstado("C"); //AGREGAR A CONSTANTES
			bean.setFecCierre(new Date());

			if(lista.getCodigoInventario()== null || "".equals(lista.getCodigoInventario())){
				//INSERTAR
				bean.setCodigoInventario(codigoInventario);
				ambitoDAO.insertAmbitosConfigurado(bean);
			}else{
				//ACTUALIZAR
				bean.setCodigoInventario(codigoInventario);
				ambitoDAO.updateAmbitosConfigurado(bean);
			}
			log.debug("TERMINA CON " + lista.getNumLocal());
		}
	}

	@Override
	public void reiniciarLocal(Map<String, Object> parametro) {
		log.debug("Reiniciando Locales");
		List<Inmueble> listaLocales = inmuebleDAO.listLocalByInventarioAmbitoNumLocal(parametro);
		String codigoInventario = (String) parametro.get("codigoInventario");
		String codigoAmbito = (String) parametro.get("codigoAmbito");

		log.debug("ListaLocales OBTENIDA");
		for(Inmueble lista : listaLocales){
			// PREPARAR BEAN
			AmbitoConfiguradoBean bean = new AmbitoConfiguradoBean();
			bean.setCodigoAmbito(codigoAmbito);
			bean.setNumLocal(lista.getNumLocal().intValue());
			bean.setCodigoInventario(codigoInventario);
			bean.setIndEstado("A"); //AGREGAR A CONSTANTES
			bean.setFecCierre(null);

			//ACTUALIZAR
			ambitoDAO.updateAmbitosConfigurado(bean);
		}
	}

	public AmbitoDAO getAmbitoDAO() {
		return ambitoDAO;
	}

	public void setAmbitoDAO(AmbitoDAO ambitoDAO) {
		this.ambitoDAO = ambitoDAO;
	}

	@Override
	public String validarInventarioLocal(String codInventario, Integer numLocal, String codPersInv) {
		// TODO Auto-generated method stub
		Map<String,Object> parametros = new HashMap<String,Object>();
		parametros.put("codInventario", codInventario);
		parametros.put("numLocal", numLocal);
		parametros.put("codPersInv", codPersInv);
		log.info("Parametros de la validacion de inventario - local:"+parametros);
		inmuebleDAO.validarMensajeError(parametros);
		log.info("Retorno de la validacion de inventario - local:"+parametros);
		Integer codError = (Integer) parametros.get("codError");
		String mensajeError = (String) parametros.get("mensajeError");
		if(codError.intValue()==0)return null;
		else return mensajeError;
	}

	public InmuebleDAO getInmuebleDAO() {
		return inmuebleDAO;
	}

	public void setInmuebleDAO(InmuebleDAO inmuebleDAO) {
		this.inmuebleDAO = inmuebleDAO;
	}

	public InmLocalTdepeDAO getInmLocalTdepeDAO() {
		return inmLocalTdepeDAO;
	}

	public void setInmLocalTdepeDAO(InmLocalTdepeDAO inmLocalTdepeDAO) {
		this.inmLocalTdepeDAO = inmLocalTdepeDAO;
	}

	public TdependenciasDAO getTdependenciasDAO() {
		return tdependenciasDAO;
	}

	public void setTdependenciasDAO(TdependenciasDAO tdependenciasDAO) {
		this.tdependenciasDAO = tdependenciasDAO;
	}

}
