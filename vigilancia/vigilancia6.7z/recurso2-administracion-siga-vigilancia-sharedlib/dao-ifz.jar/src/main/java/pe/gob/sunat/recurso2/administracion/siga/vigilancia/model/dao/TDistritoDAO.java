package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Distrito;



/**
 * DAO para acceder a los locales
 * 
 * @author
 * @version 1.0
 */
public interface TDistritoDAO {


	// parametros);//wrodriguez
	List<Distrito> getDistritos(Distrito provincia);
	// boolean updateByVistaPreliminar(T5730Bean paramUpdate);//wrodriguez

}
