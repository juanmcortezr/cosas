package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Departamento;


/**
 * DAO para acceder a los departamentos
 * 
 * @author
 * @version 1.0
 */
public interface TDepartamentoDAO {

	// parametros);//wrodriguez
	List<Departamento> getDepartamentos(String departamento);
	
	List<Departamento> getDepartamentos();
	// boolean updateByVistaPreliminar(T5730Bean paramUpdate);//wrodriguez

}
