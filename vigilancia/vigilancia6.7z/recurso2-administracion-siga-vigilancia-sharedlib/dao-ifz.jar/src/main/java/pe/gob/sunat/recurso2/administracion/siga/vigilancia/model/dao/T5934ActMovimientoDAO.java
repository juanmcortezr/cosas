package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao;

import java.util.HashMap;
import java.util.List;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.T5934ActMovimiento;


public interface T5934ActMovimientoDAO {
	
	int confirmarBienes(T5934ActMovimiento t5934ActMovimiento);
	
	/**
	 * @author arosalesa
	 * @param num_movimiento
	 * @return obtiene la sede y el responsable para la ejecucion del procedimiento almacenado
	 */
	HashMap<String,String> getParamsUsuario(String codEmpleado);
	
	List<T5934ActMovimiento> getParamsSolicitudes(T5934ActMovimiento params);
	
	List<T5934ActMovimiento> getParamsConformidad(T5934ActMovimiento params);
	
	/**
	 * @author arosalesa
	 * @param num_movimiento
	 * @return parametros para la ejecucion del procedimiento almacenado, solo devolvera resultado si se trata de una solicitud
	 */
	HashMap<String,String> getParamsSegSolicitud(Integer num_movimiento);
	
	/**
	 * Invoca un procedimiento almacenado 
	 * @author arosalesa
	 * @param num_movimiento
	 * 
	 */
	void saveSegSolicitud(HashMap<String,String> params);
	
	void firmarDocumentosConfirmados(Integer codFirma, String codEmpleado);
	

}
