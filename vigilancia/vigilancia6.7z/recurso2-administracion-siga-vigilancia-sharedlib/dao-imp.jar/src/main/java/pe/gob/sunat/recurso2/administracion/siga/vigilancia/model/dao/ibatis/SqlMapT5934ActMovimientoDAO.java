package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.T5934ActMovimiento;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.T5934ActMovimientoDAO;



public class SqlMapT5934ActMovimientoDAO extends SqlMapClientDaoSupport implements T5934ActMovimientoDAO {

	@SuppressWarnings("unchecked")
	public HashMap<String,String> getParamsUsuario(String codEmpleado){
		
		Object respuesta =this.getSqlMapClientTemplate().queryForObject("T5934actmov.getParamsUsuario",codEmpleado);
		
		if (respuesta==null) return null;
		else return (HashMap<String,String>)respuesta;
		
	}
	
	

	public int confirmarBienes(T5934ActMovimiento t5934ActMovimiento) {		
						
		return getSqlMapClientTemplate().update("T5934actmov.actualizar",t5934ActMovimiento);
		
	}	
	
	@SuppressWarnings("unchecked")
	public List<T5934ActMovimiento> getParamsSolicitudes(T5934ActMovimiento params) {		
				
		Object respuesta =this.getSqlMapClientTemplate().queryForList("T5934actmov.getParamsSolicitudes",params);
		
		if (respuesta==null) return null;
		else return (List<T5934ActMovimiento>)respuesta;
		
	}	

	@SuppressWarnings("unchecked")
	public List<T5934ActMovimiento> getParamsConformidad(T5934ActMovimiento params) {		
				
		Object respuesta =this.getSqlMapClientTemplate().queryForList("T5934actmov.getParamsConformidad",params);
		
		if (respuesta==null) return null;
		else return (List<T5934ActMovimiento>)respuesta;
		
	}	
	
	@SuppressWarnings("unchecked")
	public HashMap<String,String> getParamsSegSolicitud(Integer num_movimiento) {		
				
		Object respuesta =this.getSqlMapClientTemplate().queryForObject("T5934actmov.getParamsSegSolicitud",num_movimiento);
		
		if (respuesta==null) return null;
		else return (HashMap<String,String>)respuesta;
		
	}	
	
	public void saveSegSolicitud(HashMap<String,String> params){		
		this.getSqlMapClientTemplate().insert("T5934actmov.sp_crear_acc", params);		
	}



	@Override
	public void firmarDocumentosConfirmados(Integer codFirma, String codEmpleado) {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("codFirma",codFirma);
		params.put("codEmpleado",codEmpleado);
		this.getSqlMapClientTemplate().update("T5934actmov.firmarDocumentosConfirmados", params);
	}
	
	
	
}
