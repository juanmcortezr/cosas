package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ibatis;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Departamento;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.TDepartamentoDAO;

/**
 * Implementación del DAO para acceder y modificar la información de la
 * entidad locales
 * 
 * @author walter rodriguez
 * @version 1.0
 */
public class SqlMapTDepartamentoDAO extends SqlMapClientDaoSupport implements
		TDepartamentoDAO {

	@SuppressWarnings("unchecked")
	public List<Departamento> getDepartamentos(String departamento) {
		return (List<Departamento>) getSqlMapClientTemplate().queryForList(
				"Departamento.selectByPrimaryKey", departamento);
	}

	@SuppressWarnings("unchecked")
	public List<Departamento> getDepartamentos() {
		return (List<Departamento>) getSqlMapClientTemplate().queryForList(
				"Departamento.selectBy");
	}

}