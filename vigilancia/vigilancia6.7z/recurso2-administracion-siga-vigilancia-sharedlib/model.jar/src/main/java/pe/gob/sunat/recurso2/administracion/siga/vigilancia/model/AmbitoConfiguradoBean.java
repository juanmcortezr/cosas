package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model;

import java.util.Date;

/**
 * AmbitoConfiguradoBean Bean para Representar los Ambitos Configurados del Bean
 * T6596InvAmbito ya haciendo uso de Las Cantidades
 * 
 * @author framirez
 * @since 11/09/2015
 * @version 1.0
 */
public class AmbitoConfiguradoBean {

	private String codigoInventario;
	private String codigoAmbito;
	private String descripcionAmbito;
	private String descripcionAdministrador;
	private Integer cantLocales;
	private Integer cantCerrados;
	private Integer cantAbiertos;

	//Agregado Para Insert y Update Dinamico - FRAMIREZ 14/09/2015
	private Integer numLocal;
	private String indEstado;
	private Date fecCierre;
	
	public String getCodigoInventario() {
		return codigoInventario;
	}

	public void setCodigoInventario(String codigoInventario) {
		this.codigoInventario = codigoInventario;
	}

	public String getCodigoAmbito() {
		return codigoAmbito;
	}

	public void setCodigoAmbito(String codigoAmbito) {
		this.codigoAmbito = codigoAmbito;
	}

	public String getDescripcionAmbito() {
		return descripcionAmbito;
	}

	public void setDescripcionAmbito(String descripcionAmbito) {
		this.descripcionAmbito = descripcionAmbito;
	}

	public String getDescripcionAdministrador() {
		return descripcionAdministrador;
	}

	public void setDescripcionAdministrador(String descripcionAdministrador) {
		this.descripcionAdministrador = descripcionAdministrador;
	}

	public Integer getCantLocales() {
		return cantLocales;
	}

	public void setCantLocales(Integer cantLocales) {
		this.cantLocales = cantLocales;
	}

	public Integer getCantCerrados() {
		return cantCerrados;
	}

	public void setCantCerrados(Integer cantCerrados) {
		this.cantCerrados = cantCerrados;
	}

	public Integer getCantAbiertos() {
		return cantAbiertos;
	}

	public void setCantAbiertos(Integer cantAbiertos) {
		this.cantAbiertos = cantAbiertos;
	}

	//Agregado Para Insert y Update Dinamico - FRAMIREZ 14/09/2015
	public Integer getNumLocal() {
		return numLocal;
	}

	public void setNumLocal(Integer numLocal) {
		this.numLocal = numLocal;
	}

	public String getIndEstado() {
		return indEstado;
	}

	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}

	public Date getFecCierre() {
		return fecCierre;
	}

	public void setFecCierre(Date fecCierre) {
		this.fecCierre = fecCierre;
	}
	
}
