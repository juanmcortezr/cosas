package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model;
 
public class MaestroPersona  {
	private String nivel; 					// identificador de rol en el maestro
	private String codiEmplPer;
	private String nomEmpPer;
	private String codUnidadOrganizacional;	//parametro de busqueda
	private String unidadOrganizacional;	//parametro de busqueda
	private String nombCortPer;
	private String numeroRegistroAlterno;
	private String codiDepeTde;
	private String codiSedeSed;
	private String codiUnidadOrganizacional;
	private String codiUsuaUsu;				//login de usuario
	private String anioExpediente;			//anio del expediente
	private String expediente;				//expediente
	
	private String apePatPer;
	private String apeMatPer;
	private String regLabPer;
	private String descripcionRegimen;
	private String descripcionCortaRegimen;
	private String uuoo;
	private String descripcionUuoo;
	private String descripcionCortaUuoo;
	private String estadoTrabajador;  // 1 activo, 0 inactivo
	
	private String estaTrabPer;
	
	public MaestroPersona() 												{
		super();
	}

	public String getUnidadOrganizacional() 								{
		return unidadOrganizacional;
	}

	public void setUnidadOrganizacional(String unidadOrganizacional) {
		this.unidadOrganizacional = unidadOrganizacional;
	}

	public String getNivel(){
		return nivel;
	}

	public void setNivel(String nivel){
		this.nivel = nivel;
	}
	
	public String getCodiEmplPer(){
		return codiEmplPer;
	}

	public void setCodiEmplPer(String codiEmplPer){
		this.codiEmplPer = codiEmplPer;
	}

	public String getNomEmpPer(){
		return nomEmpPer;
	}

	public void setNomEmpPer(String nomEmpPer){
		this.nomEmpPer = nomEmpPer;
	}

	public String getNombCortPer(){
		return nombCortPer;
	}

	public void setNombCortPer(String nombCortPer){
		this.nombCortPer = nombCortPer;
	}

	public String getNumeroRegistroAlterno(){
		return numeroRegistroAlterno;
	}

	public void setNumeroRegistroAlterno(String numeroRegistroAlterno){
		this.numeroRegistroAlterno = numeroRegistroAlterno;
	}

	public String getCodiDepeTde(){
		return codiDepeTde;
	}

	public void setCodiDepeTde(String codiDepeTde){
		this.codiDepeTde = codiDepeTde;
	}

	public String getCodiSedeSed() {
		return codiSedeSed;
	}

	public void setCodiSedeSed(String codiSedeSed) {
		this.codiSedeSed = codiSedeSed;
	}

	public String getCodiUsuaUsu() {
		return codiUsuaUsu;
	}

	public void setCodiUsuaUsu(String codiUsuaUsu) {
		this.codiUsuaUsu = codiUsuaUsu;
	}

	public String getAnioExpediente() {
		return anioExpediente;
	}

	public void setAnioExpediente(String anioExpediente) {
		this.anioExpediente = anioExpediente;
	}

	public String getExpediente() {
		return expediente;
	}

	public void setExpediente(String expediente) {
		this.expediente = expediente;
	}

	public String getCodUnidadOrganizacional() {
		return codUnidadOrganizacional;
	}

	public void setCodUnidadOrganizacional(String codUnidadOrganizacional) {
		this.codUnidadOrganizacional = codUnidadOrganizacional;
	}

	public String getApePatPer() {
		return apePatPer;
	}

	public void setApePatPer(String apePatPer) {
		this.apePatPer = apePatPer;
	}

	public String getApeMatPer() {
		return apeMatPer;
	}

	public void setApeMatPer(String apeMatPer) {
		this.apeMatPer = apeMatPer;
	}

	public String getRegLabPer() {
		return regLabPer;
	}

	public void setRegLabPer(String regLabPer) {
		this.regLabPer = regLabPer;
	}

	public String getDescripcionRegimen() {
		return descripcionRegimen;
	}

	public void setDescripcionRegimen(String descripcionRegimen) {
		this.descripcionRegimen = descripcionRegimen;
	}

	public String getDescripcionCortaRegimen() {
		return descripcionCortaRegimen;
	}

	public void setDescripcionCortaRegimen(String descripcionCortaRegimen) {
		this.descripcionCortaRegimen = descripcionCortaRegimen;
	}

	public String getUuoo() {
		return uuoo;
	}

	public void setUuoo(String uuoo) {
		this.uuoo = uuoo;
	}

	public String getDescripcionUuoo() {
		return descripcionUuoo;
	}

	public void setDescripcionUuoo(String descripcionUuoo) {
		this.descripcionUuoo = descripcionUuoo;
	}

	public String getDescripcionCortaUuoo() {
		return descripcionCortaUuoo;
	}

	public void setDescripcionCortaUuoo(String descripcionCortaUuoo) {
		this.descripcionCortaUuoo = descripcionCortaUuoo;
	}

	public String getEstadoTrabajador() {
		return estadoTrabajador;
	}

	public void setEstadoTrabajador(String estadoTrabajador) {
		this.estadoTrabajador = estadoTrabajador;
	}

	public void setCodiUnidadOrganizacional(String codiUnidadOrganizacional) {
		this.codiUnidadOrganizacional = codiUnidadOrganizacional;
	}

	public String getCodiUnidadOrganizacional() {
		return codiUnidadOrganizacional;
	}

	public String getEstaTrabPer() {
		return estaTrabPer;
	}

	public void setEstaTrabPer(String estaTrabPer) {
		this.estaTrabPer = estaTrabPer;
	}


	
	private String codigoEmpleado;
	private String nombreCompleto;
	private String codigoDependencia;
	private String numeroRegistro;
	private String dependencia;
	private String sede;
	private String codigoEstado;
	private String estado;
	
	private String descNivel;

	public String getCodigoEmpleado() {
		return codigoEmpleado;
	}

	public void setCodigoEmpleado(String codigoEmpleado) {
		this.codigoEmpleado = codigoEmpleado;
	}

	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getCodigoDependencia() {
		return codigoDependencia;
	}

	public void setCodigoDependencia(String codigoDependencia) {
		this.codigoDependencia = codigoDependencia;
	}

	public String getNumeroRegistro() {
		return numeroRegistro;
	}

	public void setNumeroRegistro(String numeroRegistro) {
		this.numeroRegistro = numeroRegistro;
	}

	public String getDependencia() {
		return dependencia;
	}

	public void setDependencia(String dependencia) {
		this.dependencia = dependencia;
	}

	public String getSede() {
		return sede;
	}

	public void setSede(String sede) {
		this.sede = sede;
	}

	public String getCodigoEstado() {
		return codigoEstado;
	}

	public void setCodigoEstado(String codigoEstado) {
		this.codigoEstado = codigoEstado;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getDescNivel() {
		return descNivel;
	}

	public void setDescNivel(String descNivel) {
		this.descNivel = descNivel;
	}
	
}
