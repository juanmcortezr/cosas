package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model;

public class Provincia {
	private String codiProvTpr;
	private String nombProvTpr;
	private String codiDepaDpt;
	
	
	public Provincia() 											{		super();}
	
	public String getCodiProvTpr() 								{		return codiProvTpr;}
	public void setCodiProvTpr(String codiProvTpr) 				{		this.codiProvTpr = codiProvTpr;}
	public String getNombProvTpr() 								{		return nombProvTpr;}
	public void setNombProvTpr(String nombProvTpr) 				{		this.nombProvTpr = nombProvTpr;}
	public String getCodiDepaDpt() 								{		return codiDepaDpt;}
	public void setCodiDepaDpt(String codiDepaDpt) 				{		this.codiDepaDpt = codiDepaDpt;}

}
