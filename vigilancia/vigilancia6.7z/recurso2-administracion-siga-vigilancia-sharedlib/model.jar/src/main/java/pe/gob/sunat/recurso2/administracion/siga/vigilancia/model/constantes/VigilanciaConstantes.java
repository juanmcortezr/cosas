package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.constantes;

public class VigilanciaConstantes {

	public static final String CODIGO_NOTIFICACION_CAJACHICA = "RETW00001";

	public final static String ESTADO_CONSERVACION_BUENO="B";
	public final static String ESTADO_CONSERVACION_MALO="M";
	public final static String ESTADO_CONSERVACION_PARA_BAJA="N";
	public final static String ESTADO_CONSERVACION_REGULAR="R";
	public final static String CODIGO_PARAMETRO_INDICADORES_CONFORMIDAD_BIEN_FALTANTE="3192";
	
	public static final String USUARIO_BEAN_NAME = "usuarioBean";
	public final static String ESTADO_EMPLEADO_ACTIVO = "1";
	public final static String ESTADO_EMPLEADO_INACTIVO = "0";
	
	public final static String SOLICITUD_ANULADA = "0";
	public final static String SOLICITUD_REGISTRADA = "1";
	public final static String SOLICITUD_FIRMADA = "2";
	public final static String SOLICITUD_RECHAZADA = "3";
	public final static String SOLICITUD_AUTORIZADA = "4";
	public final static String SOLICITUD_CERRADA = "5";

	public static final String RUTA_PLANTILLAS_JASPER = "/data0/generador/jasper/plantillas/siga/";
	
	public static final String CODIGO_NOTIFICACION_VIGILANCIA_SOLICITUD = "VIGI00001";
	public static final String CODIGO_NOTIFICACION_VIGILANCIA_AUTORIZAR = "VIGI00002";
	public static final String CODIGO_NOTIFICACION_VIGILANCIA_ANULAR = "VIGI00003";
	
	public static final String TIPO_DOCUMENTO_FIRMA = "XXX";//CONFIRMAR VALIDEZ
	public static final String TIPO_PROCESO = "VIGILANCIA WEB";
	public static final String NOMBRE_PROCESO_SOLICITUD = "SOLICITUD DE VIGILANCIA";
	
	public static final String CODIGO_DEPENDENCIA_NORMATIVA = "7447";
	public static final int ID_PLANTILLA_SOLICITUD_VIGILANCIA = 200027;
	public static final String CODIGO_PROCESO_SOLICITUD_VIGILANCIA = "424";

}
