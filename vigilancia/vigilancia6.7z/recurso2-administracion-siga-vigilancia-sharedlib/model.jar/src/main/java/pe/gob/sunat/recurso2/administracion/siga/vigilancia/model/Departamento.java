package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model;

public class Departamento {
	private String codiDepaDpt; 
	private String nombDptoDpt;
	
	public Departamento() 								{		super();}
	
	public String getCodiDepaDpt() 						{		return codiDepaDpt;}
	public void setCodiDepaDpt(String codiDepaDpt) 		{		this.codiDepaDpt = codiDepaDpt;}
	public String getNombDptoDpt() 						{		return nombDptoDpt;}
	public void setNombDptoDpt(String nombDptoDpt) 		{		this.nombDptoDpt = nombDptoDpt;}	
	
}
