package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model;

import java.io.Serializable;

public class T01Parametro implements Serializable { 
	
	private String codParametro;  
	private String codModulo; //COD_MODULO
	private String codTipo; //COD_TIPO
	private String codArgumento; //COD_ARGUMENTO
	private String nomCorto; //DESC_CORTA
	private String nomLargo; //DESC_LARGA
	private String descAbrv; //DESC_ABREVIATURA
	private String codEstado; // COD_ESTADO
	
	public T01Parametro(){
		super();
	}

	public String getCodParametro() {
		return codParametro;
	}

	public void setCodParametro(String codParametro) {
		this.codParametro = codParametro;
	}

	public String getCodModulo() {
		return codModulo;
	}

	public void setCodModulo(String codModulo) {
		this.codModulo = codModulo;
	}

	public String getCodTipo() {
		return codTipo;
	}

	public void setCodTipo(String codTipo) {
		this.codTipo = codTipo;
	}

	public String getCodArgumento() {
		return codArgumento;
	}

	public void setCodArgumento(String codArgumento) {
		this.codArgumento = codArgumento;
	}

	public String getNomCorto() {
		return nomCorto;
	}

	public void setNomCorto(String nomCorto) {
		this.nomCorto = nomCorto;
	}

	public String getNomLargo() {
		return nomLargo;
	}

	public void setNomLargo(String nomLargo) {
		this.nomLargo = nomLargo;
	}

	public String getDescAbrv() {
		return descAbrv;
	}

	public void setDescAbrv(String descAbrv) {
		this.descAbrv = descAbrv;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	} 
	
	 
}
