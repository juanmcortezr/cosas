package pe.gob.sunat.recurso2.financiera.siga.tesoreria.consulta.web.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.ServiceException;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.Empleado;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.EncargosPersona;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.service.ConsultaExpedienteService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;


public class DelegacionConsultaExpedienteController extends MultiActionController {
		
	private String jsonView;
	private JsonSerializer jsonSerializer;
	
	private RegistroGeneralService registroGeneralService;
	private ConsultaExpedienteService consultaExpedienteService;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	public static final String PROCESO_DELEGACION = "10";
	public static final String DELEGACION_ACTIVA = "S";
	public static final String DELEGACION_DESHABILITADA = "N";
	
	/**
     * Carga la Pagina de la consulta
     * @param HttpServletRequest request
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */  
	public ModelAndView iniciarDelegacion(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		log.debug("debug Inicio - DelegacionConsultaExpedienteController.iniciarDelegacion");
		
		ModelAndView modelAndView;
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		String pagina = "";
		String errorMessage = "";
		
		try {
			
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			String numeroRegistro = usuarioBean.getNroRegistro().toUpperCase();
			Empleado empleado = consultaExpedienteService.getEmpleado(numeroRegistro);
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("codigoEmpleado", empleado.getCodigoEmpleado());
			String flagAutorizacion = consultaExpedienteService.validarAutorizacionConsultaExpediente(params);
			log.debug("Resultado de autorizacion: " + flagAutorizacion);
			//flagAutorizacion = "1";
			
			if (log.isDebugEnabled())log.debug("getApeMaterno:"		+usuarioBean.getApeMaterno());
			if (log.isDebugEnabled())log.debug("getApePaterno:"		+usuarioBean.getApePaterno());
			if (log.isDebugEnabled())log.debug("getCodDepend:"		+usuarioBean.getCodDepend());
			if (log.isDebugEnabled())log.debug("getCodUO:"			+usuarioBean.getCodUO());
			if (log.isDebugEnabled())log.debug("getCorreo:"			+usuarioBean.getCorreo());
			if (log.isDebugEnabled())log.debug("getLogin:"			+usuarioBean.getLogin());
			if (log.isDebugEnabled())log.debug("getNombreCompleto:"	+usuarioBean.getNombreCompleto());
			if (log.isDebugEnabled())log.debug("getNombres:"		+usuarioBean.getNombres());
			if (log.isDebugEnabled())log.debug("getNroRegistro:"	+usuarioBean.getNroRegistro());
			if (log.isDebugEnabled())log.debug("getTicket:"			+usuarioBean.getTicket());
			
			if ("1".equals(flagAutorizacion)) {
			
				respuesta.put("userRegistro", usuarioBean.getNroRegistro());
				respuesta.put("userCodDependencia", empleado.getCodigoDependencia());
				respuesta.put("userDescDependencia", empleado.getDependencia());
				
				pagina = "paginaDelegacionConsultaExpediente";
			}
			else {
				pagina = "paginaErrorSistema";
				errorMessage = "Usted no tiene autorizacion para entrar a la Consulta de Expediente Virtual.";
			}
		}
		catch(Exception e){
			log.error(e.getMessage(), e);
			pagina = "paginaErrorSistema";
			errorMessage = "A ocurrido un inconveniente por favor comuniquese con el Administrador." + e.getMessage();
		}
		finally{
			respuesta.put("mensajeError", errorMessage);
			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(pagina,respuesta);
			log.debug("Fin DelegacionConsultaExpedienteController.iniciarDelegacion");
		}
		
		return modelAndView;
	}
	
	//<prop key="consultarColaboradorPorRegistro">consultarColaboradorPorRegistro</prop>
	//<prop key="consultarColaboradorPorNombre">consultarColaboradorPorNombre</prop>
	
	public ModelAndView consultarColaboradorPorRegistro(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo consultarColaboradorPorRegistro");
			String txtRegistroColaborador = request.getParameter("txtRegistroColaborador");
			
			//<isNotNull prepend="AND" property="numeroRegistro"> M.NUMERO_REGISTRO_ALTERNO = #numeroRegistro# </isNotNull>
			//<isNotNull prepend="AND" property="nombreCompleto"> M.NOMB_CORT_PER like '%' || #nombreCompleto# || '%' </isNotNull>
			
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("numeroRegistro", txtRegistroColaborador);
			
			Empleado colaborador = consultaExpedienteService.getEmpleado(txtRegistroColaborador);
			respuesta.put("colaborador", colaborador);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo consultarColaboradorPorRegistro");
		}
		
		return modelAndView;
	}
	
	public ModelAndView consultarColaboradorPorNombre(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {
	
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo consultarColaboradorPorNombre");
			
			String txtModNombreColaborador = StringUtils.trimToEmpty(request.getParameter("txtModNombreColaborador")).toUpperCase();
			log.debug("NOmbre enviado a la consulta: " + txtModNombreColaborador);
			
			List<Empleado> listaColaboradores = consultaExpedienteService.getEmpleados(txtModNombreColaborador);
			respuesta.put("listaColaboradores", listaColaboradores);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo consultarColaboradorPorNombre");
		}
		
		return modelAndView;
	}
	
	private List<EncargosPersona> consultarDelegaciones(HttpServletRequest request, HttpServletResponse response) 
			throws ServiceException {
		
		try {

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");

			String numeroRegistro = usuarioBean.getNroRegistro().toUpperCase();
			Empleado empleado = consultaExpedienteService.getEmpleado(numeroRegistro);
			
			//SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			FormatoUtil formato = new FormatoUtil();
			
			//codiEmplPer 
			//codTipoProceso 
			//flagEncaEnc 
			//EL MISMO PAQUETE DE LAS QUERYS
			EncargosPersona param = new EncargosPersona();
			param.setCodiEmplPer(empleado.getCodigoEmpleado());
			param.setCodTipoProceso(PROCESO_DELEGACION);
			param.setFlagEncaEnc(DELEGACION_ACTIVA);
			
			List<EncargosPersona> listaDelegaciones = consultaExpedienteService.recuperarListaDelegaciones(param);
			
			for (EncargosPersona delegacion : listaDelegaciones) {

				//M1.NUMERO_REGISTRO_ALTERNO AS NUME_REGI_ALT_RESP, 
				//M1.NOMB_CORT_PER AS NOMB_CORT_PER_RESP, 
				//M2.NUMERO_REGISTRO_ALTERNO AS NUME_REGI_ALT_DELE, 
				//M2.NOMB_CORT_PER AS NOMB_CORT_PER_DELE, 
				//T.DESC_DEPE_TDE, 
				//->E.FECH_INIC_ENC, 
				//->E.FECH_FINA_ENC, 
				//E.MOTIVO, 

				delegacion.setNumeRegiAltResp(formato.formateaCadena(delegacion.getNumeRegiAltResp()));
				delegacion.setNombCortPerResp(formato.formateaCadena(delegacion.getNombCortPerResp()));
				delegacion.setNumeRegiAltDele(formato.formateaCadena(delegacion.getNumeRegiAltDele()));
				delegacion.setNombCortPerDele(formato.formateaCadena(delegacion.getNombCortPerDele()));
				delegacion.setDescDepeTde(formato.formateaCadena(delegacion.getDescDepeTde()));				
				delegacion.setFechInicEncDesc(formato.formateaFecha(delegacion.getFechInicEnc()));
				delegacion.setFechFinaEncDesc(formato.formateaFecha(delegacion.getFechFinaEnc()));
				delegacion.setMotivo(formato.formateaCadena(delegacion.getMotivo()));
			}
			
			return listaDelegaciones;
		}
		catch (Exception e) {
			log.error("Error" , e);
			throw new ServiceException (e);
		}
	}
	
	/** 
     * Recuperar expedientes virtuales 
     * @param HttpServletRequest request 
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */ 
	public ModelAndView recuperarDelegaciones(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarDelegaciones");
			
			List<EncargosPersona> listaDelegaciones = this.consultarDelegaciones(request, response);
			respuesta.put("listaDelegaciones", listaDelegaciones);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDelegaciones");
		}
		
		return modelAndView;
	}
	
	public ModelAndView exportarDelegaciones(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		//String pagina = "";
		//String errorMessage = "";
		
		try {			
			List<EncargosPersona> listaDelegaciones = this.consultarDelegaciones(request, response);
			
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			String fechaFormateada = sdf.format(new Date());
			
			// 2. Proceso las solicitudes para su exportacion a excel:
			HSSFWorkbook libroXLS/* = null*/;
			HSSFSheet hojaXLS/* = null*/;
			HSSFRow filaXLS/* = null*/;
			HSSFCell celdaXLS/* = null*/;
			
			HSSFCellStyle estiloTit/* = null*/;
			HSSFFont fuenteTit/* = null*/;
			
			HSSFCellStyle estiloDat/* = null*/;
			HSSFFont fuenteDat/* = null*/;
			
			HSSFCellStyle estiloDatIzq/* = null*/;
			HSSFFont fuenteDatIzq/* = null*/;
			
			libroXLS = new HSSFWorkbook();
			
			fuenteTit = libroXLS.createFont();
			fuenteTit.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // En negrita
			fuenteTit.setFontHeight((short) 160);
			fuenteTit.setFontName("Arial");
			
			fuenteDat = libroXLS.createFont();
			fuenteDat.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDat.setFontHeight((short) 160);
			fuenteDat.setFontName("Arial");
			
			fuenteDatIzq = libroXLS.createFont();
			fuenteDatIzq.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDatIzq.setFontHeight((short) 160);
			fuenteDatIzq.setFontName("Arial");
			
			estiloTit = libroXLS.createCellStyle();
			estiloTit.setFont(fuenteTit);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setAlignment(HSSFCellStyle.ALIGN_CENTER);

			estiloDat = libroXLS.createCellStyle();
			estiloDat.setFont(fuenteDat);
			estiloDat.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDat.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			estiloDatIzq = libroXLS.createCellStyle();
			estiloDatIzq.setFont(fuenteDat);
			estiloDatIzq.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			
			String nombreArchivo = "expedientes_" + fechaFormateada + ".xls";
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/vnd.ms-excel");

			// Ahora procesamos el reporte en
			hojaXLS = libroXLS.createSheet("Firmas");

			filaXLS = hojaXLS.createRow((short) 1);
			
			String[] columnas = 
			{"Nro. Registro", "Delegado A", "UUOO", "Fecha Inicio", 
			 "Fecha Fin", "Observaciones"};
			
			int z = 0;
			for (String columna : columnas) {
				celdaXLS = filaXLS.createCell(++z);
				celdaXLS.setCellStyle(estiloTit);
				celdaXLS.setCellValue(columna);
				hojaXLS.setColumnWidth(z, ((columna.length() + 10) * 512));
			}

			int i = 1;// numero de la fila desde la cual se itera...

			for (EncargosPersona delegacion : listaDelegaciones) {
				filaXLS = hojaXLS.createRow(++i);
				z = 0;
				
				if (i <= 65000) { //por limitaciones de xls clasico
					//i++;

					/*delegacion.getNumeRegiAltResp();
					delegacion.getNombCortPerResp();
					delegacion.getNumeRegiAltDele();
					delegacion.getNombCortPerDele();
					delegacion.getDescDepeTde();
					delegacion.getFechInicEnc();
					delegacion.getFechFinaEnc();
					delegacion.getMotivo();*/
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(delegacion.getNumeRegiAltDele());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(delegacion.getNombCortPerDele());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(delegacion.getDescDepeTde());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(delegacion.getFechInicEncDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(delegacion.getFechFinaEncDesc());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(delegacion.getMotivo());
				}
			}
			
			libroXLS.write(response.getOutputStream());
			response.getOutputStream().close();
			response.getOutputStream().flush();
			
			return modelAndView;
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
	}
	
	public ModelAndView registrarDelegacion(HttpServletRequest request, HttpServletResponse response) throws ServiceException {

		log.debug(getClass().getName() + " Inicio del metodo recuperarDelegaciones");
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		boolean validacion = true;
		//boolean grabacion = true;
		List<String> listaMensajes = new ArrayList<String>();
		String mensajeErrorRegistro = "";
		
		try {
		    String numeRegiAltResp = request.getParameter("numeRegiAltResp");
			String numeRegiAltDele = request.getParameter("numeRegiAltDele");
		    String fechInicEncDesc = request.getParameter("fechInicEncDesc");
		    String fechFinaEncDesc = request.getParameter("fechFinaEncDesc");
		    String codDependencia = request.getParameter("codDependencia");
		    String motivo = request.getParameter("motivo");
		    
		    Date fechInicEnc = null;
			try {
				fechInicEnc = sdf.parse(fechInicEncDesc);
				fechInicEnc.setHours(0);
				fechInicEnc.setMinutes(0);
				fechInicEnc.setSeconds(0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				fechInicEnc = null;
			}
			
		    Date fechFinaEnc = null;
			try {
				fechFinaEnc = sdf.parse(fechFinaEncDesc);
				fechFinaEnc.setHours(0);
				fechFinaEnc.setMinutes(0);
				fechFinaEnc.setSeconds(0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				fechFinaEnc = null;
			}
			
			Empleado empleadoResp = consultaExpedienteService.getEmpleado(numeRegiAltResp);
			Empleado empleadoDele = consultaExpedienteService.getEmpleado(numeRegiAltDele);
			String codiEncaEnc;
			if (empleadoDele == null || 
				empleadoDele.getCodigoDependencia() == null || 
				"".equals(empleadoDele.getCodigoEmpleado().trim())) {
				codiEncaEnc = null;
				validacion = false;
				listaMensajes.add("El colaborador indicado no existe.");
			}
			else {
				codiEncaEnc = empleadoDele.getCodigoEmpleado();
			}
			
			EncargosPersona paramTraslape = new EncargosPersona();
			paramTraslape.setCodiEmplPer(empleadoResp.getCodigoEmpleado());
			paramTraslape.setCodiEncaEnc(codiEncaEnc);
			paramTraslape.setCodTipoProceso(PROCESO_DELEGACION);
			paramTraslape.setCodDependencia(codDependencia);
			paramTraslape.setFechInicEnc(fechInicEnc);
			paramTraslape.setFechFinaEnc(fechFinaEnc);
			paramTraslape.setFlagEncaEnc(DELEGACION_ACTIVA);

			List<EncargosPersona> listaTraslapes = consultaExpedienteService.recuperarListaTraslapes(paramTraslape);
			if (!listaTraslapes.isEmpty()) {
				validacion = false;
				listaMensajes.add("La persona ya se encuentra registrada en el rango de fechas.");
			}
			
			if (validacion) {
				EncargosPersona param = new EncargosPersona();
				
				param.setCodiEmplPer(empleadoResp.getCodigoEmpleado());
				param.setCodiEncaEnc(empleadoDele.getCodigoEmpleado());
				param.setCodTipoProceso(PROCESO_DELEGACION);
				param.setCodDependencia(codDependencia);
				param.setFechInicEnc(fechInicEnc);
				param.setFechFinaEnc(fechFinaEnc);
				param.setFlagEncaEnc(DELEGACION_ACTIVA);
				param.setMotivo(motivo);
				
				// auditoria
				param.setUserCrea(usuarioBean.getLogin());
				param.setFechCrea(new Date());
				param.setUserModi(usuarioBean.getLogin());
				param.setFechModi(new Date());
				
				this.consultaExpedienteService.registrarDelegacion(param);
				
				respuesta.put("validacion", "1");
				respuesta.put("registro", "1");
				respuesta.put("listaMensajes", listaMensajes.toArray());
				respuesta.put("mensajeErrorRegistro", "");			
			}
			else {
				respuesta.put("validacion", "0");
				respuesta.put("registro", "0");
				respuesta.put("listaMensajes", listaMensajes.toArray());
				respuesta.put("mensajeErrorRegistro", mensajeErrorRegistro);
			}
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDelegaciones");
		}
		
		return modelAndView;
	}
	
	public ModelAndView deshabilitarDelegacion(HttpServletRequest request, HttpServletResponse response) throws ServiceException {

		log.debug(getClass().getName() + " Inicio del metodo recuperarDelegaciones");
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		try {

		    String numeRegiAltResp = request.getParameter("numeRegiAltResp");
			String numeRegiAltDele = request.getParameter("numeRegiAltDele");
		    String fechInicEncDesc = request.getParameter("fechInicEncDesc");
		    String fechFinaEncDesc = request.getParameter("fechFinaEncDesc");
		    String codDependencia = request.getParameter("codDependencia");
		    
		    Date fechInicEnc = null;
			try {
				fechInicEnc = sdf.parse(fechInicEncDesc);
				fechInicEnc.setHours(0);
				fechInicEnc.setMinutes(0);
				fechInicEnc.setSeconds(0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				fechInicEnc = null;
			}
			
		    Date fechFinaEnc = null;
			try {
				fechFinaEnc = sdf.parse(fechFinaEncDesc);
				fechFinaEnc.setHours(0);
				fechFinaEnc.setMinutes(0);
				fechFinaEnc.setSeconds(0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				fechFinaEnc = null;
			}
			
		    Date hoy = new Date();
		    hoy.setHours(0);
		    hoy.setMinutes(0);
		    hoy.setSeconds(0);	    
			
			Empleado empleadoResp = consultaExpedienteService.getEmpleado(numeRegiAltResp);
			Empleado empleadoDele = consultaExpedienteService.getEmpleado(numeRegiAltDele);
			
			EncargosPersona param = new EncargosPersona();
			param.setCodiEmplPer(empleadoResp.getCodigoEmpleado());
			param.setCodiEncaEnc(empleadoDele.getCodigoEmpleado());
			param.setCodTipoProceso(PROCESO_DELEGACION);
			param.setCodDependencia(codDependencia);
			param.setFechInicEnc(fechInicEnc);
			param.setFechFinaEnc(fechFinaEnc);
			param.setFechFinaEncParam(hoy);
			param.setFlagEncaEnc(DELEGACION_DESHABILITADA);
			
			// auditoria
			param.setUserModi(usuarioBean.getLogin());
			param.setFechModi(new Date());

		    int resultadoDeshabilitacion = consultaExpedienteService.deshabilitarDelegacion(param);
		    log.debug("resultado de la deshabilitacion: " + resultadoDeshabilitacion);
			if (resultadoDeshabilitacion > 0) {
				respuesta.put("resultadoDeshabilitacion", "1");
			}
			else {
				respuesta.put("resultadoDeshabilitacion", "0");				
			}
		    
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDelegaciones");
		}
		
		return modelAndView;
	}

	
	public String getJsonView() {
		return jsonView;
	}

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public JsonSerializer getJsonSerializer() {
		return jsonSerializer;
	}

	public void setJsonSerializer(JsonSerializer jsonSerializer) {
		this.jsonSerializer = jsonSerializer;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public ConsultaExpedienteService getConsultaExpedienteService() {
		return consultaExpedienteService;
	}

	public void setConsultaExpedienteService(
			ConsultaExpedienteService consultaExpedienteService) {
		this.consultaExpedienteService = consultaExpedienteService;
	}
}

