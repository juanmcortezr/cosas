package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper;


public class ThreadUser {

    private static ThreadLocal<UsuarioSol> usuarioSOL = new ThreadLocal<UsuarioSol>();

    public static UsuarioSol get() {
        return usuarioSOL.get();
    }
    
    
    public static void initUser(UsuarioSol user) {
        usuarioSOL.set(user);
    }
}
