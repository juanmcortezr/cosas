package pe.gob.sunat.recurso2.financiera.siga.tesoreria.tipocambio.web.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.tipocambio.service.GestionTipoCambioService;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.ServiceException;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.Empleado;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.Moneda;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.T17Ticam;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class ConsultaTipoCambioController extends MultiActionController {
	
	private String jsonView;
	private JsonSerializer jsonSerializer;
	
	private RegistroGeneralService registroGeneralService;
	private GestionTipoCambioService gestionTipoCambioService;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	private static final String PARAMETRO_MONEDAS = "3400";
	
	/** 
     * Carga la Pagina de la consulta 
     * @param HttpServletRequest request 
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */ 
	public ModelAndView iniciarConsulta(HttpServletRequest request, HttpServletResponse response) {
		
		log.debug("debug Inicio - ConsultaTipoCambioController.iniciarConsulta");
		
		ModelAndView modelAndView;
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		String pagina = "";
		String errorMessage = "";
		
		try {

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			List<T01ParametroBean> listaMoneda;
			listaMoneda = new ArrayList<T01ParametroBean>();
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cod_par", PARAMETRO_MONEDAS);
			params.put("cod_mod", "SIGA");
			params.put("cod_tipo", "D");
			
			listaMoneda = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			
			String numeroRegistro = usuarioBean.getNroRegistro().toUpperCase();
			Empleado empleado = gestionTipoCambioService.getEmpleado(numeroRegistro);
			
			params = new HashMap<String, Object>();
			params.put("codigoEmpleado", empleado.getCodigoEmpleado());
			
			if (log.isDebugEnabled())log.debug("getApeMaterno:"		+usuarioBean.getApeMaterno());
			if (log.isDebugEnabled())log.debug("getApePaterno:"		+usuarioBean.getApePaterno());
			if (log.isDebugEnabled())log.debug("getCodDepend:"		+usuarioBean.getCodDepend());
			if (log.isDebugEnabled())log.debug("getCodUO:"			+usuarioBean.getCodUO());
			if (log.isDebugEnabled())log.debug("getCorreo:"			+usuarioBean.getCorreo());
			if (log.isDebugEnabled())log.debug("getLogin:"			+usuarioBean.getLogin());
			if (log.isDebugEnabled())log.debug("getNombreCompleto:"	+usuarioBean.getNombreCompleto());
			if (log.isDebugEnabled())log.debug("getNombres:"		+usuarioBean.getNombres());
			if (log.isDebugEnabled())log.debug("getNroRegistro:"	+usuarioBean.getNroRegistro());
			if (log.isDebugEnabled())log.debug("getTicket:"			+usuarioBean.getTicket());
			
			respuesta.put("listaMoneda", listaMoneda);
			respuesta.put("userRegistro", usuarioBean.getNroRegistro());
			
			pagina = "paginaConsultaTipoCambio";
		}
		catch(Exception e){
			log.error(e.getMessage(), e);
			pagina = "paginaErrorSistema";
			errorMessage = "A ocurrido un inconveniente por favor comuniquese con el Administrador." + e.getMessage();
		}
		finally{
			respuesta.put("mensajeError", errorMessage);
			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(pagina,respuesta);
			log.debug("Fin ConsultaTipoCambioController.iniciarConsulta");
		}
		
		return modelAndView;
	}
	
	private List<T17Ticam> consultarTipoCambio(HttpServletRequest request, HttpServletResponse response) 
			throws ServiceException {
		
		try {
			//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			FormatoUtil formato = new FormatoUtil();
			
			String selTipoCambio = request.getParameter("selTipoCambio");
			String txtFechaRegistroDesde = request.getParameter("txtFechaRegistroDesde");
			String txtFechaRegistroHasta = request.getParameter("txtFechaRegistroHasta");
			String txtFechaPublicaDesde = request.getParameter("txtFechaPublicaDesde");
			String txtFechaPublicaHasta = request.getParameter("txtFechaPublicaHasta");
			String hdnTipoFecha = request.getParameter("hdnTipoFecha");
			
			log.debug("fechas enviadas: " + txtFechaRegistroDesde + " " + txtFechaRegistroHasta + " " + txtFechaPublicaDesde + " " +txtFechaPublicaHasta + " " + hdnTipoFecha + " " + selTipoCambio);
			
			if ("T".equals(selTipoCambio)) {
				selTipoCambio = null;
			}
			else {
				try {
					selTipoCambio = selTipoCambio.trim();
					
					Moneda paramMoneda = new Moneda();
					paramMoneda.setSimbMoneMon(selTipoCambio);
					List<Moneda> listaMoneda = gestionTipoCambioService.recuperarListaMoneda(paramMoneda);
					
					Moneda moneda = listaMoneda.get(0);
					selTipoCambio = moneda.getCodigoSipf().trim();
				}
				catch (Exception e) {
					log.error("error de obtencion de tipo de moneda sipf", e);
					selTipoCambio = null;
				}
			}
			
			Date fechaRegistroDesde = null;
			Date fechaRegistroHasta = null;
			Date fechaPublicacDesde = null;
			Date fechaPublicacHasta = null;
			
			if ("REG".equals(hdnTipoFecha)) {
				try {
					fechaRegistroDesde = sdf.parse(txtFechaRegistroDesde);
					fechaRegistroDesde.setHours(0);
					fechaRegistroDesde.setMinutes(0);
					fechaRegistroDesde.setSeconds(0);
				}
				catch (Exception e) {
					log.debug("error en conversion de fecha");
					fechaRegistroDesde = null;
				}
				
				try {
					fechaRegistroHasta = sdf.parse(txtFechaRegistroHasta);
					fechaRegistroHasta.setHours(23);
					fechaRegistroHasta.setMinutes(59);
					fechaRegistroHasta.setSeconds(59);
				}
				catch (Exception e) {
					log.debug("error en conversion de fecha");
					fechaRegistroHasta = null;
				}
			}
			else if ("PUB".equals(hdnTipoFecha)){
				try {
					fechaPublicacDesde = sdf.parse(txtFechaPublicaDesde);
					fechaPublicacDesde.setHours(0);
					fechaPublicacDesde.setMinutes(0);
					fechaPublicacDesde.setSeconds(0);
				}
				catch (Exception e) {
					log.debug("error en conversion de fecha");
					fechaPublicacDesde = null;
				}
				
				try {
					fechaPublicacHasta = sdf.parse(txtFechaPublicaHasta);
					fechaPublicacHasta.setHours(23);
					fechaPublicacHasta.setMinutes(59);
					fechaPublicacHasta.setSeconds(59);
				}
				catch (Exception e) {
					log.debug("error en conversion de fecha");
					fechaPublicacHasta = null;
				}
			}
			
			T17Ticam param = new T17Ticam();
			param.setT17codMoneda(selTipoCambio);
			param.setT17fCambioDesde(fechaRegistroDesde);
			param.setT17fCambioHasta(fechaRegistroHasta);
			param.setT17fPublicacDesde(fechaPublicacDesde);
			param.setT17fPublicacHasta(fechaPublicacHasta);
			List<T17Ticam> listaTipoCambio = gestionTipoCambioService.recuperarListaTipoCambio(param);

			Moneda paramMoneda = new Moneda();
			List<Moneda> listaMoneda = gestionTipoCambioService.recuperarListaMoneda(paramMoneda);
			Map<String, Moneda> mapMoneda = new HashMap<String, Moneda>();
			for (Moneda moneda : listaMoneda) {
				mapMoneda.put(moneda.getCodigoSipf(), moneda);
			}
			
			Moneda moneda;
			String codMoneda;
			
			for (T17Ticam tipoCambio : listaTipoCambio) {
				tipoCambio.setT17fCambioDesc(formato.formateaFecha(tipoCambio.getT17fCambio()));
				tipoCambio.setT17fPublicacDesc(formato.formateaFecha(tipoCambio.getT17fPublicac()));
				tipoCambio.setT17fCierreDesc(formato.formateaFecha(tipoCambio.getT17fCierre()));
				
				codMoneda = tipoCambio.getT17codMoneda();
				moneda = mapMoneda.get(codMoneda);

				tipoCambio.setDescMoneMon("-");
				if (moneda != null && moneda.getDescMoneMon() != null) {
					tipoCambio.setDescMoneMon(formato.formateaCadena(moneda.getDescMoneMon()));
				}
				
				tipoCambio.setT17iCambventDesc(formato.formateaNumero(tipoCambio.getT17iCambvent(), "###,###,###,###,##0.000"));
				tipoCambio.setT17iCambcompDesc(formato.formateaNumero(tipoCambio.getT17iCambcomp(), "###,###,###,###,##0.000"));
				//tipoCambio.setSimbMoneMon(formato.formateaCadena(tipoCambio.getSimbMoneMon()));
			}
			return listaTipoCambio;
		}
		catch (Exception e) {
			log.error("Error" , e);
			throw new ServiceException (e);
		}
	}
	
	/** 
     * Recuperar tipo cambio 
     * @param HttpServletRequest request 
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */ 
	public ModelAndView recuperarTipoCambio(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarTipoCambio");
			
			List<T17Ticam> listaTipoCambio = this.consultarTipoCambio(request, response);						
			respuesta.put("listaTipoCambio", listaTipoCambio);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarTipoCambio");
		}
		
		return modelAndView;
	}
	
	
	public ModelAndView exportarTipoCambio(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		try {			
			List<T17Ticam> listaTipoCambio = this.consultarTipoCambio(request, response);
			
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			String fechaFormateada = sdf.format(new Date());
			
			FormatoUtil formato = new FormatoUtil();
			
			// 2. Proceso las solicitudes para su exportacion a excel:
			HSSFWorkbook libroXLS/* = null*/;
			HSSFSheet hojaXLS/* = null*/;
			HSSFRow filaXLS/* = null*/;
			HSSFCell celdaXLS/* = null*/;
			
			HSSFCellStyle estiloTit/* = null*/;
			HSSFFont fuenteTit/* = null*/;
			
			HSSFCellStyle estiloDat/* = null*/;
			HSSFFont fuenteDat/* = null*/;
			
			HSSFCellStyle estiloDatIzq/* = null*/;
			HSSFFont fuenteDatIzq/* = null*/;
			
			libroXLS = new HSSFWorkbook();
			
			fuenteTit = libroXLS.createFont();
			fuenteTit.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // En negrita
			fuenteTit.setFontHeight((short) 160);
			fuenteTit.setFontName("Arial");
			
			fuenteDat = libroXLS.createFont();
			fuenteDat.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDat.setFontHeight((short) 160);
			fuenteDat.setFontName("Arial");
			
			fuenteDatIzq = libroXLS.createFont();
			fuenteDatIzq.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDatIzq.setFontHeight((short) 160);
			fuenteDatIzq.setFontName("Arial");
			
			estiloTit = libroXLS.createCellStyle();
			estiloTit.setFont(fuenteTit);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setAlignment(HSSFCellStyle.ALIGN_CENTER);

			estiloDat = libroXLS.createCellStyle();
			estiloDat.setFont(fuenteDat);
			estiloDat.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDat.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			estiloDatIzq = libroXLS.createCellStyle();
			estiloDatIzq.setFont(fuenteDat);
			estiloDatIzq.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			
			String nombreArchivo = "tipocambio_" + fechaFormateada + ".xls";
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/vnd.ms-excel");
			
			// Ahora procesamos el reporte en
			hojaXLS = libroXLS.createSheet("Tipo_cambio");
			
			filaXLS = hojaXLS.createRow((short) 1);
			
			String[] columnas = 
				{"Fecha de Cierre",
				 "Fecha de Publicaci\u00f3n",
				 "Fecha de Registro",
				 "Tipo de Moneda",
				 "Precio de Venta",
				 "Precio de Compra"};
			
			int z = 0;
			for (String columna : columnas) {
				celdaXLS = filaXLS.createCell(++z);
				celdaXLS.setCellStyle(estiloTit);
				celdaXLS.setCellValue(columna);
				hojaXLS.setColumnWidth(z, ((columna.length() + 10)* 512));
			}
			
			int i = 1;// numero de la fila desde la cual se itera...
			
			for (T17Ticam tipoCambio : listaTipoCambio) {
				
				if (i <= 65000) {
					filaXLS = hojaXLS.createRow(++i);
					z = 0;
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(tipoCambio.getT17fCierreDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(tipoCambio.getT17fPublicacDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(tipoCambio.getT17fCambioDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(tipoCambio.getDescMoneMon());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(formato.reemplazaComas(formato.formateaNumero(tipoCambio.getT17iCambvent(), "##############0.000")));
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(formato.reemplazaComas(formato.formateaNumero(tipoCambio.getT17iCambcomp(), "##############0.000")));
				}
			}
			
			libroXLS.write(response.getOutputStream());
			response.getOutputStream().close();
			response.getOutputStream().flush();
			
			return modelAndView;
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
	}
	
	public String getJsonView() {
		return jsonView;
	}

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public JsonSerializer getJsonSerializer() {
		return jsonSerializer;
	}

	public void setJsonSerializer(JsonSerializer jsonSerializer) {
		this.jsonSerializer = jsonSerializer;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public GestionTipoCambioService getGestionTipoCambioService() {
		return gestionTipoCambioService;
	}

	public void setGestionTipoCambioService(
			GestionTipoCambioService gestionTipoCambioService) {
		this.gestionTipoCambioService = gestionTipoCambioService;
	}
}