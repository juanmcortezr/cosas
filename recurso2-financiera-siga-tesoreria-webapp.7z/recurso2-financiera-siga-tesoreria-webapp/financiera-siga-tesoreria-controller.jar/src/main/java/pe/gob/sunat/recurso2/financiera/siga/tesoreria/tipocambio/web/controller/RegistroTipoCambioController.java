package pe.gob.sunat.recurso2.financiera.siga.tesoreria.tipocambio.web.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.tipocambio.service.GestionTipoCambioService;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.ServiceException;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.Empleado;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.Moneda;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.T17Ticam;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.TipoCambio;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.L9850Tipocambio;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.L9851Ticam;

public class RegistroTipoCambioController extends MultiActionController {
	
	private String jsonView;
	private JsonSerializer jsonSerializer;
	
	private RegistroGeneralService registroGeneralService;
	private GestionTipoCambioService gestionTipoCambioService;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	private static final String PARAMETRO_MONEDAS = "3400";
	
	private static final String ACCION_INSERT = "I";
	private static final String ACCION_UPDATE = "U";
	private static final String ACCION_DELETE = "D";
	private static final String ACCION_LOGIN = "L";
	private static final String ACCION_AUTH = "A";
	
	private static final String MODULO = "tcwsiga";
	
	/** 
     * Carga la Pagina de la consulta 
     * @param HttpServletRequest request 
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */ 
	public ModelAndView iniciarRegistro(HttpServletRequest request, HttpServletResponse response) {
		
		log.debug("debug Inicio - registroTipoCambioController.iniciarRegistro");
		
		ModelAndView modelAndView;
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		String pagina = "";
		String errorMessage = "";
		
		try {
			
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			List<T01ParametroBean> listaMoneda;
			listaMoneda = new ArrayList<T01ParametroBean>();
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cod_par", PARAMETRO_MONEDAS);
			params.put("cod_mod", "SIGA");
			params.put("cod_tipo", "D");
			
			listaMoneda = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			
			List<String> listaAnios;
			listaAnios = (List<String>)gestionTipoCambioService.recuperarListaAnios();
			
			String numeroRegistro = usuarioBean.getNroRegistro().toUpperCase();
			Empleado empleado = gestionTipoCambioService.getEmpleado(numeroRegistro);
			
			params = new HashMap<String, Object>();
			params.put("codigoEmpleado", empleado.getCodigoEmpleado());
			
			if (log.isDebugEnabled())log.debug("getApeMaterno:"		+usuarioBean.getApeMaterno());
			if (log.isDebugEnabled())log.debug("getApePaterno:"		+usuarioBean.getApePaterno());
			if (log.isDebugEnabled())log.debug("getCodDepend:"		+usuarioBean.getCodDepend());
			if (log.isDebugEnabled())log.debug("getCodUO:"			+usuarioBean.getCodUO());
			if (log.isDebugEnabled())log.debug("getCorreo:"			+usuarioBean.getCorreo());
			if (log.isDebugEnabled())log.debug("getLogin:"			+usuarioBean.getLogin());
			if (log.isDebugEnabled())log.debug("getNombreCompleto:"	+usuarioBean.getNombreCompleto());
			if (log.isDebugEnabled())log.debug("getNombres:"		+usuarioBean.getNombres());
			if (log.isDebugEnabled())log.debug("getNroRegistro:"	+usuarioBean.getNroRegistro());
			if (log.isDebugEnabled())log.debug("getTicket:"			+usuarioBean.getTicket());
			
			respuesta.put("listaMoneda", listaMoneda);
			respuesta.put("listaAnios", listaAnios);
			respuesta.put("userRegistro", usuarioBean.getNroRegistro());

			Date fecha = new Date();
			
			L9850Tipocambio l9850 = new L9850Tipocambio();
			
			l9850.setNomTabAud("TIPO_CAMBIO");
			l9850.setCodUsuReg(usuarioBean.getNroRegistro());
			l9850.setCodAccAud(ACCION_LOGIN);
			l9850.setFecRegAud(fecha);
			//l9850.setValAntTab("");
			//l9850.setValNueTab("");
			
			l9850.setFecRegis(fecha);
			l9850.setCodUsuregis(usuarioBean.getNroRegistro());
			l9850.setDirIpusuregis(request.getRemoteAddr());
			l9850.setFecModif(fecha);
			l9850.setCodUsumodif(usuarioBean.getNroRegistro());
			l9850.setDirIpusumodif(request.getRemoteAddr());

			gestionTipoCambioService.registrarAuditoriaOracle(l9850);
			
			L9851Ticam l9851 = new L9851Ticam();

			l9851.setNomTabAud("T17TICAM");
			l9851.setCodUsuReg(usuarioBean.getNroRegistro());
			l9851.setCodAccAud(ACCION_LOGIN);
			l9851.setFecRegAud(fecha);
			//l9851.setValAntTab("");
			//l9851.setValNueTab("");
			
			l9851.setFecRegis(fecha);
			l9851.setCodUsuregis(usuarioBean.getNroRegistro());
			l9851.setDirIpusuregis(request.getRemoteAddr());
			l9851.setFecModif(fecha);
			l9851.setCodUsumodif(usuarioBean.getNroRegistro());
			l9851.setDirIpusumodif(request.getRemoteAddr());

			gestionTipoCambioService.registrarAuditoriaInformix(l9851);
			
			pagina = "paginaRegistroTipoCambio";
		}
		catch(Exception e){
			log.error(e.getMessage(), e);
			pagina = "paginaErrorSistema";
			errorMessage = "A ocurrido un inconveniente por favor comuniquese con el Administrador." + e.getMessage();
		}
		finally{
			respuesta.put("mensajeError", errorMessage);
			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(pagina,respuesta);
			log.debug("Fin RegistroTipoCambioController.iniciarConsulta");
		}
		
		return modelAndView;
	}
	
	/** 
     * Recuperar tipo cambio 
     * @param HttpServletRequest request 
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */ 
	public ModelAndView recuperarTipoCambioMensual(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarTipoCambio");

			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
			FormatoUtil formato = new FormatoUtil();
			
			String selTipoMoneda = request.getParameter("selTipoMoneda");
			String selAnio = request.getParameter("selAnio");
			String selMes = request.getParameter("selMes");
			
			String codTipoMoneda = "";
			
			log.debug("fechas enviadas: " + selTipoMoneda + " " + selAnio + " " + selMes);
			
			try {
				selTipoMoneda = selTipoMoneda.trim();
				
				Moneda paramMoneda = new Moneda();
				paramMoneda.setSimbMoneMon(selTipoMoneda);
				List<Moneda> listaMoneda = gestionTipoCambioService.recuperarListaMoneda(paramMoneda);
				
				Moneda moneda = listaMoneda.get(0);
				codTipoMoneda = moneda.getCodigoSipf().trim();
			}
			catch (Exception e) {
				log.error("error de obtencion de tipo de moneda sipf", e);
				throw new Exception("No fue posible recuperar la informaci&oacute;n del periodo mensual.");
			}
			
			Calendar fechaRegistroDesde = null;
			Calendar fechaRegistroHasta = null;
			
			boolean validarSiga = gestionTipoCambioService.validarGrabarSiga(selTipoMoneda);
			
			try {
				fechaRegistroDesde = Calendar.getInstance();
				fechaRegistroDesde.set(Calendar.DATE, 1);
				fechaRegistroDesde.set(Calendar.MONTH, Integer.parseInt(selMes) - 1);
				fechaRegistroDesde.set(Calendar.YEAR, Integer.parseInt(selAnio));
				fechaRegistroDesde.set(Calendar.HOUR_OF_DAY, 0);
				fechaRegistroDesde.set(Calendar.MINUTE, 0);
				fechaRegistroDesde.set(Calendar.SECOND,0);
				fechaRegistroDesde.set(Calendar.MILLISECOND, 0);
			}
			catch (Exception e) {
				log.error("error en conversion de fecha", e);
				throw new Exception("No fue posible recuperar la informaci&oacute;n del periodo mensual.");
			}
			
			try {
				fechaRegistroHasta = Calendar.getInstance();
				fechaRegistroHasta.set(Calendar.DATE, 1);
				fechaRegistroHasta.set(Calendar.MONTH, Integer.parseInt(selMes));
				fechaRegistroHasta.set(Calendar.YEAR, Integer.parseInt(selAnio));
				fechaRegistroHasta.set(Calendar.HOUR_OF_DAY, 23);
				fechaRegistroHasta.set(Calendar.MINUTE, 59);
				fechaRegistroHasta.set(Calendar.SECOND,59);
				fechaRegistroHasta.set(Calendar.MILLISECOND, 999);
				fechaRegistroHasta.add(Calendar.DATE, -1);
			}
			catch (Exception e) {
				log.error("error en conversion de fecha", e);
				throw new Exception("No fue posible recuperar la informaci&oacute;n del periodo mensual.");
			}
			
			T17Ticam param = new T17Ticam();
			param.setT17codMoneda(codTipoMoneda);
			param.setT17fCambioDesde(fechaRegistroDesde.getTime());
			param.setT17fCambioHasta(fechaRegistroHasta.getTime());
			List<T17Ticam> listaTipoCambio = gestionTipoCambioService.recuperarListaTipoCambio(param);
			
			Calendar hoy = Calendar.getInstance();
			hoy.set(Calendar.HOUR_OF_DAY, 23);
			hoy.set(Calendar.MINUTE, 59);
			hoy.set(Calendar.SECOND,59);
			hoy.set(Calendar.MILLISECOND, 999);
			
			Calendar dia, minimo, maximo;
			
			minimo = Calendar.getInstance();
			minimo.setTime(fechaRegistroDesde.getTime());
			minimo.set(Calendar.HOUR_OF_DAY, 0);
			minimo.set(Calendar.MINUTE, 0);
			minimo.set(Calendar.SECOND, 0);
			minimo.set(Calendar.MILLISECOND, 0);
			
			maximo = Calendar.getInstance();
			if (hoy.before(fechaRegistroHasta) || hoy.equals(fechaRegistroHasta)) {
				maximo.setTime(hoy.getTime());
			}
			else {
				maximo.setTime(fechaRegistroHasta.getTime());
			}
			maximo.set(Calendar.HOUR_OF_DAY, 0);
			maximo.set(Calendar.MINUTE, 0);
			maximo.set(Calendar.SECOND, 0);
			minimo.set(Calendar.MILLISECOND, 0);
			
			List<Map<String, Object>> calendarioList = new ArrayList<Map<String, Object>>();
			Map<String, Object> calendario;
			Map<String, T17Ticam> calendarioMap = new HashMap<String, T17Ticam>();
			
			for (T17Ticam tipoCambio : listaTipoCambio) {
				tipoCambio.setT17fCambioDesc(formato.formateaFecha(tipoCambio.getT17fCambio()));
				tipoCambio.setT17fPublicacDesc(formato.formateaFecha(tipoCambio.getT17fPublicac()));
				tipoCambio.setT17fCierreDesc(formato.formateaFecha(tipoCambio.getT17fCierre()));
				tipoCambio.setT17codMoneda(formato.formateaCadena(tipoCambio.getT17codMoneda()));
				tipoCambio.setT17iCambventDesc(formato.reemplazaComas(formato.formateaNumero(tipoCambio.getT17iCambvent(), "##############0.000")));
				tipoCambio.setT17iCambcompDesc(formato.reemplazaComas(formato.formateaNumero(tipoCambio.getT17iCambcomp(), "##############0.000")));
				tipoCambio.setSimbMoneMon(formato.formateaCadena(selTipoMoneda));
				calendarioMap.put(sdf2.format(tipoCambio.getT17fCambio()), tipoCambio);				
			}
			
			dia = Calendar.getInstance();
			dia.setTime(minimo.getTime());
			
			T17Ticam tipoCambio;
			TipoCambio tcParam;
			Calendar tcParamFechaRegistroDesde, tcParamFechaRegistroHasta;
			
			int i = 1;
			while (dia.before(maximo) || dia.equals(maximo)) {
				
				boolean existeInformacion = false, existeInconsistencia = false, esDiaUtil = true;
				Integer countFeriado = null;
				
				tipoCambio = calendarioMap.get(sdf2.format(dia.getTime()));
				if (tipoCambio !=null && tipoCambio.getT17fCambio() != null) {
					existeInformacion = true;
					
					
					countFeriado = gestionTipoCambioService.findIsFeriado(tipoCambio.getT17fCambio());

					tcParam = new TipoCambio();
					tcParam.setSimbMoneMon(selTipoMoneda);
					
					tcParamFechaRegistroDesde = Calendar.getInstance();
					tcParamFechaRegistroDesde.setTime(dia.getTime());
					tcParamFechaRegistroDesde.set(Calendar.HOUR_OF_DAY, 0);
					tcParamFechaRegistroDesde.set(Calendar.MINUTE, 0);
					tcParamFechaRegistroDesde.set(Calendar.SECOND, 0);
					tcParamFechaRegistroDesde.set(Calendar.MILLISECOND, 0);
				
					tcParamFechaRegistroHasta = Calendar.getInstance();
					tcParamFechaRegistroHasta.setTime(dia.getTime());
					tcParamFechaRegistroHasta.set(Calendar.HOUR_OF_DAY, 23);
					tcParamFechaRegistroHasta.set(Calendar.MINUTE, 59);
					tcParamFechaRegistroHasta.set(Calendar.SECOND, 59);
					tcParamFechaRegistroHasta.set(Calendar.MILLISECOND, 999);
					
					tcParam.setFechCambTipDesde(tcParamFechaRegistroDesde.getTime());
					tcParam.setFechCambTipHasta(tcParamFechaRegistroHasta.getTime());
					existeInconsistencia = gestionTipoCambioService.validarInconsistenciaTipoCambio(tipoCambio, tcParam);
				}
				
				if (dia.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || dia.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
					esDiaUtil = false;
				}
				else if (countFeriado != null && countFeriado.intValue() > 0) {
					esDiaUtil = false;
				}
				
				if (existeInformacion) {

					if (existeInconsistencia && validarSiga) {
						calendario = new HashMap<String, Object>();
						calendario.put("id", i);
						calendario.put("title", "Incon. entre SIGA y PF");
						calendario.put("start", sdf2.format(tipoCambio.getT17fCambio()));
						calendario.put("end", sdf2.format(tipoCambio.getT17fCambio()));
						calendario.put("color", "#ff0000");
						calendarioList.add(calendario);
						i++;
					}

					
					calendario = new HashMap<String, Object>();
					calendario.put("id", i);
					calendario.put("title", "F. publ: " + tipoCambio.getT17fPublicacDesc());
					calendario.put("start", sdf2.format(tipoCambio.getT17fCambio()));
					calendario.put("end", sdf2.format(tipoCambio.getT17fCambio()));
					calendarioList.add(calendario);
					i++;

					calendario = new HashMap<String, Object>();
					calendario.put("id", i);
					calendario.put("title", "F. cier: " + tipoCambio.getT17fCierreDesc());
					calendario.put("start", sdf2.format(tipoCambio.getT17fCambio()));
					calendario.put("end", sdf2.format(tipoCambio.getT17fCambio()));
					calendarioList.add(calendario);
					i++;
					
					calendario = new HashMap<String, Object>();
					calendario.put("id", i);
					calendario.put("title", "P. com: " + tipoCambio.getT17iCambcompDesc());
					calendario.put("start", sdf2.format(tipoCambio.getT17fCambio()));
					calendario.put("end", sdf2.format(tipoCambio.getT17fCambio()));
					calendarioList.add(calendario);
					i++;

					calendario = new HashMap<String, Object>();
					calendario.put("id", i);
					calendario.put("title", "P. ven: " + tipoCambio.getT17iCambventDesc());
					calendario.put("start", sdf2.format(tipoCambio.getT17fCambio()));
					calendario.put("end", sdf2.format(tipoCambio.getT17fCambio()));
					calendarioList.add(calendario);
					i++;
				}
				else if (esDiaUtil) {
					calendario = new HashMap<String, Object>();
					calendario.put("id", i);
					calendario.put("title", "F. publ: " + "T.C. no registrado");
					calendario.put("start", sdf2.format(dia.getTime()));
					calendario.put("end", sdf2.format(dia.getTime()));
					calendario.put("color", "#ff0000");
					calendarioList.add(calendario);
					i++;
				}

				dia.add(Calendar.DATE, 1);
			}
			
			respuesta.put("listaTipoCambio", listaTipoCambio);
			respuesta.put("calendarioList", calendarioList);
			
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarTipoCambio");
		}
		
		return modelAndView;
	}

	public ModelAndView recuperarTipoCambioDiario(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarTipoCambio");
			
			SimpleDateFormat sdf  = new SimpleDateFormat("yyyyMMdd");
			FormatoUtil formato = new FormatoUtil();
			
			String txtPrmRegTipoMoneda = request.getParameter("txtPrmRegTipoMoneda");
			String txtPrmRegFechaRegistro = request.getParameter("txtPrmRegFechaRegistro");
			Date txtPrmRegFechaRegistroDate;
			
			log.debug("fechas enviadas: " + txtPrmRegTipoMoneda + " " + txtPrmRegFechaRegistro);

			Moneda moneda = new Moneda();
			try {
				txtPrmRegTipoMoneda = txtPrmRegTipoMoneda.trim();
				txtPrmRegFechaRegistroDate = sdf.parse(txtPrmRegFechaRegistro);
				
				Moneda paramMoneda = new Moneda();
				paramMoneda.setSimbMoneMon(txtPrmRegTipoMoneda);
				List<Moneda> listaMoneda = gestionTipoCambioService.recuperarListaMoneda(paramMoneda);
				
				moneda = listaMoneda.get(0);
				txtPrmRegTipoMoneda = moneda.getCodigoSipf().trim();
			}
			catch (Exception e) {
				log.error("error de obtencion de tipo de moneda sipf", e);
				throw new Exception("No fue posible recuperar la informaci&oacute;n diaria.");
			}
			
			Calendar fechaRegistroDesde = null;
			Calendar fechaRegistroHasta = null;
			
			try {
				fechaRegistroDesde = Calendar.getInstance();
				fechaRegistroDesde.setTime(txtPrmRegFechaRegistroDate);
				fechaRegistroDesde.set(Calendar.HOUR_OF_DAY, 0);
				fechaRegistroDesde.set(Calendar.MINUTE, 0);
				fechaRegistroDesde.set(Calendar.SECOND,0);
				fechaRegistroDesde.set(Calendar.MILLISECOND, 0);
			}
			catch (Exception e) {
				log.error("error en conversion de fecha", e);
				throw new Exception("No fue posible recuperar la informaci&oacute;n diaria.");
			}
			
			try {
				fechaRegistroHasta = Calendar.getInstance();
				fechaRegistroHasta.setTime(txtPrmRegFechaRegistroDate);
				fechaRegistroHasta.set(Calendar.HOUR_OF_DAY, 23);
				fechaRegistroHasta.set(Calendar.MINUTE, 59);
				fechaRegistroHasta.set(Calendar.SECOND,59);
				fechaRegistroHasta.set(Calendar.MILLISECOND, 999);
			}
			catch (Exception e) {
				log.error("error en conversion de fecha", e);
				throw new Exception("No fue posible recuperar la informaci&oacute;n diaria.");
			}
			
			T17Ticam param = new T17Ticam();
			param.setT17codMoneda(txtPrmRegTipoMoneda);
			param.setT17fCambioDesde(fechaRegistroDesde.getTime());
			param.setT17fCambioHasta(fechaRegistroHasta.getTime());
			List<T17Ticam> listaTipoCambio = gestionTipoCambioService.recuperarListaTipoCambio(param);
			
			T17Ticam tipoCambio;
			if (listaTipoCambio != null && listaTipoCambio.size() > 0) {
				tipoCambio = listaTipoCambio.get(0);
				
				tipoCambio.setT17fCambioDesc(formato.formateaFecha(tipoCambio.getT17fCambio()));
				tipoCambio.setT17fPublicacDesc(formato.formateaFecha(tipoCambio.getT17fPublicac()));
				tipoCambio.setT17fCierreDesc(formato.formateaFecha(tipoCambio.getT17fCierre()));
				
				tipoCambio.setDescMoneMon(formato.formateaCadena(moneda.getDescMoneMon()));
				tipoCambio.setT17codMoneda(formato.formateaCadena(tipoCambio.getT17codMoneda()));
				tipoCambio.setSimbMoneMon(formato.formateaCadena(moneda.getSimbMoneMon()));

				tipoCambio.setT17iCambventDesc(formato.reemplazaComas(formato.formateaNumero(tipoCambio.getT17iCambvent(), "##############0.000")));
				tipoCambio.setT17iCambcompDesc(formato.reemplazaComas(formato.formateaNumero(tipoCambio.getT17iCambcomp(), "##############0.000")));
				
				respuesta.put("existe", "1");
			}
			else {
				tipoCambio = new T17Ticam();

				tipoCambio.setT17fCambioDesc(formato.formateaFecha(fechaRegistroDesde.getTime()));
				tipoCambio.setT17fPublicacDesc("");
				tipoCambio.setT17fCierreDesc("");
				
				tipoCambio.setDescMoneMon(moneda.getDescMoneMon());
				tipoCambio.setT17codMoneda(formato.formateaCadena(moneda.getCodigoSipf()));
				tipoCambio.setSimbMoneMon(formato.formateaCadena(moneda.getSimbMoneMon()));

				tipoCambio.setT17iCambventDesc("");
				tipoCambio.setT17iCambcompDesc("");
				
				respuesta.put("existe", "0");
			}

			respuesta.put("tipoCambio", tipoCambio);
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarTipoCambio");
		}
		
		return modelAndView;
	}

	public ModelAndView validarTipoCambioRegistro(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		//validacion obligatoria que la fecha de publicacion no exista en otro dia para esa moneda
		//mensaje de alerta que la fecha de registro exista para otro dia para esa moneda
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo validarTipoCambio");
			
			FormatoUtil formato = new FormatoUtil();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			
			String txtRegFechaRegistro  = request.getParameter("txtRegFechaRegistro");
			String txtRegFechaPublicacion  = request.getParameter("txtRegFechaPublicacion");
			String txtRegFechaCierre = request.getParameter("txtRegFechaCierre");
			String hdnRegTipoMoneda = request.getParameter("hdnRegTipoMoneda");
			String hdnRegSimbMoneda = request.getParameter("hdnRegSimbMoneda");
					
			log.debug("parametros para registrar: " + txtRegFechaRegistro + " " + txtRegFechaPublicacion + " " + txtRegFechaCierre + " " + hdnRegTipoMoneda);
			
			/*	<isNotNull prepend="AND" property="t17codMoneda"> t17cod_moneda = #t17codMoneda:CHAR#</isNotNull>
			*/

			hdnRegTipoMoneda = hdnRegTipoMoneda.trim();
			hdnRegSimbMoneda = hdnRegSimbMoneda.trim();
			
			Calendar fechaRegistroDesde, fechaRegistroHasta, fechaPublicacionDesde, fechaPublicacionHasta,
				fechaCierreDesde, fechaCierreHasta;
			
			try {
				fechaRegistroDesde = Calendar.getInstance();
				fechaRegistroDesde.setTime(sdf.parse(txtRegFechaRegistro));
				fechaRegistroDesde.set(Calendar.HOUR_OF_DAY, 0);
				fechaRegistroDesde.set(Calendar.MINUTE, 0);
				fechaRegistroDesde.set(Calendar.SECOND,0);
				fechaRegistroDesde.set(Calendar.MILLISECOND, 0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				throw new Exception("No fue posible validar la informaci&oacute;n diaria.");
			}
			
			try {
				fechaRegistroHasta = Calendar.getInstance();
				fechaRegistroHasta.setTime(sdf.parse(txtRegFechaRegistro));
				fechaRegistroHasta.set(Calendar.HOUR_OF_DAY, 23);
				fechaRegistroHasta.set(Calendar.MINUTE, 59);
				fechaRegistroHasta.set(Calendar.SECOND,59);
				fechaRegistroHasta.set(Calendar.MILLISECOND, 999);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				throw new Exception("No fue posible validar la informaci&oacute;n diaria.");
			}

			try {
				fechaPublicacionDesde = Calendar.getInstance();
				fechaPublicacionDesde.setTime(sdf.parse(txtRegFechaPublicacion));
				fechaPublicacionDesde.set(Calendar.HOUR_OF_DAY, 0);
				fechaPublicacionDesde.set(Calendar.MINUTE, 0);
				fechaPublicacionDesde.set(Calendar.SECOND,0);
				fechaPublicacionDesde.set(Calendar.MILLISECOND, 0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				throw new Exception("No fue posible validar la informaci&oacute;n diaria.");
			}
			
			try {
				fechaPublicacionHasta = Calendar.getInstance();
				fechaPublicacionHasta.setTime(sdf.parse(txtRegFechaPublicacion));
				fechaPublicacionHasta.set(Calendar.HOUR_OF_DAY, 23);
				fechaPublicacionHasta.set(Calendar.MINUTE, 59);
				fechaPublicacionHasta.set(Calendar.SECOND,59);
				fechaPublicacionHasta.set(Calendar.MILLISECOND, 999);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				throw new Exception("No fue posible validar la informaci&oacute;n diaria.");
			}

			try {
				fechaCierreDesde = Calendar.getInstance();
				fechaCierreDesde.setTime(sdf.parse(txtRegFechaCierre));
				fechaCierreDesde.set(Calendar.HOUR_OF_DAY, 0);
				fechaCierreDesde.set(Calendar.MINUTE, 0);
				fechaCierreDesde.set(Calendar.SECOND,0);
				fechaCierreDesde.set(Calendar.MILLISECOND, 0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				throw new Exception("No fue posible validar la informaci&oacute;n diaria.");
			}
			
			try {
				fechaCierreHasta = Calendar.getInstance();
				fechaCierreHasta.setTime(sdf.parse(txtRegFechaCierre));
				fechaCierreHasta.set(Calendar.HOUR_OF_DAY, 23);
				fechaCierreHasta.set(Calendar.MINUTE, 59);
				fechaCierreHasta.set(Calendar.SECOND,59);
				fechaCierreHasta.set(Calendar.MILLISECOND, 999);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				throw new Exception("No fue posible validar la informaci&oacute;n diaria.");
			}

			T17Ticam param = new T17Ticam();
			param.setT17codMoneda(hdnRegTipoMoneda);
			param.setT17fCambio(fechaRegistroHasta.getTime());
			param.setT17fCambioDesde(fechaRegistroDesde.getTime());
			param.setT17fCambioDesde(fechaRegistroHasta.getTime());
			param.setT17fPublicacDesde(fechaPublicacionDesde.getTime());
			param.setT17fPublicacHasta(fechaPublicacionHasta.getTime());
			param.setT17fCierreDesde(fechaCierreDesde.getTime());
			param.setT17fCierreHasta(fechaCierreHasta.getTime());
				
			respuesta.putAll(gestionTipoCambioService.validarTipoCambioRegistro(param));
			
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarTipoCambio");
		}
		
		return modelAndView;
	}
	
	public ModelAndView validarTipoCambioEliminacion(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo validarTipoCambio");
			
			FormatoUtil formato = new FormatoUtil();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			
			String txtRegFechaRegistro  = request.getParameter("txtRegFechaRegistro");
			String hdnRegTipoMoneda = request.getParameter("hdnRegTipoMoneda");
			String hdnRegSimbMoneda = request.getParameter("hdnRegSimbMoneda");
					
			log.debug("parametros para registrar: " + txtRegFechaRegistro + hdnRegTipoMoneda);

			hdnRegTipoMoneda = hdnRegTipoMoneda.trim();
			hdnRegSimbMoneda = hdnRegSimbMoneda.trim();
			
			Calendar fechaRegistro;
			
			try {
				fechaRegistro = Calendar.getInstance();
				fechaRegistro.setTime(sdf.parse(txtRegFechaRegistro));
				fechaRegistro.set(Calendar.HOUR_OF_DAY, 0);
				fechaRegistro.set(Calendar.MINUTE, 0);
				fechaRegistro.set(Calendar.SECOND,0);
				fechaRegistro.set(Calendar.MILLISECOND, 0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				throw new Exception("No fue posible validar la informaci&oacute;n diaria.");
			}
			
			T17Ticam param = new T17Ticam();
			param.setT17codMoneda(hdnRegTipoMoneda);
			param.setT17fCambio(fechaRegistro.getTime());
				
			respuesta.putAll(gestionTipoCambioService.validarTipoCambioEliminacion(param));
			
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarTipoCambio");
		}
		
		return modelAndView;
	}
	
	public ModelAndView registrarTipoCambio(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo registrarTipoCambio");
			
			FormatoUtil formato = new FormatoUtil();
			
			String hdnRegAccion = request.getParameter("hdnRegAccion");
			String txtRegFechaRegistro = request.getParameter("txtRegFechaRegistro");
			String txtRegFechaPublicacion = request.getParameter("txtRegFechaPublicacion");
			String txtRegFechaCierre = request.getParameter("txtRegFechaCierre");
			String hdnRegTipoMoneda = request.getParameter("hdnRegTipoMoneda");
			String hdnRegSimbMoneda = request.getParameter("hdnRegSimbMoneda");
			String txtRegPrecioCompra = request.getParameter("txtRegPrecioCompra");
			String txtRegPrecioVenta = request.getParameter("txtRegPrecioVenta");
			
			log.debug("parametros para registrar: " + hdnRegAccion + " " + txtRegFechaRegistro + " " + txtRegFechaPublicacion + " " + txtRegFechaCierre);
			log.debug("parametros para registrar: " + hdnRegTipoMoneda + " " + hdnRegSimbMoneda + " " + txtRegPrecioCompra + " " + txtRegPrecioVenta);
			
			hdnRegAccion = hdnRegAccion.trim();
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm:ss");
			
			Date hoy = new Date();
			String userRegistro = usuarioBean.getNroRegistro();  
			
			Calendar fechaRegistro, fechaPublicacion, fechaCierre;
			BigDecimal precioCompra, precioVenta;

			boolean validarSiga = gestionTipoCambioService.validarGrabarSiga(hdnRegSimbMoneda);
			
			try {
				fechaRegistro = Calendar.getInstance();
				fechaRegistro.setTime(sdf.parse(txtRegFechaRegistro));
				fechaRegistro.set(Calendar.HOUR_OF_DAY, 0);
				fechaRegistro.set(Calendar.MINUTE, 0);
				fechaRegistro.set(Calendar.SECOND,0);
				fechaRegistro.set(Calendar.MILLISECOND, 0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				throw new Exception("No fue posible grabar la informaci&oacute;n diaria.");
			}
			
			T17Ticam t17Param = new T17Ticam();
			TipoCambio tcParam = new TipoCambio();

	        //comunes informix
	        t17Param.setT17fCambio(fechaRegistro.getTime());//t17f_cambio
	        t17Param.setT17codMoneda(hdnRegTipoMoneda);//t17cod_moneda
	        
			//auditoria informix
	        t17Param.setT17fActualiz(hoy);//t17f_actualiz
	        t17Param.setT17hActualiz(sdf2.format(hoy));//t17h_actualiz
	        t17Param.setT17codUsuari(userRegistro);//t17cod_usuari
	        t17Param.setT17codTermin("web");//t17cod_terminal
	        t17Param.setT17programa(MODULO);//t17programa

	        boolean errorDatosNegocio = false;
	        
	        precioCompra = new BigDecimal(0.0);
	        try {
	        	precioCompra = new BigDecimal(txtRegPrecioCompra);
	        }
	        catch (Exception e) {
	        	log.debug("error", e);
	        	errorDatosNegocio = true;
	        }

	        precioVenta = new BigDecimal(0.0);
	        try {
	        	precioVenta = new BigDecimal(txtRegPrecioVenta);
	        }
	        catch (Exception e) {
	        	log.debug("error", e);
	        	errorDatosNegocio = true;
	        }

			fechaPublicacion = Calendar.getInstance();
			try {
				fechaPublicacion.setTime(sdf.parse(txtRegFechaPublicacion));
				fechaPublicacion.set(Calendar.HOUR_OF_DAY, 0);
				fechaPublicacion.set(Calendar.MINUTE, 0);
				fechaPublicacion.set(Calendar.SECOND,0);
				fechaPublicacion.set(Calendar.MILLISECOND, 0);				
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha", e);
	        	errorDatosNegocio = true;
			}

			fechaCierre = Calendar.getInstance();
			try {
				fechaCierre.setTime(sdf.parse(txtRegFechaCierre));
				fechaCierre.set(Calendar.HOUR_OF_DAY, 0);
				fechaCierre.set(Calendar.MINUTE, 0);
				fechaCierre.set(Calendar.SECOND,0);
				fechaCierre.set(Calendar.MILLISECOND, 0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha", e);
	        	errorDatosNegocio = true;
			}
			
			//comunes oracle
	        tcParam.setFechCambTip(fechaRegistro.getTime());//FECH_CAMB_TIP
	        tcParam.setSimbMoneMon(hdnRegSimbMoneda);//SIMB_MONE_MON
	        tcParam.setValoDolaTip(new BigDecimal(1));//VALO_DOLA_TIP
			
			//auditoria oracle
	        tcParam.setUserModi(userRegistro);//USER_MODI
	        tcParam.setFechModi(hoy);//FECH_MODI
	        
	        boolean existeSiga = false;
	        Calendar fechaRegistroDesde, fechaRegistroHasta;
	        
	        fechaRegistroDesde = Calendar.getInstance();
	        fechaRegistroDesde.setTime(fechaRegistro.getTime());
			fechaRegistroDesde.set(Calendar.HOUR_OF_DAY, 0);
			fechaRegistroDesde.set(Calendar.MINUTE, 0);
			fechaRegistroDesde.set(Calendar.SECOND,0);
			fechaRegistroDesde.set(Calendar.MILLISECOND, 0);
	        
	        fechaRegistroHasta = Calendar.getInstance();
	        fechaRegistroHasta.setTime(fechaRegistro.getTime());
			fechaRegistroHasta.set(Calendar.HOUR_OF_DAY, 23);
			fechaRegistroHasta.set(Calendar.MINUTE, 59);
			fechaRegistroHasta.set(Calendar.SECOND,59);
			fechaRegistroHasta.set(Calendar.MILLISECOND, 999);
	        
	        tcParam.setFechCambTipDesde(fechaRegistroDesde.getTime());
	        tcParam.setFechCambTipHasta(fechaRegistroHasta.getTime());
	        //tcParam.setFechCambTipDesdeString(formato.formateaFecha(fechaRegistroDesde.getTime(), "yyyyMMdd"));
	        //tcParam.setFechCambTipHastaString(formato.formateaFecha(fechaRegistroHasta.getTime(), "yyyyMMdd"));
	        
	        List<TipoCambio> tipoCambioSigaList = gestionTipoCambioService.recuperarListaTipoCambioSiga(tcParam);
	        log.debug("valores para validar existeSiga: " + existeSiga + " " + tipoCambioSigaList);
	        if (tipoCambioSigaList.size() > 0) {
	        	existeSiga = true;
	        }
	        
	        
			if (ACCION_DELETE.equals(hdnRegAccion)) {
				
				gestionTipoCambioService.eliminarTipoCambioPf(t17Param);
				if (validarSiga) {
					gestionTipoCambioService.eliminarTipoCambioSiga(tcParam);					
				}
			}
			else if (ACCION_UPDATE.equals(hdnRegAccion)) {
				
				if (errorDatosNegocio) {
					throw new Exception("error en los datos de negocio");
				}

				tcParam.setValoSoleTip(precioVenta);
				tcParam.setSoleCompTip(precioCompra);
				tcParam.setFechaCierre(fechaCierre.getTime());
				tcParam.setFechaPublicacion(fechaPublicacion.getTime());

				t17Param.setT17iCambvent(precioVenta);
				t17Param.setT17iCambcomp(precioCompra);
				t17Param.setT17fCierre(fechaCierre.getTime());
				t17Param.setT17fPublicac(fechaPublicacion.getTime());
				
				this.gestionTipoCambioService.actualizarTipoCambioPf(t17Param);
		        if (existeSiga) {
					if (validarSiga) {
						gestionTipoCambioService.actualizarTipoCambioSiga(tcParam);
					}
		        }
		        else {
					if (validarSiga) {
						gestionTipoCambioService.registrarTipoCambioSiga(tcParam);
					}
		        }
			}
			else if (ACCION_INSERT.equals(hdnRegAccion)) {

				tcParam.setValoSoleTip(precioVenta);
				tcParam.setSoleCompTip(precioCompra);
				tcParam.setFechaCierre(fechaCierre.getTime());
				tcParam.setFechaPublicacion(fechaPublicacion.getTime());

				t17Param.setT17iCambvent(precioVenta);
				t17Param.setT17iCambcomp(precioCompra);
				t17Param.setT17fCierre(fechaCierre.getTime());
				t17Param.setT17fPublicac(fechaPublicacion.getTime());
				
				if (errorDatosNegocio) {
					throw new Exception("error en los datos de negocio");
				}
				
				tcParam.setUserCrea(userRegistro);//USER_CREA
		        tcParam.setFechCrea(hoy);//FECH_CREA
		        
		        this.gestionTipoCambioService.registrarTipoCambioPf(t17Param);
		        if (existeSiga) {
					if (validarSiga) {
						gestionTipoCambioService.actualizarTipoCambioSiga(tcParam);
					}
		        }
		        else {
					if (validarSiga) {
						gestionTipoCambioService.registrarTipoCambioSiga(tcParam);
					}
		        }
			}
			
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarTipoCambio");
		}
		
		return modelAndView;
	}
	
	public ModelAndView validarAutorizacionTipoCambio(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo validarAutorizacionTipoCambio");
			
			FormatoUtil formato = new FormatoUtil();
			
			String txtAutUser = request.getParameter("txtAutUser");
			String txtAutPassword = request.getParameter("txtAutPassword");
			String hdnRegSimbMoneda = request.getParameter("hdnRegSimbMoneda");
			
			log.debug("campos de autorizacion enviados: " + txtAutUser + " " + txtAutPassword + " " + hdnRegSimbMoneda);

			boolean validarSiga = gestionTipoCambioService.validarGrabarSiga(hdnRegSimbMoneda);
			
			Map<String, Object> resultado = gestionTipoCambioService.validarAutorizador(txtAutUser, txtAutPassword);
			log.debug("resultado de la autorizacion: " + resultado);
			
	    	//resultado.put("mensaje", mensaje);
	    	//resultado.put("validado", validado);
	    	//reesultado.put("ldapUser", userMap);

			if (resultado != null && resultado.get("validado") != null && ((Boolean)resultado.get("validado")).booleanValue() == true) {
				Map<?, ?> ldapUser = (Map<?, ?>)resultado.get("ldapUser");
				autorizarTipoCambio(request, response, ldapUser, validarSiga);
			}
			else {
				String mensaje = "";
				if (resultado != null) {
					mensaje = (String)resultado.get("mensaje");
				}
				
				if (mensaje != null && !"".equals(mensaje.trim())) {
					throw new ServiceException(mensaje);
				}
				else {
					throw new ServiceException("Problemas al validar el usuario de intranet");
				}

			}
			
			respuesta.putAll(resultado);
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarTipoCambio");
		}
		
		return modelAndView;
	}

	
	
	private void autorizarTipoCambio(HttpServletRequest request, HttpServletResponse response, Map<?, ?> ldapUser, boolean validarSiga) throws ServiceException {
		
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		String registroAutorizador = (String)ldapUser.get("codreg");
		
		try {
			Date fecha = new Date();
			
			L9850Tipocambio l9850 = new L9850Tipocambio();
			
			l9850.setNomTabAud("TIPO_CAMBIO");
			l9850.setCodUsuReg(registroAutorizador);
			l9850.setCodAccAud(ACCION_AUTH);
			l9850.setFecRegAud(fecha);
			//l9850.setValAntTab("");
			//l9850.setValNueTab("");
			
			l9850.setFecRegis(fecha);
			l9850.setCodUsuregis(usuarioBean.getNroRegistro());
			l9850.setDirIpusuregis(request.getRemoteAddr());
			l9850.setFecModif(fecha);
			l9850.setCodUsumodif(usuarioBean.getNroRegistro());
			l9850.setDirIpusumodif(request.getRemoteAddr());

			if (validarSiga) {
				gestionTipoCambioService.registrarAuditoriaOracle(l9850);
			}
			
			L9851Ticam l9851 = new L9851Ticam();

			l9851.setNomTabAud("T17TICAM");
			l9851.setCodUsuReg(registroAutorizador);
			l9851.setCodAccAud(ACCION_AUTH);
			l9851.setFecRegAud(fecha);
			//l9851.setValAntTab("");
			//l9851.setValNueTab("");
			
			l9851.setFecRegis(fecha);
			l9851.setCodUsuregis(usuarioBean.getNroRegistro());
			l9851.setDirIpusuregis(request.getRemoteAddr());
			l9851.setFecModif(fecha);
			l9851.setCodUsumodif(usuarioBean.getNroRegistro());
			l9851.setDirIpusumodif(request.getRemoteAddr());

			gestionTipoCambioService.registrarAuditoriaInformix(l9851);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			throw new ServiceException(e.getMessage());
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarTipoCambio");
		}
	}
	
	public String getJsonView() {
		return jsonView;
	}

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public JsonSerializer getJsonSerializer() {
		return jsonSerializer;
	}

	public void setJsonSerializer(JsonSerializer jsonSerializer) {
		this.jsonSerializer = jsonSerializer;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public GestionTipoCambioService getGestionTipoCambioService() {
		return gestionTipoCambioService;
	}

	public void setGestionTipoCambioService(
			GestionTipoCambioService gestionTipoCambioService) {
		this.gestionTipoCambioService = gestionTipoCambioService;
	}
}