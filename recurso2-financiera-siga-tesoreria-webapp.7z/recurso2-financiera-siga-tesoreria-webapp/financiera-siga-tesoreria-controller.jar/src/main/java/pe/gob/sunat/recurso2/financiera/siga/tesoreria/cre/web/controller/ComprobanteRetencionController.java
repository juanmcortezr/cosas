package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.web.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.archivo.model.bean.RegistroArchivosFisicoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.FirmaDatapowerUtil;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.FirmaServicioUtil;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.RetencionConstantes;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.ServiceException;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.TransformacionEsquemasUtil;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.model.jaxb.retention.RetentionType;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.model.jaxb.reversion.VoidedDocumentsType;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper.Response;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper.SunatGEMServiceWrapper;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper.UsuarioSol;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.Cheque;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.ComprobanteRetencion;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.ComprobanteRetencionDocument;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.Persona;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.service.ComprobanteRetencionService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

public class ComprobanteRetencionController extends MultiActionController {

	static {
    	try {
    	    Class.forName("org.apache.cxf.jaxws.JaxWsProxyFactoryBean");
    	}
    	catch(Exception e) {
    	}
	}

	
	private String jsonView;
	private JsonSerializer jsonSerializer;
	
	private RegistroGeneralService registroGeneralService;
	private RegistroArchivosService registroArchivosService;
	private ComprobanteRetencionService comprobanteRetencionService;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	//#numRegiCab#,#codiContCco#,#numItem#,#numeroEntrega#,#tipo#
	//recuperarDocumentoPdfFirmado(BigDecimal codDocaut)
	
	/**
     * Carga la Pagina de Retencion
     * @param HttpServletRequest request
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */  
	public ModelAndView iniciarAplicacion(HttpServletRequest request, HttpServletResponse response) {
		
		log.debug("debug Inicio - ComprobanteRetencionController.iniciarRetencion");
		
		ModelAndView modelAndView;
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		String pagina = "";
		String errorMessage = "";
		String opcion = request.getParameter("opcion");

		/*try {
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        dbf.setNamespaceAware(true);
	        Document doc = dbf.newDocumentBuilder().newDocument();
			
			XmlSchemaCollection collection = new XmlSchemaCollection();
			collection.read(doc, "id");			
		}
		catch (Exception e){
			log.error("ERROR CATASTROFICO", e);
		}*/
		
		try {
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			//AND esta_comp_ret in (select T.COD_ARGUMENTO from t01parametro t where T.COD_PARAMETRO ='3335' AND T.DESC_CORTA= (%cod_estadO%))
			//AND nvl (CR.TIPO_ORIGEN,'GIRO') = DE ACUERDO al valor del filtro (  select T.DESC_CORTA from t01parametro t where T.COD_PARAMETRO ='3333')
			
			List<T01ParametroBean> listaEstados;
			listaEstados = new ArrayList<T01ParametroBean>();
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cod_par", "3332");
			params.put("cod_mod", "SIGA");
			params.put("cod_tipo", "D");
			
			listaEstados = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			if ("R".equals(opcion)) {
				for (int i = listaEstados.size() - 1; i >= 0; i--) {
					T01ParametroBean estado = listaEstados.get(i);
					if ("0".equals(estado.getNom_corto())) {
						listaEstados.remove(i);
					}
				}
			}
			
			List<T01ParametroBean> listaOrigen;
			listaOrigen = new ArrayList<T01ParametroBean>();
			
			params = new HashMap<String, Object>();
			params.put("cod_par", "3333");
			params.put("cod_mod", "SIGA");
			params.put("cod_tipo", "D");
			
			listaOrigen = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			
			String numeroRegistro = usuarioBean.getNroRegistro().toUpperCase();
			
			if (log.isDebugEnabled())log.debug("getApeMaterno:"		+usuarioBean.getApeMaterno());
			if (log.isDebugEnabled())log.debug("getApePaterno:"		+usuarioBean.getApePaterno());
			if (log.isDebugEnabled())log.debug("getCodDepend:"		+usuarioBean.getCodDepend());
			if (log.isDebugEnabled())log.debug("getCodUO:"			+usuarioBean.getCodUO());
			if (log.isDebugEnabled())log.debug("getCorreo:"			+usuarioBean.getCorreo());
			if (log.isDebugEnabled())log.debug("getLogin:"			+usuarioBean.getLogin());
			if (log.isDebugEnabled())log.debug("getNombreCompleto:"	+usuarioBean.getNombreCompleto());
			if (log.isDebugEnabled())log.debug("getNombres:"		+usuarioBean.getNombres());
			if (log.isDebugEnabled())log.debug("getNroRegistro:"	+usuarioBean.getNroRegistro());
			if (log.isDebugEnabled())log.debug("getTicket:"			+usuarioBean.getTicket());
			
			Persona sunat = comprobanteRetencionService.obtenerDatosSunat();
			String rucSunat = sunat.getRuc_persona();
			
			respuesta.put("listaEstados", listaEstados);
			respuesta.put("listaEstadosString", jsonSerializer.serialize(listaEstados));
			respuesta.put("listaOrigen", listaOrigen);
			respuesta.put("listaOrigenString", jsonSerializer.serialize(listaOrigen));
			respuesta.put("userRegistro", numeroRegistro);
			//respuesta.put("serieRetencion", serieRetencion);
			respuesta.put("rucSunat", rucSunat);
			
			if ("R".equals(opcion)) {
				pagina = "paginaComprobanteRetencion";
			}
			else if ("C".equals(opcion)){
				pagina = "paginaConsultaRetencion";
			}
			else {
				throw new Exception("No ha sido seleccionada la opcion");
			}
		}
		catch(Exception e){
			log.error(e.getMessage(), e);
			pagina = "paginaErrorSistema";
			errorMessage = "A ocurrido un inconveniente por favor comuniquese con el Administrador." + e.getMessage();
		}
		finally{
			respuesta.put("mensajeError", errorMessage);
			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(pagina,respuesta);
			log.debug("Fin ComprobanteRetencionController.iniciarConsulta");
		}
		
		return modelAndView;
	}
	
	public ModelAndView consultarProveedorPorRuc(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {
		
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo consultarProveedorPorRuc");
			String ruc = request.getParameter("ruc");
			
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("num_ruc", ruc);
			//param.put("tipod_doc", "04");// SOLO PERSONAS CON RUC
			param.put("tiene_ruc", true);
			
			List<Persona> listaProveedores = comprobanteRetencionService.recuperarPersonas(param);
			Persona persona = new Persona();
			if (!listaProveedores.isEmpty()) {
				persona = listaProveedores.get(0);
			}
			
			respuesta.put("listaProveedores", listaProveedores);
			respuesta.put("persona", persona);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo consultarProveedorPorRuc");
		}
		
		return modelAndView;
	}
	
	public ModelAndView consultarProveedorPorRazonSocial(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {

		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo consultarProveedorPorRazonSocial");
			
			String razonSocial = StringUtils.trimToEmpty(request.getParameter("razonSocial")).toUpperCase();
			log.debug("razon social enviada a la consulta: " + razonSocial);
			
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("nombre_razon_social", razonSocial);
			//param.put("tipod_doc", "04");// SOLO PERSONAS CON RUC
			param.put("tiene_ruc", true);			
			
			List<Persona> listaProveedores = comprobanteRetencionService.recuperarPersonas(param);			
			respuesta.put("listaProveedores", listaProveedores);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo consultarProveedorPorRazonSocial");
		}
		
		return modelAndView;
	}
	
	private List<ComprobanteRetencion> consultarComprobantesRetencion(HttpServletRequest request, HttpServletResponse response) 
			throws ServiceException {
		
		try {
			//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat sdf2 = new SimpleDateFormat("MMyyyy");
			FormatoUtil formato = new FormatoUtil();
			
			String ruc = formato.vacioANulo(request.getParameter("txtRuc"));
			//String txtRazonSocial = StringUtils.trimToEmpty(request.getParameter("razonSocial"));
			
			String selModulo = request.getParameter("selModulo");
			if (selModulo != null)
				selModulo = selModulo.trim();
			String selEstado = request.getParameter("selEstado");
			if (selEstado != null)
				selEstado = selEstado.trim();
			
			String txtFechaDesde = request.getParameter("txtFechaDesde");
			String txtFechaHasta = request.getParameter("txtFechaHasta");
			
			String selAnio = request.getParameter("selAnio");
			String selMes = request.getParameter("selMes");
			
			//<input type="radio" id="radio1" value="radio1" name="optradio">
			//<input type="radio" id="radio2" value="radio2"  name="optradio">
			
			log.debug("Modulo y estado: " + selModulo + " " + selEstado);
			
			if ("T".equals(selModulo)) {
				selModulo = null;
			}
			
			if ("1".equals(selModulo)) {
				selModulo = "GIRO";
			}
			else if ("2".equals(selModulo)) {
				selModulo = "CCH";
			}
			
			if ("T".equals(selEstado)) {
				selEstado = null;
			}
			
			log.debug("fechas enviadas: " + txtFechaDesde + " " + txtFechaHasta);
			
			Date fechaDesde = null;
			try {
				fechaDesde = sdf.parse(txtFechaDesde);
				fechaDesde.setHours(0);
				fechaDesde.setMinutes(0);
				fechaDesde.setSeconds(0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				fechaDesde = null;
			}
			
			Date fechaHasta = null;
			try {
				fechaHasta = sdf.parse(txtFechaHasta);
				fechaHasta.setHours(23);
				fechaHasta.setMinutes(59);
				fechaHasta.setSeconds(59);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha de rango");
				fechaHasta = null;
			}
			
			if (fechaDesde == null || fechaHasta == null) {
				String periodo = selMes + selAnio;
				
				try {
					fechaDesde = sdf2.parse(periodo);
					fechaHasta = sdf2.parse(periodo);
					fechaHasta.setMonth(fechaHasta.getMonth() + 1);
					fechaHasta.setDate(fechaHasta.getDate() - 1);
				}
				catch (Exception e) {
					log.debug("error en conversion de fecha de periodo");
					fechaDesde = null;
					fechaHasta = null;
				}
			}
			
			ComprobanteRetencion param = new ComprobanteRetencion();
			param.setNrucProvRet(ruc);
			param.setTipoOrigen(selModulo);
			param.setCodEstado(selEstado);
			param.setFechaInicio(fechaDesde);
			param.setFechaFin(fechaHasta);
			
			List<ComprobanteRetencion> listaComprobantes = comprobanteRetencionService.recuperarListaComprobantesRetencion(param);
			
			for (ComprobanteRetencion comprobante : listaComprobantes) {
				
				//campos de la lista a mostrar
				comprobante.setFechaemisionDesc(formato.formateaFecha(comprobante.getFechaemision()));//"fechaemision" jdbcType="TIMESTAMP" />
				comprobante.setFechacomunicacionDesc(formato.formateaFecha(comprobante.getFechacomunicacion()));//"fechacomunicacion" jdbcType="TIMESTAMP" />
				comprobante.setNroretencion(formato.formateaCadena(comprobante.getNroretencion()));//"nroretencion" jdbcType="CHAR" />
				comprobante.setRuc(formato.formateaCadena(comprobante.getRuc()));//"ruc" jdbcType="CHAR" />
				comprobante.setRazonsocial(formato.formateaCadena(comprobante.getRazonsocial()));//"razonsocial" jdbcType="VARCHAR" />
				comprobante.setSiaf(formato.formateaCadena(comprobante.getSiaf()));//"siaf" jdbcType="CHAR" />
				comprobante.setOrigen(formato.formateaCadena(comprobante.getOrigen()));//"origen" jdbcType="VARCHAR" />
				comprobante.setCaja(formato.formateaCadena(comprobante.getCaja()));//"caja" jdbcType="VARCHAR" />
			    comprobante.setMtoretenidoDesc(formato.formateaDecimal(comprobante.getMtoretenido()));//"mtoretenido" jdbcType="DECIMAL" />
			    comprobante.setEstado(formato.formateaCadena(comprobante.getEstado()));//"estado" jdbcType="VARCHAR" />
			    comprobante.setEstadodeclaracion(formato.formateaCadena(comprobante.getEstadodeclaracion()));//"estadodeclaracion" jdbcType="CHAR" />
			    comprobante.setNrodeclaracion(formato.formateaCadena(comprobante.getNrodeclaracion()));//"nrodeclaracion" jdbcType="VARCHAR" />
			    comprobante.setDeclaraDesc(formato.formateaDecimal(comprobante.getDeclara()));//"declara" jdbcType="DECIMAL" />
			    comprobante.setCodDeclaracion(formato.formateaCadena(comprobante.getCodDeclaracion()));//"codDeclaracion" jdbcType="CHAR" />
			    comprobante.setSecuCompCop(formato.formateaCadena(comprobante.getSecuCompCop()));//"secuCompCop" jdbcType="CHAR" />
				comprobante.setFechadeclaracionDesc(formato.formateaFecha(comprobante.getFechadeclaracion()));//"fechadeclaracion" jdbcType="TIMESTAMP" />
				comprobante.setFechadescargaDesc(formato.formateaFecha(comprobante.getFechadescarga()));//"fechadescarga" jdbcType="TIMESTAMP" />
				comprobante.setFechareversionDesc(formato.formateaFecha(comprobante.getFechareversion()));//"fechareversion" jdbcType="TIMESTAMP" />

				comprobante.setNumeRegiArc(formato.formateaCadena(comprobante.getNumeRegiArc()));
			    comprobante.setEstadodeclaraciondesc(formato.formateaCadena(comprobante.getEstadodeclaraciondesc()));//"estadodeclaraciondesc" jdbcType="CHAR" />
			}
			
			return listaComprobantes;
		}
		catch (Exception e) {
			log.error("Error" , e);
			throw new ServiceException (e);
		}
	}
	
	/** 
     * Recuperar expedientes virtuales 
     * @param HttpServletRequest request 
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */ 
	public ModelAndView recuperarComprobantesRetencion(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarComprobantesRetencion");
			
			List<ComprobanteRetencion> listaComprobantes = this.consultarComprobantesRetencion(request, response);
			respuesta.put("listaComprobantes", listaComprobantes);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarComprobantesRetencion");
		}
		
		return modelAndView;
	}
	
	
	public ModelAndView exportarComprobantesRetencion(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		String paginaOrigen = request.getParameter("paginaOrigen");
		
		try {
			List<ComprobanteRetencion> listaComprobantes = this.consultarComprobantesRetencion(request, response);
			
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			String fechaFormateada = sdf.format(new Date());
			
			// 2. Proceso las solicitudes para su exportacion a excel:
			HSSFWorkbook libroXLS/* = null*/;
			HSSFSheet hojaXLS/* = null*/;
			HSSFRow filaXLS/* = null*/;
			HSSFCell celdaXLS/* = null*/;
			
			HSSFCellStyle estiloTit/* = null*/;
			HSSFFont fuenteTit/* = null*/;
			
			HSSFCellStyle estiloDat/* = null*/;
			HSSFFont fuenteDat/* = null*/;
			
			HSSFCellStyle estiloDatIzq/* = null*/;
			HSSFFont fuenteDatIzq/* = null*/;
			
			libroXLS = new HSSFWorkbook();
			
			fuenteTit = libroXLS.createFont();
			fuenteTit.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // En negrita
			fuenteTit.setFontHeight((short) 160);
			fuenteTit.setFontName("Arial");
			
			fuenteDat = libroXLS.createFont();
			fuenteDat.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDat.setFontHeight((short) 160);
			fuenteDat.setFontName("Arial");
			
			fuenteDatIzq = libroXLS.createFont();
			fuenteDatIzq.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDatIzq.setFontHeight((short) 160);
			fuenteDatIzq.setFontName("Arial");
			
			estiloTit = libroXLS.createCellStyle();
			estiloTit.setFont(fuenteTit);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setAlignment(HSSFCellStyle.ALIGN_CENTER);

			estiloDat = libroXLS.createCellStyle();
			estiloDat.setFont(fuenteDat);
			estiloDat.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDat.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			estiloDatIzq = libroXLS.createCellStyle();
			estiloDatIzq.setFont(fuenteDat);
			estiloDatIzq.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			
			String nombreArchivo = "expedientes_" + fechaFormateada + ".xls";
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/vnd.ms-excel");

			// Ahora procesamos el reporte en
			hojaXLS = libroXLS.createSheet("Firmas");

			filaXLS = hojaXLS.createRow((short) 1);
			
			String[] columnas;
			
			String[] columnasConsulta = {
			 "Fecha Emisi\u00f3n", "Fecha de Comunicaci\u00f3n", "Nro. Retenci\u00f3n", "RUC",
			 "Raz\u00f3n Social", "SIAF", "M\u00f3dulo Origen", "Caja",
			 "Monto Retenido", "Estado SIGA", "Estado Declaraci\u00f3n", "Nro. Declaraci\u00f3n",
			 "Fecha Declaraci\u00f3n", "Fecha Desc. Prov.", "Fecha Reversi\u00f3n"
			};

			String[] columnasDeclaracion = {
			 "Fecha Emisi\u00f3n", "Fecha de Comunicaci\u00f3n", "Nro. Retenci\u00f3n", "RUC",
			 "Raz\u00f3n Social", "SIAF", "M\u00f3dulo Origen", "Caja",
			 "Monto Retenido", "Estado SIGA", "Estado Declaraci\u00f3n", "Nro. Declaraci\u00f3n",
			 "Fecha Declaraci\u00f3n", "Fecha Desc. Prov."
			};

			
			if ("C".equals(paginaOrigen)) {
				columnas = columnasConsulta;
			}
			else {
				columnas = columnasDeclaracion;
			}
			
			int z = 0;
			for (String columna : columnas) {
				celdaXLS = filaXLS.createCell(++z);
				celdaXLS.setCellStyle(estiloTit);
				celdaXLS.setCellValue(columna);
				hojaXLS.setColumnWidth(z, ((columna.length() + 10)* 512));
			}

			int i = 1;// numero de la fila desde la cual se itera...
			
			for (ComprobanteRetencion comprobante : listaComprobantes) {
				filaXLS = hojaXLS.createRow(++i);
				z = 0;
				
				if (i <= 65000) { //por limitaciones de xls clasico
					//i++;
				
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getFechaemisionDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getFechacomunicacionDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getNroretencion());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getRuc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getRazonsocial());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getSiaf());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getOrigen());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getCaja());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getMtoretenidoDesc());
				    comprobante.getMtoretenido();
				    
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getEstado());
				    
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getEstadodeclaraciondesc());
				    
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getNrodeclaracion());
				    
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getFechadeclaracionDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(comprobante.getFechadescargaDesc());
					
					if ("C".equals(paginaOrigen)) {
						celdaXLS = filaXLS.createCell(++z);
						celdaXLS.setCellStyle(estiloDat);
						celdaXLS.setCellValue(comprobante.getFechareversionDesc());
					}
				}
			}
			
			libroXLS.write(response.getOutputStream());
			response.getOutputStream().close();
			response.getOutputStream().flush();
			
			return modelAndView;
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
	}
	
	
	public ModelAndView descargarArchivo(HttpServletRequest request, HttpServletResponse response) throws ServiceException {

		ModelAndView modelAndView = null;
		
		if (log.isDebugEnabled()) {log.debug("debug Inicio - RegistroArchivosController.descargarArchivo");}
		Map<String, Object> params = new HashMap<String, Object>();
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		try {
			String numeRegiArc 	= StringUtils.trim(request.getParameter("numeRegiArc"));
			long secuRegiArc = 0;
			boolean existeArchivo = false;
						
			log.debug("num_reg: " + numeRegiArc);
			params.put("num_reg", numeRegiArc);
			List<Map<String, Object>> archivos = (List<Map<String, Object>>)registroArchivosService.listarArchivos(params);
			
			byte[] bytes = new byte[1024];
			String nombre = "";
			
			log.debug("archivos: " + archivos);
			if (archivos.size() > 0) {
				try {
					log.debug("sec_reg de archivos: " + archivos.get(0).get("sec_reg") + " " + archivos.get(0).get("sec_reg").getClass().getName());
					secuRegiArc = (Long)archivos.get(0).get("sec_reg");
				}
				catch (Exception e) {
					log.debug("error de conversion", e);
					secuRegiArc = 0l;
				}
				log.debug("sec_reg: " + secuRegiArc);
				params.put("sec_reg", secuRegiArc);
				
				if (secuRegiArc > 0) {
					RegistroArchivosFisicoBean archivo = registroArchivosService.recuperarArchivo(params);
					if (archivo != null) {
						bytes = archivo.getData();
						nombre = archivo.getFile_name();
						existeArchivo = true;
					}
				}
			}
			
			if (existeArchivo) {
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment;filename="+nombre);
				
				OutputStream os = response.getOutputStream();
				
				os.write(bytes);
				
				os.flush();
				os.close();
			}
			
			return modelAndView;
		}
		catch(Exception ex){
			log.error("Error en RegistroArchivosController.descargarArchivo: " + ex.getMessage(), ex);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + ex.getMessage());
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
		finally{
			if (log.isDebugEnabled()){ log.debug("Fin - RegistroArchivosController.descargarArchivo");}
		}
	}
	
	
	private List<ComprobanteRetencionDocument> consultarDocumentos(HttpServletRequest request, HttpServletResponse response) 
			throws ServiceException {
		
		try {
			//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			FormatoUtil formato = new FormatoUtil();
			
			String secuCompRet = formato.formateaCadena(request.getParameter("secuCompRet"));
			
			ComprobanteRetencionDocument param = new ComprobanteRetencionDocument();
			param.setSecuCompRet(secuCompRet);
			
			List<ComprobanteRetencionDocument> listaDocumentos = comprobanteRetencionService.recuperarListaDocumentos(param);
			
			for (ComprobanteRetencionDocument doc : listaDocumentos) {
				
				doc.setDocumento(formato.formateaCadena(doc.getDocumento()));//<result column="DOCUMENTO" property="documento" jdbcType="VARCHAR" />
				doc.setSerienumero(formato.formateaCadena(doc.getSerienumero()));//<result column="SERIENUMERO" property="serienumero" jdbcType="VARCHAR" />
				doc.setFechaemisionDesc(formato.formateaFecha(doc.getFechaemision()));//<result column="FECHAEMISION" property="fechaemision" jdbcType="TIMESTAMP" />
				doc.setMtosolesDesc(formato.formateaDecimal(doc.getMtosoles()));//<result column="MTOSOLES" property="mtosoles" jdbcType="DECIMAL" />
				doc.setMtodolarDesc(formato.formateaDecimal(doc.getMtodolar()));//<result column="MTODOLAR" property="mtodolar" jdbcType="DECIMAL" />
				doc.setMtoretencionDesc(formato.formateaDecimal(doc.getMtoretencion()));//<result column="MTORETENCION" property="mtoretencion" jdbcType="DECIMAL" />
			}
			
			return listaDocumentos;
		}
		catch (Exception e) {
			log.error("Error" , e);
			throw new ServiceException (e);
		}
	}
	
	public ModelAndView recuperarDocumentos(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {

		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			FormatoUtil formato = new FormatoUtil();
			
			log.debug(getClass().getName() + " Inicio del metodo recuperarComprobantes");
			
			List<?> listaDocumentos = this.consultarDocumentos(request, response);
			respuesta.put("listaDocumentos", listaDocumentos);
			
			String secuCompRet = formato.formateaCadena(request.getParameter("secuCompRet"));
			Cheque param = new Cheque();
			param.setSecuCompCop(secuCompRet);
			
			Date fechaPago = this.comprobanteRetencionService.recuperarFechaPago(param);
			String fechaPagoFormateada = formato.formateaFecha(fechaPago);
			respuesta.put("fechaPago", fechaPagoFormateada);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDetalleExpedientes");
		}
		
		return modelAndView;
	}
	
	public ModelAndView exportarDocumentos(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		
		Map <String, Object> respuesta = new HashMap<String, Object>();		
		
		try {
			List<ComprobanteRetencionDocument> listaDocumentos = this.consultarDocumentos(request, response);
			
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			String fechaFormateada = sdf.format(new Date());
			
			// 2. Proceso las solicitudes para su exportacion a excel:
			HSSFWorkbook libroXLS/* = null*/;
			HSSFSheet hojaXLS/* = null*/;
			HSSFRow filaXLS/* = null*/;
			HSSFCell celdaXLS/* = null*/;
			
			HSSFCellStyle estiloTit/* = null*/;
			HSSFFont fuenteTit/* = null*/;
			
			HSSFCellStyle estiloDat/* = null*/;
			HSSFFont fuenteDat/* = null*/;
			
			HSSFCellStyle estiloDatIzq/* = null*/;
			HSSFFont fuenteDatIzq/* = null*/;
			
			libroXLS = new HSSFWorkbook();
			
			fuenteTit = libroXLS.createFont();
			fuenteTit.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // En negrita
			fuenteTit.setFontHeight((short) 160);
			fuenteTit.setFontName("Arial");
			
			fuenteDat = libroXLS.createFont();
			fuenteDat.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDat.setFontHeight((short) 160);
			fuenteDat.setFontName("Arial");
			
			fuenteDatIzq = libroXLS.createFont();
			fuenteDatIzq.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDatIzq.setFontHeight((short) 160);
			fuenteDatIzq.setFontName("Arial");
			
			estiloTit = libroXLS.createCellStyle();
			estiloTit.setFont(fuenteTit);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setAlignment(HSSFCellStyle.ALIGN_CENTER);
	
			estiloDat = libroXLS.createCellStyle();
			estiloDat.setFont(fuenteDat);
			estiloDat.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDat.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			estiloDatIzq = libroXLS.createCellStyle();
			estiloDatIzq.setFont(fuenteDat);
			estiloDatIzq.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			
			String nombreArchivo = "comprobantes_" + fechaFormateada + ".xls";
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/vnd.ms-excel");
	
			// Ahora procesamos el reporte en
			hojaXLS = libroXLS.createSheet("Firmas");
	
			filaXLS = hojaXLS.createRow((short) 1);
			
			String[] columnas = 
			{"Documento", "Serie - Numero", "Fecha Emisi\u00f3n", "Mto Total Soles", "Mto Total Dorales", "Mto Retenci\u00f3n"};
			
			int z = 0;
			for (String columna : columnas) {
				celdaXLS = filaXLS.createCell(++z);
				celdaXLS.setCellStyle(estiloTit);
				celdaXLS.setCellValue(columna);
				hojaXLS.setColumnWidth(z, ((columna.length() + 10) * 512));
			}
	
			int i = 1;// numero de la fila desde la cual se itera...
	
			for (ComprobanteRetencionDocument doc : listaDocumentos) {
				filaXLS = hojaXLS.createRow(++i);
				z = 0;
				
				if (i <= 65000) { //por limitaciones de xls clasico
					//i++;
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(doc.getDocumento());
	
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(doc.getSerienumero());
	
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(doc.getFechaemisionDesc());
	
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(doc.getMtosolesDesc());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(doc.getMtodolarDesc());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(doc.getMtoretencionDesc());
				}
			}
			
			libroXLS.write(response.getOutputStream());
			response.getOutputStream().close();
			response.getOutputStream().flush();
			
			return modelAndView;
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
	}
	
	
	//<prop key="enviarMasivoComprobanteRetencion">enviarMasivoComprobanteRetencion</prop>
	//<prop key="cosultarReversionComprobanteRetencion">consultarReversionComprobanteRetencion</prop>
	
	public ModelAndView enviarComprobanteRetencion(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		log.debug(getClass().getName() + " Inicio del metodo recuperarDelegaciones");
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		TransformacionEsquemasUtil tran = new TransformacionEsquemasUtil();
		FirmaDatapowerUtil http = new FirmaDatapowerUtil();
		FirmaServicioUtil tg = new FirmaServicioUtil();
		FormatoUtil formato = new FormatoUtil();
		
		List<String> listaMensajes = new ArrayList<String>();
		String mensaje = "";
        Response respon;
		
		try {
		    String secuCompRet = request.getParameter("secuCompRet");
		    String nroRetencion = request.getParameter("nroRetencion");
		    String usuarioAutenticacion = request.getParameter("usuarioAutenticacion");
		    String passwordAutenticacion = request.getParameter("passwordAutenticacion");
		    
		    ComprobanteRetencion param = new ComprobanteRetencion();
		    param.setSecuCompRet(secuCompRet);
		    
		    // INICIO CARGADO Y PREPARADO
		    ComprobanteRetencion cRet = comprobanteRetencionService.recuerarDatosComprobanteRetencion(param);
			List<ComprobanteRetencionDocument> cRetDocList = cRet.getComprobanteRetencionDocumentList();
		    // FIN CARGADO Y PREPARADO
			
			// INICIO FIRMADO
			RetentionType ret = tran.llenarObjetoEsquemaRetention(recuperarCodigoCertificado(), cRet, cRetDocList);
			String cadenaRet = tran.recuperarCadenaRetencion(ret);
			log.info("CRE CON SIN FIRMA: " + cadenaRet);
			//String cadenaRetFirmado = http.sendPost(RetencionConstantes.IP_FIRMA_CRE_SUNAT + recuperarCodigoCertificado()/*RetencionConstantes.URI_FIRMA_CRE_SUNAT*/, cadenaRet);
			//String cadenaRetFirmado = tg.firmaDocumentoCadena(RetencionConstantes.URL_TECNOLOGIA_GENERADOR, cadenaRet, "RET", recuperarCodigoCertificado()/*RetencionConstantes.URI_FIRMA_CRE_SUNAT_TG*/);
			String cadenaRetFirmado = tg.firmaDocumentoCadenaRest(RetencionConstantes.URL_BUS_FIRMA_CRE_SUNAT , cadenaRet, "RET", recuperarCodigoCertificado()/*RetencionConstantes.URI_FIRMA_CRE_SUNAT_TG*/);
			log.info("CRE CON FIRMA: " + cadenaRetFirmado);
			
			String nombreArchivoZip = tran.recuperarNombreRetencion(cRet.getNrucDeclRet(), cRet.getNumeSeriRetDecl(), Long.parseLong(cRet.getNumeCompRetDecl()));
			String nombreArchivoXml = tran.recuperarNombreRetencion(cRet.getNrucDeclRet(), cRet.getNumeSeriRetDecl(), Long.parseLong(cRet.getNumeCompRetDecl()));
			//tran.recuperarZipFile(RetencionConstantes.RUTA_TEMPORAL_ZIP, nombreArchivoZip, nombreArchivoXml, cadenaRetFirmado);
			//byte[] bytes = tran.recuperarZipByteArray(nombreArchivo, cadenaRetFirmado);
			// FIN FIRMADO

			boolean resultadoRetencion = true;
			boolean advertencias = false;
			
			// INICIO WS ENVIO
			UsuarioSol usuarioSol = new UsuarioSol(cRet.getNrucDeclRet(), usuarioAutenticacion, passwordAutenticacion);
			SunatGEMServiceWrapper client = new SunatGEMServiceWrapper(usuarioSol, RetencionConstantes.URL_SERVICIO_ENVIO);

			String fileZipPath = RetencionConstantes.RUTA_TEMPORAL_ZIP + nombreArchivoZip;	
			String nombreArchivoConstancia = nombreArchivoZip + "-Constancia";
        	String constanciaZipFilePath = RetencionConstantes.RUTA_TEMPORAL_ZIP + nombreArchivoConstancia + ".XML";
			
	        try {
	        	
	        	tran.recuperarZipFile(RetencionConstantes.RUTA_TEMPORAL_ZIP, nombreArchivoZip, nombreArchivoXml, cadenaRetFirmado);
	            respon = client.sendBill(nombreArchivoZip + ".ZIP", fileZipPath + ".ZIP");
	        	//respon = client.sendBill("20520485750-20-R666-00000021" + ".ZIP", fileZipPath + ".ZIP");
	        	
	            log.debug("PrincipalFacturaElectronica.SendDocumentClass.actionPerformed() 2");
	            
	            if (respon.isError()) {
	            	mensaje += "Error de Servicio CRE - Codigo de Error : " + respon.getCodigo() + "\r\n";
	            	mensaje += "Mensaje de Error: " + respon.getMensaje() + "\r\n";
	            } else {
	            	mensaje += respon.getMensaje() + "\r\n";
	                if (respon.getWarnings() != null && respon.getWarnings().size() > 0) {
	                	mensaje += "Warnings: \r\n";
	                    for (String warning : respon.getWarnings()) {
	                    	mensaje += warning + "\r\n";
	                    }
	                }
	            }
	            
	            String strCodigo = "";
	            String strEstado = "";
	            byte data[] = null;
	            
	            if(respon.isError()){
	            	strCodigo = String.valueOf(respon.getCodigo());
	            	strEstado = "99 - Rechazado";
		        	resultadoRetencion = false;
		        	data = null;
	            }
	            
	            if(!respon.isError()&&respon.getWarnings().size()>0){
	            	strCodigo = String.valueOf(respon.getCodigo());
	            	strEstado = "0 - Aceptado con Observaciones";
		        	resultadoRetencion = true;
		        	advertencias = true;
		        	data = respon.getData();
	            }
	            
	            if(!respon.isError()&&respon.getWarnings().size()==0){
	            	strCodigo = String.valueOf(respon.getCodigo());
	            	strEstado = "0 - Aceptado";
		        	resultadoRetencion = true;
		        	advertencias = true;
		        	data = respon.getData();
	            }
	            
	            mensaje += strCodigo;
	            mensaje += strEstado;
	            
		        if(!respon.isError() && data != null) {
		        	
			       File constancia = new File(constanciaZipFilePath);
			       FileOutputStream fos = new FileOutputStream(constancia);
			       fos.write(data);

			       try {
				       fos.flush();
				       fos.close();				    	   
			       }
			       catch (Exception e) {
			    	   log.error("Error", e);
			       }
		        }
	            
	            log.info("PrincipalFacturaElectronica.SendDocumentClass.actionPerformed() 3");
	            
	        } catch (Exception e) {
	        	log.error("error", e);
	        	mensaje += "Error: " + e.getCause().getMessage() + "\r\n";
	        	resultadoRetencion = false;
	        }
	        
			// FIN WS ENVIO
								
			// INICIO GRABADO SIGA
			if (resultadoRetencion) {//depende del resultado del servicio
				param = new ComprobanteRetencion();
				param.setSecuCompRet(secuCompRet);
				
				Date fechaEnvio = new Date();
				fechaEnvio.setHours(0);
				fechaEnvio .setMinutes(0);
				fechaEnvio .setSeconds(0);
				param.setFecDeclaracion(fechaEnvio);
				
				param.setMsjDeclaracion(formato.trunca(mensaje, 500));
				param.setNumSeriedeclara(cRet.getNumeSeriRetDecl());
				param.setNumNumerodeclara(Integer.parseInt(cRet.getNumeCompRetDecl()));
				param.setIndDeclaracion(RetencionConstantes.ESTADO_DECLARACION_DECLARADO);

				String numeRegiArc = registrarArchivo(nroRetencion, RetencionConstantes.RUTA_TEMPORAL_ZIP, nombreArchivoConstancia +".XML");
				param.setNumeRegiArc(numeRegiArc);
				
				// auditoria
				param.setUserModi(usuarioBean.getLogin());
				param.setFechModi(new Date());
				
				comprobanteRetencionService.registrarComprobante(param);
				
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("cod_par", "3339");
				paramMap.put("cod_mod", "SIGA");
				paramMap.put("cod_tipo", "D");
				paramMap.put("cod_arg", RetencionConstantes.COD_EXISTE_CONSULTA_PROVEEDORES);
				T01ParametroBean t01parametro = registroGeneralService.recuperarParametro(paramMap);
				
				String existeConsultaProveedores = "0";
				if (t01parametro != null) {
					existeConsultaProveedores = t01parametro.getNom_largo();
				}
				
				
				paramMap = new HashMap<String, Object>();
				paramMap.put("num_ruc", cRet.getNrucProvRet());
				paramMap.put("tiene_ruc", true);
				
				List<Persona> listaProveedores = comprobanteRetencionService.recuperarPersonasJoinContratistas(paramMap);
				Persona persona = new Persona();
				if (!listaProveedores.isEmpty()) {
					persona = listaProveedores.get(0);
				}
				
				//(String ruc, String nombreRazon, String correo, String asunto, String contenido)
				String asunto = "CRE: Comprobante Retencion Declarado";
				String contenido = "<p>Estimado Usuario</p>"+ "<p>Se ha procedido a declarar el comprobante de retenci&oacute;n " + cRet.getNroretencion() + " con Nro. de Declaraci&oacute;n " + cRet.getNumeSeriRetDecl() + " - " + cRet.getNumeCompRetDecl() + "</p>";
				
				if ("1".equals(existeConsultaProveedores.trim())) {
					contenido = contenido + "<p>Puede ingresar en la consulta de \"Proveedores SUNAT\", ubicada en la Pagina Web de la SUNAT, para proceder a descargar el archivo en formato XML firmado digitalmente.</p>";
				}
				
				if (persona != null && persona.getDir_correopago() != null) {
					comprobanteRetencionService.enviarNotificacionRegistroComprobanteRetencion(cRet.getNrucProvRet(), cRet.getRazonSocial(), persona.getDir_correopago(), asunto, contenido);					
				}
				
				respuesta.put("nroRetencion", cRet.getNroretencion());
				respuesta.put("nroDeclaracion", cRet.getNumeSeriRetDecl() + " - " + cRet.getNumeCompRetDecl());

				if (!advertencias) {
					mensaje = "";
				}
				
				respuesta.put("resultadoEnvio", "1");
				respuesta.put("listaMensajes", listaMensajes.toArray());
				respuesta.put("mensaje", mensaje);				
			}
			else {
				param = new ComprobanteRetencion();
				param.setSecuCompRet(secuCompRet);
				param.setMsjDeclaracion(formato.trunca(mensaje, 500));

				comprobanteRetencionService.registrarComprobante(param);
				
				respuesta.put("resultadoEnvio", "0");
				respuesta.put("listaMensajes", listaMensajes.toArray());
				respuesta.put("mensaje",  mensaje);
			}
			// FIN GRABADO SIGA

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
				
			respuesta.put("error", "1");
			respuesta.put("mensaje", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDelegaciones");
		}
		
		return modelAndView;
	}
	
	public ModelAndView revertirComprobanteRetencion(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		log.debug(getClass().getName() + " Inicio del metodo recuperarDelegaciones");
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		TransformacionEsquemasUtil tran = new TransformacionEsquemasUtil();
		FirmaDatapowerUtil http = new FirmaDatapowerUtil();
		FirmaServicioUtil tg = new FirmaServicioUtil();
		FormatoUtil formato = new FormatoUtil();
		
		List<String> listaMensajes = new ArrayList<String>();
		String mensaje = "";
        Response respon;
		
		try {
		    String secuCompRet = request.getParameter("secuCompRet");
		    String nroRetencion = request.getParameter("nroRetencion");
		    String usuarioAutenticacion = request.getParameter("usuarioAutenticacion");
		    String passwordAutenticacion = request.getParameter("passwordAutenticacion");
		    
		    ComprobanteRetencion param = new ComprobanteRetencion();
		    param.setSecuCompRet(secuCompRet);
		    
		    //CARGADO Y PREPARADO
		    ComprobanteRetencion cRet = comprobanteRetencionService.recuerarDatosReversion(param);
			//List<ComprobanteRetencionDocument> cRetDocList = cRet.getComprobanteRetencionDocumentList();
		    //CARGADO Y PREPARADO

			Date fechaCompara = new Date();
			fechaCompara.setHours(0);
			fechaCompara.setMinutes(0);
			fechaCompara.setSeconds(0);
		    
			Integer numeroReversion = comprobanteRetencionService.recuperarNumeroRevertidosPorDia(fechaCompara) + 1;
		    
			//FIRMADO
			VoidedDocumentsType rev = tran.llenarObjetoEsquemaReversion(recuperarCodigoCertificado(), cRet, numeroReversion);
			String cadenaRev = tran.recuperarCadenaReversion(rev);
			log.info("CRE CON SIN FIRMA: " + cadenaRev);
			//String cadenaRevFirmado = http.sendPost(RetencionConstantes.IP_FIRMA_CRE_SUNAT + recuperarCodigoCertificado()/*RetencionConstantes.URI_FIRMA_CRE_SUNAT*/, cadenaRev);
			//String cadenaRevFirmado = tg.firmaDocumentoCadena(RetencionConstantes.URL_TECNOLOGIA_GENERADOR, cadenaRev, "REV", recuperarCodigoCertificado()/*RetencionConstantes.URI_FIRMA_CRE_SUNAT_TG*/);
			String cadenaRevFirmado = tg.firmaDocumentoCadenaRest(RetencionConstantes.URL_BUS_FIRMA_CRE_SUNAT , cadenaRev, "REV", recuperarCodigoCertificado()/*RetencionConstantes.URI_FIRMA_CRE_SUNAT_TG*/);
			log.info("CRE CON FIRMA: " + cadenaRevFirmado);
			
			String nombreArchivoZip = tran.recuperarNombreReversionZip(cRet.getNrucDeclRet(), new Date(), numeroReversion);
			String nombreArchivoXml = tran.recuperarNombreReversionXml(cRet.getNrucDeclRet(), new Date(), numeroReversion);
			//tran.recuperarZipFile(RetencionConstantes.RUTA_TEMPORAL_ZIP, nombreArchivoZip, nombreArchivoXml, cadenaRevFirmado);
			//FIRMADO
			
			String numReversion = " ";//DEVUELTO POR EL ENVIO
			boolean resultadoReversion = true;
			
			
			// INICIO WS REVERSION
			UsuarioSol usuarioSol = new UsuarioSol(cRet.getNrucDeclRet(), usuarioAutenticacion, passwordAutenticacion);
			SunatGEMServiceWrapper client = new SunatGEMServiceWrapper(usuarioSol, RetencionConstantes.URL_SERVICIO_ENVIO);
	       			
	        try {
	        	String fileZipPath = RetencionConstantes.RUTA_TEMPORAL_ZIP + nombreArchivoZip;
	        	tran.recuperarZipFile(RetencionConstantes.RUTA_TEMPORAL_ZIP, nombreArchivoZip, nombreArchivoXml, cadenaRevFirmado);
	            respon = client.sendSummary(nombreArchivoZip + ".ZIP", fileZipPath + ".ZIP");
	        	
	            log.debug("PrincipalFacturaElectronica.SendDocumentClass.actionPerformed() 2");
	            
	            if (respon.isError()) {
	            	mensaje += "Error de Servicio CRE - Codigo de Error : " + respon.getCodigo() + "\r\n";
	            	mensaje += "Mensaje de Error: " + respon.getMensaje() + "\r\n";
	            } else {
	            	mensaje += respon.getMensaje() + "\r\n";
	                if (respon.getWarnings() != null && respon.getWarnings().size() > 0) {
	                	mensaje += "Warnings: \r\n";
	                    for (String warning : respon.getWarnings()) {
	                    	mensaje += warning + "\r\n";
	                    }
	                }
	            }
	            
	            String strCodigo = "";
	            String strEstado = "";
	            if(respon.isError()){
	            	strCodigo = String.valueOf(respon.getCodigo());
	            	strEstado = "99 - Rechazado";
		        	resultadoReversion = false;
	            }
	            
	            if(!respon.isError()&&respon.getWarnings().size()>0){
	            	strCodigo = String.valueOf(respon.getCodigo());
	            	strEstado = "0 - Aceptado con Observaciones";
		        	resultadoReversion = true;
		        	numReversion = respon.getMensaje();//EXTRAER DEL MENSAJE EL NRO
	            }
	            
	            if(!respon.isError()&&respon.getWarnings().size()==0){
	            	strCodigo = String.valueOf(respon.getCodigo());
	            	strEstado = "0 - Aceptado";
		        	resultadoReversion = true;
		        	numReversion = respon.getMensaje();//EXTRAER DEL MENSAJE EL NRO
	            }
	            
	            mensaje += strCodigo;
	            mensaje += strEstado;
	            
	            log.info("PrincipalFacturaElectronica.SendDocumentClass.actionPerformed() 3");
	            
	        } catch (Exception e) {
	        	log.error("error", e);
	        	mensaje += "Error: " + e.getCause().getMessage() + "\r\n";
	        	resultadoReversion = false;
	        }
			// FIN WS REVERSION
			
			
			// INICIO GRABADO SIGA
			if (resultadoReversion) {//depende del resultado del servicio				
				param = new ComprobanteRetencion();
				param.setSecuCompRet(secuCompRet);

				Date fechaEnvio = new Date();
				fechaEnvio.setHours(0);
				fechaEnvio .setMinutes(0);
				fechaEnvio .setSeconds(0);
				param.setFecReversion(fechaEnvio);
				param.setNumReversion(numReversion);
				param.setIndDeclaracion(RetencionConstantes.ESTADO_DECLARACION_EN_REVERSION);
				
				// auditoria
				param.setUserModi(usuarioBean.getLogin());
				param.setFechModi(new Date());
				
				//ACTUALIZACION 
				comprobanteRetencionService.revertirComprobante(param);
				
				respuesta.put("nroRetencion", cRet.getNroretencion());
				respuesta.put("nroDeclaracion", cRet.getNumeSeriRetDecl() + " - " + cRet.getNumeCompRetDecl());
				
				respuesta.put("resultadoEnvio", "1");
				respuesta.put("listaMensajes", listaMensajes.toArray());
				respuesta.put("mensaje", "");
			}
			else {
				param = new ComprobanteRetencion();
				param.setSecuCompRet(secuCompRet);
				param.setMsjDeclaracion(formato.trunca(mensaje, 500));

				// auditoria
				param.setUserModi(usuarioBean.getLogin());
				param.setFechModi(new Date());				
				
				//ACTUALIZACION
				comprobanteRetencionService.revertirComprobante(param);
				
				respuesta.put("resultadoEnvio", "0");
				respuesta.put("listaMensajes", listaMensajes.toArray());
				respuesta.put("mensaje",  mensaje);
			}
			// FIN GRABADO SIGA

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
				
			respuesta.put("error", "1");
			respuesta.put("mensaje", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDelegaciones");
		}
		
		return modelAndView;
	}
	
	
	
	public ModelAndView envioDeclaracionCREmasiva(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		log.debug(getClass().getName() + " Inicio del metodo recuperarDelegaciones");
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		TransformacionEsquemasUtil tran = new TransformacionEsquemasUtil();
		FirmaDatapowerUtil http = new FirmaDatapowerUtil();
		FirmaServicioUtil tg = new FirmaServicioUtil();
		FormatoUtil formato = new FormatoUtil();
		
		List<String> listaMensajes = new ArrayList<String>();
		
		try {
		    String usuarioAutenticacion = request.getParameter("usuarioAutenticacion");
		    String passwordAutenticacion = request.getParameter("passwordAutenticacion");
		    
		    String declararMasivoListString = request.getParameter("declararMasivoList");
		    List<String> declararMasivoList = (List<String>)jsonSerializer.deserialize(declararMasivoListString, ArrayList.class.getClass());
		    log.debug("arreglo de seleccionados en multiple: " + declararMasivoListString + " " + declararMasivoList);
		    
		    for (String secuCompRet : declararMasivoList) {
		    	String mensaje = "";//MENSAJE DEL SERVICIO
		    	String nroRetencion = "";
		    	String nroDeclaracion = "";
		    	
			    //String secuCompRet = request.getParameter("secuCompRet");
		    	ComprobanteRetencion param = new ComprobanteRetencion();
			    param.setSecuCompRet(secuCompRet);
			    
			    // INICIO CARGADO Y PREPARADO
			    ComprobanteRetencion cRet = comprobanteRetencionService.recuerarDatosComprobanteRetencion(param);
				List<ComprobanteRetencionDocument> cRetDocList = cRet.getComprobanteRetencionDocumentList();
			    // FIN CARGADO Y PREPARADO
				
				nroRetencion = cRet.getNroretencion();
				nroDeclaracion = cRet.getNumeSeriRetDecl() + " - " + cRet.getNumeCompRetDecl();
				
				// INICIO FIRMADO
				RetentionType ret = tran.llenarObjetoEsquemaRetention(recuperarCodigoCertificado(), cRet, cRetDocList);
				String cadenaRet = tran.recuperarCadenaRetencion(ret);
				log.info("CRE CON SIN FIRMA: " + cadenaRet);
				//String cadenaRetFirmado = http.sendPost(RetencionConstantes.IP_FIRMA_CRE_SUNAT + recuperarCodigoCertificado()/*RetencionConstantes.URI_FIRMA_CRE_SUNAT*/, cadenaRet);
				//String cadenaRetFirmado = tg.firmaDocumentoCadena(RetencionConstantes.URL_TECNOLOGIA_GENERADOR, cadenaRet, "RET", recuperarCodigoCertificado()/*RetencionConstantes.URI_FIRMA_CRE_SUNAT_TG*/);
				String cadenaRetFirmado = tg.firmaDocumentoCadenaRest(RetencionConstantes.URL_BUS_FIRMA_CRE_SUNAT , cadenaRet, "RET", recuperarCodigoCertificado()/*RetencionConstantes.URI_FIRMA_CRE_SUNAT_TG*/);
				log.info("CRE CON FIRMA: " + cadenaRetFirmado);
				
				String nombreArchivoZip = tran.recuperarNombreRetencion(cRet.getNrucDeclRet(), cRet.getNumeSeriRetDecl(), Long.parseLong(cRet.getNumeCompRetDecl()));
				String nombreArchivoXml = tran.recuperarNombreRetencion(cRet.getNrucDeclRet(), cRet.getNumeSeriRetDecl(), Long.parseLong(cRet.getNumeCompRetDecl()));
				//tran.recuperarZipFile(RetencionConstantes.RUTA_TEMPORAL_ZIP, nombreArchivoZip, nombreArchivoXml, cadenaRetFirmado);
				// FIN FIRMADO
	
				boolean resultadoRetencion = true;
				boolean advertencias = false;
		    	String mensajeEnvio = "";//MENSAJE ARMADO
		    	Response respon;
		    	
		    	
				// INICIO WS ENVIO MASIVO
				UsuarioSol usuarioSol = new UsuarioSol(cRet.getNrucDeclRet(), usuarioAutenticacion, passwordAutenticacion);
				SunatGEMServiceWrapper client = new SunatGEMServiceWrapper(usuarioSol, RetencionConstantes.URL_SERVICIO_ENVIO);

	        	String fileZipPath = RetencionConstantes.RUTA_TEMPORAL_ZIP + nombreArchivoZip;
				String nombreArchivoConstancia = nombreArchivoZip + "-Constancia";
	        	String constanciaZipFilePath = RetencionConstantes.RUTA_TEMPORAL_ZIP + nombreArchivoConstancia + ".";
				
		        try {
		        	tran.recuperarZipFile(RetencionConstantes.RUTA_TEMPORAL_ZIP, nombreArchivoZip, nombreArchivoXml, cadenaRetFirmado);
		            respon = client.sendBill(nombreArchivoZip + ".ZIP", fileZipPath + ".ZIP");
		        	
		            log.debug("PrincipalFacturaElectronica.SendDocumentClass.actionPerformed() 2");
		            
		            if (respon.isError()) {
		            	mensajeEnvio += "Error de Servicio CRE - Codigo de Error : " + respon.getCodigo() + "\r\n";
		            	mensajeEnvio += "Mensaje de Error: " + respon.getMensaje() + "\r\n";
		            } else {
		            	mensajeEnvio += respon.getMensaje() + "\r\n";
		                if (respon.getWarnings() != null && respon.getWarnings().size() > 0) {
		                	mensajeEnvio += "Warnings: \r\n";
		                    for (String warning : respon.getWarnings()) {
		                    	mensajeEnvio += warning + "\r\n";
		                    }
		                }
		            }
		            
		            String strCodigo = "";
		            String strEstado = "";
		            byte data[] = null;
		            
		            if(respon.isError()){
		            	strCodigo = String.valueOf(respon.getCodigo());
		            	strEstado = "99 - Rechazado";
			        	resultadoRetencion = false;
			        	data = null;
		            }
		            
		            if(!respon.isError()&&respon.getWarnings().size()>0){
		            	strCodigo = String.valueOf(respon.getCodigo());
		            	strEstado = "0 - Aceptado con Observaciones";
			        	resultadoRetencion = true;
			        	data = respon.getData();
		            }
		            
		            if(!respon.isError()&&respon.getWarnings().size()==0){
		            	strCodigo = String.valueOf(respon.getCodigo());
		            	strEstado = "0 - Aceptado";
			        	resultadoRetencion = true;
			        	data = respon.getData();
		            }
		            
		            mensajeEnvio += strCodigo;
		            mensajeEnvio += strEstado;
		            
			        if(!respon.isError() && data != null) {
			        	
				        File constancia = new File(constanciaZipFilePath);
				        FileOutputStream fos = new FileOutputStream(constancia);
				       fos.write(data);
				       
				       try {
					       fos.flush();
					       fos.close();				    	   
				       }
				       catch (Exception e) {
				    	   log.error("Error", e);
				       }
			        }
		            
			        log.info("PrincipalFacturaElectronica.SendDocumentClass.actionPerformed() 3");
		            
		        } catch (Exception e) {
		        	log.error("error", e);
		        	mensajeEnvio += "Error: " + e.getCause().getMessage() + "\r\n";
		        	resultadoRetencion = false;
		        }
				// FIN WS ENVIO
		    	
		    	
				// INICIO GRABADO SIGA
				if (resultadoRetencion) {//depende del resultado del servicio
					param = new ComprobanteRetencion();
					param.setSecuCompRet(secuCompRet);
					
					Date fechaEnvio = new Date();
					fechaEnvio.setHours(0);
					fechaEnvio .setMinutes(0);
					fechaEnvio .setSeconds(0);
					param.setFecDeclaracion(fechaEnvio);
					
					param.setMsjDeclaracion(formato.trunca(mensajeEnvio, 500));
					param.setNumSeriedeclara(cRet.getNumeSeriRetDecl());
					param.setNumNumerodeclara(Integer.parseInt(cRet.getNumeCompRetDecl()));
					param.setIndDeclaracion(RetencionConstantes.ESTADO_DECLARACION_DECLARADO);
	
					String numeRegiArc = registrarArchivo(cRet.getNroretencion(), RetencionConstantes.RUTA_TEMPORAL_ZIP, nombreArchivoConstancia + ".XML");
					param.setNumeRegiArc(numeRegiArc);
					
					// auditoria
					param.setUserModi(usuarioBean.getLogin());
					param.setFechModi(new Date());
					
					comprobanteRetencionService.registrarComprobante(param);
	
					//respuesta.put("nroRetencion", cRet.getNroretencion());
					//respuesta.put("nroDeclaracion", cRet.getNumeSeriRetDecl() + " - " + cRet.getNumeCompRetDecl());
	
					//respuesta.put("resultadoEnvio", "1");
					//respuesta.put("listaMensajes", listaMensajes.toArray());
					//respuesta.put("mensaje", "");
					
					if (!advertencias) {
						mensajeEnvio = "";
					}
					
					mensaje = "Se realizo la declaraci&oacute;n de " + nroRetencion + " con Nro " + nroDeclaracion + " " + mensajeEnvio;
					listaMensajes.add(mensaje);
				}
				else {
					param = new ComprobanteRetencion();
					param.setSecuCompRet(secuCompRet);
					param.setMsjDeclaracion(formato.trunca(mensajeEnvio, 500));
	
					comprobanteRetencionService.registrarComprobante(param);
					
					mensaje = "Ocurri&oacute; un error al registrar la declaraci&oacute;n " + nroRetencion + " , mensaje de error: " + mensajeEnvio;
					listaMensajes.add(mensaje);

					//respuesta.put("resultadoEnvio", "0");
					//respuesta.put("listaMensajes", listaMensajes.toArray());
					//respuesta.put("mensaje",  mensaje);
				}
		    }
			// FIN GRABADO SIGA

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			
			respuesta.put("resultadoEnvio", "1");
			respuesta.put("listaMensajes", listaMensajes.toArray());
			respuesta.put("mensaje", "");

			respuesta.put("error", "0");
		    
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
				
			respuesta.put("error", "1");
			respuesta.put("mensaje", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDelegaciones");
		}
		
		return modelAndView;
	}
	
	
	public ModelAndView envioActualizarReversion(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		log.debug(getClass().getName() + " Inicio del metodo envioActualizarReversion");
		
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		FormatoUtil formato = new FormatoUtil();
		
		List<String> listaMensajes = new ArrayList<String>();
		String mensaje = "";
		
		try {
		    String usuarioAutenticacion = request.getParameter("usuarioAutenticacion");
		    String passwordAutenticacion = request.getParameter("passwordAutenticacion");
		    
		    ComprobanteRetencion param = new ComprobanteRetencion();
		    param.setCodEstado(RetencionConstantes.ESTADO_DECLARACION_EN_REVERSION);
		    
		    //CARGADO Y PREPARADO
		    List<ComprobanteRetencion> listaComprobantes = comprobanteRetencionService.recuperarListaComprobantesRetencion(param);
		    int actualizados = 0;
		    //CARGADO Y PREPARADO
		    
			// INICIO GRABADO SIGA
			for (ComprobanteRetencion comprobante : listaComprobantes) {//depende del resultado del servicio				
				
				if (comprobante.getNumReversion() == null) {
					continue;
				}
				
				String estadoActualizacionReversion = "1"; //0: pendiente, 1: revertido ok, 2: fallo reversion
				String mensajeActualizacionReversion = "";
				
				String nroRetencion = comprobante.getNroretencion();
				String nroDeclaracion = comprobante.getNrodeclaracion();//comprobante.getNumeSeriRetDecl() + " - " + comprobante.getNumeCompRetDecl();
				
				Persona sunat = comprobanteRetencionService.obtenerDatosSunat();
				String rucSunat = sunat.getRuc_persona();
				
				// NOTA EVALUAR QUE TIPOS DE FALLO MERECEN PASARLO A "DECLARADO" Y QUE TIPOS MERECEN DEJARLO EN "EN REVERSION"
				// INICIO WS ENVIO ACTUALIZAR REVERSION
				try {
					//UsuarioSol usuarioSol = new UsuarioSol(comprobante.getRuc(), usuarioAutenticacion, passwordAutenticacion);
					UsuarioSol usuarioSol = new UsuarioSol(rucSunat, usuarioAutenticacion, passwordAutenticacion);
					SunatGEMServiceWrapper client = new SunatGEMServiceWrapper(usuarioSol, RetencionConstantes.URL_SERVICIO_ENVIO);
			       	
		            Response respon = client.getStatus(comprobante.getNumReversion());

		            if (respon.isError()) {
		                log.info("Error de Servicio CRE - Codigo de Error : " + respon.getCodigo() + "\r\n");
		                log.info("Mensaje de Error: " + respon.getMensaje() + "\r\n");

		            	estadoActualizacionReversion = "2";
		            	mensajeActualizacionReversion = respon.getCodigo() + " " + respon.getMensaje();
		            } else {
		            	if (respon.getCodigo() == 0) {
							estadoActualizacionReversion = "1";
							mensajeActualizacionReversion = "";
		            	}
		            	else if (respon.getCodigo() == 98){
							estadoActualizacionReversion = "0";
							mensajeActualizacionReversion = "";		            		
		            	}
		            	else {
			            	estadoActualizacionReversion = "2";
			            	mensajeActualizacionReversion = respon.getCodigo() + " " + respon.getMensaje();							
		            		
			                /*append(respon.getMensaje() + "\r\n");
			                if (respon.getWarnings() != null && respon.getWarnings().size() > 0) {
			                    append("Warnings: \r\n");
			                    for (String warning : respon.getWarnings()) {
			                        append(warning + "\r\n");
			                    }
			                }*/
		            	}
		            }
					
				}
				catch (Exception e) {
					// manejo de error de servicio,se adiciona a estado 2
					estadoActualizacionReversion = "2"; //0: pendiente, 1: revertido ok, 2: fallo reversion
					mensajeActualizacionReversion = "Mensaje de error de invocacion: " + e.getMessage();
				}
				// FIN WS ENVIO
							
				if("0".equals(estadoActualizacionReversion)) {
					mensaje = "Comprobante de retencion: " + nroRetencion + " declarado como: " + nroDeclaracion + " aun se encuentra en proceso de reversi&oacute;n.";
					listaMensajes.add(mensaje);
				}
				else if ("1".equals(estadoActualizacionReversion)) {
					param = new ComprobanteRetencion();
					param.setSecuCompRet(comprobante.getCodDeclaracion());
					
					param.setIndDeclaracion(RetencionConstantes.ESTADO_DECLARACION_REVERTIDO);
					
					// auditoria
					param.setUserModi(usuarioBean.getLogin());
					param.setFechModi(new Date());
					
					//ACTUALIZACION 
					comprobanteRetencionService.revertirComprobante(param);
					
					mensaje = "Comprobante de retencion: " + nroRetencion + " declarado como: " + nroDeclaracion + " fue revertido correctamente.";
					listaMensajes.add(mensaje);
				}
				else if ("2".equals(estadoActualizacionReversion)) {
					param = new ComprobanteRetencion();
					param.setSecuCompRet(comprobante.getCodDeclaracion());
					
					//param.setIndDeclaracion(RetencionConstantes.ESTADO_DECLARACION_DECLARADO);//DEJARLO "EN REVERSION", ES MEJOR MANEJARLO CON SIGESI
					param.setMsjDeclaracion(formato.trunca(mensajeActualizacionReversion, 500));
					// auditoria
					param.setUserModi(usuarioBean.getLogin());
					param.setFechModi(new Date());
					
					//ACTUALIZACION 
					comprobanteRetencionService.revertirComprobante(param);
					
					mensaje = "Comprobante de retencion: " + nroRetencion + " declarado como: " + nroDeclaracion + " no fue revertido, mensaje de error: " + mensajeActualizacionReversion;
					listaMensajes.add(mensaje);
				}
				
				actualizados++;
			}
			// FIN GRABADO SIGA

			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES

		    if (actualizados > 0) {
				respuesta.put("error", "0");
				respuesta.put("resultadoEnvio", "1");
				respuesta.put("mensaje", "");
				respuesta.put("listaMensajes", listaMensajes.toArray());
			}
			else {
				respuesta.put("error", "0");
				respuesta.put("resultadoEnvio", "0");
				respuesta.put("mensaje", "No se encontraron comprobantes en estado \"EN REVERSION\" por actualizar.");
				respuesta.put("listaMensajes", listaMensajes.toArray());
			}
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("mensaje", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDelegaciones");
		}
		
		return modelAndView;
	}
	
	
	public String registrarArchivo(String nroRetencion, String rutaArchivo, String nombreArchivo) throws Exception {
		
		String resultado = "";
		
		log.debug("Inicio -  RegistroArchivosController.cargarArchivo");
		
		Map<String, Object> params 	= new HashMap<String, Object>();
		
		String tipoDocumento = "";
		String fileDescripcion = "";
		String numeroRegistroArchivo	= "";
		String numeroArchivo = "";
		
		try{
			tipoDocumento	= "DECLARACION CRE";
			fileDescripcion	= "CERTIFICADO DE RETENCION " + nroRetencion;
			
			log.debug("El nombre del archivo antes de crear el new file: " + nombreArchivo.trim());
			File file = new File(rutaArchivo, nombreArchivo.trim());
			
			//REGISTRO = CODIGO DEL CERTIFICADO DE RETENCION -> NRO_RETENCION NUME_RET_RETE
			
			params.put("registroDescripcion", RetencionConstantes.DESCRIPCION_REGISTRO);
			params.put("numeroDocumentoOrigen", nroRetencion);//NUMERO SIGA DEL COMPROBANTE
			params.put("file", file);
			params.put("num_archivo", numeroArchivo);
			params.put("tipoDocumento", tipoDocumento);
			params.put("fileDescripcion", fileDescripcion);
			params.put("aplicacion", RetencionConstantes.APLICACION);
			params.put("modulo", RetencionConstantes.MODULO);

			numeroRegistroArchivo=registroArchivosService.registrarArchivoGeneral(params);
			resultado = numeroRegistroArchivo;
			
			//Recuperando Archivos Adjuntos////////////////////////////////////////////////////
			/*if(numeroRegitroArchivo!= null){
				if (!"".equals(numeroRegitroArchivo)){
					params.put("num_reg", numeroRegitroArchivo);
					listArchivosAdj= (List<RegistroArchivosFisicoBean>)registroArchivosService.listarArchivosAdjuntos(params);

				}
			}*/
			return resultado;
		}
		catch(Exception e){
			log.error("error registrarArchivo", e);
			throw e;
		}
	}
	
	private String recuperarCodigoCertificado() {
		
		String respuesta = "";

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("cod_par", "3339");
		paramMap.put("cod_mod", "SIGA");
		paramMap.put("cod_tipo", "D");
		paramMap.put("cod_arg", RetencionConstantes.COD_CODIGO_CERTIFICADO);
		T01ParametroBean t01parametro = registroGeneralService.recuperarParametro(paramMap);
		
		if (t01parametro != null) {
			respuesta = t01parametro.getNom_largo();
		}
		
		return respuesta;
		
	}	
	
	public String getJsonView() {
		return jsonView;
	}

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public JsonSerializer getJsonSerializer() {
		return jsonSerializer;
	}

	public void setJsonSerializer(JsonSerializer jsonSerializer) {
		this.jsonSerializer = jsonSerializer;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(
			RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public ComprobanteRetencionService getComprobanteRetencionService() {
		return comprobanteRetencionService;
	}

	public void setComprobanteRetencionService(
			ComprobanteRetencionService comprobanteRetencionService) {
		this.comprobanteRetencionService = comprobanteRetencionService;
	}
}