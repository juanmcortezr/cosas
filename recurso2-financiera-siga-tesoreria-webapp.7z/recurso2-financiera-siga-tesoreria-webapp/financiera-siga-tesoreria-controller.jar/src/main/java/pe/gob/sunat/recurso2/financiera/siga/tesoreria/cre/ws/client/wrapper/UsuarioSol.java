package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper;

public class UsuarioSol {
    
    public static ThreadLocal<UsuarioSol> usuarioThread = new ThreadLocal<UsuarioSol>();
    
    
    private String numeroRUC;
    private String usuarioSOL;
    private String password;
    public UsuarioSol(String numeroRUC, String usuarioSOL, String password) {
	super();
	this.numeroRUC = numeroRUC;
	this.usuarioSOL = usuarioSOL;
	this.password = password;
	usuarioThread.set(this);
    }
//    public String getNumeroRUC() {
//        return numeroRUC;
//    }
//    public String getUsuarioSOL() {
//        return usuarioSOL;
//    }
    public String getPassword() {
        return password;
    }
    
    
    public String rucUsuarioSOL() {
	return this.numeroRUC + this.usuarioSOL;
    }

}
