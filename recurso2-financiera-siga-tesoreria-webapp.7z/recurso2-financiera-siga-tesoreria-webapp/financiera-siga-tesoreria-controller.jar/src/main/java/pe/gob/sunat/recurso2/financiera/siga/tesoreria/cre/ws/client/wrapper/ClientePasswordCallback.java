package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.wss4j.common.ext.WSPasswordCallback;
//import org.apache.ws.security.WSPasswordCallback;

public class ClientePasswordCallback implements CallbackHandler {

   @Override
   public void handle(Callback[] callbacks) throws IOException,
         UnsupportedCallbackException {
      WSPasswordCallback pc = (WSPasswordCallback) callbacks[0];
      // set the password for our message.
      UsuarioSol usuarioSol = UsuarioSol.usuarioThread.get();
      try {
	  pc.setPassword(usuarioSol.getPassword());
      } catch(Throwable t) {
	  pc.setPassword("moddatos");
      }
   }
}
