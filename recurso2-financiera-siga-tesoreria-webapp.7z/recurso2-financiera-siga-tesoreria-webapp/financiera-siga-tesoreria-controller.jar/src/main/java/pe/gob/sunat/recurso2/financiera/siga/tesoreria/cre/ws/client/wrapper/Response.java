package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper;

import java.util.ArrayList;
import java.util.List;

public class Response {
    
    // alamcena el codigo de retorno
    private int codigo;
    //indica si se trata de un error o no
    private boolean isError = false;
    // almacena el mensaje de error
    private String mensaje;
    private List<String> warnings;
    private byte[] data;
    private String ticket;
    
    public Response(int codigo, String mensaje, List<String> warnings) {
		super();
		this.codigo = codigo;
		this.mensaje = mensaje;
		this.warnings = warnings;
		if (warnings == null) {
			this.warnings = new ArrayList<String>();
		}
		
		if(codigo != 0 ) {
		    this.isError = true;
		}
    }

    public Response(int codigo, String mensaje, List<String> warnings, byte[] data) {
		this(codigo, mensaje, warnings);
		this.data = data;
    }
    
    public Response(int codigo, String mensaje, List<String> warnings, String ticket) {
		this(codigo, mensaje, warnings);
		this.ticket = ticket;
    }
    
    public int getCodigo() {
        return codigo;
    }
    public boolean isError() {
        return isError;
    }
    public String getMensaje() {
        return mensaje;
    }
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    public List<String> getWarnings() {
        return warnings;
    }
	public byte[] getData() {
		return data;
	}

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public String getTicket() {
		return ticket;
	}
    

}
