package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.exception;

public class ConstanciaException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public ConstanciaException() {
	super();
    }

    public ConstanciaException(String message, Throwable cause) {
	super(message, cause);
    }

    public ConstanciaException(String message) {
	super(message);
    }

    public ConstanciaException(Throwable cause) {
	super(cause);
    }

}
