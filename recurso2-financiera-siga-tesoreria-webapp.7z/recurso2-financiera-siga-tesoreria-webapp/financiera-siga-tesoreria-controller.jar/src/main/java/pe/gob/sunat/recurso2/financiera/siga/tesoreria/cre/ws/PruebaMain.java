package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper.Response;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper.SunatGEMServiceWrapper;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper.UsuarioSol;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.RetencionConstantes;


public class PruebaMain {

	public static void main(String[] args) {
		PruebaMain pm = new PruebaMain();
		pm.enviarComprobanteRetencion();
	}

	public Response enviarComprobanteRetencion() {

		// ENVIO AL SERVICIO WEB DE CRE
		System.out.println("PrincipalFacturaElectronica.SendDocumentClass.actionPerformed() HEY");
       UsuarioSol usuarioSol = new UsuarioSol("1", "MODDATOS", "moddatos");
       
       SunatGEMServiceWrapper client = new SunatGEMServiceWrapper(usuarioSol, RetencionConstantes.URL_SERVICIO_ENVIO);
 		
        Response respon = new Response(0, null, null);
        String mensaje = "";
        
        try {
        	
        	//String fileNameZip = recuperarNombreRetencion(cRet.getNrucDeclRet(), cRet.getNumeSeriRetDecl(), Long.parseLong(cRet.getNumeCompRetDecl()));
        	String fileNameZip = "20520485750-20-R666-00000041";
        	//String fileNameXml = recuperarNombreRetencion(cRet.getNrucDeclRet(), cRet.getNumeSeriRetDecl(), Long.parseLong(cRet.getNumeCompRetDecl()));
        	//String fileNameXml = "20520485750-20-R001-00000030";
        	String filePath = RetencionConstantes.RUTA_TEMPORAL_ZIP;
        	String fileZipPath = filePath + fileNameZip;
        	
        	//recuperarZipFile(filePath, fileNameZip, fileNameXml, cadenaRetFirmado);
        	
            respon = client.sendBill(fileNameZip + ".ZIP", fileZipPath + ".ZIP");
            System.out.println("respon: " + respon.getCodigo() + " " + respon.isError() + " " + respon.getMensaje());
            System.out.println("PrincipalFacturaElectronica.SendDocumentClass.actionPerformed() 2");
            
            if (respon.isError()) {
            	mensaje += "Codigo de Error : " + respon.getCodigo() + "\r\n";
            	mensaje += "Mensaje de Error: " + respon.getMensaje() + "\r\n";
            } else {
            	mensaje += respon.getMensaje() + "\r\n";
                if (respon.getWarnings() != null && respon.getWarnings().size() > 0) {
                	mensaje += "Warnings: \r\n";
                    for (String warning : respon.getWarnings()) {
                    	mensaje += warning + "\r\n";
                    }
                }
            }
            
            String strCodigo = "";
            String strEstado = "";
            if(respon.isError()){
            	strCodigo = String.valueOf(respon.getCodigo());
            	strEstado = "99 - Rechazado";
            }
            
            if(!respon.isError()&&respon.getWarnings().size()>0){
            	strCodigo = String.valueOf(respon.getCodigo());
            	strEstado = "0 - Aceptado con Observaciones";
            }
            
            if(!respon.isError()&&respon.getWarnings().size()==0){
            	strCodigo = String.valueOf(respon.getCodigo());
            	strEstado = "0 - Aceptado";
            }
            
            if (!respon.isError()) {
            	System.out.println("EL MENSAJE DE RETORNO: " + mensaje);
            }
            
            mensaje += strCodigo;
            mensaje += strEstado;		
        } catch(org.apache.cxf.interceptor.Fault e1) {
        	e1.printStackTrace();
        	mensaje += "Error: " + e1.getCause().getMessage() + "\r\n";
        } catch (Exception e2) {
        	e2.printStackTrace();
        	mensaje += "Error: " + e2.getCause().getMessage() + "\r\n";
        }
        
        respon.setMensaje(mensaje);
        return respon;
        
    }
	
}
