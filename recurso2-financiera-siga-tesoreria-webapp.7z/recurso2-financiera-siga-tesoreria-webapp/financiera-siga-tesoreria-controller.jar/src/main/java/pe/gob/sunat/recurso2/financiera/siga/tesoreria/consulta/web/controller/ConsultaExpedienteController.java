package pe.gob.sunat.recurso2.financiera.siga.tesoreria.consulta.web.controller;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.archivo.model.bean.RegistroArchivosFisicoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.firma.model.bean.T5282Archbin;
import pe.gob.sunat.recurso2.administracion.siga.firma.service.ConsultaFirmaService;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.FormatoUtil;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.ServiceException;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.ContratosCronograma;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.DetallePagoContratos;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.DocumentosCompras;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.Empleado;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.ExpedientesInternosAcciones;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.IsdpClasifSupu;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.Persona;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.model.SysRegistroArchivosFisico;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.service.ConsultaExpedienteService;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

public class ConsultaExpedienteController extends MultiActionController {
	
	private String jsonView;
	private JsonSerializer jsonSerializer;
	
	private RegistroGeneralService registroGeneralService;
	private RegistroArchivosService registroArchivosService;
	private ConsultaExpedienteService consultaExpedienteService;
	private ConsultaFirmaService consultaFirmaService;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	//#numRegiCab#,#codiContCco#,#numItem#,#numeroEntrega#,#tipo#      
	
	//recuperarDocumentoPdfFirmado(BigDecimal codDocaut)
	
	/**
     * Carga la Pagina de la consulta
     * @param HttpServletRequest request
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */  
	public ModelAndView iniciarConsulta(HttpServletRequest request, HttpServletResponse response) {
		
		log.debug("debug Inicio - ConsultaExpedienteController.iniciarConsulta");
		
		ModelAndView modelAndView;
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		String pagina = "";
		String errorMessage = "";
		
		try {

			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			List<T01ParametroBean> listaEstados;
			listaEstados = new ArrayList<T01ParametroBean>();
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cod_par", "3280");
			params.put("cod_mod", "SIGA");
			params.put("cod_tipo", "D");
			
			listaEstados = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			
			//T01ParametroBean parametro = new T01ParametroBean();
			
			String numeroRegistro = usuarioBean.getNroRegistro().toUpperCase();
			Empleado empleado = consultaExpedienteService.getEmpleado(numeroRegistro);
			
			params = new HashMap<String, Object>();
			params.put("codigoEmpleado", empleado.getCodigoEmpleado());
			String flagAutorizacion = consultaExpedienteService.validarAutorizacionConsultaExpediente(params);
			//flagAutorizacion = "1";
			
			 //addOption("selEstado", 'T', "TODOS");
			
			//listaEstados = jQuery.parseJSON(listaEstadosString);
			//for (var i = 0; i < listaEstados.length; i++) {
			//	addOption("selEstado", $.trim(listaEstados[i].cod_argumento), $.trim(listaEstados[i].nom_largo));
			//}
			
			if (log.isDebugEnabled())log.debug("getApeMaterno:"		+usuarioBean.getApeMaterno());
			if (log.isDebugEnabled())log.debug("getApePaterno:"		+usuarioBean.getApePaterno());
			if (log.isDebugEnabled())log.debug("getCodDepend:"		+usuarioBean.getCodDepend());
			if (log.isDebugEnabled())log.debug("getCodUO:"			+usuarioBean.getCodUO());
			if (log.isDebugEnabled())log.debug("getCorreo:"			+usuarioBean.getCorreo());
			if (log.isDebugEnabled())log.debug("getLogin:"			+usuarioBean.getLogin());
			if (log.isDebugEnabled())log.debug("getNombreCompleto:"	+usuarioBean.getNombreCompleto());
			if (log.isDebugEnabled())log.debug("getNombres:"		+usuarioBean.getNombres());
			if (log.isDebugEnabled())log.debug("getNroRegistro:"	+usuarioBean.getNroRegistro());
			if (log.isDebugEnabled())log.debug("getTicket:"			+usuarioBean.getTicket());
			
			if ("1".equals(flagAutorizacion) || "2".equals(flagAutorizacion)) {
			
				respuesta.put("listaEstados", listaEstados);
				respuesta.put("listaEstadosString", jsonSerializer.serialize(listaEstados));
				respuesta.put("userRegistro", usuarioBean.getNroRegistro());
				
				pagina = "paginaConsultaExpediente";
			}
			else {
				pagina = "paginaErrorSistema";
				errorMessage = "Usted no tiene autorizacion para entrar a la Consulta de Expediente Virtual.";
			}
		} 
		catch(Exception e){
			log.error(e.getMessage(), e);
			pagina = "paginaErrorSistema";
			errorMessage = "A ocurrido un inconveniente por favor comuniquese con el Administrador." + e.getMessage();
		}
		finally{
			respuesta.put("mensajeError", errorMessage);
			respuesta.put("errorMessage", errorMessage);
			modelAndView = new ModelAndView(pagina,respuesta);
			log.debug("Fin ConsultaExpedienteController.iniciarConsulta");
		}
		
		return modelAndView;
	}
	
	public ModelAndView consultarProveedorPorRuc(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {
		
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo consultarProveedorPorRuc");
			String ruc = request.getParameter("ruc");
			
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("num_ruc", ruc);
			//param.put("tipod_doc", "04");// SOLO PERSONAS CON RUC
			param.put("tiene_ruc", true);
			
			List<Persona> listaProveedores = consultaExpedienteService.recuperarPersonas(param);
			Persona persona = new Persona();
			if (!listaProveedores.isEmpty()) {
				persona = listaProveedores.get(0);
			}
			
			respuesta.put("listaProveedores", listaProveedores);
			respuesta.put("persona", persona);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo consultarProveedorPorRuc");
		}
		
		return modelAndView;
	}
	
	public ModelAndView consultarProveedorPorRazonSocial(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {

		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo consultarProveedorPorRazonSocial");
			
			String razonSocial = StringUtils.trimToEmpty(request.getParameter("razonSocial")).toUpperCase();
			log.debug("razon social enviada a la consulta: " + razonSocial);
			
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("nombre_razon_social", razonSocial);
			//param.put("tipod_doc", "04");// SOLO PERSONAS CON RUC
			param.put("tiene_ruc", true);			
			
			List<Persona> listaProveedores = consultaExpedienteService.recuperarPersonas(param);			
			respuesta.put("listaProveedores", listaProveedores);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo consultarProveedorPorRazonSocial");
		}
		
		return modelAndView;
	}
	
	private List<ContratosCronograma> consultarExpedientesVirtuales(HttpServletRequest request, HttpServletResponse response) 
			throws ServiceException {
		
		try {

			//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			FormatoUtil formato = new FormatoUtil();
			
			String ruc = formato.vacioANulo(request.getParameter("ruc"));
			//String txtRazonSocial = StringUtils.trimToEmpty(request.getParameter("razonSocial"));
			
			String selEstado = request.getParameter("selEstado");
			String txtPalabraClave = formato.vacioANulo(request.getParameter("txtPalabraClave"));
			String txtContrato = formato.vacioANulo(request.getParameter("txtContrato"));
			String txtProcSelec = formato.vacioANulo(request.getParameter("txtProcSelec"));
			String txtFechaDesde = request.getParameter("txtFechaDesde");
			String txtFechaHasta = request.getParameter("txtFechaHasta");
			
			log.debug("fechas enviadas: " + txtFechaDesde + " " + txtFechaHasta);
						
			Date fechaDesde = null;
			try {
				fechaDesde = sdf.parse(txtFechaDesde);
				fechaDesde.setHours(0);
				fechaDesde.setMinutes(0);
				fechaDesde.setSeconds(0);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				fechaDesde = null;
			}
			
			Date fechaHasta = null;
			try {
				fechaHasta = sdf.parse(txtFechaHasta);
				fechaHasta.setHours(23);
				fechaHasta.setMinutes(59);
				fechaHasta.setSeconds(59);
			}
			catch (Exception e) {
				log.debug("error en conversion de fecha");
				fechaHasta = null;
			}
			
			if (txtPalabraClave != null)
				txtPalabraClave = txtPalabraClave.toUpperCase();

			if (txtContrato != null)
				txtContrato = txtContrato.toUpperCase();

			if (txtProcSelec != null)
				txtProcSelec = txtProcSelec.toUpperCase();
			
			ContratosCronograma param = new ContratosCronograma();
			param.setRuc(ruc);
			param.setSintesis(txtPalabraClave);
			param.setNroContrato(txtContrato);//param.setCodiContCco(txtContrato);
			param.setProcSeleccion(txtProcSelec);
			param.setFechaInicio(fechaDesde);
			param.setFechaFin(fechaHasta);
			
			List<ContratosCronograma> listaExpedientes = consultaExpedienteService.recuperarListaExpedientes(param,selEstado);
			
			for (ContratosCronograma contrato : listaExpedientes) {
				
				//campos de la lista a mostrar
				contrato.setRuc(formato.formateaCadena(contrato.getRuc()));
				contrato.setRazonSocial(formato.formateaCadena(contrato.getRazonSocial()));
				contrato.setProcSeleccion(formato.formateaCadena(contrato.getProcSeleccion()));
				contrato.setNroContrato(formato.formateaCadena(contrato.getNroContrato()));
				contrato.setItem(formato.formateaCadena(contrato.getItem()));
				contrato.setSintesis(formato.formateaCadena(contrato.getSintesis()));
				contrato.setfFinPrestDesc(formato.formateaFecha(contrato.getfFinPrest()));
				contrato.setEstado(formato.formateaCadena(contrato.getEstado()));
				if (contrato.getEstado() != null || contrato.getEstado().length() >= 2) {
					contrato.setEstado(contrato.getEstado().substring(1).trim());
				}
				contrato.setfUltOperDesc(formato.formateaFecha(contrato.getfUltOper()));
				contrato.setfIcauDesc(formato.formateaFecha(contrato.getfIcau()));
				contrato.setOp(formato.formateaCadena(contrato.getOp()));
				contrato.setSiaf(formato.formateaCadena(contrato.getSiaf()));
				contrato.setMoneda(formato.formateaCadena(formato.formateaMoneda(contrato.getMoneda())));
				contrato.setMontooriginalDesc(formato.formateaDecimal(contrato.getMontooriginal()));
				contrato.setMontogastonacDesc(formato.formateaDecimal(contrato.getMontogastonac()));
				contrato.setExpvirtual(formato.formateaCadena(contrato.getExpvirtual()));
				contrato.setCodEstado(formato.formateaCadena(contrato.getCodEstado()));
				
				//campos para las consultas de los detalles
				contrato.setTipo(formato.formateaCadena(contrato.getTipo()));
				contrato.setCodiContCco(formato.formateaCadena(contrato.getCodiContCco()));
				contrato.setNumItem(formato.formateaCadena(contrato.getNumItem()));
				contrato.setNumeroEntrega(contrato.getNumeroEntrega());
				contrato.setNumRegiCab(formato.formateaCadena(contrato.getNumRegiCab()));
			}
			
			return listaExpedientes;
			/*
			--ruc: s.ruc,
			--razonSocial: s.razonSocial,
			--procSeleccion: s.procSeleccion,
			--nroContrato: s.nroContrato,
			--item: s.item,
			--sintesis: s.sintesis,
			--fFinPrest: s.fFinPrestDesc,
			--estado: s.estado,
			--fUltOper: s.fUltOperDesc,
			--fIcau: s.fIcauDesc,
			--op: s.op,
			--siaf: s.siaf,
			--moneda: s.moneda,
			--montooriginal: s.montooriginalDesc,
			--montogastonac: s.montogastonacDesc,
			--expvirtual: s.expvirtual,
			compPago: s.compPago,
			seguimiento: s.seguimiento,
			--codEstado: s.codEstado
			*/
		}
		catch (Exception e) {
			log.error("Error" , e);
			throw new ServiceException (e);
		}
	}
	
	/** 
     * Recuperar expedientes virtuales 
     * @param HttpServletRequest request 
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */ 
	public ModelAndView recuperarExpedientesVirtuales(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarExpedientesVirtuales");
			
			List<ContratosCronograma> listaExpedientes = this.consultarExpedientesVirtuales(request, response);						
			respuesta.put("listaExpedientes", listaExpedientes);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarExpedientesVirtuales");
		}
		
		return modelAndView;
	}
	
	
	public ModelAndView exportarExpedientesVirtuales(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		//String pagina = "";
		//String errorMessage = "";
		
		try {			
			List<ContratosCronograma> listaExpedientes = this.consultarExpedientesVirtuales(request, response);						
			
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			String fechaFormateada = sdf.format(new Date());
			
			// 2. Proceso las solicitudes para su exportacion a excel:
			HSSFWorkbook libroXLS/* = null*/;
			HSSFSheet hojaXLS/* = null*/;
			HSSFRow filaXLS/* = null*/;
			HSSFCell celdaXLS/* = null*/;
			
			HSSFCellStyle estiloTit/* = null*/;
			HSSFFont fuenteTit/* = null*/;
			
			HSSFCellStyle estiloDat/* = null*/;
			HSSFFont fuenteDat/* = null*/;
			
			HSSFCellStyle estiloDatIzq/* = null*/;
			HSSFFont fuenteDatIzq/* = null*/;
			
			libroXLS = new HSSFWorkbook();
			
			fuenteTit = libroXLS.createFont();
			fuenteTit.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // En negrita
			fuenteTit.setFontHeight((short) 160);
			fuenteTit.setFontName("Arial");
			
			fuenteDat = libroXLS.createFont();
			fuenteDat.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDat.setFontHeight((short) 160);
			fuenteDat.setFontName("Arial");
			
			fuenteDatIzq = libroXLS.createFont();
			fuenteDatIzq.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDatIzq.setFontHeight((short) 160);
			fuenteDatIzq.setFontName("Arial");
			
			estiloTit = libroXLS.createCellStyle();
			estiloTit.setFont(fuenteTit);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setAlignment(HSSFCellStyle.ALIGN_CENTER);

			estiloDat = libroXLS.createCellStyle();
			estiloDat.setFont(fuenteDat);
			estiloDat.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDat.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			estiloDatIzq = libroXLS.createCellStyle();
			estiloDatIzq.setFont(fuenteDat);
			estiloDatIzq.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			
			String nombreArchivo = "expedientes_" + fechaFormateada + ".xls";
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/vnd.ms-excel");

			// Ahora procesamos el reporte en
			hojaXLS = libroXLS.createSheet("Firmas");

			filaXLS = hojaXLS.createRow((short) 1);
			
			String[] columnas = 
			{"RUC", "Raz\u00f3n Social", "Proc. Selecci\u00f3n", "Nro. Contrato",
			 "Item",	"S\u00edntesis", "F. Fin Prest.", "Estado",
			 "F. Ult. Oper.", "F. ICAU",	"O/P", "SIAF",
			 "Moneda", "Monto Original", "Monto Mon. Nac.", "Exp Virtual"};
			
			int z = 0;
			for (String columna : columnas) {
				celdaXLS = filaXLS.createCell(++z);
				celdaXLS.setCellStyle(estiloTit);
				celdaXLS.setCellValue(columna);
				hojaXLS.setColumnWidth(z, ((columna.length() + 10)* 512));
			}

			int i = 1;// numero de la fila desde la cual se itera...

			for (ContratosCronograma expediente : listaExpedientes) {
				filaXLS = hojaXLS.createRow(++i);
				z = 0;
				
				if (i <= 65000) { //por limitaciones de xls clasico
					//i++;
				
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getRuc());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getRazonSocial());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getProcSeleccion());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getNroContrato());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getItem());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getSintesis());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getfFinPrestDesc());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getEstado());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getfUltOperDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getfIcauDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getOp());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getSiaf());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getMoneda());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getMontooriginalDesc());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(expediente.getMontogastonacDesc());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					if ("1".equals(expediente.getExpvirtual())) {
						celdaXLS.setCellValue("Si");
					}
					else {
						celdaXLS.setCellValue("No");
					}
				}
			}
			
			libroXLS.write(response.getOutputStream());
			response.getOutputStream().close();
			response.getOutputStream().flush();
			
			return modelAndView;
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
	}
	
	
	public ModelAndView recuperarDetalleExpedientes(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {

		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		//SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		FormatoUtil formato = new FormatoUtil();
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarDetalleExpedientes");
			
			String tipo = request.getParameter("tipo");
			String codiContCco = formato.formateaCadena(request.getParameter("codiContCco"));
			String numItem = formato.formateaCadena(request.getParameter("numItem"));
			String numeroEntrega = formato.formateaCadena(request.getParameter("numeroEntrega"));
			String numRegiCab = formato.formateaCadena(request.getParameter("numRegiCab"));
			
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("tipo", tipo);
			param.put("codiContCco", codiContCco);
			param.put("numItem", numItem);
			param.put("numeroEntrega", numeroEntrega);
			param.put("numRegiCab", numRegiCab);
			
			List<SysRegistroArchivosFisico> listaDetalleExpedientes = consultaExpedienteService.recuperarListaArchivosAdjuntos(param);

			for (SysRegistroArchivosFisico det : listaDetalleExpedientes) {
				
				/*secuRegiArc: s.secuRegiArc,
				codDocaut: s.codDocaut,
				modulo: s.modulo,
				esvirtual: s.esvirtual,
				nombrearchivo: s.nombrearchivo*/
				
				//campos de la lista a mostrar

				//det.setSecuRegiArc(det.getSecuRegiArc());
				//det.setCodDocaut(det.getCodDocaut());
				det.setModulo(formato.formateaCadena(det.getModulo()));
				det.setEsvirtual(formato.formateaCadena(det.getEsvirtual()));
				det.setNombrearchivo(formato.formateaCadena(det.getNombrearchivo()));
			}

			respuesta.put("listaDetalleExpedientes", listaDetalleExpedientes);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDetalleExpedientes");
		}
		
		return modelAndView;
	}

	public ModelAndView descargarArchivo(HttpServletRequest request, HttpServletResponse response) throws ServiceException {

		ModelAndView modelAndView = null;
		
		if (log.isDebugEnabled()) {log.debug("debug Inicio - RegistroArchivosController.descargarArchivo");}
		Map<String, Object> params = new HashMap<String, Object>();
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		try {
			String secuRegiArc 	= StringUtils.trim(request.getParameter("secuRegiArc"));
			String codDocaut 	= StringUtils.trim(request.getParameter("codDocaut"));
			String esvirtual 	= StringUtils.trim(request.getParameter("esvirtual"));
			boolean existeArchivo = false;
			
			BigDecimal codDocautNumber;
			try {
				codDocautNumber = new BigDecimal(codDocaut);
			}
			catch (Exception e) {
				log.debug("error en conversion de numero");
				codDocautNumber = BigDecimal.valueOf(-1.0);				
			}
			
			log.debug("sec_reg "+secuRegiArc);
			params.put("sec_reg", secuRegiArc);
			
			byte[] bytes = new byte[1024];
			String nombre = "";
			
			if ("0".equals(esvirtual)) {
				RegistroArchivosFisicoBean archivo = registroArchivosService.recuperarArchivo(params);
				bytes = archivo.getData();
				nombre = archivo.getFile_name();
				existeArchivo = true;
			}
			else if ("1".equals(esvirtual)){
				T5282Archbin archivo = consultaFirmaService.recuperarDocumentoPdfFirmado(codDocautNumber);
				bytes = archivo.getArcDatos();
				nombre = archivo.getDesNombreAlternativo();
				
				if (nombre == null) {
					nombre = archivo.getDesNombre();
				}
				
				if (nombre == null) {
					nombre = "archivo_descarga";
				}
				
				if (!(nombre.contains(".pdf") || nombre.contains(".PDF"))) {
					nombre = nombre + ".pdf";
				}
				existeArchivo = true;
			}

			if (existeArchivo) {				
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment;filename="+nombre);
	
				OutputStream os = response.getOutputStream();
	
				os.write(bytes);
	
				os.flush();
				os.close();
			}
			
			return modelAndView;
		}
		catch(Exception ex){
			log.error("Error en RegistroArchivosController.descargarArchivo: " + ex.getMessage(), ex);

			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + ex.getMessage());			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
		finally{
			if (log.isDebugEnabled()){ log.debug("Fin - RegistroArchivosController.descargarArchivo");}
		}

	}
	
	private List<DetallePagoContratos> consultarIcau(HttpServletRequest request, HttpServletResponse response) 
			throws ServiceException {
		
		try {

			//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			//SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			FormatoUtil formato = new FormatoUtil();
			
			String tipo = request.getParameter("tipo");
			String codiContCco = formato.formateaCadena(request.getParameter("codiContCco"));
			String numItem = formato.formateaCadena(request.getParameter("numItem"));
			String numeroEntrega = formato.formateaCadena(request.getParameter("numeroEntrega"));
			String numRegiCab = formato.formateaCadena(request.getParameter("numRegiCab"));
			
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("tipo", tipo);
			param.put("codiContCco", codiContCco);
			param.put("numItem", numItem);
			param.put("numeroEntrega", numeroEntrega);
			param.put("numRegiCab", numRegiCab);
			
			List<DetallePagoContratos> listaIcau = consultaExpedienteService.recuperarListaIcau(param);

			for (DetallePagoContratos icau : listaIcau) {
				
				//campos de la lista a mostrar
				icau.setNumeroIcau(formato.formateaCadena(icau.getNumeroIcau()));
				icau.setUuoo(formato.formateaCadena(icau.getUuoo()));
				icau.setNombCortPer(formato.formateaCadena(icau.getNombCortPer()));
				icau.setFechaNotificacionDesc(formato.formateaFecha(icau.getFechaNotificacion()));
				icau.setFechaConformidadDesc(formato.formateaFecha(icau.getFechaConformidad()));
				icau.setdTranscurridoDesc(formato.formateaEntero(icau.getdTranscurrido()));
			}
			
			return listaIcau;
		}
		catch (Exception e) {
			log.error("Error" , e);
			throw new ServiceException (e);
		}
	}
	
	public ModelAndView recuperarIcau(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {

		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarIcau");
			
			List<DetallePagoContratos> listaIcau = this.consultarIcau(request, response);
			respuesta.put("listaIcau", listaIcau);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDetalleExpedientes");
		}
		
		return modelAndView;
	}

	public ModelAndView exportarIcau(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		//String pagina = "";
		//String errorMessage = "";
		
		//ruc, razon social
		//nro contrato, proc seleccion
		
		try {			
			List<DetallePagoContratos> listaIcau = this.consultarIcau(request, response);						
			
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			String fechaFormateada = sdf.format(new Date());
			
			// 2. Proceso las solicitudes para su exportacion a excel:
			HSSFWorkbook libroXLS/* = null*/;
			HSSFSheet hojaXLS/* = null*/;
			HSSFRow filaXLS/* = null*/;
			HSSFCell celdaXLS/* = null*/;
			
			HSSFCellStyle estiloTit/* = null*/;
			HSSFFont fuenteTit/* = null*/;
			
			HSSFCellStyle estiloDat/* = null*/;
			HSSFFont fuenteDat/* = null*/;
			
			HSSFCellStyle estiloDatIzq/* = null*/;
			HSSFFont fuenteDatIzq/* = null*/;
			
			libroXLS = new HSSFWorkbook();
			
			fuenteTit = libroXLS.createFont();
			fuenteTit.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // En negrita
			fuenteTit.setFontHeight((short) 160);
			fuenteTit.setFontName("Arial");
			
			fuenteDat = libroXLS.createFont();
			fuenteDat.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDat.setFontHeight((short) 160);
			fuenteDat.setFontName("Arial");
			
			fuenteDatIzq = libroXLS.createFont();
			fuenteDatIzq.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDatIzq.setFontHeight((short) 160);
			fuenteDatIzq.setFontName("Arial");
			
			estiloTit = libroXLS.createCellStyle();
			estiloTit.setFont(fuenteTit);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setAlignment(HSSFCellStyle.ALIGN_CENTER);

			estiloDat = libroXLS.createCellStyle();
			estiloDat.setFont(fuenteDat);
			estiloDat.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDat.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			estiloDatIzq = libroXLS.createCellStyle();
			estiloDatIzq.setFont(fuenteDat);
			estiloDatIzq.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			
			String nombreArchivo = "icaus_" + fechaFormateada + ".xls";
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/vnd.ms-excel");

			// Ahora procesamos el reporte en
			hojaXLS = libroXLS.createSheet("Firmas");

			filaXLS = hojaXLS.createRow((short) 1);
			
			String[] columnas = 
			{"Nro Icau", "UUOO", "Responsable", "Fecha Notificaci\u00f3n",
			 "Fecha Aprobaci\u00f3n", "Dias transc."};
			
			int z = 0;
			for (String columna : columnas) {
				celdaXLS = filaXLS.createCell(++z);
				celdaXLS.setCellStyle(estiloTit);
				celdaXLS.setCellValue(columna);
				hojaXLS.setColumnWidth(z, ((columna.length() + 10) * 512));
			}

			int i = 1;// numero de la fila desde la cual se itera...

			for (DetallePagoContratos icau : listaIcau) {
				filaXLS = hojaXLS.createRow(++i);
				z = 0;
				
				if (i <= 65000) { //por limitaciones de xls clasico
					//i++;
				
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(icau.getNumeroIcau());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(icau.getUuoo());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(icau.getNombCortPer());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(icau.getFechaNotificacionDesc());
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(icau.getFechaConformidadDesc());

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(icau.getdTranscurridoDesc());
				}
			}
			
			libroXLS.write(response.getOutputStream());
			response.getOutputStream().close();
			response.getOutputStream().flush();
			
			return modelAndView;
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
	}
	
	
	
	private List<?> consultarComprobantes(HttpServletRequest request, HttpServletResponse response) 
			throws ServiceException {
		
		try {

			//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			//SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			FormatoUtil formato = new FormatoUtil();
			
			String tipo = request.getParameter("tipo");
			String codiContCco = formato.formateaCadena(request.getParameter("codiContCco"));
			String numItem = formato.formateaCadena(request.getParameter("numItem"));
			String numeroEntrega = formato.formateaCadena(request.getParameter("numeroEntrega"));
			String numRegiCab = formato.formateaCadena(request.getParameter("numRegiCab"));
			
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("tipo", tipo);
			param.put("codiContCco", codiContCco);
			param.put("numItem", numItem);
			param.put("numeroEntrega", numeroEntrega);
			param.put("numRegiCab", numRegiCab);
			
			List<?> listaComprobantes = consultaExpedienteService.recuperarListaComprobantes(param);

			for (Object obj : listaComprobantes) {
				
				if (obj instanceof DocumentosCompras){					
					//campos de la lista a mostrar
					DocumentosCompras doc = (DocumentosCompras)obj;

					doc.setDescdocutpd(formato.formateaCadena(doc.getDescdocutpd()));
					doc.setSenudocudoc(formato.formateaCadena(doc.getSeridocudoc() + " - " + doc.getNumedocudoc()));
					doc.setSimbmonemon(formato.formateaCadena(doc.getSimbmonemon()));
					doc.setMontdocudocDesc(formato.formateaDecimal(doc.getMontdocudoc()));
				}
				else if (obj instanceof IsdpClasifSupu) {
					//campos de la lista a mostrar
					IsdpClasifSupu doc = (IsdpClasifSupu)obj;

					doc.setDescdocutpd(formato.formateaCadena(doc.getDescdocutpd()));
					doc.setSenudocudoc(formato.formateaCadena(doc.getSeridocudoc() + " - " + doc.getNumedocudoc()));
					doc.setSimbmonemon(formato.formateaCadena(doc.getSimbmonemon()));
					doc.setMontdocudocDesc(formato.formateaDecimal(doc.getMontdocudoc()));
				}
			}
			
			return listaComprobantes;
		}
		catch (Exception e) {
			log.error("Error" , e);
			throw new ServiceException (e);
		}
	}
	
	public ModelAndView recuperarComprobantes(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {

		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarComprobantes");
			
			List<?> listaComprobantes = this.consultarComprobantes(request, response);
			respuesta.put("listaComprobantes", listaComprobantes);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDetalleExpedientes");
		}
		
		return modelAndView;
	}
	
	public ModelAndView exportarComprobantes(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		ModelAndView modelAndView = null;
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		//String pagina = "";
		//String errorMessage = "";
		
		//ruc, razon social
		//String ruc = request.getParameter("ruc");
		//String razonSocial = request.getParameter("razonSocial");
		
		try {			
			List<?> listaComprobantes = this.consultarComprobantes(request, response);
			
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			String fechaFormateada = sdf.format(new Date());
			
			// 2. Proceso las solicitudes para su exportacion a excel:
			HSSFWorkbook libroXLS/* = null*/;
			HSSFSheet hojaXLS/* = null*/;
			HSSFRow filaXLS/* = null*/;
			HSSFCell celdaXLS/* = null*/;
			
			HSSFCellStyle estiloTit/* = null*/;
			HSSFFont fuenteTit/* = null*/;
			
			HSSFCellStyle estiloDat/* = null*/;
			HSSFFont fuenteDat/* = null*/;
			
			HSSFCellStyle estiloDatIzq/* = null*/;
			HSSFFont fuenteDatIzq/* = null*/;
			
			libroXLS = new HSSFWorkbook();
			
			fuenteTit = libroXLS.createFont();
			fuenteTit.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // En negrita
			fuenteTit.setFontHeight((short) 160);
			fuenteTit.setFontName("Arial");
			
			fuenteDat = libroXLS.createFont();
			fuenteDat.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDat.setFontHeight((short) 160);
			fuenteDat.setFontName("Arial");
			
			fuenteDatIzq = libroXLS.createFont();
			fuenteDatIzq.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); // Sin negrita
			fuenteDatIzq.setFontHeight((short) 160);
			fuenteDatIzq.setFontName("Arial");
			
			estiloTit = libroXLS.createCellStyle();
			estiloTit.setFont(fuenteTit);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloTit.setAlignment(HSSFCellStyle.ALIGN_CENTER);

			estiloDat = libroXLS.createCellStyle();
			estiloDat.setFont(fuenteDat);
			estiloDat.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDat.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDat.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			estiloDatIzq = libroXLS.createCellStyle();
			estiloDatIzq.setFont(fuenteDat);
			estiloDatIzq.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderRight(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setBorderTop(HSSFCellStyle.BORDER_THIN);
			estiloDatIzq.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			
			String nombreArchivo = "comprobantes_" + fechaFormateada + ".xls";
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/vnd.ms-excel");

			// Ahora procesamos el reporte en
			hojaXLS = libroXLS.createSheet("Firmas");

			filaXLS = hojaXLS.createRow((short) 1);
			
			String[] columnas = 
			{"Tipo Comprobante", "Nro. Comprobante", "Moneda", "Importe"};
			
			int z = 0;
			for (String columna : columnas) {
				celdaXLS = filaXLS.createCell(++z);
				celdaXLS.setCellStyle(estiloTit);
				celdaXLS.setCellValue(columna);
				hojaXLS.setColumnWidth(z, ((columna.length() + 10) * 512));
			}

			int i = 1;// numero de la fila desde la cual se itera...

			for (Object obj : listaComprobantes) {
				filaXLS = hojaXLS.createRow(++i);
				z = 0;
				
				if (i <= 65000) { //por limitaciones de xls clasico
					//i++;
				
					String descdocutpd = "";
					String senudocudoc = "";
					String simbmonemon = "";
					String montdocudocDesc = "";
					
					if (obj instanceof DocumentosCompras){					
						//campos de la lista a mostrar
						DocumentosCompras doc = (DocumentosCompras)obj;

						descdocutpd = doc.getDescdocutpd();
						senudocudoc = doc.getSenudocudoc();
						simbmonemon = doc.getSimbmonemon();
						montdocudocDesc = doc.getMontdocudocDesc();
					}
					else if (obj instanceof IsdpClasifSupu) {
						//campos de la lista a mostrar
						IsdpClasifSupu doc = (IsdpClasifSupu)obj;

						descdocutpd = doc.getDescdocutpd();
						senudocudoc = doc.getSenudocudoc();
						simbmonemon = doc.getSimbmonemon();
						montdocudocDesc = doc.getMontdocudocDesc();
					}
					
					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(descdocutpd);

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(senudocudoc);

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(simbmonemon);

					celdaXLS = filaXLS.createCell(++z);
					celdaXLS.setCellStyle(estiloDat);
					celdaXLS.setCellValue(montdocudocDesc);
				}
			}
			
			libroXLS.write(response.getOutputStream());
			response.getOutputStream().close();
			response.getOutputStream().flush();
			
			return modelAndView;
		}
		catch (Exception e) {
			log.error(e.getMessage(), e);
			
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
	}
	
	public ModelAndView recuperarSeguimientos(HttpServletRequest request, HttpServletResponse response)  throws ServiceException {

		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		//SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		FormatoUtil formato = new FormatoUtil();
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarDetalleExpedientes");
			
			String tipo = request.getParameter("tipo");
			String codiContCco = formato.formateaCadena(request.getParameter("codiContCco"));
			String numItem = formato.formateaCadena(request.getParameter("numItem"));
			String numeroEntrega = formato.formateaCadena(request.getParameter("numeroEntrega"));
			String numRegiCab = formato.formateaCadena(request.getParameter("numRegiCab"));
			
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("tipo", tipo);
			param.put("codiContCco", codiContCco);
			param.put("numItem", numItem);
			param.put("numeroEntrega", numeroEntrega);
			param.put("numRegiCab", numRegiCab);
			
			List<ExpedientesInternosAcciones> listaSeguimientos = consultaExpedienteService.recuperarListaSeguimientos(param);			
			
	 		//{name:'numSeguimiento',index:'numSegumiento',width:200, align:'center'},
			//{name:'modulo',index:'modulo',width:330, align:'center'},
			//{name:'descAcciAcc',index:'descAcciAcc',width:330, align:'center'},
			//{name:'nombCortPer',index:'nombCortPer',width:180, align:'center'},
			//{name:'fechInicAccDesc',index:'fechInicAccDesc',width:120, align:'center'},
			//{name:'fechTermAccDesc',index:'fechTermAccDesc',width:180, align:'center'},
			//{name:'obseTermAcc',index:'obseTermAcc',width:180, align:'center'},
			//{name:'descEstaEst',index:'descEstaEst',width:180, align:'center'}
			
			int i = 0;
			
			for (ExpedientesInternosAcciones seg : listaSeguimientos) {
				
				//campos de la lista a mostrar
				seg.setNumSeguimiento(++i);
				seg.setModulo(formato.formateaCadena(seg.getModulo()));
				seg.setDescAcciAcc(formato.formateaCadena(seg.getDescAcciAcc()));
				seg.setNombCortPer(formato.formateaCadena(seg.getNombCortPer()));
				seg.setFechInicAccDesc(formato.formateaFecha(seg.getFechInicAcc()));
				seg.setFechTermAccDesc(formato.formateaFecha(seg.getFechTermAcc()));
				seg.setObseTermAcc(formato.formateaCadena(seg.getObseTermAcc()));
				seg.setDescEstaEst(formato.formateaCadena(seg.getDescEstaEst()));
			}
			
			respuesta.put("listaSeguimientos", listaSeguimientos);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1");
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarDetalleExpedientes");
		}
		
		return modelAndView;
	}

	
	
	public String getJsonView() {
		return jsonView;
	}

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public JsonSerializer getJsonSerializer() {
		return jsonSerializer;
	}

	public void setJsonSerializer(JsonSerializer jsonSerializer) {
		this.jsonSerializer = jsonSerializer;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public ConsultaExpedienteService getConsultaExpedienteService() {
		return consultaExpedienteService;
	}

	public void setConsultaExpedienteService(
			ConsultaExpedienteService consultaExpedienteService) {
		this.consultaExpedienteService = consultaExpedienteService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(
			RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public ConsultaFirmaService getConsultaFirmaService() {
		return consultaFirmaService;
	}

	public void setConsultaFirmaService(ConsultaFirmaService consultaFirmaService) {
		this.consultaFirmaService = consultaFirmaService;
	}
}