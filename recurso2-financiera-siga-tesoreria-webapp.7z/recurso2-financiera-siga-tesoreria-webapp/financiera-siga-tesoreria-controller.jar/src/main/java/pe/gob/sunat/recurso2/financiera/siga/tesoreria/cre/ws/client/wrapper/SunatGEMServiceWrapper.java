package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.wrapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Detail;
import javax.xml.soap.DetailEntry;
import javax.xml.soap.SOAPFault;
import javax.xml.ws.soap.SOAPFaultException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.configuration.security.FiltersType;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.ConnectionType;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;

//import org.apache.ws.commons.schema.XmlSchemaCollection;
import org.apache.wss4j.dom.WSConstants;
import org.apache.wss4j.dom.handler.WSHandlerConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.BillService;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.ClientOutputInterceptor;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.billservice.StatusResponse;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.exception.ConstanciaException;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client.exception.WebserviceConfigurationException;
import pe.gob.sunat.recurso2.financiera.siga.tesoreria.util.RetencionConstantes;

public class SunatGEMServiceWrapper {
	
    // url del servicio web
    private String wsUrl;

    private String usuario;
    
	protected final Log log = LogFactory.getLog(getClass());

    public SunatGEMServiceWrapper(UsuarioSol usuarioSol, String wsUrl) {
        this.wsUrl = wsUrl;
        this.usuario = usuarioSol.rucUsuarioSOL();
        
    }

    public Response sendBill(String nombreArchivo, String rutaArchivo) {

        Response response;

        BillService client = initWebService();
        
        DataSource source = new FileDataSource(new File(rutaArchivo));
        
        try {
            byte[] constancia = client.sendBill(nombreArchivo, new DataHandler(source), null);

            try {
                //FileUtils.writeByteArrayToFile(new File("R" + nombreArchivo), constancia);
                FileUtils.writeByteArrayToFile(new File(RetencionConstantes.RUTA_TEMPORAL_ZIP + "R" + nombreArchivo), constancia);// PARA RECOJER
                
            } catch (IOException e) {
                log.error("error en el grabado de archivos", e);
            }
            return byteToResponse(constancia);

        } catch (SOAPFaultException e) {
            log.error("error en la invocacion", e);
        	response = SOAPFaultToResponse(e.getFault());
            return response;
        }
    }

    public Response sendSummary(String nombreArchivo, String rutaArchivo) {

        Response response;
        BillService client = initWebService();

        DataSource source = new FileDataSource(new File(rutaArchivo));
        try {
            String constancia = client.sendSummary(nombreArchivo, new DataHandler(source), null);

            return new Response(0, constancia, null, constancia);

        } catch (SOAPFaultException e) {
            log.error("error en la invocacion", e);
        	response = SOAPFaultToResponse(e.getFault());
            return response;
        }
    }

    public Response sendPack(String nombreArchivo, String rutaArchivo) {

	Response response;
	BillService client = initWebService();

	DataSource source = new FileDataSource(new File(rutaArchivo));
	try {
	    String constancia = client.sendPack(nombreArchivo, new DataHandler(source), null);

	    return new Response(0, constancia, null);

	} catch (SOAPFaultException e) {
        log.error("error en la invocacion", e);
		response = SOAPFaultToResponse(e.getFault());
	    return response;
	}
    }

    public Response getStatus(String ticket) {

        Response response;

        BillService client = initWebService();
        
        try {
            StatusResponse stResponse = client.getStatus(ticket);

            Integer inCode = new Integer(stResponse.getStatusCode()); 
            if(inCode.equals(98)) {
                return new Response(inCode, "La transaccion \"" + ticket + "\", aun se esta procesando", null);
            }
            
            
            if(inCode.equals(127)) {
                return new Response(inCode, "El ticket \"" + ticket +"\" no existe", null);
            }
            

            byte[] constancia = stResponse.getContent();
            
            try {
                FileUtils.writeByteArrayToFile(new File(ticket + ".zip"), constancia);
            } catch (IOException e) {
                log.error("error en el grabado de arfchivos", e);
            }
            return byteToResponse(constancia);

        } catch (SOAPFaultException e) {
            log.error("error en la invocacion", e);
        	response = SOAPFaultToResponse(e.getFault());
            return response;
        }
    }

    private BillService initWebService() {
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
        Map<String, Object> props = new HashMap<String, Object>();
        props.put("mtom-enabled", Boolean.FALSE);
        factory.setProperties(props);

        factory.setAddress(wsUrl);

        factory.setAddress(wsUrl);
        factory.getInInterceptors().add(new LoggingInInterceptor());
        factory.getOutInterceptors().add(new LoggingOutInterceptor());

        ClientOutputInterceptor co = new ClientOutputInterceptor();
        factory.getOutInterceptors().add(co);

        factory.setServiceClass(BillService.class);

        BillService client = (BillService) factory.create();

        try {
            configureSSLOnTheClient(client, usuario);
        } catch (WebserviceConfigurationException e1) {
        	log.error("Error", e1);
            throw new RuntimeException(e1);
        }
        return client;
    }


    private ResponseData searchResponse(ZipInputStream srcIs) throws IOException, ConstanciaException {

	ZipEntry entry = null;

	int countFile = 0;

	byte[] data = null;
	log.debug("srcIs (b): " + srcIs);
	log.debug("srcIs (c): " + srcIs.available());

	while (srcIs.available() == 1 && null != (entry = srcIs.getNextEntry())) {
		log.debug("srcIs (d): " + entry + " " + entry.getName() + " " + entry.getCompressedSize() + " " + entry.getSize());

	    if (entry.getName().endsWith(".xml") || entry.getName().endsWith(".XML")) {

		data = getFileResponse(srcIs);
		countFile++;
		break;
	    }

	    if (entry.getName().endsWith(".txt") || entry.getName().endsWith(".TXT")) {

		data = getFileResponse(srcIs);

		return new ResponseData(data, TipoArchivo.TXT);
	    }

	}

	if (countFile > 1) {
	    throw new ConstanciaException("La constancia de envio por lotes no tiene contancia de recpcion");
	}

	return new ResponseData(data, TipoArchivo.XML);
    }

    class ResponseData {
	byte[] data;
	// 0 XML, 1 TXT
	TipoArchivo tipo;

	ResponseData(byte[] data, TipoArchivo tipo) {
	    this.data = data;
	    this.tipo = tipo;
	}
    }

    public enum TipoArchivo {
	XML, TXT
    }

	private static byte[] getFileResponse(ZipInputStream srcIs) throws IOException {
	ByteArrayOutputStream destOs = new ByteArrayOutputStream();

	int count = 0;
	byte buffer[] = new byte[2048];
	while ((count = srcIs.read(buffer)) > 0) {
	    destOs.write(buffer, 0, count);
	}

	destOs.flush();

	byte[] data = destOs.toByteArray();

	destOs.close();

	destOs.close();

	srcIs.close();

	return data;

    }

    @SuppressWarnings("unused")
    private static byte[] unzip(byte[] data) throws ConstanciaException {
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            ZipInputStream srcIs = new ZipInputStream(bis);

            ByteArrayOutputStream destOs = new ByteArrayOutputStream();
            ZipEntry entry = null;
            while (null != (entry = srcIs.getNextEntry())) {
                if (entry.getName().endsWith(".xml")) {

                    int count = 0;
                    byte buffer[] = new byte[2048];
                    while ((count = srcIs.read(buffer)) > 0) {
                        destOs.write(buffer, 0, count);
                    }
                }

            }
            destOs.flush();
            byte[] b = destOs.toByteArray();
            destOs.close();

            destOs.close();
            srcIs.close();
            bis.close();
            return b;
        } catch (Exception e) {
            throw new ConstanciaException("Error al descomprimir la constancia", e);
        }
    }

    /**
     * @param data
     * @return
     * @throws ConstanciaException
     */
    private Document byteToDocument(byte[] data) throws ConstanciaException {

        InputStream ipEntrada = new ByteArrayInputStream(data);
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        try {
            Document doc = dbf.newDocumentBuilder().parse(ipEntrada);
            return doc;
        } catch (SAXException e) {
            throw new ConstanciaException("Error al leer la constancia", e);
        } catch (IOException e) {
            throw new ConstanciaException("Error al leer la constancia", e);
        } catch (ParserConfigurationException e) {
            throw new ConstanciaException("Error al leer la constancia", e);
        }
    }

    private Response byteToResponse(byte[] data) {
	int intCode = -1;

	try {
	    // descomprimimos el archivo

	    ByteArrayInputStream bis = new ByteArrayInputStream(data);

	    ZipInputStream srcIs = new ZipInputStream(bis);

	    ResponseData responseData = searchResponse(srcIs);

	    switch (responseData.tipo) {
	    case XML:
		return ResponseFromXmlFile(responseData.data);
		// break;

	    case TXT:
		return ResponseFromTxtFile(responseData.data);
		// break;

	    default:
		return new Response(intCode, "Tipo de archivo  de respuesta no soportado", null);
	    }

	} catch (ConstanciaException e) {
	    log.error("error", e);
	    return new Response(intCode, e.getMessage(), null);
	} catch (Exception e) {
	    log.error("error", e);
	    return new Response(intCode, "Error al momento de parsear la respuesta del comprobante: " + e.getMessage(),
		    null);
	}
    }

    private Response ResponseFromTxtFile(byte[] data) throws ConstanciaException {
	List<String> lstWarnings = new ArrayList<String>();

	return new Response(0, new String(data), lstWarnings);
    }

    private Response ResponseFromXmlFile(byte[] data) throws ConstanciaException {
	// leemos el archivo xml
	Document doc = byteToDocument(data);

	XPath xPath = XPathFactory.newInstance().newXPath();

	int intCode = -1;

	String mensaje = "Error al tratar de leer la respuesta";

	try {

	    String codigo = (String) xPath
		    .evaluate(
			    "/*[local-name()='ApplicationResponse']/*[local-name()='DocumentResponse']/*[local-name()='Response']/*[local-name()='ResponseCode']/text()",
			    doc.getDocumentElement(), XPathConstants.STRING);
	    mensaje = (String) xPath
		    .evaluate(
			    "/*[local-name()='ApplicationResponse']/*[local-name()='DocumentResponse']/*[local-name()='Response']/*[local-name()='Description']/text()",
			    doc.getDocumentElement(), XPathConstants.STRING);

	    // buscar warnings
	    NodeList warningsNode = (NodeList) xPath.evaluate(
		    "/*[local-name()='ApplicationResponse']/*[local-name()='Note']", doc.getDocumentElement(),
		    XPathConstants.NODESET);

	    List<String> lstWarnings = new ArrayList<String>();
	    for (int i = 0; i < warningsNode.getLength(); i++) {
		Node show = warningsNode.item(i);
		lstWarnings.add(show.getTextContent());
	    }

	    try {
		intCode = new Integer(codigo);
	    } catch (NumberFormatException ne) {
		throw new ConstanciaException(
			"El codigo de error informado en la constancia esta vacia o no es un valor valido: " + codigo,
			ne);
	    }

	    return new Response(intCode, mensaje, lstWarnings, data);

	} catch (XPathExpressionException e) {
	    log.error("error", e);
	    return new Response(intCode, e.getMessage(), null);
	}
    }

    @SuppressWarnings("unchecked")
    private Response SOAPFaultToResponse(SOAPFault soapFault) {

        String retCode = soapFault.getFaultCode();
        String mensaje = soapFault.getFaultString();
        Detail detalle = soapFault.getDetail();
        
        
        
        

        String[] code = retCode.split("\\.");
        int intCode = -1;

        try {
            
        	boolean isErrorFeGEM = StringUtils.isNumeric(code[code.length - 1]);
        	
        	boolean isErrorGreGEM = StringUtils.isNumeric(mensaje);
        	
        	if (isErrorFeGEM) {
        		intCode = new Integer(code[code.length - 1]);
        	} else if(isErrorGreGEM) {
        		intCode = new Integer(mensaje);
        		Iterator<DetailEntry> entries=detalle.getDetailEntries();
        		mensaje = "";
        	    while ( entries.hasNext() ) {
        	        DetailEntry newEntry = entries.next();
        	        mensaje = mensaje + "\n" + newEntry.getValue();
        	        log.debug("  Detail entry = " + mensaje);
        	    }
        	}
            
        } catch (Throwable e) {
            log.error("error", e);
            mensaje = "Ocurrio un error inesperado comuniquese con su administrador de red. " + mensaje;
        }

        return new Response(intCode, mensaje, null);
    }

    private void configureSSLOnTheClient(Object c, String usuario) throws WebserviceConfigurationException {
        org.apache.cxf.endpoint.Client client = ClientProxy.getClient(c);

        // Creating HTTP headers
        // Map<String, List<String>> headers = new HashMap<String,
        // List<String>>();
        // headers.put("Accept-Encoding", Arrays.asList("gzip","deflate"));
        //
        // // Add HTTP headers to the web service request
        // client.getRequestContext().put(Message.PROTOCOL_HEADERS, headers);

        HTTPConduit httpConduit = (HTTPConduit) client.getConduit();

        // try {
        TLSClientParameters tlsParams = new TLSClientParameters();
        tlsParams.setDisableCNCheck(true);

        /*POST https://www.sunat.gob.pe:443/ol-ti-itemision-otroscpe-gem/billService HTTP/1.1
        	Content-Length: 4755
        	Host: www.sunat.gob.pe:443
         */
        
        HTTPClientPolicy policy = new HTTPClientPolicy();
        policy.setAcceptEncoding("gzip,deflate");
        policy.setConnection(ConnectionType.KEEP_ALIVE);
        policy.setContentType("text/xml");
        policy.setConnectionTimeout(30000);//36000
        policy.setReceiveTimeout(180000);
        policy.setAllowChunking(false);// permitir partir el payload
        httpConduit.setClient(policy);

        // no validamos el certificado digital cambiar esta linea por un
        // TrustManager valido
         tlsParams.setTrustManagers( new TrustManager[]{ new
         SunatGEMServiceWrapper.TrustAllX509TrustManager() } );//sin truststore

        //tlsParams.setTrustManagers(getTrustManagers("truststore.jks"));//descomentar encaso se desee usar truststore
        //tlsParams.setTrustManagers(getTrustManagers("truststore.jks"));
        //tlsParams.setDisableCNCheck(true);

        FiltersType filter = new FiltersType();
        filter.getInclude().add(".*_EXPORT_.*");
        filter.getInclude().add(".*_EXPORT1024_.*");
        filter.getInclude().add(".*_WITH_DES_.*");
        filter.getInclude().add(".*_WITH_NULL_.*");
        filter.getExclude().add(".*_DH_anon_.*");
        tlsParams.setCipherSuitesFilter(filter);

        httpConduit.setTlsClientParameters(tlsParams);

        Map<String, Object> outProps = new HashMap<String, Object>();
        outProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
        // Specify our username
        outProps.put(WSHandlerConstants.USER, usuario);// outProps.put(WSHandlerConstants.USER,
                                                       // "2052362121ROCAFLO7");
        // Password type : plain text
        outProps.put(WSHandlerConstants.PASSWORD_TYPE, WSConstants.PW_TEXT);
        // Callback used to retrieve password for given user.
        outProps.put(WSHandlerConstants.PW_CALLBACK_CLASS, ClientePasswordCallback.class.getName());

        WSS4JOutInterceptor wsOut = new WSS4JOutInterceptor(outProps);
        client.getEndpoint().getOutInterceptors().add(wsOut);
    }

    /**
     * Obtine la lista de certificados validos para la transmision de datos a
     * traves de HTTPS
     * 
     * @return
     * @throws WebserviceConfigurationException
     */
    private TrustManager[] getTrustManagers(String truststorepath) throws WebserviceConfigurationException {
        try {
            //

            KeyStore keyStore = KeyStore.getInstance("JKS");
            String trustpass = "changeit";

            InputStream truststore = this.getClass().getClassLoader().getResourceAsStream(truststorepath);
	    // InputStream truststore =
	    // SunatGEMServiceWrapper.class.getClassLoader().getResourceAsStream(truststorepath);
            // InputStream truststore = new
            // FileInputStream("D:\\workspace\\FacturaElectronicaGEM-Client\\src\\main\\resources\\certs\\truststore.jks");

            if (truststore == null) {
                throw new WebserviceConfigurationException("no se encontro el archivo " + truststorepath);
            }

            keyStore.load(truststore, trustpass.toCharArray());
	    TrustManagerFactory trustFactory = TrustManagerFactory.getInstance(TrustManagerFactory
		    .getDefaultAlgorithm());
            trustFactory.init(keyStore);
            TrustManager[] tm = trustFactory.getTrustManagers();
            return tm;
            //
            // truststore = new File("certs\\wibble.jks");
            // keyStore.load(new FileInputStream(truststore),
            // trustpass.toCharArray());
            // KeyManagerFactory keyFactory =
            // KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            // keyFactory.init(keyStore, trustpass.toCharArray());
            // KeyManager[] km = keyFactory.getKeyManagers();
            // tlsParams.setKeyManagers(km);

            // FiltersType filter = new FiltersType();
            // filter.getInclude().add(".*_EXPORT_.*");
            // filter.getInclude().add(".*_EXPORT1024_.*");
            // filter.getInclude().add(".*_WITH_DES_.*");
            // filter.getInclude().add(".*_WITH_NULL_.*");
            // filter.getExclude().add(".*_DH_anon_.*");
            // tlsParams.setCipherSuitesFilter(filter);

        } catch (KeyStoreException kse) {
            log.error("Security configuration failed with the following: " + kse.getCause(), kse);
            throw new WebserviceConfigurationException("Security configuration failed", kse);
        } catch (NoSuchAlgorithmException nsa) {
        	log.error("Security configuration failed with the following: " + nsa.getCause(), nsa);
            throw new WebserviceConfigurationException("Security configuration failed", nsa);
        } catch (FileNotFoundException fnfe) {
        	log.error("Security configuration failed with the following: " + fnfe.getCause(), fnfe);
            throw new WebserviceConfigurationException("Security configuration failed", fnfe);
        } catch (java.security.cert.CertificateException ce) {
        	log.error("Security configuration failed with the following: " + ce.getCause(), ce);
            throw new WebserviceConfigurationException("Security configuration failed", ce);
        } catch (IOException ioe) {
        	log.error("Security configuration failed with the following: " + ioe.getCause(), ioe);
            throw new WebserviceConfigurationException("Security configuration failed", ioe);
        } catch (Exception e) {
            if (e instanceof WebserviceConfigurationException) {
                throw (WebserviceConfigurationException) e;
            }
            log.error("Security configuration failed with the following: " + e.getCause(), e);
            throw new WebserviceConfigurationException("Security configuration failed", e);
        }
    }

    /**
     * This class allow any X509 certificates to be used to authenticate the
     * remote side of a secure socket, including self-signed certificates.
     */
    public static class TrustAllX509TrustManager implements X509TrustManager {

        /** Empty array of certificate authority certificates. */
        private static final X509Certificate[] acceptedIssuers = new X509Certificate[] {};

        /**
         * Always trust for client SSL chain peer certificate chain with any
         * authType authentication types.
         * 
         * @param chain
         *            the peer certificate chain.
         * @param authType
         *            the authentication type based on the client certificate.
         */
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        /**
         * Always trust for server SSL chain peer certificate chain with any
         * authType exchange algorithm types.
         * 
         * @param chain
         *            the peer certificate chain.
         * @param authType
         *            the key exchange algorithm used.
         */
        public void checkServerTrusted(X509Certificate[] chain, String authType) {
        }

        /**
         * Return an empty array of certificate authority certificates which are
         * trusted for authenticating peers.
         * 
         * @return a empty array of issuer certificates.
         */
        public X509Certificate[] getAcceptedIssuers() {
            return (acceptedIssuers);
        }
    }

    /**
     * @author fjonislla representa a la lista de certificados que estan
     *         permitidos para dialogar con el servicio sunat factura
     *         electronica
     */
    public static class FActuraElectronicaTrustManager implements X509TrustManager {

        /** Empty array of certificate authority certificates. */
        private static final X509Certificate[] acceptedIssuers = new X509Certificate[] {};

        /**
         * Always trust for client SSL chain peer certificate chain with any
         * authType authentication types.
         * 
         * @param chain
         *            the peer certificate chain.
         * @param authType
         *            the authentication type based on the client certificate.
         */
        public void checkClientTrusted(X509Certificate[] chain, String authType) {
        }

        /**
         * Always trust for server SSL chain peer certificate chain with any
         * authType exchange algorithm types.
         * 
         * @param chain
         *            the peer certificate chain.
         * @param authType
         *            the key exchange algorithm used.
         */
        public void checkServerTrusted(X509Certificate[] chain, String authType) {
        }

        /**
         * Return an empty array of certificate authority certificates which are
         * trusted for authenticating peers.
         * 
         * @return a empty array of issuer certificates.
         */
        public X509Certificate[] getAcceptedIssuers() {
            return (acceptedIssuers);
        }
    }

}
