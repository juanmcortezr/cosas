//@javax.xml.bind.annotation.XmlSchema(
//		namespace = "http://service.sunat.gob.pe",
//		elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED/*,
//		xmlns = {
//				@javax.xml.bind.annotation.XmlNs(
//						prefix = "ns2",
//						namespaceURI="http://service.sunat.gob.pe")
//		}*/
//	)	

//@javax.xml.bind.annotation.XmlSchema(
//		namespace = "",
//		elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED
//	)

package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client;
