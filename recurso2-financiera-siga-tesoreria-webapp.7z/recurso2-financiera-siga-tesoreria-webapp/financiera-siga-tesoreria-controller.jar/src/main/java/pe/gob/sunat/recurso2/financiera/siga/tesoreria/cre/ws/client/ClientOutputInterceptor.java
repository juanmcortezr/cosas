package pe.gob.sunat.recurso2.financiera.siga.tesoreria.cre.ws.client;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.binding.soap.interceptor.SoapPreProtocolOutInterceptor;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

/**
 * http://www.mastertheboss.com/jboss-web-services/apache-cxf-interceptors
 * http://stackoverflow.com/questions/6915428/how-to-modify-the-raw-xml-message-of-an-outbound-cxf-request
 * 
 */
public class ClientOutputInterceptor extends AbstractPhaseInterceptor<Message> {

	protected final Log log = LogFactory.getLog(getClass());
	
    public ClientOutputInterceptor() {
        super(Phase.PRE_STREAM);
        addBefore(SoapPreProtocolOutInterceptor.class.getName());
    }

    public void handleMessage(Message message) {
        
    	boolean isOutbound = false;
        isOutbound = message == message.getExchange().getOutMessage()
                || message == message.getExchange().getOutFaultMessage();
        
        if (isOutbound) {
            OutputStream os = message.getContent(OutputStream.class);
            
            CachedStream cs = new CachedStream();
            message.setContent(OutputStream.class, cs);
            
            message.getInterceptorChain().doIntercept(message);
            
            try {
                cs.flush();
                IOUtils.closeQuietly(cs);
                CachedOutputStream csnew = (CachedOutputStream) message.getContent(OutputStream.class);
                
                String currentEnvelopeMessage = IOUtils.toString(csnew.getInputStream(), "UTF-8");
                csnew.flush();
                IOUtils.closeQuietly(csnew);
                
                log.debug("Outbound message: " + currentEnvelopeMessage);
                
                String res = currentEnvelopeMessage;
                
				res = changeName(res, "<sendBill xmlns=\"http://service.sunat.gob.pe\" xmlns:ns2=\"http://service.sunat.gob.pe\">", "<ns2:sendBill xmlns:ns2=\"http://service.sunat.gob.pe\">");
				res = changeName(res, "</sendBill>", "</ns2:sendBill>");

				res = changeName(res, "<sendSummary xmlns=\"http://service.sunat.gob.pe\" xmlns:ns2=\"http://service.sunat.gob.pe\">", "<ns2:sendSummary xmlns:ns2=\"http://service.sunat.gob.pe\">");
				res = changeName(res, "</sendSummary>", "</ns2:sendSummary>");

				res = changeName(res, "<getStatus xmlns=\"http://service.sunat.gob.pe\" xmlns:ns2=\"http://service.sunat.gob.pe\">", "<ns2:getStatus xmlns:ns2=\"http://service.sunat.gob.pe\">");
				res = changeName(res, "</getStatus>", "</ns2:getStatus>");
				
                if (res != null) {
                	log.debug("Outbound message has been changed: " + res);
                }
                res = res != null ? res : currentEnvelopeMessage;

                InputStream replaceInStream = IOUtils.toInputStream(res, "UTF-8");

                IOUtils.copy(replaceInStream, os);
                replaceInStream.close();
                IOUtils.closeQuietly(replaceInStream);

                os.flush();
                message.setContent(OutputStream.class, os);
                IOUtils.closeQuietly(os);

            } catch (IOException ioe) {
                //getLogger().warn("Unable to perform change.", ioe);
            	log.error("error", ioe);
                throw new RuntimeException(ioe);
            }
        } else {
            try {
                InputStream is = message.getContent(InputStream.class);
                String currentEnvelopeMessage = IOUtils.toString(is, "UTF-8");
                IOUtils.closeQuietly(is);

                log.debug("Inbound message: " + currentEnvelopeMessage);

                String res = currentEnvelopeMessage;
                log.debug("Inbound message has been changed: " + res);
                res = res != null ? res : currentEnvelopeMessage;

                is = IOUtils.toInputStream(res, "UTF-8");
                message.setContent(InputStream.class, is);
                IOUtils.closeQuietly(is);
            } catch (IOException ioe) {
                //getLogger().warn("Unable to perform change.", ioe);
            	log.error("error", ioe);
                throw new RuntimeException(ioe);
            }
        }
    }

	private String changeName(String soapMessage, String oldString, String newString) {
		soapMessage = soapMessage.replaceAll(oldString, newString);
		log.debug("After change message is " + soapMessage);
		return soapMessage;
	}
    
    public void handleFault(Message message) {
    }

    private class CachedStream extends CachedOutputStream {
        public CachedStream() {
            super();
        }

        protected void doFlush() throws IOException {
            currentStream.flush();
        }

        protected void doClose() throws IOException {
        }

        protected void onWrite() throws IOException {
        }        
    }
}

/*
public class ClientInInterceptor extends AbstractPhaseInterceptor<SoapMessage> {

	public ClientOutInterceptor() {
		super(Phase.RECEIVE);
	}

	public void handleMessage(SoapMessage message) {
		log.debug("outcoming message " + message);
		message.put(Message.ENCODING, "UTF-8");
		InputStream is = message.getContent(InputStream.class);
		//InputStream is = message.getContent(OutputStream.class);
		log.debug("mensaje en flujo: " + is + os);

		if (is != null) {
			CachedOutputStream bos = new CachedOutputStream();
			try {
				IOUtils.copy(is, bos);
				String soapMessage = new String(bos.getBytes());
				log.debug("-------------------------------------------");
				log.debug("outcoming message is " + soapMessage);
				log.debug("-------------------------------------------");
				bos.flush();
				message.setContent(InputStream.class, is);

				is.close();
				InputStream inputStream = new ByteArrayInputStream(changeName(
						soapMessage, "<ns2:sendBill", "<ns3:sendBill").getBytes());
				message.setContent(InputStream.class, inputStream);
				inputStream = new ByteArrayInputStream(changeName(
						soapMessage, "</ns2:sendBill", "</ns3:sendBill").getBytes());
				message.setContent(InputStream.class, inputStream);
				bos.close();
			} catch (IOException ioe) {
            	log.error("error", ioe);
			}
		}
	}

	private String changeName(String soapMessage, String oldString, String newString) {
		soapMessage = soapMessage.replaceAll(oldString, newString);
		log.debug("After change message is " + soapMessage);
		return soapMessage;
	}
}*/