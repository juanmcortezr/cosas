// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  //url_base_maestro: "http://10.230.168.222:7800/v2/iqbf/registro/maestros/t",
  //url_base_accion_control: "http://10.230.168.222:7800/v2/iqbf/fiscalizacion/accionescontrol/t"
  url_base_maestro: "http://localhost:7003/cl-ti-iamaestros-ws",
  url_base_accion_control: "http://localhost:7003/cl-ti-iaaccionescontrol-ws"
};
// export const environment = {
//   production: true,
//   url_base_maestro: "http://10.230.168.222:7003/cl-ti-iamaestros-ws",
//   url_base_accion_control: "http://10.230.168.222:7003/cl-ti-iaaccionescontrol-ws"
// };

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
