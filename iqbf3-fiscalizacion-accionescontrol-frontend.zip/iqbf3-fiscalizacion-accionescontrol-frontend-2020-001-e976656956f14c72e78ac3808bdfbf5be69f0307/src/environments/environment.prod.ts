export const environment = {
  production: true,
  url_base_maestro: "http://api.sunat.peru/v2/iqbf/registro/maestros/t",
  url_base_accion_control: "http://api.sunat.peru/v2/iqbf/fiscalizacion/accionescontrol/t"
  //url_base_maestro: "http://10.230.168.223:7003/cl-ti-iamaestros-ws",
  //url_base_accion_control: "http://10.230.168.223:7003/cl-ti-iaaccionescontrol-ws"
};

