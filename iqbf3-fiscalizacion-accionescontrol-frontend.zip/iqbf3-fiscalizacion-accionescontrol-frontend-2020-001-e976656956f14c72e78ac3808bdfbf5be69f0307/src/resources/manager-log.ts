const optsInfo = {
    logDirectory: './logs',
    fileNamePattern: 'info-<DATE>.log',
    dateFormat: 'YYYY.MM.DD'
};

const optsError = {
    logDirectory: './logs',
    fileNamePattern: 'error-<DATE>.log',
    dateFormat: 'YYYY.MM.DD'
};

export const logger = require('simple-node-logger').createRollingFileLogger(optsInfo);
export const logErr = require('simple-node-logger').createRollingFileLogger(optsError);
