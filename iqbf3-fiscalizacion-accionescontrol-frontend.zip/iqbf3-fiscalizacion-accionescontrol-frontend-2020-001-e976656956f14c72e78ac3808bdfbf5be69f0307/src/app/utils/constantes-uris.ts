import { environment } from 'src/environments/environment';

export class ConstantesUris {

    /**
     * URL Catalogo
     */
    static URI_CATALOGO = environment.url_base_maestro + '/catalogo';
    static URI_UBIGEO = environment.url_base_maestro + '/ubigeo';
    static URI_SERVICIO_WEB = environment.url_base_maestro + '/servicioweb';
    static URI_ASIGNACION_MASIVA_ORDEN = environment.url_base_accion_control + '/asignacionmasivaorden';
    static URI_ASIGNACION_MASIVA = environment.url_base_accion_control + '/asignacionmasiva';
    static URI_ASIGNACION_SOLICITUD = environment.url_base_accion_control + '/asignacionsolicitud';
    static URI_ASIGNA_REASIGNA_AUDITOR = environment.url_base_accion_control + '/asignareasignaauditor';
    static URI_CALIFICACION_SOLICITUD = environment.url_base_accion_control + '/calificacionsolicitud';
    static URI_CANCELACION_ORDEN = environment.url_base_accion_control + '/cancelacionorden';
    static URI_COMPLETAR_INFORME = environment.url_base_accion_control + '/completarinforme';
    static URI_CONSULTA_PROGRAMACION = environment.url_base_accion_control + '/consultaprogramacion';
    static URI_CONSULTA_SOLICITUD = environment.url_base_accion_control + '/consultasolicitud';
    static URI_DERIVACION_ORDEN = environment.url_base_accion_control + '/derivacionorden';
    static URI_EVALUACION_PROGRAMA = environment.url_base_accion_control + '/evaluacionprograma';
    static URI_EVALUACION_RESULTADO = environment.url_base_accion_control + '/evaluacionresultado';
    static URI_EVALUACION_SOLICITUD = environment.url_base_accion_control + '/evaluacionsolicitud';
    static URI_GESTION_PROGRAMA_ASIGNADO = environment.url_base_accion_control + '/gestionprogramaasignado';
    static URI_GESTION_PROGRAMA_DEFINIDO = environment.url_base_accion_control + '/gestionprogramadefinido';
    static URI_GESTION_PROGRAMA_OTROS = environment.url_base_accion_control + '/gestionprogramaotros';
    static URI_GESTION_SOLICITUD = environment.url_base_accion_control + '/gestionsolicitud';
    static URI_MANTENIMIENTO_CRITERIO = environment.url_base_accion_control + '/mantenimientocriterio';
    static URI_MANTENIMIENTO_PROGRAMA = environment.url_base_accion_control + '/mantenimientoprograma';
    static URI_REASIGNACION_PROGRAMA = environment.url_base_accion_control + '/reasignacionprograma';
    static URI_REGISTRO_RESULTADO = environment.url_base_accion_control + '/registroresultado';
    static URI_STATUS = environment.url_base_accion_control + '/status';
    static URI_COMUN = environment.url_base_accion_control + '/comun';

    //cus11
    static URI_ASIGNACION_MASIVA_AUDITOR = environment.url_base_accion_control + '/asignacionmasivaauditor';
    //cus11

    // Descarga de archivo
    static URL_DESCARGA_ARCHIVO = `${ConstantesUris.URI_COMUN}/descargarArchivo/`;
}
