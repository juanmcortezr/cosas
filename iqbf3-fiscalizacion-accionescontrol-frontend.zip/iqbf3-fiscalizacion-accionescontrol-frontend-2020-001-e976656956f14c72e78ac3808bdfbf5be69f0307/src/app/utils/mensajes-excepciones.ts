export class MensajesExcepciones {
    // CUS01
    static CUS01_EXCP_001 = 'Debe ingresar al menos un criterio de b\u00fasqueda';
    static CUS01_EXCP_002 = 'El n\u00famero de documento ingresado es incorrecto';
    static CUS01_EXCP_003 = 'Campo obligatorio';
    static CUS01_EXCP_004 = 'Debe ingresar al menos un usuario';
    static CUS01_EXCP_005 = 'Debe ingresar los datos de usuario se\u00f1alados';
    static CUS01_EXCP_006 = 'Debe completar los campos: direcci\u00f3n, departamento, provincia y distrito';
    static CUS01_EXCP_007 = 'Debe completar las respuestas de los criterios de calificaci\u00f3n';
    static CUS01_EXCP_008 = 'El periodo final debe ser mayor o igual al periodo inicio';
    static CUS01_EXCP_009 = 'Debe adjuntar el documento de referencia';
    static CUS01_EXCP_010 = 'El periodo inicio debe ser menor o igual al periodo fin';
    static CUS01_EXCP_011 = 'Los datos medio probatorio son inv\u00e1lidos';
    static CUS01_EXCP_012 = 'El n\u00famero documento es incorrecto';
    static CUS01_EXCP_013 = 'Debe ingresar la fecha y hora de visita sugerida';
    static CUS01_EXCP_014 = 'Debe seleccionar al menos una inconsistencia y un tipo de bien para el usuario';
    static CUS01_EXCP_017 = 'Ha seleccionado el tipo de bien insumo, debe seleccionar un insumo';
    static CUS01_EXCP_018 = 'Ha seleccionado el tipo de bien combustible, debe seleccionar un combustible';
    static CUS01_EXCP_019 = 'El usuario ya se encuentra en la solicitud';

    // CUS02
    static CUS02_EXCP_002 = 'El n\u00famero de documento ingresado es incorrecto';
    static CUS02_EXCP_003 = 'Debe ingresar un sustento para la devoluci\u00f3n';

    // CUS03
    static CUS03_EXCP_001 = 'Debe ingresar al menos un criterio de b\u00fasqueda';

    // CUS04
    static CUS04_INFO_GUARDAR = 'No ha guardado la calificaci\u00f3n para el usuario actual';
    static CUS04_EXCP_003 = 'Debe calificar a todos los usuarios para enviar';
    static CUS04_EXCP_004 = 'Debe ingresar un sustento para el cambio de la acci\u00f3n sugerida';
    static CUS04_EXCP_006 = 'No ha respondido todos los criterios para la calificaci\u00f3n del usuario';

    // CUS05
    static CUS05_EXCP_003 = 'El nombre ingresado es muy corto';
    static CUS05_EXCP_004 = 'El rango m\u00e1ximo de consulta es un a\u00f1o';
    static CUS05_EXCP_005 = 'La fecha hasta debe ser mayor o igual que la fecha desde';

    // CUS06
    static CUS06_EXCP_001 = 'La fecha hasta debe ser mayor o igual que la fecha desde';
    static CUS06_EXCP_002 = 'La fecha desde debe ser menor o igual que la fecha hasta';
    static CUS06_EXCP_003 = 'La fecha hasta debe ser menor o igual a la fecha actual';
    static CUS06_EXCP_004 = 'Debe de ingresar al menos un criterio de b\u00fasqueda';
    static CUS06_EXCP_005 = 'El periodo fin debe ser mayor o igual al periodo inicio';
    static CUS06_EXCP_006 = 'El periodo inicio debe ser menor o igual al periodo fin';
    static CUS06_EXCP_007 = 'El periodo fin debe ser menor o igual al periodo actual';
    static CUS06_EXCP_010 = 'Ha seleccionado el tipo de bien insumo, debe seleccionar un insumo';
    static CUS06_EXCP_011 = 'Ha seleccionado el tipo de bien combustible, debe seleccionar un combustible';

    // CUS07
    static CUS07_EXCP_006 = 'El archivo a adjuntar debe ser de formato Excel';
    static CUS07_EXCP_007 = 'El tama\u00f1o permitido es mayor a 0MB y menor o igual a 2MB';

    // CUS09
    static CUS09_EXCP_001 = 'El archivo a adjuntar debe ser de formato PDF';
    static CUS09_EXCP_005 = 'Debe seleccionar una opci\u00f3n y el valor a actualizar';
    static CUS09_EXCP_010 = 'El archivo a adjuntar debe ser de formato PDF o EXCEL';

    // CUS10
    static CUS10_EXCP_001 = 'Debe ingresar al menos un criterio de b\u00fasqueda';
    static CUS10_EXCP_002 = 'Campo obligatorio';

    // CUS11
    static CUS11_EXCP_001 = 'La fecha hasta debe ser mayor o igual que la fecha desde';
    static CUS11_EXCP_002 = 'La fecha desde debe ser menor o igual que la fecha hasta';
    static CUS11_EXCP_003 = 'La fecha hasta debe ser menor o igual a la fecha actual';
    static CUS11_EXCP_006 = 'Debe seleccionar al menos un registro';

    // CUS13
    static CUS13_EXCP_002 = 'Debe seleccionar un auditor o un agente de puesto de control';
    static CUS13_EXCP_003 = 'Debe seleccionar al menos un auditor de apoyo';

    // CUS14
    static CUS14_EXCP_001 = 'La fecha hasta debe ser mayor o igual que la fecha desde';
    static CUS14_EXCP_002 = 'La fecha desde debe ser menor o igual que la fecha hasta';
    static CUS14_EXCP_003 = 'La fecha hasta debe ser menor o igual a la fecha actual';
    static CUS14_EXCP_004 = 'Debe ingresar al menos un criterio de b\u00fasqueda';
    static CUS14_EXCP_006 = 'El n\u00famero de documento se encuentra registrado en otra acci\u00f3n';
    static CUS14_EXCP_007 = 'Solo se puede registrar un solo documento asociado a la acci\u00f3n';
    static CUS14_EXCP_010 = 'La fecha notificaci\u00f3n debe ser mayor o igual que la fecha emisi\u00f3n';
    static CUS14_EXCP_011 = 'La fecha emisi\u00f3n debe ser menor o igual que la fecha notificaci\u00f3n';
    static CUS14_EXCP_012 = 'La fecha notificaci\u00f3n debe ser menor o igual a la fecha actual';
    static CUS14_EXCP_013 = 'Se debe registrar el documento de la acci\u00f3n';
    static CUS14_EXCP_014 = 'La cantidad de d\u00edas para atenci\u00f3n debe ser mayor a 0';
    static CUS14_EXCP_015 = 'El formato de la fecha debe ser DD/MM/YYYY';
    static CUS14_EXCP_016 = 'Todas las acciones deben tener el documento principal de la acci\u00f3n';

    // CUS16
    static CUS16_EXCP_001 = 'La fecha hasta debe ser mayor o igual que la fecha desde';
    static CUS16_EXCP_002 = 'La fecha desde debe ser menor o igual que la fecha hasta';
    static CUS16_EXCP_003 = 'La fecha hasta debe ser menor o igual a la fecha actual';
    static CUS16_EXCP_004 = 'Debe ingresar al menos un criterio de b\u00fasqueda';
    static CUS16_EXCP_005 = 'Debe seleccionar al menos un registro';

    // CUS18
    static CUS18_EXCP_003 = 'El rango de fechas ingresado es invalido';
    static CUS18_EXCP_004 = 'Debe ingresar un sustento para el resultado de inconsistencia definitivo seleccionado';
    static CUS18_EXCP_005 = 'Debe seleccionar un resultado para la acci\u00f3n';
    static CUS18_EXCP_006 = 'Debe seleccionar al menos un detalle de resultado';
    static CUS18_EXCP_007 = 'Debe ingresar una descripci\u00f3n para el detalle de otros';
    static CUS18_EXCP_008 = 'La fecha ingresada debe ser mayor que la fecha de inicio de caso';
    static CUS18_EXCP_009 = 'La fecha ingresada debe ser mayor que la fecha de la primera visita';
    static CUS18_EXCP_010 = 'Debe ingresar la fecha de inicio de caso';
    static CUS18_EXCP_011 = 'Debe ingresar la fecha de la primera visita';
    static CUS18_EXCP_012 = 'Debe ingresar la fecha de la segunda visita';
    static CUS18_EXCP_013 = 'Debe ingresar un sustento para ejecuci\u00f3n';
    static CUS18_EXCP_014 = 'Debe ingresar la fecha de la solicitud de pr\u00f3rroga';
    static CUS18_EXCP_015 = 'Debe ingresar la nueva fecha de inicio de caso';
    static CUS18_EXCP_016 = 'Debe ingresar un sustento para la recomendaci\u00f3n';
    static CUS18_EXCP_017 = 'Debe ingresar un sustento para el resultado de la inconsistencia';
    static CUS18_EXCP_018 = 'Debe seleccionar el resultado de la acci\u00f3n';
    static CUS18_EXCP_019 = 'Debe seleccionar un detalle para el resultado de la acci\u00f3n';
    static CUS18_EXCP_020 = 'Debe ingresar una descripci\u00f3n de otros resultados de acci\u00f3n, si selecciono otro resultado de acci\u00f3n';
    static CUS18_EXCP_021 = 'Debe registrar al menos una tarea en el Registro de tiempos del Auditor/Agente';
    static CUS18_EXCP_022 = 'Debe registrar al menos un establecimiento en la secci\u00f3n Establecimientos';
    static CUS18_EXCP_023 = 'Debe adjuntar archivos en formato PDF o Word';
    static CUS18_EXCP_024 = 'Campo obligatorio';
    static CUS18_EXCP_025 = 'Debe ingresar los datos de Otros – establecimiento';
    static CUS18_EXCP_026 = 'Debe registrar la solicitud de neutralizaci\u00f3n';
    static CUS18_EXCP_027 = 'Debe registrar al menos un bien para el establecimiento';
    static CUS18_EXCP_028 = 'Debe ingresar un numero de acta';
    static CUS18_EXCP_029 = 'Debe ejecutar la verificaci\u00f3n de la inconsistencia antes de enviar';

    // CUS19
    static CUS19_EXCP_003 = 'Debe seleccionar una opci\u00f3n para la evaluaci\u00f3n de la orden';
    static CUS19_EXCP_004 = 'Debe ingresar un sustento para devolver la orden';

    // CUS20
    static CUS20_EXCP_001 = 'Debe ingresar al menos un criterio de b\u00fasqueda';

    // CUS22
    static CUS22_MENSAJE_F2_01 = 'No se han encontrado resultados de búsqueda';
    static CUS22_MENSAJE_F2_02 = 'Ocurrio un Error';
    static CUS22_EXCP_001 = 'La fecha hasta debe ser mayor o igual que la fecha desde';
    static CUS22_EXCP_002 = 'La fecha desde debe ser menor o igual que la fecha hasta';
    static CUS22_EXCP_003 = 'La fecha hasta debe ser menor o igual a la fecha actual';
    static CUS22_EXCP_004 = 'Debe de ingresar al menos un criterio de b\u00fasqueda';
    static CUS22_EXCP_005 = 'El periodo inicio debe ser mayor o igual al periodo inicio';
    static CUS22_EXCP_006 = 'El periodo inicio debe ser menor o igual al periodo fin';
    static CUS22_EXCP_007 = 'El periodo fin debe ser menor o igual al periodo actual';
    static CUS22_EXCP_008 = 'Campo obligatorio';
    static CUS22_EXCP_009 = 'El archivo a adjuntar debe ser de formato PDF';
    static CUS22_EXCP_010 = 'El tama\u00f1o permitido es mayor a 0MB y menor o igual a 2MB';
    static CUS22_EXCP_011 = 'El plazo debe ser mayor a 0 d\u00edas de atenci\u00f3n';
    static CUS22_EXCP_012 = 'No se puede cancelar el programa de control, este ya fue utilizado para generar un Informe de selecci\u00d3n';
    static CUS22_EXCP_013 = 'La programaci\u00d3n no cuenta con usuario. Debe proceder a cancelar la programaci\u00d3n o verificar el motivo de depuraci\u00d3n';
    static CUS22_EXCP_014 = 'Existe una determinaci\u00d3n de usuarios en curso para el mismo programa de control. debe esperar que culmine para generar una nueva programaci\u00d3n';



    // CUS29

    static CUS29_EXCP_001 = 'Debe ingresar un criterio de b\u00fasqueda';
    static CUS29_EXCP_002 = 'El Nro. de programaci\u00f3n o informe de selecci\u00f3n no existe';
    static CUS29_EXCP_003 = 'El Nro. de programaci\u00f3n o informe de selección no corresponde a un programa definido';
    static CUS29_EXCP_004 = 'La programaci\u00f3n o informe de selecci\u00f3n no corresponde a un programador de su supervisi\u00f3n';
    static CUS29_EXCP_005 = 'No existen ordenes en estado “Pendiente”';
    static CUS29_EXCP_006 = 'Se debe seleccionar al menos un auditor';
    static CUS29_EXCP_007 = 'Existe un proceso de asignaci\u00f3n en curso para la programaci\u00f3n';
    static CUS29_EXCP_008 = 'Debe agregar al menos un auditor para realizar la asignaci\u00f3n';


    // CUS30
    static CUS30_EXCP_001 = 'Campos Obligatorios';
    static CUS30_EXCP_002 = 'La sumatoria de los pesos no debe exceder el 100%';
    static CUS30_EXCP_003 = 'Los puntajes ingresados se encuentran en el rango de una de acción sugerida registrada';
    static CUS30_EXCP_004 = 'La descripción de la acción sugerida ya existe';
    static CUS30_EXCP_005 = 'El puntaje de la alternativa ya existe';
    static CUS30_EXCP_SUMA_100 = 'La suma de los pesos debe ser igual al 100%';

    // CUS31
    static CUS31_EXCP_002 = 'Código de UUOO no existe, ingresar un código válido';

    // MENSAJES
    static MENSAJE_SIN_RESULTADO = 'No se ha encontrado resultados de b\u00fasqueda';
    static MENSAJE_GUARDAR_SOLICITUD = 'Se guard\u00f3 la solicitud con n\u00famero <SP-XXXX-YYYY-UUOO>';
    static MENSAJE_INFORMATIVO_ENVIAR = 'Se envi\u00f3 con \u00e9xito.';
    static MENSAJE_INFORMATIVO_GUARDAR = 'Se guard\u00f3 con \u00e9xito';
    static MENSAJE_INFORMATIVO_ANULAR = 'Se anul\u00f3 con \u00e9xito';
    static MENSAJE_GUARDAR_PROGRAMACION = 'Se ha creado con \u00e9xito la programaci\u00f3n Nro. <N\u00famero de programaci\u00f3n>';
    static MENSAJE_INFORMATIVO_ACTUALIZAR = 'Se actualiz\u00f3 con \u00e9xito';
    static MENSAJE_ENVIAR_INFORMESELECCION = 'Se envi\u00f3 el informe de selecci\u00f3n <<n\u00famero del informe de selecci\u00f3n>>';
    static MENSAJE_INFORMATIVO_ELIMINAR = 'Se elimin\u00f3 con \u00e9xito';
    static MENSAJE_AGREGAR_DOCUMENTO = 'El documento no existe en SINE';
    static MENSAJE_INFORMATIVO_DERIVAR = 'Se deriv\u00f3 con \u00e9xito';
    static MENSAJE_CANCELAR_ORDEN = 'Se cancel\u00f3 con \u00e9xito la orden';
    static MENSAJE_INFORMATIVO_CRITERIO = 'La suma de los pesos debe ser igual al 100%';
    static MENSAJE_CAMPOS_OBLIGATORIOS = 'Completar campos obligatorios';
    static MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS = 'Datos no guardados';
    static MENSAJE_INFORMATIVO_DATOS_NO_ELIMINADOS = 'Datos no eliminados';
    static MENSAJE_INFORMATIVO_DATOS_NO_ANULADOS = 'Datos no anulados';
    static MENSAJE_INFORMATIVO_DATOS_NO_ENVIADOS = 'Datos no enviados';
    static MENSAJE_INFORMATIVO_DATOS_NO_DERIVADOS = 'Datos no derivados';
    static MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO = 'No se ha obtenido resultados';
    static MENSAJE_INFORMATIVO_HUBO_ERRORES = 'Hubo errores';

}
