import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Constantes } from './constantes';
import * as moment from 'moment';
import { UsuarioBean } from '../models/usuarioBean.model';

export function trim(value: any): string {
    if (isEmpty(value)) {
        return '';
    }
    return value.toString().trim();
}

export function isEmpty(value: any): boolean {
    if (value == null || value == undefined) {
        return true;
    }
    if (value.__proto__.constructor === String) {
        return value.trim().length === 0;
    }
    if (value.__proto__.constructor === Array) {
        return value.length === 0;
    }
    if (value.__proto__.constructor === Object) {
        return Object.getOwnPropertyNames(value).length === 0;
    }
    return false;
}

export function isNotEmpty(value: any): boolean {
    return !isEmpty(value);
}

export function toNumber(value: any): number {
    if (isEmpty(value)) {
        return null;
    }
    return parseInt(value);
}

export function isNumber(value: any): value is number {
    return !isNaN(toNumber(value));
}

export function padNumber(value: number) {
    if (isNumber(value)) {
        return `0${value}`.slice(-2);
    } else {
        return '';
    }
}

export function stringToNgbDateStruct(value: string) : NgbDateStruct {
    if (isEmpty(value)) {
        return  null;
    }
    const date = value.split(Constantes.DELIMITER_DATE);
    return {
      day: parseInt(date[0], 10),
      month: parseInt(date[1], 10),
      year: parseInt(date[2], 10)
    };
}
export function ngbDateStructToString(date: NgbDateStruct) : string {
    if (isEmpty(date)) {
        return  '';
    }
    return `${padNumber(date.day)}${Constantes.DELIMITER_DATE}${padNumber(date.month)}${Constantes.DELIMITER_DATE}${date.year}`;
}

export function dateToString(date: Date, format:string): string {
    return moment(date).format(format);
}

export function stringToDate(date: string, format:string): Date {
    return moment(date, format).toDate();
}

export function stringToMoment(date: string, format:string): moment.Moment {
    return moment(date, format);
}

export function dateToStringDDMMYYYY(date: Date): string {
    return dateToString(date, Constantes.FORMAT_FECHA_DDMMYYYY);
}
export function stringToDateDDMMYYYY(date: string): Date {
    return stringToDate(date, Constantes.FORMAT_FECHA_DDMMYYYY);
}

export function stringToMomentDDMMYYYY(date: string): moment.Moment {
    return stringToMoment(date, Constantes.FORMAT_FECHA_DDMMYYYY);
}

export function compareTwoDates(strDateHigh: string, strDateLow: string): number {
    const dateLow = stringToMomentDDMMYYYY(strDateLow);
    dateLow.set({hour: 0, minute: 0, second: 0, millisecond: 0});
    const dateHigh = stringToMomentDDMMYYYY(strDateHigh);
    dateHigh.set({hour: 0, minute: 0, second: 0, millisecond: 0});
    if (dateLow.isBefore(dateHigh)) {
        return 1;
    } else if (dateLow.isAfter(dateHigh)) {
        return -1;
    } else if (dateLow.isSame(dateHigh)) {
        return 0;
    }
    return null;
}

export function formatDatePeriodoFront(value: any): Object {
    if (isEmpty(value)) {
        return {year: '0000', month: '00'};
    }
    return {year: value.slice(0,4), month: value.slice(4,6)};
}

export function formatDatePeriodoBack(value: any): string {
    if (isEmpty(value)) {
        return '000000';
    }
    return `${value.year}${padNumber(value.month)}`;
}

export function formatHoraFront(value: any): Object {
    if (isEmpty(value)) {
        return {hour: 0, minute: 0, second: 0};
    }
    return {hour: toNumber(value.slice(0,2)), minute: toNumber(value.slice(3,5)), second: toNumber(value.slice(6,8))};
}

export function formatHoraBack(value: any): string {
    if (isEmpty(value)) {
        return '00:00:00';
    }
    return `${padNumber(value.hour)}:${padNumber(value.minute)}:${padNumber(value.second)}`;
}

export function formatUbigeo(value: any, opcionUbigeo: string): string {
    let result: string = '';
    if (isEmpty(value)) {
        return '';
    }

    if(opcionUbigeo == Constantes.UBIGEO_DEPARTAMENTO){
        result = value.slice(0,2);
    }else if(opcionUbigeo == Constantes.UBIGEO_PROVINCIA){
        result = value.slice(2,4);
    }else if(opcionUbigeo == Constantes.UBIGEO_DISTRITO){
        result = value.slice(4,6);
    }

    return result;
}

export function getFechaActual(format: string): string {
    let fecha: Date = new Date();
    if(format == Constantes.FORMAT_FECHA_DDYYYYMM){
        return `${padNumber(fecha.getDate())}/${padNumber(fecha.getMonth() + 1)}/${fecha.getFullYear()}`;
    }
    return '';
}

export function getAnioActual(): number {
    let fecha: Date = new Date();
    return fecha.getFullYear();
}

export function obtenerUsuarioBean(): UsuarioBean {
    let usuario: UsuarioBean = JSON.parse(sessionStorage.getItem('usuarioBeanJSON'));
    return usuario;
}

export function getMomentActual(): string {
    return dateToString(new Date(), Constantes.FORMAT_FECHA_DDMMYYYY);
}
