export class Correos {

    alias: string;
    codpers: string;
    smtp: string;

}