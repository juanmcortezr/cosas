export class ProgramaIncosistenciaGreNC {
    codCpe: string;
    desCpe: string;
    fecEmision: string;
    numCpe: number;
    numIncoGre: number;
    numRuc: string;
    numSerieCpe: string;
    numProgramacion: number;
}