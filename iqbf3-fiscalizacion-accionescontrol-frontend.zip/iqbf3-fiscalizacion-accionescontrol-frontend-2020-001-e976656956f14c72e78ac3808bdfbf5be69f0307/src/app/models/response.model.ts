export class Response {
    exito: boolean;
    mensaje: string;
    data : any;
}