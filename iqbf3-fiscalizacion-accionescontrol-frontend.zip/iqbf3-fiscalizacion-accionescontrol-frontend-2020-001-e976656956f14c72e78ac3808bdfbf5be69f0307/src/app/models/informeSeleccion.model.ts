import { ArchivoBean } from './archivoBean.model';

export class InformeSeleccion {
    anioInforme: number;
    codEstadoInforme: string;
    codUnidadOrganica: string;
    desEstadoInforme: string;
    desUnidadOrganica: string;
    numCorrel: number;
    numInformeSeleccion: number;
    numProgramacion: number;
    archivoInforme: ArchivoBean;
    archivoReporte: ArchivoBean;

}