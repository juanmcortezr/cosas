export class BienFiscalizadoSolicitud {

    codBienFiscalizado: string;
    codTipoBien: string;
    desOtroTipobien: string;
    desBienFisca: string;
    desTipoBien: string;
    numBienFiscaSolicitud: number;
    numSolicitud: number;

    //Ini extra
	seleccionado?: boolean;
	//fin extra

}
