import { trim, isNotEmpty } from '../utils/utilitarios';

export class AsignacionMasivaAuditoresPrincipales {

    numProgramacion: number;
    desAlcanceProgramacion:string;
    codEstadoProgramacion:string;
    desEstadoProgramacion:string;
    fechaProgramacionDesde:string;
    fechaProgramacionHasta:string;
    numInformeSeleccion: string;
    codEstadoInformeSeleccion: string;
    desEstadoInformeSeleccion: string;
    desProgramador:string;

    codProgramaControl: number;
    desProgramaControl: string;

    fecProgramacion:string;
    fecPeriodoInicio:string;
    fecPeriodoFin:string;
    desProgramadorAsignado:string;
    desEstadoInforme:string;

    // filtroValido(): boolean {
    //     return isNotEmpty(this.numProgramacion) || isNotEmpty(this.desAlcanceProgramacion) || isNotEmpty(this.codEstadoProgramacion)
    //     || isNotEmpty(this.fechaProgramacionDesde) || isNotEmpty(this.fechaProgramacionHasta) || isNotEmpty(this.numInformeSeleccion)
    //     || isNotEmpty(this.codEstadoInformeSeleccion) || isNotEmpty(this.desProgramador);
    // }

    filtroValido(): boolean{
      return true;
    }
}
