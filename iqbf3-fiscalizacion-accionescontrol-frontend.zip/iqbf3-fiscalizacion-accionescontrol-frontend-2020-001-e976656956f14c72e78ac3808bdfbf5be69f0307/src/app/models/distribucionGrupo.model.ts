export class DistribucionGrupo {

    codCargo: string;
    codPersonal: string;
    fecFin: string;
    fecInicio: string;
    numDistribucionGrupo: number;
    numGrupo: number;

}