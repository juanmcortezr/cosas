export class ConfirmacionGre {

    codConfirmacion: number;
    codResultado: string;
    codTipo: string;
    codCpe: number;
    dirLlegada: string;
    fecConfirmacion: string;
    fecLlegada: string;
    numRucConfirmacion: string;
    numCpe: number;
    numRuc: number;
    numSerieCpe: number;
    obsConfirmacion: string;

}