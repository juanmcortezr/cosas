export class PerfilRiesgos {
    codCic: number;
    codPervagg: number;
    codTipoDocumentoIdent: number;
    fecCalculo: string;
    fecFinVigencia: string;
    fecInicioVigencia: string;
    indCalculo: string;
    indNivrie: number;
    numDocumentoIdentif: string;
    numScoreglobal: number;
}