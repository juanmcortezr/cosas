export class WSEstablecimientoAnexo {
    numSprCorrel: string;
    descTipest: string;
    direccion: string;
    codDepar: string;
    codProvi: string;
    codDist: string;
    codUbigeo: string; //Ubigeo composicion
    descDep: string; //Ubigeo composicion
    descProv: string; //Ubigeo composicion
    descDist: string; //Ubigeo composicion

    //Ini extra
    seleccionado?: boolean;
    //Ini extra
}