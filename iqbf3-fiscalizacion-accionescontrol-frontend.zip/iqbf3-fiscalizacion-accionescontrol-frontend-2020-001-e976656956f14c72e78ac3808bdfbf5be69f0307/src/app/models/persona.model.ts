export class Persona {
    codPers: string;
    nombreCompleto: string;
}