export class MovimientoProgramacion {
    codEstadoInforme: string;
    codEstadoPrograma: string;
    codPersonaMovimiento: string;
    desSusDevolucion: string;
    desEstadoInforme: string;
    desEstadoProgram: string;
    fecMovimiento: string;
    nomPersonal: string;
    numMovimientoPrograma: number;
    numProgramacion: number;
}