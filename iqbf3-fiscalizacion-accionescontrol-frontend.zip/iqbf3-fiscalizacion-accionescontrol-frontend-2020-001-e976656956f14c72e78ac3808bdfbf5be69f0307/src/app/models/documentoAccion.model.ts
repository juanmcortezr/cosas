import { ArchivoBean } from './archivoBean.model';

export class DocumentoAccion {

    codEstadoDocumento: string;
    codTipoDocumento: string;
    codClase: string;
    desClase: string;
    desEstadoDocumento: string;
    desTipoDocumento: string;
    fecEmision: string;
    fecNotificacion: string;
    numDocumento: string;
    numDocumentoAccion: number;
    numUsuarioPrograma: number;
    archivoBean: ArchivoBean;

}