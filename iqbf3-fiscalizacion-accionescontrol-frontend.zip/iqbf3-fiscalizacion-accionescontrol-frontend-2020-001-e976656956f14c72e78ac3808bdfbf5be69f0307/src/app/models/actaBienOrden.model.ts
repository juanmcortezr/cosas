export class ActaBienOrden {

    codTipoActa: string;
    codTipoDocumentoVinculado: string;
    codTipoInforme: string;
    desOtraActa: string;
    desOtroDocumentoinculado: string;
    desOtroInforme: string;
    desTipoActa: string;
    desTipoDocumentoVinculado: string;
    desTipoInforme: string;
    numActaBienOrden: number;
    numActa: string;
    numDocumentoVinculado: string;
    numBienEstablecimiento: number;

}