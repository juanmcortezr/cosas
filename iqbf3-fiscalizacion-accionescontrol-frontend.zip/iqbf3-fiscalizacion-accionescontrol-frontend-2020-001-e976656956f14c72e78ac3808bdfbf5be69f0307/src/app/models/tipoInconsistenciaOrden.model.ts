export class TipoInconsistenciaOrden {
    codOrigen: string;
    codResultadoInconsistencia: string;
    codTipoInconsistencia: string;
    desOtraInconsistencia: string;
    desSusInconsis: string;
    desOrigen: string;
    desResulInconsis: string;
    desTipoInconsistencia: string;
    numInconsistenciaOrden: number;
    numOrden: number;
}