export class ProgramaIncosistenciaSaldo {
    cantidadAutorizada: number;
    cantidadConsumida: number;
    cantidadDisponible: number;
    codBienFiscalizado: string;
    codInsumo: string;
    codTipprod: string;
    codUnidadMedida: string;
    desNombreComercial: string;
    desNombreProducto: string;
    desBienfisca: string;
    desInsumo: string;
    desTipoProducto: string;
    desUnidadMedida: string;
    numIncosistemciaSaldo: number;
    numInsumoCabecera: number;
    numOrden: string;
    numPeriodo: string;
    numReposicion: number;
    numVersionInsumo: number;
    numProgramacion: number;
    porMaxInsumo: number;
    porMinInsumo: number;
}