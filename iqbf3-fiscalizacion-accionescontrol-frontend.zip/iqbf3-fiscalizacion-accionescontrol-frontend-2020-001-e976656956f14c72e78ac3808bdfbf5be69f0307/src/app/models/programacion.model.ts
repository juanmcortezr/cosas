import { trim, isNotEmpty } from '../utils/utilitarios';
import { Constantes } from '../utils/constantes';
import { CheckElement } from './checkElement.model';
import { BienFiscalizadoSolicitud } from './bienFiscalizadoSolicitud.model';
import { ArchivoBean } from './archivoBean.model';

export class Programacion {

    anioProgramacion: number;
    codEstadoPrograma: string;
    codFuente: string;
    codProceso: string;
    codProgramador: string;
    codSubEstadoProgram: string;
    codTipoProgram: string;
    codProgramaControl: string;
    desAlcance: string;
    desOtraFuente: string;
    desProgramacion: string;
    desSusCancela: string;
    desEstadoProgram: string;
    desFuente: string;
    desProceso: string;
    desProgramaControl: string;
    desProgramador: string;
    desProgramadorAdministrativo: string;
    desSubEstprogram: string;
    desTipoProgram: string;
    fecProgramacion: string;
    indCierre: string;
    numInformeCancelacion: string;
    numPlazoVerificacion: string;
    numProgramaCorrel: number;
    numProgramacion: number;
    obsProgramacion: string;
    perFin: string ;
    perInicio: string;
    desInconsistecia:string;
    desRespInconsistencia:string;
    desTipoDocumentoIdent:string;
    numDocumentoIdent:string;
    nombApeUsuario:string;
    desTipoAccion:string;
    numDocAccion:string;
    desTipOrden:string;
    numOrden:string;
    desEstOrden:string;
    nombAuditAsignad:string;
    desResOrden:string;
    numDocVin:string;

    // Parametros filtro:
    fechaDesde: string;
    fechaHasta: string;
    numInforme: string;
    codEstadoInforme: string;
    desEstadoInforme: string;
    fecIniAsignacion: string;
    inconsistencias: CheckElement[];
    tipoBienes: CheckElement[];
    bienesFiscalizados: CheckElement[];
    actividades: CheckElement[];
    desOtroIncosistencia: string;
    desOtroBien: string;

    //Cus09 OPV
   
    codTipInterv: string ;
    desTipInterv: string ;    
    codTipoDocumentoIdent:string;
 
 
    numUsuarioPrograma:string;    

    //cus11
    numAsignacion: string;
    indTipoAsignacion: string;
    codCargo: string;
    codPersona: string;
    numUsuario: string;
    numGrupo: string;
    codTipoAccion: string;

    //cus14
    numAlcanceProgramacion:string;
    numInformeSeleccion:string;
    fecInicioAsignacion:string;
    fecFinASignacion:string;
    codProgramadorAsignado:string;

    tipoDocumento:string;
    numDocumento:string;
    tipoAccion:string;
    //cus14

    //cus 07
    archivoBean: ArchivoBean;


    //VARIABLES CUS 20
    nomProgramador: string;
    nomProgramadorAdministrativo: string;

    //VARIABLES CUS 22
    plazoVerificacion: string;

    //CUS 22
    constructor() { }

    static fromJSON(data: any) {
        return Object.assign(new this, data);
    }

    filtroValido(): boolean {
        return isNotEmpty(this.numProgramacion)
            || isNotEmpty(this.desAlcance)
            || isNotEmpty(this.codEstadoPrograma)
            || isNotEmpty(this.fechaDesde)
            || isNotEmpty(this.fechaHasta)
            || isNotEmpty(this.numInforme)
            || isNotEmpty(this.codEstadoInforme)
            || isNotEmpty(this.desProgramador);
    }

    filtroValidoIU061(): boolean {
        return isNotEmpty(this.numProgramaCorrel) || isNotEmpty(this.codEstadoPrograma)
        || isNotEmpty(this.fechaDesde) || isNotEmpty(this.fechaHasta) || isNotEmpty(this.codProgramadorAsignado) || isNotEmpty(this.codProgramaControl) ;
    }

    filtroValidoIU025(): boolean {
        return isNotEmpty(this.numProgramacion) || isNotEmpty(this.codProgramaControl) ||
        isNotEmpty(this.codEstadoPrograma) || isNotEmpty(this.numInforme) ||
        isNotEmpty(this.codEstadoInforme) || isNotEmpty(this.desProgramador);
    }

    filtroValidoIU035(): boolean {
        return isNotEmpty(this.numProgramacion) || isNotEmpty(this.numAlcanceProgramacion) || 
        isNotEmpty(this.numInformeSeleccion) || isNotEmpty(this.fechaDesde) || 
        isNotEmpty(this.fechaHasta) || isNotEmpty(this.desProgramador);
    }

    filtroValidoIU039(): boolean {
        return isNotEmpty(this.numProgramacion) || isNotEmpty(this.numAlcanceProgramacion) ||
        isNotEmpty(this.numInformeSeleccion) || isNotEmpty(this.fechaDesde) ||
        isNotEmpty(this.fechaHasta) || isNotEmpty(this.desProgramador);
    }

    nuevaProgramaValidoIU062(): boolean {
        return isNotEmpty(this.codProgramaControl) ||isNotEmpty(this.indCierre) || isNotEmpty(this.perInicio)
        || isNotEmpty(this.perFin) || isNotEmpty(this.fechaHasta) || isNotEmpty(this.codProgramadorAsignado)   ;
    }

    filtroValidoIU020(): boolean{
      return isNotEmpty(this.numProgramacion)
      || isNotEmpty(this.codProgramaControl)
      || isNotEmpty(this.numInformeSeleccion)
      || isNotEmpty(this.nomProgramador)
      || isNotEmpty(this.nomProgramadorAdministrativo)
      || isNotEmpty(this.codEstadoPrograma);
    }

    esAsignado(): boolean {
        return Constantes.COD_ESTADO_PROG_ASIGNADO === trim(this.codEstadoPrograma);
    }

    esPlanificado(): boolean {
        return Constantes.COD_ESTADO_PROG_PLANIFICADO === trim(this.codEstadoPrograma);
    }

    esAutorizado(): boolean {
        return Constantes.COD_ESTADO_PROG_AUTORIZADO === trim(this.codEstadoPrograma);
    }

    esErrorEnCarga(): boolean {
        return Constantes.COD_EST_PROGRAM_ERROR_CARGA == trim(this.codEstadoPrograma);
    }

    esEjecutada(): boolean {
        return Constantes.COD_EST_PROGRAM_EJECUTADO == trim(this.codEstadoPrograma);
    }

    esDevueltoSupervisor(): boolean {
        return Constantes.COD_EST_PROGRAM_DEVUELTO_SUPERVISOR == trim(this.codEstadoPrograma);
    }

    esSeleccionProcesada(): boolean {
        return Constantes.COD_EST_PROGRAM_SELECCION_PROCESADA == trim(this.codEstadoPrograma);
    }

    esProgramado(): boolean {
        return Constantes.COD_EST_PROGRAM_PROGRAMADO == trim(this.codEstadoPrograma);
    }

    esBien(): boolean {
        return Constantes.COD_TIP_PROG_BIEN == trim(this.codTipoProgram);
    }
    esServicio(): boolean {
        return Constantes.COD_TIP_PROG_SERVICIO == trim(this.codTipoProgram);
    }

}


export class ProgramacionBean {
    codProgramaControl: string;
    codTipoDocumentoIdent:string;
    numDocumentoIdent:string;
    numInforme:string;
    codTipoOrden:string;
    fechaDesde:string;
    fechaHasta:string;
    codTipInterv:string;
    codTipoAccion:string;
    codEstadoInforme:string;
    nombAuditAsignad:string;
    codEstOrden:string;
    nombAuditApoyo:string;
    inconsistencias: CheckElement[] = [];
    tipoBienes: CheckElement[] = [];
    bienesFiscalizados: CheckElement[] = [];
}

export class ExportExcelProgramacion{
    nro_programacion:number;
    programa_control:string;
    inconsistencia:string;
    resultado_inconsistencia: string;
    periodo_inicio:string;
    periodo_fin:string;
    tipo_documento:string;
    nro_documento_usuario:string;
    nombre_o_razon_social:string;
    nro_informe_seleccion:string;
    estado_informe:string;
    tipo_accion:string;
    nro_documento_accion:string;
    tipo_orden:string;
    nro_orden:string;
    estado_orden:string;
    auditor_asignado:string;
    resultado_orden:string;
    nro_documento_vinculado:string;
}
