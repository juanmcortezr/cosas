import { ArchivoBean } from './archivoBean.model';
import { isNotEmpty } from '../utils/utilitarios';

export class AsignacionMasivaAuditores {

    numRegistro: string;
    nomApellidoUsuario: string;
    cargoLaboral: string;
    numGrupo:string;
    nomGrupo:string;

    ///Variables Extra
    numProgramacion: string;
    numInformeSeleccion: string;
    codProgramaCtrl: string;
    numAsigTemp: string;

    ///Variable para Seleccionar todo
    seleccionado: boolean;

/// PK del Supervisor Auditor
    codTipoProceso: string;



    forEach: any;

    static fromJSON(data: any) {
      return Object.assign(new this, data);
    }

    filtroValido(): boolean{
      return isNotEmpty(this.numProgramacion)
      || isNotEmpty(this.numInformeSeleccion);
    }
}
