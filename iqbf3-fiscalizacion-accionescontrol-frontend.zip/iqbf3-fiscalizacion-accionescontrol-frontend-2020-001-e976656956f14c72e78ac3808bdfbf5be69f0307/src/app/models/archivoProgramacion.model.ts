import { ArchivoBean } from './archivoBean.model';

export class ArchivoProgramacion {

    numArchivoProgram: number;
    numProgramacion: number;
    archivoBean: ArchivoBean;

}