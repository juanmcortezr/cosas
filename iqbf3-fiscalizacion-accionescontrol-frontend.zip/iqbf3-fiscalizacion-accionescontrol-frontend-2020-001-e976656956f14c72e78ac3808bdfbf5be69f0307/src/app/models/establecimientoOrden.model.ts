export class EstablecimientoOrden {
    codDepartamento: string;
    codDistrito: string;
    codOrigen: string;
    codProvincia: string;
    codTipoDocumentoIdentif: string;
    desDireccion: string;
    numEstablecimiento: number;
    numEstablecimientoOrden: number;
    numOtroRuc: string;
    numSolicitudNuetralizacion: string;
    numXutm: number;
    numYutm: number;
    numZona: number;
    numOrden: number;
}