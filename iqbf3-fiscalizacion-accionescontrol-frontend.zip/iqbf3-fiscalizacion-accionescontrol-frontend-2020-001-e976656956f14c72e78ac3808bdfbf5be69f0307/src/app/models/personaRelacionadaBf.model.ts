export class PersonaRelacionadaBf {
    apellidosNombre: string;
    numDocumentoVinculado: string;
    numeroGuia: number;
    numeroLicenciaConducir: string;
    numeroPersona: number;
    numeroRucRemitente: number;
    numeroSerie: number;
    subcontratado: number;
    tipoDocumento: string;
    tipoGuia: number;
    tipoPersona: number;
}