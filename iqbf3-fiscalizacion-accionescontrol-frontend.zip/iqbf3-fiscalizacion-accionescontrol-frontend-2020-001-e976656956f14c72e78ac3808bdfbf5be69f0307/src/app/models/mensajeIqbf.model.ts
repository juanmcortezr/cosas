export class MensajeIqbf {
    codMensaje: string;
    codTipoDocumento: string;
    codTipoProceso: string;
    desAbreviatura: string;
    desCorta: string;
    desCuerpo: string;
    desLarga: string;
    indAsunto: string;
}