export class DeclaracionesJuradasBf {

    codEstado: string;
    codTipobien: number;
    fecFinOmiso: string;
    fecFinOperacion: string;
    fecFinPresentacion: string;
    fecInicioOmiso: string;
    fecInicioOperacion: string;
    fecInicioPresentacion: string;
    indOmiso: string;
    indTipenv: number;
    numCabecera: number;
    numConfirma: number;
    numPeriodo: string;
    numRuc: number;
    numVersionRegistro: number;

}