export class ActaEstablecimiento {

    codTipoActa: string;
    codTipoDocumentoReferencia: string;
    codTipoInforme: string;
    desOtraActa: string;
    desOtroDocumentoinculado: string;
    desOtroInforme: string;
    desTipoActa: string;
    desTipoDocumentoVinculado: string;
    desTipoInforme: string;
    numActa: string;
    numActaEstablecimiento: number;
    numDocumentoVinculado: string;
    numEstablecimientoOrden: number;

}