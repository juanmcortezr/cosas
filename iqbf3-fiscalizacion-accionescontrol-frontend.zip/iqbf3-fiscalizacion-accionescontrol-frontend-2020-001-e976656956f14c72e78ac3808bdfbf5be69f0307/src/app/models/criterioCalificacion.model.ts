import { isNotEmpty } from '../utils/utilitarios';
import { AlternativaCriterio } from './alternativaCriterio.model';

export class CriterioCalificacion {

    desCriterio: string;
    numCriterio: number;
    porPeso: number;
    indEstado: string;

    //Ini extra
    desEstado: string;
    btnEstado: string;
    btnColor: string;
    alternativasCriterios: AlternativaCriterio[];
    //Fin extra

    static fromJSON(data: any) {
      return Object.assign(new this, data);
    }
///Criterios Calificación

    filtroValidoProgram(): boolean{
      return isNotEmpty(this.indEstado)
      || isNotEmpty(this.numCriterio)
      || isNotEmpty(this.porPeso);
    }

    descripcionEstado(): string {
      if (this.esActivo()) {
        return 'Activo';
      } else if (this.esInactivo()) {
        return 'Inactivo';
      }
      return '';
    }

    esActivo(): boolean {
      return this.indEstado === '1';
    }
    esInactivo(): boolean {
      return this.indEstado === '0';
    }

}
