import { isNotEmpty } from '../utils/utilitarios';

export class ProgramaControl {
    codFrecuenciaTiempo:	string;
    codProgctrl:	string;
    codUnidadOrganica:	string;
    desAlcance:	string;
    desCruce:	string;
    desDenominacion:	string; //desProgramaControl
    desEstado:	string;
    desResumen:	string;
    desUuoo:	number;
    indCierre:	string;
    indEstado:	string;
    indInformeSelec:	string;
    numPlazo:	number;

    ///Extra
    nombrePrograma: string;

    static fromJSON(data: any) {
      return Object.assign(new this, data);
    }

    filtroValido(): boolean{
      return true;
    }

    // Descripciones
    descripcionEstado(): string {
      if (this.esActivo()) {
        return 'Activo';
      } else if (this.esInactivo()) {
        return 'Inactivo';
      }
      return '';
    }

    descripcionInforme(): string {
      if (this.esCeroI()) {
        return 'NO';
      } else if (this.esUnoI()) {
        return 'SI';
      }
      return '';
    }

    descripcionCierre(): string {
      if (this.esCeroC()) {
        return 'NO';
      } else if (this.esUnoC()) {
        return 'SI';
      }
      return '';
    }

    esUnoI(): boolean {
      return this.indInformeSelec === '1';
    }
    esCeroI(): boolean {
      return this.indInformeSelec === '0';
    }

    esUnoC(): boolean {
      return this.indCierre === '1';
    }
    esCeroC(): boolean {
      return this.indCierre === '0';
    }

    esActivo(): boolean {
      return this.indEstado === '1';
    }
    esInactivo(): boolean {
      return this.indEstado === '0';
    }
}
