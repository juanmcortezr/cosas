import { ArchivoBean } from './archivoBean.model';

export class DocumentoOrden {

    archivoBean: ArchivoBean;
    codOrigen: string;
    codTipoDocumento: string;
    desDocumento: string;
    desOrigen: string;
    desTipoDocumento: string;
    fecEmision: string;
    fecEntrega: string;
    fecNotificacion: string;
    fecPresentaVisita: string;
    fecProrroga: string;
    numDocumento: string;
    numDocumentoOrden: number;
    numOrden: number;

}