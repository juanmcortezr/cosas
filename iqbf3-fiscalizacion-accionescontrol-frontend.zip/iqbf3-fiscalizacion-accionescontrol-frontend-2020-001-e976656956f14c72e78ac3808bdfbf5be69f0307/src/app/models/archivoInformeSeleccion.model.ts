import { ArchivoBean } from './archivoBean.model';

export class ArchivoInformeSeleccion {

    numArchivoDoc: number;
    numInformeSeleccion: number;
    archivoBean: ArchivoBean;

}