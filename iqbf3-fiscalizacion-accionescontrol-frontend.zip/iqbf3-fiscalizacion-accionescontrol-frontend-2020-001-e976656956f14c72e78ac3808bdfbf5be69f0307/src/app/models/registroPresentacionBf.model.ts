export class RegistroPresentacionBf {
    cntNetProd: number;
    cntPesoBruto: number;
    cantidadUnidadFisica: number;
    codEstado: String;
    codOrigen: String;
    codPartidaArancelaria: String;
    codPresen: String;
    codPresenUsu: String;
    codTipoBien: String;
    codUnidadMedidaControl: String;
    codUnidadComercial: String;
    codUnidadFiscal: String;
    desSustento: String;
    fecAlta: String;
    fecBaja: String;
    indCondicion: String;
    indUsoarte: String;
    indUsodome: String;
    numInsumoCabecera: number;
    numOrdenInsumo: String;
    numPresentacion: number;
    numReferencianModifica: number;
    numRuc: String;
    numVersionRegistro: number;
    numVersion: number;
}