export class AlternativaCriterioDefinitivo {

    desAlternativa: string;
    numAlternativa: number;
    numCriterio: number;
    valAlternativa: number;
    indEstado: string;

    //Ini extra
    seleccionado?: boolean;
    //Fin extra

    static fromJSON(data: any) {
      return Object.assign(new this, data);
    }
}
