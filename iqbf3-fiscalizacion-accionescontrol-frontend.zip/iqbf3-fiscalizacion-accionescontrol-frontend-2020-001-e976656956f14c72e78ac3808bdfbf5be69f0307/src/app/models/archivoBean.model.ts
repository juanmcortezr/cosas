export class ArchivoBean {
    uuid: string;
    blob: any[];
    numArc : number;
    desMimeType: string;
    nomArchivo: string;
    cntPesArch: number;
    tipo: string;
    blobBase64: string;
}