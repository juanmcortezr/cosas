export class TipoInconsistenciaSolicitud {
    codTipoInconsistencia: string;
    desOtraInconsistencia: string;
    desTipoInconsistencia: string;
    numInconsistenciaSolicitud: number;
    numSolicitud: number;
}