export class MovimientoSolicitud {
    codPersMov: string;
    desMotivoAsignacion: string;
    desPersonalMovimiento: string;
    fecMovimiento: string;
    numMovimientoPrograma: number;
    numSolicitud: number;
}