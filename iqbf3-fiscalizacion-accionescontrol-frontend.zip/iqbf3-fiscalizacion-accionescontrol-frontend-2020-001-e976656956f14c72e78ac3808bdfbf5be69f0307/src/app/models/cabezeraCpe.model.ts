export class CabezeraCpe {

    codCpe: string;
    codDocumenotRecepcion: string;
    codEstadoAnexo: number;
    codMoneda: string;
    codTipoCpe: string;
    desNombreRecepcion: string;
    desObservacion: string;
    fecEmision: string;
    indEstado: string;
    indProcedencia: string;
    indRechazo: string;
    mtoImporteTotal: number;
    mtoTotalIgv: number;
    mtoTotalVenta: number;
    numCpe: number;
    numCuoRegven: number;
    numDocumentoRecepcion: string;
    numIdXml: number;
    numPeriodoRegistroCompra: string;
    numPeriodoRegistroVenta: string;
    numRuc: string;
    numSerieCpe: string;

}