export class AgentePuestosCtrl {

    codDep: string;
    codEstado: string;
    codPuesto: string;
    codRol: string;
    codUnidadOrganica: string;
    desSustento: string;
    fecRegistro: string;
    numRegistroPersonal: string;

}