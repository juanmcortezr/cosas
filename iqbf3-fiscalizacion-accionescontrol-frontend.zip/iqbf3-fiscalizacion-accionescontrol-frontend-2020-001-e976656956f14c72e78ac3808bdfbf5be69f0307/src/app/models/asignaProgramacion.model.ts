export class AsignaProgramacion {

    codProgramador: string;
    desReasignacion: string;
    fecFinAsignacion: string;
    fecInicioAsignacion: string;
    indTipAsignacion: string;
    nomProgramador: string;
    numAsignacion: number;
    numProgramacion: number;

}