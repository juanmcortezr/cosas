export class RegistroUsuarioBf {
    codEstado: string;
    codMotivoBaja: string;
    codTipoBien: string;
    fecAlta: string;
    fecBaja: string;
    fecFinVigencia: string;
    fecLevanteSuspencion: string;
    fecSuspension: string;
    indAutoriza: string;
    indDesvio: string;
    indExoneracion: string;
    indmineria: string;
    indOmiso: string;
    indTrafico: string;
    indZonare: string;
    numCalificacion: number;
    numCarga: number;
    numOsinergmin: string;
    numReferencianModifica: number;
    numRegistroMtc: string;
    numRegistroAlta: string;
    numRuc: string;
    numSolicitud: number;
    numVersionRegistro: number;
}