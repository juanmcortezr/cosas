import { AlternativaCriterioDefinitivo } from './alternativaCriterioDefinitivo.model';

export class AlternativaCriterio {

    desAlternativa: string;
    numAlternativa: number;
    numCriterio: number;
    valAlternativa: number;
    indEstado: string;
    desCriterio: string;

    //Ini extra
    desEstado: string;
    btnEstado: string;
    btnColor: string;
    seleccionado?: boolean;
    pesoCriterio:number;

    alternativasDefinitivas: AlternativaCriterioDefinitivo [];
    //Fin extra

    static fromJSON(data: any) {
      return Object.assign(new this, data);
    }

    descripcionEstado(): string {
      if (this.esActivo()) {
        return 'Activo';
      } else if (this.esInactivo()) {
        return 'Inactivo';
      }
      return '';
    }

    esActivo(): boolean {
      return this.indEstado === '1';
    }
    esInactivo(): boolean {
      return this.indEstado === '0';
    }

}
