export class DocumentoRelacionado {

    codDocumentoRelacionado: string;
    codRelacion: string;
    codCpe: number;
    numDocumentoRelacionado: string;
    numRucRelacionado: string;
    numSerieDocumentoRelacionado: string;
    numCpe: number;
    numRuc: number;
    numSerieCpe: number;

}