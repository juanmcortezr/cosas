export class HistorialEstadosPrograma {
    codEstadoPrograma: string;
    desEstadoProgram: string;
    fecEstadoProgram: string;
    numHistoriaProgram: number;
    numProgramacion: number;
}