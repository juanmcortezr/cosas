export class DocumentoOperacion {

    codTipoDocumentoOperacion: string;
    desTipoDocumentoOperacion: string;
    numDocumentoOperacion: number;
    numDocumentoComercial: string;
    numOrden: number;

}