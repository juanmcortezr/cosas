export class EstablecimientoUsuario {
    codDepartamento: string;
    codDistrito: string;
    codProvincia: string;
    desDireccionEstablecimiento: string;
    desDepartamento: string;
    desDistrito: string;
    desProvincia: string;
    indOtroEstab: string;
    numEstablecimiento: number;
    numEstablecimientoUsuario: number;
    numUsuarioPrograma: number;

    //Ini extra
    numUsuarioSolicitud: number;
    desUbigeo: string;
    //Fi extra

}