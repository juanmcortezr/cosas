export class TipoInconsistenciaPrograma {
    codTipoInconsistencia: string;
    desOtraInconsistencia: string;
    desTipoInconsistencia: string;
    numInconsistenciaProgram: number;
    numProgramacion: number;
}