import { trim, isNotEmpty } from '../utils/utilitarios';
import { Programacion } from './programacion.model';
import { ArchivoBean } from './archivoBean.model';
export class UsuarioProgramacion {    
    cantidadDiasAtencion: number;
    codDependencia: string;
    codEstadoRegistro: string;
    codEstadoUsuario: string;
    codMotivaDepuracion: string;
    codNivelRiesgo: string;
    codTipoAccion: string;
    codTipoAccionSugerida: string;
    codTipoDocumentoIdentif: string;
    codTipoIntervencion: string;
    codTipoIntervencionSugerida: string;
    codUbigeoDomicilioFiscal: string;
    desSusMotivo: string;
    desDependencia: string;
    desEstadoRegistro: string;
    desEstadoUsuario: string;
    desMotDepuracion: string;
    desNivelRiesgo: string;
    desTipoAccion: string;
    desTipoAccionSugerida: string;
    desTipoDocumentoIdent: string;
    desTipoIntervencion: string;
    desTipoIntervencionSugerida: string;
    desUbigeoDomicilioFiscal: string;
    fecFinVigencia: string;
    fecInicioCaso: string;
    fecProcesamiento: string;
    horIniCaso: string;
    indNeutralizacion: string;
    desIndNeutralizacion:string;
    nomApellidoUsuario: string;
    numDocumentoIdentif: string;
    numPeridoomisomax: string;
    numPeridoomisomin: string;
    numProgramacion: number;
    numUsuarioPrograma: number;
    numVersionRegistro: number;
    nomRazonSocial:string;   
    codEstadoPrograma:string;

  
    alcanceProg:string;
    numInformeSelecci:string;
    codAuditor:string;
    nomAuditor:string;
    nombreRazonSocial:string;
    desProgctrl:string;
    numDocumentoAccion:string;
    numOrden:string;

    //Opv extra
    seleccionado: boolean;//extra para saber si esta seleccionado
    usuariosBean: UsuarioProgramacion[] ;//el cus pide una lista.
    programacionBean: Programacion[];//el cus devuelve datos de programacion.
    archivoVinculado: ArchivoBean;//el cus pide guardar un archivo.
    otrasAcciones:string;   
    tipoDocumentoVinculado:string;
	numeroDocumentoVinculado:string;
    //Opv extra

    filtroValidoIU022(): boolean {
        return  isNotEmpty(this.codNivelRiesgo)
        || isNotEmpty(this.codDependencia) || isNotEmpty(this.codTipoAccion) || isNotEmpty(this.codTipoDocumentoIdentif);
    }




    getDescripcionIndNeutralizacion():string{
        debugger;
        if(this.indNeutralizacion!=undefined){
            if(this.indNeutralizacion=="0"){
                this.desIndNeutralizacion=="No"
            }else{
                this.desIndNeutralizacion=="Si"
            }               
        } 
        return  this.desIndNeutralizacion; 
    }

    


    filtroValidoIU026(): boolean {
        return isNotEmpty(this.codNivelRiesgo) || 
        isNotEmpty(this.codDependencia) || 
        isNotEmpty(this.codTipoAccion) || 
        isNotEmpty(this.codTipoDocumentoIdentif) || 
        isNotEmpty(this.numDocumentoIdentif);
    }

    filtroValidoIU036(): boolean {
        return isNotEmpty(this.codTipoDocumentoIdentif) || isNotEmpty(this.numDocumentoIdentif) || 
        isNotEmpty(this.codTipoAccion);
    }

}

export class UsuarioProgramacionBean { 
    numProgramacion: number;
    alcanceProg:string;
    numInformeSelecci:string;
    codTipoDocumentoIdentif: string;
    numDocumentoIdentif: string;
    nomAuditor:string;
}