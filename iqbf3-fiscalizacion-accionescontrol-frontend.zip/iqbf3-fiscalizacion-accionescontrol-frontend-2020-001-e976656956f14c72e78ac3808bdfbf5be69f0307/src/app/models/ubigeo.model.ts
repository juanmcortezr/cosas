export class Ubigeo {
    codUbigeo: string;
    desUbigeo: string;
    seleccionado?: boolean;
}