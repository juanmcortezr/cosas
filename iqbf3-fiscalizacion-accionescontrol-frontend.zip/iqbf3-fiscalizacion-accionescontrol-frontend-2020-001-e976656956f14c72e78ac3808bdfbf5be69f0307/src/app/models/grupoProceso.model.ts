export class GrupoProceso {
    codTipoProceso: string;
    nomGrupo: string;
    numGrupo: number;
}