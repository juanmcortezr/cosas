export class AsignaSolicitud {

    codProgramador: string;
    fecFinAsignacion: string;
    fecInicioAsignacion: string;
    nomProgramador: string;
    numAsignacionSolic: number;
    numSolicitud: number;

}