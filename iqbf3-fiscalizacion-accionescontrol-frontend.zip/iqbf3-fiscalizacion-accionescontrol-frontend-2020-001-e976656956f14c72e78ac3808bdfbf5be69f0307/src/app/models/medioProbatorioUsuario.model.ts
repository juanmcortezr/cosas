import { ArchivoBean } from './archivoBean.model';

export class MedioProbatorioUsuario {
    archivoBean: ArchivoBean;
    codTipoMedioProbatorio: string;
    desMedioProbatorio: string;
    numMedioProbatorioUsuario: number;
    numMedioProbatorio: string;
    numUsuarioSolicitud: number;
}