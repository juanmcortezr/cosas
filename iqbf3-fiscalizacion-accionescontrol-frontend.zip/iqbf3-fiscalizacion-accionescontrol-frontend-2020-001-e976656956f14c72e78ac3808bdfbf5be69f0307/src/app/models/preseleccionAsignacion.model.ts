export class PreseleccionAsignacion {
    codAuditor: string;
    codTipoAccion: string;
    desTipoAccion: string;
    nomAuditor: string;
    numAsignacionTemp: number;
    numProgramacion: number;
}