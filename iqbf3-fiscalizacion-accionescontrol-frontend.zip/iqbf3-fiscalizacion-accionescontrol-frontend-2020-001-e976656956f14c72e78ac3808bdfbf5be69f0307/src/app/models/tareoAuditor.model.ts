export class TareoAuditor {
    desActividad: string;
    fecActividad: string;
    horEmpleada: string;
    numTareo: number;
    numOrden: number;
}