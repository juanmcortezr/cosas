export class Catalogo {

    codCatalogo: string;
    codDataCatalogo: string;
    fechaIniDataCatalogo: string;
    descripcionDataCatalogo: string;
    descripcionCorta: string;
    descripcionAcronimo: string;

    //Ini extra
	seleccionado?: boolean;
	//fin extra

    constructor(codDataCatalogo: string, descripcionDataCatalogo: string){
        this.codDataCatalogo = codDataCatalogo;
        this.descripcionDataCatalogo = descripcionDataCatalogo;
    }
    
}