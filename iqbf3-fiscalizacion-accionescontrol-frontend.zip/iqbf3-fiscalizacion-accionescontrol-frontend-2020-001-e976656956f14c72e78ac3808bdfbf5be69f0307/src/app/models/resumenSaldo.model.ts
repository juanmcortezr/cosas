export class ResumenSaldo {
    cantidadConsumida: number;
    cantidadDisponible: number;
    codTipobien: number;
    fecFinCalc: string;
    fecInicioCalculo: string;
    indInconsistencia: string;
    numConfirma: number;
    numExistencia: number;
    numInsumoCabecera: number;
    numPeriodo: string;
    numReposicion: number;
    numRuc: number;
    numVersionRegistro: number;
}