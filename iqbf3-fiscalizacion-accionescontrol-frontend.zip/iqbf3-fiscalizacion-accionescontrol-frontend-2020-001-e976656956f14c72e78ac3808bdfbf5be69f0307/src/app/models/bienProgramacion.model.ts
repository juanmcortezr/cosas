export class BienProgramacion {

    codBien: string;
    codTipoBien: string;
    desBien: string;
    numBienPrograma: number;
    numProgramacion: number;

}