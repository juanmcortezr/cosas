export class SuspensionOrden {
    codSustentoSuspencion: string;
    desSusSusp: string;
    numSusSuporden: number;
    numOrden: number;
}