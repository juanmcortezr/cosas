export class BloqueoDjro {

    codTipoDocumento: string;
    desTipoDocumento: string;
    fecBloqDjro: string;
    indEstadoBloqueDjro: string;
    numBloqueoDjro: number;
    numDocumentoIdentif: string;
    numOrden: number;
    perFin: string;
    perInicio: string;

}