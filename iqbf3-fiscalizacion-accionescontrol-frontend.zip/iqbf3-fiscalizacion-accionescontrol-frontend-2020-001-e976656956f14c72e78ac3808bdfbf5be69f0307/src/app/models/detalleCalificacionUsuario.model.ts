export class DetalleCalificacionUsuario {

    numDetalleCalificacion: number;
    numAlternativa: number;
    numCriterio: number;
    numUsuarioCalifiicacion: number;
    valPuntaje: number;

}