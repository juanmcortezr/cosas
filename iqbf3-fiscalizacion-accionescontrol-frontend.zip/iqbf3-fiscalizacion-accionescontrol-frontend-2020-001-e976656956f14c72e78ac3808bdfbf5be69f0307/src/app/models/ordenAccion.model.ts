import { isNotEmpty } from '../utils/utilitarios';

export class OrdenAccion {
    anioOrden: number;
    codEstadoOrden: string;
    codRecomendacion: string;
    codResultadoInconsistenciaDef: string;
    codResultadoInconsistenciaPre: string;
    codResulOrden: string;
    codTipoOrden: string;
    codUnidadOrganica: string;
    desRecomendacion: string;
    desSusCancela: string;
    desSusDevolucion: string;
    desSusNoaccion: string;
    desSusResul: string;
    desDepartamento: string;
    desDistrito: string;
    desEstadoOrden: string;
    desOrigen: string;
    desProvincia: string;
    desResulInconsis: string;
    desResulOrden: string;
    desTipoDocumentoIdent: string;
    desTipOrden: string;
    desTipoRecomendacion: string;
    desUnidadOrganica: string;
    fecAsigOrden: string;
    fecCancelacion: string;
    fecDerivacion: string;
    fecInicioCaso: string;
    fecInicioCasoNuevo: string;
    fecOrden: string;
    fecPrimeraVisiat: string;
    fecSegundaVisit: string;
    fecSolicProrroga: string;
    indBloqDjro: string;
    indPrimeraVisit: string;
    indRealizoAccion: string;
    indSegundaVisit: string;
    indSolicProrroga: string;
    numCorrel: number;
    numOrden: number;
    numUsuarioPrograma: number;
    obsResultado: string;
    numDocIdent:string;
    nomApeUsuario:string;

    //Ini extra
    numProgramacion: number;
    seleccionado?: boolean;
    listOrden: OrdenAccion[] = [];
    //Ini extra

    filtroValidoIU040(): boolean {
        return isNotEmpty(this.numOrden) || isNotEmpty(this.numDocIdent) || 
        isNotEmpty(this.nomApeUsuario);
    }
}

export class ListOrdenAccion {
    codTipoOrden:string;
    numOrden:number;
    fechaDesde:string;
    fechaHasta:string;
    codTipoDocumentoIdent:string;
    numDocIdent:string;
    numInforSelec:string;
    codEstadoOrden:string;
    numProgramacion:number;
}