import { ArchivoBean } from './archivoBean.model';
import { MedioProbatorioUsuario } from './medioProbatorioUsuario.model';
import { EstablecimientoUsuario } from './establecimientoUsuario.model';
import { Catalogo } from './catalogo.model';
import { BienFiscalizadoSolicitud } from './bienFiscalizadoSolicitud.model';

export class UsuarioSolicitud {
    archivoBean: ArchivoBean;
    codTipoAccion: string;
    codTipoDocumentoIdentif: string;
    codTipoDocumentoReferencia: string;
    codTipoIntervencion: string;
    desTipoAccionControl: string;
    desTipoDocumentoIdent: string;
    desTipoDocumentoRef: string;
    desTipoIntervencion: string;
    fecSugeridaVisita: string;
    horSugeVisit: string;
    nomApellidoUsuario: string;
    numDocumentoIdentif: string;
    numDocumentoReferencia: string;
    numSolicitud: number;
    numUsuarioSolicitud: number;

    //Ini extra
    desOtraInconsistencia: string;
    desOtraTipoBien: string;
    establecimientos: EstablecimientoUsuario[];
    mediosProbatorios: MedioProbatorioUsuario[];
    inconsistencias: Catalogo[];
	tipoBienes: Catalogo[];
    bienesFiscalizados: BienFiscalizadoSolicitud[];
    totalInconsistencia: number;
	totalBien: number;
    totalMedioProbatorio: number;
    valCalificacionPreliminar: number;
	valCalificacionDefinitiva: number;
    //Fin extra
}