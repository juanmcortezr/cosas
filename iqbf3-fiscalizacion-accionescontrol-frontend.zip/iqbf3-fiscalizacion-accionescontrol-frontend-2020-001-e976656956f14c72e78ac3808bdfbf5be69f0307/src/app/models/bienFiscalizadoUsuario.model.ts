export class BienFiscalizadoUsuario {

    codBienFiscalizado: string;
    codTipoBien: string;
    desOtroBien: string;
    desBienFisca: string;
    desTipoBien: string;
    numBienFiscaUsuario: number;
    numUsuarioSolicitud: number;

}