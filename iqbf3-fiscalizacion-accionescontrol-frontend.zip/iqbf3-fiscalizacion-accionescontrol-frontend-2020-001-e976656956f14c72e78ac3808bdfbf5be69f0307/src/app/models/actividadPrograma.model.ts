export class ActividadPrograma {

    codActividad: number;
    desActividad: string;
    numActividadPrograma: number;
    numProgramacion: number;

}