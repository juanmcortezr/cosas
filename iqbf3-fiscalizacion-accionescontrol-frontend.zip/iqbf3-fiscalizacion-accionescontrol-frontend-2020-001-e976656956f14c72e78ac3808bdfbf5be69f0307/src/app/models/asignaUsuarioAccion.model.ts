export class AsignaUsuarioAccion {

    codCargo: string;
    codAuditor: string;
    desCargo: string;
    fecFinAsignacion: string;
    fecInicioAsignacion: string;
    indTipAsignacion: string;
    nomAuditor: string;
    numAsignacionAccion: number;
    numUsuarioPrograma: number;

}