export class DetalleResultadoOrden {

    codResulOrden: string;
    desOtroResultado: string;
    desResulOrden: string;
    numDetalleResultadoOrden: number;
    numOrden: number;

}