import { AlternativaCriterio } from './alternativaCriterio.model';

export class CalificacionUsuario {

    desSusAccsuge: string;
    desTipoAccionSugerida: string;
    indTipCali: string;
    numAccionSugerida: number;
    numUsuarioCalifiicacion: number;
    numUsuarioSolicitud: number;
    valCalificacion: number;

    //Ini extra
    numSolicitudUnion: string;
    nomSolicitante: string;
    codTipoIntervension: string;
	codTipoAccion: string;
    desTipoIntervencion: string;
    desTipoAccionControl: string;
    codTipoDocumentoIdentif: string;
    numDocumentoIdentif: string;
    nomApellidoUsuario: string;
    desTipoDocumentoIdent: string;
    alternativasCriterios: AlternativaCriterio[];
    //Fin extra

    static fromJSON(data: any) {
        return Object.assign(new this, data);
    }
}