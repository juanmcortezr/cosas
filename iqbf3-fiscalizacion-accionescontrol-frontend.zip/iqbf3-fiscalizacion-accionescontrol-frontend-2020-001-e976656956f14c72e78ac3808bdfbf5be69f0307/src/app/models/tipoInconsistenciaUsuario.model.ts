export class TipoInconsistenciaUsuario {
    codTipoInconsistencia: string;
    desOtraInconsistencia: string;
    desTipoInconsistencia: string;
    numInconsistenciaUsuario: number;
    numUsuarioSolicitud: number;
}