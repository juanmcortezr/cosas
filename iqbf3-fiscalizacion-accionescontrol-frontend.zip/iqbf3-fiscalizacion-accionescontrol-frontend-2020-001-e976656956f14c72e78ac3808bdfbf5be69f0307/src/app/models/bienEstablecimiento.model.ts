export class BienEstablecimiento {

    cantidadStockFisico: number;
    codBienFiscalizado: string;
    codTipoBien: string;
    codUnidadMedida: string;
    desBien: string;
    desBienFisca: string;
    desTipoBien: string;
    desUnidadMedida: string;
    fecStockFisico: string;
    horStockFisico: string;
    numBienEstablecimiento: number;
    numEstablecimientoOrden: number;

}