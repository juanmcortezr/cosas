// Interfaz para la forma del objeto mensaje
export interface Mensaje {
    mensajeAlert: string;
    colorAlert: string;
}