export interface DataCatalogo {
    // codCatalogo: string;
     codDataCatalogo: string;
    // fechaIniDataCatalogo: string;
    descripcionDataCatalogo: string;
    descripcionCorta: string;
    descripcionAcronimo: string;
    abrevTipoCatalogo: string;
 }
 