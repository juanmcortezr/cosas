export class ContactoOrden {

    codTipoDocumentoIdentif: string;
    desCargo: string;
    desTipoDocumentoIdent: string;
    nomApellidoContacto: string;
    numContacto: number;
    numDocumentoIdentif: string;
    numTelefono: string;
    numOrden: number;

}