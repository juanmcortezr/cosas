export class ActividadEstablecimiento {

    codActividad: string;
    desActividad: string;
    numActividadEstablecimiento: number;
    numEstablecimientoResultado: number;

}