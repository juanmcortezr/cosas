export class ResumenStockEstablec {
    cntIngEst: number;
    cantidadSalidaEstablec: number;
    cantidadStockActual: number;
    codTipobien: number;
    fecFinCalc: string;
    fecInicioCalculo: string;
    numConfirma: number;
    numEstablecimiento: string;
    numPeriodo: string;
    numPresentacion: number;
    numReposicion: number;
    numStock: number;
    numRuc: number;
    numVersionRegistro: number;
}