export class ActividadOrden {

    codActividad: string;
    desActividad: string;
    numActividadResultado: number;
    numOrden: number;

}