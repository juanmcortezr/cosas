export class DataComplementGre {

    codigoVerificacion: string;
    desMotivoTraslado: string;
    fecEntregaProductos: string;
    fecInicioTraslado: string;
    formaTraslado: number;
    motivoEmision: number;
    motivoTraslado: number;
    numeroGuia: number;
    numeroRucRemitente: number;
    numeroSerie: number;
    rutaFiscal: string;
    tipoGuia: number;
    tipoTramo: number;
    transbordo: number;

}