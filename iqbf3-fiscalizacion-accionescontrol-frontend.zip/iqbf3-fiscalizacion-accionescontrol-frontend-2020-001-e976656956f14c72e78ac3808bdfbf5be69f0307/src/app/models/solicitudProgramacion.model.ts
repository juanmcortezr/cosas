import { ArchivoBean } from './archivoBean.model';
import { isNotEmpty } from '../utils/utilitarios';
import { Catalogo } from './catalogo.model';
import { BienFiscalizadoSolicitud } from './bienFiscalizadoSolicitud.model';
import { AsignaProgramacion } from './AsignaProgramacion.model';
import { Programacion } from './programacion.model';
import { UsuarioSolicitud } from './usuarioSolicitud.model';

export class SolicitudProgramacion {
	anioSolicitud: number;
	codEstadoSolicitud: string;
	codSolicitante: string;
	codTipoDocumentoReferencia: string;
	codUnidadOrganica: string;
	desMotivoAsignacion: string;
	desOtroSolicitante: string;
	desSusSolicitud: string;
	desEstadoSolicitud: string;
	desTipoDocumentoIdenti: string;
	desTipoAccionControl: string;
	desTipoDocumentoIdent: string;
	desTipoDocumentoRef: string;
	desTipoIntervencion: string;
	desUnidadOrganica: string;
	fecGeneracion: string;
	indOtroSolicitan: string;
	nomProgramador: string;
	nomSolicitante: string;
	nomSupervisor: string;
	numCorrel: number;
	numDocumentoReferencia: string;
	numSolicitud: number;
	obsSolicitud: string;
	perFin: string;
	perInicio: string;
	fechaDesde: string;
	fechaHasta: string;

	archivoBean: ArchivoBean;

	inconsistencias: Catalogo[];
	tipoBienes: Catalogo[];
	bienesFiscalizados: BienFiscalizadoSolicitud[];
	usuarios: UsuarioSolicitud[];

	//Ini extra
	numSolicitudUnion: string;
	codTipoDocUsuario: string;
	numDocUsuario: string;
	codTipoIntervension: string;
	codTipoAccion: string;
	indcalipreliminar: string;
	indcalidefinitiva: string;
	numMedProbausu: number;
	desOtraInconsistencia: string;
	desOtraTipoBien: string;
	listaHistoriaAsignaciones: AsignaProgramacion[];
	calificacionPreliminar: number;
	calificacionDefinitiva: number;
	solicitante: string;
	fecEstadoActual: string;

	calificacionDesde: string;
	calificacionHasta: string;
	esSupervisorSolicitante: boolean;
	esSupervisorProgramador: boolean;
	//fin extra

	filtroValido(): boolean {
		return isNotEmpty(this.numSolicitudUnion)
			|| isNotEmpty(this.codTipoDocUsuario)
			|| isNotEmpty(this.numDocUsuario)
			|| isNotEmpty(this.codTipoIntervension)
			|| isNotEmpty(this.codTipoAccion)
			|| isNotEmpty(this.codEstadoSolicitud);
	}

	filtroValidoProgram(): boolean {
		return isNotEmpty(this.numSolicitudUnion)
			|| isNotEmpty(this.codTipoDocUsuario)
			|| isNotEmpty(this.numDocUsuario)
			|| isNotEmpty(this.codTipoIntervension)
			|| isNotEmpty(this.codTipoAccion)
			|| isNotEmpty(this.codEstadoSolicitud)
			|| isNotEmpty(this.nomSolicitante)
			|| isNotEmpty(this.nomProgramador);
	}

	filtroConsultasoli(): boolean {
		return isNotEmpty(this.numSolicitudUnion)
			|| isNotEmpty(this.codTipoDocUsuario)
			|| isNotEmpty(this.numDocUsuario)
			|| isNotEmpty(this.codEstadoSolicitud)
			|| isNotEmpty(this.fechaDesde)
			|| isNotEmpty(this.fechaHasta)
			|| isNotEmpty(this.codTipoIntervension)
			|| isNotEmpty(this.codTipoAccion)
			|| isNotEmpty(this.nomSolicitante)
			|| isNotEmpty(this.nomProgramador)
			|| isNotEmpty(this.calificacionDesde)
			|| isNotEmpty(this.calificacionHasta)
			|| isNotEmpty(this.numDocumentoReferencia)
			|| isNotEmpty(this.inconsistencias)
			|| isNotEmpty(this.tipoBienes)
			|| isNotEmpty(this.bienesFiscalizados);
	}
}