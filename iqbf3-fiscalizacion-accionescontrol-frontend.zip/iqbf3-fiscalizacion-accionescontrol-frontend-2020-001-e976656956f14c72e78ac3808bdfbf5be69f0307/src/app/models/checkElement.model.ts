export class CheckElement {
    codigo: string;
    descripcion: string;
    seleccionado: boolean;
    tipo: string;

    constructor(pcodigo, pdescripcion, pseleccionado) {
        this.codigo = pcodigo;
        this.descripcion = pdescripcion;
        this.seleccionado = pseleccionado;
    }
}
