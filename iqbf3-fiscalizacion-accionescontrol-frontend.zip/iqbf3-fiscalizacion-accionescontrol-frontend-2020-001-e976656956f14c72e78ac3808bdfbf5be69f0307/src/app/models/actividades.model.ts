export class Actividades {

    codActividad: string;
    desActividad: string;
    desDetalleActividad: string;
    indServicio: string;
    nomActividad: string;
    numOrden: number;

}