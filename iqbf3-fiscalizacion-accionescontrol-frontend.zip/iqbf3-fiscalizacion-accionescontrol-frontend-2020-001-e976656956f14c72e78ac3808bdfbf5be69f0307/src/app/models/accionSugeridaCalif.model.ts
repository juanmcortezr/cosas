export class AccionSugeridaCalif {

    desAccionSugerida: string;
    indEstadoAccionSugerida: string;
    numAccionSugerida: number;
    valMaximo: number;
    valMinimo: number;

    //Ini extra
    desEstado: string;
    btnEstado: string;
    btnColor: string;
    //Fin extra



    static fromJSON(data: any) {
      return Object.assign(new this, data);
    }

    descripcionEstado(): string {
      if (this.esActivo()) {
        return 'Activo';
      } else if (this.esInactivo()) {
        return 'Inactivo';
      }
      return '';
    }

    esActivo(): boolean {
      return this.indEstadoAccionSugerida === '1';
    }
    esInactivo(): boolean {
      return this.indEstadoAccionSugerida === '0';
    }
}
