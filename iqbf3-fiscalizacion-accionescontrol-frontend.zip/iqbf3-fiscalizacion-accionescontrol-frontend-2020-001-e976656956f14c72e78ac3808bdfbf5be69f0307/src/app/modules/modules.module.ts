import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModulesRoutingModule } from './modules-routing.module';
import { ModulesComponent } from './modules.component';
import { primeNgModule } from '../app-primeng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AvisosComponent } from './intranet/shared/components/avisos/avisos.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [ModulesComponent, AvisosComponent],
  imports: [
    CommonModule,
    ModulesRoutingModule,
    primeNgModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule
  ],
  exports: [
    AvisosComponent
  ]
})
export class ModulesModule { }
