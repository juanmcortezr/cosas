import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-evaluar-informe-resultados',
  templateUrl: './evaluar-informe-resultados.component.html',
  styleUrls: ['./evaluar-informe-resultados.component.css']
})
export class EvaluarInformeResultadosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
