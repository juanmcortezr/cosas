import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-evaluar-resultados-otros',
  templateUrl: './evaluar-resultados-otros.component.html',
  styleUrls: ['./evaluar-resultados-otros.component.css']
})
export class EvaluarResultadosOtrosComponent implements OnInit {

  hideNO: boolean = false;
  hideOC: boolean = false;
  hideOF: boolean = true;
  hideOFNO: boolean = true;
  constructor() { }

  ngOnInit() {
  }

  cambiarResultado(val){
  	if(val == "1"){
      this.hideNO = false;
      this.hideOFNO = false;
      this.hideOC = false;
      this.hideOF = true;
  	}else if(val == "2"){
      this.hideNO = false;
      this.hideOFNO = false;
      this.hideOC = true;
      this.hideOF = false;
  	}else if(val == "3"){
      this.hideNO = true;
      this.hideOFNO = true;
      this.hideOC = false;
      this.hideOF = true;
  	}else{
      this.hideNO = true;
      this.hideOFNO = true;
      this.hideOC = true;
      this.hideOF = false;
    }
  }
}
