import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrar-actividades-resultados',
  templateUrl: './registrar-actividades-resultados.component.html',
  styleUrls: ['./registrar-actividades-resultados.component.css']
})
export class RegistrarActividadesResultadosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
