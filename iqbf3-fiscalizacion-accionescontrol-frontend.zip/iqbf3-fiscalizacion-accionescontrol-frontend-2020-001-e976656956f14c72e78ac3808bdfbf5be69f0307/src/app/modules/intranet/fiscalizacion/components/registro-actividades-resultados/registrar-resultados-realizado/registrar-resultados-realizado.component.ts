import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrar-resultados-realizado',
  templateUrl: './registrar-resultados-realizado.component.html',
  styleUrls: ['./registrar-resultados-realizado.component.css']
})
export class RegistrarResultadosRealizadoComponent implements OnInit {
  hide: boolean = false;
  hideNO: boolean = false;
  hideOC: boolean = false;
  hideOF: boolean = true;
  hideOCNO: boolean = true;
  hideOFNO: boolean = true;

  constructor() { }

  ngOnInit() {
  }

  cambiarResultado(val){
    if(val == "1"){
      this.hide = false;
      this.hideNO = false;
      this.hideOC = false;
      this.hideOF = true;
      this.hideOCNO= true;
      this.hideOFNO = true;
  	}else if(val == "2"){
      this.hide = false;
      this.hideNO = false;
      this.hideOC = true;
      this.hideOF = false;
      this.hideOCNO= true;
      this.hideOFNO = false;
  	}else if(val == "3"){
      this.hide = true;
      this.hideNO = true;
      this.hideOC = false;
      this.hideOF = true;
      this.hideOCNO= false;
      this.hideOFNO = true;
  	}else{
      this.hide = false;
      this.hideNO = true;
      this.hideOC = true;
      this.hideOF = false;
      this.hideOCNO= true;
      this.hideOFNO = true;
    }
  }
}
