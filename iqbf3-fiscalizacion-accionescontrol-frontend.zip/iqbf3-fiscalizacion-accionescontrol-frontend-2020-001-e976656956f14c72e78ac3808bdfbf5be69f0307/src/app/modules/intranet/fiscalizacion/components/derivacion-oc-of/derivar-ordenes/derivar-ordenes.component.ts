import { Component, OnInit } from '@angular/core';
import { Programacion } from 'src/app/models/programacion.model';
import { ArchivoBean } from 'src/app/models/archivoBean.model';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UtilService } from 'src/app/services/shared/util.service';
import { Constantes } from 'src/app/utils/constantes';
import { trim, toNumber } from 'src/app/utils/utilitarios';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { GestionProgramaOtrosService } from 'src/app/services/gestion-programa-otros.service';
import { OrdenAccion } from 'src/app/models/ordenAccion.model';
import { DerivacionOrdenService } from 'src/app/services/derivacion-orden.service';

@Component({
  selector: 'app-derivar-ordenes',
  templateUrl: './derivar-ordenes.component.html',
  styleUrls: ['./derivar-ordenes.component.css']
})
export class DerivarOrdenesComponent implements OnInit {

  //Inicio declaracion
  tipoLBL: string; //Indicar que es una etiqueta label
  numeroProgramacion: string = ''; //Numero de programacion para editar
  programacion: Programacion = new Programacion(); //Declarar e inicializar objeto programacion
  ordenesProgramaciones: OrdenAccion[] = []; //Almacena lista de ordenes programacion
  ordenesProgramacionesSel: OrdenAccion[] = []; //Almacena lista de ordenes programacion seleccionadas
  archivoBeanInformeSeleccion: ArchivoBean = new ArchivoBean(); //Declarar e inicializar objeto para archivo
  filtro: any = {}; //Objeto filtro (Mapear datos ngModel)
  formaDerivarOrden: FormGroup; //FormGroup para registrar y editar usuario de programacion
  urlDescargaArchivo: string; // URL de descarga de archivo
  //Fin declaracion

  constructor(private router: Router,
    private rutaActiva: ActivatedRoute,
    private gestionProgramaOtrosService: GestionProgramaOtrosService,
    private derivacionOrdenService: DerivacionOrdenService,
    private utilService: UtilService) { }

  ngOnInit() {
    this.limpiarCampos();
    this.limpiarCamposBuscarOrden();
    this.inicio();
  }

  //Inicio metodos componente
  async inicio() {

    this.numeroProgramacion = trim(this.rutaActiva.snapshot.params.numProgramacion);

    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO;

    this.formaDerivarOrden = new FormGroup(
      {
        "numProgramacion": new FormControl(''),
        "fechaProgramacion": new FormControl(''),
        "programador": new FormControl(''),
        "fuente": new FormControl(''),
        "desOtraFuente": new FormControl(''),
        "alcanse": new FormControl(''),
        "desProgramacion": new FormControl(''),
        "periodoInicio": new FormControl(''),
        "periodoFin": new FormControl(''),
        "observacion": new FormControl(''),
        "numInformeSeleccion": new FormControl(''),
        "archivoInformeSeleccion": new FormControl('')
      }
    );

    await this.obtenerDatosProgramacion(this.numeroProgramacion);
    this.obtenerDerivarOrden(this.numeroProgramacion);
  }

  limpiarCampos() {
    this.ordenesProgramaciones = [];
  }

  limpiarCamposBuscarOrden() {
    this.filtro = {
      numOrden: Constantes.VALOR_VACIO,
      numDocumentoUsuario: Constantes.VALOR_VACIO,
      nomApellidoAuditor: Constantes.VALOR_VACIO
    };
  }

  //Propiedades formControl
  get numProgramacion() { return this.formaDerivarOrden.get('numProgramacion') as FormControl; }
  get fechaProgramacion() { return this.formaDerivarOrden.get('fechaProgramacion') as FormControl; }
  get programador() { return this.formaDerivarOrden.get('programador') as FormControl; }
  get fuente() { return this.formaDerivarOrden.get('fuente') as FormControl; }
  get desOtraFuente() { return this.formaDerivarOrden.get('desOtraFuente') as FormControl; }
  get alcanse() { return this.formaDerivarOrden.get('alcanse') as FormControl; }
  get desProgramacion() { return this.formaDerivarOrden.get('desProgramacion') as FormControl; }
  get periodoInicio() { return this.formaDerivarOrden.get('periodoInicio') as FormControl; }
  get periodoFin() { return this.formaDerivarOrden.get('periodoFin') as FormControl; }
  get observacion() { return this.formaDerivarOrden.get('observacion') as FormControl; }
  get numInformeSeleccion() { return this.formaDerivarOrden.get('numInformeSeleccion') as FormControl; }
  get archivoInformeSeleccion() { return this.formaDerivarOrden.get('archivoInformeSeleccion') as FormControl; }

  //Eventos checkbox
  eventoCkbOrdenAll(event: any){
    if(this.ordenesProgramaciones != null && this.ordenesProgramaciones.length > 0){
      if(event.target.checked){
        this.ordenesProgramaciones.forEach(e => {
          e.seleccionado = true;
        });
        this.ordenesProgramacionesSel = this.ordenesProgramaciones;
      }else{
        this.ordenesProgramaciones.forEach(e => {
          e.seleccionado = false;
        });
        this.ordenesProgramacionesSel = [];
      }
    }
  }

  eventoCkbOrden(event: any, orden: OrdenAccion){
    this.ordenesProgramacionesSel = this.ordenesProgramacionesSel.filter(e => trim(e.numOrden) != trim(orden.numOrden));

    if(event.target.checked){
      this.ordenesProgramacionesSel = this.ordenesProgramacionesSel.concat(orden); 
    }
  }

  //Eventos botones
  eventoBtnBuscarOrden(){
    this.listarOrdenProgramacion();
  }

  eventoBtnCancelar(){
    this.router.navigate(['/fiscalizacion/derivacion-oc-of']);
  }

  eventoBtnDerivar(){
    this.derivarOrden();
  }

  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  async obtenerDatosProgramacion(numeroProgramacion: string){

    let result = await this.gestionProgramaOtrosService.obtenerRegistrarPrograma(toNumber(numeroProgramacion)).toPromise();

    if (result.exito) {

      let programacion: Programacion = new Programacion();

      programacion = result.data;

      console.log(programacion); //Temporal eliminar
      
      this.numProgramacion.setValue(trim(programacion.numProgramacion));
      this.fechaProgramacion.setValue(trim(programacion.fecProgramacion));
      this.programador.setValue(trim(programacion.desProgramador));
      this.fuente.setValue(trim(programacion.desFuente));
      this.desOtraFuente.setValue(trim(programacion.desOtraFuente));
      this.alcanse.setValue(trim(programacion.desAlcance));
      this.desProgramacion.setValue(trim(programacion.desProgramacion));
      this.periodoInicio.setValue(trim(programacion.perInicio));
      this.periodoFin.setValue(trim(programacion.perFin));
      this.observacion.setValue(trim(programacion.obsProgramacion));
      this.numInformeSeleccion.setValue(trim(programacion.numInformeSeleccion));

      if(programacion.archivoBean != null){
        this.archivoInformeSeleccion.setValue(trim(programacion.archivoBean.nomArchivo));
        this.archivoBeanInformeSeleccion = programacion.archivoBean;
      }else{
        this.archivoInformeSeleccion.setValue('');
        this.archivoBeanInformeSeleccion = new ArchivoBean();
      }

      await this.listarOrdenProgramacionInicial();

    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de programacion => ${result.mensaje}`);
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
    }
  }

  obtenerDerivarOrden(numeroProgramacion: string){

    this.derivacionOrdenService.obtenerDerivarOrden(toNumber(numeroProgramacion)).subscribe(
      result => {
        if (result.exito) {

          console.log(result.data); //Temporal eliminar

        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de derivacion => ${result.mensaje}`);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  async listarOrdenProgramacionInicial(){
    this.ordenesProgramaciones = [];

    let orden: OrdenAccion = new OrdenAccion();
    orden.numProgramacion = toNumber(this.numeroProgramacion);

    let result = await this.derivacionOrdenService.listarOrdenPrograma(orden).toPromise();

    if (result.exito) {
      this.ordenesProgramaciones = result.data;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de ordenes programacion => ${result.mensaje}`);
    }
  }

  async listarOrdenProgramacion(){
    this.ordenesProgramaciones = [];

    let orden: OrdenAccion = new OrdenAccion();
    orden.numProgramacion = toNumber(this.numeroProgramacion);
    orden.numOrden = toNumber(this.filtro.numOrden);
    orden.numDocIdent = trim(this.filtro.numDocumentoUsuario);
    orden.nomApeUsuario = trim(this.filtro.nomApellidoAuditor);

    if(orden.filtroValidoIU040()){

      let result = await this.derivacionOrdenService.listarOrdenPrograma(orden).toPromise();

      if (result.exito) {
        this.ordenesProgramaciones = result.data;
      } else {
        console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de ordenes programacion => ${result.mensaje}`);
      }

    }else{
      this.utilService.alertaMensaje(MensajesExcepciones.CUS16_EXCP_004, Constantes.MODAL_DANGER);
    }
  }

  derivarOrden(){
    this.limpiarCamposBuscarOrden();

    if(this.formaDerivarOrden.valid){

      if(this.ordenesProgramacionesSel == null || this.ordenesProgramacionesSel.length <= 0){
        this.utilService.alertaMensaje(MensajesExcepciones.CUS16_EXCP_005, Constantes.MODAL_DANGER);
        return false;
      }

      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE_DERIVAR,Constantes.MODAL_PRIMARY, () => {

        let ordenAccion: OrdenAccion = new OrdenAccion();
        ordenAccion.listOrden = this.ordenesProgramacionesSel;

        // console.log(JSON.stringify(orden));

        this.derivacionOrdenService.guardarDerivarOrden(ordenAccion).subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DERIVAR, Constantes.MODAL_SUCCESS);
            } else {
              if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_DERIVADOS}`, Constantes.MODAL_DANGER);
              }else{
                this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
              }
            }
          },
          error => {
            console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_DERIVADOS, Constantes.MODAL_DANGER);
          }
        );
        
      });
    } else {
      this.formaDerivarOrden.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }
  //Fin metodos Web Service
}
