import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CatalogoService, InterfazCatalogo} from 'iqbf';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { UtilService } from 'src/app/services/shared/util.service';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { OrdenAccion, ListOrdenAccion } from 'src/app/models/ordenAccion.model';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { trim, isEmpty, stringToMoment, padNumber, dateToString, isNotEmpty, formatDatePeriodoFront, formatDatePeriodoBack, toNumber,stringToMomentDDMMYYYY, dateToStringDDMMYYYY } from 'src/app/utils/utilitarios';
import { Constantes } from 'src/app/utils/constantes';
import { CancelacionOrdenService } from 'src/app/services/cancelacion-orden.service';

@Component({
  selector: 'app-cancelacion-oc-of',
  templateUrl: './cancelacion-oc-of.component.html',
  styleUrls: ['./cancelacion-oc-of.component.css']
})
export class CancelacionOcOfComponent implements OnInit {

   tipoOrdenes: InterfazCatalogo.Catalogo[] = [];
   codDataCatalogoTipoOrden: string;
   tipoDocUsuario: InterfazCatalogo.Catalogo[] = [];
   codDataCatalogoTipoDocUsuario: string;
   tipoEstadoOrdenes: InterfazCatalogo.Catalogo[] = [];
   codDataCatalogoTipoEstadoOrden: string;
   formBusqueda:FormGroup;
   submitted : boolean = false;
   mensaje:string = "";
   es: any;
   ordenes : OrdenAccion[];

   ordenSeleccionado:OrdenAccion;

  constructor(
    private router: Router,
    private catalogoService: CatalogoService,
    private cancelacionOrdenService: CancelacionOrdenService,
    private http: HttpClient,
    private utilService: UtilService,
    private formBuilder: FormBuilder,
    private rutaActiva: ActivatedRoute) { 
      this.createForm();
    this.cargarTiposOrdenes();
    this.cargarTiposDocUsuario();
    this.cargarTiposEstadoOrdenes();
  }

  ngOnInit() {
    this.es = {
      firstDayOfWeek: 0,
      dayNames: ["Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sábado"],
      dayNamesShort: ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"],
      dayNamesMin: ["Do","Lu","Ma","Mi","Ju","Vi","Sa"],
      monthNames: [ "Enero","Febrero","Marzo","Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" ],
      monthNamesShort: [ "Ene", "Feb", "Mar", "Abr", "May", "Jun","Jul", "Ago", "Sep", "Oct", "Nov", "Dic" ],
      today: 'Hoy',
      clear: 'Clear',
      dateFormat: 'mm/dd/yy',
      weekHeader: 'Sc'
  };
  }

  private createForm() {
    this.formBusqueda = this.formBuilder.group({
      cboTipoOrden: '',
      txtNroOrden: '',
      txtCalendarDesde: '',
      txtCalendarHasta: '',
      //['', Validators.required ],''
      cboTipoDocUsu: '',
      txtNroDocUsu: '',
      txtNroInfoSele: '',
      cboEstOrden: '',
      txtNroProg:'',
    });
  }


  cargarTiposOrdenes ():void{
    this.tipoOrdenes = [];
      this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_TIPO_ORDENES).subscribe(
        result => {
          this.tipoOrdenes =  result.data;
        },
        error => {
          console.log("Hubo errores ", error);
        }
      )
    }

    cargarTiposDocUsuario ():void{
      this.tipoDocUsuario = [];
        this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF).subscribe(
          result => {
            this.tipoDocUsuario =  result.data;
          },
          error => {
            console.log("Hubo errores ", error);
          }
        )
      }

      cargarTiposEstadoOrdenes ():void{
        this.tipoEstadoOrdenes = [];
          this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_ESTADO_ORDEN).subscribe(
            result => {
              this.tipoEstadoOrdenes =  result.data;
            },
            error => {
              console.log("Hubo errores ", error);
            }
          )
        }


      buscarOrdenes():void{
      let codTipOrden = this.formBusqueda.get('cboTipoOrden').value;
      let nroOrden = this.formBusqueda.get('txtNroOrden').value;
      let fechaDesde = this.formBusqueda.get('txtCalendarDesde').value;
      let fechaHasta = this.formBusqueda.get('txtCalendarHasta').value;
      let codTipoDoc = this.formBusqueda.get('cboTipoDocUsu').value;
      let numDoc = this.formBusqueda.get('txtNroDocUsu').value;
      let nroInfo = this.formBusqueda.get('txtNroInfoSele').value;
      let codEstOrden = this.formBusqueda.get('cboEstOrden').value;
      let nroProg = this.formBusqueda.get('txtNroProg').value;
      
      console.log("fechaDesde : " + fechaDesde);

      if(this.validar(codTipOrden) && this.validar(nroOrden) &&
      this.validar(fechaDesde) && this.validar(fechaHasta) &&
      this.validar(codTipoDoc) && this.validar(numDoc) &&
      this.validar(nroInfo) && this.validar(codEstOrden) && this.validar(nroProg)){
        this.mensaje = "Debe ingresar al menos un criterio de búsqueda";
        this.submitted = true;
        return;
      }

      this.mensaje = "";
      this.submitted = false;

      let filtro:ListOrdenAccion = new ListOrdenAccion();

      filtro ={
        codTipoOrden:codTipOrden,
        numOrden:nroOrden,
        fechaDesde: fechaDesde,
        fechaHasta:fechaHasta,
        codTipoDocumentoIdent:codTipoDoc,
        numDocIdent:numDoc,
        numInforSelec:nroInfo,
        codEstadoOrden:codEstOrden,
        numProgramacion:nroProg
       }

       this.cancelacionOrdenService.listarOrdenPrograma(filtro).subscribe(result => {     
        console.log("resultado : " + result);
        this.ordenes = result;
        if(this.ordenes == undefined){
          this.mensaje = "No existe datos.";
           this.submitted = true;
        }else{
          this.mensaje = "";
           this.submitted = false;
        }
      });
    }

     
    
    limpiar():void{
          this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
          this.router.navigate(['fiscalizacion/cancelacion-oc-of']));
      }

      validar(dato:any):boolean{
        return dato == undefined || dato == '';
      }


      // Limpiar Buscador  Fecha desde
validarFechaDesde() {
  let fechaDesde = this.formBusqueda.get('txtCalendarDesde').value;
      let fechaHasta = this.formBusqueda.get('txtCalendarHasta').value;
  const momentDesde = stringToMomentDDMMYYYY(fechaDesde);
  const momentHasta = stringToMomentDDMMYYYY(fechaHasta);
  this.submitted = false;
  if (momentDesde.isAfter(momentHasta)) {
    this.mensaje = MensajesExcepciones.CUS22_EXCP_002;
    this.submitted = true;
  }
  return  this.submitted ;
}
// Limpiar Buscador  Fecha Hasta
  validarFechaHasta() {
    let fechaDesde = this.formBusqueda.get('txtCalendarDesde').value;
    let fechaHasta = this.formBusqueda.get('txtCalendarHasta').value;
    const momentDesde = stringToMomentDDMMYYYY(fechaDesde);
    const momentHasta = stringToMomentDDMMYYYY(fechaHasta);
    const momentToday = stringToMomentDDMMYYYY(dateToStringDDMMYYYY(new Date()));
    this.submitted = false;
    if (momentHasta.isBefore(momentDesde)) {
      this.mensaje = MensajesExcepciones.CUS22_EXCP_001;
      this.submitted = true;
    } else if (momentHasta.isAfter(momentToday)) {
      this.mensaje = MensajesExcepciones.CUS22_EXCP_003;
      this.submitted = true;
    }
    return this.submitted;
  }


  cancelarOrden(orden:OrdenAccion):void{
   this.ordenSeleccionado = orden;
  }

}
