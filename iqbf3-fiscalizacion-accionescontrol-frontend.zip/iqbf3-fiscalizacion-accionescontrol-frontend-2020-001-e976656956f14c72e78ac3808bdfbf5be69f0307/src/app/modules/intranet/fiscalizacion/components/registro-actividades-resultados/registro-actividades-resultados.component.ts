import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-actividades-resultados',
  templateUrl: './registro-actividades-resultados.component.html',
  styleUrls: ['./registro-actividades-resultados.component.css']
})
export class RegistroActividadesResultadosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
