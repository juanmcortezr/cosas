import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-evaluar-resultados-definidos',
  templateUrl: './evaluar-resultados-definidos.component.html',
  styleUrls: ['./evaluar-resultados-definidos.component.css']
})
export class EvaluarResultadosDefinidosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
