import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mostrar-establecimiento',
  templateUrl: './mostrar-establecimiento.component.html',
  styleUrls: ['./mostrar-establecimiento.component.css']
})
export class MostrarEstablecimientoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
