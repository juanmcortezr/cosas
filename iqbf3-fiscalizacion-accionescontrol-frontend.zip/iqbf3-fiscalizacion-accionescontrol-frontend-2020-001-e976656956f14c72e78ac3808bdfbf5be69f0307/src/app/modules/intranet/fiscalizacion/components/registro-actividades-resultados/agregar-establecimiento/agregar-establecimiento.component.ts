import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agregar-establecimiento',
  templateUrl: './agregar-establecimiento.component.html',
  styleUrls: ['./agregar-establecimiento.component.css']
})
export class AgregarEstablecimientoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
