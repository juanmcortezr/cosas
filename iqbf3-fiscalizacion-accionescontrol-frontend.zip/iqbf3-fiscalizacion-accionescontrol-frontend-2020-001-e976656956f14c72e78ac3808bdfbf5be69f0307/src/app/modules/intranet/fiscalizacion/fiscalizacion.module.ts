import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FiscalizacionRoutingModule } from './fiscalizacion-routing.module';
import { DerivacionOcOfComponent } from './components/derivacion-oc-of/derivacion-oc-of.component';
import { RegistroActividadesResultadosComponent } from './components/registro-actividades-resultados/registro-actividades-resultados.component';
import { EvaluarInformeResultadosComponent } from './components/evaluar-informe-resultados/evaluar-informe-resultados.component';
import { CancelacionOcOfComponent } from './components/cancelacion-oc-of/cancelacion-oc-of.component';
import { primeNgModule } from 'src/app/app-primeng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DerivarOrdenesComponent } from './components/derivacion-oc-of/derivar-ordenes/derivar-ordenes.component';
import { RegistrarResultadosRealizadoComponent } from './components/registro-actividades-resultados/registrar-resultados-realizado/registrar-resultados-realizado.component';
import { AgregarEstablecimientoComponent } from './components/registro-actividades-resultados/agregar-establecimiento/agregar-establecimiento.component';
import { EvaluarResultadosOtrosComponent } from './components/evaluar-informe-resultados/evaluar-resultados-otros/evaluar-resultados-otros.component';
import { EvaluarResultadosDefinidosComponent } from './components/evaluar-informe-resultados/evaluar-resultados-definidos/evaluar-resultados-definidos.component';
import { MostrarEstablecimientoComponent } from './components/evaluar-informe-resultados/mostrar-establecimiento/mostrar-establecimiento.component';
import { RegistrarActividadesResultadosComponent } from './components/registro-actividades-resultados/registrar-actividades-resultados/registrar-actividades-resultados.component';
import { ModulesModule } from '../../modules.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { IqbfModule } from 'iqbf';



@NgModule({
  declarations: [
    DerivacionOcOfComponent, 
    RegistroActividadesResultadosComponent, 
    EvaluarInformeResultadosComponent, 
    CancelacionOcOfComponent, 
    DerivarOrdenesComponent, 
    RegistrarResultadosRealizadoComponent, 
    AgregarEstablecimientoComponent, 
    EvaluarResultadosOtrosComponent, 
    EvaluarResultadosDefinidosComponent, 
    MostrarEstablecimientoComponent, 
    RegistrarActividadesResultadosComponent
  ],
  imports: [
    CommonModule,
    FiscalizacionRoutingModule,
    primeNgModule,
    IqbfModule,
    FormsModule,
    NgbModule,
    ReactiveFormsModule,
    ModulesModule
  ]
})
export class FiscalizacionModule { }
