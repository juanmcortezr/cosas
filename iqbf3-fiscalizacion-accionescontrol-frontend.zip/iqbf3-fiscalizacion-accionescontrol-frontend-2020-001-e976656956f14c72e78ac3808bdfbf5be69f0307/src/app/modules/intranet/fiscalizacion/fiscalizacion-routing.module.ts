import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DerivacionOcOfComponent } from './components/derivacion-oc-of/derivacion-oc-of.component';
import { RegistroActividadesResultadosComponent } from './components/registro-actividades-resultados/registro-actividades-resultados.component';
import { EvaluarInformeResultadosComponent } from './components/evaluar-informe-resultados/evaluar-informe-resultados.component';
import { CancelacionOcOfComponent } from './components/cancelacion-oc-of/cancelacion-oc-of.component';
import { DerivarOrdenesComponent } from './components/derivacion-oc-of/derivar-ordenes/derivar-ordenes.component';
import { RegistrarResultadosRealizadoComponent } from './components/registro-actividades-resultados/registrar-resultados-realizado/registrar-resultados-realizado.component';
import { EvaluarResultadosOtrosComponent } from './components/evaluar-informe-resultados/evaluar-resultados-otros/evaluar-resultados-otros.component';
import { AgregarEstablecimientoComponent } from './components/registro-actividades-resultados/agregar-establecimiento/agregar-establecimiento.component'; 
import { EvaluarResultadosDefinidosComponent } from './components/evaluar-informe-resultados/evaluar-resultados-definidos/evaluar-resultados-definidos.component';
import { MostrarEstablecimientoComponent } from './components/evaluar-informe-resultados/mostrar-establecimiento/mostrar-establecimiento.component';
import { RegistrarActividadesResultadosComponent } from './components/registro-actividades-resultados/registrar-actividades-resultados/registrar-actividades-resultados.component';


const routes: Routes = [
  {path: 'derivacion-oc-of', component: DerivacionOcOfComponent},
  {path: 'registro-actividades-resultados', component: RegistroActividadesResultadosComponent},
  {path: 'evaluar-informe-resultados', component: EvaluarInformeResultadosComponent},
  {path: 'cancelacion-oc-of', component: CancelacionOcOfComponent},
  {path: 'derivacion-oc-of/derivar-orden/:numProgramacion', component: DerivarOrdenesComponent},
  {path: 'registro-actividades-resultados/registrar-resultados-realizado', component: RegistrarResultadosRealizadoComponent},
  {path: 'evaluar-informe-resultados/evaluar-resultados-otros', component: EvaluarResultadosOtrosComponent},
  {path: 'registro-actividades-resultados/agregar-establecimiento', component: AgregarEstablecimientoComponent},
  {path: 'evaluar-informe-resultados/evaluar-resultados-definidos', component: EvaluarResultadosDefinidosComponent},
  {path: 'evaluar-informe-resultados/mostrar-establecimiento', component: MostrarEstablecimientoComponent},
  {path: 'registro-actividades-resultados/registrar-actividades-resultados', component: RegistrarActividadesResultadosComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FiscalizacionRoutingModule { }
