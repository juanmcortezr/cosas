import { Component, OnInit } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { Mensaje } from 'src/app/models/interfaces/mensaje.model';
import { debounceTime } from 'rxjs/operators';
import { Constantes } from 'src/app/utils/constantes';
import { UtilService } from 'src/app/services/shared/util.service';

@Component({
  selector: 'app-avisos',
  templateUrl: './avisos.component.html',
  styleUrls: ['./avisos.component.css']
})
export class AvisosComponent implements OnInit {

  private suscripcionMensajes: Subscription; // Aquí almacenaremos la suscripción
  mensajeAlert: string = null;
  colorAlert: string = Constantes.MODAL_PRIMARY;

  constructor(private utilService: UtilService) {}

  ngOnInit() {

    this.suscripcionMensajes = this.utilService.escuchaMensaje().subscribe((msj: Mensaje) => {
      this.mensajeAlert = msj.mensajeAlert;
      this.colorAlert = msj.colorAlert;
    });
    this.utilService.escuchaMensaje().pipe(
      debounceTime(Constantes.ALERT_TIEMPO_3000)
    ).subscribe(() => {
      this.mensajeAlert = null;
      this.colorAlert = Constantes.MODAL_PRIMARY;
    });

  }

  ngOnDestroy(): void {
    this.utilService.alertaMensaje(null, Constantes.MODAL_PRIMARY);
    if (this.suscripcionMensajes) {
      this.suscripcionMensajes.unsubscribe();  // Cancelamos la suscripción cuando se destruya el componente
    }
  }
}
