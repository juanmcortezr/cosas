import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GestionProgramasDefinidosComponent } from './components/gestion-programas-definidos/gestion-programas-definidos.component';
import { GestionOtrosProgramasControlComponent } from './components/gestion-otros-programas-control/gestion-otros-programas-control.component';
import { BandejaProgramasAsignadosComponent } from './components/bandeja-programas-asignados/bandeja-programas-asignados.component';
import { EvaluacionProgramasInformeSelComponent } from './components/evaluacion-programas-informe-sel/evaluacion-programas-informe-sel.component';
import { AsignacionMasivaAuditoresPrincipalesComponent } from './components/asignacion-masiva-auditores-principales/asignacion-masiva-auditores-principales.component';
import { AsignacionReasignacionAuditoresComponent } from './components/asignacion-reasignacion-auditores/asignacion-reasignacion-auditores.component';
import { CompletarInformeSeleccionComponent } from './components/completar-informe-seleccion/completar-informe-seleccion.component';
import { ReasignarProgramacionInformeSeleccionComponent } from './components/reasignar-programacion-informe-seleccion/reasignar-programacion-informe-seleccion.component';
import { AsignacionMasivaOCComponent } from './components/asignacion-masiva-oc/asignacion-masiva-oc.component';
import { CargarFiscalizableComponent } from './components/bandeja-programas-asignados/cargar-fiscalizable/cargar-fiscalizable.component';
import { FormularioInformeSeleccionComponent } from './components/bandeja-programas-asignados/formulario-informe-seleccion/formulario-informe-seleccion.component';

import { EvaluarProgramaSeleccionComponent } from './components/evaluacion-programas-informe-sel/evaluar-programa-seleccion/evaluar-programa-seleccion.component';
import { RegistrarDocumentosSeleccionComponent } from './components/completar-informe-seleccion/registrar-documentos-seleccion/registrar-documentos-seleccion.component';
import { InformeSeleccionComponent } from './components/completar-informe-seleccion/informe-seleccion/informe-seleccion.component';
import { ActualizarProgramaDefinidoComponent } from './components/gestion-programas-definidos/actualizar-programa-definido/actualizar-programa-definido.component';
import { GuardarProgramacionComponent } from './components/gestion-otros-programas-control/guardar-programacion/guardar-programacion.component';
import { EvaluarProgramacionInformeOtrosComponent } from './components/evaluacion-programas-informe-sel/evaluar-programacion-informe-otros/evaluar-programacion-informe-otros.component';

const routes: Routes = [
  {path: 'gestion-programas-definidos', component: GestionProgramasDefinidosComponent},
  {path: 'gestion-otros-programas-control', component: GestionOtrosProgramasControlComponent},
  {path: 'bandeja-programas-asignados', component: BandejaProgramasAsignadosComponent},
  {path: 'bandeja-programas-asignados/formulario-informe-seleccion', component: FormularioInformeSeleccionComponent},
  {path: 'bandeja-programas-asignados/formulario-informe-seleccion/:numProgramacion', component: FormularioInformeSeleccionComponent},
  {path: 'evaluacion-programas-informe-sel', component: EvaluacionProgramasInformeSelComponent},
  {path: 'asignacion-masiva-auditores-principales', component: AsignacionMasivaAuditoresPrincipalesComponent},
  {path: 'asignacion-reasignacion-auditores', component: AsignacionReasignacionAuditoresComponent},
  {path: 'completar-informe-seleccion', component: CompletarInformeSeleccionComponent},
  {path: 'completar-informe-seleccion/informe-seleccion/:numProgramacion', component: InformeSeleccionComponent},
  {path: 'completar-informe-seleccion/registrar-documentos-seleccion/:numProgramacion/:numUsuarioPrograma', component: RegistrarDocumentosSeleccionComponent},
  {path: 'reasignar-programacion-informe-seleccion', component: ReasignarProgramacionInformeSeleccionComponent},
  {path: 'asignacion-masiva-oc', component: AsignacionMasivaOCComponent},
  {path: 'bandeja-programas-asignados/cargar-fiscalizable/:numProgramacion', component: CargarFiscalizableComponent},
  {path: 'evaluacion-programas-informe-sel/evaluar-programa-seleccion/:numProgramacion', component: EvaluarProgramaSeleccionComponent},
  {path: 'gestion-programas-definidos/actualizar-programa-definido/:numProgramacion', component: ActualizarProgramaDefinidoComponent},
  {path: 'gestion-otros-programas-control/guardar-programacion', component: GuardarProgramacionComponent},
  {path: 'gestion-otros-programas-control/guardar-programacion/:numProgramacion', component: GuardarProgramacionComponent},
  {path: 'evaluacion-programas-informe-sel/evaluar-otros/:numProgramacion', component: EvaluarProgramacionInformeOtrosComponent}

  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProgramacionRoutingModule { }
