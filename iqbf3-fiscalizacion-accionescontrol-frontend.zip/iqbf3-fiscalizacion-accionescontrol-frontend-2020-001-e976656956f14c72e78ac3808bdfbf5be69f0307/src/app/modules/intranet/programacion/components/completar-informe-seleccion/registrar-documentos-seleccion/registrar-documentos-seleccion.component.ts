import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Constantes } from 'src/app/utils/constantes';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { trim, toNumber } from 'src/app/utils/utilitarios';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { UtilService } from 'src/app/services/shared/util.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CompletarInformeService } from 'src/app/services/completar-informe.service';
import { ArchivoBean } from 'src/app/models/archivoBean.model';
import { UsuarioProgramacion } from 'src/app/models/usuarioProgramacion.model';
import { DocumentoAccion } from 'src/app/models/documentoAccion.model';
import { NgbActiveModal, NgbModalRef, NgbModal, NgbModalConfig, NgbTimepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { Programacion } from 'src/app/models/programacion.model';

@Component({
  selector: 'app-registrar-documentos-seleccion',
  templateUrl: './registrar-documentos-seleccion.component.html',
  styleUrls: ['./registrar-documentos-seleccion.component.css']
})
export class RegistrarDocumentosSeleccionComponent implements OnInit {

  //Inicio declaracion
  tipoLBL: string; //Indicar que es una etiqueta label
  numeroProgramacion: string = ''; //Numero de programacion para editar
  catalogoTipoDocAccion: string; //Codigo de catalogo tipo accion
  usuarioProgramacion: UsuarioProgramacion = new UsuarioProgramacion(); //Declarar e inicializar objeto usuarioProgramacion
  documentosAcciones: DocumentoAccion[] = []; //Almacena lista documentos acciones
  // archivoBeanInformeSeleccion: ArchivoBean = new ArchivoBean(); //Declarar e inicializar objeto para archivo
  verMgsCompletarInforme: boolean = false; //Ocultar mensaje de alerta registrar y editar completar informe
  verMgsDocumento: boolean = false; //Ocultar mensaje de alerta registrar y editar documento
  modalRef: NgbModalRef;
  formaCompletarInforme: FormGroup; //FormGroup
  formaDocumento: FormGroup; //FormGroup
  urlDescargaArchivo: string; // URL de descarga de archivo

  @ViewChild('mdlAgregarDocumento', {static: true}) mdlAgregarDocumento: NgbActiveModal;
  //Fin declaracion

  constructor(private router: Router,
    private rutaActiva: ActivatedRoute,
    // private gestionProgramaOtrosService: GestionProgramaOtrosService,
    private completarInformeService: CompletarInformeService,
    private utilService: UtilService,
    private modalService: NgbModal,
    private configModal: NgbModalConfig,
    private configTime: NgbTimepickerConfig) { 
      configModal.backdrop = 'static';
      configModal.keyboard = false;
      configTime.seconds = false;
      configTime.spinners = false;
    }

  ngOnInit() {
    this.inicio();
    this.limpiarCampos();
    this.acitvarMensaje(false, false);
  }

  //Inicio metodos componente
  async inicio() {

    this.numeroProgramacion = trim(this.rutaActiva.snapshot.params.numProgramacion);

    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;
    this.catalogoTipoDocAccion = ConstantesCatalogo.COD_CATALOGO_TIPO_DOCUMENTOTRABAJO;
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO;

    this.formaCompletarInforme = new FormGroup(
      {
        "tipoDocumento": new FormControl(''),
        "numDocumento": new FormControl(''),
        "nomRazonSocial": new FormControl(''),
        "tipoIntervencion": new FormControl(''),
        "tipoAccion": new FormControl(''),
        "auditorPrincipal": new FormControl(''),
        "cantidadDiasEstimadoAccion": new FormControl('', Validators.required),
        "fechaInicioCasoCitacion": new FormControl('', Validators.required),
        "horaAccion": new FormControl('', Validators.required)
      }
    );

    this.formaDocumento = new FormGroup(
      {
        "rdbDefaultOpcionDoc": new FormControl('', Validators.required),
        "tipoDocumentoDoc": new FormControl('', Validators.required),
        "numDocumentoDoc": new FormControl('', Validators.required),
        "fechaEmisionDoc": new FormControl('', Validators.required),
        "fechaNotificacionDoc": new FormControl('', Validators.required),
        "archivoDocumentoAccionDoc": new FormControl('', Validators.required)
      }
    );

    // await this.obtenerDatosProgramacion(this.numeroProgramacion);
    // this.obtenerCompletarInforme(this.numeroProgramacion);
  }

  limpiarCampos() {
    this.resetearFormaCompletarInforme();
    this.documentosAcciones = [];
  }

  resetearFormaCompletarInforme() {
    this.formaCompletarInforme.reset();
  }

  resetearFormaDocumento() {
    this.formaDocumento.reset();
  }

  acitvarMensaje(a: boolean, b: boolean) {
    this.verMgsCompletarInforme = a;
    this.verMgsDocumento = b;
  }

  //Propiedades formControl
  /* Completar informe */
  get tipoDocumento() { return this.formaCompletarInforme.get('tipoDocumento') as FormControl; }
  get numDocumento() { return this.formaCompletarInforme.get('numDocumento') as FormControl; }
  get nomRazonSocial() { return this.formaCompletarInforme.get('nomRazonSocial') as FormControl; }
  get tipoIntervencion() { return this.formaCompletarInforme.get('tipoIntervencion') as FormControl; }
  get tipoAccion() { return this.formaCompletarInforme.get('tipoAccion') as FormControl; }
  get auditorPrincipal() { return this.formaCompletarInforme.get('auditorPrincipal') as FormControl; }
  get cantidadDiasEstimadoAccion() { return this.formaCompletarInforme.get('cantidadDiasEstimadoAccion') as FormControl; }
  get fechaInicioCasoCitacion() { return this.formaCompletarInforme.get('fechaInicioCasoCitacion') as FormControl; }
  get horaAccion() { return this.formaCompletarInforme.get('horaAccion') as FormControl; }

  /* Documento */
  get rdbDefaultOpcionDoc() { return this.formaDocumento.get('rdbDefaultOpcionDoc') as FormControl; }
  get tipoDocumentoDoc() { return this.formaDocumento.get('tipoDocumentoDoc') as FormControl; }
  get numDocumentoDoc() { return this.formaDocumento.get('numDocumentoDoc') as FormControl; }
  get fechaEmisionDoc() { return this.formaDocumento.get('fechaEmisionDoc') as FormControl; }
  get fechaNotificacionDoc() { return this.formaDocumento.get('fechaNotificacionDoc') as FormControl; }
  get archivoDocumentoAccionDoc() { return this.formaDocumento.get('archivoDocumentoAccionDoc') as FormControl; }

  //Eventos botones
  eventoBtnAgregarDocumento(){
    // this.agregarDocumento();
    this.resetearFormaDocumento();
    this.modalRef = this.modalService.open(this.mdlAgregarDocumento, { size: 'lg' });
  }

  eventoBtnEliminarDocumento(documentoAccion: DocumentoAccion){
    // this.eliminarDocumento();
  }

  eventoBtnEditarDocumento(documentoAccion: DocumentoAccion){


    this.modalRef = this.modalService.open(this.mdlAgregarDocumento, { size: 'lg' });
  }

  eventoBtnGuardarDocumentoAccion(){
    this.guardarDocumentoAccion();
  }

  eventoBtnAnterior(){
    this.router.navigate(['/programacion/completar-informe-seleccion/informe-seleccion', this.numeroProgramacion]);
  }

  eventoBtnGuardarDocumentoInforme(){
    this.guardarDocumentoInforme();
  }

  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  // async obtenerDatosProgramacion(numeroProgramacion: string){

  //   let result = await this.gestionProgramaOtrosService.obtenerRegistrarPrograma(toNumber(numeroProgramacion)).toPromise();

  //   if (result.exito) {

  //     let programacion: Programacion = new Programacion();

  //     programacion = result.data;

  //     console.log(programacion); //Temporal eliminar
      
  //     this.numProgramacion.setValue(trim(programacion.numProgramacion));
  //     this.fechaProgramacion.setValue(trim(programacion.fecProgramacion));

  //   } else {
  //     console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de programacion => ${result.mensaje}`);
  //     this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
  //   }
  // }

  // obtenerCompletarInforme(numeroProgramacion: string){

  //   let programacion: Programacion = new Programacion();
  //   programacion.numProgramacion = toNumber(numeroProgramacion);

  //   this.completarInformeService.obtenerCompletarInforme(programacion).subscribe(
  //     result => {
  //       if (result.exito) {

  //         console.log(result.data); //Temporal eliminar

  //       } else {
  //         console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de completar informe => ${result.mensaje}`);
  //         this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
  //       }
  //     },
  //     error => {
  //       console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
  //     }
  //   );
  // }

  // async listarDocumentosAccion(){
  //   this.usuarios = [];

  //   let usuarioProgramacion: UsuarioProgramacion = new UsuarioProgramacion();
  //   usuarioProgramacion.numProgramacion = toNumber(this.numeroProgramacion);

  //   let result = await this.completarInformeService.listarUsuarioPrograma(usuarioProgramacion).toPromise();

  //   if (result.exito) {
  //     this.usuarios = result.data;
  //   } else {
  //     console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios programacion => ${result.mensaje}`);
  //   }
  // }

  guardarDocumentoAccion(){
    this.acitvarMensaje(false, true);

    if(this.formaDocumento.valid){

      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE,Constantes.MODAL_PRIMARY, () => {

        let documentoAccion: DocumentoAccion = new DocumentoAccion();
        //Asignar datos
        
        this.completarInformeService.guardarDocumentoAccion(documentoAccion).subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
              //Listar documentos
            } else {
              if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS}`, Constantes.MODAL_DANGER);
              }else{
                this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
              }
            }
          },
          error => {
            console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS, Constantes.MODAL_DANGER);
          }
        );
        
      });
    } else {
      this.formaDocumento.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }

  guardarDocumentoInforme(){
    this.acitvarMensaje(true, false);

    if(this.formaCompletarInforme.valid){

      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE,Constantes.MODAL_PRIMARY, () => {

        let documentoAccion: DocumentoAccion = new DocumentoAccion();
        //Asignar datos
        
        this.completarInformeService.guardarDocumentoInforme(documentoAccion).subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
            } else {
              if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS}`, Constantes.MODAL_DANGER);
              }else{
                this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
              }
            }
          },
          error => {
            console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS, Constantes.MODAL_DANGER);
          }
        );
        
      });
    } else {
      this.formaCompletarInforme.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }
  //Fin metodos Web Service

}
