import { Component, OnInit } from '@angular/core';
import { GestionProgramaDefinidoService } from 'src/app/services/gestion-programa-definido.service';
import { trim } from 'src/app/utils/utilitarios';
import { ActivatedRoute } from '@angular/router';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';

@Component({
  selector: 'app-actualizar-programa-definido',
  templateUrl: './actualizar-programa-definido.component.html',
  styleUrls: ['./actualizar-programa-definido.component.css']
})
export class ActualizarProgramaDefinidoComponent implements OnInit {

  // Catalogo
  catalogoNivelRiesgo: string;
  catalogoEstUsuAccion: string;
  catalogoMotivoDepu: string;
  catalogoMotivoDepuSub: string;
  parametroDependencia: string;

  constructor(private gestionProgramaDefinido: GestionProgramaDefinidoService,
              private rutaActiva: ActivatedRoute) { }

  ngOnInit() {
    this.catalogoNivelRiesgo = ConstantesCatalogo.COD_CATALOGO_NIVEL_DERIESGO;
    this.catalogoEstUsuAccion = ConstantesCatalogo.COD_CATALOGO_ESTADO_USUARIOACCION;
    this.catalogoMotivoDepu = ConstantesCatalogo.COD_CATALOGO_MOTIVOS_DEPURACION;
    this.catalogoMotivoDepuSub = ConstantesCatalogo.COD_MOTIVO_DEPURACION_SUBSANO_INCONSISTENCIA;
    this.parametroDependencia = ConstantesCatalogo.COD_PARAMETRO_DEPENDENCIAS;

    let numProgramacion = trim(this.rutaActiva.snapshot.params.numProgramacion);
    this.obtenerDatosProgramacionDefinido(numProgramacion);
  }

  obtenerDatosProgramacionDefinido(numProgramacion) {
    this.gestionProgramaDefinido.obtenerDatosActualizar(numProgramacion).subscribe(respuesta => {
      if (respuesta.exito) {
        console.log(respuesta);
      }
    });
  }

}
