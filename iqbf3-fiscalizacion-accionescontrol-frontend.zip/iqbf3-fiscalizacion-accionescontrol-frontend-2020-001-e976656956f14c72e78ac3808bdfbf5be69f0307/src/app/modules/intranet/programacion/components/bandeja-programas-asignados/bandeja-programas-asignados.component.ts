import { Component, OnInit } from '@angular/core';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { Constantes } from 'src/app/utils/constantes';
import { Programacion } from 'src/app/models/programacion.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { stringToMomentDDMMYYYY, dateToStringDDMMYYYY } from 'src/app/utils/utilitarios';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { GestionProgramaAsignadoService } from 'src/app/services/gestion-programa-asignado.service';

@Component({
  selector: 'app-bandeja-programas-asignados',
  templateUrl: './bandeja-programas-asignados.component.html',
  styleUrls: ['./bandeja-programas-asignados.component.css']
})
export class BandejaProgramasAsignadosComponent implements OnInit {

  //catalogo
  catalogoEstadoProg: string;
  catalogoEstadoInforme: string;
  permitidosEstadoProg: string[] = [];
  filtro: Programacion = new Programacion();

  listaPrograma: Programacion[];

  constructor(private utilService: UtilService,
            private gestionProgramaAsignadoService: GestionProgramaAsignadoService) { }

  ngOnInit() {
    this.catalogoEstadoProg = ConstantesCatalogo.COD_CATALOGO_ESTADOS_PROGRAMAS;
    this.catalogoEstadoInforme = ConstantesCatalogo.COD_CATALOGO_ESTADO_INFORMESELECCION;
    this.permitidosEstadoProg = Constantes.ESTADOS_PROGRAM_OTROS;
  }

  nuevoFiltro() {
    this.filtro = new Programacion();
    this.listaPrograma = [];
  }

  listarPrograma() {
    this.listaPrograma = [];
    if (!this.filtro.filtroValido()) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
      return false;
    }
    let valido = this.validarFechaHasta();
    if (valido) {
      valido = this.validarFechaDesde();
    }
    if (!valido) {
      return false;
    }
    this.gestionProgramaAsignadoService.listarPrograma(this.filtro).subscribe(
      result => {
        if (result.exito) {
          this.listaPrograma = (result.data as Programacion[]).map(y => Programacion.fromJSON(y));
        } else {
          this.listaPrograma = [];
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_SIN_RESULTADO, Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );
  }

  validarFechaHasta() {
    const momentDesde = stringToMomentDDMMYYYY(this.filtro.fechaDesde);
    const momentHasta = stringToMomentDDMMYYYY(this.filtro.fechaHasta);
    const momentToday = stringToMomentDDMMYYYY(dateToStringDDMMYYYY(new Date()));
    let valido = true;
    if (momentHasta.isBefore(momentDesde)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS06_EXCP_001, Constantes.MODAL_DANGER);
      valido = false;
    } else if (momentHasta.isAfter(momentToday)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS06_EXCP_003, Constantes.MODAL_DANGER);
      valido = false;
    }
    return valido;
  }

  validarFechaDesde() {
    const momentDesde = stringToMomentDDMMYYYY(this.filtro.fechaDesde);
    const momentHasta = stringToMomentDDMMYYYY(this.filtro.fechaHasta);
    let valido = true;
    if (momentDesde.isAfter(momentHasta)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS06_EXCP_002, Constantes.MODAL_DANGER);
      valido = false;
    }
    return valido;
  }
}
