import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EvaluacionProgramaService } from 'src/app/services/evaluacion-programa.service';
import { UtilService } from 'src/app/services/shared/util.service';
import { NgbModal, NgbModalConfig, NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Constantes } from 'src/app/utils/constantes';
import { trim, toNumber } from 'src/app/utils/utilitarios';
import { Actividades } from 'src/app/models/actividades.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { UsuarioProgramacion } from 'src/app/models/usuarioProgramacion.model';
import { Programacion } from 'src/app/models/programacion.model';
import { CheckElement } from 'src/app/models/checkElement.model';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { GestionProgramaDefinidoService } from 'src/app/services/gestion-programa-definido.service';
import { GestionProgramaOtrosService } from 'src/app/services/gestion-programa-otros.service';
import { GestionProgramaAsignadoService } from 'src/app/services/gestion-programa-asignado.service';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { ArchivoBean } from 'src/app/models/archivoBean.model';

@Component({
  selector: 'app-evaluar-programacion-informe-otros',
  templateUrl: './evaluar-programacion-informe-otros.component.html',
  styleUrls: ['./evaluar-programacion-informe-otros.component.css']
})
export class EvaluarProgramacionInformeOtrosComponent implements OnInit {

  //Inicio declaracion
  tipoLBL: string; //Indicar que es una etiqueta label
  numeroProgramacion: string = ''; //Numero de programacion para editar
  catalogoTipoDocIdentif: string; //Codigo de catalogo tipo de documento
  catalogoNivelRiesgo:string; //Codigo de catalogo nivel de riesgo
  catalogoDependencias:string; //Codigo de catalogo dependencia
  catalogoTipoAccionControl: string; //Codigo de catalogo tipo accion control
  programacion: Programacion = new Programacion(); //Declarar e inicializar objeto programacion
  inconsistencias: CheckElement[] = []; //Almacena lista de inconsistencias de programacion
  tiposBienes: CheckElement[] = []; //Almacena lista de tipo de bienes de programacion
  bienesFiscalizados: CheckElement[] = []; //Almacena lista de bienes fiscalizados programacion
  actividades: CheckElement[] = []; //Almacena lista de actividades de servicio programacion
  usuarios: UsuarioProgramacion[] = []; //Almacena lista de usuarios programacion
  filtro: any = {}; //Objeto filtro (Mapear datos ngModel)
  validTipDoc: any = {
    "requerido": false,
    "minLenght": 0,
    "maxLenght": Constantes.MAX_LENGHT_DOC_OTROS,
    "pattern": Constantes.VALOR_VACIO,
    "tipoDoc": Constantes.VALOR_VACIO,
    "tipoVal": Constantes.TIPO_VALI_ONLYNUMBERLETTER
  }; //Validar si es DNI o RUC
  archivoBeanInformeSelFisico: ArchivoBean = new ArchivoBean(); //Declarar e inicializar objeto para archivo
  archivoBeanReporteIncons: ArchivoBean = new ArchivoBean(); //Declarar e inicializar objeto para archivo
  archivoBeanOtroDocVinculado: ArchivoBean = new ArchivoBean(); //Declarar e inicializar objeto para archivo
  esTipoProgramacionBien: boolean = false; //Oculta seccion bien
  esTipoProgramacionServicio: boolean = false; //Oculta seccion servicio
  tieneArchivoReporteIncons: boolean = true; //Oculta boton descargar
  esPerfilSupervisor: boolean = false; //Validar perfil supervisor
  esPerfilGerente: boolean = false; //Validar perfil gerente
  readonlySustentoDevolucion: boolean = true; //Validar si ha seleccionado opcion devolver
  codigoEstadoAprobado: string = Constantes.VALOR_VACIO;
  codigoEstadoAutorizado: string = Constantes.VALOR_VACIO;
  codigoEstadoDevuelto: string = Constantes.VALOR_VACIO;
  modalRef: NgbModalRef;
  formaProgInformeOtro: FormGroup; //FormGroup para registrar y editar usuario de programacion
  formaVerDocumento: FormGroup; //FormGroup para ver documento de usuario
  urlDescargaArchivo: string; // URL de descarga de archivo

  @ViewChild('mdlVerDocumento', { static: true }) mdlVerDocumento: NgbActiveModal;
  //Fin declaracion

  constructor(private router: Router,
    private rutaActiva: ActivatedRoute,
    private modalService: NgbModal,
    private configModal: NgbModalConfig,
    private gestionProgramaOtrosService: GestionProgramaOtrosService,
    private gestionProgramaAsignadoService: GestionProgramaAsignadoService,
    private evaluacionProgramaService: EvaluacionProgramaService,
    private utilService: UtilService) {
    configModal.backdrop = 'static';
    configModal.keyboard = false;
  }

  ngOnInit() {
    this.limpiarCampos();
    this.limpiarCamposBuscarUsuario();
    this.inicio();
  }

  //Inicio metodos componente
  async inicio() {

    this.numeroProgramacion = trim(this.rutaActiva.snapshot.params.numProgramacion);

    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO;
    this.catalogoTipoDocIdentif = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
    this.catalogoNivelRiesgo = ConstantesCatalogo.COD_CATALOGO_NIVEL_DERIESGO; 
    this.catalogoDependencias= ConstantesCatalogo.COD_PARAMETRO_DEPENDENCIAS;
    this.catalogoTipoAccionControl = ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL;
    this.codigoEstadoAprobado = Constantes.COD_EST_PROGRAM_APROBADO;
    this.codigoEstadoAutorizado = Constantes.COD_EST_PROGRAM_AUTORIZADO;

    this.esPerfilSupervisor = false; //Validar con Sesion
    this.esPerfilGerente = true; //Validar con Sesion

    if(this.esPerfilSupervisor){
      this.codigoEstadoDevuelto = Constantes.COD_EST_PROGRAM_DEVUELTO_SUPERVISOR;
    }

    if(this.esPerfilGerente){
      this.codigoEstadoDevuelto = Constantes.COD_EST_PROGRAM_DEVUELTO_GERENCIA;
    }

    this.formaProgInformeOtro = new FormGroup(
      {
        "numProgramacion": new FormControl(''),
        "programaControl": new FormControl(''),
        "alcanse": new FormControl(''),
        "fechaProgramacion": new FormControl(''),
        "fuente": new FormControl(''),
        "desOtraFuente": new FormControl(''),
        "desProgramaControl": new FormControl(''),
        "observacion": new FormControl(''),
        "desBien": new FormControl(''),
        "numInforme": new FormControl(''),
        "archivoInformeSelFisico": new FormControl(''),
        "archivoReporteIncons": new FormControl(''),
        "rdbDefaultEvaProgOtro": new FormControl('', Validators.required),
        "sustentoDevolucion": new FormControl('', [Validators.required, Validators.maxLength(500)])
      }
    );

    this.formaVerDocumento = new FormGroup(
      {
        "tipoDocumentoUsu": new FormControl(''),
        "numDocumentoUsu": new FormControl(''),
        "nomRazonSocialUsu": new FormControl(''),
        "documentoVinculadoUsu": new FormControl(''),
        "numDocumentoVinculadoUsu": new FormControl(''),
        "archivoOtroDocVinculadoUsu": new FormControl('')
      }
    );

    this.eventoRdbDefaultEstablecimiento();

    await this.obtenerDatosProgramacion(this.numeroProgramacion);
    this.obtenerEvaluarPrograma(this.numeroProgramacion);
  }

  limpiarCampos() {
    this.esTipoProgramacionBien = false;
    this.esTipoProgramacionServicio = false;
    this.tieneArchivoReporteIncons = true;
    this.esPerfilSupervisor = false;
    this.esPerfilGerente = false;
    this.readonlySustentoDevolucion = true;
  
    this.usuarios = [];
  }

  limpiarCamposBuscarUsuario(){

    this.filtro = {
      nivelRiesgo: Constantes.VALOR_VACIO,
      dependencia: Constantes.VALOR_VACIO,
      tipoAccion: Constantes.VALOR_VACIO,
      tipoDocumento: Constantes.VALOR_VACIO,
      numDocumento: Constantes.VALOR_VACIO
    };

    this.validTipDoc = {
      "requerido": false,
      "minLenght": 0,
      "maxLenght": Constantes.MAX_LENGHT_DOC_OTROS,
      "pattern": Constantes.VALOR_VACIO,
      "tipoDoc": Constantes.VALOR_VACIO,
      "tipoVal": Constantes.TIPO_VALI_ONLYNUMBERLETTER
    };
  }

  resetearformaProgInformeOtro() {
    this.formaProgInformeOtro.reset();
  }

  //Propiedades formControl
  /* Evaluacion programa otros */
  get numProgramacion() { return this.formaProgInformeOtro.get('numProgramacion') as FormControl; }
  get programaControl() { return this.formaProgInformeOtro.get('programaControl') as FormControl; }
  get alcanse() { return this.formaProgInformeOtro.get('alcanse') as FormControl; }
  get fechaProgramacion() { return this.formaProgInformeOtro.get('fechaProgramacion') as FormControl; }
  get fuente() { return this.formaProgInformeOtro.get('fuente') as FormControl; }
  get desOtraFuente() { return this.formaProgInformeOtro.get('desOtraFuente') as FormControl; }
  get desProgramaControl() { return this.formaProgInformeOtro.get('desProgramaControl') as FormControl; }
  get observacion() { return this.formaProgInformeOtro.get('observacion') as FormControl; }
  get desBien() { return this.formaProgInformeOtro.get('desBien') as FormControl; }
  get numInforme() { return this.formaProgInformeOtro.get('numInforme') as FormControl; }
  get archivoInformeSelFisico() { return this.formaProgInformeOtro.get('archivoInformeSelFisico') as FormControl; }
  get archivoReporteIncons() { return this.formaProgInformeOtro.get('archivoReporteIncons') as FormControl; }
  get rdbDefaultEvaProgOtro() { return this.formaProgInformeOtro.get('rdbDefaultEvaProgOtro') as FormControl; }
  get sustentoDevolucion() { return this.formaProgInformeOtro.get('sustentoDevolucion') as FormControl; }

  /* Documento vinculado usuario */
  get tipoDocumentoUsu() { return this.formaVerDocumento.get('tipoDocumentoUsu') as FormControl; }
  get numDocumentoUsu() { return this.formaVerDocumento.get('numDocumentoUsu') as FormControl; }
  get nomRazonSocialUsu() { return this.formaVerDocumento.get('nomRazonSocialUsu') as FormControl; }
  get documentoVinculadoUsu() { return this.formaVerDocumento.get('documentoVinculadoUsu') as FormControl; }
  get numDocumentoVinculadoUsu() { return this.formaVerDocumento.get('numDocumentoVinculadoUsu') as FormControl; }
  get archivoOtroDocVinculadoUsu() { return this.formaVerDocumento.get('archivoOtroDocVinculadoUsu') as FormControl; }

  //Eventos
  eventoRdbDefaultEstablecimiento(){
    this.rdbDefaultEvaProgOtro.valueChanges.subscribe(valor => {
      valor = trim(valor);
      
      if(valor == Constantes.COD_EST_PROGRAM_APROBADO){
        this.readonlySustentoDevolucion = true;
        this.sustentoDevolucion.setValidators(null);
        this.sustentoDevolucion.setValue('');
      }else if(valor == Constantes.COD_EST_PROGRAM_AUTORIZADO){
        this.readonlySustentoDevolucion = true;
        this.sustentoDevolucion.setValidators(null);
        this.sustentoDevolucion.setValue('');
      }else if(valor == Constantes.COD_EST_PROGRAM_DEVUELTO_SUPERVISOR || 
        valor == Constantes.COD_EST_PROGRAM_DEVUELTO_GERENCIA){
        this.readonlySustentoDevolucion = false;
        this.sustentoDevolucion.setValidators([Validators.required, Validators.maxLength(500)]);
      }
  
      this.sustentoDevolucion.updateValueAndValidity();
      // this.sustentoDevolucion.reset();
    });
  }

  //Eventos combos
  eventoCboCodTipoDocIdentif(event: any){
    let valor = trim(event.target.value);

    if(valor == Constantes.TIPO_DOCUMENTO_DNI){
      this.validTipDoc.requerido = true;
      this.validTipDoc.minLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.pattern = Constantes.VALIDA_PATTERN_SOLO_NUMERO;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_DNI;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }else if(valor == Constantes.TIPO_DOCUMENTO_RUC){
      this.validTipDoc.requerido = true;
      this.validTipDoc.minLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.pattern = Constantes.VALIDA_PATTERN_SOLO_NUMERO;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_RUC;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }else{
      this.validTipDoc.requerido = false;
      this.validTipDoc.minLenght = 0;
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_OTROS;
      this.validTipDoc.pattern = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoDoc = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBERLETTER;
    }

  }

  //Eventos botones
  eventoBtnBuscarUsuario(){
    this.listarUsuariosProgramacion();
  }

  eventoBtnVerDocumentoVinculado(usuario: UsuarioProgramacion){
    console.log(usuario);

    this.tipoDocumentoUsu.setValue(trim(usuario.desTipoDocumentoIdent));
    this.numDocumentoUsu.setValue(trim(usuario.numDocumentoIdentif));
    this.nomRazonSocialUsu.setValue(trim(usuario.nomApellidoUsuario));
    this.documentoVinculadoUsu.setValue('');
    this.numDocumentoVinculadoUsu.setValue('');
    this.archivoOtroDocVinculadoUsu.setValue('');

    this.archivoBeanOtroDocVinculado = new ArchivoBean();

    this.modalRef = this.modalService.open(this.mdlVerDocumento, { size: 'lg' });
  }

  eventoBtnCancelar(){
    this.router.navigate(['/programacion/evaluacion-programas-informe-sel']);
  }

  eventoBtnGuardar(){
    this.guardarEvaluacionProgramacion();
  }

  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  async obtenerDatosProgramacion(numeroProgramacion: string){

    let result = await this.gestionProgramaOtrosService.obtenerRegistrarPrograma(toNumber(numeroProgramacion)).toPromise();

    if (result.exito) {

      let programacion: Programacion = new Programacion();

      programacion = result.data;

      console.log(programacion); //Temporal eliminar
      
      this.numProgramacion.setValue(trim(programacion.numProgramacion));
      this.programaControl.setValue(trim(programacion.desProgramaControl));
      this.alcanse.setValue(trim(programacion.desAlcance));
      this.fechaProgramacion.setValue(trim(programacion.fecProgramacion));
      this.fuente.setValue(trim(programacion.desFuente));
      this.desOtraFuente.setValue(trim(programacion.desOtraFuente));
      this.desProgramaControl.setValue(trim(programacion.desProgramacion));
      this.observacion.setValue(trim(programacion.obsProgramacion));
      this.desBien.setValue(trim(programacion.desOtroBien));
      this.numInforme.setValue(trim(programacion.numInforme));

      this.esTipoProgramacionBien = trim(programacion.codTipoProgram) == Constantes.COD_TIP_PROG_BIEN ? true : false;
      this.esTipoProgramacionServicio = trim(programacion.codTipoProgram) == Constantes.COD_TIP_PROG_SERVICIO ? true : false;

      if(programacion.archivoBean != null){
        this.archivoInformeSelFisico.setValue(trim(programacion.archivoBean.nomArchivo));
        this.archivoBeanInformeSelFisico = programacion.archivoBean;
      }else{
        this.archivoInformeSelFisico.setValue('');
        this.archivoBeanInformeSelFisico = new ArchivoBean();
      }

      if(programacion.archivoBean != null){
        this.tieneArchivoReporteIncons = true;
        this.archivoReporteIncons.setValue(trim(programacion.archivoBean.nomArchivo));
        this.archivoBeanReporteIncons = programacion.archivoBean;
      }else{
        this.tieneArchivoReporteIncons = false;
        this.archivoReporteIncons.setValue('');
        this.archivoBeanReporteIncons = new ArchivoBean();
      }

      // this.rdbDefaultEvaProgOtro.setValue(trim(programacion.codEstadoPrograma));
      this.sustentoDevolucion.setValue(trim(programacion.desSusCancela));

      this.inconsistencias = programacion.inconsistencias;
      this.tiposBienes = programacion.tipoBienes;
      this.bienesFiscalizados = programacion.bienesFiscalizados;
      this.actividades = programacion.actividades;

      await this.listarUsuariosProgramacionInicial();

    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de programacion => ${result.mensaje}`);
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
    }
  }

  obtenerEvaluarPrograma(numeroProgramacion: string){

    let programacion: Programacion = new Programacion();
    programacion.numProgramacion = toNumber(numeroProgramacion);

    this.evaluacionProgramaService.obtenerEvaluarPrograma(programacion).subscribe(
      result => {
        if (result.exito) {

          console.log(result.data); //Temporal eliminar

        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de evaluacion programa => ${result.mensaje}`);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  async listarUsuariosProgramacionInicial(){
    this.usuarios = [];

    let usuarioProgramacion: UsuarioProgramacion = new UsuarioProgramacion();
    usuarioProgramacion.numProgramacion = toNumber(this.numeroProgramacion);

    let result = await this.gestionProgramaAsignadoService.listarUsuario(usuarioProgramacion).toPromise();

    if (result.exito) {
      this.usuarios = result.data;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios programacion => ${result.mensaje}`);
    }
  }

  async listarUsuariosProgramacion(){
    this.usuarios = [];

    let usuarioProgramacion: UsuarioProgramacion = new UsuarioProgramacion();
    usuarioProgramacion.numProgramacion = toNumber(this.numeroProgramacion);
    usuarioProgramacion.codNivelRiesgo = trim(this.filtro.nivelRiesgo);
    usuarioProgramacion.codDependencia = trim(this.filtro.dependencia);
    usuarioProgramacion.codTipoAccion = trim(this.filtro.tipoAccion);
    usuarioProgramacion.codTipoDocumentoIdentif = trim(this.filtro.tipoDocumento);
    usuarioProgramacion.numDocumentoIdentif = trim(this.filtro.numDocumento);

    if(usuarioProgramacion.filtroValidoIU026()){

      let result = await this.gestionProgramaAsignadoService.listarUsuario(usuarioProgramacion).toPromise();

      if (result.exito) {
        this.usuarios = result.data;
      } else {
        console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios programacion => ${result.mensaje}`);
      }

    }
  }

  guardarEvaluacionProgramacion(){
    this.limpiarCamposBuscarUsuario();
    
    if(this.formaProgInformeOtro.valid){

      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE,Constantes.MODAL_PRIMARY, () => {

        let programacion: Programacion = new Programacion();
        programacion.numProgramacion = toNumber(this.numeroProgramacion);
        programacion.codEstadoPrograma = trim(this.rdbDefaultEvaProgOtro.value);
        programacion.desSusCancela = trim(this.sustentoDevolucion.value);
        programacion.numInforme = trim(this.numInforme.value);
        
        this.evaluacionProgramaService.guardarEvaluacionPrograma(programacion).subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
            } else {
              if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS}`, Constantes.MODAL_DANGER);
              }else{
                this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
              }
            }
          },
          error => {
            console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS, Constantes.MODAL_DANGER);
          }
        );
        
      });
    } else {
      this.formaProgInformeOtro.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }
  //Fin metodos Web Service
}