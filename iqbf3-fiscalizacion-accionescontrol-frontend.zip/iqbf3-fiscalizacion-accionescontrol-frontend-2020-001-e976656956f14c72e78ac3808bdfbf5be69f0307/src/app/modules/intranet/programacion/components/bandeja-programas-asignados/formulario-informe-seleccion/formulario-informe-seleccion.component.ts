//import utiles de angular
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CatalogoService } from 'iqbf';
import { UtilService } from 'src/app/services/shared/util.service';
import { NgbModal, NgbActiveModal, NgbModalRef, NgbModalConfig, NgbTimepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, Validators, FormControl,  AbstractControl  } from '@angular/forms';
//import constantes
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { Constantes } from 'src/app/utils/constantes';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
//utilitarios del proyecto
import { trim, isEmpty, stringToMoment, padNumber, dateToString, isNotEmpty, formatDatePeriodoFront, formatDatePeriodoBack, toNumber, formatHoraBack, formatHoraFront } from 'src/app/utils/utilitarios';
import { ArchivoBean } from 'src/app/models/archivoBean.model';//Sirve para importar Archivos
//Gestion de servicios
import { GestionProgramaAsignadoService } from 'src/app/services/gestion-programa-asignado.service';
import { ServicioWebService } from 'src/app/services/maestros/servicio-web.service';

//Variables de Modelo y Consulta
import { Programacion } from 'src/app/models/programacion.model';
import { UsuarioProgramacion } from 'src/app/models/usuarioProgramacion.model';
import { InformeSeleccion } from 'src/app/models/informeSeleccion.model';

import { Catalogo } from 'src/app/models/catalogo.model';
import { IfStmt } from '@angular/compiler';
import { toInteger } from '@ng-bootstrap/ng-bootstrap/util/util';
import { CheckElement } from 'src/app/models/checkElement.model';
import { empty } from 'rxjs';





@Component({
  selector: 'app-formulario-informe-seleccion',
  templateUrl: './formulario-informe-seleccion.component.html',
  styleUrls: ['./formulario-informe-seleccion.component.css']
})
export class FormularioInformeSeleccionComponent implements OnInit {
  //Variable Util
  tipoLBL: string; //Indicar que es una etiqueta label

  //Variables de Catalogos 
  catalogoTipoDocIdentif: string; //Codigo de catalogo de tipo de documento
  catalogoTipoDocVinculado:string; //Codigo de catalogo de documento vinculado
  catalogoNivelRiesgo:string;//Codigo de catalogo de Nivel de Riesgo
  catalogoDependencias:string;//Codigo de catalogo de Nivel de Riesgo
  catalogoTipoDocReferencia: string; //Codigo de catalogo de tipo de documento de referencia
  catalogoMotivosDepuracion:string; // Codigo de catalogo de Motivos de Depuracion
  catalogoTipoAccionControl: string; //Codigo de catalogo de accion de control
  catalogoMotivoDepuracionSubsanoInconsistencia:string; // Motivo depuracion Subsano Inconsistencia
  catalogoTipoIncosistencias: string; //Codigo de catalogo de inconsistencias
  catalogoTipoBien: string; //Codigo de catalogo de tipo de bien  
  //Fin catalogos

  //variables de Formulario
  formDatosProgramacion:FormGroup;
  formInformeSeleccion:FormGroup;
  formListarUsuario:FormGroup;
  formModalRegistrarProgDefinido:FormGroup;

  //variables Datos de Programacion
  numProgramacion: string = ''; //Numero de programacion
  programacion: Programacion = new Programacion();
  usuarioProgramacion: UsuarioProgramacion = new UsuarioProgramacion(); 
  usuarioProgramacionIU024 : UsuarioProgramacion = new UsuarioProgramacion(); 
  usuarioProgramacionIU023 : UsuarioProgramacion = new UsuarioProgramacion();   
  informeSeleccion:  InformeSeleccion=new InformeSeleccion();
  esServicio:boolean;//Sirve para ocultar o Mostrar Actividades
  esBien:boolean;//Sirve para ocultar o Mostrar Sección bienes fiscalizado / no fiscalizados
  tipoRadioButtonModel:string;// radio button que cambia combo de catalogos.
  catalogoVariable:string; // Variable del combo cambiante.
  comboVariable:string;// Variable del combo cambiante.
  mostrarComboIndNeutralizacion:boolean=false;
  indNeutralizacion:string=''; //variable del Combo IndNeutralizacion.
  desSusMotivo:string;

  //LISTAS
  catalogoInconsistencias: CheckElement[] = []; 
  catalogoTipoBienes: CheckElement[] = []; 
  catalogoBienesFiscalizados: CheckElement[] = []; 
  catalogoActividades: CheckElement[] = []; 
  usuarioProgramacionLista: UsuarioProgramacion[] = []; //Almacena lista de usuarioProgramacion
  usuarioProgramacionListaSel: UsuarioProgramacion[] = []; //Almacena lista de usuarioProgramacion seleccionadas
  usuariosProgramacionBean:UsuarioProgramacion;
  programacionListaIU023:Programacion[]=[];
  usuariosProgramacionOtraAccionLista: UsuarioProgramacion[] = []; //Almacena lista de usuarioProgramacion de otras acciones



  //Indicadores de Habilitado/deshabilitados
  des_HabiBtnActualizar:boolean;//variable que habilita el combo.
  des_HabiDesSusMotivo:boolean;//variable que habilita el combo.
  des_HabiDesComboVariable:boolean;//variable que habilita el combo.
  deLectura:boolean; 
  verMgsModalBuscar:boolean;
  verMgsModalActualizar:boolean;
  verMgsModalGuardar:boolean;
  verMgsModalIU24:boolean;
  

  //Archivos
  urlDescargaArchivoInformeSeleccion: string; // URL de descarga de archivo
  urlDescargaArchivoReporteInconsistencias: string; // URL de descarga de archivo
  urlDescargaArchivoVinculado: string;// URL de descarga de archivo
  extensionesPermitidasIU024: string[];
  extensionesPermitidasReporte: string[];
  extensionesPermitidasInforme: string[];

  sizeFile: number;
  messageExtensionIU024: string;
  messageExtensionReporte: string;
  messageExtensionInforme: string;
  messageSize: string;
  //Modales
  modalRef: NgbModalRef;
  @ViewChild('mdlRegistrarProgDefinido', {static: true}) mdlRegistrarProgDefinido: NgbActiveModal;
  @ViewChild('mdlDetalleAccionesUsuario', {static: true}) mdlDetalleAccionesUsuario: NgbActiveModal;
  
  constructor(private catalogoService: CatalogoService,
    private gestionProgramaAsignadoService: GestionProgramaAsignadoService,    
    private servicioWebService: ServicioWebService,
    private utilService: UtilService,
    private router: Router,
    private rutaActiva: ActivatedRoute,
    private modalService: NgbModal,
    private configModal: NgbModalConfig,
    private configTime: NgbTimepickerConfig) { 
      configModal.backdrop = 'static';
      configModal.keyboard = false;
      configTime.seconds = false;
      configTime.spinners = false;
    }

        
  ngOnInit() {
    this.CargarConstantes();
    this.inicio();
  }
  CargarConstantes(){
    this.catalogoTipoDocIdentif = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
    this.catalogoNivelRiesgo = ConstantesCatalogo.COD_CATALOGO_NIVEL_DERIESGO; 
    this.catalogoDependencias= ConstantesCatalogo.COD_PARAMETRO_DEPENDENCIAS;
    this.catalogoTipoAccionControl = ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL;
    this.catalogoMotivosDepuracion = ConstantesCatalogo.COD_CATALOGO_MOTIVOS_DEPURACION;
    this.catalogoMotivoDepuracionSubsanoInconsistencia= ConstantesCatalogo.COD_MOTIVO_DEPURACION_SUBSANO_INCONSISTENCIA; 
    this.catalogoTipoDocVinculado= ConstantesCatalogo.COD_CATALOGO_DOCUMENTO_VINCULADO 

    this.urlDescargaArchivoInformeSeleccion = ConstantesUris.URL_DESCARGA_ARCHIVO;
    this.urlDescargaArchivoReporteInconsistencias = ConstantesUris.URL_DESCARGA_ARCHIVO;
    this.urlDescargaArchivoVinculado= ConstantesUris.URL_DESCARGA_ARCHIVO;
    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;      
    this.catalogoTipoIncosistencias = ConstantesCatalogo.COD_CATALOGO_TIPO_INCONSISTENCIAS;
    this.catalogoTipoBien = ConstantesCatalogo.COD_CATALOGO_TIPO_BIEN;
    
  }
  activarMensaje(a: boolean, b: boolean, c: boolean,d: boolean) {         
    this.verMgsModalBuscar=a;
    this.verMgsModalActualizar=b;
    this.verMgsModalGuardar=c;
    this.verMgsModalIU24=d;    
  }  
  
  inicio(){
    debugger;
    this.extensionesPermitidasIU024 = [ Constantes.ARCHIVO_EXTENSION_PFD ];    
    this.extensionesPermitidasInforme = [ Constantes.ARCHIVO_EXTENSION_PFD ];
    this.extensionesPermitidasReporte = [ Constantes.ARCHIVO_EXTENSION_PFD,Constantes.ARCHIVO_EXTENSION_XLS ,Constantes.ARCHIVO_EXTENSION_EXCEL_XLSX,Constantes.ARCHIVO_EXTENSION_EXCEL_XLSM];

    this.sizeFile = Constantes.ARCHIVO_TAMANIO_2MB;
    this.messageExtensionIU024 = MensajesExcepciones.CUS09_EXCP_001;    
    this.messageExtensionInforme = MensajesExcepciones.CUS09_EXCP_001;
    this.messageExtensionReporte = MensajesExcepciones.CUS09_EXCP_010;

    this.messageSize = MensajesExcepciones.CUS07_EXCP_007;
    this.numProgramacion = trim(this.rutaActiva.snapshot.params.numProgramacion);
    this.nuevaProgramacion();
    this.nuevoFiltro();
    this.nuevoInforme();
    this.des_HabiDesSusMotivo=true;      
    this.des_HabiBtnActualizar=true;
    this.des_HabiDesComboVariable=true;
    this.formDatosProgramacion = new FormGroup({
      "numProgramacion": new FormControl(""),
      "fecIniAsignacion": new FormControl(''),
      "desProgramador": new FormControl(''),  
      "desFuente": new FormControl(''),        
      "desOtraFuente": new FormControl(''), 
      "desAlcance": new FormControl(''),         
      "desProgramacion": new FormControl(''), 
      "perInicio": new FormControl(''),
      "obsProgramacion": new FormControl(''),
      "perFin": new FormControl(''),
      "desTipoProgram": new FormControl('')
    }); 
    this.formInformeSeleccion = new FormGroup({
      "numCorrel": new FormControl('',[Validators.maxLength(4),Validators.pattern('^[0-9]*$')]),
      "anioInforme": new FormControl('',[Validators.maxLength(4),Validators.pattern('^[0-9]*$')]),
      "codUnidadOrganica": new FormControl('',Validators.maxLength(6)),
      "archivoInformeSeleccion": new FormControl(''),
      "archivoReporteInconsistencias": new FormControl(''),           
      "codNivelRiesgo":new FormControl(''),
      "codDependencia":new FormControl(''),
      "codTipoAccion":new FormControl(''),
      "codTipoDocumentoIdentif":new FormControl(''),
      "numUsuarioPrograma" :new FormControl('') ,      
      "tipoRadioButtonControl":  new FormControl(''),   
      "indNeutralizacionControl": new FormControl('') ,
      "catalogoVariableComboControl": new FormControl(''), 
      "desSusMotivoControl":new FormControl('')
    }); 
    this.formModalRegistrarProgDefinido = new FormGroup({
      "desTipoDocumentoIdentIU024": new FormControl(''),
      "numDocumentoIdentifIU024": new FormControl(''),
      "nomRazonSocialIU024": new FormControl(''), 
      "tipoDocumentoVinculadoIU024": new FormControl('',Validators.required),    
      "numeroDocumentoVinculadoIU024": new FormControl('',Validators.required),
      "archivoOtroDocumentoVinculado": new FormControl('')      
    }); 

    if (this.numProgramacion!="") {
      this.cargarRegistrarInforme();
    } else {
      
    }
  }
  buscar() {
    debugger;
    this.activarMensaje(true,false,false,false);    
    this.usuarioProgramacion.numProgramacion= toNumber(this.numProgramacion) ;
    if (!this.usuarioProgramacion.filtroValidoIU022()) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS22_EXCP_004, Constantes.MODAL_DANGER);
      return false;
    }
    this.gestionProgramaAsignadoService.listarUsuario(this.usuarioProgramacion).subscribe(
      result => {
        if (result.exito) {
          this.usuarioProgramacionLista=result.data; 
          this.usuarioProgramacionLista.forEach(element => {
            if(element.programacionBean.length>0){
              element.otrasAcciones="SI";
            }else{
              element.otrasAcciones=undefined;
            }

          });
          // if(this.usuarioProgramacionLista != null && this.usuarioProgramacionLista.length > 0){
          //   this.usuarioProgramacionLista.forEach(async element => {  
          //     element.usuariosBean = await this.listarOtraAccion(element);
          //   }); 
          // }
        } else {
          this.usuarioProgramacionLista= [];
          this.usuarioProgramacionListaSel= [];
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios => ${result.mensaje}`);
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );

  }


  // Limpiar valores de textos del Modal
  nuevaProgramacion() {
    this.programacion = new Programacion();  
  }
  nuevoFiltro() {
    this.usuarioProgramacion = new UsuarioProgramacion();  
  }
  nuevoInforme(){
    this.informeSeleccion = new InformeSeleccion();  
  }
  nuevoUsuariosProgramacionBean(){
    this.usuariosProgramacionBean = new UsuarioProgramacion();  
  }

  // ESTO ES LO QUE SUCEDE EN EL INICIO
  cargarRegistrarInforme(){
    debugger;
    this.esServicio=false;
    this.esBien=false;
    this.gestionProgramaAsignadoService.cargarRegistrarInforme(this.numProgramacion).subscribe(
      result => {
        if (result.exito) {
          debugger;         
          this.programacion.numProgramacion=Number(this.numProgramacion);
          this.programacion.fecIniAsignacion= result.data.fecIniAsignacion;
          this.programacion.desProgramador=result.data.desProgramador;
          this.programacion.desFuente=result.data.desFuente;
          this.programacion.desOtraFuente=result.data.desOtraFuente;
          this.programacion.desAlcance=result.data.desAlcance;
          this.programacion.desProgramacion=result.data.desProgramacion;
          this.programacion.perInicio=result.data.perInicio;
          this.programacion.obsProgramacion=result.data.obsProgramacion;
          this.programacion.perFin=result.data.perFin;
          this.programacion.desTipoProgram=result.data.desTipoProgram;
          //carga de Inasistencias.
          this.programacion.inconsistencias=result.data.inconsistencias;             
          this.catalogoInconsistencias=this.programacion.inconsistencias;
          //carga de tipoBienes.
          this.programacion.tipoBienes=result.data.tipoBienes;
          this.catalogoTipoBienes=this.programacion.tipoBienes;
          //carga de bienesFiscalizados.
          this.programacion.bienesFiscalizados=result.data.bienesFiscalizados;
          this.catalogoBienesFiscalizados=this.programacion.bienesFiscalizados;
          //carga de Actividades.
          this.programacion.actividades=result.data.actividades;
          this.catalogoActividades=this.programacion.actividades; 
          this.programacion.codTipoProgram= result.data.codTipoProgram;
          if (this.programacion.esServicio()){
            this.esServicio=true;
          }else{
            this.esServicio=false;
          }     
          if (this.programacion.esBien()){
            this.esBien=true;
          }else{
            this.esBien=false;
          } 
            if(result.data.informeSeleccion!=undefined){
              this.informeSeleccion=result.data.informeSeleccion;
                // this.informeSeleccion.anioInforme=result.data.informeSeleccion.anioInforme;
                // this.informeSeleccion.codEstadoInforme=result.data.informeSeleccion.codEstadoInforme;
                // this.informeSeleccion.codUnidadOrganica=result.data.informeSeleccion.codUnidadOrganica;
                // this.informeSeleccion.desEstadoInforme=result.data.informeSeleccion.desEstadoInforme;
                // this.informeSeleccion.desUnidadOrganica=result.data.informeSeleccion.desUnidadOrganica;
                // this.informeSeleccion.numCorrel=result.data.informeSeleccion.numCorrel;
                // this.informeSeleccion.numInformeSeleccion=result.data.informeSeleccion.numInformeSeleccion;
                // this.informeSeleccion.numProgramacion=result.data.informeSeleccion.numProgramacion;
                // this.informeSeleccion.archivoInforme=result.data.informeSeleccion.archivoInforme;
                // this.informeSeleccion.archivoReporte=result.data.informeSeleccion.archivoReporte;
            }
        } else {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS22_MENSAJE_F2_01, Constantes.MODAL_DANGER);
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );
  }

  // async listarOtraAccion(usuarioProgramacionFiltro:UsuarioProgramacion): Promise<UsuarioProgramacion[]>{
  //   debugger;
  //   let usuariosProgramacionOtraAccionLista: UsuarioProgramacion[] = [];
  //   let result = await this.gestionProgramaAsignadoService.listarOtraAccion(usuarioProgramacionFiltro).toPromise();
  //   if (result.exito) {
  //     usuariosProgramacionOtraAccionLista= result.data;            
  //   } else {
  //     usuariosProgramacionOtraAccionLista= [];
  //     console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios => ${result.mensaje}`);
  //   }
  //   return usuariosProgramacionOtraAccionLista;
  // }

  guardarInforme() {
    debugger;
    this.activarMensaje(false,false,true,false);    
    this.tipoRadioButtonControl.setValidators(null); 
    this.tipoRadioButtonControl.updateValueAndValidity();
    this.indNeutralizacionControl.setValidators(null);
    this.indNeutralizacionControl.updateValueAndValidity(); 
    this.catalogoVariableComboControl.setValidators(null);
    this.catalogoVariableComboControl.updateValueAndValidity(); 
    this.desSusMotivoControl.setValidators(null);
    this.desSusMotivoControl.updateValueAndValidity(); 
    if (this.formInformeSeleccion.valid){
      debugger;
      this.informeSeleccion.numProgramacion=toNumber(this.numProgramacion);
      this.informeSeleccion.archivoInforme=this.archivoInformeSeleccion.value;
      this.informeSeleccion.archivoReporte=this.archivoReporteInconsistencias.value;
      this.gestionProgramaAsignadoService.guardarInformeSeleccion(this.informeSeleccion).subscribe(
        result => {
          if (result.exito) {

            this.utilService.alertaMensaje("Creado Correctamente", Constantes.MODAL_SUCCESS);      
          } else {
            this.utilService.alertaMensaje(result.mensaje, Constantes.MODAL_DANGER);
          }
        },
        error => {
          console.log('Hubo errores ', error);
        }
      );
    }else{
      this.formInformeSeleccion.markAllAsTouched();
    }


  }
  //ACTUALIZAR
  guardarDepurarInforme(){  
    debugger;
    this.activarMensaje(false,true,false,false);
    this.nuevoUsuariosProgramacionBean();
    this.tipoRadioButtonControl.setValidators(Validators.required); 
    this.tipoRadioButtonControl.updateValueAndValidity();  
    if(this.tipoRadioButtonModel=="3"){       
      this.indNeutralizacionControl.setValidators(Validators.required);
      this.indNeutralizacionControl.updateValueAndValidity(); 
    }else{
      this.catalogoVariableComboControl.setValidators(Validators.required);
      this.catalogoVariableComboControl.updateValueAndValidity(); 
    }  
    if(this.des_HabiDesSusMotivo==false ) {
      this.desSusMotivoControl.setValidators(Validators.required);
      this.desSusMotivoControl.updateValueAndValidity(); 
    }else{
      this.desSusMotivoControl.setValidators(null);
      this.desSusMotivoControl.updateValueAndValidity(); 
    }

    if (this.formInformeSeleccion.valid){  
        //MODAL SI --NO
        this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE, Constantes.MODAL_PRIMARY, () => {
          if(this.tipoRadioButtonModel=="1"){
            this.usuariosProgramacionBean.codMotivaDepuracion = this.comboVariable;               
          }
          if(this.tipoRadioButtonModel=="2"){
            this.usuariosProgramacionBean.codTipoAccion = this.comboVariable;
          }
          if(this.tipoRadioButtonModel=="3"){
            this.usuariosProgramacionBean.indNeutralizacion = this.indNeutralizacion;
          }    
          this.usuariosProgramacionBean.numProgramacion=Number(this.numProgramacion);     
          this.usuariosProgramacionBean.usuariosBean= this.usuarioProgramacionListaSel;  
          this.gestionProgramaAsignadoService.guardarDepurarInforme(this.usuariosProgramacionBean).subscribe(
            result => {
              if (result.exito) {
                this.utilService.alertaMensaje("Creado Correctamente", Constantes.MODAL_SUCCESS);
              } else {
                this.utilService.alertaMensaje(MensajesExcepciones.CUS22_MENSAJE_F2_01, Constantes.MODAL_DANGER);
              }
            },
            error => {
              console.log('Hubo errores ', error);
            }
          );
        });     
    }else{
      this.formInformeSeleccion.markAllAsTouched();
    }


  }

  //VINCULADO GUARDAR IU24
  guardarDocumentoVinculado (){  
    this.activarMensaje(false,false,false,true);  
    debugger;   
    if (this.usuarioProgramacionIU024.tipoDocumentoVinculado=='99'){
      this.archivoOtroDocumentoVinculado.setValidators(Validators.required);
    }else{
      this.archivoOtroDocumentoVinculado.setValidators(null);
    }
    this.archivoOtroDocumentoVinculado.updateValueAndValidity();
    if (this.formModalRegistrarProgDefinido.valid){
      //MODAL SI --NO
      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE, Constantes.MODAL_PRIMARY, () => {
          this.usuarioProgramacionIU024.archivoVinculado=this.archivoOtroDocumentoVinculado.value;
          debugger;
          this.gestionProgramaAsignadoService.guardarDocumentoVinculado(this.usuarioProgramacionIU024).subscribe(
            result => {
              if (result.exito) {                
                this.usuarioProgramacionIU024.numDocumentoAccion=result.data.numDocumentoAccion;                

                this.utilService.alertaMensaje("Creado Correctamente", Constantes.MODAL_SUCCESS);
                
              } else {
                this.utilService.alertaMensaje(MensajesExcepciones.CUS22_MENSAJE_F2_01, Constantes.MODAL_DANGER);
              }
            },
            error => {
              console.log('Hubo errores ', error);
            }
          );
        }); 
    }else{
      this.formModalRegistrarProgDefinido.markAllAsTouched();
    }
  } 
 

  cerrarModalIU023(){
    // setTimeout(() => {
      this.modalRef.close();
      this.usuarioProgramacionIU023=new UsuarioProgramacion();

    // }, Constantes.ALERT_TIEMPO_2000);
  }
  cerrarModalIU024(){
    // setTimeout(() => {
      this.usuarioProgramacionIU024=new UsuarioProgramacion();
      this.modalRef.close();
      
  }
  async eventoBtnListaUsuariosAdjuntar(usuarioProgLista:UsuarioProgramacion) {
    debugger;
    this.usuarioProgramacionIU024=new UsuarioProgramacion();
    this.usuarioProgramacionIU024.numUsuarioPrograma=usuarioProgLista.numUsuarioPrograma;
    this.usuarioProgramacionIU024.desTipoDocumentoIdent=usuarioProgLista.desTipoDocumentoIdent; 
    this.usuarioProgramacionIU024.numDocumentoIdentif=usuarioProgLista.numDocumentoIdentif; 
    this.usuarioProgramacionIU024.nomApellidoUsuario=usuarioProgLista.nomApellidoUsuario;
    datosAdjuntos:new UsuarioProgramacion();
    const datosAdjuntos = await this.cargarDocumentoVinculado(this.usuarioProgramacionIU024);
    if(datosAdjuntos[0].numDocumentoAccion!=undefined){
      this.usuarioProgramacionIU024.numDocumentoAccion=datosAdjuntos[0].numDocumentoAccion;
      this.usuarioProgramacionIU024.tipoDocumentoVinculado=datosAdjuntos[0].tipoDocumentoVinculado;
      this.usuarioProgramacionIU024.numeroDocumentoVinculado=datosAdjuntos[0].numeroDocumentoVinculado;
      this.usuarioProgramacionIU024.archivoVinculado=datosAdjuntos[0].archivoVinculado;
    }
    this.activarMensaje(false,false,false,true);
    this.modalRef = this.modalService.open(this.mdlRegistrarProgDefinido, { size: 'lg' });
  }

  async cargarDocumentoVinculado(usuarioProgramacionFiltro:UsuarioProgramacion): Promise<UsuarioProgramacion>{
    debugger;
    let result = await this.gestionProgramaAsignadoService.cargarDocumentoVinculado (usuarioProgramacionFiltro).toPromise();
    if (result.exito) {
      usuarioProgramacionFiltro= result.data;            
    } else {
       console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios => ${result.mensaje}`);
    }
    return usuarioProgramacionFiltro;
  }

  //IU23
  async eventoBtnListaUsuariosSi(usuarioProgLista:UsuarioProgramacion) {
    debugger;
    this.usuarioProgramacionIU023=new UsuarioProgramacion();
    this.usuarioProgramacionIU023=usuarioProgLista;
    this.programacionListaIU023=this.usuarioProgramacionIU023.programacionBean;    
    this.modalRef = this.modalService.open(this.mdlDetalleAccionesUsuario, { size: 'lg' });
  }
  // cambia la variable catalogo asociado al combo catalogo dependiendo del radiobutton seleccionado.
  cambiarTipoRadioButton(){
    if(this.tipoRadioButtonModel=="1"){
      this.mostrarComboIndNeutralizacion=false;  
      this.catalogoVariable=this.catalogoMotivosDepuracion;
      this.des_HabiDesComboVariable=false;
      this.indNeutralizacion='';
    }
    if(this.tipoRadioButtonModel=="2"){
      this.mostrarComboIndNeutralizacion=false;  
      this.catalogoVariable=this.catalogoTipoAccionControl;
      this.des_HabiDesComboVariable=false;
      this.indNeutralizacion='';
    }
    if(this.tipoRadioButtonModel=="3"){
      this.comboVariable= undefined;
      this.catalogoVariable=undefined; 
      this.mostrarComboIndNeutralizacion=true;     
      this.des_HabiDesComboVariable=true;
      this.deLectura=true;
    }
  }
  cambioMotivoOtros(){    
    //radio button 1=catalogoMotivosDepuracion; //combo variable=99 es otros.
    if(this.tipoRadioButtonModel=="1" && this.comboVariable=='99'){
      this.des_HabiDesSusMotivo=false;  
      this.desSusMotivoControl.enable;    
    }else{
      this.des_HabiDesSusMotivo=true; 
      this.desSusMotivoControl.disable;  
    }     
  }   

  eventoCkbListaUsuariosAll(event: any){
    debugger;
    if(this.usuarioProgramacionLista != null && this.usuarioProgramacionLista.length > 0){
      if(event.target.checked){
        this.usuarioProgramacionLista.forEach(e => {
          e.seleccionado = true;   
          this.des_HabiBtnActualizar=false;
        });
        this.usuarioProgramacionListaSel = this.usuarioProgramacionLista;
      }else{
        this.usuarioProgramacionLista.forEach(e => {
          e.seleccionado = false;
        });
        this.usuarioProgramacionListaSel = [];    
        this.des_HabiBtnActualizar=true;
      }
    }
  }

  eventoCkbListaUsuarios(event: any, usuarioProgramacionXD: UsuarioProgramacion){
    debugger;
    this.usuarioProgramacionListaSel = this.usuarioProgramacionListaSel.filter(e => trim(e.numUsuarioPrograma) != trim(usuarioProgramacionXD.numUsuarioPrograma));    
    if(event.target.checked){
      usuarioProgramacionXD.seleccionado = true;
      this.usuarioProgramacionListaSel.push(usuarioProgramacionXD);       
    }else{      
      this.usuarioProgramacionListaSel.slice(this.usuarioProgramacionListaSel.indexOf(usuarioProgramacionXD));      
    }
    if(this.usuarioProgramacionListaSel.filter(x=> x.seleccionado==true).length>0){  
      this.des_HabiBtnActualizar=false;
    }else{    
      this.des_HabiBtnActualizar=true;
    }

  }
  //formInformeSeleccion
  
  get numCorrel() { return this.formInformeSeleccion.get('numCorrel') as FormControl; }
  get anioInforme() { return this.formInformeSeleccion.get('anioInforme') as FormControl; }
  get codUnidadOrganica() { return this.formInformeSeleccion.get('codUnidadOrganica') as FormControl; }
  get archivoInformeSeleccion() { return this.formInformeSeleccion.get('archivoInformeSeleccion') as FormControl; }
  get archivoReporteInconsistencias() { return this.formInformeSeleccion.get('archivoReporteInconsistencias') as FormControl; }
  get tipoRadioButtonControl() { return this.formInformeSeleccion.get('tipoRadioButtonControl') as FormControl; }
  get indNeutralizacionControl() { return this.formInformeSeleccion.get('indNeutralizacionControl') as FormControl; }
  get catalogoVariableComboControl() { return this.formInformeSeleccion.get('catalogoVariableComboControl') as FormControl; }
  get desSusMotivoControl() { return this.formInformeSeleccion.get('desSusMotivoControl') as FormControl; }



  //formModalRegistrarProgDefinido
  get archivoOtroDocumentoVinculado(){return this.formModalRegistrarProgDefinido.get('archivoOtroDocumentoVinculado') as FormControl; }
  get tipoDocumentoVinculadoIU024(){return this.formModalRegistrarProgDefinido.get('tipoDocumentoVinculadoIU024') as FormControl; }
  
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }
  
  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }

}
