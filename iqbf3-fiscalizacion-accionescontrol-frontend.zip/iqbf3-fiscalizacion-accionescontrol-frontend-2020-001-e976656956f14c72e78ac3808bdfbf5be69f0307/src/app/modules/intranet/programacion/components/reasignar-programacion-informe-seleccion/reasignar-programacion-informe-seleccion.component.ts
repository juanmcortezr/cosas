import { Component, OnInit } from '@angular/core';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { Router } from '@angular/router';
import { Programacion } from 'src/app/models/programacion.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { Constantes } from 'src/app/utils/constantes';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { ReasignacionProgramaService } from 'src/app/services/reasignacion-programa.service';

@Component({
  selector: 'app-reasignar-programacion-informe-seleccion',
  templateUrl: './reasignar-programacion-informe-seleccion.component.html',
  styleUrls: ['./reasignar-programacion-informe-seleccion.component.css']
})
export class ReasignarProgramacionInformeSeleccionComponent implements OnInit {
// Catalogo
catalogoEstadoProg: string;

filtro: any = {};
programacion: Programacion = new Programacion();
listaPrograma: Programacion[] = [];

constructor(private router: Router,
            private utilService: UtilService,
            private reasignacionProgramaService: ReasignacionProgramaService) { }

ngOnInit() {
  this.catalogoEstadoProg = ConstantesCatalogo.COD_CATALOGO_ESTADOS_PROGRAMAS;
  this.limpiarCampos();
}

limpiarCampos(){
  // Setear valores
  this.filtro = {
    numProgramacion: "",
    codProgramaControl: "",
    numInformeSeleccion: "",
    nomProgramador: "",
    nomProgramadorAdministrativo: "",
    codEstadoPrograma: ""
  };
  this.listaPrograma = [];
}

cargarRegistrarPrograma() {
  this.router.navigate(['/solicitudes/gestion-solicitudes-programacion/formulario']);
}


// Inicio metodos Web Service
listarProgramacion() {
  this.listaPrograma = [];
  this.programacion.numProgramacion = this.filtro.numProgramacion;
  this.programacion.codProgramaControl = this.filtro.codProgramaControl;
  this.programacion.numInformeSeleccion = this.filtro.numInformeSeleccion;
  this.programacion.nomProgramador = this.filtro.nomProgramador;
  this.programacion.nomProgramadorAdministrativo = this.filtro.nomProgramadorAdministrativo;
  this.programacion.codEstadoPrograma = this.filtro.codEstadoPrograma;

  console.log('Datos que estoy llevando', this.programacion);

  if (this.programacion.filtroValidoIU020()) {

      //this.listaPrograma = this.reasignacionProgramaService.listarProgramacion(this.programacion);

      // console.log('listaPrograma =>', this.listaPrograma);


  } else {
    this.utilService.alertaMensaje(MensajesExcepciones.CUS20_EXCP_001, Constantes.MODAL_DANGER);
  }

 }

}
