import { Component, OnInit } from '@angular/core';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { Router } from '@angular/router';
import { Programacion } from 'src/app/models/programacion.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { Constantes } from 'src/app/utils/constantes';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { CompletarInformeService } from "src/app/services/completar-informe.service";
import { toNumber, trim, stringToMomentDDMMYYYY, dateToStringDDMMYYYY } from 'src/app/utils/utilitarios';

@Component({
  selector: 'app-completar-informe-seleccion',
  templateUrl: './completar-informe-seleccion.component.html',
  styleUrls: ['./completar-informe-seleccion.component.css']
})

export class CompletarInformeSeleccionComponent implements OnInit {

  //Inicio declaracion
  programacion: Programacion = new Programacion(); //Declarar e inicializar objeto progrma control
  programaciones: Programacion[] = []; //Almacena lista programas de control
  soloNumero: string = Constantes.TIPO_VALI_ONLYNUMBER; //Validar que solo se ingrese numeros
  filtro: any = {}; //Objeto filtro (Mapear datos ngModel)
  //Fin declaracion

  constructor(private router: Router,
    private completarInformeService: CompletarInformeService,
    private utilService: UtilService) { }

  ngOnInit() {
    this.limpiarCampos();
    this.inicio();
  }

  //Inicio metodos componente
  inicio() {

  }

  limpiarCampos() {

    this.filtro = {
      numProgrmacion: Constantes.VALOR_VACIO,
      alcanseProgramaControl: Constantes.VALOR_VACIO,
      numInformeSeleccion: Constantes.VALOR_VACIO,
      fechaProgDesde: Constantes.VALOR_VACIO,
      fechaProgHasta: Constantes.VALOR_VACIO,
      programadorAsignado: Constantes.VALOR_VACIO
    };

    this.programaciones = [];
  }

  eventoBtnBuscar() {
    this.listarProgramaciones();
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  listarProgramaciones() {
    this.programaciones = [];
    let valido: boolean = false;

    this.programacion.numProgramacion = toNumber(this.filtro.numProgrmacion);
    this.programacion.numAlcanceProgramacion = trim(this.filtro.alcanseProgramaControl);
    this.programacion.numInformeSeleccion = trim(this.filtro.numInformeSeleccion);
    this.programacion.fechaDesde = trim(this.filtro.fechaProgDesde);
    this.programacion.fechaHasta = trim(this.filtro.fechaProgHasta);
    this.programacion.desProgramador = trim(this.filtro.programadorAsignado);

    if (this.programacion.filtroValidoIU035()) {

      valido = this.validarFechaHasta();

      if (valido) {
        valido = this.validarFechaDesde();
      }

      if (!valido) {
        return false;
      }

      this.completarInformeService.listarPrograma(this.programacion).subscribe(
        result => {
          if (result.exito) {
            this.programaciones = result.data;
          } else {
            console.log(result.mensaje);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_SIN_RESULTADO, Constantes.MODAL_PRIMARY);
          }
        },
        error => {
          console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
        }
      );
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS14_EXCP_004, Constantes.MODAL_DANGER);
    }
  }
  //Fin metodos Web Service

  //Inicio otros
  validarFechaDesde() {
    const momentDesde = stringToMomentDDMMYYYY(this.filtro.fechaProgDesde);
    const momentHasta = stringToMomentDDMMYYYY(this.filtro.fechaProgHasta);
    let valido: boolean = true;
    if (momentDesde.isAfter(momentHasta)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS14_EXCP_002, Constantes.MODAL_DANGER);
      valido = false;
    }
    return valido;
  }

  validarFechaHasta() {
    const momentDesde = stringToMomentDDMMYYYY(this.filtro.fechaProgDesde);
    const momentHasta = stringToMomentDDMMYYYY(this.filtro.fechaProgHasta);
    const momentToday = stringToMomentDDMMYYYY(dateToStringDDMMYYYY(new Date()));
    let valido: boolean = true;
    if (momentHasta.isBefore(momentDesde)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS14_EXCP_001, Constantes.MODAL_DANGER);
      valido = false;
    } else if (momentHasta.isAfter(momentToday)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS14_EXCP_003, Constantes.MODAL_DANGER);
      valido = false;
    }
    return valido;
  }
  //Fin otros
}
