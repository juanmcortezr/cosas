import { Component, OnInit } from '@angular/core';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { ActivatedRoute, Router } from '@angular/router';
import { CompletarInformeService } from "src/app/services/completar-informe.service";
import { Programacion } from "src/app/models/programacion.model";
import { UsuarioProgramacion } from "src/app/models/usuarioProgramacion.model";
import { UtilService } from 'src/app/services/shared/util.service';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { Constantes } from 'src/app/utils/constantes';
import { ArchivoBean } from 'src/app/models/archivoBean.model';
import { FormGroup, FormControl } from '@angular/forms';
import { trim, toNumber } from 'src/app/utils/utilitarios';
import { GestionProgramaOtrosService } from 'src/app/services/gestion-programa-otros.service';
import { ConstantesUris } from 'src/app/utils/constantes-uris';

@Component({
  selector: 'app-informe-seleccion',
  templateUrl: './informe-seleccion.component.html',
  styleUrls: ['./informe-seleccion.component.css']
})
export class InformeSeleccionComponent implements OnInit {
  
  //Inicio declaracion
  tipoLBL: string; //Indicar que es una etiqueta label
  numeroProgramacion: string = ''; //Numero de programacion para editar
  catalogoTipoDocIdentif: string; //Codigo de catalogo tipo de documento
  catalogoTipoAccion: string; //Codigo de catalogo tipo de accion
  programacion: Programacion = new Programacion(); //Declarar e inicializar objeto programacion
  usuarios: UsuarioProgramacion[] = []; //Almacena lista de usuarios programacion
  archivoBeanInformeSeleccion: ArchivoBean = new ArchivoBean(); //Declarar e inicializar objeto para archivo
  filtro: any = {}; //Objeto filtro (Mapear datos ngModel)
  validTipDoc: any = {
    "requerido": false,
    "minLenght": 0,
    "maxLenght": Constantes.MAX_LENGHT_DOC_OTROS,
    "pattern": Constantes.VALOR_VACIO,
    "tipoDoc": Constantes.VALOR_VACIO,
    "tipoVal": Constantes.TIPO_VALI_ONLYNUMBERLETTER
  }; //Validar si es DNI o RUC
  formaCompletarInforme: FormGroup; //FormGroup
  urlDescargaArchivo: string; // URL de descarga de archivo
  //Fin declaracion

  constructor(private router: Router,
    private rutaActiva: ActivatedRoute,
    private gestionProgramaOtrosService: GestionProgramaOtrosService,
    private completarInformeService: CompletarInformeService,
    private utilService: UtilService) {
    }

  ngOnInit() {
    this.limpiarCampos();
    this.limpiarCamposBuscarUsuario();
    this.inicio();
  }

  //Inicio metodos componente
  async inicio() {

    this.numeroProgramacion = trim(this.rutaActiva.snapshot.params.numProgramacion);

    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;
    this.catalogoTipoDocIdentif = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
    this.catalogoTipoAccion = ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL;
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO;

    this.formaCompletarInforme = new FormGroup(
      {
        "numProgramacion": new FormControl(''),
        "fechaProgramacion": new FormControl(''),
        "programador": new FormControl(''),
        "fuente": new FormControl(''),
        "desOtraFuente": new FormControl(''),
        "alcanse": new FormControl(''),
        "desProgramacion": new FormControl(''),
        "periodoInicio": new FormControl(''),
        "periodoFin": new FormControl(''),
        "observacion": new FormControl(''),
        "numInformeSeleccion": new FormControl(''),
        "archivoInformeSeleccion": new FormControl('')
      }
    );

    await this.obtenerDatosProgramacion(this.numeroProgramacion);
    this.obtenerCompletarInforme(this.numeroProgramacion);
  }

  limpiarCampos() {
    this.usuarios = [];
  }

  limpiarCamposBuscarUsuario() {
    this.filtro = {
      tipoDocumento: Constantes.VALOR_VACIO,
      numDocumento: Constantes.VALOR_VACIO,
      tipoAccion: Constantes.VALOR_VACIO
    };

    this.validTipDoc = {
      "requerido": false,
      "minLenght": 0,
      "maxLenght": Constantes.MAX_LENGHT_DOC_OTROS,
      "pattern": Constantes.VALOR_VACIO,
      "tipoDoc": Constantes.VALOR_VACIO,
      "tipoVal": Constantes.TIPO_VALI_ONLYNUMBERLETTER
    };
  }

  //Propiedades formControl
  get numProgramacion() { return this.formaCompletarInforme.get('numProgramacion') as FormControl; }
  get fechaProgramacion() { return this.formaCompletarInforme.get('fechaProgramacion') as FormControl; }
  get programador() { return this.formaCompletarInforme.get('programador') as FormControl; }
  get fuente() { return this.formaCompletarInforme.get('fuente') as FormControl; }
  get desOtraFuente() { return this.formaCompletarInforme.get('desOtraFuente') as FormControl; }
  get alcanse() { return this.formaCompletarInforme.get('alcanse') as FormControl; }
  get desProgramacion() { return this.formaCompletarInforme.get('desProgramacion') as FormControl; }
  get periodoInicio() { return this.formaCompletarInforme.get('periodoInicio') as FormControl; }
  get periodoFin() { return this.formaCompletarInforme.get('periodoFin') as FormControl; }
  get observacion() { return this.formaCompletarInforme.get('observacion') as FormControl; }
  get numInformeSeleccion() { return this.formaCompletarInforme.get('numInformeSeleccion') as FormControl; }
  get archivoInformeSeleccion() { return this.formaCompletarInforme.get('archivoInformeSeleccion') as FormControl; }

  //Eventos combos
  eventoCboCodTipoDocIdentif(event: any){
    let valor = trim(event.target.value);

    if(valor == Constantes.TIPO_DOCUMENTO_DNI){
      this.validTipDoc.requerido = true;
      this.validTipDoc.minLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.pattern = Constantes.VALIDA_PATTERN_SOLO_NUMERO;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_DNI;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }else if(valor == Constantes.TIPO_DOCUMENTO_RUC){
      this.validTipDoc.requerido = true;
      this.validTipDoc.minLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.pattern = Constantes.VALIDA_PATTERN_SOLO_NUMERO;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_RUC;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }else{
      this.validTipDoc.requerido = false;
      this.validTipDoc.minLenght = 0;
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_OTROS;
      this.validTipDoc.pattern = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoDoc = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBERLETTER;
    }

  }

  //Eventos botones
  eventoBtnBuscarUsuario(){
    this.listarUsuariosProgramacion();
  }

  eventoBtnCancelar(){
    this.router.navigate(['/programacion/completar-informe-seleccion']);
  }

  eventoBtnGuardarInformeSeleccion(){
    this.guardarInformeSeleccion();
  }

  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  async obtenerDatosProgramacion(numeroProgramacion: string){

    let result = await this.gestionProgramaOtrosService.obtenerRegistrarPrograma(toNumber(numeroProgramacion)).toPromise();

    if (result.exito) {

      let programacion: Programacion = new Programacion();

      programacion = result.data;

      console.log(programacion); //Temporal eliminar
      
      this.numProgramacion.setValue(trim(programacion.numProgramacion));
      this.fechaProgramacion.setValue(trim(programacion.fecProgramacion));
      this.programador.setValue(trim(programacion.desProgramador));
      this.fuente.setValue(trim(programacion.desFuente));
      this.desOtraFuente.setValue(trim(programacion.desOtraFuente));
      this.alcanse.setValue(trim(programacion.desAlcance));
      this.desProgramacion.setValue(trim(programacion.desProgramacion));
      this.periodoInicio.setValue(trim(programacion.perInicio));
      this.periodoFin.setValue(trim(programacion.perFin));
      this.observacion.setValue(trim(programacion.obsProgramacion));
      this.numInformeSeleccion.setValue(trim(programacion.numInformeSeleccion));

      if(programacion.archivoBean != null){
        this.archivoInformeSeleccion.setValue(trim(programacion.archivoBean.nomArchivo));
        this.archivoBeanInformeSeleccion = programacion.archivoBean;
      }else{
        this.archivoInformeSeleccion.setValue('');
        this.archivoBeanInformeSeleccion = new ArchivoBean();
      }

      await this.listarUsuariosProgramacionInicial();

    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de programacion => ${result.mensaje}`);
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
    }
  }

  obtenerCompletarInforme(numeroProgramacion: string){

    let programacion: Programacion = new Programacion();
    programacion.numProgramacion = toNumber(numeroProgramacion);

    this.completarInformeService.obtenerCompletarInforme(programacion).subscribe(
      result => {
        if (result.exito) {

          console.log(result.data); //Temporal eliminar

        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de completar informe => ${result.mensaje}`);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  async listarUsuariosProgramacionInicial(){
    this.usuarios = [];

    let usuarioProgramacion: UsuarioProgramacion = new UsuarioProgramacion();
    usuarioProgramacion.numProgramacion = toNumber(this.numeroProgramacion);

    let result = await this.completarInformeService.listarUsuarioPrograma(usuarioProgramacion).toPromise();

    if (result.exito) {
      this.usuarios = result.data;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios programacion => ${result.mensaje}`);
    }
  }

  async listarUsuariosProgramacion(){
    this.usuarios = [];

    let usuarioProgramacion: UsuarioProgramacion = new UsuarioProgramacion();
    usuarioProgramacion.numProgramacion = toNumber(this.numeroProgramacion);
    usuarioProgramacion.codTipoDocumentoIdentif = trim(this.filtro.tipoDocumento);
    usuarioProgramacion.numDocumentoIdentif = trim(this.filtro.numDocumento);
    usuarioProgramacion.codTipoAccion = trim(this.filtro.tipoAccion);

    if(usuarioProgramacion.filtroValidoIU036()){

      let result = await this.completarInformeService.listarUsuarioPrograma(usuarioProgramacion).toPromise();

      if (result.exito) {
        this.usuarios = result.data;

        console.log(result.data);
      } else {
        console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios programacion => ${result.mensaje}`);
      }

    }else{
      this.utilService.alertaMensaje(MensajesExcepciones.CUS14_EXCP_004, Constantes.MODAL_DANGER);
    }
  }

  guardarInformeSeleccion(){
    this.limpiarCamposBuscarUsuario();
    
    if(this.formaCompletarInforme.valid){

      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE,Constantes.MODAL_PRIMARY, () => {
        
        this.completarInformeService.guardarInformeSeleccion().subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
            } else {
              if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS}`, Constantes.MODAL_DANGER);
              }else{
                this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
              }
            }
          },
          error => {
            console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS, Constantes.MODAL_DANGER);
          }
        );
        
      });
    } else {
      this.formaCompletarInforme.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }
  //Fin metodos Web Service
}
