import { Component, OnInit, ViewChild } from '@angular/core';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { Router } from '@angular/router';
import { Programacion } from 'src/app/models/programacion.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { Constantes } from 'src/app/utils/constantes';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { GestionProgramaOtrosService } from 'src/app/services/gestion-programa-otros.service';
import { dateToString, stringToMomentDDMMYYYY, dateToStringDDMMYYYY, isEmpty } from 'src/app/utils/utilitarios';
import { NgbModal, NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Persona } from 'src/app/models/persona.model';

@Component({
  selector: 'app-gestion-otros-programas-control',
  templateUrl: './gestion-otros-programas-control.component.html',
  styleUrls: ['./gestion-otros-programas-control.component.css']
})
export class GestionOtrosProgramasControlComponent implements OnInit {

  // Catalogo
  verMsgsBandeja: boolean = false;
  verMsgsCancelacion: boolean = false;
  verMsgsAsignacion: boolean = false;
  catalogoEstadoProg: string;
  catalogoEstadoInforme: string;
  permitidosEstadoProg: string[] = [];
  filtro: Programacion = new Programacion();
  seleccionado: Programacion = new Programacion();

  listaPrograma: Programacion[];
  listaPersonas: Persona[] = [];
  modalRef: NgbModalRef;
  formRegCancelacion: FormGroup;
  formRegAsignar: FormGroup;

  @ViewChild('mdlVerListaAuditores', {static: true}) mdlVerListaAuditores: NgbActiveModal;
  @ViewChild('mdlCancelarProgramacion', {static: true}) mdlCancelarProgramacion: NgbActiveModal;

  constructor(private router: Router,
              private utilService: UtilService,
              private gestionProgramaOtros: GestionProgramaOtrosService,
              private modalService: NgbModal) { }

  ngOnInit() {
    this.catalogoEstadoProg = ConstantesCatalogo.COD_CATALOGO_ESTADOS_PROGRAMAS;
    this.catalogoEstadoInforme = ConstantesCatalogo.COD_CATALOGO_ESTADO_INFORMESELECCION;
    this.permitidosEstadoProg = Constantes.ESTADOS_PROGRAM_OTROS;
    this.formRegCancelacion = new FormGroup({
      "desSusCancela": new FormControl("", Validators.required),
      "numInformeCancelacion": new FormControl("")
    });
    this.formRegAsignar = new FormGroup({
      "codProgramador": new FormControl("", Validators.required)
    });
    this.nuevoFiltro();
  }

  nuevoFiltro() {
    this.filtro = new Programacion();
    this.listaPrograma = [];
  }

  eventoMostrarCancelar(prog: Programacion) {
    this.seleccionado = prog;
    this.formRegCancelacion.reset();
    this.modalRef = this.modalService.open(this.mdlCancelarProgramacion, {size : 'lg'});
  }

  eventoMostrarAsignar(prog: Programacion) {
    this.seleccionado = prog;
    this.formRegAsignar.reset();
    this.seleccionado.codProgramador = prog.codProgramador || '';
    this.listaPersonas = [];
    this.gestionProgramaOtros.listarProgramador().subscribe(
      result => {
        if (result.exito) {
          this.listaPersonas = result.data;
          this.modalRef = this.modalService.open(this.mdlVerListaAuditores, {size : 'lg'});
        } else {
          console.log(`No se ha obtenido las actividades`);
        }
      },
      error => {
        console.log("Hubo errores ", error);
      }
    );
  }

  eventoCancelar() {
    this.activarMensaje(false, true, false);
    if (this.formRegCancelacion.valid) {
      this.utilService.modalConfirmacion('Confirmaci\u00f3n',  '¿Est\u00e1 seguro que desea guardar?', Constantes.MODAL_PRIMARY, () => {
        this.gestionProgramaOtros.guardarCancelarPrograma(this.seleccionado).subscribe(rpta => {
          if (rpta.exito) {
            this.utilService.alertaMensaje('Se guard\u00f3 con \u00e9xito', Constantes.MODAL_SUCCESS);
            this.listarPrograma();
            this.cerrarModal();
          } else {
            this.utilService.alertaMensaje((rpta.mensaje), Constantes.MODAL_DANGER);
          }
        });
      });
    } else {
      this.formRegCancelacion.markAllAsTouched(); //Por formGroup
      //this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }

  eventoAsignar() {
    this.activarMensaje(false, false, true);
    if (this.formRegAsignar.valid) {
      this.utilService.modalConfirmacion('Confirmaci\u00f3n',  '¿Est\u00e1 seguro que desea guardar?', Constantes.MODAL_PRIMARY, () => {
        this.gestionProgramaOtros.guardarAsignarPrograma(this.seleccionado).subscribe(rpta => {
          if (rpta.exito) {
            this.utilService.alertaMensaje('Se guard\u00f3 con \u00e9xito', Constantes.MODAL_SUCCESS);
            this.listarPrograma();
            this.cerrarModal();
          } else {
            this.utilService.alertaMensaje((rpta.mensaje), Constantes.MODAL_DANGER);
          }
        });
      });
    } else {
      this.formRegCancelacion.markAllAsTouched(); //Por formGroup
      //this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }

  activarMensaje(bandeja: boolean, cancelacion: boolean, asignacion: boolean) {
    this.verMsgsBandeja = bandeja;
    this.verMsgsCancelacion = cancelacion;
    this.verMsgsAsignacion = asignacion;
  }

  listarPrograma() {
    this.activarMensaje(true, false, false);
    this.listaPrograma = [];
    if (!this.filtro.filtroValido()) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
      return false;
    }
    let valido = this.validarFechaHasta();
    if (valido) {
      valido = this.validarFechaDesde();
    }
    if (!valido) {
      return false;
    }
    this.gestionProgramaOtros.listarPrograma(this.filtro).subscribe(
      result => {
        if (result.exito) {
          this.listaPrograma = (result.data as Programacion[]).map(y => Programacion.fromJSON(y));
        } else {
          this.listaPrograma = [];
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_SIN_RESULTADO, Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );
  }

  cargarRegistrarPrograma() {
    this.router.navigate(['/solicitudes/gestion-solicitudes-programacion/formulario']);
  }

  validarFechaHasta() {
    const momentDesde = stringToMomentDDMMYYYY(this.filtro.fechaDesde);
    const momentHasta = stringToMomentDDMMYYYY(this.filtro.fechaHasta);
    const momentToday = stringToMomentDDMMYYYY(dateToStringDDMMYYYY(new Date()));
    let valido = true;
    this.activarMensaje(true, false, false);
    if (momentHasta.isBefore(momentDesde)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS06_EXCP_001, Constantes.MODAL_DANGER);
      valido = false;
    } else if (momentHasta.isAfter(momentToday)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS06_EXCP_003, Constantes.MODAL_DANGER);
      valido = false;
    }
    return valido;
  }

  validarFechaDesde() {
    const momentDesde = stringToMomentDDMMYYYY(this.filtro.fechaDesde);
    const momentHasta = stringToMomentDDMMYYYY(this.filtro.fechaHasta);
    let valido = true;
    this.activarMensaje(true, false, false);
    if (momentDesde.isAfter(momentHasta)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS06_EXCP_002, Constantes.MODAL_DANGER);
      valido = false;
    }
    return valido;
  }
  cerrarModal(){
    setTimeout(() => {
      this.modalRef.close();
    }, Constantes.ALERT_TIEMPO_1000);
  }
  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }

  getErrorLabel(groupName: FormGroup, controlName: string) {
    return this.getErrorClass(groupName, controlName, Constantes.ERROR_CLASS_FORM_CONTROL_LBL);
  }
  //Validaciones formControl
}
