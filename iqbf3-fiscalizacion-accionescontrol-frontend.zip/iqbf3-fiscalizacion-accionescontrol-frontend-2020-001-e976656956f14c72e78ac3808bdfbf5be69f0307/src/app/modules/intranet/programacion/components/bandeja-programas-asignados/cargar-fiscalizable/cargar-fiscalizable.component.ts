import { Component, OnInit, Inject } from '@angular/core';
import { trim, isNotEmpty } from 'src/app/utils/utilitarios';
import { ActivatedRoute } from '@angular/router';
import { Programacion } from 'src/app/models/programacion.model';
import { GestionProgramaAsignadoService } from 'src/app/services/gestion-programa-asignado.service';
import { Constantes } from 'src/app/utils/constantes';
import { Router } from '@angular/router';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { FileService } from 'iqbf';
import { ArchivoBean } from 'src/app/models/archivoBean.model';
import { UtilService } from 'src/app/services/shared/util.service';

@Component({
  selector: 'app-cargar-fiscalizable',
  templateUrl: './cargar-fiscalizable.component.html',
  styleUrls: ['./cargar-fiscalizable.component.css']
})
export class CargarFiscalizableComponent implements OnInit {

  programacion: Programacion = new Programacion();
  extensionesPermitidas: string[];
  sizeFile: number;
  messageExtension: string;
  messageSize: string;

  constructor(private router: Router,
              private rutaActiva: ActivatedRoute,
              @Inject(FileService) private fileService: FileService,
              private utilService: UtilService,
              private gestionProgramaAsignadoService: GestionProgramaAsignadoService) { }

  ngOnInit() {
    this.extensionesPermitidas = [ Constantes.ARCHIVO_EXTENSION_XLS ];
    this.sizeFile = Constantes.ARCHIVO_TAMANIO_2MB;
    this.messageExtension = MensajesExcepciones.CUS07_EXCP_006;
    this.messageSize = MensajesExcepciones.CUS07_EXCP_007;
    let numProgramacion = trim(this.rutaActiva.snapshot.params.numProgramacion);
    if (isNotEmpty(numProgramacion)) {
      this.gestionProgramaAsignadoService.obtenerCargarFiscalizable(numProgramacion).subscribe(data => {
        if (data.exito) {
          this.programacion = Programacion.fromJSON(data.data);
        }
      });
    }
  }

  descargarPlantilla() {
    this.gestionProgramaAsignadoService.obtenerPlantillaUniverso().subscribe(rpta => {
      if (rpta.exito) {
        let data = rpta.data as ArchivoBean;
        this.fileService.downloadFileB64(data.blobBase64, data.nomArchivo, data.desMimeType);
      }
    });
  }

  obtenerDetalleError() {
    this.gestionProgramaAsignadoService.obtenerDetalleError(this.programacion.numProgramacion).subscribe(rpta => {
      if (rpta.exito) {
        let data = rpta.data as ArchivoBean;
        this.fileService.downloadFileB64(data.blobBase64, data.nomArchivo, data.desMimeType);
      }
    });
  }

  cargar() {
    console.log(this.programacion);
    this.utilService.modalConfirmacion('Confirmaci\u00f3n', '¿Est\u00e1 seguro que desea cargar el archivo?', Constantes.MODAL_PRIMARY, () => {
      let envio = new Programacion();
      envio.numProgramacion = this.programacion.numProgramacion;
      envio.archivoBean = this.programacion.archivoBean;
      this.gestionProgramaAsignadoService.guardarUniversoFiscalizable(envio).subscribe(rpta => {
        console.log(rpta);
        if (rpta.exito) {
          this.router.navigate(['/programacion/bandeja-programas-asignados']);
        }
      });
    });
  }

}
