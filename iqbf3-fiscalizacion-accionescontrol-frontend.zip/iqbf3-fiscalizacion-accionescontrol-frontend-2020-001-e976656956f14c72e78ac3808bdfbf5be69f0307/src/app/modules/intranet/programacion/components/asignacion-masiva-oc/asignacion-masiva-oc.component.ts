import { Component, OnInit } from '@angular/core';
import { UtilService } from 'src/app/services/shared/util.service';
import { Router } from '@angular/router';
import { AsignacionMasivaAudtoresPrincipalService } from 'src/app/services/asignacion-masiva-auditores-principal.service';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { Constantes } from 'src/app/utils/constantes';
import { AsignacionMasivaAuditores } from 'src/app/models/asignacionMasivaAuditores.model';
import { trim } from 'src/app/utils/utilitarios';
import { FormGroup } from '@angular/forms';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-asignacion-masiva-oc',
  templateUrl: './asignacion-masiva-oc.component.html',
  styleUrls: ['./asignacion-masiva-oc.component.css']
})
export class AsignacionMasivaOCComponent implements OnInit {
  // Inico Declaración
  filtro: any = {};
  asignacionOC: any = {};
  auditoresVigentes: any = {};
  disabledButton = true;


  verMsgPrincipal: boolean = false;
  verMsgModal: boolean = false;

  asignacionMasivaAuditores: AsignacionMasivaAuditores = new AsignacionMasivaAuditores();
  listarAsignacionesMasivas: AsignacionMasivaAuditores[] = [];

  asignacionMasiva: FormGroup;

  listarAuditorVigente: AsignacionMasivaAuditores[] = [];


  // Inico Declaración
  constructor(private router: Router,
              private asignacionMasivaAudtoresPrincipalService: AsignacionMasivaAudtoresPrincipalService,
              private utilService: UtilService) { }

  ngOnInit() {
    this.limpiarCampos();
    this.listarSupervisionAuditor();
  }

  limpiarCampos(){
    // Setear valores
    this.filtro = {
      numProgramacion: "",
      numInformeSeleccion: ""
    };
    this.listarAsignacionesMasivas = [];
  }

  activarAlertMensaje(a: boolean, b: boolean) {
    this.verMsgPrincipal = a;
    this.verMsgModal = b;
  }


  eventoCkbAuditoresAll(evento: any) {
    if (evento.target.checked) {
      this.listarAuditorVigente.forEach(a => {
        a.seleccionado = true;
      });
    } else {
      this.listarAuditorVigente.forEach(a => {
        a.seleccionado = false;
      });
    }

  }

  eliminarAuditorPreseleccionado(numAsigTemp: string){
    this.asignacionMasivaAuditores = new AsignacionMasivaAuditores();
    this.asignacionMasivaAuditores.numAsigTemp = trim(numAsigTemp);
    console.log('numAsigTemp a Eliminar=> ',numAsigTemp);
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE_ELIMINAR ,
          Constantes.MODAL_PRIMARY, () => {

              this.listarAsignacionesMasivas = this.listarAsignacionesMasivas.filter(l => trim(l.numAsigTemp) !== trim(numAsigTemp));
              console.log('SE ESTA ELIMINANDO : ', this.asignacionMasivaAuditores.numAsigTemp);
        });
  }

  guardarAsignacion(asignacionMasivaAuditores: AsignacionMasivaAuditores){
    //Depende de datos del back - fin del flujo

    //Invocar a proceso
    ///asignarOrdenesNoConformeBatchServiceImpl

  }

  //MODALA - CUS 29

  //COMBO
  supervisiones: AsignacionMasivaAuditores[] = [];

  listarSupervisionAuditor(){
    this.filtro.cboSupervisiones = '';
    this.supervisiones = this.asignacionMasivaAudtoresPrincipalService.ListaSupervision();
  }



  listarAuditoresVigentes(numGrupo: string){
    this.activarAlertMensaje(false, true);
    this.listarAuditorVigente = [];
    this.asignacionMasivaAuditores.numGrupo = trim(numGrupo);

    console.log('NumGrupo', this.asignacionMasivaAuditores.numGrupo);

    this.asignacionMasivaAuditores.numGrupo = this.asignacionMasivaAuditores.numGrupo === '' ? ' ' : this.asignacionMasivaAuditores.numGrupo;

    this.listarAuditorVigente = this.asignacionMasivaAudtoresPrincipalService.ListaAsignacionPrueba(this.asignacionMasivaAuditores);

    this.listarAuditorVigente.forEach(a => {
      a.seleccionado = false;
    });

    console.log('listarAuditorVigente =>', this.listarAuditorVigente);
    const filtro = this.listarAuditorVigente.filter(a => (a.numGrupo  == this.asignacionMasivaAuditores.numGrupo) &&
    (trim(a.codProgramaCtrl) != Constantes.COD_TIP_PROG_OTROS) );
    console.log('filtro  =>',filtro);
    if (filtro.length == 0) {
        this.listarAuditorVigente = [];
        this.utilService.alertaMensaje(MensajesExcepciones.CUS29_EXCP_001, Constantes.MODAL_DANGER);
        return false;
    }

    this.listarAuditorVigente = filtro;
  }



  guardarAuditorPreselec(asignacionMasivaAuditores: AsignacionMasivaAuditores){
    //Pendiente - click Select (All)
  }



    // Inicio metodos Web Service
    listarResumenOrdenesNoConformes() {
      this.activarAlertMensaje(true, false);
      this.disabledButton = true;
      this.listarAsignacionesMasivas = [];
      this.asignacionMasivaAuditores.numProgramacion = trim(this.filtro.numProgramacion);
      this.asignacionMasivaAuditores.numInformeSeleccion = trim(this.filtro.numInformeSeleccion);

      console.log('Datos que estoy llevando', this.asignacionMasivaAuditores);

      if (this.asignacionMasivaAuditores.filtroValido()) {
          // AQUI FILTROS PARA LOS DATOS DE LA BUSQUEDA
          this.disabledButton = false;

          this.listarAsignacionesMasivas = this.asignacionMasivaAudtoresPrincipalService.ListaAsignacionPrueba(this.asignacionMasivaAuditores);

          console.log('listarAsignacionesMasivas =>', this.listarAsignacionesMasivas);

          ///////////////////////////////////////// El Nro. de programación o informe de selección no existe
          const filtro2 = this.listarAsignacionesMasivas.filter(a => (a.numProgramacion  === this.asignacionMasivaAuditores.numProgramacion) ||
          (a.numInformeSeleccion  === this.asignacionMasivaAuditores.numInformeSeleccion)) ;
          console.log('filtro 2 =>',filtro2);

          if (filtro2.length == 0) {
              this.listarAsignacionesMasivas = [];
              this.disabledButton = true;
              this.utilService.alertaMensaje(MensajesExcepciones.CUS29_EXCP_002, Constantes.MODAL_DANGER);
              return false;
          }

          /////////////////////////////////////////////// El Nro. de programación o informe de selección no corresponde a un programa definido
          const filtro3 = this.listarAsignacionesMasivas.filter(a => ((a.numProgramacion  === this.asignacionMasivaAuditores.numProgramacion) ||
          (a.numInformeSeleccion  === this.asignacionMasivaAuditores.numInformeSeleccion)) &&
          (trim(a.codProgramaCtrl) == Constantes.COD_TIP_PROG_OTROS));
          console.log('filtro 3 =>',filtro3);

          if (filtro3.length > 0) {
              this.listarAsignacionesMasivas = [];
              this.disabledButton = true;
              this.utilService.alertaMensaje(MensajesExcepciones.CUS29_EXCP_003, Constantes.MODAL_DANGER);
              return false;
          }
          /////////////////////////////////////

          this.listarAsignacionesMasivas = filtro2;

      } else {
        this.utilService.alertaMensaje(MensajesExcepciones.CUS29_EXCP_001, Constantes.MODAL_DANGER);
      }

     }

}
