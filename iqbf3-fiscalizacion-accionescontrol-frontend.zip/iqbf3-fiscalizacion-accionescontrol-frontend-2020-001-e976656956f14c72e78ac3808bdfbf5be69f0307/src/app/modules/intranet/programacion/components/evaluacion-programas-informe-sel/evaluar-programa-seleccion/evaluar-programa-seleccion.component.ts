import { Component, OnInit } from '@angular/core';
import { Constantes } from 'src/app/utils/constantes';
import { UtilService } from 'src/app/services/shared/util.service';
import { Router, ActivatedRoute } from '@angular/router';
import { trim, toNumber } from 'src/app/utils/utilitarios';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Programacion } from 'src/app/models/programacion.model';
import { ArchivoBean } from 'src/app/models/archivoBean.model';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { UsuarioProgramacion } from 'src/app/models/usuarioProgramacion.model';
import { GestionProgramaAsignadoService } from 'src/app/services/gestion-programa-asignado.service';
import { GestionProgramaOtrosService } from 'src/app/services/gestion-programa-otros.service';
import { EvaluacionProgramaService } from 'src/app/services/evaluacion-programa.service';

@Component({
  selector: 'app-evaluar-programa-seleccion',
  templateUrl: './evaluar-programa-seleccion.component.html',
  styleUrls: ['./evaluar-programa-seleccion.component.css']
})
export class EvaluarProgramaSeleccionComponent implements OnInit {

  //Inicio declaracion
  tipoLBL: string; //Indicar que es una etiqueta label
  numeroProgramacion: string = ''; //Numero de programacion para editar
  programacion: Programacion = new Programacion(); //Declarar e inicializar objeto programacion
  usuarios: UsuarioProgramacion[] = []; //Almacena lista de usuarios programacion
  tieneInformeSeleccion: boolean = false; //Oculta seccion informe seleccion
  esPerfilSupervisor: boolean = false; //Validar perfil supervisor
  esPerfilGerente: boolean = false; //Validar perfil gerente
  readonlySustentoDevolucion: boolean = true; //Validar si ha seleccionado opcion devolver
  codigoEstadoAprobado: string = Constantes.VALOR_VACIO;
  codigoEstadoAutorizado: string = Constantes.VALOR_VACIO;
  codigoEstadoDevuelto: string = Constantes.VALOR_VACIO;
  archivoBeanInformeSelFisico: ArchivoBean = new ArchivoBean();
  formaProgInformeDefinido: FormGroup; //FormGroup para registrar y editar usuario de programacion
  urlDescargaArchivo: string; // URL de descarga de archivo
  //Fin declaracion

  constructor(private router: Router,
    private rutaActiva: ActivatedRoute,
    private gestionProgramaOtrosService: GestionProgramaOtrosService,
    private gestionProgramaAsignadoService: GestionProgramaAsignadoService,
    private evaluacionProgramaService: EvaluacionProgramaService,
    private utilService: UtilService) {
  }

  ngOnInit() {
    this.limpiarCampos();
    this.inicio();
  }

  //Inicio metodos componente
  async inicio() {

    this.numeroProgramacion = trim(this.rutaActiva.snapshot.params.numProgramacion);

    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO;
    this.codigoEstadoAprobado = Constantes.COD_EST_PROGRAM_APROBADO;
    this.codigoEstadoAutorizado = Constantes.COD_EST_PROGRAM_AUTORIZADO;

    this.esPerfilSupervisor = false; //Validar con Sesion
    this.esPerfilGerente = true; //Validar con Sesion

    if(this.esPerfilSupervisor){
      this.codigoEstadoDevuelto = Constantes.COD_EST_PROGRAM_DEVUELTO_SUPERVISOR;
    }

    if(this.esPerfilGerente){
      this.codigoEstadoDevuelto = Constantes.COD_EST_PROGRAM_DEVUELTO_GERENCIA;
    }

    this.formaProgInformeDefinido = new FormGroup(
      {
        "numProgramacion": new FormControl(''),
        "programaControl": new FormControl(''),
        "alcanse": new FormControl(''),
        "fechaProgramacion": new FormControl(''),
        "programador": new FormControl(''),
        "plazoAtencion": new FormControl(''),
        "desProgramaControl": new FormControl(''),
        "cierreAutomatico": new FormControl(''),
        "observacion": new FormControl(''),
        "numInforme": new FormControl(''),
        "archivoInformeSelFisico": new FormControl(''),
        "rdbDefaultEvaProgDef": new FormControl('', Validators.required),
        "sustentoDevolucion": new FormControl('', Validators.required)
      }
    );

    this.eventoRdbDefaultEstablecimiento();

    await this.obtenerDatosProgramacion(this.numeroProgramacion);
    this.obtenerEvaluarPrograma(this.numeroProgramacion);
  }

  limpiarCampos() {
    this.tieneInformeSeleccion = false;
    this.esPerfilSupervisor = false;
    this.esPerfilGerente = false;
    this.readonlySustentoDevolucion = true;

    this.usuarios = [];
  }

  resetearformaProgInformeOtro() {
    this.formaProgInformeDefinido.reset();
  }

  //Propiedades formControl
  get numProgramacion() { return this.formaProgInformeDefinido.get('numProgramacion') as FormControl; }
  get programaControl() { return this.formaProgInformeDefinido.get('programaControl') as FormControl; }
  get alcanse() { return this.formaProgInformeDefinido.get('alcanse') as FormControl; }
  get fechaProgramacion() { return this.formaProgInformeDefinido.get('fechaProgramacion') as FormControl; }
  get programador() { return this.formaProgInformeDefinido.get('programador') as FormControl; }
  get plazoAtencion() { return this.formaProgInformeDefinido.get('plazoAtencion') as FormControl; }
  get desProgramaControl() { return this.formaProgInformeDefinido.get('desProgramaControl') as FormControl; }
  get cierreAutomatico() { return this.formaProgInformeDefinido.get('cierreAutomatico') as FormControl; }
  get observacion() { return this.formaProgInformeDefinido.get('observacion') as FormControl; }
  get numInforme() { return this.formaProgInformeDefinido.get('numInforme') as FormControl; }
  get archivoInformeSelFisico() { return this.formaProgInformeDefinido.get('archivoInformeSelFisico') as FormControl; }
  get rdbDefaultEvaProgDef() { return this.formaProgInformeDefinido.get('rdbDefaultEvaProgDef') as FormControl; }
  get sustentoDevolucion() { return this.formaProgInformeDefinido.get('sustentoDevolucion') as FormControl; }

  //Eventos
  eventoRdbDefaultEstablecimiento(){
    this.rdbDefaultEvaProgDef.valueChanges.subscribe(valor => {
      valor = trim(valor);
      
      if(valor == Constantes.COD_EST_PROGRAM_APROBADO){
        this.readonlySustentoDevolucion = true;
        this.sustentoDevolucion.setValidators(null);
        this.sustentoDevolucion.setValue('');
      }else if(valor == Constantes.COD_EST_PROGRAM_AUTORIZADO){
        this.readonlySustentoDevolucion = true;
        this.sustentoDevolucion.setValidators(null);
        this.sustentoDevolucion.setValue('');
      }else if(valor == Constantes.COD_EST_PROGRAM_DEVUELTO_SUPERVISOR || 
        valor == Constantes.COD_EST_PROGRAM_DEVUELTO_GERENCIA){
        this.readonlySustentoDevolucion = false;
        this.sustentoDevolucion.setValidators(Validators.required);
      }
  
      this.sustentoDevolucion.updateValueAndValidity();
      // this.sustentoDevolucion.reset();
    });
  }

  eventoBtnCancelar(){
    this.router.navigate(['/programacion/evaluacion-programas-informe-sel']);
  }

  eventoBtnGuardar(){
    this.guardarEvaluacionProgramacion();
  }

  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  async obtenerDatosProgramacion(numeroProgramacion: string){

    let result = await this.gestionProgramaOtrosService.obtenerRegistrarPrograma(toNumber(numeroProgramacion)).toPromise();

    if (result.exito) {

      let programacion: Programacion = new Programacion();

      programacion = result.data;

      console.log(programacion); //Temporal eliminar
      
      this.numProgramacion.setValue(trim(programacion.numProgramacion));
      this.programaControl.setValue(trim(programacion.desProgramaControl));
      this.alcanse.setValue(trim(programacion.desAlcance));
      this.fechaProgramacion.setValue(trim(programacion.fecProgramacion));
      this.programador.setValue(trim(programacion.desProgramador));
      this.plazoAtencion.setValue(trim(programacion.numPlazoVerificacion));
      this.desProgramaControl.setValue(trim(programacion.desProgramacion));
      this.cierreAutomatico.setValue(trim(programacion.indCierre));
      this.observacion.setValue(trim(programacion.obsProgramacion));
      this.numInforme.setValue(trim(programacion.numInforme));

      this.tieneInformeSeleccion = trim(programacion.numInforme) != Constantes.VALOR_VACIO ? true : false;

      if(programacion.archivoBean != null){
        this.archivoInformeSelFisico.setValue(trim(programacion.archivoBean.nomArchivo));
        this.archivoBeanInformeSelFisico = programacion.archivoBean;
      }else{
        this.archivoInformeSelFisico.setValue('');
        this.archivoBeanInformeSelFisico = new ArchivoBean();
      }
      
      // this.rdbDefaultEvaProgDef.setValue(trim(programacion.codEstadoPrograma));
      this.sustentoDevolucion.setValue(trim(programacion.desSusCancela));

      this.listarUsuariosProgramacion();

    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de programacion => ${result.mensaje}`);
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
    }
  }

  obtenerEvaluarPrograma(numeroProgramacion: string){

    let programacion: Programacion = new Programacion();
    programacion.numProgramacion = toNumber(numeroProgramacion);

    this.evaluacionProgramaService.obtenerEvaluarPrograma(programacion).subscribe(
      result => {
        if (result.exito) {

          console.log(result.data); //Temporal eliminar

        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de evaluacion programa => ${result.mensaje}`);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  listarUsuariosProgramacion(){
    this.usuarios = [];

    let usuarioProgramacion: UsuarioProgramacion = new UsuarioProgramacion();
    usuarioProgramacion.numProgramacion = toNumber(this.numeroProgramacion);

    this.gestionProgramaAsignadoService.listarUsuario(usuarioProgramacion).subscribe(
      result => {
        if (result.exito) {
          this.usuarios = result.data;
        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios programacion => ${result.mensaje}`);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  guardarEvaluacionProgramacion(){
    
    if(this.formaProgInformeDefinido.valid){

      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE,Constantes.MODAL_PRIMARY, () => {

        let programacion: Programacion = new Programacion();
        programacion.numProgramacion = toNumber(this.numeroProgramacion);
        programacion.codEstadoPrograma = trim(this.rdbDefaultEvaProgDef.value);
        programacion.desSusCancela = trim(this.sustentoDevolucion.value);
        programacion.numInforme = trim(this.numInforme.value);
        
        this.evaluacionProgramaService.guardarEvaluacionPrograma(programacion).subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
            } else {
              if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS}`, Constantes.MODAL_DANGER);
              }else{
                this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
              }
            }
          },
          error => {
            console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS, Constantes.MODAL_DANGER);
          }
        );
        
      });
    } else {
      this.formaProgInformeDefinido.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }
  //Fin metodos Web Service

}