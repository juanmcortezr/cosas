import { Component, OnInit, ViewChild } from '@angular/core';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { Router } from '@angular/router';
import { Programacion } from 'src/app/models/programacion.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { Constantes } from 'src/app/utils/constantes';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { GestionProgramaDefinidoService } from 'src/app/services/gestion-programa-definido.service';
import { trim, isEmpty, stringToMoment, padNumber, dateToString, isNotEmpty, formatDatePeriodoFront, formatDatePeriodoBack, toNumber,stringToMomentDDMMYYYY, dateToStringDDMMYYYY } from 'src/app/utils/utilitarios';
import { ProgramaControl } from 'src/app/models/programaControl.model';
import { FormGroup, Validators, FormControl,  AbstractControl  } from '@angular/forms';
import { CheckElement } from 'src/app/models/checkElement.model';
import { NgbModalRef, NgbActiveModal, NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { MantenimientoProgramaService } from 'src/app/services/mantenimiento-programa.service';

@Component({
  selector: 'app-gestion-programas-definidos',
  templateUrl: './gestion-programas-definidos.component.html',
  styleUrls: ['./gestion-programas-definidos.component.css']
})
export class GestionProgramasDefinidosComponent implements OnInit {

  tipoLBL: string; //Indicar que es una etiqueta label
  catalogoEstadoProg: string;
  catalogoEstadoInforme: string;
  permitidosEstadoProg: string[] = [];
  filtro: Programacion = new Programacion();
  listaPrograma: Programacion[];
  listaControl: ProgramaControl[];
  programaControl: ProgramaControl;
  nuevaPrograma: Programacion = new Programacion();
  formNuevaPrograma: FormGroup;
  modalRef: NgbModalRef;//1 para modal
  formatoFechaPeriodo: string; //Formatos de fechas para periodos (Inicio/Fin)
  formatoFechaPerCompleto: string; //Formatos de fechas para periodos (Inicio/Fin)
  esGreNoconfirmada:boolean;//Sirve para habilitar Periodos

  @ViewChild('mdlRegistrarProgDefinido', {static: true}) mdlRegistrarProgDefinido: NgbActiveModal;//2 para modal

  constructor(private router: Router,
              private utilService: UtilService,
              private gestionProgramaDefinido: GestionProgramaDefinidoService,
              private mantenimientoProgramaService: MantenimientoProgramaService,
              private modalService: NgbModal,//3 para modal
              private configModal: NgbModalConfig) { 
                configModal.backdrop = 'static';
                configModal.keyboard = false;
              }//4 para modal

  ngOnInit() {
    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;
    this.catalogoEstadoProg = ConstantesCatalogo.COD_CATALOGO_ESTADOS_PROGRAMAS;
    this.catalogoEstadoInforme = ConstantesCatalogo.COD_CATALOGO_ESTADO_INFORMESELECCION;
    this.permitidosEstadoProg = Constantes.ESTADOS_PROGRAM_DEFINIDO;
    this.cargarFormularioNuevaPrograma();
    this.llenarCombos();
    this.nuevoFiltro();  
    
    this.eventocodProgramaControl();
  }
  //---------------METODOS  COMPARTIDOS------------------------------
  llenarCombos(){
    this.mantenimientoProgramaService.listarProgramaControl(new ProgramaControl()).subscribe(
      result => {
        if (result.exito) {
          this.listaControl = (result.data as ProgramaControl[]).map(y => Programacion.fromJSON(y));
        } else {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS22_MENSAJE_F2_02, Constantes.MODAL_DANGER);
        }
      },
      error => {
        console.log('Hubo errores la llenar combo', error);
      }
    );
  }
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }
  
  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }

// -------------------------------------------------------------------------------------------------------//
// ------------------------------------------METODOS USADOS EN BUSCADOR--------------------------------//
// -------------------------------------------------------------------------------------------------------//


// Limpiar valores de textos del Buscador
  nuevoFiltro() {
    this.filtro = new Programacion();
    this.listaPrograma = [];
  }
// Limpiar BUSCADOR  
  limpiarcampos (){
    this.filtro = new Programacion();
    this.listaPrograma = [];
  }
  
// Realizar Busqueda
  buscar() {
    this.listaPrograma = [];
    if (!this.filtro.filtroValidoIU061()) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS22_EXCP_004, Constantes.MODAL_DANGER);
      return false;
    }
    let valido = this.validarFechaHasta();
    if (valido) {
      valido = this.validarFechaDesde();
    }
    if (!valido) {
      return false;
    }
    this.gestionProgramaDefinido.listarProgramaDefinido(this.filtro).subscribe(
      result => {
        if (result.exito) {
          this.listaPrograma = (result.data as Programacion[]).map(y => Programacion.fromJSON(y));
        } else {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS22_MENSAJE_F2_01, Constantes.MODAL_DANGER);
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );

  }
// Limpiar Buscador  Fecha desde
validarFechaDesde() {
  const momentDesde = stringToMomentDDMMYYYY(this.filtro.fechaDesde);
  const momentHasta = stringToMomentDDMMYYYY(this.filtro.fechaHasta);
  let valido = true;
  if (momentDesde.isAfter(momentHasta)) {
    this.utilService.alertaMensaje(MensajesExcepciones.CUS22_EXCP_002, Constantes.MODAL_DANGER);
    valido = false;
  }
  return valido;
}
// Limpiar Buscador  Fecha Hasta
  validarFechaHasta() {
    const momentDesde = stringToMomentDDMMYYYY(this.filtro.fechaDesde);
    const momentHasta = stringToMomentDDMMYYYY(this.filtro.fechaHasta);
    const momentToday = stringToMomentDDMMYYYY(dateToStringDDMMYYYY(new Date()));
    let valido = true;
    if (momentHasta.isBefore(momentDesde)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS22_EXCP_001, Constantes.MODAL_DANGER);
      valido = false;
    } else if (momentHasta.isAfter(momentToday)) {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS22_EXCP_003, Constantes.MODAL_DANGER);
      valido = false;
    }
    return valido;
  }

//ABRIR MODAL
eventoBtnNuevaProgramacion(){
  this.modalRef = this.modalService.open(this.mdlRegistrarProgDefinido, { size: 'lg' });    
}

// -------------------------------------------------------------------------------------------------------//
// ------------------------------------------FORMULARIO NUEVA PROGRAMACION--------------------------------//
// -------------------------------------------------------------------------------------------------------//
  cargarFormularioNuevaPrograma(){
    this.formatoFechaPeriodo = Constantes.FORMAT_FECHA_YYYYMM;
    this.formatoFechaPerCompleto = `DD${this.formatoFechaPeriodo}`;    
    this.nuevaProgramacion();
    
    this.formNuevaPrograma = new FormGroup({
      "codProgramaControl": new FormControl("", Validators.required),
      "indCierre": new FormControl('', Validators.required),
      "plazoVerificacion": new FormControl('', Validators.required),  
      "desAlcance": new FormControl('', Validators.required),        
      "desProgramacion": new FormControl('', Validators.required),       
      "periodoInicio": new FormControl(''),       
      "periodoFin": new FormControl('')
    });    
  }

  get codProgramaControl() { return this.formNuevaPrograma.get('codProgramaControl') as FormControl; }
  get periodoInicio() { return this.formNuevaPrograma.get('periodoInicio') as FormControl; }
  get periodoFin() { return this.formNuevaPrograma.get('periodoFin') as FormControl; }
  get desProgramacion() { return this.formNuevaPrograma.get('desProgramacion') as FormControl; }
  get desAlcance() { return this.formNuevaPrograma.get('desAlcance') as FormControl; }

  eventocodProgramaControl() {
    this.esGreNoconfirmada = false;
    this.codProgramaControl.valueChanges.subscribe(valor => {
      valor = trim(valor);
      if (Constantes.LISTA_PROG_CONTROL_GRE.indexOf(valor) >= 0) {
        this.esGreNoconfirmada = true;
        this.periodoInicio.setValidators([Validators.required, this.validacionPeriodoIni]);
        this.periodoFin.setValidators([Validators.required, this.validacionPeriodoFin]);
      } else {
        this.esGreNoconfirmada = false;
        this.periodoInicio.setValidators(null);
        this.periodoFin.setValidators(null);
      }
      this.periodoInicio.setValue('');
      this.periodoFin.setValue('');
      this.periodoInicio.updateValueAndValidity();
      this.periodoFin.updateValueAndValidity();
    });
  }

// Limpiar valores de textos del Modal
  nuevaProgramacion() {
    this.nuevaPrograma = new Programacion();  
  }
// Limpiar Modal
  limpiarNuevaProgramacion (){ 
    this.modalRef.close(); //Cerrar modal.dismiss()  
    this.nuevaProgramacion(); 
    this.formNuevaPrograma.markAsUntouched(); 
  }
// Guardar Modal
  guardarNuevaProgramacion() {
    if (this.formNuevaPrograma.valid) { 
      //MODAL SI --NO
      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE, Constantes.MODAL_PRIMARY, () => {
        let programacion = new Programacion();
        programacion.desAlcance = this.desAlcance.value;
        programacion.desProgramacion = this.desProgramacion.value;
        programacion.perFin = formatDatePeriodoBack(this.periodoFin.value);
        programacion.perInicio = formatDatePeriodoBack(this.periodoInicio.value);
        programacion.codProgramaControl = this.codProgramaControl.value;
        programacion.numProgramacion = 0;
        this.gestionProgramaDefinido.guardarPrograma(programacion).subscribe(rpta => {
          if (rpta.exito) {
            this.limpiarNuevaProgramacion();
          }
        });
      });
      
    }else{
      this.formNuevaPrograma.markAllAsTouched();
    }
  }
// CAMBIO COMBO DE COD PROGRAMA 
  cambiarDatosxCombo(){
    if(this.nuevaPrograma.codProgramaControl!=""){
      this.gestionProgramaDefinido.obtenerProgramaControl(this.nuevaPrograma.codProgramaControl).subscribe(
        result => {
          if (result.exito) {
            this.nuevaPrograma.indCierre=result.data.indCierre;
            this.nuevaPrograma.plazoVerificacion=result.data.numPlazo;
            this.nuevaPrograma.desAlcance=result.data.desAlcance;
            this.nuevaPrograma.desProgramacion=result.data.desResumen; 
          } else {
            this.utilService.alertaMensaje(MensajesExcepciones.CUS22_MENSAJE_F2_01, Constantes.MODAL_DANGER);
          }
        },
        error => {
          console.log('Hubo errores ', error);
        }
      );

    }else{
      this.nuevaProgramacion();
    }
  }


//Validacion personalizada Periodo Inicio
      validacionPeriodoIni(control: AbstractControl): { [s: string]: boolean } | null {
        let formatoFechaPeriodo: string = Constantes.FORMAT_FECHA_YYYYMM;
        let formatoFechaPerCompleto: string = `DD${formatoFechaPeriodo}`;
        // control.parent es el FormGroup
        if (control.parent) { // En las primeras llamadas control.parent es undefined
          if (control.value) { // En las primeras llamadas control.value es undefined
            if(isNotEmpty(control.value) && isNotEmpty(control.parent.controls['periodoFin'].value)){
              const periodoInicio = `${control.value.year}${padNumber(control.value.month)}`;
              const periodoFin = `${control.parent.controls['periodoFin'].value.year}${padNumber(control.parent.controls['periodoFin'].value.month)}`;
              const momentDesde = stringToMoment(`01${periodoInicio}`, formatoFechaPerCompleto);
              const momentHasta = stringToMoment(`01${periodoFin}`, formatoFechaPerCompleto);
              if (momentDesde.isAfter(momentHasta)) {
                return { periodoiniafter: true };
              }
            }
          }
        }
        return null;
      }
//Validacion personalizada Periodo Fin
    validacionPeriodoFin(control: AbstractControl): { [s: string]: boolean } | null {
      let formatoFechaPeriodo: string = Constantes.FORMAT_FECHA_YYYYMM;
      let formatoFechaPerCompleto: string = `DD${formatoFechaPeriodo}`;
      // control.parent es el FormGroup
      if (control.parent) { // En las primeras llamadas control.parent es undefined
        if (control.value) { // En las primeras llamadas control.value es undefined
          if(isNotEmpty(control.value) && isNotEmpty(control.parent.controls['periodoInicio'].value)){
            const periodoInicio = `${control.parent.controls['periodoInicio'].value.year}${padNumber(control.parent.controls['periodoInicio'].value.month)}`;
            const periodoFin = `${control.value.year}${padNumber(control.value.month)}`;
            const momentDesde = stringToMoment(`01${periodoInicio}`, formatoFechaPerCompleto);
            const momentHasta = stringToMoment(`01${periodoFin}`, formatoFechaPerCompleto);
            const momentToday = stringToMoment(dateToString(new Date(), formatoFechaPerCompleto), formatoFechaPerCompleto);
            if (momentHasta.isBefore(momentDesde)) {
              return { periodofinbefore: true };
            } else if (momentHasta.isAfter(momentToday)) {
              return { periodofinafter: true };
            }
          }
        }
      }
      return null;
    } 


}
