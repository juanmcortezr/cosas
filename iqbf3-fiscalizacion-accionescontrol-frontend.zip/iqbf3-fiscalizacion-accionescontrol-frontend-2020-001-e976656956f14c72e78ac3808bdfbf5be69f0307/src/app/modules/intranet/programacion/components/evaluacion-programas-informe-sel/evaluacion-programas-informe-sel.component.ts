import { Component, OnInit, ɵConsole } from '@angular/core';
import { Router } from '@angular/router';
import { UtilService } from 'src/app/services/shared/util.service';
import { ProgramaControl } from 'src/app/models/programaControl.model';
import { Programacion } from 'src/app/models/programacion.model';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { Constantes } from 'src/app/utils/constantes';
import { trim, isNotEmpty, toNumber } from 'src/app/utils/utilitarios';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { EvaluacionProgramaService } from 'src/app/services/evaluacion-programa.service';
import { MantenimientoProgramaService } from 'src/app/services/mantenimiento-programa.service';

@Component({
  selector: 'app-evaluacion-programas-informe-sel',
  templateUrl: './evaluacion-programas-informe-sel.component.html',
  styleUrls: ['./evaluacion-programas-informe-sel.component.css']
})
export class EvaluacionProgramasInformeSelComponent implements OnInit {

  //Inicio declaracion
  catalogoTipoEstadoProgramacion: string; //Codigo de catalogo estado programa
  catalogoTipoEstadoInformeSeleccion: string; //Codigo de catalogo estado informe seleccion
  programacion: Programacion = new Programacion(); //Declarar e inicializar objeto progrma control
  programaciones: Programacion[] = []; //Almacena lista programas de control
  tiposProgramasControl: ProgramaControl[] = []; //Almacena lista tipos progrmas de control
  tiposEstadosInformeSeleccion: ProgramaControl[] = []; //Almacena lista tipos estados informe seleccion
  soloNumero: string = Constantes.TIPO_VALI_ONLYNUMBER; //Validar que solo se ingrese numeros
  filtro: any = {}; //Objeto filtro (Mapear datos ngModel)
  //Fin declaracion

  constructor(private router: Router,
    private evaluacionProgramaService: EvaluacionProgramaService,
    private mantenimientoProgramaService: MantenimientoProgramaService,
    private utilService: UtilService) { }

  ngOnInit() {
    this.inicio();
    this.limpiarCampos();
  }

  //Inicio metodos componente
  inicio() {
    this.catalogoTipoEstadoProgramacion = ConstantesCatalogo.COD_CATALOGO_ESTADOS_PROGRAMAS;
    this.catalogoTipoEstadoInformeSeleccion = ConstantesCatalogo.COD_CATALOGO_ESTADO_INFORMESELECCION;

    this.listarTipoProgramaControl();
  }

  limpiarCampos() {

    this.filtro = {
      numProgrmacion: Constantes.VALOR_VACIO,
      codProgrmaControl: Constantes.VALOR_VACIO,
      codEstadoProgramacion: Constantes.VALOR_VACIO,
      numInforme: Constantes.VALOR_VACIO,
      codEstadoInformSeleccion: Constantes.VALOR_VACIO,
      programadorAsignado: Constantes.VALOR_VACIO
    };

    this.programaciones = [];
  }

  eventoBtnBuscar(){
    this.listarProgramaDefinido();
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  listarTipoProgramaControl(){
    this.tiposProgramasControl = [];

    let programaControl: ProgramaControl = new ProgramaControl();

    this.mantenimientoProgramaService.listarProgramaControl(programaControl).subscribe(
      result => {
        if (result.exito) {
          this.tiposProgramasControl = result.data;
        } else {
          console.log(result.mensaje);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  listarProgramaDefinido() {
    this.programaciones = [];

    this.programacion.numProgramacion = toNumber(this.filtro.numProgrmacion);
    this.programacion.codProgramaControl = trim(this.filtro.codProgrmaControl);
    this.programacion.codEstadoPrograma = trim(this.filtro.codEstadoProgramacion);
    this.programacion.numInforme = trim(this.filtro.numInforme);
    this.programacion.codEstadoInforme = trim(this.filtro.codEstadoInformSeleccion);
    this.programacion.desProgramador = trim(this.filtro.programadorAsignado);

    if (this.programacion.filtroValidoIU025()) {

      this.evaluacionProgramaService.listarPrograma(this.programacion).subscribe(
        result => {
          if (result.exito) {
            this.programaciones = result.data;
          } else {
            console.log(result.mensaje);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_SIN_RESULTADO, Constantes.MODAL_PRIMARY);
          }
        },
        error => {
          console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
        }
      );
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS10_EXCP_001, Constantes.MODAL_DANGER);
    }
  }
  //Fin metodos Web Service
}