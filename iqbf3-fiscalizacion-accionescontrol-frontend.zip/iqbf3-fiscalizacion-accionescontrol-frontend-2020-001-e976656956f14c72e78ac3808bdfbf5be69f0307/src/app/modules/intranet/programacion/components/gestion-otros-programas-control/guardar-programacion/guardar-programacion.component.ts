import { Component, OnInit, Directive } from '@angular/core';
import { Programacion } from 'src/app/models/programacion.model';
import { Catalogo } from 'src/app/models/catalogo.model';
import { CatalogoService } from 'src/app/services/maestros/catalogo.service';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { CheckElement } from 'src/app/models/checkElement.model';
import { GestionSolicitudService } from 'src/app/services/gestion-solicitud.service';
import { GestionProgramaOtrosService } from 'src/app/services/gestion-programa-otros.service';
import { UtilService } from 'src/app/services/shared/util.service';
import { trim, isEmpty, stringToMoment, padNumber, dateToString, isNotEmpty, formatDatePeriodoFront, toNumber } from 'src/app/utils/utilitarios';
import { Constantes } from 'src/app/utils/constantes';
import { FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';
import { BienFiscalizadoSolicitud } from 'src/app/models/bienFiscalizadoSolicitud.model';
import { Actividades } from 'src/app/models/actividades.model';
import { Persona } from 'src/app/models/persona.model';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { ActivatedRoute } from '@angular/router';
import { zip, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Response } from 'src/app/models/response.model';

@Component({
  selector: 'app-guardar-programacion',
  templateUrl: './guardar-programacion.component.html',
  styleUrls: ['./guardar-programacion.component.css']
})
@Directive({
  selector: 'label[controlName]',
})
export class GuardarProgramacionComponent implements OnInit {

  constructor(private catalogoService: CatalogoService,
              private gestionSolicitudService: GestionSolicitudService,
              private utilService: UtilService,
              private rutaActiva: ActivatedRoute,
              private gestionProgramaOtrosService: GestionProgramaOtrosService) {
  }

  // Catalogo
  catalogoTipoBien: string;
  catalogoFuentesProg: string;
  catalogoTipoIncosistencias: string;
  otraIncosistencia: boolean;
  otroTipoBien: boolean;
  otraFuente: boolean;
  esProgBien: boolean;
  esInsumo: boolean;
  esCombustible: boolean;
  habilitarEnvio: boolean;
  tipoProgBien: string;
  tipoProgServ: string;
  formatoFechaPeriodo: string;
  formatoFechaPerCompleto: string;

  formulario: Programacion = new Programacion();
  editar: Programacion;
  catalogoTipoBienes: Catalogo[] = [];
  perInicioDate: any;
  perFinDate: any;
  formRegProgramacion: FormGroup;
  listaPersonas: Persona[] = [];
  incosistenciaTouched: boolean;
  tipoBienTouched: boolean;
  bienTouched: boolean;
  actividadTouched: boolean;
  numProgramacion: string;

  ngOnInit() {
    this.formRegProgramacion = new FormGroup({
      "desAlcance": new FormControl("", Validators.required),
      "desProgramacion": new FormControl("", Validators.required),
      "perInicio": new FormControl("", [Validators.required, this.validacionPeriodoIni]),
      "perFin": new FormControl("", [Validators.required, this.validacionPeriodoFin]),
      "codFuente": new FormControl("", Validators.required),
      "codProgramador": new FormControl("", Validators.required),
      "obsProgramacion":  new FormControl("", Validators.required),
      "desOtroBien": new FormControl("", Validators.maxLength(200)),
      "desOtroIncosistencia": new FormControl("", Validators.maxLength(200)),
      "desOtraFuente": new FormControl("", Validators.maxLength(200)),
      "codTipoProgram": new FormControl("", Validators.required)
    });
    this.incosistenciaTouched = false;
    this.tipoBienTouched = false;
    this.bienTouched = false;
    this.actividadTouched = false;
    this.otraIncosistencia = false;
    this.otroTipoBien = false;
    this.otraFuente = false;
    this.habilitarEnvio = false;
    this.catalogoTipoIncosistencias = ConstantesCatalogo.COD_CATALOGO_TIPO_INCONSISTENCIAS;
    this.catalogoTipoBien = ConstantesCatalogo.COD_CATALOGO_TIPO_BIEN;
    this.catalogoFuentesProg = ConstantesCatalogo.COD_CATALOGO_FUENTES_PROGRAMAS;
    this.tipoProgBien = Constantes.COD_TIP_PROG_BIEN;
    this.tipoProgServ = Constantes.COD_TIP_PROG_SERVICIO;
    this.formulario.codTipoProgram = this.tipoProgBien;
    this.esProgBien = true;
    this.formatoFechaPeriodo = Constantes.FORMAT_FECHA_YYYYMM;
    this.formatoFechaPerCompleto = `DD${this.formatoFechaPeriodo}`;

    this.numProgramacion = trim(this.rutaActiva.snapshot.params.numProgramacion) || "-1";

    zip(
      this.catalogoService.obtenerCatalogo(this.catalogoTipoIncosistencias),
      this.catalogoService.obtenerCatalogo(this.catalogoTipoBien),
      this.gestionProgramaOtrosService.listarActividadFiscalizada(),
      this.gestionProgramaOtrosService.listarProgramador(),
      this.gestionProgramaOtrosService.obtenerRegistrarPrograma(toNumber(this.numProgramacion))
    )
    .pipe(
      map(([incosistencias, tipoBienes, actividades, programadores, programa]) => {
        return ({incosistencias, tipoBienes, actividades, programadores, programa });
      }),
      catchError(error => throwError(error))
      ).subscribe(data => {
        if (data) {
          this.cargarDatosPrincipales(data.programa);
          this.listarCatalogoInconsistencias(data.incosistencias);
          this.listarCatalogoTipoBienes(data.tipoBienes);
          this.listarActividadesFiscalizadas(data.actividades);
          this.listarProgramadores(data.programadores);
          this.cargarDatos(data.programa);
        }
      });

  }

  cargarDatosPrincipales(response: Response) {
    if (response.exito) {
      this.formulario = Programacion.fromJSON(response.data);
      this.perInicioDate = formatDatePeriodoFront(this.formulario.perInicio);
      this.perFinDate = formatDatePeriodoFront(this.formulario.perFin);
      this.formulario.bienesFiscalizados = [];
    }
  }

  cargarDatos(response: Response) {
    if (response.exito) {
      this.editar = response.data;
      this.habilitarEnvio = true;
      this.esProgBien = (this.editar.codTipoProgram == this.tipoProgBien);
      this.otraFuente = isNotEmpty(this.editar.desOtraFuente);
      this.otraIncosistencia = isNotEmpty(this.editar.desOtroBien);
      this.otroTipoBien = isNotEmpty(this.editar.desOtroBien);
      // inconsistencias
      this.formulario.inconsistencias.forEach(i => {
        let exist = this.editar.inconsistencias.find(ri => trim(ri.codigo) == trim(i.codigo));
        if (isNotEmpty(exist)) {
          i.seleccionado = true;
        }
      });
      if (this.esProgBien) {
        // tipoBienes
        this.formulario.tipoBienes.forEach(i => {
          let exist = this.editar.tipoBienes.find(ri => trim(ri.codigo) == trim(i.codigo));
          if (isNotEmpty(exist)) {
            i.seleccionado = true;
          }
        });
        this.formulario.bienesFiscalizados = this.editar.bienesFiscalizados;
        this.eventoTipoBien();
        this.formulario.desOtroBien = this.editar.desOtroBien;
      } else {
        // actividades
        this.formulario.actividades.forEach(i => {
          let exist = this.editar.actividades.find(ri => trim(ri.codigo) == trim(i.codigo));
          if (isNotEmpty(exist)) {
            i.seleccionado = true;
          }
        });
      }
    };
  }

  listarCatalogoInconsistencias(result: Response) {
    this.formulario.inconsistencias = [];
    if (result.exito) {
      this.formulario.inconsistencias = (result.data as Catalogo[]).map(x => new CheckElement(x.codDataCatalogo, x.descripcionDataCatalogo, false));
    }
  }

  listarCatalogoTipoBienes(result: Response) {
    this.formulario.tipoBienes = [];
    if (result.exito) {
      this.formulario.tipoBienes = (result.data as Catalogo[]).map(x => new CheckElement(x.codDataCatalogo, x.descripcionDataCatalogo, false));
      this.formulario.tipoBienes.push(new CheckElement(Constantes.OPCION_CODIGO_OTROS, Constantes.OPCION_NOMBRE_OTROS, false));
    }
  }

  listarActividadesFiscalizadas(result: Response) {
    this.formulario.actividades = [];
    if (result.exito) {
      this.formulario.actividades = (result.data as Actividades[]).map(x => new CheckElement(x.codActividad, x.nomActividad, false));
    }
  }

  listarProgramadores(result: Response) {
    this.listaPersonas = [];
    if (result.exito) {
      this.listaPersonas = result.data;
    }
  }

  eventoInconsistencia() {
    this.incosistenciaTouched = true;
    this.otraIncosistencia = false;
    this.desOtroIncosistencia.setValidators(null);
    this.formulario.inconsistencias.forEach(d => {
      if (d.codigo === Constantes.OPCION_CODIGO_OTROS && d.seleccionado) {
        this.otraIncosistencia = true;
        this.desOtroIncosistencia.setValidators([Validators.required]);
        return;
      }
    });
    this.desOtroIncosistencia.setValue('');
    this.desOtroIncosistencia.updateValueAndValidity();
  }

  eventoFuente() {
    this.otraFuente = false;
    this.desOtraFuente.setValidators(null);
    if (this.formulario.codFuente === Constantes.OPCION_CODIGO_OTROS) {
      this.otraFuente = true;
      this.desOtraFuente.setValidators([Validators.required]);
    }
    this.desOtraFuente.setValue('');
    this.desOtraFuente.updateValueAndValidity();
  }

  eventoTipoBien() {
    this.tipoBienTouched = true;
    this.otroTipoBien = false;
    this.esInsumo = false;
    this.esCombustible = false;
    //this.formulario.bienesFiscalizados = [];
    this.desOtroBien.setValidators(null);
    this.formulario.tipoBienes.forEach(d => {
      if (Constantes.OPCION_TIPO_BIEN_INSUMO == trim(d.codigo) && d.seleccionado) {
        this.esInsumo = true;
      }
      if (Constantes.OPCION_TIPO_BIEN_COMBUSTIBLE == trim(d.codigo) && d.seleccionado) {
        this.esCombustible = true;
      }
      if (Constantes.OPCION_LISTA_OTROS.indexOf(trim(d.codigo)) >= 0 && d.seleccionado) {
        this.otroTipoBien = true;
        this.desOtroBien.setValidators([Validators.required]);
      }
      if (d.seleccionado) {
        this.gestionSolicitudService.listarBienesFiscalizados(d.codigo).subscribe(
          result => {
            if (result.exito) {
              let datos = (result.data as BienFiscalizadoSolicitud[]).map(x => {
                let element = new CheckElement(x.codBienFiscalizado, x.desBienFisca, false);
                let exist = this.formulario.bienesFiscalizados.find(ri => trim(ri.codigo) == trim(element.codigo));
                element.tipo = d.codigo;
                if (isNotEmpty(exist)) {
                  element.seleccionado = true;
                }
                return element;
              });
              datos.forEach(e => {
                let exist = this.formulario.bienesFiscalizados.find(ri => trim(ri.codigo) == trim(e.codigo));
                if (isEmpty(exist)) {
                  this.formulario.bienesFiscalizados.push(e);
                }
              });
              this.formulario.bienesFiscalizados.sort((a, b) => a.codigo.localeCompare(b.codigo));
            }
          },
          error => {
            console.log("Hubo errores ", error);
          }
        );
        }
      });
      this.desOtroBien.setValue('');
      this.desOtroBien.updateValueAndValidity();
  }

  eventoTipPrograma() {
    this.esProgBien = (this.formulario.codTipoProgram == this.tipoProgBien);
    if (this.formulario.codTipoProgram == this.tipoProgBien) {
      this.formulario.tipoBienes.forEach(bien => bien.seleccionado = false);
      this.eventoTipoBien();
      this.tipoBienTouched = false;
      this.bienTouched = false;
      this.formulario.bienesFiscalizados = [];
      this.formulario.desOtroBien = "";
    } else if  (this.formulario.codTipoProgram == this.tipoProgServ) {
      this.formulario.actividades.forEach(bien => bien.seleccionado = false);
    }
  }

  
  //Validacion personalizada
  validacionPeriodoIni(control: AbstractControl): { [s: string]: boolean } | null {
    let formatoFechaPeriodo: string = Constantes.FORMAT_FECHA_YYYYMM;
    let formatoFechaPerCompleto: string = `DD${formatoFechaPeriodo}`;
    // control.parent es el FormGroup
    if (control.parent) { // En las primeras llamadas control.parent es undefined
      if (control.value) { // En las primeras llamadas control.value es undefined
        if(isNotEmpty(control.value) && isNotEmpty(control.parent.controls['perFin'].value)){
          const periodoInicio = `${control.value.year}${padNumber(control.value.month)}`;
          const periodoFin = `${control.parent.controls['perFin'].value.year}${padNumber(control.parent.controls['perFin'].value.month)}`;
          const momentDesde = stringToMoment(`01${periodoInicio}`, formatoFechaPerCompleto);
          const momentHasta = stringToMoment(`01${periodoFin}`, formatoFechaPerCompleto);
          if (momentDesde.isAfter(momentHasta)) {
            return { periodoiniafter: true };
          }
        }
      }
    }
    return null;
  }

  validacionPeriodoFin(control: AbstractControl): { [s: string]: boolean } | null {
    let formatoFechaPeriodo: string = Constantes.FORMAT_FECHA_YYYYMM;
    let formatoFechaPerCompleto: string = `DD${formatoFechaPeriodo}`;
    // control.parent es el FormGroup
    if (control.parent) { // En las primeras llamadas control.parent es undefined
      if (control.value) { // En las primeras llamadas control.value es undefined
        if(isNotEmpty(control.value) && isNotEmpty(control.parent.controls['perInicio'].value)){
          const periodoInicio = `${control.parent.controls['perInicio'].value.year}${padNumber(control.parent.controls['perInicio'].value.month)}`;
          const periodoFin = `${control.value.year}${padNumber(control.value.month)}`;
          const momentDesde = stringToMoment(`01${periodoInicio}`, formatoFechaPerCompleto);
          const momentHasta = stringToMoment(`01${periodoFin}`, formatoFechaPerCompleto);
          const momentToday = stringToMoment(dateToString(new Date(), formatoFechaPerCompleto), formatoFechaPerCompleto);
          if (momentHasta.isBefore(momentDesde)) {
            return { periodofinbefore: true };
          } else if (momentHasta.isAfter(momentToday)) {
            return { periodofinafter: true };
          }
        }
      }
    }
    return null;
  }

  eventoGuardar() {
    this.incosistenciaTouched = true;
    this.tipoBienTouched = false;
    this.bienTouched = false;
    if (this.esProgBien) { // Bien
      this.tipoBienTouched = true;
      this.bienTouched = true;
    }

    if (this.formRegProgramacion.valid) {
      let inconsistencias = this.formulario.inconsistencias.filter(check => check.seleccionado);
      let tipoBienes = this.formulario.tipoBienes.filter(check => check.seleccionado);
      let actividades = this.formulario.actividades.filter(check => check.seleccionado);
      let bienesFiscalizados = this.formulario.bienesFiscalizados.filter(check => check.seleccionado);
      if (inconsistencias.length <= 0) {
        this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
        return false;
      }
      if (this.esProgBien) { // Bien
        this.tipoBienTouched = true;
        this.bienTouched = true;
        if(tipoBienes.length <= 0) {
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
          return false;
        }
        /*if(bienesFiscalizados.length <= 0) {
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
          return false;
        }*/
      } else { // Servicio
        if(actividades.length <= 0) {
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
          return false;
        }
      }
      if (this.esInsumo && (bienesFiscalizados.filter(b => b.tipo == Constantes.OPCION_TIPO_BIEN_INSUMO).length <=0)) {
        this.utilService.alertaMensaje(MensajesExcepciones.CUS06_EXCP_010, Constantes.MODAL_DANGER);
        return false;
      }
      if (this.esCombustible && (bienesFiscalizados.filter(b => b.tipo == Constantes.OPCION_TIPO_BIEN_COMBUSTIBLE).length <=0)) {
        this.utilService.alertaMensaje(MensajesExcepciones.CUS06_EXCP_011, Constantes.MODAL_DANGER);
        return false;
      }

      this.utilService.modalConfirmacion('Confirmaci\u00f3n', '¿Est\u00e1 seguro que desea guardar?', Constantes.MODAL_PRIMARY, () => {
        // Agregar periodos:
        let envio = Programacion.fromJSON(this.formulario);
        envio.perInicio = this.periodoInicio;
        envio.perFin = this.periodoFin;
        envio.codEstadoPrograma = Constantes.COD_EST_PROGRAM_PLANIFICADO;
        envio.inconsistencias = inconsistencias;
        envio.tipoBienes = tipoBienes;
        envio.actividades = actividades;
        envio.bienesFiscalizados = bienesFiscalizados;
        this.gestionProgramaOtrosService.guardarPrograma(envio).subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje(result.mensaje, Constantes.MODAL_SUCCESS);
              this.habilitarEnvio = true;
              this.formulario.numProgramacion = (result.data as Programacion).numProgramacion;
            } else {
              this.utilService.alertaMensaje('Datos no guardados', Constantes.MODAL_DANGER);
            }
          },
          error => {
            this.utilService.alertaMensaje('Datos no guardados', Constantes.MODAL_DANGER);
          }
        );
      });
    } else {
      this.formRegProgramacion.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }

  eventoEnviar() {
    this.incosistenciaTouched = true;
    this.tipoBienTouched = false;
    this.bienTouched = false;
    if (this.esProgBien) { // Bien
      this.tipoBienTouched = true;
      this.bienTouched = true;
    }

    if (this.formRegProgramacion.valid) {
      this.utilService.modalConfirmacion('Confirmaci\u00f3n', '¿Est\u00e1 seguro que desea enviar la programaci\u00f3n al programador?', Constantes.MODAL_PRIMARY, () => {
        // Agregar periodos:
        let envio = Programacion.fromJSON(this.formulario);
        this.gestionProgramaOtrosService.enviarPrograma(envio).subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje('Se guard\u00f3 con \u00e9xito', Constantes.MODAL_SUCCESS);
            } else {
              this.utilService.alertaMensaje('Error al enviar', Constantes.MODAL_DANGER);
            }
          },
          error => {
            this.utilService.alertaMensaje('Error al enviar', Constantes.MODAL_DANGER);
          }
        );
      });
    }
  }

  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }

  getErrorLabel(groupName: FormGroup, controlName: string) {
    return this.getErrorClass(groupName, controlName, Constantes.ERROR_CLASS_FORM_CONTROL_LBL);
  }
  getErrorClassCkb(arrayList: CheckElement[], estadoTouched: boolean) {
    arrayList = arrayList.filter(check => check.seleccionado);
    return this.utilService.getErrorClassCkbFormControl(arrayList, estadoTouched, Constantes.ERROR_CLASS_FORM_CONTROL_TXT);
  }
  getErrorLabelCkb(arrayList: any[], estadoTouched: boolean) {
    arrayList = arrayList.filter(check => check.seleccionado);
    return this.utilService.getErrorClassCkbFormControl(arrayList, estadoTouched, Constantes.ERROR_CLASS_FORM_CONTROL_LBL);
  }
  getErrorMensajeCkb(arrayList: any[], estadoTouched: boolean) {
    arrayList = arrayList.filter(check => check.seleccionado);
    return this.utilService.getErrorMensajeCkbFormControl(arrayList, estadoTouched);
  }
  //Ini metodos componente
  // Propiedades formControl
  get desOtroIncosistencia() {
    return this.formRegProgramacion.get('desOtroIncosistencia') as FormControl;
  }

  get desOtroBien() {
    return this.formRegProgramacion.get('desOtroBien') as FormControl;
  }

  get desOtraFuente() {
    return this.formRegProgramacion.get('desOtraFuente') as FormControl;
  }
  get periodoInicio() {
    if (isEmpty(this.perInicioDate)) {
      return  '';
    }
    return `${this.perInicioDate.year}${padNumber(this.perInicioDate.month)}`;
  }
  get periodoFin() {
    if (isEmpty(this.perFinDate)) {
      return  '';
    }
    return `${this.perFinDate.year}${padNumber(this.perFinDate.month)}`;
  }
}
