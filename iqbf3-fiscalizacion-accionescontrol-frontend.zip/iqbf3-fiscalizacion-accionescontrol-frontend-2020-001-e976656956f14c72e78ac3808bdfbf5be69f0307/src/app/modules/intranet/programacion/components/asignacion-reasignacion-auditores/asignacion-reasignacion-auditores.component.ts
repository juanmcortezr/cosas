import { Component, OnInit } from '@angular/core';
import { InterfazCatalogo, CatalogoService } from 'iqbf';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { UtilService } from 'src/app/services/shared/util.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { UsuarioProgramacionBean, UsuarioProgramacion } from 'src/app/models/usuarioProgramacion.model';
import { AsignaReasignaAuditorService } from 'src/app/services/asigna-reasigna-auditor.service';
import { GrupoProceso } from 'src/app/models/grupoProceso.model';

@Component({
  selector: 'app-asignacion-reasignacion-auditores',
  templateUrl: './asignacion-reasignacion-auditores.component.html',
  styleUrls: ['./asignacion-reasignacion-auditores.component.css']
})
export class AsignacionReasignacionAuditoresComponent implements OnInit {

  formBusqueda: FormGroup;
  tipoDocUsuario: InterfazCatalogo.Catalogo[] = [];
  listaSupervision: GrupoProceso[];
  mensaje: string;
  submitted: boolean = false;
  consulta : UsuarioProgramacion[];
  itemSeleccionado :UsuarioProgramacion;
  codFiscalizacion : string = "02";
  rbOpcion:boolean;
  lbOpcion:string;


  constructor(
    private router: Router,
    private catalogoService: CatalogoService,
    private http: HttpClient,
    private utilService: UtilService,
    private formBuilder: FormBuilder,
    private asignaReasignaAuditorService: AsignaReasignaAuditorService,
    private rutaActiva: ActivatedRoute
   
  ) {
    this.cargarTiposDocUsuario();
    this.createForm();
    this.itemSeleccionado  = new UsuarioProgramacion();
  }

  ngOnInit() {
  }

  private createForm() {
    this.formBusqueda = this.formBuilder.group({
      nroProg: '',
      alcProg: '',
      nroInfSele: '',
      cboTipDocUsu: '',
      nroDocUsu: '',
      audiPrincipal: '',
    });
  }

  cargarTiposDocUsuario(): void {
    this.tipoDocUsuario = [];
    this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF).subscribe(
      result => {
        this.tipoDocUsuario = result.data;
      },
      error => {
        console.log("Hubo errores ", error);
      }
    )
  }

  buscar(): void {

  let nroProg = this.formBusqueda.get('nroProg').value;
  let alcProg = this.formBusqueda.get('alcProg').value;
  let nroInfSele = this.formBusqueda.get('nroInfSele').value;
  let cboTipDocUsu = this.formBusqueda.get('cboTipDocUsu').value;
  let nroDocUsu = this.formBusqueda.get('nroDocUsu').value;
  let audiPrincipal = this.formBusqueda.get('audiPrincipal').value;

  if(this.validar(nroProg) && this.validar(alcProg) && this.validar(nroInfSele)
    && this.validar(cboTipDocUsu) && this.validar(nroDocUsu) && this.validar(audiPrincipal)){
      this.mensaje = "Debe de ingresar al menos un criterio de búsqueda.";
      this.submitted = true;
 //<    return;
    }

  let filtro : UsuarioProgramacionBean = new UsuarioProgramacionBean();

  filtro = {
    numProgramacion: nroProg,
    alcanceProg:alcProg,
    numInformeSelecci:nroInfSele,
    codTipoDocumentoIdentif: cboTipDocUsu,
    numDocumentoIdentif: nroDocUsu,
    nomAuditor:audiPrincipal
  }


  this.asignaReasignaAuditorService.listarUsuarioProgramacion(filtro).subscribe(
    result => {
      console.log("resultado : " + result);
      this.consulta = result;
      if (this.consulta == undefined || this.consulta.length == 0) {
        this.mensaje = "No existe datos.";
        this.submitted = true;
      } else {
        this.mensaje = "";
        this.submitted = false;
      }
    },
    error => {
      console.log("Hubo errores ", error);
    }
  )

}

reasignarAuditorPrincipal(item:UsuarioProgramacion):void{
 this.itemSeleccionado = item;
 this.rbOpcion= true;
 this.opcionAuditorAction();
}

auditoresApoyo(item:UsuarioProgramacion):void{
  this.itemSeleccionado = item;
}

opcionAuditorAction():void{
  this.lbOpcion = "Supervisiones";

  this.asignaReasignaAuditorService.listarSupervisionAuditor().subscribe(
    result => {
      console.log("resultado : " + result);
      this.listaSupervision = result;
    },
    error => {
      console.log("Hubo errores ", error);
    }
  )

}

opcionAgenteAction():void{
  this.lbOpcion = "Puesto de control";
}

  limpiar(): void {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate(['programacion/asignacion-reasignacion-auditores']));
  }

  validar(dato: any): boolean {
    return dato == undefined || dato == '';
  }

}
