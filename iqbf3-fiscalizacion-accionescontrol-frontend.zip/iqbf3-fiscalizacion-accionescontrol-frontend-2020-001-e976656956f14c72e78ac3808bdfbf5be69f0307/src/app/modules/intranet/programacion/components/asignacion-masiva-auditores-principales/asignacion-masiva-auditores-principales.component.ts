import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Constantes } from 'src/app/utils/constantes';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { Programacion } from 'src/app/models/programacion.model';
import { AsignacionMasivaAuditores } from "src/app/models/asignacionMasivaAuditores.model";
import { UtilService } from 'src/app/services/shared/util.service';
import { AsignacionMasivaAudtoresPrincipalService } from 'src/app/services/asignacion-masiva-auditores-principal.service';
import { trim, isNotEmpty, compareTwoDates, getMomentActual, isEmpty, stringToMoment } from 'src/app/utils/utilitarios';
import { NgbModalRef, NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-asignacion-masiva-auditores-principales',
  templateUrl: './asignacion-masiva-auditores-principales.component.html',
  styleUrls: ['./asignacion-masiva-auditores-principales.component.css']
})
export class AsignacionMasivaAuditoresPrincipalesComponent implements OnInit {

  /* Declaracion variables */
  // Catalogo
  catalogoEstadoProg: string;
  catalogoEstadoInforme: string;

  //Model & List
  filtro: Programacion = new Programacion();
  filtroListaAuditores: AsignacionMasivaAuditores = new AsignacionMasivaAuditores();
  programacion: Programacion = new Programacion();
  solicituAsignacion: Programacion = new Programacion();
  programaciones: Programacion[];
  listaAuditoresAsignar: AsignacionMasivaAuditores[];
  listaAuditoresPrincipal: AsignacionMasivaAuditores[];
  listaAuditoresPrincipalAux: AsignacionMasivaAuditores[];

  cboValSupervisorPuestosControl: AsignacionMasivaAuditores[];

  //Fechas
  desdeObligatorio: boolean = false;
  hastaObligatorio: boolean = false;

  //Modal
  @ViewChild('mdlSeleccionAuditoresAsigMasiva', { static: true }) mdlSeleccionAuditoresAsigMasiva: NgbActiveModal;
  @ViewChild('mdlListaAuditores', { static: true }) mdlListaAuditores: NgbActiveModal;
  modalRef: NgbModalRef;
  modalRefList: NgbModalRef;
  hiddenMdlAsignar: boolean = false;

  constructor(
    private router: Router,
    private utilService: UtilService,
    private modalService: NgbModal,
    private asignacionMasivaAudtoresPrincipal: AsignacionMasivaAudtoresPrincipalService
  ) { }

  ngOnInit() {
    this.inicio();
  }

  /* Inicio Metodos de Componentes */
  inicio() {
    this.catalogoEstadoProg = ConstantesCatalogo.COD_CATALOGO_ESTADOS_PROGRAMAS;
    this.catalogoEstadoInforme = ConstantesCatalogo.COD_CATALOGO_ESTADO_INFORMESELECCION;
    this.limpiarcampos();
  }

  limpiarcampos() {
    this.filtro = new Programacion();
    this.programaciones = [];
    this.obligatoriedadFechas(false, false);
  }

  obligatoriedadFechas(a: boolean, b: boolean) {
    this.desdeObligatorio = a;
    this.hastaObligatorio = b;
  }

  validarFechaActual(hasta: string, ind: string) {
    let fechaActual = getMomentActual();
    if (compareTwoDates(fechaActual, hasta).toString() == Constantes.COMPARE_MOMENT_AFTER
      && ind == Constantes.IND_HASTA) {
      this.obligatoriedadFechas(false, true);
      this.utilService.alertaMensaje(MensajesExcepciones.CUS11_EXCP_003, Constantes.MODAL_DANGER);
      return false;
    }
  }

  validarHastaMayor(desde: string, hasta: string, ind: string) {
    if (compareTwoDates(hasta, desde).toString() == Constantes.COMPARE_MOMENT_AFTER) {
      this.obligatoriedadFechas(true, true);
      if (ind == Constantes.IND_HASTA)
        this.utilService.alertaMensaje(MensajesExcepciones.CUS11_EXCP_001, Constantes.MODAL_DANGER);
      if (ind == Constantes.IND_DESDE)
        this.utilService.alertaMensaje(MensajesExcepciones.CUS11_EXCP_002, Constantes.MODAL_DANGER);
      return false;
    }
  }

  eventoFechas(desde: string, hasta: string, indFecha: string) {
    if (isNotEmpty(desde) && isNotEmpty(hasta) && isNotEmpty(indFecha)) {
      this.obligatoriedadFechas(false, false);
      this.validarFechaActual(hasta, indFecha);
      this.validarHastaMayor(desde, hasta, indFecha);
    }
    else if (isNotEmpty(hasta) && isNotEmpty(indFecha)) {
      this.obligatoriedadFechas(false, false);
      this.validarFechaActual(hasta, indFecha);
    }
    else {
      this.obligatoriedadFechas(false, false);
    }
  }

  cancelarAsignarAuditores() {
    this.modalRef.close();
  }

  cancelarAuditorPrincipal() {
    this.modalRefList.close();
    setTimeout(() => {
      this.hiddenMdlAsignar = false;
    }, Constantes.ALERT_TIEMPO_100);
  }
  /* Fin Metodos de Componentes */

  /* Inicio Metodos de Web Services */
  listarPrograma() {
    this.programacion = new Programacion();
    this.programaciones = [];

    this.programacion.numProgramacion = this.filtro.numProgramacion;
    this.programacion.desAlcance = trim(this.filtro.desAlcance);
    this.programacion.codEstadoPrograma = trim(this.filtro.codEstadoPrograma);
    this.programacion.fechaDesde = trim(this.filtro.fechaDesde);
    this.programacion.fechaHasta = trim(this.filtro.fechaHasta);
    this.programacion.numInforme = trim(this.filtro.numInforme);
    this.programacion.codEstadoInforme = trim(this.filtro.codEstadoInforme);
    this.programacion.desProgramador = trim(this.filtro.desProgramador);

    if (this.programacion.filtroValido()) {
      this.asignacionMasivaAudtoresPrincipal.listarPrograma(this.programacion).subscribe(
        result => {
          if (result.exito) {
            this.programaciones = result.data;
            console.log("carga listarPrograma", this.programaciones);
            this.cargarListaAuditor();
          } else {
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_SIN_RESULTADO, Constantes.MODAL_DANGER);
          }
        },
        error => {
          console.log('Hubo errores ', error);
        }
      );
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
    }
  }

  asignarAuditores(programacion: Programacion) {
    this.solicituAsignacion = programacion;
    console.log('this.solicituAsignacion =>', this.solicituAsignacion);
    this.cboSupervisorPuestosControl();
    //carga inicial de listaAuditoresAsignar
    this.filtroListaAuditores.numRegistro = "123456";
    this.asignacionMasivaAudtoresPrincipal.obtenerAsignarAuditor(this.filtroListaAuditores).subscribe(
      result => {
        if (result.exito) {
          this.listaAuditoresAsignar = result.data;
          console.log("obtenerAsignarAuditor", result.data);
          this.hiddenMdlAsignar = false;
          this.modalRef = this.modalService.open(this.mdlSeleccionAuditoresAsigMasiva, { size: 'lg' });

        } else {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
          console.log("error al obtener listaAuditores");
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );
  }

  /* Fin Metodos de Web Services */

  cargarAsignarAuditor() {
    console.log("cargarAsignarAuditor()");
  }

  guardarAsignarAuditores() {
    this.asignacionMasivaAudtoresPrincipal.guardarAuditorPresel(this.listaAuditoresAsignar).subscribe(
      result => {
        if (result.exito) {
          console.log("carga inicial lstaAuditores", result.data);
        } else {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
          console.log("error al obtener listaAuditores");
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );
    console.log("guardarAuditorPresel()");
  }

  cargarAuditorPrincipal() {
    //carga inicial de listaAuditoresPrincipal
    this.asignacionMasivaAudtoresPrincipal.listarAuditor(this.filtroListaAuditores).subscribe(
      result => {
        if (result.exito) {
          this.listaAuditoresPrincipal = result.data;
          console.log("listarAuditor", result.data);
          this.hiddenMdlAsignar = true;
          this.modalRefList = this.modalService.open(this.mdlListaAuditores, { size: 'lg' });
        } else {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
          console.log("error al obtener listaAuditores");
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );
  }

  eliminarAuditor(valor: string) {
    let c = 0;
    this.listaAuditoresAsignar.forEach(element => {
      if (valor == element.numRegistro) {
        this.listaAuditoresAsignar.splice(c, 1);
      }
      c++;
    });
  }

  agregarAuditorPrincipal() {
    let auditoresSeleccionados = document.querySelectorAll("input[type=checkbox]:checked");
    this.listaAuditoresPrincipalAux = [];
    this.listaAuditoresPrincipal.forEach(element1 => {
      auditoresSeleccionados.forEach(element2 => {
        if (element1.numRegistro == element2.id) {
          this.listaAuditoresAsignar.push(element1);
          this.listaAuditoresPrincipalAux.push(element1);
        }
      });
    });
    this.modalRefList.close();
    setTimeout(() => {
      this.hiddenMdlAsignar = false;
    }, Constantes.ALERT_TIEMPO_100);
  }

  checkMarcarQuitarTodos() {

    let auditoresSeleccionados: any = document.querySelectorAll("input[type=checkbox]:not([name=checkTodos])");

    var element = <HTMLInputElement>document.getElementById("checkTodos");
    if (!element.checked) {
      for (let i = 0; i < auditoresSeleccionados.length; i++) {
        if (auditoresSeleccionados[i].type == "checkbox")
          auditoresSeleccionados[i].checked = 0
      }
    } else {
      for (let i = 0; i < auditoresSeleccionados.length; i++) {
        if (auditoresSeleccionados[i].type == "checkbox")
          auditoresSeleccionados[i].checked = 1
      }
    }
  }

  cboSupervisorPuestosControl() {
    this.asignacionMasivaAudtoresPrincipal.cargarListaAuditor().subscribe(
      result => {
        if (result.exito) {
          this.cboValSupervisorPuestosControl = result.data;
          console.log("carga inicial lstaAuditores", result.data);
        } else {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
          console.log("error al obtener listarAuditor");
        }
      },
      error => {
        console.log('error: cboSupervisorPuestosControl()', error);
      }
    );
  }

  cargarListaAuditor() {
    console.log("cargarListaAuditor()");
  }

  listarAuditor() {
    console.log("listarAuditor()");
  }

  agregarAuditor() {
    console.log("agregarAuditor()");
  }

}
