import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IqbfModule } from 'iqbf';

import { ProgramacionRoutingModule } from './programacion-routing.module';
import { GestionProgramasDefinidosComponent } from './components/gestion-programas-definidos/gestion-programas-definidos.component';
import { GestionOtrosProgramasControlComponent } from './components/gestion-otros-programas-control/gestion-otros-programas-control.component';
import { BandejaProgramasAsignadosComponent } from './components/bandeja-programas-asignados/bandeja-programas-asignados.component';
import { EvaluacionProgramasInformeSelComponent } from './components/evaluacion-programas-informe-sel/evaluacion-programas-informe-sel.component';
import { AsignacionMasivaAuditoresPrincipalesComponent } from './components/asignacion-masiva-auditores-principales/asignacion-masiva-auditores-principales.component';
import { AsignacionReasignacionAuditoresComponent } from './components/asignacion-reasignacion-auditores/asignacion-reasignacion-auditores.component';
import { CompletarInformeSeleccionComponent } from './components/completar-informe-seleccion/completar-informe-seleccion.component';
import { ReasignarProgramacionInformeSeleccionComponent } from './components/reasignar-programacion-informe-seleccion/reasignar-programacion-informe-seleccion.component';
import { AsignacionMasivaOCComponent } from './components/asignacion-masiva-oc/asignacion-masiva-oc.component';
import { primeNgModule } from 'src/app/app-primeng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CargarFiscalizableComponent } from './components/bandeja-programas-asignados/cargar-fiscalizable/cargar-fiscalizable.component';
import { FormularioInformeSeleccionComponent } from './components/bandeja-programas-asignados/formulario-informe-seleccion/formulario-informe-seleccion.component';
import { EvaluarProgramaSeleccionComponent } from './components/evaluacion-programas-informe-sel/evaluar-programa-seleccion/evaluar-programa-seleccion.component';
import { RegistrarDocumentosSeleccionComponent } from './components/completar-informe-seleccion/registrar-documentos-seleccion/registrar-documentos-seleccion.component';
import { InformeSeleccionComponent } from './components/completar-informe-seleccion/informe-seleccion/informe-seleccion.component';
import { ActualizarProgramaDefinidoComponent } from './components/gestion-programas-definidos/actualizar-programa-definido/actualizar-programa-definido.component';
import { GuardarProgramacionComponent } from './components/gestion-otros-programas-control/guardar-programacion/guardar-programacion.component';
import { EvaluarProgramacionInformeOtrosComponent } from './components/evaluacion-programas-informe-sel/evaluar-programacion-informe-otros/evaluar-programacion-informe-otros.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModulesModule } from '../../modules.module';

@NgModule({
  declarations: [
    GestionProgramasDefinidosComponent, 
    GestionOtrosProgramasControlComponent, 
    BandejaProgramasAsignadosComponent, 
    EvaluacionProgramasInformeSelComponent, 
    AsignacionMasivaAuditoresPrincipalesComponent, 
    AsignacionReasignacionAuditoresComponent, 
    CompletarInformeSeleccionComponent, 
    ReasignarProgramacionInformeSeleccionComponent, 
    AsignacionMasivaOCComponent, 
    CargarFiscalizableComponent, 
    FormularioInformeSeleccionComponent, 
    EvaluarProgramaSeleccionComponent,
    RegistrarDocumentosSeleccionComponent,
    InformeSeleccionComponent,
    ActualizarProgramaDefinidoComponent,
    GuardarProgramacionComponent,
    EvaluarProgramacionInformeOtrosComponent
  ],

  imports: [
    CommonModule,
    ProgramacionRoutingModule,
    primeNgModule,
    IqbfModule,
    FormsModule,
    NgbModule,
    ReactiveFormsModule,
    ModulesModule
  ]
})
export class ProgramacionModule { }
