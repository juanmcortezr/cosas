import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IqbfModule } from 'iqbf';

import { SolicitudesRoutingModule } from './solicitudes-routing.module';
import { GestionSolicitudesProgramacionComponent } from './components/gestion-solicitudes-programacion/gestion-solicitudes-programacion.component';
import { EvaluacionSolicitudProgramacionComponent } from './components/evaluacion-solicitud-programacion/evaluacion-solicitud-programacion.component';
import { AsignacionSolicitudProgramacionComponent } from './components/asignacion-solicitud-programacion/asignacion-solicitud-programacion.component';
import { CalificarSolicitudProgramacionComponent } from './components/calificar-solicitud-programacion/calificar-solicitud-programacion.component';
import { primeNgModule } from 'src/app/app-primeng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormularioSolicitudComponent } from './components/gestion-solicitudes-programacion/formulario-solicitud/formulario-solicitud.component';
import { EvaluarSolicitudComponent } from './components/evaluacion-solicitud-programacion/evaluar-solicitud/evaluar-solicitud.component';
import { CalificarSolicitudComponent } from './components/calificar-solicitud-programacion/calificar-solicitud/calificar-solicitud.component';
import { DetalleSolicitudComponent } from './components/gestion-solicitudes-programacion/detalle-solicitud/detalle-solicitud.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModulesModule } from '../../modules.module';

@NgModule({
  declarations: [
    GestionSolicitudesProgramacionComponent,
    EvaluacionSolicitudProgramacionComponent,
    AsignacionSolicitudProgramacionComponent,
    CalificarSolicitudProgramacionComponent,
    FormularioSolicitudComponent,
    EvaluarSolicitudComponent,
    CalificarSolicitudComponent,
    DetalleSolicitudComponent
  ],
  imports: [
    CommonModule,
    SolicitudesRoutingModule,
    primeNgModule,
    IqbfModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    ModulesModule
  ]
})
export class SolicitudesModule { }
