import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Constantes } from 'src/app/utils/constantes';
import { trim, isNotEmpty } from 'src/app/utils/utilitarios';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { CalificacionSolicitudService } from 'src/app/services/calificacion-solicitud.service';

@Component({
  selector: 'app-calificar-solicitud-programacion',
  templateUrl: './calificar-solicitud-programacion.component.html',
  styleUrls: ['./calificar-solicitud-programacion.component.css']
})
export class CalificarSolicitudProgramacionComponent implements OnInit {

  /*Inicio declaracion*/
  hiddeTable: boolean = true;

  //Combos
  // *Catalogo
  catalogoTipoDocUsuario: string;
  catalogoTipoIntervencion: string;
  catalogoTipoAccion: string;
  catalogoEstaSolicitud: string;

  // solicitud: any = {};
  solicitud: SolicitudProgramacion = new SolicitudProgramacion();
  caliSolicitud: SolicitudProgramacion = new SolicitudProgramacion();
  caliSolicitudes: SolicitudProgramacion[] = [];
  listaPermitidosTipoAccion: string[] = [];
  validTipDoc: any = {
    "maxLenght": '',
    "tipoDoc": '',
    "tipoVal": ''
  };
  /*Fin declaracion*/

  constructor(
    private router: Router,
    private utilService: UtilService,
    private calificacionSolicitudService: CalificacionSolicitudService
  ) { }

  ngOnInit() {
    this.Inicio();
  }

  //Inicio metodos componente
  Inicio() {
    this.inicializarCatalogos();
    this.limpiarcampos();
  }
  inicializarCatalogos() {
    this.catalogoTipoIntervencion = ConstantesCatalogo.COD_CATALOGO_TIPO_INTERVENCION;
    this.catalogoTipoAccion = ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL;
    this.catalogoEstaSolicitud = ConstantesCatalogo.COD_CATALOGO_ESTADO_SOLICITUD;
    this.catalogoTipoDocUsuario = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
  }

  limpiarcampos() {
    this.solicitud = new SolicitudProgramacion();
    this.caliSolicitudes = [];
    this.listaPermitidosTipoAccion = [];
    //Setear tabla
    this.hiddeTable = true;
  }

  //Eventos combo
  eventoCboCodTipoDocIdentif(codTipDoc: string) {
    this.solicitud.numDocUsuario = '';
    if (codTipDoc == Constantes.TIPO_DOCUMENTO_DNI) {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_DNI;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }
    else if (codTipDoc == Constantes.TIPO_DOCUMENTO_RUC) {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_RUC;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }
    else {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_OTROS;
      this.validTipDoc.tipoDoc = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBERLETTER;
    }
  }

  eventoCodTipoIntervencion(value: string) {
    if (value == Constantes.TIPO_INTERVENCION_CONTROL) {
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_CARTA, Constantes.TIPO_ACCION_ESQUELA];
    } else if (value == Constantes.TIPO_INTERVENCION_FISCALIZACION) {
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_VISITA_PROGRAMADA, Constantes.TIPO_ACCION_VISITA_NO_PROGRAMADA];
    } else {
      this.listaPermitidosTipoAccion = [];
    }
  }
  //Fin metodos componente

  //Ini metodos Web Service
  listarSolicitudesporAsignar() {
    console.log('Buscar solicitud por asignar');

    this.caliSolicitudes = [];

    this.caliSolicitud.numSolicitudUnion = trim(this.solicitud.numSolicitudUnion);
    this.caliSolicitud.codTipoDocUsuario = trim(this.solicitud.codTipoDocUsuario);
    this.caliSolicitud.numDocUsuario = trim(this.solicitud.numDocUsuario);
    this.caliSolicitud.codTipoIntervension = trim(this.solicitud.codTipoIntervension);
    this.caliSolicitud.codTipoAccion = trim(this.solicitud.codTipoAccion);
    this.caliSolicitud.nomProgramador = trim(this.solicitud.nomProgramador);

    if (this.caliSolicitud.filtroValidoProgram()) {
      // validar numDocUsuario
      if (isNotEmpty(this.caliSolicitud.codTipoDocUsuario)) {
        if (isNotEmpty(this.caliSolicitud.numDocUsuario)) {
          if ((this.caliSolicitud.codTipoDocUsuario == Constantes.TIPO_DOCUMENTO_DNI
            && this.caliSolicitud.numDocUsuario.length < 8)
            || (this.caliSolicitud.codTipoDocUsuario == Constantes.TIPO_DOCUMENTO_RUC
              && this.caliSolicitud.numDocUsuario.length < 11)) {
            this.utilService.alertaMensaje(MensajesExcepciones.CUS02_EXCP_002, Constantes.MODAL_DANGER);
            return false;
          }
        }
      }

      this.calificacionSolicitudService.listarSolicitudesporCalificar(this.caliSolicitud).subscribe(
        result => {
          if (result.exito) {
            this.caliSolicitudes = result.data;
            this.hiddeTable = false;
          } else {
            console.log(result.mensaje);
            this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
          }
        },
        error => {
          console.log("Hubo errores ", error);
        }
      );
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
    }
  }

  //Fin metodos Web Service
}
