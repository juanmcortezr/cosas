import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal, NgbActiveModal, NgbModalRef, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { Constantes } from 'src/app/utils/constantes';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { trim, isNotEmpty } from 'src/app/utils/utilitarios';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { Persona } from 'src/app/models/persona.model';
import { AsignaSolicitud } from 'src/app/models/asignaSolicitud.model';
import { AsignaProgramacion } from 'src/app/models/AsignaProgramacion.model';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { CatalogoService } from 'src/app/services/maestros/catalogo.service';
import { AsignacionSolicitudService } from 'src/app/services/asignacion-solicitud.service';
import { GestionProgramaOtrosService } from 'src/app/services/gestion-programa-otros.service';


@Component({
  selector: 'app-asignacion-solicitud-programacion',
  templateUrl: './asignacion-solicitud-programacion.component.html',
  styleUrls: ['./asignacion-solicitud-programacion.component.css']
})
export class AsignacionSolicitudProgramacionComponent implements OnInit {
  /*Inicio declaracion*/
  //Combos
  // *Catalogo
  catalogoTipoDocUsuario: string;
  catalogoTipoIntervencion: string;
  catalogoTipoAccion: string;
  catalogoEstaSolicitud: string;

  // Declara variables
  solicitud: SolicitudProgramacion = new SolicitudProgramacion();
  asigResigSolicitud: SolicitudProgramacion = new SolicitudProgramacion();
  asigResigSolicitudes: SolicitudProgramacion[] = [];
  asignaSolicitud: AsignaSolicitud = new AsignaSolicitud();
  histAsignaciones: AsignaProgramacion[] = [];

  //Componentes
  verMsgBandeja: boolean = false;
  verMsgModal: boolean = false;
  hiddeTable: boolean = true;
  programadores: Persona[] = [];
  listaPermitidosTipoAccion: string[] = [];
  validTipDoc: any = {
    "maxLenght": '',
    "tipoDoc": '',
    "tipoVal": ''
  };

  //Archivo
  urlDescargaArchivo: string;

  //Modal
  modalRef: NgbModalRef;
  @ViewChild('mdlDetalleAccionesUsuario', { static: true }) mdlDetalleAccionesUsuario: NgbActiveModal;
  /*Fin declaracion*/

  constructor(
    private router: Router,
    private modalService: NgbModal,
    private utilService: UtilService,
    private catalogoService: CatalogoService,
    private asignacionSolicitudService: AsignacionSolicitudService,
    private gestionProgramaOtrosService: GestionProgramaOtrosService
  ) { }

  ngOnInit() {
    this.Inicio();
  }

  //Inicio metodos componente
  Inicio() {
    this.inicializarComponentes();
    this.limpiarcampos(); this.listarProgramadores();
    //Archivo
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO
  }

  inicializarComponentes() {
    this.catalogoTipoIntervencion = ConstantesCatalogo.COD_CATALOGO_TIPO_INTERVENCION;
    this.catalogoTipoAccion = ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL;
    this.catalogoEstaSolicitud = ConstantesCatalogo.COD_CATALOGO_ESTADO_SOLICITUD;
    this.catalogoTipoDocUsuario = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
  }

  limpiarcampos() {
    this.solicitud = new SolicitudProgramacion();
    this.asigResigSolicitud = new SolicitudProgramacion();
    this.asigResigSolicitudes = [];
    this.listaPermitidosTipoAccion = [];
    //Setear mensajes
    this.mostrarMensaje(false, false);
    //Setear tabla
    this.hiddeTable = true;
  }

  //Eventos combo
  eventoCboCodTipoDocIdentif(codTipDoc: string) {
    this.solicitud.numDocUsuario = '';
    if (codTipDoc == Constantes.TIPO_DOCUMENTO_DNI) {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_DNI;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }
    else if (codTipDoc == Constantes.TIPO_DOCUMENTO_RUC) {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_RUC;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }
    else {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_OTROS;
      this.validTipDoc.tipoDoc = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBERLETTER;
    }
  }

  eventoCodTipoIntervencion(value: string) {
    if (value == Constantes.TIPO_INTERVENCION_CONTROL) {
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_CARTA, Constantes.TIPO_ACCION_ESQUELA];
    } else if (value == Constantes.TIPO_INTERVENCION_FISCALIZACION) {
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_VISITA_PROGRAMADA, Constantes.TIPO_ACCION_VISITA_NO_PROGRAMADA];
    } else {
      this.listaPermitidosTipoAccion = [];
    }
  }

  mostrarMensaje(a: boolean, b: boolean) {
    this.verMsgBandeja = a;
    this.verMsgModal = b;
  }

  cancelarAsignacion() {
    this.modalRef.close();
  }
  //Fin metodos componente

  //Ini metodos Web Service
  listarSolicitudesporAsignar() {
    this.asigResigSolicitud = new SolicitudProgramacion();
    this.asigResigSolicitudes = [];
    this.asigResigSolicitud.numSolicitudUnion = trim(this.solicitud.numSolicitudUnion);
    this.asigResigSolicitud.codTipoDocUsuario = trim(this.solicitud.codTipoDocUsuario);
    this.asigResigSolicitud.numDocUsuario = trim(this.solicitud.numDocUsuario);
    this.asigResigSolicitud.codTipoIntervension = trim(this.solicitud.codTipoIntervension);
    this.asigResigSolicitud.codTipoAccion = trim(this.solicitud.codTipoAccion);
    this.asigResigSolicitud.nomProgramador = trim(this.solicitud.nomProgramador);

    this.mostrarMensaje(true,false);

    if (this.asigResigSolicitud.filtroValidoProgram()) {
      // validar numDocUsuario
      if (isNotEmpty(this.asigResigSolicitud.codTipoDocUsuario)) {
        if (isNotEmpty(this.asigResigSolicitud.numDocUsuario)) {
          if ((this.asigResigSolicitud.codTipoDocUsuario == Constantes.TIPO_DOCUMENTO_DNI
            && this.asigResigSolicitud.numDocUsuario.length < 8)
            || (this.asigResigSolicitud.codTipoDocUsuario == Constantes.TIPO_DOCUMENTO_RUC
              && this.asigResigSolicitud.numDocUsuario.length < 11)) {
            this.utilService.alertaMensaje(MensajesExcepciones.CUS02_EXCP_002, Constantes.MODAL_DANGER);
            return false;
          }
        }
      }

      this.asignacionSolicitudService.listarSolicitudesporAsignar(this.asigResigSolicitud).subscribe(
        result => {
          if (result.exito) {
            this.asigResigSolicitudes = result.data;
            this.hiddeTable = false;
          } else {
            console.log(result.mensaje);
            this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
          }
        },
        error => {
          console.log("Hubo errores ", error);
        }
      );
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
    }
  }

  cargarAsignacionSolicitud(solicitud: SolicitudProgramacion) {
    this.histAsignaciones = [];
    this.asigResigSolicitud = solicitud;
    this.asignaSolicitud.codProgramador = '';
    this.mostrarMensaje(false,true);
    this.modalRef = this.modalService.open(this.mdlDetalleAccionesUsuario, { size: 'lg' });
    this.asignacionSolicitudService.cargarAsignacionSolicitud(solicitud.numSolicitud).subscribe(
      result => {
        if (result.exito) {
          this.histAsignaciones = result.data;
        } else {
          console.log(result.mensaje);
          // this.utilService.alertaMensaje('No se encuentra histAsignaciones', Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log("Hubo errores ", error);
      }
    );
  }

  listarProgramadores() {
    this.programadores = [];
    this.gestionProgramaOtrosService.listarProgramador().subscribe(
      result => {
        if (result.exito) {
          this.programadores = result.data;
        } else {
          console.log(`No se ha obtenido las actividades`);
        }
      },
      error => {
        console.log("Hubo errores ", error);
      }
    );
  }

  guardarAsignacionSolicitud(codPers: string, numSoli: number) {
    if (codPers != '') {
      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,
        Constantes.MODAL_MENSAJE_GUARDAR_SOLICITUD,
        Constantes.MODAL_PRIMARY, () => {
          this.asignaSolicitud = new AsignaSolicitud();
          this.asignaSolicitud.numSolicitud = numSoli;
          this.asignaSolicitud.codProgramador = codPers;
          this.asignacionSolicitudService.guardarAsignacionSolicitud(this.asignaSolicitud).subscribe(respuesta => {
            if (respuesta.exito) {
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
              setTimeout(() => {
                this.modalRef.close();
                this.listarSolicitudesporAsignar();
              }, Constantes.ALERT_TIEMPO_2000);
            }
          });
        }
      );
    }
  }
  //Fin metodos Web Service
}