import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Constantes } from 'src/app/utils/constantes';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { trim, isNotEmpty } from 'src/app/utils/utilitarios';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { GestionSolicitudService } from 'src/app/services/gestion-solicitud.service';
import { EvaluacionSolicitudService } from 'src/app/services/evaluacion-solicitud.service';

@Component({
  selector: 'app-evaluacion-solicitud-programacion',
  templateUrl: './evaluacion-solicitud-programacion.component.html',
  styleUrls: ['./evaluacion-solicitud-programacion.component.css']
})
export class EvaluacionSolicitudProgramacionComponent implements OnInit {

  /*Inicio declaracion*/
  //Supervisor
  supervisorSolicitante: string = '1';
  supervisorProgramador: string = '2';
  esProgramador: boolean = false;
  esSolicitante: boolean = false;

  tipoSupervisor: string = this.supervisorSolicitante;
  hiddeTable: boolean = true;

  //Combos
  // *Catalogo
  catalogoTipoDocUsuario: string;
  catalogoTipoIntervencion: string;
  catalogoTipoAccion: string;
  catalogoEstaSolicitud: string;

  //Variables
  solicitud: SolicitudProgramacion = new SolicitudProgramacion();
  evalSolicitud: SolicitudProgramacion = new SolicitudProgramacion();
  evalSolicitudes: SolicitudProgramacion[] = [];
  listaPermitidosTipoAccion: string[] = [];
  validTipDoc: any = {
    "maxLenght": '',
    "tipoDoc": '',
    "tipoVal": ''
  };
  //Archivo
  urlDescargaArchivo: string;
  /* Fin declaracion */

  constructor(
    private router: Router,
    private utilService: UtilService,
    private evaluacionSolicitudService: EvaluacionSolicitudService,
    private gestionSolicitudService: GestionSolicitudService
  ) { }

  ngOnInit() {
    this.inicio();
  }
  /*Inicio metodos componente*/
  inicio() {
    this.inicializarCatalogos();
    this.limpiarcampos();
    this.cambiarSupervisor(this.supervisorSolicitante);
    //Archivo
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO
  }

  inicializarCatalogos() {
    this.catalogoTipoIntervencion = ConstantesCatalogo.COD_CATALOGO_TIPO_INTERVENCION;
    this.catalogoTipoAccion = ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL;
    this.catalogoEstaSolicitud = ConstantesCatalogo.COD_CATALOGO_ESTADO_SOLICITUD;
    this.catalogoTipoDocUsuario = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
  }

  limpiarcampos() {
    this.solicitud = new SolicitudProgramacion();
    //Setear tabla
    this.hiddeTable = true;
    this.evalSolicitudes = [];
    this.listaPermitidosTipoAccion = [];
  }

  cambiarSupervisor(tipoSupervisor: string) {
    this.limpiarcampos();
    if (tipoSupervisor == this.supervisorSolicitante) {
      this.esProgramador = false;
      this.esSolicitante = true;
    } else if (tipoSupervisor == this.supervisorProgramador) {
      this.esProgramador = true;
      this.esSolicitante = false;
    }
  }

  //Eventos combo
  eventoCboCodTipoDocIdentif(codTipDoc: string) {
    this.solicitud.numDocUsuario = '';
    if (codTipDoc == Constantes.TIPO_DOCUMENTO_DNI) {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_DNI;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }
    else if (codTipDoc == Constantes.TIPO_DOCUMENTO_RUC) {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_RUC;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }
    else {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_OTROS;
      this.validTipDoc.tipoDoc = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBERLETTER;
    }
  }

  eventoCodTipoIntervencion(value: string) {
    if (value == Constantes.TIPO_INTERVENCION_CONTROL) {
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_CARTA, Constantes.TIPO_ACCION_ESQUELA];
    } else if (value == Constantes.TIPO_INTERVENCION_FISCALIZACION) {
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_VISITA_PROGRAMADA, Constantes.TIPO_ACCION_VISITA_NO_PROGRAMADA];
    } else {
      this.listaPermitidosTipoAccion = [];
    }
  }
  /*Fin metodos componente*/

  /*Ini metodos Web Service*/
  listarSolicitudSupervisorProgramador() {
    console.log('Buscar evaluacion solicitud');

    this.evalSolicitudes = [];

    this.evalSolicitud.numSolicitudUnion = trim(this.solicitud.numSolicitudUnion);
    this.evalSolicitud.codTipoDocUsuario = trim(this.solicitud.codTipoDocUsuario);
    this.evalSolicitud.numDocUsuario = trim(this.solicitud.numDocUsuario);
    this.evalSolicitud.codTipoIntervension = trim(this.solicitud.codTipoIntervension);
    this.evalSolicitud.codTipoAccion = trim(this.solicitud.codTipoAccion);
    this.evalSolicitud.codEstadoSolicitud = trim(this.solicitud.codEstadoSolicitud);
    this.evalSolicitud.nomSolicitante = trim(this.solicitud.nomSolicitante);

    if (this.evalSolicitud.filtroValidoProgram()) {
      //validar numDocUsuario
      if (isNotEmpty(this.evalSolicitud.codTipoDocUsuario)) {
        if (isNotEmpty(this.evalSolicitud.numDocUsuario)) {
          if ((this.evalSolicitud.codTipoDocUsuario == Constantes.TIPO_DOCUMENTO_DNI
            && this.evalSolicitud.numDocUsuario.length < 8)
            || (this.evalSolicitud.codTipoDocUsuario == Constantes.TIPO_DOCUMENTO_RUC
              && this.evalSolicitud.numDocUsuario.length < 11)) {
            this.utilService.alertaMensaje(MensajesExcepciones.CUS02_EXCP_002, Constantes.MODAL_DANGER);
            return false;
          }
        }
      }

      if (this.esProgramador == true) {
        console.log("listarSolicitudSupervisorProgramador ");
        this.evaluacionSolicitudService.listarSolicitudSupervisorProgramador(this.evalSolicitud).subscribe(
          result => {
            if (result.exito) {
              this.evalSolicitudes = result.data;
              this.hiddeTable = false;
            } else {
              console.log(result.mensaje);
              this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
            }
          },
          error => {
            console.log("Hubo errores ", error);
          }
        );
      }
      else if (this.esSolicitante == true) {
        console.log("listarSolicitudSupervisorSolicitante ");
        this.gestionSolicitudService.listarSolicitudSupervisorSolicitante(this.evalSolicitud).subscribe(
          result => {
            if (result.exito) {
              this.evalSolicitudes = result.data;
              this.hiddeTable = false;
            } else {
              console.log(result.mensaje);
              this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
            }
          },
          error => {
            console.log("Hubo errores ", error);
          }
        );
      }
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
    }
  }
  /*Fin metodos Web Service*/
}
