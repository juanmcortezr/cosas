import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Constantes } from 'src/app/utils/constantes';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { trim, isNotEmpty, isEmpty, toNumber } from 'src/app/utils/utilitarios';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { UsuarioSolicitud } from 'src/app/models/usuarioSolicitud.model';
import { CalificacionUsuario } from 'src/app/models/calificacionUsuario.model';
import { AlternativaCriterio } from 'src/app/models/alternativaCriterio.model';
import { CriterioCalificacion } from 'src/app/models/criterioCalificacion.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { CalificacionSolicitudService } from 'src/app/services/calificacion-solicitud.service';
import { AccionSugeridaCalif } from 'src/app/models/accionSugeridaCalif.model';
import { AlternativaCriterioDefinitivo } from 'src/app/models/alternativaCriterioDefinitivo.model';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { Response } from 'src/app/models/response.model';

@Component({
  selector: 'app-calificar-solicitud',
  templateUrl: './calificar-solicitud.component.html',
  styleUrls: ['./calificar-solicitud.component.css']
})
export class CalificarSolicitudComponent implements OnInit {

  /*Ini declaracion*/
  //Declaracion variables
  numSolicProg: string = '';
  indTipCali: string = '0';
  usuarioSolicitud: UsuarioSolicitud = new UsuarioSolicitud();
  usuarioSolicitudes: UsuarioSolicitud[] = [];
  usuarioCaliPreliminar: CalificacionUsuario = new CalificacionUsuario();
  usuarioCaliDefinitiva: CalificacionUsuario = new CalificacionUsuario();
  calificacionUsuarios: CalificacionUsuario[] = [];
  criteriosCalificaciones: CriterioCalificacion[] = [];
  alternativasCriterios: AlternativaCriterio[] = [];
  alternativasCriteriosSel: AlternativaCriterio[] = [];
  alternativasCriteriosSels: AlternativaCriterioDefinitivo[] = [];
  accionesSugeridasCalif: AccionSugeridaCalif[] = [];
  //Combo Default
  valueSelectAccion: string = Constantes.VALOR_VACIO;
  estadoTouchedListaCriterio: boolean = false;
  campoObligatorio: boolean = false;
  sustentoObligatorio: boolean = false;
  clickGuardar: boolean = true;
  hiddeDetalle: boolean = true;
  verMgsCalificarUsuario: boolean = false;
  verMgsEnviarUsuario: boolean = false;
  verMgsUsuario: boolean = false;
  //Archivo
  urlDescargaArchivo: string;
  /*Fin declaracion*/

  constructor(
    private rutaActiva: ActivatedRoute,
    private router: Router,
    private utilService: UtilService,
    private calificacionSolicitudService: CalificacionSolicitudService
  ) { }

  ngOnInit() {
    this.inicio();
  }

  /* Inicio metodos componentes */
  inicio() {
    this.numSolicProg = trim(this.rutaActiva.snapshot.params.numSolicProg);
    if (isNotEmpty(this.numSolicProg)) {
      this.cargarDatosCalificaciondefinitiva();
      this.cargarAccionesSugeridas();
      this.mostrarMensaje(false, false, false);
    }
    //Archivo
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO
  }

  mostrarMensaje(a: boolean, b: boolean, c: boolean) {
    this.verMgsCalificarUsuario = a;
    this.verMgsUsuario = b;
    this.verMgsEnviarUsuario = c;
  }

  cambiarUsuario(usuario: UsuarioSolicitud) {
    this.mostrarMensaje(false, true, false);
    let usuatemp = usuario;

    if (this.clickGuardar == true) {
      this.cargarDetalleUsuario(usuario);
    }
    else if (this.clickGuardar == false) {
      if (this.usuarioSolicitud != usuatemp) {
        if (isNotEmpty(this.alternativasCriteriosSels) || isNotEmpty(this.valueSelectAccion)) {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS04_INFO_GUARDAR, Constantes.MODAL_PRIMARY);
          this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,
            Constantes.MODAL_MENSAJE_CAMBIAR_CALIFICACION,
            Constantes.MODAL_PRIMARY, () => {
              this.clickGuardar = true;
              this.cargarDetalleUsuario(usuatemp);
            });
        } else {
          this.clickGuardar = true;
          this.cargarDetalleUsuario(usuatemp);
        }
      }
    }
  }

  async agregarAlternativaSeleccionada(event: any, index: number, numCriterio: string, alternativas: AlternativaCriterioDefinitivo[]) {
    this.estadoTouchedListaCriterio = true;
    let valor = trim(event.target.value);
    this.alternativasCriteriosSels = this.alternativasCriteriosSels.filter(c => c.numCriterio != toNumber(numCriterio)); //Eliminar registros de array por numCriterio
    this.alternativasCriteriosSels = this.alternativasCriteriosSels.concat(alternativas.filter(c => c.numAlternativa == toNumber(valor))); //Agregar objeto seleccionado a la lista
    this.alternativasCriteriosSels.forEach(a => {
      a.seleccionado = true;
    })
    this.campoObligatorio = false;
    //Calcular total Calificación Preliminar
    this.usuarioCaliDefinitiva.valCalificacion = this.calcularCalificacionDefinitiva();
    await this.cargarAccionSugerida();
  }

  buscarAlternativas(codCriterio: number, codAlternativa: number) {
    if (this.alternativasCriterios != null || this.alternativasCriterios.length > 0 ||
      isNotEmpty(this.alternativasCriterios)) {

      this.alternativasCriterios.forEach(aler => {
        aler.alternativasDefinitivas.forEach(def => {
          if (def.numCriterio == codCriterio && def.numAlternativa == codAlternativa) {
            def.seleccionado = true;
            return false;
          }
        });
      });
    }
  }

  calcularCalificacionDefinitiva(): number {
    let alternativaCriterioNew: AlternativaCriterioDefinitivo = new AlternativaCriterioDefinitivo();
    let alternativaCriterioedit: AlternativaCriterio = new AlternativaCriterio();
    let valorCriterio: number = Number(0);
    let valorAlternativa: number = Number(0);
    let totalCalificacion: number = Number(0);

    if (this.alternativasCriterios != null && this.alternativasCriterios.length > 0) {
      console.log('alternativasCriterios', this.alternativasCriterios);
      if (this.alternativasCriteriosSels != null && this.alternativasCriteriosSels.length > 0) {
        console.log('alternativasCriteriosSels', this.alternativasCriteriosSels);
        this.alternativasCriterios.forEach(c => {
          console.log('-----------------------------------');
          valorCriterio = Number(c.pesoCriterio);
          console.log('valorCriterio', valorCriterio);
          alternativaCriterioNew = this.alternativasCriteriosSels.find(a => a.numCriterio == c.numCriterio);
          console.log('alternativaCriterioNew', alternativaCriterioNew);
          if (alternativaCriterioNew != null) {
            valorAlternativa = Number(alternativaCriterioNew.valAlternativa);
            console.log('valorAlternativa', valorAlternativa);
            totalCalificacion = (totalCalificacion + (valorCriterio * valorAlternativa));
            console.log('totalCalificacion', totalCalificacion);
          }
        });
      }
    }
    console.log('totalCalificacionFinal', parseFloat((totalCalificacion / 100).toFixed(2)));
    return parseFloat((totalCalificacion / 100).toFixed(2));
  }

  async cargarAccionSugerida() {
    this.valueSelectAccion = Constantes.VALOR_VACIO;
    let valCriteDefi = this.usuarioCaliDefinitiva.valCalificacion;
    if (valCriteDefi > 0) {
      this.accionesSugeridasCalif.forEach(asc => {
        if (valCriteDefi >= asc.valMinimo && valCriteDefi <= asc.valMaximo) {
          this.valueSelectAccion = asc.numAccionSugerida.toString();
        }
      })
      if (isEmpty(this.valueSelectAccion)) {
        this.sustentoObligatorio = true;
      } else {
        this.sustentoObligatorio = false;
      }
    } else {
      this.valueSelectAccion = Constantes.VALOR_VACIO;
      this.sustentoObligatorio = false;
    }
    this.usuarioCaliDefinitiva.numAccionSugerida = toNumber(this.valueSelectAccion);
    this.usuarioCaliDefinitiva.desSusAccsuge = Constantes.VALOR_VACIO;
  }

  eventoAccionSugerida(accionSugerida: string) {
    let acciontemp = this.usuarioCaliDefinitiva.numAccionSugerida;
    this.usuarioCaliDefinitiva.desSusAccsuge = Constantes.VALOR_VACIO;
    if (acciontemp == toNumber(accionSugerida)) {
      this.sustentoObligatorio = false;
    } else if (isEmpty(accionSugerida) || accionSugerida == Constantes.VALOR_VACIO) {
      this.sustentoObligatorio = false;
    } else {
      this.sustentoObligatorio = true;
    }
  }

  translateAlternativasCriterioDefinitivo(alterCriterios: AlternativaCriterio[]): AlternativaCriterioDefinitivo[] {
    let alternativa: AlternativaCriterioDefinitivo = new AlternativaCriterioDefinitivo();
    let alternativaTmp: AlternativaCriterio = new AlternativaCriterio();
    let listAlternativas: AlternativaCriterioDefinitivo[] = [];

    alterCriterios.forEach(a => {
      alternativaTmp = new AlternativaCriterio();
      console.log('a.numCriterio', a.numCriterio);
      console.log('this.alternativasCriterios', this.alternativasCriterios);
      // alternativaTmp = this.alternativasCriterios.find(ac => ac.numCriterio === a.numCriterio);
      console.log('alternativaTmp = >', alternativaTmp);
      alternativa = new AlternativaCriterioDefinitivo();
      alternativa.numCriterio = a.numCriterio;
      alternativa.numAlternativa = a.numAlternativa;
      alternativa.desAlternativa = a.desAlternativa;
      alternativa.valAlternativa = a.valAlternativa;
      alternativa.indEstado = a.indEstado;
      alternativa.seleccionado = a.seleccionado;

      listAlternativas.push(alternativa);
    });

    return listAlternativas;
  }

  translateAlternativasCriterio(alterCriterios: AlternativaCriterioDefinitivo[]): AlternativaCriterio[] {
    let alternativa: AlternativaCriterio = new AlternativaCriterio();
    let list: AlternativaCriterio[] = [];

    alterCriterios.forEach(a => {
      let alternativaTmp: AlternativaCriterioDefinitivo = new AlternativaCriterioDefinitivo();
      // alternativa = this.alternativasCriterios.find(ac => ac.numCriterio === a.numCriterio);
      alternativa = new AlternativaCriterio();
      alternativaTmp = a;

      alternativa.numCriterio = alternativaTmp.numCriterio;
      alternativa.numAlternativa = alternativaTmp.numAlternativa;
      alternativa.desAlternativa = alternativaTmp.desAlternativa;
      alternativa.valAlternativa = alternativaTmp.valAlternativa;
      alternativa.indEstado = alternativaTmp.indEstado;
      alternativa.seleccionado = alternativaTmp.seleccionado;


      list.push(alternativa);
    });
    this.alternativasCriteriosSel = list;
    return this.alternativasCriteriosSel;
  }
  /* Fin metodos componentes */

  /*Inicio metodos Web Service*/
  cargarAccionesSugeridas() {
    this.accionesSugeridasCalif = [];
    this.calificacionSolicitudService.listarAccionesSugeridas(Constantes.IND_ESTADO_ACTIVO).subscribe(result => {
      if (result.exito) {
        this.accionesSugeridasCalif = result.data;
      }
    });
  }

  cargarDatosCalificaciondefinitiva() {
    this.mostrarMensaje(false, true, false);
    this.usuarioSolicitudes = [];
    this.calificacionSolicitudService.cargarDatosCalificacionDefinitiva(this.numSolicProg).subscribe(
      result => {
        if (result.exito) {
          this.usuarioSolicitudes = result.data;
        } else {
          this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log("Hubo errores ", error);
      }
    );
  }

  cargarDetalleUsuario(usuario: UsuarioSolicitud) {
    this.usuarioCaliPreliminar == new CalificacionUsuario();
    this.usuarioCaliDefinitiva == new CalificacionUsuario();
    this.alternativasCriterios = [];
    this.alternativasCriteriosSel = [];
    this.alternativasCriteriosSels = [];
    this.valueSelectAccion = Constantes.VALOR_VACIO;
    this.estadoTouchedListaCriterio = false;
    this.clickGuardar = false;
    this.hiddeDetalle = false;
    this.campoObligatorio = true;
    this.sustentoObligatorio = true;

    this.mostrarMensaje(true, false, false);
    this.usuarioSolicitud = usuario;
    this.calificacionSolicitudService.listarCalificacionUsuario(this.usuarioSolicitud.numUsuarioSolicitud).subscribe(async result => {
      if (result.exito) {
        this.calificacionUsuarios = result.data;
        // for (let jj = 0; jj < this.calificacionUsuarios.length; jj++) {
        // let usuarioCali = this.calificacionUsuarios[jj];
        this.calificacionUsuarios.forEach(async usuarioCali => {
          console.log("usuarioCali.indTipCali => ", usuarioCali.indTipCali);

          if (trim(usuarioCali.indTipCali) === "0") {
            this.indTipCali = trim(usuarioCali.indTipCali);
            this.usuarioCaliPreliminar = CalificacionUsuario.fromJSON(usuarioCali);
            this.alternativasCriterios = this.usuarioCaliPreliminar.alternativasCriterios.map(map => {
              let definitiva = new AlternativaCriterio();
              definitiva.numCriterio = map.numCriterio;
              definitiva.numAlternativa = map.numAlternativa;
              definitiva.valAlternativa = map.valAlternativa;
              definitiva.indEstado = map.indEstado;
              definitiva.desAlternativa = map.desAlternativa;
              definitiva.seleccionado = map.seleccionado;
              definitiva.desCriterio = map.desCriterio;
              definitiva.pesoCriterio = map.pesoCriterio;
              definitiva.alternativasDefinitivas = [];
              return definitiva;
            });
            console.log('this.alternativasCriterios', this.alternativasCriterios);
            this.usuarioCaliDefinitiva.valCalificacion = Constantes.VALOR_INICIAL;
            await this.listarAlternativas(null);
            this.cargarAccionSugerida();
          }
          else if (trim(usuarioCali.indTipCali) === "1") {
            this.indTipCali = trim(usuarioCali.indTipCali);
            this.usuarioCaliDefinitiva = CalificacionUsuario.fromJSON(usuarioCali);
            this.alternativasCriteriosSel = this.usuarioCaliDefinitiva.alternativasCriterios;
            console.log('this.usuarioCaliDefinitiva.valCalificacion', this.usuarioCaliDefinitiva.valCalificacion);
            //Inicio - Editar
            //Seleccion Acciones
            if (this.usuarioCaliDefinitiva.numAccionSugerida != null || isNotEmpty(this.usuarioCaliDefinitiva.numAccionSugerida)) {
              this.valueSelectAccion = this.usuarioCaliDefinitiva.numAccionSugerida.toString();
            }
            if (isNotEmpty(this.alternativasCriteriosSel) || this.alternativasCriteriosSel.length > 0 || this.alternativasCriteriosSel != null) {
              //Procesar seleccion de combos
              console.log('this.alternativasCriteriosSel', this.alternativasCriteriosSel);
              this.alternativasCriteriosSels = this.translateAlternativasCriterioDefinitivo(this.alternativasCriteriosSel);
              if (isNotEmpty(this.alternativasCriteriosSels) || this.alternativasCriteriosSels.length > 0 || this.alternativasCriteriosSels != null) {
                this.alternativasCriteriosSels.forEach(alternativa => {
                  this.buscarAlternativas(alternativa.numCriterio, alternativa.numAlternativa);
                });
              }
              //Calcular total Calificación Preliminar
              this.usuarioCaliDefinitiva.valCalificacion = this.calcularCalificacionDefinitiva();
            }
            //Fin - Editar
          }
        });
        // }
      } else {
        this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
      }
    });
  }

  listarAlternativas = async _ => {
    //Obtener lista alternativas
    for (let ii = 0; ii < this.alternativasCriterios.length; ii++) {
      let alternativa = this.alternativasCriterios[ii];
      let result: Response = await this.calificacionSolicitudService.listarAlternativaCriterio(alternativa.numCriterio, Constantes.IND_ESTADO_ACTIVO).toPromise();
      if (result.exito) {
        alternativa.alternativasDefinitivas = result.data as AlternativaCriterioDefinitivo[];
      } else {
        this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
      }
    }
  }

  validarCalificacionDefinitiva(sustento: string): boolean {
    let validado: boolean = false;

    let lengthAlterCrite: number = this.alternativasCriterios.length;
    let lengthAlterCriteSel: number = this.alternativasCriteriosSels.length;

    if (lengthAlterCrite == lengthAlterCriteSel) {
      if (this.sustentoObligatorio == false && isEmpty(sustento)) {
        validado = true;
      } else if (this.sustentoObligatorio == true && isNotEmpty(sustento)) {
        validado = true;
      } else if (this.sustentoObligatorio == true && isEmpty(sustento)) {
        this.sustentoObligatorio == true;
        this.utilService.alertaMensaje(MensajesExcepciones.CUS04_EXCP_004, Constantes.MODAL_DANGER);
      }
    } else {
      this.campoObligatorio = true;
      this.utilService.alertaMensaje(MensajesExcepciones.CUS04_EXCP_006, Constantes.MODAL_DANGER);
    }
    return validado;
  }

  guardarCalificacionDefinitiva(usuarioCaliDefinitiva: CalificacionUsuario) {
    this.usuarioCaliDefinitiva = usuarioCaliDefinitiva;
    if (this.validarCalificacionDefinitiva(this.usuarioCaliDefinitiva.desSusAccsuge)) {
      this.usuarioCaliDefinitiva.numAccionSugerida = toNumber(this.valueSelectAccion);
      this.usuarioCaliDefinitiva.numUsuarioSolicitud = this.usuarioSolicitud.numUsuarioSolicitud;
      this.usuarioCaliDefinitiva.numUsuarioCalifiicacion = this.usuarioCaliPreliminar.numUsuarioCalifiicacion;
      this.usuarioCaliDefinitiva.alternativasCriterios = this.translateAlternativasCriterio(this.alternativasCriteriosSels);
      if (this.indTipCali === "0") {
        this.usuarioCaliDefinitiva.numUsuarioCalifiicacion = Constantes.VALOR_INICIAL;
      }

      this.calificacionSolicitudService.guardarCalificacionDefinitiva(this.usuarioCaliDefinitiva).subscribe(
        result => {
          if (result.exito) {
            this.clickGuardar = true;
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
            setTimeout(() => {
              this.hiddeDetalle = true;
              this.cargarDatosCalificaciondefinitiva();
            }, Constantes.ALERT_TIEMPO_2000);
          }
        },
        error => {
        }
      );
    }
  }

  enviarCalificacion() {
    let usuario: SolicitudProgramacion = new SolicitudProgramacion();
    usuario.numSolicitud = toNumber(this.numSolicProg);
    this.calificacionSolicitudService.enviarCalificacion(usuario).subscribe(
      result => {
        if (result.exito) {
          this.router.navigate(['/solicitudes/calificar-solicitud-programacion']);

        } else {
          this.utilService.alertaMensaje(result.mensaje, Constantes.MODAL_DANGER);
        }
      },
      error => {
      }
    );
  }
  /*Fin metodos Web Service*/
}
