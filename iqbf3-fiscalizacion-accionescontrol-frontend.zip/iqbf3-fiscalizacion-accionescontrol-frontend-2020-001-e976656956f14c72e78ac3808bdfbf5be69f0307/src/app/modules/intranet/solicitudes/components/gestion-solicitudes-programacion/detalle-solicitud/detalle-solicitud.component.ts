import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CatalogoService } from 'src/app/services/maestros/catalogo.service';
import { GestionSolicitudService } from 'src/app/services/gestion-solicitud.service';
import { UtilService } from 'src/app/services/shared/util.service';
import { Constantes } from 'src/app/utils/constantes';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { Catalogo } from 'src/app/models/catalogo.model';
import { BienFiscalizadoSolicitud } from 'src/app/models/bienFiscalizadoSolicitud.model';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { trim, isEmpty, stringToMoment, padNumber, dateToString, isNotEmpty, formatDatePeriodoFront, formatDatePeriodoBack, toNumber, formatHoraBack, formatHoraFront, formatUbigeo } from 'src/app/utils/utilitarios';
import { FormGroup, FormControl, Validators, AbstractControl, FormArray } from '@angular/forms';
import { UsuarioSolicitud } from 'src/app/models/usuarioSolicitud.model';
import { EstablecimientoUsuario } from 'src/app/models/establecimientoUsuario.model';
import { MedioProbatorioUsuario } from 'src/app/models/medioProbatorioUsuario.model';
import { NgbModal, NgbActiveModal, NgbModalRef, NgbModalConfig, NgbTimepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { CriterioCalificacion } from 'src/app/models/criterioCalificacion.model';
import { CalificacionUsuario } from 'src/app/models/calificacionUsuario.model';
import { AlternativaCriterio } from 'src/app/models/alternativaCriterio.model';
import { AccionSugeridaCalif } from 'src/app/models/accionSugeridaCalif.model';
import { EstablecimientoOrden } from 'src/app/models/establecimientoOrden.model';
import { UbigeoService } from 'src/app/services/maestros/ubigeo.service';
import { Ubigeo } from 'src/app/models/ubigeo.model';
import { WSEstablecimientoAnexo } from 'src/app/models/WSEstablecimientoAnexo.model';
import { ServicioWebService } from 'src/app/services/maestros/servicio-web.service';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { ArchivoBean } from 'src/app/models/archivoBean.model';
import { UploadFileTempComponent } from 'iqbf';

@Component({
  selector: 'app-detalle-solicitud',
  templateUrl: './detalle-solicitud.component.html',
  styleUrls: ['./detalle-solicitud.component.css']
})
export class DetalleSolicitudComponent implements OnInit {

  //Ini declaracion
  tipoLBL: string; //Indicar que es una etiqueta label
  catalogoTipoDocIdentif: string; //Codigo de catalogo de tipo de documento
  catalogoTipoDocReferencia: string; //Codigo de catalogo de tipo de documento de referencia
  catalogoTipoIntervencion: string; //Codigo de catalogo de intervencion
  catalogoTipoAccionControl: string; //Codigo de catalogo de accion de control
  catalogoTipoMedioProbatorio: string; //Codigo de catalogo de tipo de medio probatorio
  catalogoTipoIncosistencias: string; //Codigo de catalogo de inconsistencias
  catalogoTipoBien: string; //Codigo de catalogo de tipo de bien
  numSolicProg: string = ''; //Numero de solicitud para editar solicitud de programacion
  numSolicProgUnionFront: string = ''; //Numero de solicitud completo que se mostrara en el HTML
  solicitudProgramacion: SolicitudProgramacion = new SolicitudProgramacion(); //Declarar e inicializar objeto de solicitud de programacion
  usuarioSolicitud: UsuarioSolicitud = new UsuarioSolicitud(); //Declarar e inicializar objeto usuario de solicitud
  usuariosSolicitudes: UsuarioSolicitud[] = []; //Almacena lista de usuarios de solicitud
  establecimientosUsuarios: EstablecimientoUsuario[] = []; //Almacena lista de establecimientos de usuarios
  mediosProbatoriosUsuarios: MedioProbatorioUsuario[] = []; //Almacena lista de medios probatorios de usuarios
  criteriosCalificaciones: CriterioCalificacion[] = []; //Almacena lista de criterios de calificacines (Modulo de mantenimiento)
  alternativasCriterios: AlternativaCriterio[]; //Almacena lista de alternativas (Un criterio de calificacion puede tener varias alternativas) usuario
  alternativasCriteriosSel: AlternativaCriterio[]; //Almacena lista de alternativas seleccionadas
  accionesSugeridas: AccionSugeridaCalif[] = []; //Almacena lista de acciones sugeridas (Modulo de mantenimiento)
  establecimientosAnexos: WSEstablecimientoAnexo[] = []; //Almacena lista de establecimientos
  establecimientosAnexosSel: WSEstablecimientoAnexo[] = []; //Almacena lista de establecimientos seleccionadas
  departamentos: Ubigeo[] = []; //Almacena lista de departamentos de ubigeo
  provincias: Ubigeo[] = []; //Almacena lista de provincias de ubigeo
  distritos: Ubigeo[] = []; //Almacena lista de distritos de ubigeo
  objUsuarioEditar: Object = new Object(); //Usuario de lista seleccionado
  objUsuarioEstablecimientoSel: Object = new Object(); //Usuario de lista seleccionado
  catalogoInconsistencias: Catalogo[] = []; //Almacena lista de inconsistencias de catalogo (Inicial)
  catalogoTipoBienes: Catalogo[] = []; //Almacena lista de tipo de bienes de catalogo (Inicial)
  bienesFiscalizados: BienFiscalizadoSolicitud[] = []; //Almacena lista de bienes fiscalizados (Inicial)
  bienesFiscalizadosTemp: BienFiscalizadoSolicitud[] = []; //Almacena lista de bienes fiscalizados (Temporal)
  arrayCkbInconsistencias: Catalogo[] = []; //Almacena lista de inconsistencias marcadas
  arrayCkbTipoBienes: Catalogo[] = []; //Almacena lista de tipo de bienes marcadas
  arrayCkbBienesFiscalizados: BienFiscalizadoSolicitud[] = []; //Almacena lista de bienes fiscalizados marcadas
  listaPermitidosTipoAccion: string[] = []; //Lista de tipos de accion a mostrar
  agregarCkb: boolean = true; //Agregar checkbox (Evento change lista de checkbox)
  quitarCkb: boolean = false; //Quitar checkbox (Evento change lista de checkbox)
  estadoCkbInconsistencia: boolean = true; //Valida si campo textarea de otras inconsistencias debe habilitarse
  estadoCkbTipoBien: boolean = true; //Valida si campo textarea de otros tipos de bienes debe habilitarse
  estadoTouchedInconsistencia: boolean = false; //Valida si lista de checks de inconsistencias fue tocado (Mostrar mensaje en pantalla en rojo)
  estadoTouchedTipoBien: boolean = false; //Valida si lista de checks de tipo de bien fue tocado (Mostrar mensaje en pantalla en rojo)
  estadoTouchedBienFisca: boolean = false; //Valida si lista de checks de bienes fiscalizados fue tocado (Mostrar mensaje en pantalla en rojo)
  estadoTouchedListaCriterio: boolean = false; //Valida si lista de criterios fue tocado
  verMgsUsuario: boolean = false; //Ocultar mensaje de alerta registrar y editar usuario
  verMgsMedioProbatorio: boolean = false; //Ocultar mensaje de alerta registrar medio probatorio
  verMgsCalificarUsuario: boolean = false; //Ocultar mensaje de alerta registrar y editar calificar usuario
  verMgsEstablecimiento: boolean = false; //Ocultar mensaje de alerta registrar y editar establecimiento usuario
  verMgsUsuarioList: boolean = false; //Ocultar mensaje de alerta usuario lista
  verMgsEstablecimientoUsuarioList: boolean = false; //Ocultar mensaje de alerta establecimiento usuario lista
  verMgsEnviarSolicitud: boolean = false; //Ocultar mensaje de alerta enviar solicitud
  verEstablecimientosUsuario: boolean = false; //Ocultar seccion establecimientos de usuario
  verEstablecimientoRUC: boolean = false; //Ocultar seccion establecimiento RUC
  verEstablecimientoOTROS: boolean = false; //Ocultar seccion establecimiento OTROS
  verOpcionEstablecimientoRUC: boolean = true; //Ocultar opcion establecimiento RUC
  ocultarColumnasUsuario: boolean = false; //Ocultar columnas lista detalle de usuarios
  readonlyNombreRazonSocial = true; //Valida si campo de texto nombre de razon social debe habilitarse
  numUsuarioSolicitudEditar: number = 0; //Validar si es registar o editar usuario
  numCalificarUsuarioEditar: number = 0; //Validar si es registar o editar calificacion usuario
  numEstablecimientoEditar: number = 0; //Validar si es registar o editar establecimiento usuario
  esProgramador: boolean = false; //Validar si es programdor
  esFiscalizacion: boolean = false; //Validar si tipo intervencion es fiscalizacion
  textoCodTipoMedioProbatorio: string = '' //Almacena texto combo codTipoMedioProbatorio
  validTipDoc: any = {
    "requerido": false,
    "minLenght": 0,
    "maxLenght": Constantes.MAX_LENGHT_DOC_OTROS,
    "pattern": Constantes.VALOR_VACIO,
    "tipoDoc": Constantes.VALOR_VACIO,
    "tipoVal": Constantes.TIPO_VALI_ONLYNUMBERLETTER
  }; //Validar tipo de documento
  cus01Excp002: string = ''; //Validar mensaje excepcion
  cus01Excp012: string = ''; //Validar mensaje excepcion
  modalRef: NgbModalRef;
  formaUsuarioSolProg: FormGroup; //FormGroup para registrar y editar usuario de solicitud de programacion
  formaCalificacionSolProg: FormGroup; //FormGroup para calificar usuario
  formaEstablecimientoSolProg: FormGroup; //FormGroup para registrar y editar establecimiento de usuario
  urlDescargaArchivo: string; // URL de descarga de archivo

  @ViewChild('mdlUsuario', {static: true}) mdlUsuario: NgbActiveModal;
  @ViewChild('mdlCalificacion', {static: true}) mdlCalificacion: NgbActiveModal;
  @ViewChild('mdlEstablecimiento', {static: true}) mdlEstablecimiento: NgbActiveModal;
  //Fin declaracion

  constructor(private catalogoService: CatalogoService,
    private gestionSolicitudService: GestionSolicitudService,
    private ubigeoService: UbigeoService,
    private servicioWebService: ServicioWebService,
    private utilService: UtilService,
    private router: Router,
    private rutaActiva: ActivatedRoute,
    private modalService: NgbModal,
    private configModal: NgbModalConfig,
    private configTime: NgbTimepickerConfig) { 
      configModal.backdrop = 'static';
      configModal.keyboard = false;
      configTime.seconds = false;
      configTime.spinners = false;
    }

  ngOnInit() {
    this.limpiarcampos();
    this.acitvarMensaje(false, false, false, false, false);
    this.inicio();
  }

  //Inicio metodos componente
  inicio() {

    this.numSolicProg = trim(this.rutaActiva.snapshot.params.numSolicProg);

    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;
    this.catalogoTipoDocIdentif = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
    this.catalogoTipoDocReferencia = ConstantesCatalogo.COD_CATALOGO_TIPO_DOCUMENTO_REFERENCIAAC;
    this.catalogoTipoIntervencion = ConstantesCatalogo.COD_CATALOGO_TIPO_INTERVENCION;
    this.catalogoTipoAccionControl = ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL;
    this.catalogoTipoMedioProbatorio = ConstantesCatalogo.COD_CATALOGO_TIPODOC_TRANSACCION;
    this.catalogoTipoIncosistencias = ConstantesCatalogo.COD_CATALOGO_TIPO_INCONSISTENCIAS;
    this.catalogoTipoBien = ConstantesCatalogo.COD_CATALOGO_TIPO_BIEN;
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO;

    this.formaUsuarioSolProg = new FormGroup(
      {
        "codTipoDoc": new FormControl('', Validators.required),
        "numDocUsuario": new FormControl('', Validators.required),
        "nombreRazonSocial": new FormControl('', [Validators.required, Validators.maxLength(200)]),
        "codTipoDocOtroRef": new FormControl(''),
        "numDocUsuOtroRef": new FormControl('', Validators.maxLength(50)),
        "archivoDocUsuRef": new FormControl(''),
        "codTipoIntervencion": new FormControl('', Validators.required),
        "codTipoAccion": new FormControl('', Validators.required),
        "fechaSugeridaVisita": new FormControl(''),
        "horaSugeridaVisita": new FormControl(''),
        "otrosDesInconsistencia": new FormControl('', Validators.maxLength(500)),
        "otrosDesBien": new FormControl('', Validators.maxLength(500)),
        "codTipoMedioProbatorio": new FormControl(''),
        "numMedioProbatorio": new FormControl('', Validators.maxLength(50)),
        "archivoMedioProbatorio": new FormControl('')
      }
    );

    this.formaCalificacionSolProg = new FormGroup(
      {
        "solicitanteCal": new FormControl('', Validators.required),
        "desTipoIntervencionCal": new FormControl('', Validators.required),
        "desTipoAccionCal": new FormControl('', Validators.required),
        "desTipoDocumentoCal": new FormControl('', Validators.required),
        "numDocumentoCal": new FormControl('', Validators.required),
        "nombreRazonSocialCal": new FormControl('', Validators.required),
        "accionSugeridaCal": new FormControl(''),
        "calificacionPreliminar": new FormControl('', Validators.required),
        "sustentoCalificacionCal": new FormControl('', [Validators.maxLength(500)])
      }
    );

    this.formaEstablecimientoSolProg = new FormGroup(
      {
        "desTipoDocumentoEst": new FormControl('', Validators.required),
        "numDocumentoEst": new FormControl('', Validators.required),
        "nombreRazonSocialEst": new FormControl('', Validators.required),
        "direccionEstablecimientoEst": new FormControl(''),
        "departamentoEst": new FormControl(''),
        "provinciaEst": new FormControl(''),
        "distritoEst": new FormControl(''),
        "rdbDefaultEstablecimientoEst": new FormControl('')
      }
    );

    //Es programador
    this.esProgramador = true; //Temporal, debe validarse
    if(this.esProgramador){
      this.accionSugeridaCal.setValidators([Validators.required]);
      this.sustentoCalificacionCal.setValidators([Validators.required]);;
    }else{
      this.accionSugeridaCal.setValidators(null);
      this.sustentoCalificacionCal.setValidators(null);
    }

    this.eventoCodTipoDoc(); //Evento formControl => codTipoDoc
    this.eventoCodTipoDocOtroRef(); //Evento formControl => codTipoDocOtroRef
    this.eventoCodTipoIntervencion(); //Evento formControl => codTipoIntervencion
    this.eventoCodTipoMedioProbatorio(); //Evento formControl => codTipoMedioProbatorio
    this.eventoCodDepartamento(); //Evento formControl => codDepartamento
    this.eventoCodProvincia(); //Evento formControl => codProvincia
    this.eventoRdbDefaultEstablecimiento(); //Evento formControl => rdbDefaultEstablecimiento

    this.listarUsuarios(this.numSolicProg);
  }

  limpiarcampos() {
    this.usuariosSolicitudes = [];
    this.establecimientosUsuarios = [];
    this.listaPermitidosTipoAccion = [];
    this.mediosProbatoriosUsuarios = [];
    this.criteriosCalificaciones = [];
    this.alternativasCriterios = [];
    this.alternativasCriteriosSel = [];
    this.accionesSugeridas = [];
    this.establecimientosAnexos = [];
    this.establecimientosAnexosSel = [];
    this.verEstablecimientosUsuario = false;
    this.verMgsEnviarSolicitud = false;
    this.ocultarColumnasUsuario = false;

    this.validTipDoc = {
      "requerido": false,
      "minLenght": 0,
      "maxLenght": Constantes.MAX_LENGHT_DOC_OTROS,
      "pattern": Constantes.VALOR_VACIO,
      "tipoDoc": Constantes.VALOR_VACIO,
      "tipoVal": Constantes.TIPO_VALI_ONLYNUMBERLETTER
    };

    this.limpiarMensajeExcepcion();
    this.limpiarCatalogos();
    this.limpiarReadonly();
    this.limpiarTouched();
    this.limpiarVerEstablecimientoRucOtros();
  }

  limpiarMensajeExcepcion(){
    this.cus01Excp002 = Constantes.VALOR_VACIO;
    this.cus01Excp012 = Constantes.VALOR_VACIO;
  }

  limpiarCatalogos() {
    this.catalogoInconsistencias = [];
    this.catalogoTipoBienes = [];
    this.bienesFiscalizados = [];
    this.bienesFiscalizadosTemp = [];
    this.arrayCkbInconsistencias = [];
    this.arrayCkbTipoBienes = [];
    this.arrayCkbBienesFiscalizados = [];
  }

  limpiarReadonly(){
    this.estadoCkbInconsistencia = true;
    this.estadoCkbTipoBien = true;
  }

  limpiarTouched() {
    this.estadoTouchedInconsistencia = false;
    this.estadoTouchedTipoBien = false;
    this.estadoTouchedBienFisca = false;
  }

  limpiarMedioProbatorio() {
    this.codTipoMedioProbatorio.setValue('');
    this.numMedioProbatorio.setValue('');
    this.archivoMedioProbatorio.setValue('');
  }

  limpiarEstablecimiento(){
    this.establecimientosAnexos = [];
    this.establecimientosAnexosSel = [];
    this.departamentos = [];
    this.provincias = [];
    this.distritos = [];
    this.resetearFormGroupEstablecimientoSolProg();
    this.desTipoDocumentoEst.setValue('');
    this.numDocumentoEst.setValue('');
    this.nombreRazonSocialEst.setValue('');
    this.direccionEstablecimientoEst.setValue('');
    this.departamentoEst.setValue('');
    this.provinciaEst.setValue('');
    this.distritoEst.setValue('');
    this.verOpcionEstablecimientoRUC = true;
  }

  limpiarVerEstablecimientoRucOtros(){
    this.verEstablecimientoRUC = false;
    this.verEstablecimientoOTROS = false;
  }

  acitvarMensaje(a: boolean, b: boolean, c: boolean, d: boolean, e: boolean) {
    this.verMgsUsuario = a;
    this.verMgsMedioProbatorio = b;
    this.verMgsCalificarUsuario = c;
    this.verMgsEstablecimiento = c;
    this.verMgsUsuarioList = d;
    this.verMgsEstablecimientoUsuarioList = e;
    this.verMgsEnviarSolicitud = false;
  }

  resetearFormGroupUsuarioSolProg() {
    this.formaUsuarioSolProg.reset();
  }

  resetearFormGroupCalificacionSolProg() {
    this.formaCalificacionSolProg.reset();
  }

  resetearFormGroupEstablecimientoSolProg() {
    this.formaEstablecimientoSolProg.reset();
  }

  //Propiedades formControl
  /* Usuario */
  get codTipoDoc() { return this.formaUsuarioSolProg.get('codTipoDoc') as FormControl; }
  get numDocUsuario() { return this.formaUsuarioSolProg.get('numDocUsuario') as FormControl; }
  get nombreRazonSocial() { return this.formaUsuarioSolProg.get('nombreRazonSocial') as FormControl; }
  get codTipoDocOtroRef() { return this.formaUsuarioSolProg.get('codTipoDocOtroRef') as FormControl; }
  get numDocUsuOtroRef() { return this.formaUsuarioSolProg.get('numDocUsuOtroRef') as FormControl; }
  get archivoDocUsuRef() { return this.formaUsuarioSolProg.get('archivoDocUsuRef') as FormControl; }
  get codTipoIntervencion() { return this.formaUsuarioSolProg.get('codTipoIntervencion') as FormControl; }
  get codTipoAccion() { return this.formaUsuarioSolProg.get('codTipoAccion') as FormControl; }
  get fechaSugeridaVisita() { return this.formaUsuarioSolProg.get('fechaSugeridaVisita') as FormControl; }
  get horaSugeridaVisita() { return this.formaUsuarioSolProg.get('horaSugeridaVisita') as FormControl; }
  get codTipoMedioProbatorio() { return this.formaUsuarioSolProg.get('codTipoMedioProbatorio') as FormControl; }
  get numMedioProbatorio() { return this.formaUsuarioSolProg.get('numMedioProbatorio') as FormControl; }
  get archivoMedioProbatorio() { return this.formaUsuarioSolProg.get('archivoMedioProbatorio') as FormControl; }
  get otrosDesInconsistencia() { return this.formaUsuarioSolProg.get('otrosDesInconsistencia') as FormControl; }
  get otrosDesBien() { return this.formaUsuarioSolProg.get('otrosDesBien') as FormControl; }

  /* Calificacion */
  get solicitanteCal() { return this.formaCalificacionSolProg.get('solicitanteCal') as FormControl; }
  get desTipoIntervencionCal() { return this.formaCalificacionSolProg.get('desTipoIntervencionCal') as FormControl; }
  get desTipoAccionCal() { return this.formaCalificacionSolProg.get('desTipoAccionCal') as FormControl; }
  get desTipoDocumentoCal() { return this.formaCalificacionSolProg.get('desTipoDocumentoCal') as FormControl; }
  get numDocumentoCal() { return this.formaCalificacionSolProg.get('numDocumentoCal') as FormControl; }
  get nombreRazonSocialCal() { return this.formaCalificacionSolProg.get('nombreRazonSocialCal') as FormControl; }
  get accionSugeridaCal() { return this.formaCalificacionSolProg.get('accionSugeridaCal') as FormControl; }
  get calificacionPreliminar() { return this.formaCalificacionSolProg.get('calificacionPreliminar') as FormControl; }
  get sustentoCalificacionCal() { return this.formaCalificacionSolProg.get('sustentoCalificacionCal') as FormControl; }

  /* Establecimiento */
  get desTipoDocumentoEst() { return this.formaEstablecimientoSolProg.get('desTipoDocumentoEst') as FormControl; }
  get numDocumentoEst() { return this.formaEstablecimientoSolProg.get('numDocumentoEst') as FormControl; }
  get nombreRazonSocialEst() { return this.formaEstablecimientoSolProg.get('nombreRazonSocialEst') as FormControl; }
  get direccionEstablecimientoEst() { return this.formaEstablecimientoSolProg.get('direccionEstablecimientoEst') as FormControl; }
  get departamentoEst() { return this.formaEstablecimientoSolProg.get('departamentoEst') as FormControl; }
  get provinciaEst() { return this.formaEstablecimientoSolProg.get('provinciaEst') as FormControl; }
  get distritoEst() { return this.formaEstablecimientoSolProg.get('distritoEst') as FormControl; }
  get rdbDefaultEstablecimientoEst() { return this.formaEstablecimientoSolProg.get('rdbDefaultEstablecimientoEst') as FormControl; }

  //Eventos
  eventoInputValidacionNumDocumento(numDocumento: string){
    this.validarNumeroDocumento(numDocumento);
  }

  eventoCkbInconsistencias(valor: Catalogo, opcion: boolean) {
    if (opcion) {
      this.arrayCkbInconsistencias = this.arrayCkbInconsistencias.concat(valor); //Agregar
      if (valor.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS) this.otrosDesInconsistencia.setValidators([Validators.required, Validators.maxLength(500)]);
    } else {
      this.arrayCkbInconsistencias = this.arrayCkbInconsistencias.filter(s => s.codDataCatalogo !== valor.codDataCatalogo); //Quitar
      if (valor.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS) this.otrosDesInconsistencia.setValidators(null);
    }

    this.estadoTouchedCkbInconsistencia();

    if (valor.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS) {
      this.estadoCkbInconsistencia = !opcion;
      this.otrosDesInconsistencia.setValue('');
      this.otrosDesInconsistencia.updateValueAndValidity();
    }
  }

  eventoCkbTipoBien(valor: Catalogo, opcion: boolean) {
    if (opcion) {
      this.arrayCkbTipoBienes = this.arrayCkbTipoBienes.concat(valor); //Agregar
      if (valor.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS ||
        valor.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_DISOLVENTE ||
        valor.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_MEZCLA) {
        this.otrosDesBien.setValidators([Validators.required, Validators.maxLength(500)]);
        this.estadoCkbTipoBien = false;
        //this.otrosDesBien.setValue('');
        this.otrosDesBien.updateValueAndValidity();
      }
    } else {
      this.arrayCkbTipoBienes = this.arrayCkbTipoBienes.filter(s => s.codDataCatalogo !== valor.codDataCatalogo); //Quitar
      if (this.arrayCkbTipoBienes.filter(s => s.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS).length <= 0 &&
        this.arrayCkbTipoBienes.filter(s => s.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_DISOLVENTE).length <= 0 &&
        this.arrayCkbTipoBienes.filter(s => s.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_MEZCLA).length <= 0) {
        this.otrosDesBien.setValidators(null);
        this.estadoCkbTipoBien = true;
        this.otrosDesBien.setValue('');
        this.otrosDesBien.updateValueAndValidity();
      }
    }
    this.arrayCkbBienesFiscalizados = this.arrayCkbBienesFiscalizados.filter(T => T.codTipoBien != valor.codDataCatalogo);
    this.estadoTouchedCkb();
    this.listarBienesFiscalizados();
  }

  eventoCkbFiscalizados(valor: BienFiscalizadoSolicitud, opcion: boolean) {
    console.log(opcion);
    if (opcion) {
      this.arrayCkbBienesFiscalizados = this.arrayCkbBienesFiscalizados.concat(valor); //Agregar
    } else {
      this.arrayCkbBienesFiscalizados = this.arrayCkbBienesFiscalizados.filter(s => s.codBienFiscalizado !== valor.codBienFiscalizado); //Quitar
    }
    this.estadoTouchedCkb();
  }

  eventoRdbDefaultEstablecimiento(){
    this.rdbDefaultEstablecimientoEst.valueChanges.subscribe(valor => {
      valor = trim(valor);
      this.limpiarVerEstablecimientoRucOtros();
      this.establecimientosAnexosSel = [];
      
      if(valor == Constantes.ESTABLECIMIENTO_POR_RUC){
        this.verEstablecimientoRUC = true;
        this.direccionEstablecimientoEst.setValidators(null);
        this.departamentoEst.setValidators(null);
        this.provinciaEst.setValidators(null);
        this.distritoEst.setValidators(null);
      }else if(valor == Constantes.ESTABLECIMIENTO_POR_OTROS){
        this.verEstablecimientoOTROS = true;
        this.direccionEstablecimientoEst.setValidators(Validators.required);
        this.departamentoEst.setValidators(Validators.required);
        this.provinciaEst.setValidators(Validators.required);
        this.distritoEst.setValidators(Validators.required);
      }
  
      this.direccionEstablecimientoEst.updateValueAndValidity();
      this.departamentoEst.updateValueAndValidity();
      this.provinciaEst.updateValueAndValidity();
      this.distritoEst.updateValueAndValidity();
  
      this.direccionEstablecimientoEst.reset();
      this.departamentoEst.reset();
      this.provinciaEst.reset();
      this.distritoEst.reset();
  
      this.direccionEstablecimientoEst.setValue('');
      this.departamentoEst.setValue('');
      this.provinciaEst.setValue('');
      this.distritoEst.setValue('');
      
      if(this.establecimientosAnexos != null && this.establecimientosAnexos.length > 0){
        this.establecimientosAnexos.forEach(e => {
          e.seleccionado = false;
        });
      }
    });
  }

  eventoCkbEstablecimientoAll(event: any){
    if(this.establecimientosAnexos != null && this.establecimientosAnexos.length > 0){
      if(event.target.checked){
        this.establecimientosAnexos.forEach(e => {
          e.seleccionado = true;
        });
        this.establecimientosAnexosSel = this.establecimientosAnexos;
      }else{
        this.establecimientosAnexos.forEach(e => {
          e.seleccionado = false;
        });
        this.establecimientosAnexosSel = [];
      }
    }
  }

  eventoCkbEstablecimiento(event: any, wsEstablecimientoAnexo: WSEstablecimientoAnexo){
    this.establecimientosAnexosSel = this.establecimientosAnexosSel.filter(e => trim(e.numSprCorrel) != trim(wsEstablecimientoAnexo.numSprCorrel));

    if(event.target.checked){
      this.establecimientosAnexosSel = this.establecimientosAnexosSel.concat(wsEstablecimientoAnexo); 
    }
  }

  onChangeCodTipoMedioProbatorio(event: any) {
    let valor = trim(event.target.value);
    if (valor == Constantes.VALOR_VACIO) { this.textoCodTipoMedioProbatorio = ''; }
    else { this.textoCodTipoMedioProbatorio = trim(event.target.options[event.target.options.selectedIndex].text); }
  }

  getValidarTipoDocRUC(){
    /* Ini validar html */
    this.validTipDoc.requerido = true;
    this.validTipDoc.minLenght = Constantes.MAX_LENGHT_DOC_RUC;
    this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_RUC;
    this.validTipDoc.pattern = Constantes.VALIDA_PATTERN_SOLO_NUMERO;
    this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_RUC;
    this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    /* Fin validar html */
  }

  getValidarTipoDocDNI(){
    /* Ini validar html */
    this.validTipDoc.requerido = true;
    this.validTipDoc.minLenght = Constantes.MAX_LENGHT_DOC_DNI;
    this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_DNI;
    this.validTipDoc.pattern = Constantes.VALIDA_PATTERN_SOLO_NUMERO;
    this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_DNI;
    this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    /* Fin validar html */
  }

  getValidarTipoDocOtros(){
    /* Ini validar html */
    this.validTipDoc.requerido = false;
    this.validTipDoc.minLenght = 0;
    this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_OTROS;
    this.validTipDoc.pattern = Constantes.VALOR_VACIO;
    this.validTipDoc.tipoDoc = Constantes.VALOR_VACIO;
    this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBERLETTER;
    /* Fin validar html */
  }

  //Evento combos
  eventoCodTipoDoc() {
    this.codTipoDoc.valueChanges.subscribe(valor => {
      valor = trim(valor);
      this.cus01Excp002 = Constantes.VALOR_VACIO;
      this.cus01Excp012 = Constantes.VALOR_VACIO;

      if (valor == Constantes.TIPO_DOCUMENTO_RUC) {
        this.readonlyNombreRazonSocial = true;
        this.numDocUsuario.setValidators([Validators.required,
        Validators.minLength(11),
        Validators.maxLength(11),
        Validators.pattern(Constantes.VALIDA_PATTERN_SOLO_NUMERO)]);
        this.getValidarTipoDocRUC();
      } else if (valor == Constantes.TIPO_DOCUMENTO_DNI) {
        this.readonlyNombreRazonSocial = true;
        this.numDocUsuario.setValidators([Validators.required,
        Validators.minLength(8),
        Validators.maxLength(8),
        Validators.pattern(Constantes.VALIDA_PATTERN_SOLO_NUMERO)]);
        this.getValidarTipoDocDNI();
      } else if (valor == Constantes.TIPO_DOCUMENTO_PASAPORTE) {
        this.readonlyNombreRazonSocial = false;
        this.numDocUsuario.setValidators([Validators.required, Validators.minLength(8), Validators.maxLength(15)]);
        this.getValidarTipoDocOtros();
      } else if (valor == Constantes.TIPO_DOCUMENTO_CARNE_EXTRANJERIA) {
        this.readonlyNombreRazonSocial = false;
        this.numDocUsuario.setValidators([Validators.required, Validators.minLength(8), Validators.maxLength(15)]);
        this.getValidarTipoDocOtros();
      } else if (valor == Constantes.TIPO_DOCUMENTO_CEDULA_DIPLOMATICA) {
        this.readonlyNombreRazonSocial = false;
        this.numDocUsuario.setValidators([Validators.required, Validators.minLength(8), Validators.maxLength(15)]);
        this.getValidarTipoDocOtros();
      } else {
        this.readonlyNombreRazonSocial = true;
        this.numDocUsuario.setValidators(Validators.required);
        this.getValidarTipoDocOtros();
      }
      this.nombreRazonSocial.setValue('');
      this.numDocUsuario.setValue('');
      this.numDocUsuario.updateValueAndValidity();
    });
  }

  eventoCodTipoDocOtroRef() {
    this.codTipoDocOtroRef.valueChanges.subscribe(valor => {
      valor = trim(valor);
      if (valor != Constantes.VALOR_VACIO) {
        this.numDocUsuOtroRef.setValidators([Validators.required, Validators.maxLength(50)]);
        this.archivoDocUsuRef.setValidators(Validators.required);
      } else {
        this.numDocUsuOtroRef.setValidators(null);
        this.archivoDocUsuRef.setValidators(null);
      }
      this.numDocUsuOtroRef.setValue('');
      this.numDocUsuOtroRef.updateValueAndValidity();
      this.archivoDocUsuRef.updateValueAndValidity();
    });
  }

  eventoCodTipoIntervencion() {
    this.codTipoIntervencion.valueChanges.subscribe(valor => {
      valor = trim(valor);
      this.esFiscalizacion = false;

      if (valor == Constantes.TIPO_INTERVENCION_CONTROL) {
        this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_CARTA, Constantes.TIPO_ACCION_ESQUELA];
        this.fechaSugeridaVisita.setValidators(null);
        this.horaSugeridaVisita.setValidators(null);
      } else if (valor == Constantes.TIPO_INTERVENCION_FISCALIZACION) {
        this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_VISITA_PROGRAMADA, Constantes.TIPO_ACCION_VISITA_NO_PROGRAMADA];
        this.fechaSugeridaVisita.setValidators(Validators.required);
        this.horaSugeridaVisita.setValidators(Validators.required);
        this.esFiscalizacion = true;
      } else {
        this.listaPermitidosTipoAccion = [];
        this.fechaSugeridaVisita.setValidators(null);
        this.horaSugeridaVisita.setValidators(null);
      }
      this.fechaSugeridaVisita.setValue('');
      this.horaSugeridaVisita.setValue('');
      this.fechaSugeridaVisita.updateValueAndValidity();
      this.horaSugeridaVisita.updateValueAndValidity();
    });
  }

  eventoCodTipoMedioProbatorio() {
    this.codTipoMedioProbatorio.valueChanges.subscribe(valor => {
      valor = trim(valor);
      if (valor == Constantes.VALOR_VACIO) {
        this.numMedioProbatorio.setValue('');
        this.archivoMedioProbatorio.setValue('');
      }
    });
  }

  eventoCodDepartamento() {
    this.departamentoEst.valueChanges.subscribe(valor => {
      valor = trim(valor);
      this.provincias = [];
      this.distritos = [];
      if (valor != Constantes.VALOR_VACIO) {
        this.listarProvincias(valor);
        this.provinciaEst.setValue('');
        this.distritoEst.setValue('');
      }
    });
  }

  eventoCodProvincia() {
    this.provinciaEst.valueChanges.subscribe(valor => {
      valor = trim(valor);
      this.distritos = [];
      if (valor != Constantes.VALOR_VACIO) {
        this.listarDistritos(this.departamentoEst.value, valor);
        this.distritoEst.setValue('');
      }
    });
  }

  //Evento botones
  eventoBtnOcultarColumnasUsuario(){
    this.ocultarColumnasUsuario = !this.ocultarColumnasUsuario;
  }

  async eventoBtnAgregarUsuario() {
    this.numUsuarioSolicitudEditar = 0;
    this.mediosProbatoriosUsuarios = [];
    this.limpiarMensajeExcepcion();
    this.limpiarCatalogos();
    this.limpiarReadonly();
    this.limpiarTouched();
    this.resetearFormGroupUsuarioSolProg();

    this.objUsuarioEditar = {
      'codTipoDocumentoIdentif': Constantes.VALOR_VACIO,
      'numDocumentoIdentif': Constantes.VALOR_VACIO
    }

    this.modalRef = this.modalService.open(this.mdlUsuario, { size: 'xl' as 'lg' });
    await this.obtenerDatosSolicitud(this.numSolicProg, true);
  }

  eventoBtnAgregarMedioProbatorio() {
    this.agregarMedioProbatorio();
  }

  eventoBtnGuardarUsuario() {
    this.guardarUsuario();
  }
  
  eventoRdbUsuarioSeleccionar(usuarioSolicitud: UsuarioSolicitud) {
    this.verEstablecimientosUsuario = true;

    /* Ini limpiar establecimiento */
    this.numEstablecimientoEditar = 0;
    this.limpiarVerEstablecimientoRucOtros();
    this.limpiarEstablecimiento();
    /* Fin limpiar establecimiento */

    this.objUsuarioEstablecimientoSel = {
      'codTipoDocumentoIdentif': usuarioSolicitud.codTipoDocumentoIdentif,
      'numUsuarioSolicitudEditar': usuarioSolicitud.numUsuarioSolicitud,
      'desTipoDocumentoIdent': usuarioSolicitud.desTipoDocumentoIdent,
      'numDocumentoIdentif': usuarioSolicitud.numDocumentoIdentif,
      'nomApellidoUsuario': usuarioSolicitud.nomApellidoUsuario
    }
    this.listarEstablecimientosUsuarios(usuarioSolicitud.numSolicitud, usuarioSolicitud.numUsuarioSolicitud);
  }

  eventoBtnUsuarioDescargarArchivo(numSolicProg: number, numUsuarioSolicitud: number) {
    console.log('Descargar registro usuario ==> ');
  }

  eventoBtnUsuarioEliminar(numSolicProg: number, numUsuarioSolicitud: number) {
    this.eliminarUsuario(numSolicProg, numUsuarioSolicitud);
  }

  async eventoBtnUsuarioEditar(numSolicProg: number, numUsuarioSolicitud: number) {
    this.numUsuarioSolicitudEditar = numUsuarioSolicitud;
    this.mediosProbatoriosUsuarios = [];
    this.limpiarMensajeExcepcion();
    this.limpiarCatalogos();
    this.limpiarReadonly();
    this.limpiarTouched();
    this.resetearFormGroupUsuarioSolProg();
    this.modalRef = this.modalService.open(this.mdlUsuario, { size: 'xl' as 'lg' });
    await this.obtenerDatosSolicitud(this.numSolicProg, false);
    this.obtenerDatosUsuario(numSolicProg, numUsuarioSolicitud);
  }

  async eventoBtnUsuarioCalificar(numSolicProg: number, numUsuarioSolicitud: number) {
    this.numUsuarioSolicitudEditar = numUsuarioSolicitud;
    this.resetearFormGroupCalificacionSolProg();
    this.modalRef = this.modalService.open(this.mdlCalificacion, { size: 'lg' });
    await this.listarCriteriosCalificacion(); //Del modulo de mantenimiento
    await this.listarAccionesSugeridas(); //Del modulo de mantenimiento
    this.obtenerCalificacionUsuario(numSolicProg, numUsuarioSolicitud);
  }

  eventoBtnGuardarCalificacionUsuario(){
    this.guardarCalificacionUsuario();
  }

  eventoBtnAgregarEstablecimiento() {
    this.numEstablecimientoEditar = 0;
    this.limpiarVerEstablecimientoRucOtros();
    this.limpiarEstablecimiento();

    this.desTipoDocumentoEst.setValue(this.objUsuarioEstablecimientoSel['desTipoDocumentoIdent']);
    this.numDocumentoEst.setValue(this.objUsuarioEstablecimientoSel['numDocumentoIdentif']);
    this.nombreRazonSocialEst.setValue(this.objUsuarioEstablecimientoSel['nomApellidoUsuario']);

    this.modalRef = this.modalService.open(this.mdlEstablecimiento, { size: 'lg' });

    if(trim(this.objUsuarioEstablecimientoSel['codTipoDocumentoIdentif']) == Constantes.TIPO_DOCUMENTO_RUC){
      this.rdbDefaultEstablecimientoEst.setValue(Constantes.ESTABLECIMIENTO_POR_RUC);
      this.verEstablecimientoRUC = true;
      this.listarEstablecimientosAnexos(trim(this.objUsuarioEstablecimientoSel['numDocumentoIdentif']));
    }else{
      this.rdbDefaultEstablecimientoEst.setValue(Constantes.ESTABLECIMIENTO_POR_OTROS);
      this.verEstablecimientoOTROS = true;
    }

    this.listarDepartamentos();
  }

  eventoBtnEstablecimientoEliminar(numUsuarioSolicitud: number, numEstablecimientoUsuario: number) {
    this.eliminarEstablecimientoUsuario(numUsuarioSolicitud, numEstablecimientoUsuario);
  }

  async eventoBtnEstablecimientoEditar(numUsuarioSolicitud: number, numEstablecimientoUsuario: number) {
    this.numEstablecimientoEditar = numEstablecimientoUsuario;
    this.limpiarVerEstablecimientoRucOtros();
    this.limpiarEstablecimiento();

    this.desTipoDocumentoEst.setValue(this.objUsuarioEstablecimientoSel['desTipoDocumentoIdent']);
    this.numDocumentoEst.setValue(this.objUsuarioEstablecimientoSel['numDocumentoIdentif']);
    this.nombreRazonSocialEst.setValue(this.objUsuarioEstablecimientoSel['nomApellidoUsuario']);
    this.rdbDefaultEstablecimientoEst.setValue(Constantes.ESTABLECIMIENTO_POR_OTROS);
    this.verOpcionEstablecimientoRUC = false;
    this.verEstablecimientoOTROS = true;

    this.modalRef = this.modalService.open(this.mdlEstablecimiento, { size: 'lg' });
    await this.listarDepartamentos();
    this.obtenerEstablecimiento(numUsuarioSolicitud, numEstablecimientoUsuario);
  }

  eventoBtnGuardarEstablecimiento() {
    this.guardarEstablecimientoUsuario();
  }

  eventoBtnAnterior() {
    this.router.navigate(['/solicitudes/gestion-solicitudes-programacion/formulario', this.numSolicProg]);
  }

  eventoBtnEnviar() {
    this.enviarSolicitudProgramacion();
  }

  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }

  getErrorClassCkb(arrayList: any[], estadoTouched: boolean, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    if (tipo == Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
      return this.utilService.getErrorMensajeCkbFormControl(arrayList, estadoTouched);
    }
    return this.utilService.getErrorClassCkbFormControl(arrayList, estadoTouched, tipo);
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  listarBienesFiscalizados() {
    this.bienesFiscalizados = [];
    // this.arrayCkbBienesFiscalizados = [];
    let bienesFiscalizadosTemp: BienFiscalizadoSolicitud[] = [];

    if (this.arrayCkbTipoBienes.length != null && this.arrayCkbTipoBienes.length > 0) {

      this.arrayCkbTipoBienes.forEach(t => {
        if (t.codDataCatalogo != Constantes.OPCION_CODIGO_OTROS) {
          bienesFiscalizadosTemp = bienesFiscalizadosTemp.concat(this.bienesFiscalizadosTemp.filter(b => b.codTipoBien == t.codDataCatalogo));
        }
      });

      this.bienesFiscalizados = bienesFiscalizadosTemp;
      this.arrayCkbBienesFiscalizados = bienesFiscalizadosTemp.filter(b => b.seleccionado == true);
    }
  }

  /* Solicitud */

   async obtenerDatosSolicitud(numSolicProg: string, opcionAgregarEditar: boolean) {

     let result = await this.gestionSolicitudService.obtenerDatosSolicitud(numSolicProg).toPromise();

    if (result.exito) {
      this.solicitudProgramacion = result.data;

      //Si es agregar
      if(opcionAgregarEditar){
        this.solicitudProgramacion.inconsistencias.forEach(i => { i.seleccionado = true; });
        this.solicitudProgramacion.tipoBienes.forEach(t => { t.seleccionado = true; });
        this.solicitudProgramacion.bienesFiscalizados.forEach(b => { b.seleccionado = true; });
      }else{
        this.solicitudProgramacion.inconsistencias.forEach(i => { i.seleccionado = false; });
        this.solicitudProgramacion.tipoBienes.forEach(t => { t.seleccionado = false; });
        this.solicitudProgramacion.bienesFiscalizados.forEach(b => { b.seleccionado = false; });
      }

      this.catalogoInconsistencias = this.solicitudProgramacion.inconsistencias;
      this.catalogoTipoBienes = this.solicitudProgramacion.tipoBienes;
      this.bienesFiscalizados = this.solicitudProgramacion.bienesFiscalizados;
      this.bienesFiscalizadosTemp = this.solicitudProgramacion.bienesFiscalizados;

      //Si es agregar
      if(opcionAgregarEditar){
        this.otrosDesInconsistencia.setValue(this.solicitudProgramacion.desOtraInconsistencia);
        this.otrosDesBien.setValue(this.solicitudProgramacion.desOtraTipoBien);

        this.arrayCkbInconsistencias = this.solicitudProgramacion.inconsistencias;
        this.arrayCkbTipoBienes = this.solicitudProgramacion.tipoBienes;
        this.arrayCkbBienesFiscalizados = this.solicitudProgramacion.bienesFiscalizados;

        //Ckeck otros inconsistencias
        if (this.arrayCkbInconsistencias.filter(v => v.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS).length > 0) {
          this.otrosDesInconsistencia.setValidators([Validators.required, Validators.maxLength(500)]);
          this.estadoCkbInconsistencia = false;
        }else{
          this.otrosDesInconsistencia.setValidators(null);
        }
        this.otrosDesInconsistencia.updateValueAndValidity();

        //Ckeck otros tipo de bienes
        if (this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS).length > 0 ||
          this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_DISOLVENTE).length > 0 ||
          this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_MEZCLA).length > 0) {
          this.otrosDesBien.setValidators([Validators.required, Validators.maxLength(500)]);
          this.estadoCkbTipoBien = false;
        }else{
          this.otrosDesBien.setValidators(null);
        }
        this.otrosDesBien.updateValueAndValidity();
      }

    } else {
      console.log(result.mensaje);
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
    }
  }

  /* Usuario */

  listarUsuarios(numSolicProg: string) {
    this.verEstablecimientosUsuario = false;
    this.usuariosSolicitudes = [];

    this.gestionSolicitudService.obtenerDetalleSolicitud(numSolicProg).subscribe(
      result => {
        if (result.exito) {
          this.usuariosSolicitudes = result.data;
        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de usuarios => ${result.mensaje}`);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  obtenerDatosUsuario(numSolicProg: number, numUsuarioSolicitud: number) {
    this.acitvarMensaje(true, false, false, false, false);

    let usuarioSolicitudFilttro: UsuarioSolicitud = new UsuarioSolicitud();
    usuarioSolicitudFilttro.numSolicitud = numSolicProg;
    usuarioSolicitudFilttro.numUsuarioSolicitud = numUsuarioSolicitud;

    this.gestionSolicitudService.obtenerDatosUsuario(usuarioSolicitudFilttro).subscribe(
      result => {
        if (result.exito) {

          let usuarioSolicitud: UsuarioSolicitud = new UsuarioSolicitud();

          usuarioSolicitud = result.data;

          this.objUsuarioEditar = {
            'codTipoDocumentoIdentif': trim(usuarioSolicitud.codTipoDocumentoIdentif),
            'numDocumentoIdentif': trim(usuarioSolicitud.numDocumentoIdentif)
          }

          this.codTipoDoc.setValue(usuarioSolicitud.codTipoDocumentoIdentif);
          this.numDocUsuario.setValue(usuarioSolicitud.numDocumentoIdentif);
          this.nombreRazonSocial.setValue(usuarioSolicitud.nomApellidoUsuario);
          this.codTipoDocOtroRef.setValue(usuarioSolicitud.codTipoDocumentoReferencia);
          this.numDocUsuOtroRef.setValue(usuarioSolicitud.numDocumentoReferencia);
          this.archivoDocUsuRef.setValue(usuarioSolicitud.archivoBean); //Archivo
          this.codTipoIntervencion.setValue(usuarioSolicitud.codTipoIntervencion);
          this.fechaSugeridaVisita.setValue(usuarioSolicitud.fecSugeridaVisita);
          this.horaSugeridaVisita.setValue(formatHoraFront(usuarioSolicitud.horSugeVisit));
          this.otrosDesInconsistencia.setValue(usuarioSolicitud.desOtraInconsistencia);
          this.otrosDesBien.setValue(usuarioSolicitud.desOtraTipoBien);

          this.mediosProbatoriosUsuarios = usuarioSolicitud.mediosProbatorios;
          this.arrayCkbInconsistencias = usuarioSolicitud.inconsistencias;
          this.arrayCkbTipoBienes = usuarioSolicitud.tipoBienes;
          this.arrayCkbBienesFiscalizados = usuarioSolicitud.bienesFiscalizados;

          //Ckeck inconsistencias
          if(this.arrayCkbInconsistencias != null && this.arrayCkbInconsistencias.length > 0){
            this.catalogoInconsistencias.forEach(i => {
              i.seleccionado = this.buscarInconsistencias(i.codDataCatalogo);
            });

            if (this.arrayCkbInconsistencias.filter(v => v.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS).length > 0) {
              this.otrosDesInconsistencia.setValidators([Validators.required, Validators.maxLength(500)]);
              this.estadoCkbInconsistencia = false;
            }else{
              this.otrosDesInconsistencia.setValidators(null);
            }
            this.otrosDesInconsistencia.updateValueAndValidity();
          }

          //Ckeck tipo de bienes
          if(this.arrayCkbTipoBienes != null && this.arrayCkbTipoBienes.length > 0){
            this.catalogoTipoBienes.forEach(t => {
              t.seleccionado = this.buscarTipoBienes(t.codDataCatalogo);
            });

            if (this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS).length > 0 ||
              this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_DISOLVENTE).length > 0 ||
              this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_MEZCLA).length > 0) {
              this.otrosDesBien.setValidators([Validators.required, Validators.maxLength(500)]);
              this.estadoCkbTipoBien = false;
            }else{
              this.otrosDesBien.setValidators(null);
            }
            this.otrosDesBien.updateValueAndValidity();
          }

          //Ckeck bienes fiscalizados
          if(this.arrayCkbBienesFiscalizados != null && this.arrayCkbBienesFiscalizados.length > 0){
            this.bienesFiscalizados.forEach(b => {
              b.seleccionado = this.buscarBienesFiscalizados(b.codBienFiscalizado);
            });
          }

          //Se realizo ya el combo tipo de accion depende del combo tipo intervencion.
          //Por tiempo no se seleccionaba.
          setTimeout(() => {
            this.codTipoAccion.setValue(usuarioSolicitud.codTipoAccion);
          }, Constantes.ALERT_TIEMPO_1000);

        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de usuario => ${result.mensaje}`);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  guardarUsuario() {
    let existeInsumoBF = false;
    let existeCombustibleBF = false;
    this.acitvarMensaje(true, false, false, false, false);
    this.estadoTouchedCkbInconsistencia();
    this.estadoTouchedCkb();
    this.validacionMedioProbatorio(false);
    this.limpiarMedioProbatorio();

    if (this.formaUsuarioSolProg.valid) {

      if (this.arrayCkbInconsistencias.length <= 0 || this.arrayCkbTipoBienes.length <= 0) {
        this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_014, Constantes.MODAL_DANGER);
        return false;
      }

      this.arrayCkbTipoBienes.forEach(d => {
        if (d.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_INSUMO) {
          existeInsumoBF = true;
        } else if (d.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_COMBUSTIBLE) {
          existeCombustibleBF = true;
        }
      });

      if (existeInsumoBF) {
        if (this.arrayCkbBienesFiscalizados.filter(d => d.codTipoBien == Constantes.OPCION_TIPO_BIEN_INSUMO).length <= 0) {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_017, Constantes.MODAL_DANGER);
          return false;
        }
      }

      if (existeCombustibleBF) {
        if (this.arrayCkbBienesFiscalizados.filter(d => d.codTipoBien == Constantes.OPCION_TIPO_BIEN_COMBUSTIBLE).length <= 0) {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_018, Constantes.MODAL_DANGER);
          return false;
        }
      }

      if(this.numUsuarioSolicitudEditar == 0){
        if (this.usuariosSolicitudes.length > 0) {
          if (this.usuariosSolicitudes.filter(u => trim(u.codTipoDocumentoIdentif) == trim(this.codTipoDoc.value)
            && trim(u.numDocumentoIdentif) == trim(this.numDocUsuario.value)).length > 0) {
            this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_019, Constantes.MODAL_DANGER);
            return false;
          }
        }
      }else{
        if (this.usuariosSolicitudes.length > 0) {

          if(trim(this.objUsuarioEditar['codTipoDocumentoIdentif']) != trim(this.codTipoDoc.value) ||
          trim(this.objUsuarioEditar['numDocumentoIdentif']) != trim(this.numDocUsuario.value)){
            
            if (this.usuariosSolicitudes.filter(u => trim(u.codTipoDocumentoIdentif) == trim(this.codTipoDoc.value)
            && trim(u.numDocumentoIdentif) == trim(this.numDocUsuario.value)).length > 0) {            
              this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_019, Constantes.MODAL_DANGER);
              return false;
            }

          }
        }
      }

      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE_AGREGAR_USUARIO,Constantes.MODAL_PRIMARY, () => {
        let usuarioSolicitud: UsuarioSolicitud = new UsuarioSolicitud();

        usuarioSolicitud.numSolicitud = toNumber(this.numSolicProg);
        usuarioSolicitud.numUsuarioSolicitud = this.numUsuarioSolicitudEditar == 0 ? 0 : this.numUsuarioSolicitudEditar;
        usuarioSolicitud.codTipoDocumentoIdentif = trim(this.codTipoDoc.value);
        usuarioSolicitud.numDocumentoIdentif = trim(this.numDocUsuario.value);
        usuarioSolicitud.nomApellidoUsuario = trim(this.nombreRazonSocial.value);
        usuarioSolicitud.codTipoDocumentoReferencia = trim(this.codTipoDocOtroRef.value);
        usuarioSolicitud.numDocumentoReferencia = trim(this.numDocUsuOtroRef.value);
        usuarioSolicitud.archivoBean = this.archivoDocUsuRef.value;
        usuarioSolicitud.codTipoIntervencion = trim(this.codTipoIntervencion.value);
        usuarioSolicitud.codTipoAccion = trim(this.codTipoAccion.value);
        usuarioSolicitud.fecSugeridaVisita = trim(this.fechaSugeridaVisita.value);
        usuarioSolicitud.horSugeVisit = formatHoraBack(this.horaSugeridaVisita.value);
        usuarioSolicitud.desOtraInconsistencia = trim(this.otrosDesInconsistencia.value);
        usuarioSolicitud.desOtraTipoBien = trim(this.otrosDesBien.value);

        usuarioSolicitud.mediosProbatorios = this.mediosProbatoriosUsuarios;
        usuarioSolicitud.inconsistencias = this.arrayCkbInconsistencias;
        usuarioSolicitud.tipoBienes = this.arrayCkbTipoBienes;
        usuarioSolicitud.bienesFiscalizados = this.arrayCkbBienesFiscalizados;

        this.gestionSolicitudService.guardarUsuario(usuarioSolicitud).subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
              this.cerrarModal();
              this.listarUsuarios(result.data.numSolicitud);
            } else {
              if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS}`, Constantes.MODAL_DANGER);
              }else{
                this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
              }
            }
          },
          error => {
            console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS, Constantes.MODAL_DANGER);
          }
        );
      });

    } else {
      this.formaUsuarioSolProg.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_005, Constantes.MODAL_DANGER);
    }
  }

  eliminarUsuario(numSolicProg: number, numUsuarioSolicitud: number) {
    this.acitvarMensaje(false, false, false, true, false);
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE_ELIMINAR, Constantes.MODAL_PRIMARY, () => {

      let usuarioSolicitudFiltro: UsuarioSolicitud = new UsuarioSolicitud();
      usuarioSolicitudFiltro.numSolicitud = numSolicProg;
      usuarioSolicitudFiltro.numUsuarioSolicitud = numUsuarioSolicitud;

      this.gestionSolicitudService.eliminarUsuario(usuarioSolicitudFiltro).subscribe(
        result => {
          if (result.exito) {
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_ELIMINAR, Constantes.MODAL_SUCCESS);
            this.listarUsuarios(trim(numSolicProg));
          } else {
            if(trim(result.mensaje) == Constantes.VALOR_VACIO){
              this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_ELIMINADOS}`, Constantes.MODAL_DANGER);
            }else{
              this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
            }
          }
        },
        error => {
          console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_ELIMINADOS, Constantes.MODAL_DANGER);
        }
      );

    }, () => {
      this.acitvarMensaje(false, false, false, false, false);
    });
  }

  agregarMedioProbatorio() {
    this.acitvarMensaje(false, true, false, false, false);
    this.validacionMedioProbatorio(true);

    if (trim(this.codTipoMedioProbatorio.value) != Constantes.VALOR_VACIO &&
      trim(this.numMedioProbatorio.value) != Constantes.VALOR_VACIO &&
      trim(this.archivoMedioProbatorio.value) != Constantes.VALOR_VACIO) {

      if (this.mediosProbatoriosUsuarios.filter(m => m.codTipoMedioProbatorio == trim(this.codTipoMedioProbatorio.value) &&
        m.numMedioProbatorio == trim(this.numMedioProbatorio.value)).length > 0) {
        this.utilService.alertaMensaje('Ya existe medio probatorio', Constantes.MODAL_PRIMARY);
        return false;
      }

      let medioProbatorio: MedioProbatorioUsuario = new MedioProbatorioUsuario();

      medioProbatorio.codTipoMedioProbatorio = trim(this.codTipoMedioProbatorio.value);
      medioProbatorio.desMedioProbatorio = trim(this.textoCodTipoMedioProbatorio);
      medioProbatorio.numMedioProbatorio = trim(this.numMedioProbatorio.value);
      medioProbatorio.archivoBean = this.archivoMedioProbatorio.value; //Archivo

      this.mediosProbatoriosUsuarios = this.mediosProbatoriosUsuarios.concat(medioProbatorio);

      this.acitvarMensaje(false, false, false, false, false);
      this.validacionMedioProbatorio(false);
      // this.codTipoMedioProbatorio.setValue('');
      this.numMedioProbatorio.setValue('');
      this.archivoMedioProbatorio.setValue(null);
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_011, Constantes.MODAL_DANGER);
    }
  }

  eliminarMedioProbatorio(medio: MedioProbatorioUsuario) {
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE_ELIMINAR,Constantes.MODAL_PRIMARY, () => {

      let mediosProbatoriosUsuarios: MedioProbatorioUsuario[] = [];

      this.mediosProbatoriosUsuarios.filter(m => {
        if (!(m.codTipoMedioProbatorio == medio.codTipoMedioProbatorio && m.numMedioProbatorio == medio.numMedioProbatorio)) {
          mediosProbatoriosUsuarios = mediosProbatoriosUsuarios.concat(m);
        }
      });

      this.mediosProbatoriosUsuarios = mediosProbatoriosUsuarios;
    });
  }

  descargarMedioProbatorio(medio: MedioProbatorioUsuario) {
    console.log(medio);
  }

  /* Calificacion usuario */

  //Criterios de calificacion del modulo de mantenimiento
  async listarCriteriosCalificacion(){
    this.criteriosCalificaciones = [];

    let result = await this.gestionSolicitudService.listarCriteriosCalificacion().toPromise();

    if (result.exito) {
      this.criteriosCalificaciones = result.data;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de criterios de calificacion => ${result.mensaje}`);
    }
  }

  async listarAccionesSugeridas(){
    this.accionesSugeridas = [];

    let result = await this.gestionSolicitudService.listarAccionesSugeridas("1").toPromise();

    if (result.exito) {
      this.accionesSugeridas = result.data;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de acciones sugeridas => ${result.mensaje}`);
    }
  }

  obtenerCalificacionUsuario(numSolicProg: number, numUsuarioSolicitud: number){
    this.estadoTouchedListaCriterio = false;
    this.alternativasCriterios = [];

    this.gestionSolicitudService.obtenerDatosCalificacionUsuario(numUsuarioSolicitud).subscribe(
      result => {
        if (result.exito) {

          let criterioCalificacion: CalificacionUsuario = new CalificacionUsuario();

          criterioCalificacion = result.data;

          this.numCalificarUsuarioEditar = isEmpty(criterioCalificacion.numUsuarioCalifiicacion) ? 0 : criterioCalificacion.numUsuarioCalifiicacion; //Id de la calificacion
          this.numSolicProgUnionFront = `Nro. Solicitud: ${criterioCalificacion.numSolicitudUnion}`;
          this.solicitanteCal.setValue(criterioCalificacion.nomSolicitante);
          this.desTipoIntervencionCal.setValue(criterioCalificacion.desTipoIntervencion);
          this.desTipoAccionCal.setValue(criterioCalificacion.desTipoAccionControl);
          this.desTipoDocumentoCal.setValue(criterioCalificacion.desTipoDocumentoIdent);
          this.numDocumentoCal.setValue(criterioCalificacion.numDocumentoIdentif);
          this.nombreRazonSocialCal.setValue(criterioCalificacion.nomApellidoUsuario);
          this.calificacionPreliminar.setValue(criterioCalificacion.valCalificacion);
          this.accionSugeridaCal.setValue(isEmpty(criterioCalificacion.numAccionSugerida) ? '' : criterioCalificacion.numAccionSugerida);
          this.sustentoCalificacionCal.setValue(trim(criterioCalificacion.desSusAccsuge));

          this.alternativasCriterios = criterioCalificacion.alternativasCriterios;
          this.alternativasCriteriosSel = criterioCalificacion.alternativasCriterios;

          //Si es editar
          if(isNotEmpty(criterioCalificacion.numUsuarioCalifiicacion)){
            if(criterioCalificacion.numUsuarioCalifiicacion > 0){
              //Procesar seleccion de combos
              if(this.criteriosCalificaciones != null && this.criteriosCalificaciones.length > 0){
                this.criteriosCalificaciones.forEach(c => {
                  if(c.alternativasCriterios != null && c.alternativasCriterios.length > 0){
                    c.alternativasCriterios.forEach(a => {
                      a.seleccionado = this.buscarAlternativas(a.numCriterio, a.numAlternativa);
                    });
                  }
                });
              }

              //Calcular total Calificación Preliminar
              this.calificacionPreliminar.setValue(this.calcularCalificacionPreliminar() / Number(100));
            }
          }

        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de calificacion de usuario => ${result.mensaje}`);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  agregarAlternativaSeleccionada(event: any, index: number, numCriterio: string, alternativas: AlternativaCriterio[]){
    this.estadoTouchedListaCriterio = true;
    let valor = trim(event.target.value);
    
    this.alternativasCriteriosSel = this.alternativasCriteriosSel.filter(c => trim(c.numCriterio) != trim(numCriterio)); //Eliminar registros de array por numCriterio
    this.alternativasCriteriosSel = this.alternativasCriteriosSel.concat(alternativas.filter(c => trim(c.numAlternativa) == valor)); //Agregar objeto seleccionado a la lista

    //Calcular total Calificación Preliminar
    this.calificacionPreliminar.setValue(this.calcularCalificacionPreliminar() / Number(100));
  }

  guardarCalificacionUsuario(){
    this.estadoTouchedListaCriterio = true;
    this.acitvarMensaje(false, false, true, false, false);

    if(this.formaCalificacionSolProg.valid){

      if(this.criteriosCalificaciones != null && this.alternativasCriteriosSel != null){

        if(this.criteriosCalificaciones.length <= 0){
          this.utilService.alertaMensaje('Verificar que existan criterios de calificaci\u00f3n', Constantes.MODAL_DANGER);
          return false;
        }
  
        if(this.alternativasCriteriosSel.length <= 0){
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_007, Constantes.MODAL_DANGER);
          return false;
        }
  
        if(this.criteriosCalificaciones.length != this.alternativasCriteriosSel.length){
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_007, Constantes.MODAL_DANGER);
          return false;
        }

        this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE,Constantes.MODAL_PRIMARY, () => {

          let criterioCalificacion: CalificacionUsuario = new CalificacionUsuario();

          criterioCalificacion.numUsuarioSolicitud = this.numUsuarioSolicitudEditar; //Id usuario
          criterioCalificacion.numUsuarioCalifiicacion = this.numCalificarUsuarioEditar == 0 ? 0 : this.numCalificarUsuarioEditar; //Id de la calificacion
          
          criterioCalificacion.valCalificacion = this.calificacionPreliminar.value;
          criterioCalificacion.numAccionSugerida = this.accionSugeridaCal.value; 
          criterioCalificacion.desSusAccsuge = trim(this.sustentoCalificacionCal.value);

          criterioCalificacion.alternativasCriterios = this.alternativasCriteriosSel;

          this.gestionSolicitudService.guardarCalificacionPreliminar(criterioCalificacion).subscribe(
            result => {
              if (result.exito) {
                this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
                this.cerrarModal();
                this.listarUsuarios(this.numSolicProg);
              } else {
                if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                  this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS}`, Constantes.MODAL_DANGER);
                }else{
                  this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
                }
              }
            },
            error => {
              console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS, Constantes.MODAL_DANGER);
            }
          );
          
        });
        
      }else{
        this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
      }
    } else {
      this.formaCalificacionSolProg.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }
  }

  listarEstablecimientosUsuarios(numSolicProg: number, numUsuarioSolicitud: number) {
    this.establecimientosUsuarios = [];

    let usuarioSolicitudFiltro: UsuarioSolicitud = new UsuarioSolicitud();
    usuarioSolicitudFiltro.numSolicitud = numSolicProg; //Id usuario
    usuarioSolicitudFiltro.numUsuarioSolicitud = numUsuarioSolicitud;

    this.gestionSolicitudService.listarEstablecimientosUsuario(usuarioSolicitudFiltro).subscribe(
      result => {
        if (result.exito) {
          this.establecimientosUsuarios = result.data;
        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de establecimientos de usuario => ${result.mensaje}`);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  async listarEstablecimientosAnexos(numDocumento: string){
    this.establecimientosAnexos = [];
    
    // numDocumento = '20100066603'; //Comenetar, solo es para pruebas
    let result = await this.servicioWebService.listarEstablecimientosAnexos(numDocumento).toPromise();

    if (result.exito) {
      this.establecimientosAnexos = result.data;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de establecimientos anexos => ${result.mensaje}`);
    }
  }

  async listarDepartamentos(){
    this.departamentos = [];

    let result = await this.ubigeoService.listarDepartamentos().toPromise();

    if (result.exito) {
      this.departamentos = result.data;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de departamentos => ${result.mensaje}`);
    }
  }

  async listarProvincias(codUbigeoDep: string){
    this.provincias = [];

    let result = await this.ubigeoService.listarProvincias(trim(codUbigeoDep)).toPromise();

    if (result.exito) {
      this.provincias = result.data;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de provincias => ${result.mensaje}`);
    }
  }

  async listarDistritos(codUbigeoDep: string, codUbigeoProv: string){
    this.distritos = [];

    let result = await this.ubigeoService.listarDistritos(trim(codUbigeoDep), trim(codUbigeoProv)).toPromise();

    if (result.exito) {
      this.distritos = result.data;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de distritos => ${result.mensaje}`);
    }
  }

  obtenerEstablecimiento(numUsuarioSolicitud: number, numEstablecimientoUsuario: number){
    let establecimientoUsuarioFiltrol: EstablecimientoUsuario = new EstablecimientoUsuario();
    establecimientoUsuarioFiltrol.numUsuarioSolicitud = numUsuarioSolicitud; //Id usuario
    establecimientoUsuarioFiltrol.numEstablecimientoUsuario = numEstablecimientoUsuario;

    this.gestionSolicitudService.obtenerDatosEstablecimientoUsuario(establecimientoUsuarioFiltrol).subscribe(
      result => {
        if (result.exito) {

          let establecimientoUsuario: EstablecimientoUsuario = new EstablecimientoUsuario();

          establecimientoUsuario = result.data;
          
          this.numEstablecimientoEditar = establecimientoUsuario.numEstablecimientoUsuario; //Id de establecimiento;
          this.numEstablecimientoEditar = establecimientoUsuario.numEstablecimientoUsuario;
          this.direccionEstablecimientoEst.setValue(establecimientoUsuario.desDireccionEstablecimiento);
          this.departamentoEst.setValue(establecimientoUsuario.codDepartamento);
          this.provinciaEst.setValue(establecimientoUsuario.codProvincia);
          this.distritoEst.setValue(establecimientoUsuario.codDistrito);

        } else {
          console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de datos de establecimiento de usuario => ${result.mensaje}`);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
      }
    );
  }

  guardarEstablecimientoUsuario(){
    this.acitvarMensaje(false, false, true, false, false);

    if(!this.verEstablecimientoRUC &&  !this.verEstablecimientoOTROS){
      this.utilService.alertaMensaje('Seleccionar tipo establecimiento', Constantes.MODAL_DANGER);
      return false;
    }

    if(this.formaEstablecimientoSolProg.valid){

      if(this.verEstablecimientoRUC){
        if(this.establecimientosAnexosSel != null && this.establecimientosAnexosSel.length <= 0){
          this.utilService.alertaMensaje('Debe seleccionar almenos un establecimiento de la lista', Constantes.MODAL_DANGER);
          return false;
        }
      }

      // Validar si direccin existe
      // if(this.numEstablecimientoEditar == 0){
      //   if(this.verEstablecimientoOTROS){
      //     if(this.establecimientosUsuarios.filter(e => trim(e.desDireccionEstablecimiento) == trim(this.direccionEstablecimientoEst.value) 
      //     && trim(e.codDepartamento) == trim(this.departamentoEst.value)
      //     && trim(e.codProvincia) == trim(this.provinciaEst.value)
      //     && trim(e.codDistrito) == trim(this.distritoEst.value)).length > 0){
      //       this.utilService.alertaMensaje('Dirección ya existe en la lista detalle', Constantes.MODAL_DANGER);
      //       return false;
      //     }
      //   }
      // }

      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE_GUARDAR_ESTABLECIMIENTO,Constantes.MODAL_PRIMARY, () => {

        let usuarioSolicitud: UsuarioSolicitud = new UsuarioSolicitud();
        let establecimientosUsuarios: EstablecimientoUsuario[] = [];
        let numEstablecimientoEditar: number = this.numEstablecimientoEditar == 0 ? 0 : this.numEstablecimientoEditar; //Id de establecimiento
        let numUsuarioSolicitudEditar: number = this.objUsuarioEstablecimientoSel['numUsuarioSolicitudEditar']; //Id usuario seleccionado

        usuarioSolicitud.numSolicitud = toNumber(this.numSolicProg);
        usuarioSolicitud.numUsuarioSolicitud = numUsuarioSolicitudEditar; //Id usuario

        if(this.verEstablecimientoRUC){

          this.establecimientosAnexosSel.forEach(e => {
            let establecimientoUsuarioRUC: EstablecimientoUsuario = new EstablecimientoUsuario();
          
            establecimientoUsuarioRUC.indOtroEstab = Constantes.ESTABLECIMIENTO_POR_RUC;

            establecimientoUsuarioRUC.numEstablecimientoUsuario = numEstablecimientoEditar; //Id de establecimiento;
            establecimientoUsuarioRUC.numUsuarioPrograma = 0; //Por definir

            establecimientoUsuarioRUC.numEstablecimiento = toNumber(trim(e.numSprCorrel)); //Id establecimiento de anexo
            establecimientoUsuarioRUC.desDireccionEstablecimiento = trim(e.direccion);
            establecimientoUsuarioRUC.codDepartamento = trim(e.codDepar);
            establecimientoUsuarioRUC.codProvincia = trim(e.codProvi);
            establecimientoUsuarioRUC.codDistrito = formatUbigeo(trim(e.codUbigeo), Constantes.UBIGEO_DISTRITO); //Porque sw no devuele codigo distrito

            establecimientosUsuarios = establecimientosUsuarios.concat(establecimientoUsuarioRUC); 
          });

          usuarioSolicitud.establecimientos = establecimientosUsuarios;
        }else if(this.verEstablecimientoOTROS){
          let establecimientoUsuarioOtro: EstablecimientoUsuario = new EstablecimientoUsuario();

          establecimientoUsuarioOtro.indOtroEstab = Constantes.ESTABLECIMIENTO_POR_OTROS;
        
          establecimientoUsuarioOtro.numEstablecimientoUsuario = numEstablecimientoEditar; //Id de establecimiento;
          establecimientoUsuarioOtro.numUsuarioPrograma = 0; //Por definir

          establecimientoUsuarioOtro.numEstablecimiento = 0; //Id establecimiento de anexo
          establecimientoUsuarioOtro.desDireccionEstablecimiento = trim(this.direccionEstablecimientoEst.value);
          establecimientoUsuarioOtro.codDepartamento = trim(this.departamentoEst.value); 
          establecimientoUsuarioOtro.codProvincia = trim(this.provinciaEst.value);
          establecimientoUsuarioOtro.codDistrito = trim(this.distritoEst.value);

          establecimientosUsuarios = establecimientosUsuarios.concat(establecimientoUsuarioOtro);

          usuarioSolicitud.establecimientos = establecimientosUsuarios;
        }

        this.gestionSolicitudService.guardarEstablecimiento(usuarioSolicitud).subscribe(
          result => {
            if (result.exito) {
              this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
              this.cerrarModal();
              this.listarEstablecimientosUsuarios(toNumber(this.numSolicProg), numUsuarioSolicitudEditar);
            } else {
              if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS}`, Constantes.MODAL_DANGER);
              }else{
                this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
              }
            }
          },
          error => {
            console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS, Constantes.MODAL_DANGER);
          }
        );
        
      });
    } else {
      this.formaEstablecimientoSolProg.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_006, Constantes.MODAL_DANGER);
    }
  }

  eliminarEstablecimientoUsuario(numUsuarioSolicitud: number, numEstablecimientoUsuario: number) {
    this.acitvarMensaje(false, false, false, false, true);
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE_ELIMINAR, Constantes.MODAL_PRIMARY, () => {

      let establecimientoUsuarioFiltro: EstablecimientoUsuario = new EstablecimientoUsuario();
      establecimientoUsuarioFiltro.numUsuarioSolicitud = numUsuarioSolicitud; //Id usuario
      establecimientoUsuarioFiltro.numEstablecimientoUsuario = numEstablecimientoUsuario;

      this.gestionSolicitudService.eliminarEstablecimientoUsuario(establecimientoUsuarioFiltro).subscribe(
        result => {
          if (result.exito) {
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_ELIMINAR, Constantes.MODAL_SUCCESS);
            this.listarEstablecimientosUsuarios(toNumber(this.numSolicProg), numUsuarioSolicitud);
          } else {
            if(trim(result.mensaje) == Constantes.VALOR_VACIO){
              this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_ELIMINADOS}`, Constantes.MODAL_DANGER);
            }else{
              this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
            }
          }
        },
        error => {
          console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_ELIMINADOS, Constantes.MODAL_DANGER);
        }
      );

    }, () => {
      this.acitvarMensaje(false, false, false, false, false);
    });
  }

  enviarSolicitudProgramacion() {
    this.acitvarMensaje(false, false, false, false, false)
    this.verMgsEnviarSolicitud = true;

    if(this.usuariosSolicitudes != null && this.usuariosSolicitudes.length <= 0){
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_004, Constantes.MODAL_DANGER);
      return false;
    }

    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE_ENVIAR_SOLICITUD, Constantes.MODAL_PRIMARY, () => {

      let usuarioSolicitud: UsuarioSolicitud = new UsuarioSolicitud();
      usuarioSolicitud.numSolicitud = toNumber(this.numSolicProg);

      this.gestionSolicitudService.enviarDetalleSolicitudProgram(usuarioSolicitud).subscribe(
        result => {
          if (result.exito) {
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_ENVIAR, Constantes.MODAL_SUCCESS);

            setTimeout(() => {
              this.verMgsEnviarSolicitud = false;
              this.router.navigate(['/solicitudes/gestion-solicitudes-programacion']);
            }, Constantes.ALERT_TIEMPO_2000);
          } else {
            if(trim(result.mensaje) == Constantes.VALOR_VACIO){
              this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_ENVIADOS}`, Constantes.MODAL_DANGER);
            }else{
              this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
            }
          }
        },
        error => {
          console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_ENVIADOS, Constantes.MODAL_DANGER);
        }
      );

    }, () => {
      this.verMgsEnviarSolicitud = false;
    });
  }

  validarNumeroDocumento(numDocumento: string){
    let tipoDocumento: string = trim(this.codTipoDoc.value);
    this.cus01Excp002 = Constantes.VALOR_VACIO;
    this.cus01Excp012 = Constantes.VALOR_VACIO;

    if(tipoDocumento == Constantes.TIPO_DOCUMENTO_DNI || 
      tipoDocumento == Constantes.TIPO_DOCUMENTO_RUC){

        if(trim(numDocumento) == Constantes.VALOR_VACIO) { 
          this.nombreRazonSocial.setValue('');
          return false; 
        }

        this.cus01Excp002 = MensajesExcepciones.CUS01_EXCP_002;

        if(this.numDocUsuario.valid){

          this.cus01Excp002 = Constantes.VALOR_VACIO;

          if(tipoDocumento == Constantes.TIPO_DOCUMENTO_DNI && trim(numDocumento).length == toNumber(Constantes.MAX_LENGHT_DOC_DNI)){
            this.servicioWebService.obtenerPersonaDNI(numDocumento).subscribe(
              result => {
                if (result.exito) {
                  this.nombreRazonSocial.setValue(`${trim(result.data.desApepatPnat)} ${trim(result.data.desApematPnat)} ${trim(result.data.desNombrePnat)}`);
                } else {
                  this.nombreRazonSocial.setValue('');
                  this.cus01Excp012 = MensajesExcepciones.CUS01_EXCP_012;
                  this.nombreRazonSocial.markAsTouched();
                }
              },
              error => {
                this.nombreRazonSocial.setValue('');
                this.cus01Excp012 = MensajesExcepciones.CUS01_EXCP_012;
                this.nombreRazonSocial.markAsTouched();
                console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
              }
            );
          }
    
          if(tipoDocumento == Constantes.TIPO_DOCUMENTO_RUC && trim(numDocumento).length == toNumber(Constantes.MAX_LENGHT_DOC_RUC)){
            this.servicioWebService.obtenerDatosRuc(numDocumento).subscribe(
              result => {
                if (result.exito) {
                  this.nombreRazonSocial.setValue(`${trim(result.data.ddpNombre)}`);
                } else {
                  this.nombreRazonSocial.setValue('');
                  this.cus01Excp012 = MensajesExcepciones.CUS01_EXCP_012;
                  this.nombreRazonSocial.markAsTouched();
                }
              },
              error => {
                this.nombreRazonSocial.setValue('');
                this.cus01Excp012 = MensajesExcepciones.CUS01_EXCP_012;
                this.nombreRazonSocial.markAsTouched();
                console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
              }
            );
          }
        }else{
          this.nombreRazonSocial.setValue('');
          this.nombreRazonSocial.markAsTouched();
        }
    }
  }
  //Fin metodos Web Service

  //Inicio otros
  buscarInconsistencias(codDataCatalogo: string): boolean {
    let estado: boolean = false;
    if(this.arrayCkbInconsistencias != null && this.arrayCkbInconsistencias.length > 0){
      this.arrayCkbInconsistencias.forEach(d => {
        if (d.codDataCatalogo == codDataCatalogo) {
          estado = true;
        }
      });
    }
    return estado;
  }

  buscarTipoBienes(codDataCatalogo: string): boolean {
    let estado: boolean = false;
    if(this.arrayCkbTipoBienes != null && this.arrayCkbTipoBienes.length > 0){
      this.arrayCkbTipoBienes.forEach(d => {
        if (d.codDataCatalogo == codDataCatalogo) {
          estado = true;
        }
      });
    }
    return estado;
  }

  buscarBienesFiscalizados(codBienFiscalizado: string): boolean {
    let estado: boolean = false;
    if(this.arrayCkbBienesFiscalizados != null && this.arrayCkbBienesFiscalizados.length > 0){
      this.arrayCkbBienesFiscalizados.forEach(d => {
        if (d.codBienFiscalizado == codBienFiscalizado) {
          estado = true;
        }
      });
    }
    return estado;
  }

  buscarAlternativas(codCriterio: number, codAlternativa: number): boolean {
    let estado: boolean = false;
    if(this.alternativasCriterios != null && this.alternativasCriterios.length > 0){
      this.alternativasCriterios.forEach(a => {
        if (a.numCriterio == codCriterio && a.numAlternativa == codAlternativa) {
          estado = true;
        }
      });           
    }
    return estado;
  }

  calcularCalificacionPreliminar(): number {
    let alternativaCriterio: AlternativaCriterio = new AlternativaCriterio();
    let valorCriterio: number = Number(0);
    let valorAlternativa: number = Number(0);
    let totalCalificacion: number = Number(0);

    if(this.criteriosCalificaciones != null && this.criteriosCalificaciones.length > 0){
      if(this.alternativasCriteriosSel != null && this.alternativasCriteriosSel.length > 0){
        this.criteriosCalificaciones.forEach(c => {
          valorCriterio = Number(c.porPeso);
  
          alternativaCriterio = this.alternativasCriteriosSel.find(a => a.numCriterio == c.numCriterio);
  
          if(alternativaCriterio != null){
            valorAlternativa = Number(alternativaCriterio.valAlternativa);
            totalCalificacion = totalCalificacion + (valorCriterio * valorAlternativa);
          }
        });
      }           
    }
    return totalCalificacion;
  }

  estadoTouchedCkbInconsistencia() {
    this.estadoTouchedInconsistencia = true;
  }

  estadoTouchedCkb() {
    if (this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_INSUMO).length > 0 ||
      this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_COMBUSTIBLE).length > 0) {
      this.estadoTouchedTipoBien = true;
      this.estadoTouchedBienFisca = true;
    } else {
      this.estadoTouchedTipoBien = true;
      this.estadoTouchedBienFisca = false;
    }
  }

  validacionMedioProbatorio(opcion: boolean) {
    if (opcion) {
      this.codTipoMedioProbatorio.setValidators([Validators.required]);
      this.numMedioProbatorio.setValidators([Validators.required, Validators.maxLength(50)]);
      this.archivoMedioProbatorio.setValidators([Validators.required]);
    } else {
      this.codTipoMedioProbatorio.setValidators(null);
      this.numMedioProbatorio.setValidators(null);
      this.archivoMedioProbatorio.setValidators(null);
    }
    this.codTipoMedioProbatorio.markAsTouched();
    this.numMedioProbatorio.markAsTouched();
    this.archivoMedioProbatorio.markAsTouched();
    this.codTipoMedioProbatorio.updateValueAndValidity();
    this.numMedioProbatorio.updateValueAndValidity();
    this.archivoMedioProbatorio.updateValueAndValidity();
  }

  cerrarModal(){
    setTimeout(() => {
      this.modalRef.close();
    }, Constantes.ALERT_TIEMPO_2000);
  }
  //Fin otros

}