import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CatalogoService } from 'src/app/services/maestros/catalogo.service';
import { GestionSolicitudService } from 'src/app/services/gestion-solicitud.service';
import { UtilService } from 'src/app/services/shared/util.service';
import { Constantes } from 'src/app/utils/constantes';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { Catalogo } from 'src/app/models/catalogo.model';
import { BienFiscalizadoSolicitud } from 'src/app/models/bienFiscalizadoSolicitud.model';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { trim, isEmpty, stringToMoment, padNumber, dateToString, isNotEmpty, formatDatePeriodoFront, formatDatePeriodoBack, toNumber, getFechaActual, getAnioActual } from 'src/app/utils/utilitarios';
import { FormGroup, FormControl, Validators,  AbstractControl } from '@angular/forms';
import { ArchivoBean } from 'src/app/models/archivoBean.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';

@Component({
  selector: 'app-formulario-solicitud',
  templateUrl: './formulario-solicitud.component.html',
  styleUrls: ['./formulario-solicitud.component.css']
})
export class FormularioSolicitudComponent implements OnInit {

  //Ini declaracion
  tipoLBL: string; //Indicar que es una etiqueta label
  catalogoTipoDocIdentif: string; //Codigo de catalogo de tipo de documento
  catalogoTipoIncosistencias: string; //Codigo de catalogo de inconsistencias
  catalogoTipoBien: string; //Codigo de catalogo de tipo de bien
  numSolicProg: string = ''; //Numero de solicitud para editar solicitud de programacion
  numSolicProgUnion: string = ''; //Numero de solicitud completo SP-XXXX-YYYY-UUOO
  numSolicProgUnionFront: string = ''; //Numero de solicitud completo que se mostrara en el HTML
  solicitudProgramacion: SolicitudProgramacion = new SolicitudProgramacion(); //Declarar e inicializar objeto de solicitud de programacion
  catalogoInconsistencias: Catalogo[] = []; //Almacena lista de inconsistencias de catalogo (Inicial)
  catalogoTipoBienes: Catalogo[] = []; //Almacena lista de tipo de bienes de catalogo (Inicial)
  bienesFiscalizados: BienFiscalizadoSolicitud[] = []; //Almacena lista de bienes fiscalizados (Inicial)
  arrayCkbInconsistencias: Catalogo[] = []; //Almacena lista de inconsistencias marcadas
  arrayCkbTipoBienes: Catalogo[] = []; //Almacena lista de tipo de bienes marcadas
  arrayCkbBienesFiscalizados: BienFiscalizadoSolicitud[] = []; //Almacena lista de bienes fiscalizados marcadas
  agregarCkb: boolean = true; //Agregar checkbox (Evento change lista de checkbox)
  quitarCkb: boolean = false; //Quitar checkbox (Evento change lista de checkbox)
  estadoCkbSolUUOO: boolean = true; //Valida si campo de texto descripcion de otras UUOO debe habilitarse
  estadoCkbInconsistencia: boolean = true; //Valida si campo textarea de otras inconsistencias debe habilitarse
  estadoCkbTipoBien: boolean = true; //Valida si campo textarea de otros tipos de bienes debe habilitarse
  estadoDevolucionSol: boolean = false; //Valida si la solicitud de programacion es de devolucion
  estadoTouchedInconsistencia: boolean = false; //Valida si lista de checks de inconsistencias fue tocado (Mostrar mensaje en pantalla en rojo)
  estadoTouchedTipoBien: boolean = false; //Valida si lista de checks de tipo de bien fue tocado (Mostrar mensaje en pantalla en rojo)
  estadoTouchedBienFisca: boolean = false; //Valida si lista de checks de bienes fiscalizados fue tocado (Mostrar mensaje en pantalla en rojo)
  estadoBtnSiguiente: boolean = false; //Valida si boton siguiente debe habilitarse
  esAuditor: boolean = true; //Valida si es auditor
  perInicioDate: any; //Valor inicial periodo inicio
  perFinDate: any; //Valor inicial periodo fin
  archivoBean: ArchivoBean; //Archivo de la solicitud
  formatoFechaPeriodo: string; //Formatos de fechas para periodos (Inicio/Fin)
  formatoFechaPerCompleto: string; //Formatos de fechas para periodos (Inicio/Fin)
  formaRegEdiSolProg: FormGroup; //FormGroup para registrar y editar solicitud programacion
  urlDescargaArchivo: string; // URL de descarga de archivo
  //Fin declaracion

  constructor(private catalogoService: CatalogoService,
    private gestionSolicitudService: GestionSolicitudService,
    private utilService: UtilService,
    private router: Router,
    private rutaActiva: ActivatedRoute) { }

  ngOnInit() {
    this.limpiarcampos();
    this.limpiarTouched();
    this.inicio();
  }

  //Inicio metodos componente
  async inicio() {
    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;
    this.catalogoTipoDocIdentif = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
    this.catalogoTipoIncosistencias = ConstantesCatalogo.COD_CATALOGO_TIPO_INCONSISTENCIAS;
    this.catalogoTipoBien = ConstantesCatalogo.COD_CATALOGO_TIPO_BIEN;
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO;

    this.perInicioDate = '';
    this.perFinDate = '';
    this.formatoFechaPeriodo = Constantes.FORMAT_FECHA_YYYYMM;
    this.formatoFechaPerCompleto = `DD${this.formatoFechaPeriodo}`;

    this.estadoBtnSiguiente = false;

    this.formaRegEdiSolProg = new FormGroup(
      {
        "solicitante": new FormControl('QN-03 Luis Miguel Espinoza Tinedo', Validators.required), //Se debe obtener de sesion (Local storage)
        "unidadOrganica": new FormControl('7E2303 - Gerencia de fiscalización de Bienes fiscalizados', Validators.required), //Se debe obtener de sesion (Local storage)
        "fechaGeneracion": new FormControl(getFechaActual(Constantes.FORMAT_FECHA_DDYYYYMM), Validators.required), //Se debe obtener de sesion (Local storage)
        "ckbSolUUOO": new FormControl(''),
        "descripcionUUOO": new FormControl(''),
        "periodoInicio": new FormControl('', [Validators.required, this.validacionPeriodoIni]),
        "periodoFin": new FormControl('', [Validators.required, this.validacionPeriodoFin]),
        "motivoSugeridoAsigSol": new FormControl('', Validators.maxLength(200)),
        "codTipoDocIdentif": new FormControl(''),
        "numDocUsuario": new FormControl(''),
        "archivoDocReferencia": new FormControl(''),
        "otrosDesInconsistencia": new FormControl(''),
        "otrosDesBien": new FormControl(''),
        "sustentoSol": new FormControl('', [Validators.required, Validators.maxLength(500)]),
        "observacionSol": new FormControl('', Validators.maxLength(500)),
        "motivoDevolucion": new FormControl('', Validators.maxLength(500))
      }
    );

    //Es auditor
    //Se debe obtener de sesion (Local storage)
    if(this.esAuditor){
      this.codTipoDocIdentif.setValidators([Validators.required]);
      this.numDocUsuario.setValidators([Validators.required]);
      this.archivoDocReferencia.setValidators([Validators.required]);
    }else{
      this.codTipoDocIdentif.setValidators(null);
      this.numDocUsuario.setValidators(null);
      this.archivoDocReferencia.setValidators(null);
    }

    this.eventoCkbEstadoSolUUOO(); //Evento formControl => ckbSolUUOO
    this.eventoCboCodTipoDocIdentif(); //Evento formControl => codTipoDocIdentif

    this.numSolicProg = trim(this.rutaActiva.snapshot.params.numSolicProg);

    if (this.numSolicProg != Constantes.VALOR_VACIO) {
      //Editar
      await this.obtenerDatosSolicitud(this.numSolicProg);
    } else {
      //Nuevo
      this.numSolicProgUnion = '';
      this.numSolicProgUnionFront = ''
    }

    await this.listarCatalogoInconsistencias();
    await this.listarCatalogoTipoBienes();
  }

  limpiarcampos() {
    //Setear tabla
    this.catalogoInconsistencias = [];
    this.catalogoTipoBienes = [];
    this.bienesFiscalizados = [];
    this.arrayCkbInconsistencias = [];
    this.arrayCkbTipoBienes = [];
    this.arrayCkbBienesFiscalizados = [];
  }

  limpiarTouched(){
    this.estadoTouchedInconsistencia = false;
    this.estadoTouchedTipoBien = false;
    this.estadoTouchedBienFisca = false;
  }

  resetearFormGroup(){
    //Setear formGroug
    this.formaRegEdiSolProg.reset();
  }

  //Propiedades formControl
  get solicitante() { return this.formaRegEdiSolProg.get('solicitante') as FormControl; }
  get unidadOrganica() { return this.formaRegEdiSolProg.get('unidadOrganica') as FormControl; }
  get fechaGeneracion() { return this.formaRegEdiSolProg.get('fechaGeneracion') as FormControl; }
  get ckbSolUUOO() { return this.formaRegEdiSolProg.get('ckbSolUUOO') as FormControl; }
  get descripcionUUOO() { return this.formaRegEdiSolProg.get('descripcionUUOO') as FormControl; }
  get periodoInicio() { return this.formaRegEdiSolProg.get('periodoInicio') as FormControl; }
  get periodoFin() { return this.formaRegEdiSolProg.get('periodoFin') as FormControl; }
  get motivoSugeridoAsigSol() { return this.formaRegEdiSolProg.get('motivoSugeridoAsigSol') as FormControl; }
  get codTipoDocIdentif() { return this.formaRegEdiSolProg.get('codTipoDocIdentif') as FormControl; }
  get numDocUsuario() { return this.formaRegEdiSolProg.get('numDocUsuario') as FormControl; }
  get archivoDocReferencia() { return this.formaRegEdiSolProg.get('archivoDocReferencia') as FormControl; }
  get otrosDesInconsistencia() { return this.formaRegEdiSolProg.get('otrosDesInconsistencia') as FormControl; }
  get otrosDesBien() { return this.formaRegEdiSolProg.get('otrosDesBien') as FormControl; }
  get sustentoSol() { return this.formaRegEdiSolProg.get('sustentoSol') as FormControl; }
  get observacionSol() { return this.formaRegEdiSolProg.get('observacionSol') as FormControl; }
  get motivoDevolucion() { return this.formaRegEdiSolProg.get('motivoDevolucion') as FormControl; }

  //Eventos
  eventoCkbEstadoSolUUOO() {
    this.ckbSolUUOO.valueChanges.subscribe(checked => {
      if (checked) {
        this.estadoCkbSolUUOO = false;
        this.descripcionUUOO.setValidators([Validators.required,Validators.maxLength(500)]);
      } else {
        this.estadoCkbSolUUOO = true;
        this.descripcionUUOO.setValidators(null);
      }
      this.descripcionUUOO.setValue(''); //Setear valor a formControl
      this.descripcionUUOO.updateValueAndValidity(); //Activar validacion
    });
  }

  eventoCkbInconsistencias(valor: Catalogo, opcion: boolean) {
    if (opcion) {
      this.arrayCkbInconsistencias = this.arrayCkbInconsistencias.concat(valor); //Agregar
      if (valor.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS) this.otrosDesInconsistencia.setValidators([Validators.required, Validators.maxLength(500)]);
    } else {
      this.arrayCkbInconsistencias = this.arrayCkbInconsistencias.filter(s => s.codDataCatalogo !== valor.codDataCatalogo); //Quitar
      if (valor.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS) this.otrosDesInconsistencia.setValidators(null);
    }

    this.estadoTouchedCkbInconsistencia();

    if (valor.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS) {
      this.estadoCkbInconsistencia = !opcion;
      this.otrosDesInconsistencia.setValue('');
      this.otrosDesInconsistencia.updateValueAndValidity();
    }
  }

  async eventoCkbTipoBien(valor: Catalogo, opcion: boolean) {
    if (opcion) {
      this.arrayCkbTipoBienes = this.arrayCkbTipoBienes.concat(valor); //Agregar
      if (valor.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS ||
        valor.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_DISOLVENTE ||
        valor.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_MEZCLA){
          this.otrosDesBien.setValidators([Validators.required, Validators.maxLength(500)]);
          this.estadoCkbTipoBien = false;
          //this.otrosDesBien.setValue('');
          this.otrosDesBien.updateValueAndValidity();
        }
    } else {
      this.arrayCkbTipoBienes = this.arrayCkbTipoBienes.filter(s => s.codDataCatalogo !== valor.codDataCatalogo); //Quitar
      if (this.arrayCkbTipoBienes.filter(s => s.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS).length <= 0 &&
      this.arrayCkbTipoBienes.filter(s => s.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_DISOLVENTE).length <= 0 &&
      this.arrayCkbTipoBienes.filter(s => s.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_MEZCLA).length <= 0){
        this.otrosDesBien.setValidators(null);
        this.estadoCkbTipoBien = true;
        this.otrosDesBien.setValue('');
       this.otrosDesBien.updateValueAndValidity();
      }
    }
    this.arrayCkbBienesFiscalizados = this.arrayCkbBienesFiscalizados.filter(T => T.codTipoBien != valor.codDataCatalogo);
    this.estadoTouchedCkb();
    await this.listarBienesFiscalizados();
  }

  eventoCkbFiscalizados(valor: BienFiscalizadoSolicitud, opcion: boolean) {
    if (opcion) {
      this.arrayCkbBienesFiscalizados = this.arrayCkbBienesFiscalizados.concat(valor); //Agregar
    } else {
      this.arrayCkbBienesFiscalizados = this.arrayCkbBienesFiscalizados.filter(s => s.codBienFiscalizado !== valor.codBienFiscalizado); //Quitar
    }
    this.estadoTouchedCkb();
  }

  //Evento combos
  eventoCboCodTipoDocIdentif() {
    this.codTipoDocIdentif.valueChanges.subscribe(valor => {
      valor = trim(valor);
      if (valor == Constantes.TIPO_DOCUMENTO_RUC) {
        this.numDocUsuario.setValidators([Validators.required,
        Validators.minLength(11),
        Validators.maxLength(11),
        Validators.pattern(Constantes.VALIDA_PATTERN_SOLO_NUMERO)]);
      } else if (valor == Constantes.TIPO_DOCUMENTO_DNI) {
        this.numDocUsuario.setValidators([Validators.required,
        Validators.minLength(8),
        Validators.maxLength(8),
        Validators.pattern(Constantes.VALIDA_PATTERN_SOLO_NUMERO)]);
      } else if (valor == Constantes.TIPO_DOCUMENTO_PASAPORTE) {
        this.numDocUsuario.setValidators([Validators.required, Validators.minLength(8), Validators.maxLength(15)]);
      } else if (valor == Constantes.TIPO_DOCUMENTO_CARNE_EXTRANJERIA) {
        this.numDocUsuario.setValidators([Validators.required, Validators.minLength(8), Validators.maxLength(15)]);
      } else if (valor == Constantes.TIPO_DOCUMENTO_CEDULA_DIPLOMATICA) {
        this.numDocUsuario.setValidators([Validators.required, Validators.minLength(8), Validators.maxLength(15)]);
      } else {
        this.numDocUsuario.setValidators(null);
      }
      this.numDocUsuario.setValue('');
      this.numDocUsuario.updateValueAndValidity();
    });
  }

  //Validacion personalizada
  validacionPeriodoIni(control: AbstractControl): { [s: string]: boolean } | null {
    let formatoFechaPeriodo: string = Constantes.FORMAT_FECHA_YYYYMM;
    let formatoFechaPerCompleto: string = `DD${formatoFechaPeriodo}`;
    // control.parent es el FormGroup
    if (control.parent) { // En las primeras llamadas control.parent es undefined
      if (control.value) { // En las primeras llamadas control.value es undefined
        if(isNotEmpty(control.value) && isNotEmpty(control.parent.controls['periodoFin'].value)){
          const periodoInicio = `${control.value.year}${padNumber(control.value.month)}`;
          const periodoFin = `${control.parent.controls['periodoFin'].value.year}${padNumber(control.parent.controls['periodoFin'].value.month)}`;
          const momentDesde = stringToMoment(`01${periodoInicio}`, formatoFechaPerCompleto);
          const momentHasta = stringToMoment(`01${periodoFin}`, formatoFechaPerCompleto);
          if (momentDesde.isAfter(momentHasta)) {
            return { periodoiniafter: true };
          }
        }
      }
    }
    return null;
  }

  validacionPeriodoFin(control: AbstractControl): { [s: string]: boolean } | null {
    let formatoFechaPeriodo: string = Constantes.FORMAT_FECHA_YYYYMM;
    let formatoFechaPerCompleto: string = `DD${formatoFechaPeriodo}`;
    // control.parent es el FormGroup
    if (control.parent) { // En las primeras llamadas control.parent es undefined
      if (control.value) { // En las primeras llamadas control.value es undefined
        if(isNotEmpty(control.value) && isNotEmpty(control.parent.controls['periodoInicio'].value)){
          const periodoInicio = `${control.parent.controls['periodoInicio'].value.year}${padNumber(control.parent.controls['periodoInicio'].value.month)}`;
          const periodoFin = `${control.value.year}${padNumber(control.value.month)}`;
          const momentDesde = stringToMoment(`01${periodoInicio}`, formatoFechaPerCompleto);
          const momentHasta = stringToMoment(`01${periodoFin}`, formatoFechaPerCompleto);
          const momentToday = stringToMoment(dateToString(new Date(), formatoFechaPerCompleto), formatoFechaPerCompleto);
          if (momentHasta.isBefore(momentDesde)) {
            return { periodofinbefore: true };
          } else if (momentHasta.isAfter(momentToday)) {
            return { periodofinafter: true };
          }
        }
      }
    }
    return null;
  }

  //Evento botones
  eventoBtnSiguiente() {
    if(this.estadoBtnSiguiente == true){
      this.router.navigate(['/solicitudes/gestion-solicitudes-programacion/detalle', this.numSolicProg]);
    }
  }

  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }

  getErrorClassCkb(arrayList: any[], estadoTouched: boolean, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    if (tipo == Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
      return this.utilService.getErrorMensajeCkbFormControl(arrayList, estadoTouched);
    }
    return this.utilService.getErrorClassCkbFormControl(arrayList, estadoTouched, tipo);
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  obtenerDatosSolicitante() {
    
  }

  async listarCatalogoInconsistencias() {
    this.catalogoInconsistencias = [];
    let catalogoInconsistenciasTemp: Catalogo[] = [];

    let result = await this.catalogoService.obtenerCatalogo(this.catalogoTipoIncosistencias).toPromise();

    if (result.exito) {
      catalogoInconsistenciasTemp = result.data;

      //Ini - Editar
      if(this.numSolicProg != Constantes.VALOR_VACIO) {
        if(this.arrayCkbInconsistencias != null && this.arrayCkbInconsistencias.length > 0){
          catalogoInconsistenciasTemp.forEach(i => {
            i.seleccionado = this.buscarInconsistencias(i.codDataCatalogo);
          });

          //Ckeck otros
          if(this.arrayCkbInconsistencias.filter(v => v.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS).length > 0){
            this.otrosDesInconsistencia.setValidators([Validators.required]);
            this.estadoCkbInconsistencia = false;
            //this.otrosDesInconsistencia.setValue('');
            this.otrosDesInconsistencia.updateValueAndValidity();
          }
        }
      }
      //Fin - Editar

      this.catalogoInconsistencias = catalogoInconsistenciasTemp;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de inconsistencias => ${result.mensaje}`);
    } 
  }

  async listarCatalogoTipoBienes() {
    this.catalogoTipoBienes = [];
    let catalogoTipoBienesTemp: Catalogo[] = [];

    let result = await this.catalogoService.obtenerCatalogo(this.catalogoTipoBien).toPromise();

    if (result.exito) {
      catalogoTipoBienesTemp = result.data;
      catalogoTipoBienesTemp.push(new Catalogo(Constantes.OPCION_CODIGO_OTROS, Constantes.OPCION_NOMBRE_OTROS));
      
      //Ini - Editar
      if(this.numSolicProg != Constantes.VALOR_VACIO) {
        if(this.arrayCkbTipoBienes != null && this.arrayCkbTipoBienes.length > 0){

          catalogoTipoBienesTemp.forEach(t => {
            t.seleccionado = this.buscarTipoBienes(t.codDataCatalogo);
          });

          //Ckeck otros
          if(this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_CODIGO_OTROS).length > 0 ||
          this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_DISOLVENTE).length > 0 ||
          this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_MEZCLA).length > 0){
            this.otrosDesBien.setValidators([Validators.required]);
            this.estadoCkbTipoBien = false;
            //this.otrosDesBien.setValue('');
            this.otrosDesBien.updateValueAndValidity();
          }

          await this.listarBienesFiscalizados();
        }
      }
      //Fin - Editar

      this.catalogoTipoBienes = catalogoTipoBienesTemp;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de tipos de bienes => ${result.mensaje}`);
    }
  }

  async listarBienesFiscalizados() {
    this.bienesFiscalizados = [];
    let bienesFiscalizadosTemp: BienFiscalizadoSolicitud[] = [];

    if (this.arrayCkbTipoBienes != null && this.arrayCkbTipoBienes.length > 0) {

      this.arrayCkbTipoBienes.forEach(async t => {
        if (t.codDataCatalogo != Constantes.OPCION_CODIGO_OTROS){

          let result = await this.gestionSolicitudService.listarBienesFiscalizados(t.codDataCatalogo).toPromise();

          if (result.exito) {
            bienesFiscalizadosTemp = bienesFiscalizadosTemp.concat(result.data);
            
            //Ini - Editar
            if(this.arrayCkbBienesFiscalizados != null && this.arrayCkbBienesFiscalizados.length > 0){
              bienesFiscalizadosTemp.forEach(b => {
                b.seleccionado = this.buscarBienesFiscalizados(b.codBienFiscalizado);
              });
            }
            //Fin - Editar

            this.bienesFiscalizados = bienesFiscalizadosTemp;
          } else {
            console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de bienes fiscalizados => ${result.mensaje}`);
          }
        }
      });
    }
  }

  async obtenerDatosSolicitud(numSolicProg: string) {

    let result = await this.gestionSolicitudService.obtenerDatosSolicitud(numSolicProg).toPromise();

    if (result.exito) {
      this.solicitudProgramacion = result.data;

      this.estadoBtnSiguiente = true;

      //Llenar campo con data recuperada
      this.numSolicProg = numSolicProg;
      this.numSolicProgUnion = this.solicitudProgramacion.numSolicitudUnion;
      this.numSolicProgUnionFront = `Nro. Solicitud: ${this.solicitudProgramacion.numSolicitudUnion}`;

      this.solicitante.setValue(this.solicitudProgramacion.nomSolicitante)
      this.unidadOrganica.setValue(this.solicitudProgramacion.desUnidadOrganica);
      this.fechaGeneracion.setValue(this.solicitudProgramacion.fecGeneracion);
      this.ckbSolUUOO.setValue(this.solicitudProgramacion.indOtroSolicitan);
      this.descripcionUUOO.setValue(this.solicitudProgramacion.desOtroSolicitante);
      this.periodoInicio.setValue(formatDatePeriodoFront(this.solicitudProgramacion.perInicio));
      this.periodoFin.setValue(formatDatePeriodoFront(this.solicitudProgramacion.perFin));
      this.motivoSugeridoAsigSol.setValue(this.solicitudProgramacion.desMotivoAsignacion);
      this.codTipoDocIdentif.setValue(this.solicitudProgramacion.codTipoDocumentoReferencia);
      this.numDocUsuario.setValue(this.solicitudProgramacion.numDocumentoReferencia);
      this.otrosDesInconsistencia.setValue(this.solicitudProgramacion.desOtraInconsistencia);
      this.otrosDesBien.setValue(this.solicitudProgramacion.desOtraTipoBien);
      this.sustentoSol.setValue(this.solicitudProgramacion.desSusSolicitud);
      this.observacionSol.setValue(this.solicitudProgramacion.obsSolicitud);
      this.archivoDocReferencia.setValue(this.solicitudProgramacion.archivoBean);
      this.archivoBean = this.solicitudProgramacion.archivoBean;
      this.estadoDevolucionSol = trim(this.solicitudProgramacion.codEstadoSolicitud) == Constantes.COD_EST_SOLICITUD_DEVUELTO ? true : false;

      this.arrayCkbInconsistencias = this.solicitudProgramacion.inconsistencias;
      this.arrayCkbTipoBienes = this.solicitudProgramacion.tipoBienes;
      this.arrayCkbBienesFiscalizados = this.solicitudProgramacion.bienesFiscalizados;

    } else {
      console.log(result.mensaje);
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO, Constantes.MODAL_PRIMARY);
    }
  }

  async guardarSolicitud() {
    let existeInsumoBF = false;
    let existeCombustibleBF = false;
    this.estadoTouchedCkbInconsistencia();
    this.estadoTouchedCkb();

    if (this.formaRegEdiSolProg.valid) {

      if(this.arrayCkbInconsistencias.length <= 0 || this.arrayCkbTipoBienes.length <= 0){
        this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
        return false;
      }

      this.arrayCkbTipoBienes.forEach(d => {
        if(d.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_INSUMO){
          existeInsumoBF = true;
        }else if(d.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_COMBUSTIBLE){
          existeCombustibleBF = true;
        }
      });

      if(existeInsumoBF){
        if(this.arrayCkbBienesFiscalizados.filter(d => d.codTipoBien == Constantes.OPCION_TIPO_BIEN_INSUMO).length <= 0){
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_017, Constantes.MODAL_DANGER);
          return false;
        }
      }

      if(existeCombustibleBF){
        if(this.arrayCkbBienesFiscalizados.filter(d => d.codTipoBien == Constantes.OPCION_TIPO_BIEN_COMBUSTIBLE).length <= 0){
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_018, Constantes.MODAL_DANGER);
          return false;
        }
      }

      let solicitudProgramacion: SolicitudProgramacion = new SolicitudProgramacion();

      solicitudProgramacion.anioSolicitud = getAnioActual(); //Obtener del sistema
      // solicitudProgramacion.codEstadoSolicitud = "";
      solicitudProgramacion.codSolicitante = ""; //Obtener sesion (Local storage)
      solicitudProgramacion.codTipoDocumentoReferencia = trim(this.codTipoDocIdentif.value);
      solicitudProgramacion.codUnidadOrganica = ""; //Obtener sesion (Local storage)
      solicitudProgramacion.desMotivoAsignacion = trim(this.motivoSugeridoAsigSol.value);
      solicitudProgramacion.desOtroSolicitante = trim(this.descripcionUUOO.value);
      solicitudProgramacion.desSusSolicitud = trim(this.sustentoSol.value);
      // solicitudProgramacion.desEstadoSolicitud = "";
      // solicitudProgramacion.desTipoDocumentoIdenti = "";
      // solicitudProgramacion.desTipoAccionControl = "";
      // solicitudProgramacion.desTipoDocumentoIdent = "";
      // solicitudProgramacion.desTipoDocumentoRef = "";
      // solicitudProgramacion.desTipoIntervencion = "";
      solicitudProgramacion.desUnidadOrganica = trim(this.unidadOrganica.value); //Obtener sesion (Local storage)
      solicitudProgramacion.fecGeneracion = getFechaActual(Constantes.FORMAT_FECHA_DDYYYYMM); //Obtener del sistema
      solicitudProgramacion.indOtroSolicitan = trim(this.ckbSolUUOO.value);
      // solicitudProgramacion.nomProgramador = "";
      solicitudProgramacion.nomSolicitante = trim(this.solicitante.value); //Obtener sesion (Local storage)
      // solicitudProgramacion.nomSupervisor = "";
      solicitudProgramacion.numCorrel = 0;
      solicitudProgramacion.numDocumentoReferencia = trim(this.numDocUsuario.value);
      solicitudProgramacion.numSolicitud = this.numSolicProg == '' ? 0 : toNumber(this.numSolicProg);
      solicitudProgramacion.numSolicitudUnion = this.numSolicProgUnion;
      solicitudProgramacion.obsSolicitud = trim(this.observacionSol.value);
      solicitudProgramacion.perFin = formatDatePeriodoBack(this.periodoFin.value);
      solicitudProgramacion.perInicio = formatDatePeriodoBack(this.periodoInicio.value);
      solicitudProgramacion.desOtraInconsistencia = trim(this.otrosDesInconsistencia.value);
      solicitudProgramacion.desOtraTipoBien = trim(this.otrosDesBien.value);
      solicitudProgramacion.archivoBean = this.archivoDocReferencia.value; //Archivo;
      solicitudProgramacion.inconsistencias = this.arrayCkbInconsistencias;
      solicitudProgramacion.tipoBienes = this.arrayCkbTipoBienes;
      solicitudProgramacion.bienesFiscalizados = this.arrayCkbBienesFiscalizados;

      console.log(solicitudProgramacion);
      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE,Constantes.MODAL_PRIMARY, () => {
        this.gestionSolicitudService.guardarSolicitud(solicitudProgramacion).subscribe(
          async result => {
            if (result.exito) {
              this.estadoBtnSiguiente = true;
              this.utilService.alertaMensaje(this.numSolicProg == Constantes.VALOR_VACIO ? `Se guard\u00f3 la solicitud con n\u00famero ${result.data.numSolicitudUnion}` : MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
              this.limpiarcampos();
              this.resetearFormGroup();
              await this.obtenerDatosSolicitud(result.data.numSolicitud);
              await this.listarCatalogoInconsistencias();
              await this.listarCatalogoTipoBienes();
              this.estadoTouchedCkbInconsistencia();
              this.estadoTouchedCkb();
            } else {
              if(trim(result.mensaje) == Constantes.VALOR_VACIO){
                this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS}`, Constantes.MODAL_DANGER);
              }else{
                this.utilService.alertaMensaje(`${result.mensaje}`, Constantes.MODAL_DANGER);
              }
            }
          },
          error => {
            console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_GUARDADOS, Constantes.MODAL_DANGER);
          }
        );
      });

    } else {
      this.periodoInicio.updateValueAndValidity(); //Ejecutar validacion formControl
      this.periodoFin.updateValueAndValidity(); //Ejecutar validacion formControl
      this.formaRegEdiSolProg.markAllAsTouched(); //Por formGroup
      this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_CAMPOS_OBLIGATORIOS, Constantes.MODAL_DANGER);
    }

  }
  //Fin metodos Web Service

  //Inicio otros
  buscarInconsistencias(codDataCatalogo: string): boolean{
    let estado: boolean = false;
    if(this.arrayCkbInconsistencias != null && this.arrayCkbInconsistencias.length > 0){
      this.arrayCkbInconsistencias.forEach(d => {
        if(d.codDataCatalogo == codDataCatalogo){
          estado = true;
        }
      });
    }
    return estado;
  }

  buscarTipoBienes(codDataCatalogo: string): boolean{
    let estado: boolean = false;
    if(this.arrayCkbTipoBienes != null && this.arrayCkbTipoBienes.length > 0){
      this.arrayCkbTipoBienes.forEach(d => {
        if(d.codDataCatalogo == codDataCatalogo){
          estado = true;
        }
      });
    }
    return estado;
  }

  buscarBienesFiscalizados(codBienFiscalizado: string): boolean{
    let estado: boolean = false;
    if(this.arrayCkbBienesFiscalizados != null && this.arrayCkbBienesFiscalizados.length > 0){
      this.arrayCkbBienesFiscalizados.forEach(d => {
        if(d.codBienFiscalizado == codBienFiscalizado){
          estado = true;
        }
      });
    }
    return estado;
  }

  estadoTouchedCkbInconsistencia(){
    this.estadoTouchedInconsistencia = true;
  }

  estadoTouchedCkb(){
    if(this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_INSUMO).length > 0 ||
      this.arrayCkbTipoBienes.filter(v => v.codDataCatalogo == Constantes.OPCION_TIPO_BIEN_COMBUSTIBLE).length > 0){
        this.estadoTouchedTipoBien = true;
        this.estadoTouchedBienFisca = true;
    }else{
      this.estadoTouchedTipoBien = true;
      this.estadoTouchedBienFisca = false;
    }
  }
  //Fin otros
}
