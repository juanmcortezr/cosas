import { Component, OnInit, ɵConsole } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Constantes } from 'src/app/utils/constantes';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { trim, isNotEmpty, isEmpty } from 'src/app/utils/utilitarios';
import { Catalogo } from 'src/app/models/catalogo.model';
import { UsuarioSolicitud } from 'src/app/models/usuarioSolicitud.model';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { MedioProbatorioUsuario } from 'src/app/models/medioProbatorioUsuario.model';
import { EstablecimientoUsuario } from 'src/app/models/establecimientoUsuario.model';
import { BienFiscalizadoSolicitud } from 'src/app/models/bienFiscalizadoSolicitud.model';
import { UtilService } from 'src/app/services/shared/util.service';
import { EvaluacionSolicitudService } from 'src/app/services/evaluacion-solicitud.service';
import { ArchivoBean } from 'src/app/models/archivoBean.model';


@Component({
  selector: 'app-evaluar-solicitud',
  templateUrl: './evaluar-solicitud.component.html',
  styleUrls: ['./evaluar-solicitud.component.css']
})
export class EvaluarSolicitudComponent implements OnInit {

  /* Inicio declaracion */
  //*Solicitante
  supervisorSolicitante: string = '1';
  esSolicitante: boolean = false;
  //*Programacion
  supervisorProgramador: string = '2';
  esProgramador: boolean = false;
  //Supervisor Session
  tipoSupervisor: string = this.supervisorSolicitante;
  opcEvaluacion: any = {
    "opcSi": "",
    "opcNo": "",
    "readOnly": true
  };
  hiddeTable: boolean = true;

  //Archivo
  urlDescargaArchivo: string;
  archivo: ArchivoBean = new ArchivoBean();
  archivoUsuario: ArchivoBean = new ArchivoBean();

  //Combos
  // *Catalogo
  catalogoTipoIncosistencias: string;
  catalogoTipoBien: string;

  //Variables
  //*Solicitud
  numSolicProg: string = '';
  solicitudProgramacion: SolicitudProgramacion = new SolicitudProgramacion();
  usuarioSolic: UsuarioSolicitud = new UsuarioSolicitud();
  inconsistencias: Catalogo[];
  tipoBienes: Catalogo[];
  bienesFiscalizados: BienFiscalizadoSolicitud[];
  //*Usuario
  usuarios: UsuarioSolicitud[] = [];
  mediosProbatorios: MedioProbatorioUsuario[] = [];
  establecimientos: EstablecimientoUsuario[] = [];
  usuarioInconsistencias: Catalogo[];
  usuarioTipoBienes: Catalogo[];
  usuarioBienesFiscalizados: BienFiscalizadoSolicitud[];
  /* Fin declaracion */

  constructor(
    private router: Router,
    private evaluacionSolicitudService: EvaluacionSolicitudService,
    private utilService: UtilService,
    private rutaActiva: ActivatedRoute
  ) { }

  ngOnInit() {
    this.Inicio();
  }

  /* Inicio metodos componente */

  Inicio() {
    //Catalogo
    this.catalogoTipoIncosistencias = ConstantesCatalogo.COD_CATALOGO_TIPO_INCONSISTENCIAS;
    this.catalogoTipoBien = ConstantesCatalogo.COD_CATALOGO_TIPO_BIEN;
    //Archivo
    this.urlDescargaArchivo = ConstantesUris.URL_DESCARGA_ARCHIVO
    //Obtener NumSolic 
    this.numSolicProg = trim(this.rutaActiva.snapshot.params.numSolicProg);
    //Iniciar métodos
    if (isNotEmpty(this.numSolicProg)) {
      this.cambiarSupervisor(this.supervisorSolicitante);
      this.obtenerDatosSolicitud();
      this.readonlyTxtArea(true);
    }
  }

  //Supervisor Session
  cambiarSupervisor(tipoSupervisor: string) {
    this.opcEvaluacion = {};
    if (tipoSupervisor == this.supervisorSolicitante) {
      this.esProgramador = false;
      this.esSolicitante = true;

      this.opcEvaluacion.opcSi = "Autorizar";
      this.opcEvaluacion.opcNo = "Devolver";
    } else if (tipoSupervisor == this.supervisorProgramador) {
      this.esProgramador = true;
      this.esSolicitante = false;

      this.opcEvaluacion.opcSi = "Aprobar";
      this.opcEvaluacion.opcNo = "Archivar";
    }
  }

  readonlyTxtArea(readonly: boolean) {
    this.solicitudProgramacion.desSusSolicitud = "";
    if (readonly == true) {
      this.opcEvaluacion.readOnly = readonly;
    } else if (readonly == false) {
      this.opcEvaluacion.readOnly = readonly;
    }
  }

  cancelarEvaluacion() {
    this.router.navigate(['/solicitudes/evaluacion-solicitud-programacion']);
  }

  setearEstadoSolicitud() {
    if (this.tipoSupervisor == this.supervisorSolicitante) {
      this.solicitudProgramacion.esSupervisorSolicitante = this.esSolicitante;
      if (this.opcEvaluacion.readOnly == true)
        this.solicitudProgramacion.codEstadoSolicitud = Constantes.COD_ESTADO_SOLICITUD_AUTORIZADO
      else if (this.opcEvaluacion.readOnly == false)
        this.solicitudProgramacion.codEstadoSolicitud = Constantes.COD_ESTADO_SOLICITUD_DEVUELTO
    } else if (this.tipoSupervisor == this.supervisorProgramador) {
      this.solicitudProgramacion.esSupervisorProgramador = this.esProgramador;
      if (this.opcEvaluacion.readOnly == true)
        this.solicitudProgramacion.codEstadoSolicitud = Constantes.COD_ESTADO_SOLICITUD_APROBADO
      else if (this.opcEvaluacion.readOnly == false)
        this.solicitudProgramacion.codEstadoSolicitud = Constantes.COD_ESTADO_SOLICITUD_ARCHIVADO
    }
  }

  validarGuardar(desSusSolicitud: string): boolean {
    let indGuardar: boolean = false;
    if (this.opcEvaluacion.readOnly == true && isEmpty(desSusSolicitud)) {
      indGuardar = true;
    } else if (this.opcEvaluacion.readOnly == false && isNotEmpty(desSusSolicitud)) {
      indGuardar = true;
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS02_EXCP_003, Constantes.MODAL_DANGER);
    }
    return indGuardar;
  }
  /* Fin metodos componente */

  /* Inicio metodos Web Service */
  obtenerDatosSolicitud() {
    this.evaluacionSolicitudService.obtenerDetalleEvaluarSolicitud(this.numSolicProg).subscribe(
      result => {
        if (result.exito) {
          this.solicitudProgramacion = result.data;
          this.inconsistencias = this.solicitudProgramacion.inconsistencias;
          this.tipoBienes = this.solicitudProgramacion.tipoBienes;
          this.bienesFiscalizados = this.solicitudProgramacion.bienesFiscalizados;
          this.usuarios = this.solicitudProgramacion.usuarios;
          this.archivo = this.solicitudProgramacion.archivoBean;
          //Setear Sustento
          this.solicitudProgramacion.desSusSolicitud = "";
        } else {
          console.log(result.mensaje);
          this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log("Hubo errores ", error);
      }
    );
  }

  obtenerUsuarioSeleccionado(idUsuario: string, indicador: string) {
    this.usuarioSolic = new UsuarioSolicitud();
    this.evaluacionSolicitudService.obtenerUsuarioSeleccionado(idUsuario).subscribe(
      result => {
        if (result.exito) {
          this.usuarioSolic = result.data;
          this.mediosProbatorios = this.usuarioSolic.mediosProbatorios;
          this.establecimientos = this.usuarioSolic.establecimientos;
          this.usuarioInconsistencias = this.usuarioSolic.inconsistencias;
          this.usuarioTipoBienes = this.usuarioSolic.tipoBienes;
          this.usuarioBienesFiscalizados = this.usuarioSolic.bienesFiscalizados;
          this.archivoUsuario = this.usuarioSolic.archivoBean;

          if (indicador == 'sel') {
            this.hiddeTable = false;
          } else if (indicador == 'mdl') {
            this.hiddeTable = true;
          }
          console.log(result.data);
        } else {
          console.log(result.mensaje);
          this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
        }
      },
      error => {
        console.log("Hubo errores ", error);
      }
    );
  }

  guardarEvaluacion(solicitudProgramacion: SolicitudProgramacion) {
    this.solicitudProgramacion = solicitudProgramacion;

    // setear codEstado
    this.setearEstadoSolicitud();

    if (this.validarGuardar(this.solicitudProgramacion.desSusSolicitud)) {
      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,
        Constantes.MODAL_MENSAJE_GUARDAR_EVALUACION,
        Constantes.MODAL_PRIMARY, () => {
          this.evaluacionSolicitudService.guardarEvaluacion(this.solicitudProgramacion).subscribe(
            result => {
              if (result.exito) {
                this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_GUARDAR, Constantes.MODAL_SUCCESS);
                setTimeout(() => {
                  this.router.navigate(['/solicitudes/evaluacion-solicitud-programacion']);
                }, Constantes.ALERT_TIEMPO_4000);
              } else {
                console.log(result.mensaje);
                this.utilService.alertaMensaje('No se guardo la evaluacion.', Constantes.MODAL_DANGER);
              }
            },
            error => {
              console.log("Hubo errores ", error);
            }
          );
        }
      );
    }
  }
  /* Fin metodos Web Service */
}
