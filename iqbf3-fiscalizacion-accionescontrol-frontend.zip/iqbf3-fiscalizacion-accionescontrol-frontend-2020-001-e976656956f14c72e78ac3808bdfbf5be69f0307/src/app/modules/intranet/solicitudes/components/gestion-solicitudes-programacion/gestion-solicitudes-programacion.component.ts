import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { CatalogoService } from 'src/app/services/maestros/catalogo.service';
import { Router } from '@angular/router';
import { GestionSolicitudService } from 'src/app/services/gestion-solicitud.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { trim, isNotEmpty, toNumber } from 'src/app/utils/utilitarios';
import { UtilService } from 'src/app/services/shared/util.service';
import { Constantes } from 'src/app/utils/constantes';

@Component({
  selector: 'app-gestion-solicitudes-programacion',
  templateUrl: './gestion-solicitudes-programacion.component.html',
  styleUrls: ['./gestion-solicitudes-programacion.component.css']
})
export class GestionSolicitudesProgramacionComponent implements OnInit {

  //Inicio declaracion
  catalogoTipoDocIdentif: string; //Codigo de catalogo tipo de documento de identificacion
  catalogoTipoIntervencion: string; //Codigo de catalogo tipo de intervencion
  catalogoTipoAccionControl: string; //Codigo de catalogo tipo de accion
  catalogoEstadoSol: string; //Codigo de catalogo estado de solicitud
  solicitudProgramacion: SolicitudProgramacion = new SolicitudProgramacion(); //Declarar e inicializar objeto de solicitud de programacion
  solicitudesProgramacion: SolicitudProgramacion[] = []; //Almacena lista de solicitudes
  filtro: any = {}; //Objeto filtro (Mapear datos ngModel)
  validTipDoc: any = {
    "requerido": false,
    "minLenght": 0,
    "maxLenght": Constantes.MAX_LENGHT_DOC_OTROS,
    "pattern": Constantes.VALOR_VACIO,
    "tipoDoc": Constantes.VALOR_VACIO,
    "tipoVal": Constantes.TIPO_VALI_ONLYNUMBERLETTER
  };
  estado: boolean = false;
  opcionAnular: boolean = false;
  listaPermitidosTipoAccion: string[] = []; //Lista de tipos de accion a mostrar
  //Fin declaracion

  constructor(private router: Router,
    private catalogoService: CatalogoService,
    private gestionSolicitudService: GestionSolicitudService,
    private utilService: UtilService) { }

  ngOnInit() {
    this.inicio();
    this.limpiarcampos();
  }

  //Inicio metodos componente
  inicio() {
    this.catalogoTipoDocIdentif = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
    this.catalogoTipoIntervencion = ConstantesCatalogo.COD_CATALOGO_TIPO_INTERVENCION;
    this.catalogoTipoAccionControl = ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL;
    this.catalogoEstadoSol = ConstantesCatalogo.COD_CATALOGO_ESTADO_SOLICITUD;
  }

  limpiarcampos() {
    //Setear valores
    this.filtro = {
      numSolicitud: "",
      codTipoDocUsuario: "",
      numDocUsuario: "",
      codTipoIntervension: "",
      codTipoAccion: "",
      codEstadoSolicitud: ""
    };

    this.validTipDoc = {
      "requerido": false,
      "minLenght": 0,
      "maxLenght": Constantes.MAX_LENGHT_DOC_OTROS,
      "pattern": Constantes.VALOR_VACIO,
      "tipoDoc": Constantes.VALOR_VACIO,
      "tipoVal": Constantes.TIPO_VALI_ONLYNUMBERLETTER
    };

    //Setear tabla
    this.solicitudesProgramacion = [];
    this.listaPermitidosTipoAccion = [];
  }

  eventoCboCodTipoDocIdentif(event: any){
    let valor = trim(event.target.value);

    if(valor == Constantes.TIPO_DOCUMENTO_DNI){
      this.validTipDoc.requerido = true;
      this.validTipDoc.minLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.pattern = Constantes.VALIDA_PATTERN_SOLO_NUMERO;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_DNI;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }else if(valor == Constantes.TIPO_DOCUMENTO_RUC){
      this.validTipDoc.requerido = true;
      this.validTipDoc.minLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.pattern = Constantes.VALIDA_PATTERN_SOLO_NUMERO;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_RUC;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }else{
      this.validTipDoc.requerido = false;
      this.validTipDoc.minLenght = 0;
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_OTROS;
      this.validTipDoc.pattern = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoDoc = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBERLETTER;
    }

  }

  eventoBtnNuevaSolicitud() {
    this.router.navigate(['/solicitudes/gestion-solicitudes-programacion/formulario']);
  }

  eventoBtnBuscar(){
    this.opcionAnular = false;
    this.listarSolicitudProgramacion();
  }

  //Eventos combo
  eventoCodTipoIntervencion(value: string){
    if(value == Constantes.TIPO_INTERVENCION_CONTROL){
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_CARTA, Constantes.TIPO_ACCION_ESQUELA];
    }else if(value == Constantes.TIPO_INTERVENCION_FISCALIZACION){
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_VISITA_PROGRAMADA, Constantes.TIPO_ACCION_VISITA_NO_PROGRAMADA];
    }else{
      this.listaPermitidosTipoAccion = [];
    }
  }
  //Fin metodos componente

  //Inicio metodos Web Service
  listarSolicitudProgramacion() {
    this.solicitudesProgramacion = [];

    this.solicitudProgramacion.numSolicitudUnion = trim(this.filtro.numSolicitud);
    this.solicitudProgramacion.codTipoDocUsuario = trim(this.filtro.codTipoDocUsuario);
    this.solicitudProgramacion.numDocUsuario = trim(this.filtro.numDocUsuario);
    this.solicitudProgramacion.codTipoIntervension = trim(this.filtro.codTipoIntervension);
    this.solicitudProgramacion.codTipoAccion = trim(this.filtro.codTipoAccion);
    this.solicitudProgramacion.codEstadoSolicitud = trim(this.filtro.codEstadoSolicitud);

    if (this.solicitudProgramacion.filtroValido()) {

      //validar numDocUsuario
      if (isNotEmpty(this.solicitudProgramacion.codTipoDocUsuario)) {
        if (!isNotEmpty(this.solicitudProgramacion.numDocUsuario)) {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_002, Constantes.MODAL_DANGER);
          return false;
        }
      }

      //validar codTipoDocUsuario
      if (isNotEmpty(this.solicitudProgramacion.numDocUsuario)) {
        if (!isNotEmpty(this.solicitudProgramacion.codTipoDocUsuario)) {
          this.utilService.alertaMensaje('Seleccionar tipo de documento del usuario', Constantes.MODAL_PRIMARY);
          return false;
        }
      }

      //Validar que DNI tenga 8 digitos
      if(trim(this.filtro.codTipoDocUsuario) == Constantes.TIPO_DOCUMENTO_DNI && trim(this.filtro.numDocUsuario).length != 8){
        this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_002, Constantes.MODAL_DANGER);
        return false;
      }

      //Validar que RUC tenga 11 digitos
      if(trim(this.filtro.codTipoDocUsuario) == Constantes.TIPO_DOCUMENTO_RUC && trim(this.filtro.numDocUsuario).length != 11){
        this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_002, Constantes.MODAL_DANGER);
        return false;
      }

      this.gestionSolicitudService.listarSolicitudProgramacion(this.solicitudProgramacion).subscribe(
        result => {
          if (result.exito) {
            this.solicitudesProgramacion = result.data;
          } else {
            console.log(result.mensaje);
            if(this.opcionAnular == false) this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_SIN_RESULTADO, Constantes.MODAL_PRIMARY);
          }
        },
        error => {
          console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
        }
      );
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
    }
  }

  eliminarSolicitudProgramacion(numSolicProg: string){
    this.opcionAnular = true;
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,Constantes.MODAL_MENSAJE_ANULAR_SOLICITUD,Constantes.MODAL_PRIMARY, () => {
      this.gestionSolicitudService.eliminarSolicitudProgramacion(numSolicProg).subscribe(
        result => {
          if (result.exito) {
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_ANULAR, Constantes.MODAL_SUCCESS);
            this.listarSolicitudProgramacion();
          } else {
            this.utilService.alertaMensaje(`${MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_ANULADOS}. ${result.mensaje}`, Constantes.MODAL_DANGER);
          }
        },
        error => {
          console.log(MensajesExcepciones.MENSAJE_INFORMATIVO_HUBO_ERRORES, error);
          this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_INFORMATIVO_DATOS_NO_ANULADOS, Constantes.MODAL_DANGER);
        }
      );
    });
  }
  //Fin metodos Web Service
}
