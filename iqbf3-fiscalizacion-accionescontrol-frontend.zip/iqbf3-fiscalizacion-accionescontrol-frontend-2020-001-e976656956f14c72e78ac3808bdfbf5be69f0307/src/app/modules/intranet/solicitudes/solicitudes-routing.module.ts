import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GestionSolicitudesProgramacionComponent } from './components/gestion-solicitudes-programacion/gestion-solicitudes-programacion.component';
import { EvaluacionSolicitudProgramacionComponent } from './components/evaluacion-solicitud-programacion/evaluacion-solicitud-programacion.component';
import { AsignacionSolicitudProgramacionComponent } from './components/asignacion-solicitud-programacion/asignacion-solicitud-programacion.component';
import { CalificarSolicitudProgramacionComponent } from './components/calificar-solicitud-programacion/calificar-solicitud-programacion.component';
import { FormularioSolicitudComponent } from './components/gestion-solicitudes-programacion/formulario-solicitud/formulario-solicitud.component';
import { EvaluarSolicitudComponent } from './components/evaluacion-solicitud-programacion/evaluar-solicitud/evaluar-solicitud.component';
import { CalificarSolicitudComponent } from './components/calificar-solicitud-programacion/calificar-solicitud/calificar-solicitud.component';
import { DetalleSolicitudComponent } from './components/gestion-solicitudes-programacion/detalle-solicitud/detalle-solicitud.component'
const routes: Routes = [
  {path: 'gestion-solicitudes-programacion', component: GestionSolicitudesProgramacionComponent},
  {path: 'gestion-solicitudes-programacion/formulario', component: FormularioSolicitudComponent},
  {path: 'gestion-solicitudes-programacion/formulario/:numSolicProg', component: FormularioSolicitudComponent},
  // {path: 'gestion-solicitudes-programacion/detalle', component: DetalleSolicitudComponent},
  {path: 'gestion-solicitudes-programacion/detalle/:numSolicProg', component: DetalleSolicitudComponent},
  {path: 'evaluacion-solicitud-programacion', component: EvaluacionSolicitudProgramacionComponent},
  {path: 'asignacion-solicitud-programacion', component: AsignacionSolicitudProgramacionComponent},
  {path: 'calificar-solicitud-programacion', component: CalificarSolicitudProgramacionComponent},
  {path: 'evaluacion-solicitud-programacion/evaluar-solicitud/:numSolicProg', component: EvaluarSolicitudComponent},
  {path: 'calificar-solicitud-programacion/calificar-solicitud/:numSolicProg', component: CalificarSolicitudComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SolicitudesRoutingModule { }
