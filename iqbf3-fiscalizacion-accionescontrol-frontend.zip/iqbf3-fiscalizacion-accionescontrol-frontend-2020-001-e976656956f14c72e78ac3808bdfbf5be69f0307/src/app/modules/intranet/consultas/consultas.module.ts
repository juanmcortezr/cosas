import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConsultasRoutingModule } from './consultas-routing.module';
import { SolicitudesProgramacionComponent } from './components/solicitudes-programacion/solicitudes-programacion.component';
import { ProgramacionesComponent } from './components/programaciones/programaciones.component';
import { primeNgModule } from 'src/app/app-primeng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IqbfModule } from 'iqbf';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModulesModule } from '../../modules.module';


@NgModule({
  declarations: [SolicitudesProgramacionComponent, ProgramacionesComponent],
  imports: [
    CommonModule,
    ConsultasRoutingModule,
    primeNgModule,
    FormsModule,
    IqbfModule,
    NgbModule,
    ModulesModule,
    ReactiveFormsModule,
  ]
})
export class ConsultasModule { }
