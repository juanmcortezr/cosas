import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SolicitudesProgramacionComponent } from './components/solicitudes-programacion/solicitudes-programacion.component';
import { ProgramacionesComponent } from './components/programaciones/programaciones.component';


const routes: Routes = [
  {path: 'solicitudes-programacion', component: SolicitudesProgramacionComponent},
  {path: 'programaciones', component: ProgramacionesComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConsultasRoutingModule { }
