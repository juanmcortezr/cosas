import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CatalogoService, InterfazCatalogo } from 'iqbf';
import { HttpClient } from '@angular/common/http';
import { UtilService } from 'src/app/services/shared/util.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { stringToMomentDDMMYYYY, dateToStringDDMMYYYY } from 'src/app/utils/utilitarios';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { ExcelService } from 'iqbf';
import { tsXLXS } from 'ts-xlsx-export';
import { Constantes } from 'src/app/utils/constantes';
import { ConsultaProgramacionService } from 'src/app/services/consulta-programacion.service';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { Programacion, ProgramacionBean, ExportExcelProgramacion } from 'src/app/models/programacion.model';
import { CheckElement } from 'src/app/models/checkElement.model';


@Component({
  selector: 'app-programaciones',
  templateUrl: './programaciones.component.html',
  styleUrls: ['./programaciones.component.css']
})
export class ProgramacionesComponent implements OnInit {

  formBusqueda: FormGroup;
  tipoDocUsuario: InterfazCatalogo.Catalogo[] = [];
  tipoOrdenes: InterfazCatalogo.Catalogo[] = [];
  tipoEstadoOrdenes: InterfazCatalogo.Catalogo[] = [];
  progControl: InterfazCatalogo.Catalogo[] = [];
  tipoIntervenciones: InterfazCatalogo.Catalogo[] = [];
  tipoAccion: InterfazCatalogo.Catalogo[] = [];
  estadoInformes: InterfazCatalogo.Catalogo[] = [];
  submitted: boolean = false;
  mensaje: string;
  private serEx: ExcelService;
  solicitudes: Programacion[];
  isSolicitudEmpty: boolean = true;

  constructor(
    private router: Router,
    private catalogoService: CatalogoService,
    private consultaProgramacionService: ConsultaProgramacionService,
    private http: HttpClient,
    private utilService: UtilService,
    private formBuilder: FormBuilder,
    private rutaActiva: ActivatedRoute
  ) {
    this.createForm();
    this.cargarTiposOrdenes();
    this.cargarTiposDocUsuario();
    this.cargarTiposEstadoOrdenes();
    this.cargarTiposProgControl();
    this.cargarTiposInterveciones();
    this.cargarTiposAcciones();
    this.cargarEstadoInformes();
  }

  ngOnInit() {
  }

  private createForm() {
    this.formBusqueda = this.formBuilder.group({
      cboProgCtl: '',
      cboTipoDoc: '',
      nroDoc: '',
      cboTipOrden: '',
      txtCalendarDesde: '',
      txtCalendarHasta: '',
      nroInfSele: '',
      cboTipInterv: '',
      cboTipAccion: '',
      cboEstInfSele: '',
      nomApAuditorAsig: '',
      cboEstOrden: '',
      nomApAuditorApoyo: '',
      chkInconsistencia1: false,
      chkInconsistencia2: false,
      chkInconsistencia3: false,
      chkInconsistencia4: false,
      chkInconsistencia5: false,
      chkInconsistencia6: false,
      chkInconsistencia7: false,
      chkInconsistencia8: false,
      chkInconsistencia9: false,
      chkInconsistencia10: false,
      chkInconsistencia11: false,
      chkTipBien1: false,
      chkTipBien2: false,
      chkTipBien3: false,
      chkTipBien4: false,
      chkBienFiscal1: false,
      chkBienFiscal2: false,
      chkBienFiscal3: false,
    });
  }

  cargarEstadoInformes(): void {
    this.estadoInformes = [];
    this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_ESTADO_SOLICITUD).subscribe(
      result => {
        this.estadoInformes = result.data;
      },
      error => {
        console.log("Hubo errores ", error);
      }
    )
  }

  cargarTiposAcciones(): void {
    this.tipoAccion = [];
    this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL).subscribe(
      result => {
        this.tipoAccion = result.data;
      },
      error => {
        console.log("Hubo errores ", error);
      }
    )
  }

  cargarTiposInterveciones(): void {
    this.tipoIntervenciones = [];
    this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_TIPO_INTERVENCION).subscribe(
      result => {
        this.tipoIntervenciones = result.data;
      },
      error => {
        console.log("Hubo errores ", error);
      }
    )
  }

  cargarTiposDocUsuario(): void {
    this.tipoDocUsuario = [];
    this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF).subscribe(
      result => {
        this.tipoDocUsuario = result.data;
      },
      error => {
        console.log("Hubo errores ", error);
      }
    )
  }

  cargarTiposOrdenes(): void {
    this.tipoOrdenes = [];
    this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_TIPO_ORDENES).subscribe(
      result => {
        this.tipoOrdenes = result.data;
      },
      error => {
        console.log("Hubo errores ", error);
      }
    )
  }

  cargarTiposEstadoOrdenes(): void {
    this.tipoEstadoOrdenes = [];
    this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_ESTADO_ORDEN).subscribe(
      result => {
        this.tipoEstadoOrdenes = result.data;
      },
      error => {
        console.log("Hubo errores ", error);
      }
    )
  }

  cargarTiposProgControl(): void {
    this.progControl = [];
    this.catalogoService.obtenerCatalogo(ConstantesCatalogo.COD_CATALOGO_FUENTES_PROGRAMAS).subscribe(
      result => {
        this.progControl = result.data;
      },
      error => {
        console.log("Hubo errores ", error);
      }
    )
  }

  validarFechaDesde() {
    let fechaDesde = this.formBusqueda.get('txtCalendarDesde').value;
    let fechaHasta = this.formBusqueda.get('txtCalendarHasta').value;
    const momentDesde = stringToMomentDDMMYYYY(fechaDesde);
    const momentHasta = stringToMomentDDMMYYYY(fechaHasta);
    this.submitted = false;
    if (momentDesde.isAfter(momentHasta)) {
      this.mensaje = MensajesExcepciones.CUS22_EXCP_002;
      this.submitted = true;
    }
    return this.submitted;
  }
  validarFechaHasta() {
    let fechaDesde = this.formBusqueda.get('txtCalendarDesde').value;
    let fechaHasta = this.formBusqueda.get('txtCalendarHasta').value;
    const momentDesde = stringToMomentDDMMYYYY(fechaDesde);
    const momentHasta = stringToMomentDDMMYYYY(fechaHasta);
    const momentToday = stringToMomentDDMMYYYY(dateToStringDDMMYYYY(new Date()));
    this.submitted = false;
    if (momentHasta.isBefore(momentDesde)) {
      this.mensaje = MensajesExcepciones.CUS22_EXCP_001;
      this.submitted = true;
    } else if (momentHasta.isAfter(momentToday)) {
      this.mensaje = MensajesExcepciones.CUS22_EXCP_003;
      this.submitted = true;
    }
    return this.submitted;
  }

  buscarProgramacion(): void {

    let cboProgCtl = this.formBusqueda.get('cboProgCtl').value;
    let cboTipoDoc = this.formBusqueda.get('cboTipoDoc').value;
    let nroDoc = this.formBusqueda.get('nroDoc').value;
    let cboTipOrden = this.formBusqueda.get('cboTipOrden').value;
    let txtCalendarDesde = this.formBusqueda.get('txtCalendarDesde').value;
    let txtCalendarHasta = this.formBusqueda.get('txtCalendarHasta').value;
    let nroInfSele = this.formBusqueda.get('nroInfSele').value;
    let cboTipInterv = this.formBusqueda.get('cboTipInterv').value;
    let cboTipAccion = this.formBusqueda.get('cboTipAccion').value;
    let cboEstInfSele = this.formBusqueda.get('cboEstInfSele').value;
    let nomApAuditorAsig = this.formBusqueda.get('nomApAuditorAsig').value;
    let cboEstOrden = this.formBusqueda.get('cboEstOrden').value;
    let nomApAuditorApoyo = this.formBusqueda.get('nomApAuditorApoyo').value;
    let chkInconsistencia1 = this.formBusqueda.get('chkInconsistencia1').value;
    let chkInconsistencia2 = this.formBusqueda.get('chkInconsistencia2').value;
    let chkInconsistencia3 = this.formBusqueda.get('chkInconsistencia3').value;
    let chkInconsistencia4 = this.formBusqueda.get('chkInconsistencia4').value;
    let chkInconsistencia5 = this.formBusqueda.get('chkInconsistencia5').value;
    let chkInconsistencia6 = this.formBusqueda.get('chkInconsistencia6').value;
    let chkInconsistencia7 = this.formBusqueda.get('chkInconsistencia7').value;
    let chkInconsistencia8 = this.formBusqueda.get('chkInconsistencia8').value;
    let chkInconsistencia9 = this.formBusqueda.get('chkInconsistencia9').value;
    let chkInconsistencia10 = this.formBusqueda.get('chkInconsistencia10').value;
    let chkInconsistencia11 = this.formBusqueda.get('chkInconsistencia11').value;
    let chkTipBien1 = this.formBusqueda.get('chkTipBien1').value;
    let chkTipBien2 = this.formBusqueda.get('chkTipBien2').value;
    let chkTipBien3 = this.formBusqueda.get('chkTipBien3').value;
    let chkTipBien4 = this.formBusqueda.get('chkTipBien4').value;
    let chkBienFiscal1 = this.formBusqueda.get('chkBienFiscal1').value;
    let chkBienFiscal2 = this.formBusqueda.get('chkBienFiscal2').value;
    let chkBienFiscal3 = this.formBusqueda.get('chkBienFiscal3').value;

    if (this.validar(txtCalendarDesde) || this.validar(txtCalendarHasta)) {
      this.mensaje = "Debe un rango de periodo de consulta de un año como máximo.";
      this.submitted = true;
      return;
    }

    if (this.validarFechaDesde() || this.validarFechaHasta()) {
      return;
    }

    const momentDesde = stringToMomentDDMMYYYY(txtCalendarDesde);
    const momentHasta = stringToMomentDDMMYYYY(txtCalendarHasta);

    let resta = momentHasta.diff(momentDesde, 'days');

    if (resta > 365) {
      this.mensaje = "Debe un rango de periodo de consulta de un año como máximo.";
      this.submitted = true;
      return;
    }

    if (cboTipoDoc == Constantes.TIPO_DOCUMENTO_DNI && nroDoc.length !== 8) {
      this.mensaje = "El número de documento ingresado es incorrecto.";
      this.submitted = true;
      return;
    }

    if (cboTipoDoc == Constantes.TIPO_DOCUMENTO_RUC && nroDoc.length !== 11) {
      this.mensaje = "El número de documento ingresado es incorrecto.";
      this.submitted = true;
      return;
    }

    if (nomApAuditorAsig.length < 4 && nomApAuditorApoyo.length < 4) {
      this.mensaje = "El nombre ingresado es muy corto.";
      this.submitted = true;
      return;
    }

    this.mensaje = "";
    this.submitted = false;

    let filtroIncos :CheckElement[] = []; 
    let filtrotipoBien :CheckElement[] = []; 
    let filtroBienFiscal :CheckElement[] = []; 
    let check:CheckElement;

    if (chkInconsistencia1 == true){check = new CheckElement("01","Diferencias en egresos (Declarados vs Imputados)",true); filtroIncos.push(check)}
    if (chkInconsistencia2 == true){check = new CheckElement("02","Diferencias en exportaciones (SICOBF vs Aduanet)",true); filtroIncos.push(check)}
    if (chkInconsistencia3 == true){check = new CheckElement("03","Diferencias en exportaciones (SICOBF vs Autorizaciones de Salidas)",true); filtroIncos.push(check)}
    if (chkInconsistencia4 == true){check = new CheckElement("04","Diferencias en importaciones (SICOBF vs Aduanet)",true); filtroIncos.push(check)}
    if (chkInconsistencia5 == true){check = new CheckElement("05","Diferencias en importaciones (SICOBF vs Autorizaciones de Ingreso)",true); filtroIncos.push(check)}
    if (chkInconsistencia6 == true){check = new CheckElement("06","Diferencias en ingresos (Declarados vs Imputados)",true); filtroIncos.push(check)}
    if (chkInconsistencia7 == true){check = new CheckElement("15","Omisos",true); filtroIncos.push(check)}
    if (chkInconsistencia8 == true){check = new CheckElement("13","Stock y cantidad autorizada negativo",true); filtroIncos.push(check)}
    if (chkInconsistencia9 == true){check = new CheckElement("16","Usuario de Baja con stock",true); filtroIncos.push(check)}
    if (chkInconsistencia10 == true){check = new CheckElement("09","GRE no confirmadas - Destinatario",true); filtroIncos.push(check)}
    if (chkInconsistencia11 == true){check = new CheckElement("08","GRE no confirmadas - Transportista",true); filtroIncos.push(check)}

    if (chkTipBien1 == true){check = new CheckElement("1","INSUMO",true); filtrotipoBien.push(check)}
    if (chkTipBien2 == true){check = new CheckElement("2","COMBUSTIBLE",true); filtrotipoBien.push(check)}
    if (chkTipBien3 == true){check = new CheckElement("4","DISOLVENTE",true); filtrotipoBien.push(check)}
    if (chkTipBien4 == true){check = new CheckElement("5","MEZCLA",true); filtrotipoBien.push(check)}

    if (chkBienFiscal1 == true){check = new CheckElement("001","ACETONA",true); filtroBienFiscal.push(check)}
    if (chkBienFiscal2 == true){check = new CheckElement("002","ACETATO DE ETILO",true); filtroBienFiscal.push(check)}
    if (chkBienFiscal3 == true){check = new CheckElement("003","ACIDO SULFURICO",true); filtroBienFiscal.push(check)}
    
    let filtro: ProgramacionBean = new ProgramacionBean();
    filtro = {
      codProgramaControl: cboProgCtl,
      codTipoDocumentoIdent: cboTipoDoc,
      numDocumentoIdent: nroDoc,
      numInforme: nroInfSele,
      codTipoOrden: cboTipOrden,
      fechaDesde: txtCalendarDesde,
      fechaHasta: txtCalendarHasta,
      codTipInterv: cboTipInterv,
      codTipoAccion: cboTipAccion,
      codEstadoInforme: cboEstInfSele,
      nombAuditAsignad: nomApAuditorAsig,
      codEstOrden: cboEstOrden,
      nombAuditApoyo: nomApAuditorApoyo,
      inconsistencias:filtroIncos,
      tipoBienes:filtrotipoBien,
      bienesFiscalizados:filtroBienFiscal
    }

    this.consultaProgramacionService.listarConsultaSolicitudProgramacion(filtro).subscribe(
      result => {
        console.log("resultado : " + result);
        this.solicitudes = result;
        if (this.solicitudes == undefined || this.solicitudes.length == 0) {
          this.mensaje = "No existe datos.";
          this.submitted = true;
          this.isSolicitudEmpty = true;
        } else {
          this.mensaje = "";
          this.submitted = false;
          this.isSolicitudEmpty = false;

        }
      },
      error => {
        console.log("Hubo errores ", error);
      }
    )


  }

  exportar(): void {
    let listaExpProg: ExportExcelProgramacion[] = [];
    let fechaActual: Date = new Date();
    let fechaActualstr: string = fechaActual.getFullYear() + pad((fechaActual.getMonth() + 1)) + pad(fechaActual.getDate());

    this.solicitudes.forEach(item => {
      let expProg: ExportExcelProgramacion = new ExportExcelProgramacion();
      expProg.nro_programacion = item.numProgramacion;
      expProg.programa_control = item.desProgramaControl;
      expProg.inconsistencia = item.desInconsistecia;
      expProg.resultado_inconsistencia = item.desRespInconsistencia;
      expProg.periodo_inicio = item.perInicio;
      expProg.periodo_fin = item.perFin;
      expProg.tipo_documento = item.desTipoDocumentoIdent;
      expProg.nro_documento_usuario = item.numDocumentoIdent;
      expProg.nombre_o_razon_social = item.nombApeUsuario;
      expProg.nro_informe_seleccion = item.numInforme;
      expProg.estado_informe = item.desEstadoInforme;
      expProg.tipo_accion = item.desTipoAccion;
      expProg.nro_documento_accion = item.numDocAccion;
      expProg.tipo_orden = item.desTipOrden;
      expProg.nro_orden = item.numOrden;
      expProg.estado_orden = item.desEstOrden;
      expProg.auditor_asignado = item.nombAuditAsignad;
      expProg.resultado_orden = item.desResOrden;
      expProg.nro_documento_vinculado = item.numDocVin;

      listaExpProg.push(expProg);
    });
    tsXLXS().exportAsExcelFile(listaExpProg).saveAsExcelFile('Lista_Consulta_De_Programaciones_' + fechaActualstr);
  }


  limpiar(): void {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate(['consultas/programaciones']));
  }

  validar(dato: any): boolean {
    return dato == undefined || dato == '';
  }


}

function pad(n: number): string {
  return n < 10 ? "0" + n.toString() : n.toString();
}