import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Constantes } from 'src/app/utils/constantes';
import { UtilService } from 'src/app/services/shared/util.service';
import { SolicitudProgramacion } from 'src/app/models/solicitudProgramacion.model';
import { ConsultaSolicitudService } from 'src/app/services/consulta-solicitud.service';
import { Catalogo } from 'src/app/models/catalogo.model';
import { BienFiscalizadoSolicitud } from 'src/app/models/bienFiscalizadoSolicitud.model';
import { CatalogoService } from 'src/app/services/maestros/catalogo.service';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { ConstantesCatalogo } from 'src/app/utils/constantes-catalogo';
import { stringToMoment, compareTwoDates, isNotEmpty, isEmpty, trim, toNumber, stringToMomentDDMMYYYY } from 'src/app/utils/utilitarios';

@Component({
  selector: 'app-solicitudes-programacion',
  templateUrl: './solicitudes-programacion.component.html',
  styleUrls: ['./solicitudes-programacion.component.css']
})
export class SolicitudesProgramacionComponent implements OnInit {

  /* inicio Declaracion Variables */
  //Catalogos
  catalogoTipoDocUsuario: string;
  catalogoEstadoSolicitud: string;
  catalogoTipoIntervencion: string;
  catalogoTipoAccion: string;

  // Variables
  solicitudProgramacion: SolicitudProgramacion = new SolicitudProgramacion();
  solicitudesProgramacion: SolicitudProgramacion[] = [];

  //Accion
  listaPermitidosTipoAccion: string[] = [];

  //Fechas
  desdeObligatorio: boolean = false;
  hastaObligatorio: boolean = false;

  validTipDoc: any = {
    "maxLenght": '',
    "tipoDoc": '',
    "tipoVal": ''
  };

  //Chk Inconsistencias - Tipo Bienes - Bienes Fiscalizados
  catalogoTipoIncosistencias: string;
  catalogoTipoBien: string;
  catalogoInconsistencias: Catalogo[] = [];
  catalogoTipoBienes: Catalogo[] = [];

  bienesFiscalizados: BienFiscalizadoSolicitud[] = [];
  arrayCkbInconsistencias: Catalogo[] = [];
  arrayCkbTipoBienes: Catalogo[] = [];
  arrayCkbBienesFiscalizados: BienFiscalizadoSolicitud[] = [];

  agregarCkb: boolean = true; //Agregar checkbox
  quitarCkb: boolean = false; //Quitar checkbox

  estadoCkbInconsistencia: boolean = true;
  estadoCkbTipoBien: boolean = true;

  estadoTouchedInconsistencia: boolean = false;
  estadoTouchedTipoBien: boolean = false;
  estadoTouchedBienFisca: boolean = false;

  /* Fin Declaracion Variables */
  constructor(private router: Router,
    private catalogoService: CatalogoService,
    private utilService: UtilService,
    private rutaActiva: ActivatedRoute,
    private consultaSolicitudService: ConsultaSolicitudService) { }

  ngOnInit() {
    this.inicio();
    this.limpiarcampos();
  }

  inicio() {
    this.catalogoTipoDocUsuario = ConstantesCatalogo.COD_CATALOGO_TIPDOCIDENTIF;
    this.catalogoEstadoSolicitud = ConstantesCatalogo.COD_CATALOGO_ESTADO_SOLICITUD;
    this.catalogoTipoIntervencion = ConstantesCatalogo.COD_CATALOGO_TIPO_INTERVENCION;
    this.catalogoTipoAccion = ConstantesCatalogo.COD_CATALOGO_TIPO_ACCIONCONTROL;
    this.catalogoTipoIncosistencias = ConstantesCatalogo.COD_CATALOGO_TIPO_INCONSISTENCIAS;
    this.catalogoTipoBien = ConstantesCatalogo.COD_CATALOGO_TIPO_BIEN;
    this.listarCatalogoInconsistencias();
    this.listarCatalogoTipoBienes();
  }

  limpiarcampos() {
    this.solicitudProgramacion = new SolicitudProgramacion();
    this.solicitudesProgramacion = [];
    this.listaPermitidosTipoAccion = [];
    this.obligatoriedadFechas(false, false);
    this.listarCatalogoInconsistencias();
    this.listarCatalogoTipoBienes();
    this.bienesFiscalizados = [];
    this.arrayCkbInconsistencias = [];
    this.arrayCkbTipoBienes = [];
    this.arrayCkbBienesFiscalizados = [];

  }

  //Eventos combo
  eventoCboCodTipoDocIdentif(codTipDoc: string) {
    this.solicitudProgramacion.numDocUsuario = '';
    if (codTipDoc == Constantes.TIPO_DOCUMENTO_DNI) {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_DNI;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_DNI;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }
    else if (codTipDoc == Constantes.TIPO_DOCUMENTO_RUC) {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_RUC;
      this.validTipDoc.tipoDoc = Constantes.TIPO_DOCUMENTO_RUC;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBER;
    }
    else {
      this.validTipDoc.maxLenght = Constantes.MAX_LENGHT_DOC_OTROS;
      this.validTipDoc.tipoDoc = Constantes.VALOR_VACIO;
      this.validTipDoc.tipoVal = Constantes.TIPO_VALI_ONLYNUMBERLETTER;
    }
  }

  eventoCodTipoIntervencion(value: string) {
    if (value == Constantes.TIPO_INTERVENCION_CONTROL) {
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_CARTA, Constantes.TIPO_ACCION_ESQUELA];
    } else if (value == Constantes.TIPO_INTERVENCION_FISCALIZACION) {
      this.listaPermitidosTipoAccion = [Constantes.TIPO_ACCION_VISITA_PROGRAMADA, Constantes.TIPO_ACCION_VISITA_NO_PROGRAMADA];
    } else {
      this.listaPermitidosTipoAccion = [];
    }
  }

  //Validaciones formControl
  eventoCkbInconsistencias(valor: string, opcion: boolean) {
    let catalogo: Catalogo = null;
    if (opcion) {
      catalogo = this.catalogoInconsistencias.find(inconsistencia => inconsistencia.codDataCatalogo === valor);//Agregar
      this.arrayCkbInconsistencias.push(catalogo);
    } else {
      this.arrayCkbInconsistencias = this.solicitudProgramacion.inconsistencias.filter(inconsistencia => inconsistencia.codDataCatalogo !== valor);//Quitar
    }
    //Cargar Inconsistencias a SolicitudProgramacion
    this.solicitudProgramacion.inconsistencias = this.arrayCkbInconsistencias;
  }

  async eventoCkbTipoBien(valor: string, opcion: boolean) {
    let catalogo: Catalogo = null;
    if (opcion) {
      catalogo = this.catalogoTipoBienes.find(bien => bien.codDataCatalogo === valor);//Agregar
      this.arrayCkbTipoBienes.push(catalogo);
    } else {
      this.arrayCkbTipoBienes = this.solicitudProgramacion.tipoBienes.filter(bien => bien.codDataCatalogo !== valor);//Quitar
    }
    //Limpieza Check
    this.arrayCkbBienesFiscalizados = this.arrayCkbBienesFiscalizados.filter(T => T.codTipoBien != valor);
    //Cargar TipoBienes a SolicitudProgramacion
    this.solicitudProgramacion.tipoBienes = this.arrayCkbTipoBienes;
    await this.listarBienesFiscalizados();
  }

  eventoCkbFiscalizados(valor: string, opcion: boolean) {
    let bienFiscalizado: BienFiscalizadoSolicitud = null;
    if (opcion) {
      bienFiscalizado = this.bienesFiscalizados.find(bf => bf.codBienFiscalizado === valor);//Agregar
      this.arrayCkbBienesFiscalizados.push(bienFiscalizado);
    } else {
      this.arrayCkbBienesFiscalizados = this.solicitudProgramacion.bienesFiscalizados.filter(bf => bf.codBienFiscalizado !== valor);//Quitar
    }
    //Cargar BienesFiscalizados a SolicitudProgramacion
    this.solicitudProgramacion.bienesFiscalizados = this.arrayCkbBienesFiscalizados;
  }

  validarRangoFechas(): boolean {
    let fechaTmp = null;
    let fechaLimite: string = '';
    let rango: number = null;
    let validado = true;

    fechaTmp = stringToMomentDDMMYYYY(this.solicitudProgramacion.fechaDesde);
    fechaLimite = (fechaTmp.add('years', 1).format(Constantes.FORMAT_FECHA_DDMMYYYY)).toString();
    rango = compareTwoDates(fechaLimite, this.solicitudProgramacion.fechaHasta);

    if (rango == toNumber(Constantes.COMPARE_MOMENT_AFTER)) {
      validado = false;
    } else if (rango == toNumber(Constantes.COMPARE_MOMENT_BEFORE)
      || rango == toNumber(Constantes.COMPARE_MOMENT_SAME)) {
      validado = true;
    }
    console.log('fechaDesde', fechaTmp);
    console.log('fechaLimite', fechaLimite);
    console.log('fechaHasta', this.solicitudProgramacion.fechaHasta);
    console.log('rango', rango);

    console.log('1 - Antes | 0 - Igual | -1 - Despues = la rpta es ', rango);

    return validado;
  }

  obligatoriedadFechas(a: boolean, b: boolean) {
    this.desdeObligatorio = a;
    this.hastaObligatorio = b;
  }


  eventoFechas(desde: string, hasta: string) {
    if (isNotEmpty(desde) && isNotEmpty(hasta)) {
      this.obligatoriedadFechas(false, false);
      if (compareTwoDates(hasta, desde).toString() == Constantes.COMPARE_MOMENT_AFTER) {
        this.obligatoriedadFechas(true, true);
        this.utilService.alertaMensaje(MensajesExcepciones.CUS05_EXCP_005, Constantes.MODAL_DANGER);
        return false;
      }
    }
    else {
      this.obligatoriedadFechas(false, false);
    }
  }
  /*Fin metodos componente*/

  /*Ini metodos Web Service*/
  async listarCatalogoInconsistencias() {
    this.catalogoInconsistencias = [];
    let catalogoInconsistenciasTemp: Catalogo[] = [];

    let result = await this.catalogoService.obtenerCatalogo(this.catalogoTipoIncosistencias).toPromise();

    if (result.exito) {
      catalogoInconsistenciasTemp = result.data;
      this.catalogoInconsistencias = catalogoInconsistenciasTemp;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de inconsistencias => ${result.mensaje}`);
    }
  }

  async listarCatalogoTipoBienes() {
    this.catalogoTipoBienes = [];
    let catalogoTipoBienesTemp: Catalogo[] = [];

    let result = await this.catalogoService.obtenerCatalogo(this.catalogoTipoBien).toPromise();

    if (result.exito) {
      catalogoTipoBienesTemp = result.data;
      // catalogoTipoBienesTemp.push(new Catalogo(Constantes.OPCION_CODIGO_OTROS, Constantes.OPCION_NOMBRE_OTROS));
      this.catalogoTipoBienes = catalogoTipoBienesTemp;
    } else {
      console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de tipos de bienes => ${result.mensaje}`);
    }
  }

  async listarBienesFiscalizados() {
    this.bienesFiscalizados = [];
    let bienesFiscalizadosTemp: BienFiscalizadoSolicitud[] = [];

    if (this.arrayCkbTipoBienes != null && this.arrayCkbTipoBienes.length > 0) {
      this.arrayCkbTipoBienes.forEach(async t => {
        if (t.codDataCatalogo != Constantes.OPCION_CODIGO_OTROS) {
          let result = await this.consultaSolicitudService.listarBienesFiscalizados(t.codDataCatalogo).toPromise();
          if (result.exito) {
            bienesFiscalizadosTemp = bienesFiscalizadosTemp.concat(result.data);
            this.bienesFiscalizados = bienesFiscalizadosTemp;
          } else {
            console.log(`${MensajesExcepciones.MENSAJE_INFORMATIVO_SIN_OBTENER_RESULTADO} de bienes fiscalizados => ${result.mensaje}`);
          }
        }
      });
    }
  }

  listarConsultaProgramacion() {
    console.log('Consultar solicitud');
    this.solicitudesProgramacion = [];

    if (this.solicitudProgramacion.filtroConsultasoli()) {
      // validar numDocUsuario
      if (isNotEmpty(this.solicitudProgramacion.codTipoDocUsuario)) {
        if (isNotEmpty(this.solicitudProgramacion.numDocUsuario)) {
          if ((this.solicitudProgramacion.codTipoDocUsuario == Constantes.TIPO_DOCUMENTO_DNI
            && this.solicitudProgramacion.numDocUsuario.length < 8)
            || (this.solicitudProgramacion.codTipoDocUsuario == Constantes.TIPO_DOCUMENTO_RUC
              && this.solicitudProgramacion.numDocUsuario.length < 11)) {
            this.utilService.alertaMensaje(MensajesExcepciones.CUS02_EXCP_002, Constantes.MODAL_DANGER);
            return false;
          }
        }
      }

      if (isNotEmpty(this.solicitudProgramacion.fechaDesde) && isNotEmpty(this.solicitudProgramacion.fechaHasta)) {
        this.eventoFechas(this.solicitudProgramacion.fechaDesde, this.solicitudProgramacion.fechaHasta);
        if (this.validarRangoFechas() != true) {
          this.obligatoriedadFechas(false, true);
          this.utilService.alertaMensaje(MensajesExcepciones.CUS05_EXCP_004, Constantes.MODAL_DANGER);
          return false;
        }

      }

      if (isNotEmpty(this.solicitudProgramacion.nomSolicitante)) {
        if (this.solicitudProgramacion.nomSolicitante.length < 3) {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS05_EXCP_003, Constantes.MODAL_DANGER);
          return false;
        }
      }

      this.consultaSolicitudService.listarConsultaProgramacion(this.solicitudProgramacion).subscribe(
        result => {
          if (result.exito) {
            this.solicitudesProgramacion = result.data;
          } else {
            console.log(result.mensaje);
            this.utilService.alertaMensaje('No se ha encontrado resultados de b\u00fasqueda', Constantes.MODAL_PRIMARY);
          }
        },
        error => {
          console.log("Hubo errores ", error);
        }
      );
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
    }
  }
  /*Fin metodos Web Service*/
}
