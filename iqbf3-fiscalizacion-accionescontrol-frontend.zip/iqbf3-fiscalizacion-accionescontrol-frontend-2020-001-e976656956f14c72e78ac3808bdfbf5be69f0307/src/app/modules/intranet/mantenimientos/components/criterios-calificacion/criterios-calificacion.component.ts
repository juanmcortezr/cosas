import { Component, OnInit } from '@angular/core';
import { CriterioCalificacion } from 'src/app/models/criterioCalificacion.model';
import { Router } from '@angular/router';
import { MantenimientoCriterioService } from 'src/app/services/mantenimiento-criterio.service';
import { Constantes } from 'src/app/utils/constantes';
import { trim, isNotEmpty, toNumber } from 'src/app/utils/utilitarios';
import { UtilService } from 'src/app/services/shared/util.service';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { timeout } from 'rxjs/operators';
import { AlternativaCriterio } from 'src/app/models/alternativaCriterio.model';
import { AccionSugeridaCalif } from 'src/app/models/accionSugeridaCalif.model';

@Component({
  selector: 'app-criterios-calificacion',
  templateUrl: './criterios-calificacion.component.html',
  styleUrls: ['./criterios-calificacion.component.css']
})
export class CriteriosCalificacionComponent implements OnInit {

  // Inicio declaracion
  tipoLBL: string;
  pesoAcumulativo: number = 0;
  pesoTotal: number = 0;

  verMsgAlternativa: boolean = false;
  verMsgCriterio: boolean = false;

  criterioCalificacion: CriterioCalificacion = new CriterioCalificacion();
  listarCriterioCalificaciones: CriterioCalificacion[] = [];
  tituloCriterio: string = '';
  criterio: any = {};

  alternativaCriterio: AlternativaCriterio = new AlternativaCriterio();
  listarAlternativaCriterios: AlternativaCriterio[] = [];
  altercriterio: any = {};

  accionSugeridaCalif: AccionSugeridaCalif = new AccionSugeridaCalif();
  listarAccionesSugeridasCalif: AccionSugeridaCalif[] = [];
  accsugerida: any = {};

  hiddeTable = true;
  valiCriCali: FormGroup;
  valiAlterCri: FormGroup;
  valiAccionSuge: FormGroup;
  // Fin declaracion

  constructor(private router: Router,
              private mantenimientoCriterioService: MantenimientoCriterioService,
              private utilService: UtilService) {}

  ngOnInit() {
    this.inicio();
    this.cargarMantenimientoCriterio();
    this.cargarAccsugerida();
  }

  inicio() {
    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;

    //Validaciones Criterios de calificación
    this.valiCriCali = new FormGroup({
      desCriterio: new FormControl('', [Validators.required]),
      porPeso: new FormControl('', [Validators.required])
    });

    //Validaciones Alternativas por Criterio
    this.valiAlterCri = new FormGroup({
      desAlternativa: new FormControl('', [Validators.required]),
      valAlternativa: new FormControl('', [Validators.required])
    });

    //Validaciones Acciones Sugeridas
    this.valiAccionSuge = new FormGroup({
      desAccionSugerida: new FormControl('', [Validators.required]),
      valMinimo: new FormControl('', [Validators.required]),
      valMaximo: new FormControl('', [Validators.required])
    });
  }

  resetearFormGroup(){
    //Setear formGroug
    this.valiCriCali.reset();
    this.valiCriCali.get('desCriterio').setValue('');
    this.valiCriCali.get('porPeso').setValue('');
    this.valiAlterCri.get('desAlternativa').setValue('');
    this.valiAlterCri.get('valAlternativa').setValue('');
    this.valiAccionSuge.get('desAccionSugerida').setValue('');
    this.valiAccionSuge.get('valMinimo').setValue('');
    this.valiAccionSuge.get('valMaximo').setValue('');
  }

  activarAlertMensaje(a: boolean, b: boolean) {
    this.verMsgCriterio = a;
    this.verMsgAlternativa = b;
  }

  cargarMantenimientoCriterio() {
    this.listarCriterioCalificacion();
  }

  guardarCriterio() {
    this.activarAlertMensaje(true, false);
    // Para todo el formGro
    let pesoTotal: number = 0;
    this.valiCriCali.markAllAsTouched();

    // VALIDACIÓN PARA TODOS LOS CAMPOS DEL FORMCONTROL
    if (this.valiCriCali.valid) {
      this.criterioCalificacion.desCriterio = trim(this.valiCriCali.value.desCriterio);
      this.criterioCalificacion.porPeso = this.valiCriCali.value.porPeso;

      pesoTotal = Number(this.pesoAcumulativo) + Number(this.criterioCalificacion.porPeso);

      if (pesoTotal <= Constantes.MAX_VAL_100){
        this.mantenimientoCriterioService.guardarCriterio(this.criterioCalificacion).subscribe(
          result => {
            if (result.exito) {
              if (pesoTotal < Constantes.MAX_VAL_100){
                this.utilService.alertaMensaje(MensajesExcepciones.CUS30_EXCP_SUMA_100, Constantes.MODAL_PRIMARY);
                this.listarCriterioCalificacion();
                return false;
              }
              this.listarCriterioCalificacion();
            } else {
              console.log(result.mensaje);
            }
          },
          error => {
            console.log("Hubo errores ", error);
          }
        );
      }else{
        this.utilService.alertaMensaje(MensajesExcepciones.CUS30_EXCP_002, Constantes.MODAL_DANGER);
      }
    } else {
    }
  }

  guardarEstadoCriterio(criterio: CriterioCalificacion, indEstado: string) {
    let pesoSuma: number = 0;
    let signo: number = (indEstado === '1') ? 1 : -1;
    this.criterioCalificacion = new CriterioCalificacion();
    this.criterioCalificacion.numCriterio = criterio.numCriterio;
    this.criterioCalificacion.indEstado = trim(indEstado);
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,
      indEstado === '1' ? Constantes.MODAL_MENSAJE_ACTIVAR : Constantes.MODAL_MENSAJE_DESACTIVAR,
      Constantes.MODAL_PRIMARY, () => {
        let pesoActual = this.pesoAcumulativo + (criterio.porPeso * signo);
        if (pesoActual > Constantes.MAX_VAL_100) {
          this.activarAlertMensaje(true, false);
          this.utilService.alertaMensaje(MensajesExcepciones.CUS30_EXCP_002, Constantes.MODAL_DANGER);
          return false;
        }
        this.mantenimientoCriterioService.guardarEstadoCriterio(this.criterioCalificacion).subscribe(respuesta => {
          if (respuesta.exito) {
            this.pesoAcumulativo = 0;
            this.listarCriterioCalificacion();
          }
        });
    });
  }

  eliminarCriterio(numCriterio: number){
    this.criterioCalificacion = new CriterioCalificacion();
    this.criterioCalificacion.numCriterio = numCriterio;
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE_ELIMINAR  ,
      Constantes.MODAL_PRIMARY, () => {
      this.mantenimientoCriterioService.eliminarCriterio(this.criterioCalificacion).subscribe(respuesta => {
        if (respuesta.exito) {
          this.listarCriterioCalificaciones.forEach(eliminar => {
            if (eliminar.numCriterio === numCriterio) {
              this.listarCriterioCalificacion();
            }
          });
        }
      });
    });
  }

  cargarDetalleCriterio(numCriterio: number, criterios: CriterioCalificacion) {
    this.hiddeTable = false;

    this.tituloCriterio = `${criterios.numCriterio} - ${criterios.desCriterio}`;

    this.listarAlternativaCriterio(numCriterio);
  }


  guardarAlternativa() {
      this.activarAlertMensaje(false, true);
      // Para todo el formGroup
      this.valiAlterCri.markAllAsTouched();

      // VALIDACIÓN PARA TODOS LOS CAMPOS DEL FORMCONTROL
      if (this.valiAlterCri.valid) {

          const filtro = this.listarAlternativaCriterios.filter(a => (trim(a.valAlternativa) === trim(this.valiAlterCri.get('valAlternativa').value)) && a.indEstado === '1');

          if (filtro.length > 0) {
              this.utilService.alertaMensaje(MensajesExcepciones.CUS30_EXCP_005, Constantes.MODAL_DANGER);
              return false;
          }

          this.alternativaCriterio.desAlternativa = trim(this.valiAlterCri.value.desAlternativa);
          this.alternativaCriterio.valAlternativa = this.valiAlterCri.value.valAlternativa;
          this.alternativaCriterio.numCriterio = this.criterioCalificacion.numCriterio;

          this.mantenimientoCriterioService.guardarAlternativa(this.alternativaCriterio).subscribe(
              result => {
                if (result.exito) {
                  let data = (result.data as AlternativaCriterio[]).map(y => AlternativaCriterio.fromJSON(y));
                  this.listarAlternativaCriterios = data.filter(p => p.numCriterio === this.criterioCalificacion.numCriterio);
                  this.listarAlternativaCriterio(this.alternativaCriterio.numCriterio);
                } else {
                  console.log(result.mensaje);
                }
              },
              error => {
                console.log("Hubo errores ", error);
              }
            );
         } else {
      }
    }


  guardarEstadoAlternativa(numCriterio: number, indEstado: string, numAlternativa: number, valAlternativa: number) {
    this.alternativaCriterio = new AlternativaCriterio();
    this.alternativaCriterio.numCriterio = numCriterio;
    this.alternativaCriterio.indEstado = trim(indEstado);
    this.alternativaCriterio.numAlternativa = numAlternativa;
    this.alternativaCriterio.valAlternativa = valAlternativa;
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,
      indEstado === '1' ? Constantes.MODAL_MENSAJE_ACTIVAR : Constantes.MODAL_MENSAJE_DESACTIVAR,
      Constantes.MODAL_PRIMARY, () => {

      const filtro = this.listarAlternativaCriterios.filter(a => (trim(a.valAlternativa) === trim(valAlternativa) )
      && a.indEstado === '1' && !(trim(a.numAlternativa) === trim(numAlternativa)) );

      if (filtro.length > 0) {
          this.activarAlertMensaje(false, true);
          this.utilService.alertaMensaje(MensajesExcepciones.CUS30_EXCP_005, Constantes.MODAL_DANGER);
          return false;
      }

      this.mantenimientoCriterioService.guardarEstadoAlternativa(this.alternativaCriterio).subscribe(respuesta => {
        if (respuesta.exito) {
          this.listarAlternativaCriterios.forEach(alter => {
            if (alter.numCriterio === numCriterio && alter.numAlternativa === numAlternativa) {
              alter.indEstado = indEstado;
              this.listarAlternativaCriterio(alter.numCriterio);
            }
          });
        }
      });
    });
  }

  eliminarAlternativa(numAlternativa: number){
    this.alternativaCriterio = new AlternativaCriterio();
    this.alternativaCriterio.numAlternativa = numAlternativa;
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE_ELIMINAR ,
      Constantes.MODAL_PRIMARY, () => {
      this.mantenimientoCriterioService.eliminarAlternativa(this.alternativaCriterio).subscribe(respuesta => {
        if (respuesta.exito) {
          this.listarAlternativaCriterios.forEach(eliminar => {
            if (eliminar.numAlternativa === numAlternativa) {
              this.listarAlternativaCriterio(eliminar.numCriterio);
            }
          });
        }
      });
    });
  }

  cargarAccsugerida() {
    this.listarAccionesSugeridas();
  }


  guardarAccionSugerida(){
    this.valiAccionSuge.markAllAsTouched();

    // VALIDACIÓN PARA TODOS LOS CAMPOS DEL FORMCONTROL
    if (this.valiAccionSuge.valid) {

      // VALIDACIÓN PUNTAJE
      console.log("this.listarAccionesSugeridasCalif => ", this.listarAccionesSugeridasCalif);
      const filtro1 = this.listarAccionesSugeridasCalif.filter(a => {
        return (((a.valMinimo <= parseFloat(this.valiAccionSuge.get('valMinimo').value)) &&
        (a.valMaximo > parseFloat(this.valiAccionSuge.get('valMinimo').value))) ||
        ((a.valMinimo <= parseFloat(this.valiAccionSuge.get('valMaximo').value)) &&
        (a.valMaximo >= parseFloat(this.valiAccionSuge.get('valMaximo').value)))) &&
         a.indEstadoAccionSugerida === '1';});
      console.log("this.filtro1 => ", filtro1);

      if (filtro1.length > 0) {
          this.activarAlertMensaje(false, true);
          this.utilService.alertaMensaje(MensajesExcepciones.CUS30_EXCP_003, Constantes.MODAL_DANGER);
          return false;
      }

      // VALIDACIÓN DESCRIPCIÓN
      const filtro2 = this.listarAccionesSugeridasCalif.filter(a => (trim(a.desAccionSugerida) === trim(this.valiAccionSuge.get('desAccionSugerida').value)) && a.indEstadoAccionSugerida === '1');

      if (filtro2.length > 0) {
          this.activarAlertMensaje(false, true);
          this.utilService.alertaMensaje(MensajesExcepciones.CUS30_EXCP_004, Constantes.MODAL_DANGER);
          return false;
      }

      this.accionSugeridaCalif.desAccionSugerida = trim(this.valiAccionSuge.value.desAccionSugerida);
      this.accionSugeridaCalif.valMinimo = this.valiAccionSuge.value.valMinimo;
      this.accionSugeridaCalif.valMaximo = this.valiAccionSuge.value.valMaximo;
      this.mantenimientoCriterioService.guardarAccsugerida(this.accionSugeridaCalif).subscribe(
        result => {
          if (result.exito) {
            this.listarAccionesSugeridas();
          } else {
            console.log(result.mensaje);
          }
        },
        error => {
          console.log("Hubo errores ", error);
        }
      );
    } else {
    }
  }

  guardarEstadoAccSugerida(numAccionSugerida: number, indEstadoAccionSugerida: string, valMinimo: number, valMaximo: number, desAccionSugerida: string){
    this.accionSugeridaCalif = new AccionSugeridaCalif();
    this.accionSugeridaCalif.numAccionSugerida = numAccionSugerida;
    this.accionSugeridaCalif.indEstadoAccionSugerida = trim(indEstadoAccionSugerida);
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,
      indEstadoAccionSugerida === '1' ? Constantes.MODAL_MENSAJE_ACTIVAR : Constantes.MODAL_MENSAJE_DESACTIVAR,
         Constantes.MODAL_PRIMARY, () => {

          // VALIDACIÓN PUNTAJE
          console.log("this.listarAccionesSugeridasCalif => ", this.listarAccionesSugeridasCalif);
          const filtro1 = this.listarAccionesSugeridasCalif.filter(a => {
            return (((a.valMinimo <= toNumber(valMinimo)) &&
            (a.valMaximo > toNumber(valMinimo))) ||
            ((a.valMinimo <= toNumber(valMaximo)) &&
            (a.valMaximo >= toNumber(valMaximo)))) &&
            a.indEstadoAccionSugerida === '1' && !(trim(a.numAccionSugerida) === trim(numAccionSugerida)); });

          console.log("this.filtro1 => ", filtro1);

          if (filtro1.length > 0) {
              this.activarAlertMensaje(false, true);
              this.utilService.alertaMensaje(MensajesExcepciones.CUS30_EXCP_003, Constantes.MODAL_DANGER);
              return false;
          }

          // VALIDACIÓN DESCRIPCIÓN
          const filtro2 = this.listarAccionesSugeridasCalif.filter(a => (trim(a.desAccionSugerida) === trim(desAccionSugerida)) &&
          a.indEstadoAccionSugerida === '1' && !(trim(a.numAccionSugerida) === trim(numAccionSugerida)));

          if (filtro2.length > 0) {
              this.activarAlertMensaje(false, true);
              this.utilService.alertaMensaje(MensajesExcepciones.CUS30_EXCP_004, Constantes.MODAL_DANGER);
              return false;
          }

          this.mantenimientoCriterioService.guardarEstadoAccSugerida(this.accionSugeridaCalif).subscribe(respuesta => {
           if (respuesta.exito) {
            this.listarAccionesSugeridasCalif.forEach(alter => {
              if (alter.numAccionSugerida === numAccionSugerida) {
                alter.indEstadoAccionSugerida = indEstadoAccionSugerida;
                this.listarAccionesSugeridas();
              }
             });
           }
         });
       });
  }


  eliminarAccSugerida(numAccionSugerida: number){
    this.accionSugeridaCalif = new AccionSugeridaCalif();
    this.accionSugeridaCalif.numAccionSugerida = numAccionSugerida;
    this.utilService.modalConfirmacion(Constantes.MODAL_TITULO, Constantes.MODAL_MENSAJE_ELIMINAR,
      Constantes.MODAL_PRIMARY, () => {
      this.mantenimientoCriterioService.eliminarAccSugerida(this.accionSugeridaCalif).subscribe(respuesta => {
        if (respuesta.exito) {
          this.listarAccionesSugeridasCalif.forEach(eliminar => {
            if (eliminar.numAccionSugerida === numAccionSugerida) {
              this.listarAccionesSugeridas();
            }
          });
        }
      });
    });
  }

  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }
  // Fin metodos componente


  // Inicio metodos Web Service
  listarCriterioCalificacion() {
    this.pesoAcumulativo = 0;
    this.listarCriterioCalificaciones = [];
    this.mantenimientoCriterioService.cargarMantenimientoCriterio(0).subscribe(
      result => {
        if (result.exito) {
          this.listarCriterioCalificaciones = (result.data as CriterioCalificacion[]).map(y => CriterioCalificacion.fromJSON(y));

          for (let criterio of this.listarCriterioCalificaciones) {
            if (criterio.indEstado === '1'){
              this.pesoAcumulativo = this.pesoAcumulativo + criterio.porPeso;
            }
          }
        } else {
          console.log(result.mensaje);
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );
  }

   listarAlternativaCriterio(numCriterio: number) {
     this.listarAlternativaCriterios = [];
     this.criterioCalificacion = new CriterioCalificacion();
     this.criterioCalificacion.numCriterio = numCriterio;
    // this.mantenimientoCriterioService.cargarDetalleCriterio(numCriterio, Constantes.IND_ESTADO_ACTIVO).subscribe(
     this.mantenimientoCriterioService.cargarDetalleCriterio(numCriterio, Constantes.VALOR_VACIO, Constantes.IND_ESTADO_NO_ELIMINADO).subscribe(
       result => {
         if (result.exito) {
           this.listarAlternativaCriterios = (result.data as AlternativaCriterio[]).map(y => AlternativaCriterio.fromJSON(y));
         } else {
           console.log(result.mensaje);
         }
       },
       error => {
         console.log('Hubo errores ', error);
       }
     );
   }


  listarAccionesSugeridas() {
    this.listarAccionesSugeridasCalif = [];
    this.mantenimientoCriterioService.cargarAccsugerida().subscribe(
      result => {
        if (result.exito) {
          this.listarAccionesSugeridasCalif = (result.data as AccionSugeridaCalif[]).map(y => AccionSugeridaCalif.fromJSON(y));
        } else {
          console.log(result.mensaje);
        }
      },
      error => {
        console.log('Hubo errores ', error);
      }
    );
  }
  // Fin metodos Web Service
}
