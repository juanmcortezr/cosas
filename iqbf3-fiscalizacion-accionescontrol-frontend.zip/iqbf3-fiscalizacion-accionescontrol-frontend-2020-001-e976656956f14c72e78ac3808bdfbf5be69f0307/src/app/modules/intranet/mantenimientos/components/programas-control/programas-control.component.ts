import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { UtilService } from 'src/app/services/shared/util.service';
import { Constantes } from 'src/app/utils/constantes';
import { MantenimientoProgramaService } from 'src/app/services/mantenimiento-programa.service';
import { ProgramaControl } from 'src/app/models/programaControl.model';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';
import { trim, isNotEmpty } from 'src/app/utils/utilitarios';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import { NgbModal, NgbActiveModal, NgbModalRef, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { ServicioWebService } from 'src/app/services/maestros/servicio-web.service';

@Component({
  selector: 'app-programas-control',
  templateUrl: './programas-control.component.html',
  styleUrls: ['./programas-control.component.css']
})
export class ProgramasControlComponent implements OnInit {
  // Inicio declaracion
  programaControl: ProgramaControl = new ProgramaControl();
  listarProgramasControl: ProgramaControl[] = [];
  pControl: any = {};
  filtro: any = {};
  modalRef: NgbModalRef;

  hiddeTable: boolean = true;
  tipoLBL: string;
  esValidaUUOO: boolean = false;
  valiProgramC: FormGroup;

  @ViewChild('mdlEditarProgramaControl', {static: true}) mdlEditarProgramaControl: NgbActiveModal;

  constructor(private router: Router,
              private mantenimientoProgramaService: MantenimientoProgramaService,
              private utilService: UtilService,
              private modalService: NgbModal,
              private configModal: NgbModalConfig,
              private servicioWeb: ServicioWebService) {
                configModal.backdrop = 'static';
                configModal.keyboard = false;
              }

  ngOnInit() {
    this.inicio();
    this.limpiarCampos();
    this.listarProgramasControl = [];
  }

  inicio() {
    this.tipoLBL = Constantes.ERROR_CLASS_FORM_CONTROL_LBL;

    //Validaciones Acciones Sugeridas
    this.valiProgramC = new FormGroup({
      desAlcance: new FormControl('', [Validators.required]),
      desDenominacion: new FormControl('', [Validators.required]),
      numPlazo: new FormControl('', [Validators.required]),
      codUnidadOrganica: new FormControl('', [Validators.required]),
      reqInforme: new FormControl('', [Validators.required]),
      cboCierre: new FormControl('', [Validators.required])
    });

  }

  limpiarCampos(){
    //Setear valores
    this.filtro = {
      nombrePrograma: "",
      cboEstado: ""
    };

    //Setear tabla
    this.listarProgramasControl = [];
  }

  resetearFormGroup(){
    //Setear formGroug
    this.valiProgramC.reset();
    this.valiProgramC.get('reqInforme').setValue('');
    this.valiProgramC.get('cboCierre').setValue('');
  }



    guardarEstadoPrograma(codigoPrograma: string, indEstado: string) {
      this.programaControl = new ProgramaControl();
      this.programaControl.codProgctrl = trim(codigoPrograma);
      this.programaControl.indEstado = trim(indEstado);
      console.log('prog',this.programaControl);
      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,
        indEstado === '1' ? Constantes.MODAL_MENSAJE_ACTIVAR : Constantes.MODAL_MENSAJE_DESACTIVAR,
        Constantes.MODAL_PRIMARY, () => {
        this.mantenimientoProgramaService.guardarEstadoPrograma(this.programaControl).subscribe(respuesta => {
          console.log('SEVICE',this.programaControl);
          if (respuesta.exito) {
            this.listarProgramasControl.forEach(cri => {
              if (cri.codProgctrl === codigoPrograma) {
                cri.indEstado = indEstado;
              }
            });
          }
        });
      });
    }

    cargarDatosPrograma(progControl: ProgramaControl) {
      this.resetearFormGroup();
      this.programaControl = progControl;
      console.log(this.programaControl);
      this.valiProgramC.get('desAlcance').setValue(this.programaControl.desAlcance);
      this.valiProgramC.get('desDenominacion'). setValue(this.programaControl.desDenominacion);
      this.valiProgramC.get('numPlazo'). setValue(this.programaControl.numPlazo);
      this.valiProgramC.get('codUnidadOrganica'). setValue(this.programaControl.codUnidadOrganica);
      this.valiProgramC.get('reqInforme'). setValue(this.programaControl.indInformeSelec);
      this.valiProgramC.get('cboCierre'). setValue(this.programaControl.indCierre);
      this.modalRef = this.modalService.open(this.mdlEditarProgramaControl, { size: 'lg' });
    }

    async eventoObtenerUnidadOrganica() {
      await this.obtenerUnidadOrganica();

      if (!this.esValidaUUOO) {
        this.utilService.alertaMensaje(MensajesExcepciones.CUS31_EXCP_002, Constantes.MODAL_DANGER);
      }
    }

    eventoBtnGuardarDatosPrograma(codProgctrl:	string) {
      this.utilService.modalConfirmacion(Constantes.MODAL_TITULO,
        codProgctrl != '0' ? Constantes.MODAL_MENSAJE : Constantes.MODAL_MENSAJE,
        Constantes.MODAL_PRIMARY, () => {
            this.guardarDatosPrograma(codProgctrl);
        });
    }

    async guardarDatosPrograma(codProgctrl:	string) {

      if (this.valiProgramC.valid) {

        await this.obtenerUnidadOrganica();

        if (!this.esValidaUUOO) {
          this.utilService.alertaMensaje(MensajesExcepciones.CUS31_EXCP_002, Constantes.MODAL_DANGER);
          return false;
        }

        this.programaControl = new ProgramaControl();
        console.log(this.programaControl);

        this.programaControl.codProgctrl = codProgctrl;
        this.programaControl.desAlcance = trim(this.valiProgramC.get('desAlcance').value);
        this.programaControl.desDenominacion = trim(this.valiProgramC.get('desDenominacion').value);
        this.programaControl.numPlazo = this.valiProgramC.get('numPlazo').value;
        this.programaControl.codUnidadOrganica = trim(this.valiProgramC.get('codUnidadOrganica').value);
        this.programaControl.indInformeSelec = trim(this.valiProgramC.get('reqInforme').value);
        this.programaControl.indCierre = trim(this.valiProgramC.get('cboCierre').value);

        this.mantenimientoProgramaService.guardarDatosPrograma(this.programaControl).subscribe(respuesta => {
                console.log('SEVICE',this.programaControl);
                if (respuesta.exito) {

                  this.modalRef.close(); //Cerrar modal

                  this.listarProgramaControl();
                  //Carga inicial

                }
        });

      }else{
        this.valiProgramC.markAllAsTouched();
      }

     }


  //Validaciones formControl
  getErrorMensaje(groupName: FormGroup, controlName: string): string {
    return this.utilService.getErrorMensajeFormControl(groupName, controlName);
  }

  getErrorClass(groupName: FormGroup, controlName: string, tipo: string = Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
    return this.utilService.getErrorClassFormControl(groupName, controlName, tipo);
  }
  // Fin metodos componente

  //Inicio metodos Web Service
  listarProgramaControl() {
    this.listarProgramasControl = [];
    this.programaControl.desDenominacion = trim(this.filtro.nombrePrograma);
    this.programaControl.indEstado = trim(this.filtro.cboEstado);
    if (this.programaControl.filtroValido()) {
      this.programaControl.desDenominacion = this.programaControl.desDenominacion === '' ? ' ' : this.programaControl.desDenominacion;
      this.mantenimientoProgramaService.listarProgramaControl(this.programaControl).subscribe(
        result => {
          if (result.exito) {
            this.listarProgramasControl = (result.data as ProgramaControl[]).map(y => ProgramaControl.fromJSON(y));
          } else {
            this.utilService.alertaMensaje(MensajesExcepciones.MENSAJE_SIN_RESULTADO, Constantes.MODAL_PRIMARY);
          }
        },
        error => {
          console.log(error);
        }
      );
    } else {
      this.utilService.alertaMensaje(MensajesExcepciones.CUS01_EXCP_001, Constantes.MODAL_DANGER);
    }
  }

  async obtenerUnidadOrganica() {

    this.esValidaUUOO = false;

    const codUUOO: string = trim(this.valiProgramC.get('codUnidadOrganica').value);

    const result = await this.servicioWeb.obtenerUnidadOrganica(codUUOO).toPromise();

    if (result.exito) {
      this.esValidaUUOO = true;
    }
  }

}
