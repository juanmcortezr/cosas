import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProgramasControlComponent } from './components/programas-control/programas-control.component';
import { CriteriosCalificacionComponent } from './components/criterios-calificacion/criterios-calificacion.component';

const routes: Routes = [
  {path: 'programas-control', component: ProgramasControlComponent},
  {path: 'criterios-calificacion', component: CriteriosCalificacionComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MantenimientosRoutingModule { }
