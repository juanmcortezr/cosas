import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MantenimientosRoutingModule } from './mantenimientos-routing.module';
import { ProgramasControlComponent } from './components/programas-control/programas-control.component';
import { CriteriosCalificacionComponent } from './components/criterios-calificacion/criterios-calificacion.component';
import { primeNgModule } from 'src/app/app-primeng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModulesModule } from '../../modules.module';


@NgModule({
  declarations: [ProgramasControlComponent, CriteriosCalificacionComponent],
  imports: [
    CommonModule,
    MantenimientosRoutingModule,
    primeNgModule,
    FormsModule,
    ReactiveFormsModule,
    ModulesModule
  ]
})
export class MantenimientosModule { }
