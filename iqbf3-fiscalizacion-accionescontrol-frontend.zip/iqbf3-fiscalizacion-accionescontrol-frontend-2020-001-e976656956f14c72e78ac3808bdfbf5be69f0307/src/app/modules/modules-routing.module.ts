import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ModulesComponent } from './modules.component';


const routes: Routes = [
  { path: 'ol-iq-iacontrolacceso/ServletAcceso.htm', component: ModulesComponent },
  {
    path: '', component: ModulesComponent,
  children: [
    {path: 'programacion', loadChildren: './intranet/programacion/programacion.module#ProgramacionModule'},
    {path: 'fiscalizacion', loadChildren: './intranet/fiscalizacion/fiscalizacion.module#FiscalizacionModule'},
    {path: 'consultas', loadChildren: './intranet/consultas/consultas.module#ConsultasModule'},
    {path: 'mantenimientos', loadChildren: './intranet/mantenimientos/mantenimientos.module#MantenimientosModule'},
    {path: 'solicitudes', loadChildren: './intranet/solicitudes/solicitudes.module#SolicitudesModule'}
  ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ModulesRoutingModule { }
