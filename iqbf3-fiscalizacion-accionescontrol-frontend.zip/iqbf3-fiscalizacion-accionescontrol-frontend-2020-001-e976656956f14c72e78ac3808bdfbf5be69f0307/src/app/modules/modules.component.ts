import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { isNotEmpty } from '../utils/utilitarios';
import { mappingMenu } from '../utils/mapping-menu';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-modules',
  templateUrl: './modules.component.html',
  styleUrls: ['./modules.component.css']
})
export class ModulesComponent implements OnInit {

  constructor(private router: Router) { }

  mostrarMenu: boolean;

  ngOnInit() {
    this.mostrarMenu = true;
    if (environment.production) {
      const pagina = sessionStorage.getItem("pagina");
      if (isNotEmpty(pagina)) {
        const pagCompleta = mappingMenu[pagina];
        this.router.navigate([`/${pagCompleta}`]);
      }
      this.mostrarMenu = false;
    }
  }

}
