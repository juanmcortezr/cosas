import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { isEmpty } from '../utils/utilitarios';
import { UsuarioBean } from '../models/usuarioBean.model';

@Injectable()
export class InterceptorService implements HttpInterceptor {

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (isEmpty(sessionStorage.getItem("usuarioBeanJSON"))) {
            sessionStorage.setItem("usuarioBeanJSON", btoa(JSON.stringify(this.dummy())));
        }
        const token: string = sessionStorage.getItem('usuarioBeanJSON');
        /*const authReq = req.clone({
            headers: new HttpHeaders({
              'Content-Type':  'application/json',
              'usuariobean-header': sessionStorage.getItem("usuarioBeanJSON")
            })
          });*/

        /*const proxyReq = req.clone({
            headers: (req.method == 'POST' || req.method == 'GET' ? req.headers.set("usuariobean-header", sessionStorage.getItem("usuarioBeanJSON")) : req.headers)
        });*/
        let solicitud = req;
        if (token) {
            solicitud = req.clone({
                setHeaders: {
                    authorization: `Bearer ${token}`
                }
            });
        }
        return next.handle(solicitud);
    }

    dummy(): UsuarioBean {
        let usuario = new UsuarioBean();
        usuario.nombreCompleto = "Rosas Alva Huaman Edward";
        usuario.login = "EROSAS";
        usuario.numRUC = "12345678901";
        usuario.nroRegistro = "6758";
        usuario.codUO = "1U2303";
        return usuario;
    }
}
