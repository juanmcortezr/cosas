import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { IqbfModule } from 'iqbf';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { primeNgModule } from './app-primeng.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { LoadingComponent } from './utils/loading/loading/loading.component';
import { NgbDateAdapter, NgbDateParserFormatter, NgbDatepickerI18n, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomAdapter } from './utils/providers/datepicker-adapter';
import { CustomDateParserFormatter } from './utils/providers/datepicker-formater';
import { CustomDatepickerI18n } from './utils/providers/datepicker-i18n-es';
import { InterceptorService } from './interceptors/interceptor.service';


@NgModule({
  declarations: [
    AppComponent,
    LoadingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    primeNgModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    IqbfModule,
    ReactiveFormsModule,
    NgbModule
  ],
  exports: [
    primeNgModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
    { provide: NgbDateAdapter, useClass: CustomAdapter },
    { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },
    { provide: NgbDatepickerI18n, useClass: CustomDatepickerI18n }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
