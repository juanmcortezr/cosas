import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EvaluacionResultadoService {

  constructor(private http: HttpClient) { }

  cargarRegistroResultado(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/cargarRegistroResultado`);
  }
  listarOrdenesAccion(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/listarOrdenesAccion`);
  }
  cargarDatosOrden(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/cargarDatosOrden`);
  }
  verDocumentoAccion(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/verDocumentoAccion`);
  }
  descargarDocumentoAccion(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/descargarDocumentoAccion`);
  }
  descargarInformeResultado(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/descargarInformeResultado`);
  }
  descargarOtroDoc(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/descargarOtroDoc`);
  }
  verEstablecimiento(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/verEstablecimiento`);
  }
  verBien(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/verBien`);
  }
  guardarEvaluacionOrden(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_RESULTADO}/guardarEvaluacionOrden`);
  }
}
