import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { ProgramaControl } from '../models/programaControl.model';
import { isNotEmpty } from '../utils/utilitarios';

@Injectable({
  providedIn: 'root'
})
export class MantenimientoProgramaService {

  constructor(private http: HttpClient) { }

  //INICIO - JDAVILA

  listarProgramaControl(programaControl: ProgramaControl): Observable<Response> {
    let query = '';
    if (isNotEmpty(programaControl.desDenominacion)) {
      query += `nominacion=${programaControl.desDenominacion}&`;
    }
    if (isNotEmpty(programaControl.indEstado)) {
      query += `indEstado=${programaControl.indEstado}`;
    }
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_PROGRAMA}/programaControl?${query}`);
  }

  guardarEstadoPrograma(programaControl: ProgramaControl): Observable<Response> {
    let parametro: string = JSON.stringify(programaControl);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_PROGRAMA}/estadoPrograma`, parametro, { headers: myHeader});
  }

  cargarDatosPrograma(codProgctrl: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_PROGRAMA}/cDatosPrograma/${codProgctrl}`);
  }

  guardarDatosPrograma(programaControl: ProgramaControl): Observable<Response> {
    let parametro: string = JSON.stringify(programaControl);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_PROGRAMA}/gDatosPrograma`, parametro, { headers: myHeader});
  }

}


