import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { Programacion } from '../models/programacion.model';

@Injectable({
  providedIn: 'root'
})
export class ReasignacionProgramaService {

  constructor(private http: HttpClient) { }

	listarProgramacion(programacion: Programacion): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REASIGNACION_PROGRAMA}/listarPrograma`);
  }

  obtenerReasingarProgramador(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REASIGNACION_PROGRAMA}/obtenerReasingarProgramador`);
  }

  guardarAsignarPrograma(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REASIGNACION_PROGRAMA}/guardarAsignarPrograma`, parametro);
	}

}
