import { Injectable } from '@angular/core';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { Programacion } from '../models/programacion.model';
import { AsignacionMasivaAuditores } from '../models/asignacionMasivaAuditores.model';
import { UtilService } from './shared/util.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable({
	providedIn: 'root'
})
export class AsignacionMasivaAudtoresPrincipalService {

  constructor(private util: UtilService,
              private http: HttpClient) { }


	//pantalla1
	listarPrograma(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/listarPrograma`, programacion);
	}

	//pantalla2
	obtenerAsignarAuditor(asignacionMasivaAuditores: AsignacionMasivaAuditores): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/obtenerAsignarAuditor`, asignacionMasivaAuditores);
	}

	//pantalla3
	cargarListaAuditor(): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/cargarListaAuditor`);
	}

	listarAuditor(asignacionMasivaAuditores: AsignacionMasivaAuditores): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/listarAuditor`, asignacionMasivaAuditores);
	}

	guardarAuditorPresel(asignacionMasivaAuditores: AsignacionMasivaAuditores[]): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/guardarAuditorPresel`, asignacionMasivaAuditores);
	}

  //ASIGNACIÓN MASIVA DE ORDENES DE CONTROL NO CONFORMES - CUS 29

  listarResumenOrdenesNoConformes(asignacionMasivaAuditores: AsignacionMasivaAuditores): Observable<Response> {
    let parametro: string = JSON.stringify(asignacionMasivaAuditores);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_AUDITOR}/listarResumenOrdenesNoConformes`, parametro, { headers: myHeader});
  }

  eliminarAuditorPreseleccionado(asignacionMasivaAuditores: AsignacionMasivaAuditores){
    let parametro: string = JSON.stringify(asignacionMasivaAuditores);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_AUDITOR}/eliminarAuditorPreseleccionado`, parametro, { headers: myHeader});
  }

  guardarAsignacion(asignacionMasivaAuditores: AsignacionMasivaAuditores){
    let parametro: string = JSON.stringify(asignacionMasivaAuditores);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_AUDITOR}/guardarAsignacion`, parametro, { headers: myHeader});
  }

  ///MODAL - CUS 29

  listarSupervisionAuditor(){
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_PROGRAMA}/listarSupervisionAuditor`);
  }

  listarAuditoresVigentes(asignacionMasivaAuditores: AsignacionMasivaAuditores){
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_PROGRAMA}/listarAuditoresVigentes/${asignacionMasivaAuditores.numGrupo}`);
  }

  guardarAuditorPreselec(asignacionMasivaAuditores: AsignacionMasivaAuditores){
    let parametro: string = JSON.stringify(asignacionMasivaAuditores);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_AUDITOR}/guardarAuditorPreselec`, parametro, { headers: myHeader});
  }



  ListaAsignacionPrueba(asignacionMasivaAuditores: AsignacionMasivaAuditores) {

    const listarAsignacionesMasivas: AsignacionMasivaAuditores[] = [];

    const a: AsignacionMasivaAuditores = new AsignacionMasivaAuditores();
    a.numProgramacion = '3';
    a.numInformeSeleccion = '0901-2020-3YJ500';
    a.numRegistro = '8910';
    a.nomApellidoUsuario = 'John Davila';
    a.cargoLaboral = '10';
    a.codProgramaCtrl = '002';
    a.numAsigTemp = '18';
    a.numGrupo = '3';
    listarAsignacionesMasivas.push(a);

    const b: AsignacionMasivaAuditores = new AsignacionMasivaAuditores();
    b.numProgramacion = '5';
    b.numInformeSeleccion = '1002-2020-3YJ500';
    b.numRegistro = '8920';
    b.nomApellidoUsuario = 'Sofia Williamson';
    b.cargoLaboral = '20';
    b.codProgramaCtrl = '003';
    b.numAsigTemp = '19';
    b.numGrupo = '2';
    listarAsignacionesMasivas.push(b);

    const c: AsignacionMasivaAuditores = new AsignacionMasivaAuditores();
    c.numProgramacion = '6';
    c.numInformeSeleccion = '1204-2020-3YJ500';
    c.numRegistro = '8930';
    c.nomApellidoUsuario = 'R G';
    c.cargoLaboral = '10';
    c.codProgramaCtrl = '999'; // OTROS
    c.numAsigTemp = '20';
    c.numGrupo = '3';
    listarAsignacionesMasivas.push(c);

    const lista: AsignacionMasivaAuditores[]  = [];
    lista.push(a);
    lista.push(b);
    lista.push(c);

    return lista;
  }


  ListaSupervision() {

    const listaSupervision: AsignacionMasivaAuditores[] = [];

    const a: AsignacionMasivaAuditores = new AsignacionMasivaAuditores();
    a.numGrupo = '2';
    a.numProgramacion = 'Trazabilidad';
    a.codTipoProceso = '02';
    listaSupervision.push(a);

    const b: AsignacionMasivaAuditores = new AsignacionMasivaAuditores();
    b.numGrupo = '3';
    b.numProgramacion = 'Supervision 3';
    b.codTipoProceso = '02';
    listaSupervision.push(b);


    const lista: AsignacionMasivaAuditores[]  = [];
    lista.push(a);
    lista.push(b);

    return lista;
  }

}
