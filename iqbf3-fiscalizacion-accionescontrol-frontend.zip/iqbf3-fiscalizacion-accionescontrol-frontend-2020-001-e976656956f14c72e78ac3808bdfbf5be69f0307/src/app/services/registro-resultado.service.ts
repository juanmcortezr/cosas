import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegistroResultadoService {

  constructor(private http: HttpClient) { }

    //INICIO - JDAVILA

    cargarRegistrarResultado(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/cargarRegistrarResultado`);
  }

  listarOrdenesAccion(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/listarOrdenesAccion`);
  }

  verDetalleInconsistencia(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/verDetalleInconsistencia`);
  }

  verDocumentoAccion(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/verDocumentoAccion`);
  }

  verificarInconsistencia(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/verificarInconsistencia`);
  }

  cargarDatosOrden(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/cargarDatosOrden`);
  }

  descargarDocumentoAccion(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/descargarDocumentoAccion`);
  }

  descargarInformeResultado(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/descargarInformeResultado`);
  }

  descargarOtroDoc(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/descargarOtroDoc`);
  }

  guardarActa(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/guardarActa`, parametro);
  }

  guardarActaBien(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/guardarActaBien`, parametro);
  }

  guardarBien(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/guardarBien`, parametro);
  }

  guardarContacto(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/guardarContacto`, parametro);
  }

  guardarDocumentoOperacion(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/guardarDocumentoOperacion`, parametro);
  }

  guardarEstablecimiento(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/guardarEstablecimiento`, parametro);
  }

  guardarOtroDocumento(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/guardarOtroDocumento`, parametro);
  }

  guardarResultadoOrden(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/guardarResultadoOrden`, parametro);
  }

  guardarTareo(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/guardarTareo`, parametro);
  }

  editarActa(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/editarActa`);
  }

  editarActaBien(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/editarActaBien`);
  }

  editarBien(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/editarBien`);
  }


  editarEstablecimiento(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/editarEstablecimiento`);
  }

  editarOtroDoc(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/editarOtroDoc`);
  }

  eliminarActa(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/eliminarActa`, parametro);
  }

  eliminarActaBien(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/eliminarActaBien`, parametro);
  }

  eliminarBien(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/eliminarBien`, parametro);
  }

  eliminarContacto(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/eliminarContacto`, parametro);
  }

  eliminarEstablecimiento(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/eliminarEstablecimiento`, parametro);
  }

  eliminarInformeResultado(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/eliminarInformeResultado`, parametro);
  }

  eliminarOperacion(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/eliminarOperacion`, parametro);
  }

  eliminarOtroDocumento(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/eliminarOtroDocumento`, parametro);
  }


  eliminarTareo(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/eliminarTareo`, parametro);
  }

  enviarResultadoOrden(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/enviarResultadoOrden`);
  }
}
