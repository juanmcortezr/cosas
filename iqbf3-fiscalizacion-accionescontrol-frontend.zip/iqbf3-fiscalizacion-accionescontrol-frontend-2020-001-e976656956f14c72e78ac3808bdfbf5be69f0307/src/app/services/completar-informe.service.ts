import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { Programacion } from '../models/programacion.model';
import { UsuarioProgramacion } from '../models/usuarioProgramacion.model';
import { UtilService } from './shared/util.service';
import { DocumentoAccion } from '../models/documentoAccion.model';

//CUS14
@Injectable({
  providedIn: 'root'
})
export class CompletarInformeService {

  constructor(private http: HttpClient, 
    private util: UtilService) { }

  listarPrograma(programacion: Programacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_COMPLETAR_INFORME}/listarProgramacion`, programacion);
  }

  obtenerCompletarInforme(programacion:Programacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_COMPLETAR_INFORME}/obtenerCompletarInforme`,programacion);
  }

  listarUsuarioPrograma(usuarioProgramacion: UsuarioProgramacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_COMPLETAR_INFORME}/listarUsuarioPrograma`, usuarioProgramacion);
  }
  
  obtenerArchivo(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_COMPLETAR_INFORME}/obtenerArchivo`);
  }
  
  obtenerRegistrarInforme(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_COMPLETAR_INFORME}/obtenerRegistrarInforme`);
  }

  guardarInformeSeleccion(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_COMPLETAR_INFORME}/guardarInformeSeleccion`);
  }

  obtenerAgregarDocumento(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_COMPLETAR_INFORME}/obtenerAgregarDocumento`);
  }

  guardarDocumentoInforme(documentoAccion: DocumentoAccion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_COMPLETAR_INFORME}/guardarDocumentoInforme`, documentoAccion);
  }

  guardarDocumentoAccion(documentoAccion: DocumentoAccion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_COMPLETAR_INFORME}/guardarDocumentoAccion`, documentoAccion);
  }
  
  eliminarArchivo():   Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_COMPLETAR_INFORME}/eliminarArchivo`);
  }
}
