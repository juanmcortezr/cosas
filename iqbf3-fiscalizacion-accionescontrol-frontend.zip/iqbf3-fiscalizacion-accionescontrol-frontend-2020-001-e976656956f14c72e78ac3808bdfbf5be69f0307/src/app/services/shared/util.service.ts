import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable, BehaviorSubject } from 'rxjs';
import { ConfirmModalComponent } from 'iqbf';
import { trim, isNotEmpty, isEmpty } from 'src/app/utils/utilitarios';
import { isFunction } from 'util';
import { Constantes } from 'src/app/utils/constantes';
import { Mensaje } from 'src/app/models/interfaces/mensaje.model';
import { Response } from 'src/app/models/response.model';
import { FormGroup, AbstractControl } from '@angular/forms';
import { MensajesExcepciones } from 'src/app/utils/mensajes-excepciones';

@Injectable({
    providedIn: 'root'
})
export class UtilService {

    // Ini - LEMA - Alert
    private _alertaMensaje: BehaviorSubject<Mensaje> = new BehaviorSubject({
        mensajeAlert: null,
        colorAlert: Constantes.MODAL_PRIMARY
    });
    // Fin - LEMA - Alert

    constructor(private http: HttpClient, private modalService: NgbModal) {
    }

    callPOST(url: string, bean?: any): Observable<Response> {
        const parametro: string = isNotEmpty(bean) ? JSON.stringify(bean) : '{}';
        let myHeader = new HttpHeaders();
        myHeader = myHeader.set('Content-Type', 'application/json');
        return this.http.post<Response>(url, parametro, { headers: myHeader });
    }

    callGET(url: string, bean?: any): Observable<Response> {
        const params = new HttpParams();
        if (isNotEmpty(bean)) {
            for (let k in bean) {
                params.set(trim(k), bean[k]);
            }
        }
        return this.http.get<Response>(url, { params: params });
    }

    private mensajeConfirmacion(titulo, mensaje, tipoModal, claseModal, fnSuccess?: () => void, fnDanger?: () => void) {
        const modal = {
            titulo: titulo,
            mensaje: mensaje
        };

        const modalRef = this.modalService.open(ConfirmModalComponent, {});
        modalRef.componentInstance.modal = modal;
        modalRef.componentInstance.tipoModal = tipoModal;
        modalRef.componentInstance.classModal = claseModal;
        modalRef.componentInstance.respuesta.subscribe(data => {
            if (trim(data) === 'SI') {
                if (isFunction(fnSuccess)) {
                    fnSuccess();
                }
            } else if (trim(data) === 'NO') {
                if (isFunction(fnDanger)) {
                    fnDanger();
                }
            }
        });
    }

    // Alerta mensaje simple
    modalMensaje(titulo, mensaje, claseModal) {
        this.mensajeConfirmacion(titulo, mensaje, Constantes.MODAL_OK, claseModal);
    }

    // Alerta confirmacion
    modalConfirmacion(titulo, mensaje, claseModal, fnSuccess?: () => void, fnDanger?: () => void) {
        this.mensajeConfirmacion(titulo, mensaje, Constantes.MODAL_NO_SI, claseModal, fnSuccess, fnDanger);
    }

    // Ini - LEMA - Alert
    // Método público para quien se quiera suscribir a los mensajes
    public escuchaMensaje(): Observable<Mensaje> {
        return this._alertaMensaje.asObservable();
    }

    // Método público para quien quiera emitir un mensaje
    public alertaMensaje(mensaje: string, color: string): void {
        let msj: Mensaje = { mensajeAlert: mensaje, colorAlert: color }
        this._alertaMensaje.next(msj);
    }
    // Fin - LEMA - Alert

    //Ini validar formGroup y formControl
    public getErrorMensajeFormControl(groupName: FormGroup, controlName: string): string {
        //debugger;
        let error = '';
        let nombreError = '';
        const control = groupName.get(controlName);
        if (this.getErrorEstadoFormControl(groupName, controlName)) {
            //error = JSON.stringify(control.errors);
            let objetoError: any = control.errors;
            //Obtener nombre de key
            for (var key in objetoError) {
                nombreError = key;
            }

            switch (nombreError) {
                case 'required':
                    error = 'Campo obligatorio';
                    break;
                case 'minlength':
                    error = `Campo debe tener mínimo ${control.errors.minlength.requiredLength} caracteres`;
                    break;
                case 'maxlength':
                    error = `Campo debe tener máximo ${control.errors.maxlength.requiredLength} caracteres`;
                    break;
                case 'email':
                    error = 'Campo debe tener formato de correo';
                    break;
                case 'pattern':
                    if (control.errors.pattern.requiredPattern == Constantes.VALIDA_PATTERN_SOLO_NUMERO) error = 'Campo debe ser númerico';
                    else error = 'Verificar valor ingresado';
                    break;
                case 'periodoiniafter':
                    error = MensajesExcepciones.CUS01_EXCP_010;
                    break;
                case 'periodofinbefore':
                    error = MensajesExcepciones.CUS01_EXCP_008;
                    break;
                case 'periodofinafter':
                    error = MensajesExcepciones.CUS06_EXCP_007;
                    break;
                default:
                    error = '';
            }
        }
        return error;
    }

    public getErrorClassFormControl(groupName: FormGroup, controlName: string, tipo: string) {
        let estado: boolean = false;
        if (this.getErrorEstadoFormControl(groupName, controlName)) {
            estado = true;
        }

        if (tipo == Constantes.ERROR_CLASS_FORM_CONTROL_LBL) {
            return {
                'text-danger': estado
            };
        } else if (tipo == Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
            return {
                'form-control': true,
                'is-invalid': estado
            };
        }
    }

    public getErrorMensajeCkbFormControl(arrayList: any[], estadoTouched: boolean) {
        if (estadoTouched) {
            return arrayList.length > 0 ? '' : 'Campo obligatorio';
        }
        return '';
    }

    public getErrorClassCkbFormControl(arrayList: any[], estadoTouched: boolean, tipo: string) {
        if (estadoTouched && tipo == Constantes.ERROR_CLASS_FORM_CONTROL_LBL) {
            return {
                'text-danger': arrayList.length > 0 ? false : true
            };
        } else if (estadoTouched && tipo == Constantes.ERROR_CLASS_FORM_CONTROL_TXT) {
            return {
                'form-control': true,
                'is-invalid': arrayList.length > 0 ? false : true
            };
        }
    }

    public getErrorEstadoFormControl(groupName: FormGroup, controlName: string): boolean {
        const control = groupName.get(controlName);
        if (control.errors != null && control.touched) {
            return true;
        }
        return false;
    }

    public validarJsonFecha(control: AbstractControl): { [key: string]: boolean } | null {
        if (isEmpty(control.value) || !Object.keys(control.value).length) {
            return { 'required': true };
        }
        return null;
    }
    //Fin validar formGroup y formControl
}
