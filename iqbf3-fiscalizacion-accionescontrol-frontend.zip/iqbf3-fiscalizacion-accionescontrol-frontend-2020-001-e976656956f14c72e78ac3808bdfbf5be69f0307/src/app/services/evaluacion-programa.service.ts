import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { UsuarioProgramacion } from '../models/usuarioProgramacion.model';
import { UtilService } from './shared/util.service';
import { Programacion } from '../models/programacion.model';

@Injectable({
  providedIn: 'root'
})
export class EvaluacionProgramaService {

  constructor(private util: UtilService, 
    private http: HttpClient) { }

  listarPrograma(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_EVALUACION_PROGRAMA}/listarProgramacion`, programacion);
  }

  obtenerEvaluarPrograma(programacion: Programacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_EVALUACION_PROGRAMA}/obtenerEvaluarPrograma`, programacion);
  }

  obtenerArchivo(numArchivo:number): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_PROGRAMA}/obtenerArchivo/${numArchivo}`);
  }

  listarUsuario(parametro: UsuarioProgramacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_EVALUACION_PROGRAMA}/listarUsuarioProgramacion`, parametro);
  }

  obtenerDocumentoVinculado(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_PROGRAMA}/obtenerDocumentoVinculado`);
  }

  guardarEvaluacionPrograma(programacion: Programacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_EVALUACION_PROGRAMA}/guardarEvaluacionPrograma`, programacion);
  }

}
