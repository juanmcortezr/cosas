import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { SolicitudProgramacion } from '../models/solicitudProgramacion.model';
import { UtilService } from './shared/util.service';

@Injectable({
  providedIn: 'root'
})
export class ConsultaSolicitudService {

  constructor(private http: HttpClient, private util: UtilService, ) { }

  listarConsultaProgramacion(solicitudProgramacion: SolicitudProgramacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_CONSULTA_SOLICITUD}/consultaSolicitudProgramacion`, solicitudProgramacion);
  }

  obtenerExcel(id: number): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_CONSULTA_SOLICITUD}/obtenerExcel/${id}/`);
  }

  obtenerDatosSolicitud(numSolicProg: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerDatosSolicitud/${numSolicProg}`);
  }

  verificarInconsistencia(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_REGISTRO_RESULTADO}/verificarInconsistencia`);
  }

  listarBienesFiscalizados(codTipoBien: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/listarBienesFiscalizados/${codTipoBien}`);
  }
}
