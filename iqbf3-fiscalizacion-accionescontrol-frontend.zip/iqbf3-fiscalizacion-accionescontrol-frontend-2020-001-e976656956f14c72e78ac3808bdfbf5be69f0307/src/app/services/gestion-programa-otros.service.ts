import { Injectable } from '@angular/core';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { Programacion } from '../models/programacion.model';
import { UtilService } from './shared/util.service';

@Injectable({
	providedIn: 'root'
})
export class GestionProgramaOtrosService {

	constructor(private util: UtilService) { }

	listarPrograma(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/programas`, programacion);
	}

	listarActividadFiscalizada(): Observable<Response> {
		return this.util.callGET(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/actividadesFiscalizada`);
	}

	listarProgramador(): Observable<Response> {
		return this.util.callGET(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/programadores`);
	}

	obtenerRegistrarPrograma(numProgramacion: number): Observable<Response> {
		return this.util.callGET(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/programacion/${numProgramacion}`);
	}

	obtenerAsignarPrograma(): Observable<Response> {
		return null;//this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/obtenerAsignarPrograma`);
	}

	obtenerCancelarPrograma(): Observable<Response> {
		return null;//this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/obtenerCancelarPrograma`);
	}

	guardarPrograma(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/guardarPrograma`, programacion);
	}

	enviarPrograma(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/enviarPrograma`, programacion);
	}

	guardarCancelarPrograma(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/guardarCancelarPrograma`, programacion);
	}

	guardarAsignarPrograma(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_OTROS}/guardarAsignarPrograma`, programacion);
	}

}
