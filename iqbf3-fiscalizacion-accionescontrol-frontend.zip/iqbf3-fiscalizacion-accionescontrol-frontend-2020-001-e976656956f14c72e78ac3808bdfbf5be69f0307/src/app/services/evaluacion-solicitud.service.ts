import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { SolicitudProgramacion } from '../models/solicitudProgramacion.model';
import { UtilService } from './shared/util.service';

@Injectable({
  providedIn: 'root'
})
export class EvaluacionSolicitudService {

  constructor(private http: HttpClient, private util: UtilService) { }

  obtenerBandejaEvaluacionSolicitudes(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_SOLICITUD}/obtenerBandejaEvaluacionSolicitudes`);
  }
  obtenerDetalleEvaluarSolicitud(numSolicProg: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_SOLICITUD}/obtenerDetalleEvaluarSolicitud/${numSolicProg}`);
  }
  obtenerUsuarioSeleccionado(idUsuario: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_EVALUACION_SOLICITUD}/obtenerUsuarioSeleccionado/${idUsuario}`);
  }
  guardarEvaluacion(solicitudProgramacion: SolicitudProgramacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_EVALUACION_SOLICITUD}/guardarEvaluacion`, solicitudProgramacion);
  }
  listarSolicitudSupervisorProgramador(solicitudProgramacion: SolicitudProgramacion): Observable<Response> {
    let parametro: string = JSON.stringify(solicitudProgramacion);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_EVALUACION_SOLICITUD}/listarSolicitudSupervisorProgramador`, parametro, { headers: myHeader });
  }
}
