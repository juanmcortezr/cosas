import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { SolicitudProgramacion } from '../models/solicitudProgramacion.model';
import { BienFiscalizadoSolicitud } from '../models/bienFiscalizadoSolicitud.model';
import { UsuarioSolicitud } from '../models/usuarioSolicitud.model';
import { EstablecimientoUsuario } from '../models/establecimientoUsuario.model';
import { CalificacionUsuario } from '../models/calificacionUsuario.model';
import { UtilService } from './shared/util.service';

@Injectable({
  providedIn: 'root'
})
export class GestionSolicitudService {

  constructor(private http: HttpClient,private util: UtilService) { }

  /* Solicitud programacion */

  obtenerBandejadeSolicitudes(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerBandejadeSolicitudes`);
  }

  listarSolicitudProgramacion(solicitudProgramacion: SolicitudProgramacion): Observable<Response> {
    let parametro: string = JSON.stringify(solicitudProgramacion);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/listarSolicitudProgramacion`, parametro, { headers: myHeader });
  }

  obtenerDatosSolicitud(numSolicProg: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerDatosSolicitud/${numSolicProg}`);
  }

  obtenerPaginaNuevaSolicitud(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerPaginaNuevaSolicitud`);
  }

  guardarSolicitud(solicitudProgramacion: SolicitudProgramacion): Observable<Response> {
    let parametro: string = JSON.stringify(solicitudProgramacion);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/guardarSolicitud`, parametro, { headers: myHeader });
  }

  enviarDetalleSolicitudProgram(usuarioSolicitud: UsuarioSolicitud): Observable<Response> {
    let parametro: string = JSON.stringify(usuarioSolicitud);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/enviarDetalleSolicitudProgram`, parametro, { headers: myHeader });
  }

  /* Listados detalla solicitud */

  //Listar usuarios de solicitud
  obtenerDetalleSolicitud(numSolicProg: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerDetalleSolicitud/${numSolicProg}`);
  }

  listarEstablecimientosUsuario(usuarioSolicitud: UsuarioSolicitud): Observable<Response> {
    let parametro: string = JSON.stringify(usuarioSolicitud);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/listarEstablecimientosUsuario`, parametro, { headers: myHeader });
  }

  /* Obtener */

  obtenerDatosUsuario(usuarioSolicitud: UsuarioSolicitud): Observable<Response> {
    let parametro: string = JSON.stringify(usuarioSolicitud);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerDatosUsuario`, parametro, { headers: myHeader });
  }

  obtenerDatosCalificacionUsuario(numUsuarioSolicitud: number): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerDatosCalificacionUsuario/${numUsuarioSolicitud}`);
  }

  obtenerDatosEstablecimientoUsuario(establecimientoUsuario: EstablecimientoUsuario): Observable<Response> {
    let parametro: string = JSON.stringify(establecimientoUsuario);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerDatosEstablecimientoUsuario`, parametro, { headers: myHeader });
  }

  obtenerVigenciaUsuario(usuarioSolicitud: UsuarioSolicitud): Observable<Response> {
    let parametro: string = JSON.stringify(usuarioSolicitud);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerVigenciaUsuario`, parametro, { headers: myHeader });
  }

  /* Guardar */

  guardarUsuario(usuarioSolicitud: UsuarioSolicitud): Observable<Response> {
    let parametro: string = JSON.stringify(usuarioSolicitud);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/guardarUsuario`, parametro, { headers: myHeader });
  }

  guardarCalificacionPreliminar(calificacionUsuario: CalificacionUsuario): Observable<Response> {
    let parametro: string = JSON.stringify(calificacionUsuario);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/guardarCalificacionPreliminar`, parametro, { headers: myHeader });
  }

  guardarEstablecimiento(usuarioSolicitud: UsuarioSolicitud): Observable<Response> {
    let parametro: string = JSON.stringify(usuarioSolicitud);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/guardarEstablecimiento`, parametro, { headers: myHeader });
  }

  /* Editar */

  editarEstablecimientoUsuario(): Observable<Response> {
    let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/editarEstablecimientoUsuario`, parametro);
  }

  /* Eliminar */

  eliminarSolicitudProgramacion(numSolicProg: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/eliminarSolicitudProgramacion/${numSolicProg}`);
  }

  eliminarUsuario(usuarioSolicitud: UsuarioSolicitud): Observable<Response> {
    let parametro: string = JSON.stringify(usuarioSolicitud);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/eliminarUsuario`, parametro, { headers: myHeader });
  }

  eliminarMedioProbatorioGrilla(): Observable<Response> {
    let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/eliminarMedioProbatorioGrilla`, parametro);
  }

  eliminarEstablecimientoUsuario(establecimientoUsuario: EstablecimientoUsuario): Observable<Response> {
    let parametro: string = JSON.stringify(establecimientoUsuario);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/eliminarEstablecimientoUsuario`, parametro, { headers: myHeader });
  }

  eliminarDocumentoReferencia(): Observable<Response> {
    let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/eliminarDocumentoReferencia`, parametro);
  }

  /* Listados */

  listarSolicitudSupervisorSolicitante(solicitudProgramacion: SolicitudProgramacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_GESTION_SOLICITUD}/listarSolicitudSupervisorSolicitante`, solicitudProgramacion);
  }

  listarBienesFiscalizados(codTipoBien: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/listarBienesFiscalizados/${codTipoBien}`);
  }

  listarCriteriosCalificacion(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/criterios`);
  }

  listarAccionesSugeridas(indEstado: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/accionesSugeridas?indEstado=${indEstado}`);
  }

  /* Otros */

  obtenerPaginaAgregarUsuario(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerPaginaAgregarUsuario`);
  }

  obtenerPaginaCalificacionPreliminar(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerPaginaCalificacionPreliminar`);
  }

  obtenerPaginaEstablecimientoUsuario(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/obtenerPaginaEstablecimientoUsuario`);
  }

  cargarenGrillaMedioProbatorio(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_GESTION_SOLICITUD}/cargarenGrillaMedioProbatorio`);
  }

}
