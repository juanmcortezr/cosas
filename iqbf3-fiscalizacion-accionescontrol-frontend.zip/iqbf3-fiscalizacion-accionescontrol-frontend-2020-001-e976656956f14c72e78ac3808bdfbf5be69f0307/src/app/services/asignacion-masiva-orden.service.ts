import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { AsignaUsuarioAccion } from '../models/asignaUsuarioAccion.model';

@Injectable({
  providedIn: 'root'
})
export class AsignacionMasivaOrdenService {

  constructor(private http: HttpClient) { }

  listarPrograma(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/listarPrograma`);
  }

  obtenerAsignarAuditor(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/obtenerAsignarAuditor`);
  }

  obtenerListaAuditor(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/obtenerListaAuditor`);
  }

  guardarAuditorPresel(asignaUsuarioAccion: AsignaUsuarioAccion): Observable<Response> {
    let parametro: string = JSON.stringify(asignaUsuarioAccion);
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/guardarAuditorPresel`, parametro);
  }

  listarAuditor(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/listarAuditor`);
  }

  agregarAuditor(asignaUsuarioAccion: AsignaUsuarioAccion): Observable<Response> {
    let parametro: string = JSON.stringify(asignaUsuarioAccion);
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA_ORDEN}/agregarAuditor`, parametro);
  }
}
