import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { tap, map, catchError, switchMap } from 'rxjs/operators';

import { Programacion } from '../models/programacion.model';
import { UtilService } from './shared/util.service';


@Injectable({
	providedIn: 'root'
})
export class GestionProgramaDefinidoService {

	constructor(private http: HttpClient,private util: UtilService) { }

	obtenerPrograma(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/obtenerPrograma`);
	}

	obtenerRegistrarPrograma(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/obtenerRegistrarPrograma`);
	}

	// METODO QUE BUSCA EN BASE A FILTROS PROGRAMACIONES
	listarProgramaDefinido(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/listarProgramaDefinido`, programacion);
	}
	// METODO QUE LISTA COMBO PROGRAMA CONTROL
    listarTipoProgramaControl () : Observable<Response> {
        return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/listarTipoProgramaControl`);
	}
	// METODO QUE LISTA COMBO PROGRAMA CONTROL
	obtenerProgramaControl(codProgramaControl:String) : Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/obtenerProgramaControl/${codProgramaControl}`);
	}
	
	cargarDatosCalificacionDefinitiva(numSoli: string): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_CALIFICACION_SOLICITUD}/cargarDatosCalificacionDefinitiva/${numSoli}`);
	  }

	obtenerDatoscancelar(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/obtenerDatoscancelar`);
	}

	obtenerDatosActualizar(numProgramacion): Observable<Response> {
		return this.util.callGET(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/obtenerDatosActualizar/${numProgramacion}`);
	}

	guardarPrograma(parametro: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/guardarPrograma`, parametro);
	}

	listarUsuarios(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/listarUsuarios`);
	}

	guardarProgramaActualizado(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
		return this.http.post<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/guardarProgramaActualizado`, parametro);
	}

	enviarPrograma(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/enviarPrograma`);
	}

	eliminarArchivo(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
		return this.http.post<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/eliminarArchivo`, parametro);
	}

	obtenerArchivo(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/obtenerArchivo`);
	}

	guardarCancelarPrograma(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
		return this.http.post<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/guardarCancelarPrograma`, parametro);
	}

	obtenerAccionusuario(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_DEFINIDO}/obtenerAccionusuario`);
	}

}
