import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { SolicitudProgramacion } from '../models/solicitudProgramacion.model';
import { UtilService } from './shared/util.service';
import { CalificacionUsuario } from '../models/calificacionUsuario.model';

@Injectable({
  providedIn: 'root'
})
export class CalificacionSolicitudService {

  constructor(private http: HttpClient, private util: UtilService) { }

  listarSolicitudesporCalificar(solicitudProgramacion: SolicitudProgramacion): Observable<Response> {
    let parametro: string = JSON.stringify(solicitudProgramacion);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type', 'application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_CALIFICACION_SOLICITUD}/listarSolicitudesporCalificar`, parametro, { headers: myHeader });
  }
  cargarDatosCalificacionDefinitiva(numSoli: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_CALIFICACION_SOLICITUD}/cargarDatosCalificacionDefinitiva/${numSoli}`);
  }
  guardarCalificacionDefinitiva(calificacionUsuario: CalificacionUsuario): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_CALIFICACION_SOLICITUD}/guardarCalificacionDefinitiva`, calificacionUsuario);
  }
  enviarCalificacion(solicitudProgramacion: SolicitudProgramacion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_CALIFICACION_SOLICITUD}/enviarCalificacion`, solicitudProgramacion);
  }
  listarCalificacionUsuario(numUsuario: number): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_CALIFICACION_SOLICITUD}/listarCalificacionUsuario/${numUsuario}`);
  }
  listarAlternativaCriterio(numCriterio: number, indEst: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/detalleCriterio/${numCriterio}?indEst=${indEst}`);
  }
  listarAccionesSugeridas(indEstado: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/accionesSugeridas?indEstado=${indEstado}`);
  }
}
