import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { UsuarioProgramacion } from '../models/usuarioProgramacion.model';
import { UtilService } from './shared/util.service';
import { Programacion } from '../models/programacion.model';
import { InformeSeleccion } from '../models/informeSeleccion.model';


@Injectable({
	providedIn: 'root'
})
export class GestionProgramaAsignadoService {

	constructor(private util: UtilService, private http: HttpClient) { }

	//Guarda Informe de Seleccion
	listarPrograma(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/listarPrograma`, programacion);
	}

	cargarRegistrarInforme (numProgramacion:String): Observable<Response> {
		debugger;
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/obtenerRegistrarInformeSelec/${numProgramacion}`);				
	}

	obtenerCargarFiscalizable(numProgramacion: any): Observable<Response> {
		return this.util.callGET(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/obtenerCargarFiscalizable/${numProgramacion}`);
	}
	
	
	//Guarda Informe de Seleccion
	guardarInformeSeleccion(informeSeleccion: InformeSeleccion): Observable<Response> {
		debugger;
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/guardarInformeSeleccion`, informeSeleccion);
	}
	//Guarda Depurar Informe
	guardarDepurarInforme(usuarioProgramacion: UsuarioProgramacion ): Observable<Response> {
		debugger;
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/guardarDepurarInforme`, usuarioProgramacion);
	}
	//Listar Otra Accion
	listarOtraAccion(usuarioProgramacion: UsuarioProgramacion ): Observable<Response> {
		debugger;
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/listarOtraAccion`, usuarioProgramacion);
	}
	
	//guardar Archivo Vinculado
	guardarDocumentoVinculado(usuarioProgramacion: UsuarioProgramacion): Observable<Response> {
		debugger;
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/guardarDocumentoVinculado`, usuarioProgramacion);
	}	
	cargarDocumentoVinculado (usuarioProgramacion: UsuarioProgramacion): Observable<Response> {
		debugger;
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/cargarDocumentoVinculado`, usuarioProgramacion);
	}

	obtenerRegistrarInformeSelec(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/obtenerRegistrarInformeSelec`);
	}

	obtenerPlantillaUniverso(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/obtenerPlantillaUniverso`);
	}

	obtenerDetalleError(numProgramacion: number): Observable<Response> {
		return this.util.callGET(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/obtenerDetalleError/${numProgramacion}`);
	}

	guardarUniversoFiscalizable(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/guardarUniversoFiscalizable`, programacion);
	}

	eliminarArchivo(): Observable<Response> {
		let parametro: string = ""; //JSON.stringify(solicitudProgramacion);
		return this.http.post<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/eliminarArchivo`, parametro);
	}

	obtenerArchivo(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/obtenerArchivo`);
	}

	listarUsuario(parametro:UsuarioProgramacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/listarUsuario`, parametro);
	}

	obtenerAccionUsuario(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/obtenerAccionUsuario`);
	}



	enviarInformeSeleccion(): Observable<Response> {
		return this.http.get<Response>(`${ConstantesUris.URI_GESTION_PROGRAMA_ASIGNADO}/enviarInformeSeleccion`);
	}


}
