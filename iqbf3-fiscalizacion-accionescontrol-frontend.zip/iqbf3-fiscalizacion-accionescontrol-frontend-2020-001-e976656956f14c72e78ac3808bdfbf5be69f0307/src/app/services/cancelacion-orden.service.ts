import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { ListOrdenAccion, OrdenAccion } from '../models/ordenAccion.model';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CancelacionOrdenService {

  constructor(private http: HttpClient) { }

  listarOrdenPrograma(filtro: ListOrdenAccion):  Observable<OrdenAccion[]> {
    
      const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<Response>(`${ConstantesUris.URI_CANCELACION_ORDEN}/listarOrdenPrograma`, filtro, { headers: headers }).pipe(
      map(response  => {
          if (response.exito) {
              return response.data as OrdenAccion[];
          }
      }));   
  }
  obtenerCancelarOrden():  Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_CANCELACION_ORDEN}/obtenerCancelarOrden`);
  }
  eliminarArchivo():  Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_CANCELACION_ORDEN}/eliminarArchivo`);
  }
  obtenerArchivo():  Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_CANCELACION_ORDEN}/obtenerArchivo`);
  }
  guardarDatosOrden():  Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_CANCELACION_ORDEN}/guardarDatosOrden`);
  }
}
