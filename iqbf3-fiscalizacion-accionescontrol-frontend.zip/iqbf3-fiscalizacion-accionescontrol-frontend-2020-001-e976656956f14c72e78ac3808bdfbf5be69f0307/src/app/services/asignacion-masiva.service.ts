import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { AsignaUsuarioAccion } from '../models/asignaUsuarioAccion.model';

@Injectable({
  providedIn: 'root'
})
export class AsignacionMasivaService {

  constructor(private http: HttpClient) { }

  obtenerDatosAsignacion(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA}/obtenerDatosAsignacion`);
  }
  obtenerSeleccionAudtor(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA}/obtenerSeleccionAudtor`);
  }
  guardarAsignacion(asignaUsuarioAccion: AsignaUsuarioAccion): Observable<Response> {
    let parametro: string = JSON.stringify(asignaUsuarioAccion);
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA}/guardarAsignacion`, parametro);
  }
  listarAuditor(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA}/listarAuditor`);
  }
  agregarAuditor(asignaUsuarioAccion: AsignaUsuarioAccion): Observable<Response> {
    let parametro: string = JSON.stringify(asignaUsuarioAccion);
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNACION_MASIVA}/agregarAuditor`, parametro);
  }

}
