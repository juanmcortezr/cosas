import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { SolicitudProgramacion } from '../models/solicitudProgramacion.model';
import { map } from 'rxjs/operators';
import { Programacion, ProgramacionBean } from '../models/programacion.model';

@Injectable({
  providedIn: 'root'
})
export class ConsultaProgramacionService {

  constructor(private http: HttpClient) { }

  listarConsultaSolicitudProgramacion(filtro: ProgramacionBean):  Observable<Programacion[]> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<Response>(`${ConstantesUris.URI_CONSULTA_PROGRAMACION}/listaConsultaProgramacion`, filtro, { headers: headers }).pipe(
      map(response => {
        if (response.exito) {
          return response.data as Programacion[];
      }
      }

      )
    );
  }
}