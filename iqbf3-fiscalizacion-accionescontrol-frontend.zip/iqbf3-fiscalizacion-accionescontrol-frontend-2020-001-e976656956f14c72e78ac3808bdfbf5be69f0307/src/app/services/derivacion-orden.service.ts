import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { UtilService } from './shared/util.service';
import { Programacion } from '../models/programacion.model';
import { OrdenAccion } from '../models/ordenAccion.model';

@Injectable({
  providedIn: 'root'
})
export class DerivacionOrdenService {

  constructor(private util: UtilService,
    private http: HttpClient) { }

  listarPrograma(programacion: Programacion): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_DERIVACION_ORDEN}/listarProgramacion`, programacion);
  }

  obtenerDerivarOrden(numProgramacion: number): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_DERIVACION_ORDEN}/obtenerDerivarOrden/${numProgramacion}`);
  }

  obtenerArchivo(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_DERIVACION_ORDEN}/obtenerArchivo`);
  }

  listarOrdenPrograma(orden: OrdenAccion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_DERIVACION_ORDEN}/listarOrdenPrograma`, orden);
  }

  guardarDerivarOrden(ordenAccion: OrdenAccion): Observable<Response> {
    return this.util.callPOST(`${ConstantesUris.URI_DERIVACION_ORDEN}/derivarOrdenes`, ordenAccion);
  }
}
