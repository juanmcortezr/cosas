import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Response } from '../../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UbigeoService {

  constructor(private http: HttpClient) { }

  listarDepartamentos() : Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_UBIGEO}/departamentos`);
  }

  listarProvincias(codUbigeoDep: string) : Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_UBIGEO}/departamentos/${codUbigeoDep}/provincias`);
  }

  listarDistritos(codUbigeoDep: string, codUbigeoProv: string) : Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_UBIGEO}/departamentos/${codUbigeoDep}/provincias/${codUbigeoProv}/distritos`);
  }
}
