import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Catalogo } from 'src/app/models/catalogo.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Response } from '../../models/response.model';

@Injectable({
  providedIn: 'root'
})
export class CatalogoService {

  constructor(private http: HttpClient) { }

  obtenerCatalogo(codCatalogo: string) : Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_CATALOGO}/${codCatalogo}`);
  }
}
