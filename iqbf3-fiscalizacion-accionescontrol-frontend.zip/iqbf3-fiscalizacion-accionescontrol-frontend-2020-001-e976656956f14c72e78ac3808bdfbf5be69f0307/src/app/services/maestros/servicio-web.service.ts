import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Catalogo } from 'src/app/models/catalogo.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Response } from '../../models/response.model';

@Injectable({
  providedIn: 'root'
})
export class ServicioWebService {

  constructor(private http: HttpClient) { }

  obtenerUnidadOrganica(codUnidadOrganica: string) : Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_SERVICIO_WEB}/unidadOrganica/${codUnidadOrganica}`);
  }

  listarEstablecimientosAnexos(numDocumento: string) : Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_SERVICIO_WEB}/establecimientosDomicilio/${numDocumento}`);
  }

  obtenerDatosRuc(numDocumento: string) : Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_SERVICIO_WEB}/obtenerDatosRuc/${numDocumento}`);
  }

  obtenerPersonaDNI(numDocumento: string) : Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_SERVICIO_WEB}/obtenerPersonaDNI/${numDocumento}`);
  }
}
