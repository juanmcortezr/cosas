import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { AsignaSolicitud } from '../models/asignaSolicitud.model';
import { SolicitudProgramacion } from '../models/solicitudProgramacion.model';
import { UtilService } from './shared/util.service';

@Injectable({
  providedIn: 'root'
})
export class AsignacionSolicitudService {

  constructor(private http: HttpClient, private util:UtilService) { }

  listarSolicitudesporAsignar(solicitudProgramacion: SolicitudProgramacion): Observable<Response> {
    let parametro: string = JSON.stringify(solicitudProgramacion);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNACION_SOLICITUD}/listarSolicitudesAsignar`, parametro, { headers: myHeader});
  }

	cargarAsignacionSolicitud(numSoli: number): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNACION_SOLICITUD}/cargarAsignacionSolicitud/${numSoli}`);
	}

  guardarAsignacionSolicitud(asignaSolicitud: AsignaSolicitud): Observable<Response> {
		return this.util.callPOST(`${ConstantesUris.URI_ASIGNACION_SOLICITUD}/guardarAsignacionSolicitud`, asignaSolicitud);
	}
}