import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';

import { CriterioCalificacion } from 'src/app/models/criterioCalificacion.model';
import { AlternativaCriterio } from '../models/alternativaCriterio.model';
import { AccionSugeridaCalif } from '../models/accionSugeridaCalif.model';

@Injectable({
  providedIn: 'root'
})
export class MantenimientoCriterioService {

  constructor(private http: HttpClient) { }


  //INICIO - JDAVILA

  cargarMantenimientoCriterio(numCriterio: number): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/mantenimientoCriterio/${numCriterio}`);
  }

  guardarCriterio(criterioCalificacion: CriterioCalificacion): Observable<Response> {
    let parametro: string = JSON.stringify(criterioCalificacion);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/criterio`, parametro, { headers: myHeader});
  }

  guardarEstadoCriterio(criterioCalificacion: CriterioCalificacion): Observable<Response> {
    let parametro: string = JSON.stringify(criterioCalificacion);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/estadoCriterio`, parametro, { headers: myHeader});
  }

  eliminarCriterio(criterioCalificacion: CriterioCalificacion): Observable<Response> {
    let parametro: string = JSON.stringify(criterioCalificacion);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/eCriterio`, parametro, { headers: myHeader});
  }

  cargarDetalleCriterio(numCriterio: number,indEst: string, indDel: string): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/detalleCriterio/${numCriterio}?indEst=${indEst}&indDel=${indDel}`);
  }

  guardarAlternativa(alternativaCriterio : AlternativaCriterio): Observable<Response> {
    let parametro: string = JSON.stringify(alternativaCriterio);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/alternativa`, parametro, { headers: myHeader});
  }

  guardarEstadoAlternativa(alternativaCriterio: AlternativaCriterio): Observable<Response> {
    let parametro: string = JSON.stringify(alternativaCriterio);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/estadoAlternativa`, parametro, { headers: myHeader});
  }

  eliminarAlternativa(alternativaCriterio: AlternativaCriterio): Observable<Response> {
    let parametro: string = JSON.stringify(alternativaCriterio);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/eAlternativa`, parametro, { headers: myHeader});
  }

  cargarAccsugerida(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/accionesSugeridas`);
  }

  guardarAccsugerida(accionSugeridaCalif: AccionSugeridaCalif): Observable<Response> {
    let parametro: string = JSON.stringify(accionSugeridaCalif);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/accionSugerida`, parametro, { headers: myHeader});
  }

  guardarEstadoAccSugerida(accionSugeridaCalif: AccionSugeridaCalif): Observable<Response> {
    let parametro: string = JSON.stringify(accionSugeridaCalif);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/estadoAccSugerida`, parametro, {headers: myHeader});
  }

  eliminarAccSugerida(accionSugeridaCalif: AccionSugeridaCalif): Observable<Response> {
    let parametro: string = JSON.stringify(accionSugeridaCalif);
    console.log(parametro);
    let myHeader = new HttpHeaders();
    myHeader = myHeader.set('Content-Type','application/json');
    return this.http.post<Response>(`${ConstantesUris.URI_MANTENIMIENTO_CRITERIO}/eAccSugerida`, parametro, {headers: myHeader});
  }

}
