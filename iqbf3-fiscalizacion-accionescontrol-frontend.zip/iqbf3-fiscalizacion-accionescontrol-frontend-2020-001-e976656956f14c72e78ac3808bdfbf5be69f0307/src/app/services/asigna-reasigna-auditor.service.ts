import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../models/response.model';
import { ConstantesUris } from 'src/app/utils/constantes-uris';
import { Observable } from 'rxjs';
import { AsignaProgramacion } from '../models/asignaProgramacion.model';
import { UsuarioProgramacionBean, UsuarioProgramacion } from '../models/usuarioProgramacion.model';
import { map } from 'rxjs/operators';
import { GrupoProceso } from '../models/grupoProceso.model';

@Injectable({
  providedIn: 'root'
})
export class AsignaReasignaAuditorService {

  constructor(private http: HttpClient) { }

	listarUsuarioProgramacion(filtro:UsuarioProgramacionBean): Observable<UsuarioProgramacion[]> {

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNA_REASIGNA_AUDITOR}/listarUsuarioProgramacion`, filtro, { headers: headers }).pipe(
      map(response => {
        if (response.exito) {
          return response.data as UsuarioProgramacion[];
      }
      }

      )
    );
  }
  
  listarSupervisionAuditor(): Observable<GrupoProceso[]> {

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNA_REASIGNA_AUDITOR}/listarSupervisionAuditor`, { headers: headers }).pipe(
      map(response => {
        if (response.exito) {
          return response.data as GrupoProceso[];
      }
      }

      )
    );
	}

  obtenerAsignarAuditor(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNA_REASIGNA_AUDITOR}/obtenerAsignarAuditor`);
	}

	obtenerAsignarAuditorApoyo(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNA_REASIGNA_AUDITOR}/obtenerAsignarAuditorApoyo`);
	}

	listarAuditorPuesto(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNA_REASIGNA_AUDITOR}/listarAuditorPuesto`);
	}

  guardarAuditorPrin(asignaProgramacion: AsignaProgramacion): Observable<Response> {
		let parametro: string = JSON.stringify(asignaProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNA_REASIGNA_AUDITOR}/guardarAuditorPrin`, parametro);
  }
  
  obtenerAuditorApoyo(): Observable<Response> {
    return this.http.get<Response>(`${ConstantesUris.URI_ASIGNA_REASIGNA_AUDITOR}/obtenerAuditorApoyo`);
	}

  guardarAuditorApoyo(asignaProgramacion: AsignaProgramacion): Observable<Response> {
		let parametro: string = JSON.stringify(asignaProgramacion);
    return this.http.post<Response>(`${ConstantesUris.URI_ASIGNA_REASIGNA_AUDITOR}/guardarAuditorApoyo`, parametro);
  }
}
