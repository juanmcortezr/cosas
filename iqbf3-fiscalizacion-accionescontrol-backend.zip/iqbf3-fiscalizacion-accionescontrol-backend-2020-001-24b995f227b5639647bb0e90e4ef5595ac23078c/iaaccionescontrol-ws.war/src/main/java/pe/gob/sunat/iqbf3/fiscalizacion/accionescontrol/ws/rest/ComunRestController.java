package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.ComunService;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/comun")
public class ComunRestController extends RestControllerBase {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    @EJB(name="accionescontrol.comunService")
    private ComunService comunService;
    
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/descargarArchivo/{numArc}")
	public Response descargarArchivo(@PathParam("numArc") Long numArc, ArchivoBean archivoBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio StatusRestController - current");
		byte[] bytes = comunService.obtenerBytesArchivo(numArc);
		archivoBean.setBlobBase64(DatatypeConverter.printBase64Binary(bytes));
		return ResponseRestUtil.ok(new ResponseBean<>(archivoBean));
	}

}
