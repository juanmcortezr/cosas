package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AgentePuestosCtrlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignacionMasivaAuditoresBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.GrupoProcesoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PreseleccionAsignacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.AsignacionMasivaOrdenService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;


//CUS11
@Path("/asignacionmasivaorden")
public class AsignacionMasivaOrdenRestController extends RestControllerBase {
	
	@EJB
    private AsignacionMasivaOrdenService asignacionMasivaOrdenService;

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarProgramacion")
	public Response listarProgramacion(ProgramacionBean filtro) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio AsignacionMasivaOrdenRestController - listarProgramacion");
		}
		
		List<ProgramacionBean>  programacionBean=asignacionMasivaOrdenService.listarProgramacion(filtro);
		
		System.out.println("en: asignacionMasivaOrden/listarProgramacion=>"+programacionBean);
		
		ResponseBean<List<ProgramacionBean>> respuesta = new ResponseBean<List<ProgramacionBean>>(programacionBean);
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/cargarAsignacionAuditor/{numProgramacion}")
	public Response cargarAsignacionAuditor(@PathParam("numProgramacion") String numProgramacion) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio AsignacionMasivaOrdenRestController - cargarAsignacionAuditor");
		}
		
		ProgramacionBean listProgramacionBean=asignacionMasivaOrdenService.obtenerDatosProgramacion(numProgramacion);
		List<UsuarioProgramacionBean> listUsuarioProgramacionBean=asignacionMasivaOrdenService.listarResumenAccion(numProgramacion);
		listProgramacionBean.setListUsuarioProgramacionBean(listUsuarioProgramacionBean);
		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<ProgramacionBean>(listProgramacionBean);
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/cargarAsignacionAuditorPreseleccion")
	//public Response cargarAsignacionAuditorPreseleccion(@PathParam("numProgramacion") String numProgramacion) {
	public Response cargarAsignacionAuditorPreseleccion(ProgramacionBean filtro) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio AsignacionMasivaOrdenRestController - cargarAsignacionAuditor");
		}
		
		List<PreseleccionAsignacionBean>  listPreseleccionAsignacionBean=asignacionMasivaOrdenService.listarAuditorPresel(filtro.getNumProgramacion().toString(), filtro.getCodTipoAccion());
		
		ResponseBean<List<PreseleccionAsignacionBean>> respuesta = new ResponseBean<List<PreseleccionAsignacionBean>>(listPreseleccionAsignacionBean);
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/obtenerListaAuditor")
	public Response obtenerListaAuditor(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionMasivaOrdenRestController - obtenerListaAuditor");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarAuditorPresel")
	public Response guardarAuditorPresel(List<AsignacionMasivaAuditoresBean> data) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionMasivaOrdenRestController - guardarAuditorPresel");
		System.out.println(data);
		return ResponseRestUtil.ok("prueba");
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarSupervisionAuditor")
	public Response listarSupervisionAuditor() {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio AsignacionMasivaOrdenRestController - listarAuditor");
		}
		
		List<GrupoProcesoBean> listGrupoProcesoBean = asignacionMasivaOrdenService.listarSupervisionAuditor();
		
		System.out.println("en: asignacionMasivaOrden/cargarListaAuditor=>"+listGrupoProcesoBean);
		
		ResponseBean<List<GrupoProcesoBean>> respuesta = new ResponseBean<List<GrupoProcesoBean>>(listGrupoProcesoBean);
		return ResponseRestUtil.ok(respuesta);
	}
	

	//listar auditores segun parametro de combobox
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarAuditoresAuditores/{numGrupo}")
	public Response listarAuditor(@PathParam("numGrupo") String numGrupo) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio AsignacionMasivaOrdenRestController - listarAuditoresAuditores");
		}
		
		List<DistribucionGrupoBean> listDistribucionGrupoBean = asignacionMasivaOrdenService.listarAuditoresAuditores(numGrupo);
		
		ResponseBean<List<DistribucionGrupoBean>> respuesta = new ResponseBean<List<DistribucionGrupoBean>>(listDistribucionGrupoBean);
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarAuditoresAgentes/{codPuestoControl}")
	public Response listarAuditoresAgentes(@PathParam("codPuestoControl") String codPuestoControl) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio AsignacionMasivaOrdenRestController - listarAuditoresAuditores");
		}
		
		List<AgentePuestosCtrlBean> listDistribucionGrupoBean = asignacionMasivaOrdenService.listarAgentePuesto(codPuestoControl);
		
		ResponseBean<List<AgentePuestosCtrlBean>> respuesta = new ResponseBean<List<AgentePuestosCtrlBean>>(listDistribucionGrupoBean);
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/agregarAuditor")
	public Response agregarAuditor(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionMasivaOrdenRestController - agregarAuditor");
		return ResponseRestUtil.ok("prueba");
	}
}
