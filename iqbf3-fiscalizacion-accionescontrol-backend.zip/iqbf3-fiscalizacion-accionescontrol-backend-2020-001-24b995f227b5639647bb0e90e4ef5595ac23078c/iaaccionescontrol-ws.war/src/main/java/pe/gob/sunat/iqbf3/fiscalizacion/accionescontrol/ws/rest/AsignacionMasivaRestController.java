package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/asignacionmasiva")
public class AsignacionMasivaRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDatosAsignacion")
	public Response obtenerDatosAsignacion() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionMasivaRestController - obtenerDatosAsignacion");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerSeleccionAudtor")
	public Response obtenerSeleccionAudtor() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionMasivaRestController - obtenerSeleccionAudtor");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarAsignacion")
	public Response guardarAsignacion() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionMasivaRestController - guardarAsignacion");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarAuditor")
	public Response listarAuditor() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionMasivaRestController - listarAuditor");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/agregarAuditor")
	public Response agregarAuditor() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionMasivaRestController - agregarAuditor");
		return ResponseRestUtil.ok("prueba");
	}

}
