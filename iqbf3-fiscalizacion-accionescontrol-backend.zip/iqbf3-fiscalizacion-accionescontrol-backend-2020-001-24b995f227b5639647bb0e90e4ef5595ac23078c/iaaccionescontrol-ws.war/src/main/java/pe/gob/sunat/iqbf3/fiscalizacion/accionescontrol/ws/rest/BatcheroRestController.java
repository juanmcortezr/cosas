package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.CargaUsuarioBatchService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.DeterminarSeleccionUsuariosBatchService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.EnviarDocumentosSineBatchService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.GenerarDocumentosBatchService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.GenerarOrdenesOtrosProgramasBatchService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.VerificarEstadoNotificacionBatchService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.VerificarLevantamientoInconsistenciaBatchService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/batchero")
public class BatcheroRestController extends RestControllerBase {

	@EJB
	private CargaUsuarioBatchService cargaUsuarioService;

	@EJB
	private GenerarOrdenesOtrosProgramasBatchService generarOrdenesOtrosProgramasBatchService;

	@EJB
	private DeterminarSeleccionUsuariosBatchService determinarSeleccionUsuariosBatchService;

	@EJB
	private EnviarDocumentosSineBatchService enviarDocumentosSineBatchService;

	
	@EJB
	private VerificarEstadoNotificacionBatchService verificarEstadoNotificacionBatchService;
	
	//CUS28
	@EJB
	private VerificarLevantamientoInconsistenciaBatchService verificarLevantamientoInconsistenciaBatchService;
	
	@EJB
	private GenerarDocumentosBatchService generarDocumentosBatchService;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/batcheroCus08/{numProgramacion}")
	public Response batchero08(@PathParam("numProgramacion") Long numProgramacion) {
		try{
			 return ResponseRestUtil.ok(cargaUsuarioService.validarArchivoCarga(numProgramacion));
		} catch(Exception e) {
			return ResponseRestUtil.ok("ERROR : " + e.getMessage());
		}
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/batcheroCus23/{numProgramacion}")
	public Response batchero23(@PathParam("numProgramacion") Long numProgramacion) {
		try{
			 return ResponseRestUtil.ok(determinarSeleccionUsuariosBatchService.iniciarProcesamiento(numProgramacion));
		} catch(Exception e) {
			return ResponseRestUtil.ok("ERROR : " + e.getMessage());
		}
	}

	@GET
	@Path("/batcheroCus15/{numInformeSeleccion}")
	public Response batchero15(@PathParam("numInformeSeleccion") Long numInformeSeleccion) {
		
		try{
		generarOrdenesOtrosProgramasBatchService.generarOrdenesOtrosProgramas(numInformeSeleccion);
		}catch(Exception e){
			return ResponseRestUtil.ok("ERROR : " + e.getMessage());
		}
	  return ResponseRestUtil.ok("OK");
	}
	
	@GET
	@Path("/batcheroCus26")
	public Response batchero26() {
		try{
		enviarDocumentosSineBatchService.enviarDocumentoSine();
		}catch(Exception e){
			return ResponseRestUtil.ok("Error : " + e.getMessage());
		}
		return ResponseRestUtil.ok("OK");
	}
	
	@GET
	@Path("/batcheroCus27")
	public Response batchero27() {
		
		try{
			verificarEstadoNotificacionBatchService.verificarEstadoNotificacion();
		}catch(Exception e){
			return ResponseRestUtil.ok("ERROR : " + e.getMessage());
		}
		
		return ResponseRestUtil.ok("OK");
	}
	
	
	@GET
	@Path("/batcheroCus28/{numProgramacion}")
	public Response batchero28(@PathParam("numProgramacion") Long numProgramacion) {
		
		try{
			
			verificarLevantamientoInconsistenciaBatchService.iniciarProcesamiento(numProgramacion);
			
		}catch(Exception e){
			return ResponseRestUtil.ok("ERROR : " + e.getMessage());
		}
		
		return ResponseRestUtil.ok("OK");
	}
	
	@GET
	@Path("/batcheroCus32")
	public Response batchero32() {
		
		try{
			verificarEstadoNotificacionBatchService.verificarEstadoNotificacion();
		}catch(Exception e){
			return ResponseRestUtil.ok("ERROR : " + e.getMessage());
		}
		
		return ResponseRestUtil.ok("OK");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/batcheroCus25/{numProgramacion}")
	public Response batchero25(@PathParam("numProgramacion") Long numProgramacion) {
		
		try{
			return ResponseRestUtil.ok(generarDocumentosBatchService.generarDocumentos(numProgramacion));
		}catch(Exception e){
			return ResponseRestUtil.ok("ERROR : " + e.getMessage());
		}
	}
}
