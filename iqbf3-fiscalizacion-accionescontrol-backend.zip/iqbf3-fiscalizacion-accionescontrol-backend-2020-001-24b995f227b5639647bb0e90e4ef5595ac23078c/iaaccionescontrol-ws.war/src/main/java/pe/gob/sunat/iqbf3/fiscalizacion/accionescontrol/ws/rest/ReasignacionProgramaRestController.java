package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.ReasignacionProgramaService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/reasignacionprograma")
public class ReasignacionProgramaRestController extends RestControllerBase {
	
	@EJB
	private ReasignacionProgramaService reasignacionProgramaService;
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Context
	private HttpServletRequest request;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarPrograma")
	public Response listarProgramacion(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ReasignacionProgramaRestController - listarProgramacion ");
		ResponseBean<List<ProgramacionBean>> respuesta = new ResponseBean<List<ProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
				
		List<ProgramacionBean> lista = reasignacionProgramaService.listarProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarHistorialAsignaciones/{numProgramacion}/{indTipAsignacion}")
	public Response listarHistorialAsignaciones(@PathParam("numProgramacion") Long numProgramacion,@PathParam("indTipAsignacion") String indTipAsignacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ReasignacionProgramaRestController - listarHistorialAsignaciones");
		ResponseBean<List<AsignaProgramacionBean>> respuesta = new ResponseBean<List<AsignaProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		List<AsignaProgramacionBean> lista = reasignacionProgramaService.listarHistorialAsignaciones(numProgramacion, indTipAsignacion);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<AsignaProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarProgramador/{indTipAsignacion}")
	public Response listarProgramador(@PathParam("indTipAsignacion") String indTipAsignacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - listarProgramador");
		ResponseBean<List<DistribucionGrupoBean>> respuesta = new ResponseBean<List<DistribucionGrupoBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<DistribucionGrupoBean> lista = reasignacionProgramaService.listarProgramador(indTipAsignacion);

		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<DistribucionGrupoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerReasingarProgramador")
	public Response obtenerReasingarProgramador() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ReasignacionProgramaRestController - obtenerReasingarProgramador");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarAsignarPrograma")
	public Response guardarAsignarPrograma() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ReasignacionProgramaRestController - guardarAsignarPrograma");
		return ResponseRestUtil.ok("prueba");
	}

	
	
	
}
