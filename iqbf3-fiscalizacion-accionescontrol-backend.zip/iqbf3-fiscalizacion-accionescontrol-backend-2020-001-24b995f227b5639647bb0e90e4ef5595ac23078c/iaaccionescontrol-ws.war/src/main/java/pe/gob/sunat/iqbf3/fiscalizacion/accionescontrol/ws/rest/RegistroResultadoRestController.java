package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActaEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActividadEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ContactoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DetalleInconsistenciaBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOperacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.EstablecimientoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaIncosistenciaGreNCBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaIncosistenciaSaldoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaIncosistenciaStockBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.TareoAuditorBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoOperacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.RegistroResultadoService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/registroresultado")
public class RegistroResultadoRestController extends RestControllerBase {
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@EJB
	private RegistroResultadoService registroResultadoService;
	
	@Context
	private HttpServletRequest request;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cargarRegistroResultado/{numOrden}")
	public Response cargarRegistroResultadoOrden(@PathParam("numOrden") Long numOrden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - cargarRegistrarResultado");
		ResponseBean<OrdenAccionBean> respuesta = new ResponseBean<OrdenAccionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			OrdenAccionBean orden = registroResultadoService.obtenerDatosOrden(numOrden);
			if (!MaestrosUtilidades.isEmpty(orden)) {
				respuesta = new ResponseBean<OrdenAccionBean>(orden);
			}
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarOrdenesAccion")
	public Response listarOrdenesAccion(OrdenAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - listarOrdenesAccion");
		ResponseBean<List<OrdenAccionBean>> respuesta = new ResponseBean<List<OrdenAccionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<OrdenAccionBean> lista = registroResultadoService.listarOrdenAccion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<OrdenAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerProgramaControl/{numOrden}")
	public Response obtenerTipoProgramaControl(@PathParam("numOrden") Long numOrden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - obtenerTipoProgramaControl");
		ResponseBean<ProgramaControlBean> respuesta = new ResponseBean<ProgramaControlBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ProgramaControlBean programaControlBean = registroResultadoService.obtenerTipoProgramaControl(numOrden);
		if (!MaestrosUtilidades.isEmpty(programaControlBean)) {
			respuesta = new ResponseBean<ProgramaControlBean>(programaControlBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/verDetalleInconsistencia/{numUsuarioProgramacion}")
	public Response verDetalleInconsistencia(@PathParam("numUsuarioProgramacion") Long numUsuarioProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - verDetalleInconsistencia");
		ResponseBean<DetalleInconsistenciaBean> respuesta = new ResponseBean<DetalleInconsistenciaBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		DetalleInconsistenciaBean detalleInconsistenciaBean = new DetalleInconsistenciaBean();
		OrdenAccionBean detalleInconsistencia = registroResultadoService.obtenerDetalleInconsistencia(numUsuarioProgramacion);
		if (!MaestrosUtilidades.isEmpty(detalleInconsistencia)) {
			detalleInconsistenciaBean.setDetalleInconsistencia(detalleInconsistencia);
		}
		List<ProgramaIncosistenciaStockBean> listaStockNegativo = registroResultadoService.listarDetalleStockNegativo(numUsuarioProgramacion);
		if (!MaestrosUtilidades.isEmpty(listaStockNegativo)) {
			detalleInconsistenciaBean.setListaStockNegativo(listaStockNegativo);
		}
		List<ProgramaIncosistenciaSaldoBean> listaSaldoNegativo = registroResultadoService.listarDetalleSaldoNegativo(numUsuarioProgramacion);
		if (!MaestrosUtilidades.isEmpty(listaSaldoNegativo)) {
			detalleInconsistenciaBean.setListaSaldoNegativo(listaSaldoNegativo);
		}
		List<ProgramaIncosistenciaGreNCBean> listaGreNC = registroResultadoService.listarDetalleGreNoConfirmada(numUsuarioProgramacion);
		if (!MaestrosUtilidades.isEmpty(listaGreNC)) {
			detalleInconsistenciaBean.setListaGreNC(listaGreNC);
		}
		if (!MaestrosUtilidades.isEmpty(detalleInconsistenciaBean)) {
			respuesta = new ResponseBean<DetalleInconsistenciaBean>(detalleInconsistenciaBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/verDocumentoAccion/{numOrden}")
	public Response verDocumentoAccion(@PathParam("numOrden") Long numOrden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - verDocumentoAccion");
		ResponseBean<List<DocumentoAccionBean>> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<DocumentoAccionBean> lista = registroResultadoService.listarDocumentoAccion(numOrden);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<DocumentoAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/verificarInconsistencia")
	public Response verificarInconsistencia() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - verificarInconsistencia");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cargarDatosOrden")
	public Response cargarDatosOrden() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - cargarDatosOrden");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/descargarDocumentoAccion")
	public Response descargarDocumentoAccion() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - descargarDocumentoAccion");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/descargarInformeResultado")
	public Response descargarInformeResultado() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - descargarInformeResultado");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/descargarOtroDoc")
	public Response descargarOtroDoc() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - descargarOtroDoc");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarActa")
	public Response guardarActa() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarActa");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarActaBien")
	public Response guardarActaBien() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarActaBien");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarBien")
	public Response guardarBien() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarBien");
		return ResponseRestUtil.ok("prueba");
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarContacto")
	public Response guardarContacto(ContactoOrdenBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarContacto");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(registroResultadoService.guardarContacto(formulario));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarDocumentoOperacion")
	public Response guardarDocumentoOperacion() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarDocumentoOperacion");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarEstablecimiento")
	public Response guardarEstablecimiento(EstablecimientoOrdenBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarEstablecimiento");
		ResponseBean<String> respuesta = new ResponseBean<String>(MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		int resultado = registroResultadoService.guardarEstablecimiento(filtro);
		
		if (!MaestrosUtilidades.isEmpty(resultado)&&resultado>0) {
			respuesta = new ResponseBean<String>(String.valueOf(resultado));
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarOtroDocumento")
	public Response guardarOtroDocumento(DocumentoOrdenBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarOtroDocumento");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(registroResultadoService.guardarOtroDocumento(formulario));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarResultadoOrden")
	public Response guardarResultadoOrden() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarResultadoOrden");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarTareo")
	public Response guardarTareo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarTareo");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/editarActa")
	public Response editarActa() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - editarActa");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/editarActaBien")
	public Response editarActaBien() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - editarActaBien");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/editarBien")
	public Response editarBien() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - editarBien");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/editarEstablecimiento")
	public Response editarEstablecimiento() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - editarEstablecimiento");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/editarOtroDoc")
	public Response editarOtroDoc() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - editarOtroDoc");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarActa")
	public Response eliminarActa() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarActa");
		return ResponseRestUtil.ok("prueba");
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarActaBien")
	public Response eliminarActaBien() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarActaBien");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarBien")
	public Response eliminarBien() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarBien");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarContacto")
	public Response eliminarContacto(ContactoOrdenBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarContacto");
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		ResponseBean<String> response = new ResponseBean<String>();
		response.setExito(false);
		response.setMensaje("");
		if (registroResultadoService.eliminarContacto(filtro)) {
			response.setExito(true);
		}
		return ResponseRestUtil.ok(response);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarEstablecimiento")
	public Response eliminarEstablecimiento() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarEstablecimiento");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarInformeResultado")
	public Response eliminarInformeResultado() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarInformeResultado");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarOperacion")
	public Response eliminarOperacion() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarOperacion");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarOtroDocumento")
	public Response eliminarOtroDocumento() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarOtroDocumento");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarTareo")
	public Response eliminarTareo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarTareo");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/enviarResultadoOrden")
	public Response enviarResultadoOrden() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - enviarResultadoOrden");
		return ResponseRestUtil.ok("prueba");
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarResultadoOrden")
	public Response guardarResultadoOrden(OrdenAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - eliminarTareo");
		ResponseBean<OrdenAccionBean> respuesta = new ResponseBean<OrdenAccionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		int resultado = registroResultadoService.guardarResultadoOrden(filtro);
		if (!MaestrosUtilidades.isEmpty(resultado)&&resultado>0) {
			respuesta = new ResponseBean<OrdenAccionBean>(true, "actualizacion");
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarBien")
	public Response obtenerBien(@QueryParam("numEstabOrden") int numEstabOrden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - obtenerBien");
		ResponseBean<List<BienEstablecimientoBean>> respuesta = new ResponseBean<List<BienEstablecimientoBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		BienEstablecimientoBean bean=new BienEstablecimientoBean();
		bean.setNumEstablecimientoOrden(numEstabOrden);
		List<BienEstablecimientoBean> lista = registroResultadoService.listarBien(bean);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<BienEstablecimientoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarActa")
	public Response obtenerActaEstablecimiento(@QueryParam("numEstabOrden") int numEstabOrden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - obtenerActaEstablecimiento");
		ResponseBean<List<ActaEstablecimientoBean>> respuesta = new ResponseBean<List<ActaEstablecimientoBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ActaEstablecimientoBean bean=new ActaEstablecimientoBean();
		bean.setNumEstablecimientoOrden(numEstabOrden);
		List<ActaEstablecimientoBean> lista = registroResultadoService.listarActa(bean);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ActaEstablecimientoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarActividadEstab")
	public Response listarActividadEstablecimiento(@QueryParam("numEstabOrden") int numEstabOrden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - listarActividadEstablecimiento");
		ResponseBean<List<ActividadEstablecimientoBean>> respuesta = new ResponseBean<List<ActividadEstablecimientoBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ActividadEstablecimientoBean bean=new ActividadEstablecimientoBean();
		bean.setNumEstablecimientoOrden(numEstabOrden);
		List<ActividadEstablecimientoBean> lista = registroResultadoService.listarActividadEstab(bean);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ActividadEstablecimientoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarEstablecimiento")
	public Response listarEstablecimientoOrden(EstablecimientoOrdenBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - listarEstablecimientoOrden");
		ResponseBean<List<EstablecimientoOrdenBean>> respuesta = new ResponseBean<List<EstablecimientoOrdenBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<EstablecimientoOrdenBean> lstBean = registroResultadoService.listarEstablecimiento(filtro);
		
		if (!MaestrosUtilidades.isEmpty(lstBean)) {
			respuesta = new ResponseBean<List<EstablecimientoOrdenBean>>(lstBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarDocumentoOperacion")
	public Response guardarDocumentoOperacion(DocumentoOperacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarDocumentoOperacion");
		ResponseBean<DocumentoOperacionBean> respuesta = new ResponseBean<DocumentoOperacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		DocumentoOperacionBean bean = registroResultadoService.guardarOperacion(filtro);
		
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<DocumentoOperacionBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/actualizarDocumentoOperacion")
	public Response actualizarDocumentoOperacion(DocumentoOperacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - actualizarDocumentoOperacion");
		ResponseBean<DocumentoOperacionBean> respuesta = new ResponseBean<DocumentoOperacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		DocumentoOperacionBean bean = registroResultadoService.actualizarDocumentoOperacion(filtro);
		
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<DocumentoOperacionBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarDocumentoOperacion")
	public Response listarDocumentoOperacion(DocumentoOperacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - listarDocumentoOperacion");
		ResponseBean<List<DocumentoOperacionBean>> respuesta = new ResponseBean<List<DocumentoOperacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		//filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		List<DocumentoOperacionBean> lstBean = registroResultadoService.listarOperacion(filtro);
		
		if (!MaestrosUtilidades.isEmpty(lstBean)) {
			respuesta = new ResponseBean<List<DocumentoOperacionBean>>(lstBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarTareoAuditor")
	public Response guardarTareo(TareoAuditorBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarTareoAuditor");
		ResponseBean<TareoAuditorBean> respuesta = new ResponseBean<TareoAuditorBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		TareoAuditorBean bean = registroResultadoService.guardarTareo(filtro);
		
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<TareoAuditorBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/actualizarTareoAuditor")
	public Response actualizarTareoOrden(TareoAuditorBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - actualizarTareoOrden");
		ResponseBean<TareoAuditorBean> respuesta = new ResponseBean<TareoAuditorBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		TareoAuditorBean bean = registroResultadoService.actualizarTareo(filtro);
		
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<TareoAuditorBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarContactoOrden")
	public Response guardarContactoOrden(ContactoOrdenBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarContactoOrden");
		ResponseBean<ContactoOrdenBean> respuesta = new ResponseBean<ContactoOrdenBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		ContactoOrdenBean bean = registroResultadoService.guardarContactoOrden(filtro);
		
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<ContactoOrdenBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/actualizarContactoOrden")
	public Response actualizarContactoOrden(ContactoOrdenBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - actualizarContactoOrden");
		ResponseBean<ContactoOrdenBean> respuesta = new ResponseBean<ContactoOrdenBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		ContactoOrdenBean bean = registroResultadoService.actualizarContactoOrden(filtro);
		
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<ContactoOrdenBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarDocumentoOrden")
	public Response guardarDocumentoOrden(DocumentoOrdenBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - guardarDocumentoOrden");
		ResponseBean<DocumentoOrdenBean> respuesta = new ResponseBean<DocumentoOrdenBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		DocumentoOrdenBean bean = registroResultadoService.guardarDocumentoOrden(filtro);
		
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<DocumentoOrdenBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/actualizarDocumentoOrden")
	public Response actualizarDocumentoOrden(DocumentoOrdenBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - actualizarDocumentoOrden");
		ResponseBean<DocumentoOrdenBean> respuesta = new ResponseBean<DocumentoOrdenBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		DocumentoOrdenBean bean = registroResultadoService.actualizarDocumentoOrden(filtro);
		
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<DocumentoOrdenBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/actualizarEstablecimiento")
	public Response actualizarEstablecimiento(EstablecimientoOrdenBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoRestController - actualizarEstablecimiento");
		ResponseBean<String> respuesta = new ResponseBean<String>(MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		int resultado = registroResultadoService.actualizarEstablecimientoOrden(filtro);
		
		if (!MaestrosUtilidades.isEmpty(resultado)&&resultado>0) {
			respuesta = new ResponseBean<String>(String.valueOf(resultado));
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
}
