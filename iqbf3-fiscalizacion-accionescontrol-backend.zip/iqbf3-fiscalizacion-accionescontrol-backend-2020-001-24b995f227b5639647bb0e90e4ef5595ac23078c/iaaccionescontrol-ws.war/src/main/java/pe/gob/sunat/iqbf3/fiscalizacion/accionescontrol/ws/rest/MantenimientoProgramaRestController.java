package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.MantenimientoProgramaService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/mantenimientoprograma")
public class MantenimientoProgramaRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@EJB
	private MantenimientoProgramaService mantenimientoProgramaService;
	
	@Context
	private HttpServletRequest request;

	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/programaControl")
	public Response listarProgramaControl(@QueryParam("nominacion") String nominacion, @QueryParam("indEstado") String indEstado) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoProgramaRestController - listarProgramaControl");
		ResponseBean<List<ProgramaControlBean>> respuesta = new ResponseBean<List<ProgramaControlBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<ProgramaControlBean> lista = mantenimientoProgramaService
				.listarProgramaControl(nominacion, indEstado);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ProgramaControlBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/estadoPrograma")
	public Response guardarEstadoPrograma(ProgramaControlBean programaControlBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoProgramaRestController - guardarEstadoPrograma");
		ResponseBean<ProgramaControlBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);

		programaControlBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		ProgramaControlBean bean = mantenimientoProgramaService.guardarEstadoPrograma(programaControlBean);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<>(true, bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cDatosPrograma/{codProgctrl}")
	public Response cargarDatosPrograma(@PathParam("codProgctrl") String codProgctrl) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoProgramaRestController - cargarDatosPrograma");
		ResponseBean<List<ProgramaControlBean>> respuesta = new ResponseBean<List<ProgramaControlBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<ProgramaControlBean> lista = mantenimientoProgramaService.cargarDatosPrograma(codProgctrl);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ProgramaControlBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/gDatosPrograma")
	public Response guardarDatosPrograma(ProgramaControlBean programaControlBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoProgramaRestController - guardarDatosPrograma");

		ResponseBean<ProgramaControlBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);

		programaControlBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		ProgramaControlBean bean = mantenimientoProgramaService.guardarDatosPrograma(programaControlBean);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<>(true, bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
}
