package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActividadesBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PersonaBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.GestionProgramaOtrosService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/gestionprogramaotros")
public class GestionProgramaOtrosRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@EJB
	private GestionProgramaOtrosService gestionProgramaOtrosService;

	@Context
	private HttpServletRequest request;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/programas")
	public Response listarPrograma(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - listarPrograma");
		ResponseBean<List<ProgramacionBean>> respuesta = new ResponseBean<List<ProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		logger.debug(String.format("filtro.getNumInforme() => %s", filtro.getNumInforme()));

		List<ProgramacionBean> lista = gestionProgramaOtrosService.listarPrograma(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/actividadesFiscalizada")
	public Response listarActividadFiscalizada() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - listarActividadFiscalizada");
		ResponseBean<List<ActividadesBean>> respuesta = new ResponseBean<List<ActividadesBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);

		List<ActividadesBean> lista = gestionProgramaOtrosService.listarActividadFiscalizada();
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ActividadesBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/programadores")
	public Response listarProgramador() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - obtenerRegistrarPrograma");
		ResponseBean<List<PersonaBean>> respuesta = new ResponseBean<List<PersonaBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);

		List<PersonaBean> lista = gestionProgramaOtrosService.listarProgramador();
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<PersonaBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/programacion/{numProgramacion}")
	public Response obtenerRegistrarPrograma(@PathParam("numProgramacion") Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - obtenerRegistrarPrograma");
		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ProgramacionBean programa = gestionProgramaOtrosService.obtenerDatosProgramacion(numProgramacion);
		if (!MaestrosUtilidades.isEmpty(programa)) {
			respuesta = new ResponseBean<>(true, programa);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerInformeSelecccion/{numInforme}")
	public Response obtenerInformeSelecccion(@PathParam("numInforme") Long numInforme){
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - obtenerInformeSelecccion");
		ResponseBean<InformeSeleccionBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		InformeSeleccionBean informeSeleccion = gestionProgramaOtrosService.obtenerInformeSelecccion(numInforme);
		if (!MaestrosUtilidades.isEmpty(informeSeleccion)) {
			respuesta = new ResponseBean<>(true, informeSeleccion);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerAsignarPrograma")
	public Response obtenerAsignarPrograma() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - obtenerAsignarPrograma");
		return ResponseRestUtil.ok("prueba");	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerCancelarPrograma")
	public Response obtenerCancelarPrograma() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - obtenerCancelarPrograma");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarPrograma")
	public Response guardarPrograma(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - guardarPrograma");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaOtrosService.guardarPrograma(formulario));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/enviarPrograma")
	public Response enviarPrograma(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - enviarPrograma");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaOtrosService.enviarProgramacion(formulario));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarCancelarPrograma")
	public Response guardarCancelarPrograma(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - guardarCancelarPrograma");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaOtrosService.cancelarProgramacion(formulario));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarAsignarPrograma")
	public Response guardarAsignarPrograma(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - guardarAsignarPrograma");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaOtrosService.guardarAsignacionProgramacion(formulario));
	}
}
