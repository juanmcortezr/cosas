package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.EvaluacionProgramaService;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/evaluacionprograma")
public class EvaluacionProgramaRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Context
    private HttpServletRequest servletRequest;
	@EJB
	private EvaluacionProgramaService evaluacionProgramaService;
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarProgramacion")
	public Response listarPrograma(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaRestController - listarProgramacion ");
		ResponseBean<List<ProgramacionBean>> respuesta = new ResponseBean<List<ProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<ProgramacionBean> lista = evaluacionProgramaService.listarProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerTipoProgramaControl/{numProgramacion}") 
	public Response obtenerTipoProgramaControl(@PathParam("numProgramacion") Integer numProgramacion){
		ResponseBean<List<ProgramaControlBean>> respuesta = new ResponseBean<List<ProgramaControlBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<ProgramaControlBean> lista = evaluacionProgramaService.obtenerTipoProgramaControl(numProgramacion);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ProgramaControlBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerEstadosProgramacion") 
	public Response obtenerEstadosProgramacion(){
		ResponseBean<List<DataCatalogoBean>> respuesta = new ResponseBean<List<DataCatalogoBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<DataCatalogoBean> lista = evaluacionProgramaService.obtenerEstadosProgramacion();
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<DataCatalogoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerEstadosInformeSeleccion") 
	public Response obtenerEstadosInformeSeleccion(){
		ResponseBean<List<DataCatalogoBean>> respuesta = new ResponseBean<List<DataCatalogoBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<DataCatalogoBean> lista = evaluacionProgramaService.obtenerEstadosInformeSeleccion();
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<DataCatalogoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerEvaluarPrograma")
	public Response obtenerEvaluarPrograma(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaRestController - obtenerEvaluarPrograma");
		ResponseBean<MovimientoProgramacion> respuesta = new ResponseBean<MovimientoProgramacion>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		MovimientoProgramacion bean = evaluacionProgramaService.obtenerEvaluarPrograma(filtro);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<MovimientoProgramacion>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerArchivo/{numArchivo}")
	public Response obtenerArchivo(@PathParam("numArchivo") String numArchivo) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaRestController - obtenerArchivo");
		ResponseBean<ArchivoBean> respuesta = new ResponseBean<ArchivoBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ArchivoBean archivoBeanBean = evaluacionProgramaService.obtenerArchivo(Long.valueOf(numArchivo));
		if (!MaestrosUtilidades.isEmpty(archivoBeanBean)) {
			respuesta = new ResponseBean<ArchivoBean>(archivoBeanBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarUsuarioProgramacion")
	public Response listarUsuario(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaRestController - listarUsuarioProgramacion");
		ResponseBean<List<UsuarioProgramacionBean>> respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<UsuarioProgramacionBean> lista = evaluacionProgramaService.listarUsuarioProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cargarDocumentoVinculado")
	public Response cargarDocumentoVinculado(UsuarioProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaRestController - obtenerDocumentoVinculado");
		ResponseBean<UsuarioProgramacionBean> respuesta = new ResponseBean<UsuarioProgramacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		UsuarioProgramacionBean userBean = evaluacionProgramaService.obtenerDocumentoVinculado(formulario);
		if (!MaestrosUtilidades.isEmpty(userBean)) {
			respuesta = new ResponseBean<UsuarioProgramacionBean>(userBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarEvaluacionPrograma")
	public Response guardarEvaluacionPrograma(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaRestController - guardarEvaluacionPrograma");
		AuditoriaBean auditoriaBean = this.obtenerUsuarioBean(servletRequest);
		filtro.setAuditoriaBean(auditoriaBean);
		ResponseBean<Programacion> respuesta = new ResponseBean<Programacion>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		Programacion programacion = evaluacionProgramaService.guardarProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(programacion)) {
			respuesta = new ResponseBean<Programacion>(programacion);
		}
		return ResponseRestUtil.ok(respuesta);
	}
}
