package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.EvaluacionSolicitudService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.GestionSolicitudService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/evaluacionsolicitud")
public class EvaluacionSolicitudRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@EJB
	private EvaluacionSolicitudService evaluacionSolicitudService;

	@EJB
	private GestionSolicitudService gestionSolicitudService;

	@Context
	private HttpServletRequest request;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDetalleEvaluarSolicitud/{numSolicProg}")
	public Response obtenerDetalleEvaluarSolicitud(@PathParam("numSolicProg") Long numSolicProg) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionSolicitudRestController - obtenerDetalleEvaluarSolicitud");
		ResponseBean<SolicitudProgramacionBean> respuesta = new ResponseBean<SolicitudProgramacionBean>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);

		SolicitudProgramacionBean datosSolicitud = evaluacionSolicitudService.obtenerDatosSolicitud(numSolicProg);
		if (!MaestrosUtilidades.isEmpty(datosSolicitud)){
			respuesta = new ResponseBean<SolicitudProgramacionBean>(datosSolicitud);
		}
		
		return ResponseRestUtil.ok(respuesta);
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerUsuarioSeleccionado/{numUsuarioSolicitud}")
	public Response obtenerUsuarioSeleccionado(@PathParam("numUsuarioSolicitud") Long numUsuarioSolicitud) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionSolicitudRestController - obtenerUsuarioSeleccionado");
		ResponseBean<UsuarioSolicitudBean> respuesta = new ResponseBean<UsuarioSolicitudBean>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);

		UsuarioSolicitudBean datosSolicitud = evaluacionSolicitudService.obtenerUsuarioSeleccionado(numUsuarioSolicitud);
		if (!MaestrosUtilidades.isEmpty(datosSolicitud)){
			respuesta = new ResponseBean<UsuarioSolicitudBean>(datosSolicitud);
		}

		return ResponseRestUtil.ok(respuesta);
	}

	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarEvaluacion")
	public Response guardarEvaluacion(SolicitudProgramacionBean solicitudProg) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionSolicitudRestController - guardarEvaluacion");
		ResponseBean<SolicitudProgramacionBean> respuesta = new ResponseBean<SolicitudProgramacionBean>(
				false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		solicitudProg.setAuditoriaBean(this.obtenerUsuarioBean(request));
		solicitudProg = evaluacionSolicitudService.guardarEvaluacion(solicitudProg);
		if (!MaestrosUtilidades.isEmpty(solicitudProg)) {
			respuesta = new ResponseBean<SolicitudProgramacionBean>(true, solicitudProg);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarSolicitudSupervisorProgramador")
	public Response listarSolicitudSupervisorProgramador(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio listarSolicitudSupervisorProgramador - listarSolicitudesporAsignar");
		ResponseBean<List<SolicitudProgramacionBean>> respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(
				false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<SolicitudProgramacionBean> lista = evaluacionSolicitudService.listarSolicitudSupervisorProgramador(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
}
