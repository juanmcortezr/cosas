package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AccionSugeridaCalifBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AlternativaCriterioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CriterioCalificacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.MantenimientoCriterioService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/mantenimientocriterio")
public class MantenimientoCriterioRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@EJB
    private MantenimientoCriterioService mantenimientoCriterioService;
	
	@Context
	private HttpServletRequest request;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/mantenimientoCriterio/{numCriterio}")
	public Response cargarMantenimientoCriterio(@PathParam("numCriterio") Integer numCriterio) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - cargarMantenimientoCriterio");
		ResponseBean<List<CriterioCalificacionBean>> respuesta = new ResponseBean<List<CriterioCalificacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<CriterioCalificacionBean> lista = mantenimientoCriterioService.listarCriterioCalificacion(numCriterio);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<CriterioCalificacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/criterio")
	public Response guardarCriterio(CriterioCalificacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - guardarCriterio");
		ResponseBean<CriterioCalificacionBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		if (!MaestrosUtilidades.isEmpty(filtro)) {
			filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
			CriterioCalificacionBean listaMantenimiento = mantenimientoCriterioService.guardarCriterio(filtro);
			if (!MaestrosUtilidades.isEmpty(listaMantenimiento)) {
				respuesta = new ResponseBean<CriterioCalificacionBean>(listaMantenimiento);
			}
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/estadoCriterio")
	public Response actualizarCriterio(CriterioCalificacionBean criterioCalificacionBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - guardarEstadoCriterio");
		ResponseBean<CriterioCalificacionBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		criterioCalificacionBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		CriterioCalificacionBean bean = mantenimientoCriterioService.actualizarCriterio(criterioCalificacionBean);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<>(true, bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eCriterio")
	public Response eliminarCriterio(CriterioCalificacionBean criterioCalificacionBean){
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - guardarEstadoCriterio");
		ResponseBean<CriterioCalificacionBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		criterioCalificacionBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		CriterioCalificacionBean bean = mantenimientoCriterioService.eliminarCriterio(criterioCalificacionBean);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<>(true, bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/detalleCriterio/{numCriterio}")
	public Response cargarDetalleCriterio(@PathParam("numCriterio") Long numCriterio, @QueryParam("indEst") String indEst, @QueryParam("indDel") String indDel) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - cargarDetalleCriterio");
		ResponseBean<List<AlternativaCriterioBean>> respuesta = new ResponseBean<List<AlternativaCriterioBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<AlternativaCriterioBean> lista = mantenimientoCriterioService.listarAlternativaCriterio(numCriterio, indEst, indDel);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<AlternativaCriterioBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	

	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/alternativa")
	public Response guardarAlternativa(AlternativaCriterioBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - guardarAlternativa");
		ResponseBean<List<AlternativaCriterioBean>> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		if (!MaestrosUtilidades.isEmpty(filtro)) {
			filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
			List<AlternativaCriterioBean> listaMantenimiento = mantenimientoCriterioService.guardarAlternativa(filtro);
			if (!MaestrosUtilidades.isEmpty(listaMantenimiento)) {
				respuesta = new ResponseBean<List<AlternativaCriterioBean>>(listaMantenimiento);
			}
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/estadoAlternativa")
	public Response actualizarAlternativa(AlternativaCriterioBean alternativaCriterioBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - guardarEstadoAlternativa");
		ResponseBean<AlternativaCriterioBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		alternativaCriterioBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		AlternativaCriterioBean bean = mantenimientoCriterioService.actualizarAlternativa (alternativaCriterioBean);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<>(true, bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eAlternativa")
	public Response eliminarAlternativa(AlternativaCriterioBean alternativaCriterioBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - guardarEstadoAlternativa");
		ResponseBean<AlternativaCriterioBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		alternativaCriterioBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		AlternativaCriterioBean bean = mantenimientoCriterioService.eliminarAlternativa(alternativaCriterioBean);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<>(true, bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/accionesSugeridas")
	public Response cargarAccsugerida(@QueryParam("indEstado") String indEstado) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - cargaraccionesSugeridas");
		ResponseBean<List<AccionSugeridaCalifBean>> respuesta = new ResponseBean<List<AccionSugeridaCalifBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<AccionSugeridaCalifBean> lista = mantenimientoCriterioService.listarAccionesSugeridas(indEstado);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<AccionSugeridaCalifBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/accionSugerida")
	public Response guardarAccionSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - guardarAccionSugerida");
		ResponseBean<AccionSugeridaCalifBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		if (!MaestrosUtilidades.isEmpty(accionSugeridaCalifBean)) {
			accionSugeridaCalifBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
			AccionSugeridaCalifBean lista = mantenimientoCriterioService.guardarAccionSugerida(accionSugeridaCalifBean);
			if (!MaestrosUtilidades.isEmpty(lista)) {
				respuesta = new ResponseBean<AccionSugeridaCalifBean>(lista);
			}
		}
		return ResponseRestUtil.ok(respuesta);
	}


	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/criterios")
	public Response listarCriterios() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - listarCriterios");
		ResponseBean<List<CriterioCalificacionBean>> respuesta = new ResponseBean<List<CriterioCalificacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<CriterioCalificacionBean> lista = mantenimientoCriterioService.listarCriterioCalificacion();
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<CriterioCalificacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/estadoAccSugerida")
	public Response actualizarAccSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - guardarEstadoAccSugerida");
		ResponseBean<AccionSugeridaCalifBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
			
		accionSugeridaCalifBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		AccionSugeridaCalifBean bean = mantenimientoCriterioService.actualizarAccSugerida(accionSugeridaCalifBean);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<>(true, bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eAccSugerida")
	public Response eliminarAccSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioRestController - guardarEstadoAccSugerida");
		ResponseBean<AccionSugeridaCalifBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
			
		accionSugeridaCalifBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		AccionSugeridaCalifBean bean = mantenimientoCriterioService.eliminarAccSugerida(accionSugeridaCalifBean);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<>(true, bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
}
