package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.EvaluacionResultadoService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/evaluacionresultado")
public class EvaluacionResultadoRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@EJB
	private EvaluacionResultadoService evaluacionResultadoService;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cargarRegistroResultado")
	public Response cargarRegistroResultado() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - cargarRegistroResultado");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarOrdenesAccion")
	public Response listarOrdenesAccion() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - listarOrdenesAccion");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cargarDatosOrden")
	public Response cargarDatosOrden() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - cargarDatosOrden");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/verDocumentoAccion")
	public Response verDocumentoAccion() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - verDocumentoAccion");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/descargarDocumentoAccion")
	public Response descargarDocumentoAccion() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - descargarDocumentoAccion");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/descargarInformeResultado")
	public Response descargarInformeResultado() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - descargarInformeResultado");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/descargarOtroDoc")
	public Response descargarOtroDoc() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - descargarOtroDoc");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/verEstablecimiento")
	public Response verEstablecimiento() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - verEstablecimiento");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/verBien")
	public Response verBien() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - verBien");
		return ResponseRestUtil.ok("prueba");
	}

		
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarEvaluacionOrden")
	public Response guardarEvaluacionOrden(OrdenAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionResultadoRestController - guardarEvaluacionOrden");
		ResponseBean<OrdenAccionBean> respuesta = new ResponseBean<OrdenAccionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		int resultado = evaluacionResultadoService.actualizarOrden(filtro);
		if (!MaestrosUtilidades.isEmpty(resultado)&&resultado>0) {
			respuesta = new ResponseBean<OrdenAccionBean>(true, "actualizacion");
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
}
