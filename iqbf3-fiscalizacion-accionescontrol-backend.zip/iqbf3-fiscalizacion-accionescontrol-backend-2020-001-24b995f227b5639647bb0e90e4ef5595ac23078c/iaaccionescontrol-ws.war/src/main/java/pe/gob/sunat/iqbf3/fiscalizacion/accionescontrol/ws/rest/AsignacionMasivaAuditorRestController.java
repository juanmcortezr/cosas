package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.AsignacionMasivaAuditorService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
//cus11
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/asignacionmasivaauditor")
public class AsignacionMasivaAuditorRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@EJB
	private AsignacionMasivaAuditorService asignacionMasivaAuditorService;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarResumenOrdenesNoConformes")
	public Response listarResumenOrdenesNoConformes(ProgramacionBean programacionBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionMasivaAuditorRestController - listarResumenOrdenesNoConformes");
		ResponseBean<List<OrdenAccionBean>> respuesta = new ResponseBean<List<OrdenAccionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		List<OrdenAccionBean> lista = asignacionMasivaAuditorService.obtenerResumenOrdPend(programacionBean);
		
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<OrdenAccionBean>>(lista);
		}
		
		return ResponseRestUtil.ok(respuesta);
	}
	
}
