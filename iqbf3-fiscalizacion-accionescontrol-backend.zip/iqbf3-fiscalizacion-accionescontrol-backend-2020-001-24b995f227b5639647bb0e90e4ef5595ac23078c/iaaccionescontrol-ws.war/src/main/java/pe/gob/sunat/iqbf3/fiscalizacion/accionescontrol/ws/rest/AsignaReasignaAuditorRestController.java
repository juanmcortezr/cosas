package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AgentePuestosCtrlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaUsuarioAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.GrupoProcesoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.AsignaReasignaAuditorService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/asignareasignaauditor")
public class AsignaReasignaAuditorRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@EJB
	private AsignaReasignaAuditorService asignaReasignaAuditorService;
		
	@Context
	HttpServletRequest request;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarPrograma")
	public Response listarPrograma() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - listarPrograma");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerAsignarAuditor")
	public Response obtenerAsignarAuditor() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - obtenerAsignarAuditor");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerAsignarAuditorApoyo")
	public Response obtenerAsignarAuditorApoyo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - obtenerAsignarAuditorApoyo");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarAuditorPuesto")
	public Response listarAuditorPuesto() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - listarAuditorPuesto");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarAuditorPrin")
	public Response guardarAuditorPrin() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - guardarAuditorPrin");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerAuditorApoyo")
	public Response obtenerAuditorApoyo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - obtenerAuditorApoyo");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarAuditorApoyo")
	public Response guardarAuditorApoyo(AsignaUsuarioAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - guardarAuditorApoyo");
		ResponseBean<AsignaUsuarioAccionBean> respuesta = new ResponseBean<AsignaUsuarioAccionBean>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		AsignaUsuarioAccionBean bean = asignaReasignaAuditorService.guardarAuditorApoyo(filtro);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<AsignaUsuarioAccionBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarUsuarioProgramacion")
	public Response listarUsuarioProgramacion(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - listarUsuario");
		ResponseBean<List<UsuarioProgramacionBean>> respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		logger.debug(String.format("filtro.getNumInforme() => %s", filtro.getNumUsuarioPrograma()));

		List<UsuarioProgramacionBean> lista = asignaReasignaAuditorService.listarUsuarioProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarSupervisionAuditor")
	public Response listarSupervisionAuditor() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - listarSupervisionAuditor");
		ResponseBean<List<GrupoProcesoBean>> respuesta = new ResponseBean<List<GrupoProcesoBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<GrupoProcesoBean> lista = asignaReasignaAuditorService.listarSupervisionAuditor();
		
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<GrupoProcesoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
//	@POST
//	@Produces(MediaType.APPLICATION_JSON)
//	@Consumes(MediaType.APPLICATION_JSON)
//	@Path("/listarSupervisionAuditor")
//	public Response listarPuestosControl() {
//		if (logger.isDebugEnabled())
//			logger.debug("Inicio AsignaReasignaAuditorRestController - listarPuestosControl");
//		ResponseBean<List<Catalog>> respuesta = new ResponseBean<List<Catalog>>(false,
//				MaestrosMensajes.MENSAJE_LISTA_VACIA);
//		List<CatalogBean> lista = asignaReasignaAuditorService.listarSupervisionAuditor();
//		
//		if (!MaestrosUtilidades.isEmpty(lista)) {
//			respuesta = new ResponseBean<List<Catalog>>(lista);
//		}
//		return ResponseRestUtil.ok(respuesta);
//	}

	// CONSULTAR
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarAuditorPrincipal/{numGrupo}")
	public Response listarAuditorPrincipal(@PathParam("numGrupo") String numGrupo) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - listarAuditorPrincipal");
		ResponseBean<List<AsignaUsuarioAccionBean>> respuesta = new ResponseBean<List<AsignaUsuarioAccionBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<AsignaUsuarioAccionBean> lista = asignaReasignaAuditorService.listarAuditorPrincipal(numGrupo);

		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<AsignaUsuarioAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/obtenerAsigUsuarioAccion")
	public Response obtenerAsigUsuarioAccion(AsignaUsuarioAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - obtenerAsigUsuarioAccion");
		ResponseBean<List<AsignaUsuarioAccionBean>> respuesta = new ResponseBean<List<AsignaUsuarioAccionBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<AsignaUsuarioAccionBean> lista = asignaReasignaAuditorService.obtenerAsigUsuarioAccion(filtro);

		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<AsignaUsuarioAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarAgentePuesto/{codPuesto}/{codRol}")
	public Response listarAgentePuesto(@PathParam("codPuesto") String codPuesto, @PathParam("codRol") String codRol) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - obtenerAsigUsuarioAccion");
		ResponseBean<List<AgentePuestosCtrlBean>> respuesta = new ResponseBean<List<AgentePuestosCtrlBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<AgentePuestosCtrlBean> lista = asignaReasignaAuditorService.listarAgentePuesto(codPuesto, codRol);

		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<AgentePuestosCtrlBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	// CONSULTAR
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listaCargaAuditoresPrincipales/{numProgramacion}")
	public Response listaCargaAuditoresPrincipales(@PathParam("numProgramacion") String numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - obtenerAsigUsuarioAccion");
		ResponseBean<List<AsignaUsuarioAccionBean>> respuesta = new ResponseBean<List<AsignaUsuarioAccionBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<AsignaUsuarioAccionBean> lista = asignaReasignaAuditorService.listaCargaAuditoresPrincipales(numProgramacion);

		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<AsignaUsuarioAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	// CONSULTAR
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarAuditorPrincipal")
	public Response guardarAuditorPrincipal(AsignaUsuarioAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - guardarAsignacionProgramacion");
		ResponseBean<AsignaUsuarioAccionBean> respuesta = new ResponseBean<AsignaUsuarioAccionBean>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		AsignaUsuarioAccionBean bean = asignaReasignaAuditorService.guardarAuditorPrincipal(filtro);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<AsignaUsuarioAccionBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarAuditorApoyo")
	public Response listarAuditorApoyo(DistribucionGrupoBean bean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - listarAuditoresApoyo");
		ResponseBean<List<DistribucionGrupoBean>> respuesta = new ResponseBean<List<DistribucionGrupoBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<DistribucionGrupoBean> lista = asignaReasignaAuditorService.listarAuditorApoyo(bean);

		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<DistribucionGrupoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarAuditorApoyoAsignado/{num}")
	public Response listarAuditorApoyoAsignado(@PathParam("num") Long num) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorRestController - listarAuditorApoyo");
		ResponseBean<List<DistribucionGrupoBean>> respuesta = new ResponseBean<List<DistribucionGrupoBean>>(false,
				MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<DistribucionGrupoBean> lista = asignaReasignaAuditorService.listarAuditorApoyoAsignado(num);

		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<DistribucionGrupoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarAuditoresAgentes")
	public Response listarAuditoresAgentes(AsignaUsuarioAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - listarAuditoresAgentes");
		ResponseBean<List<AsignaUsuarioAccionBean>> respuesta = new ResponseBean<List<AsignaUsuarioAccionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<AsignaUsuarioAccionBean> lista = asignaReasignaAuditorService.listarAuditoresAgentes(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<AsignaUsuarioAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	

	/*@GET
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/asignacion/{numUsuarioPrograma}")
	 public Response cargarAsignacionAuditor(@PathParam("numUsuarioPrograma") String numUsuarioPrograma){
	 //Long numUsuarioPrograma){
	 if(logger.isDebugEnabled())
	 logger.debug("Inicio AsignaReasignaAuditorRestController -	 cargarAsignacionAuditor");
	 ResponseBean<AsignaUsuarioAccionBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
	 AsignaUsuarioAccionBean asignacion = asignaReasignaAuditorService.obtenerDatosAccion(numUsuarioPrograma);
	 if(!MaestrosUtilidades.isEmpty(asignacion)){
	 respuesta = new ResponseBean<>(true, asignacion);
	 }
	 return ResponseRestUtil.ok(respuesta);
	
	 }*/

}
