package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CalificacionUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.CalificacionSolicitudService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/calificacionsolicitud")
public class CalificacionSolicitudRestController extends RestControllerBase {
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@EJB
	private CalificacionSolicitudService calificacionSolicitudService;

	@Context
	private HttpServletRequest request;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarSolicitudesporCalificar")
	public Response listarSolicitudesporCalificar(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudRestController - listarSolicitudesporCalificar");
		ResponseBean<List<SolicitudProgramacionBean>> respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(
				false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<SolicitudProgramacionBean> lista = calificacionSolicitudService.listarSolicitudesporCalificar(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cargarDatosCalificacionDefinitiva/{numSolicProg}")
	public Response cargarDatosCalificacionDefinitiva(@PathParam("numSolicProg") Long numSolicProg){
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudRestController - cargarDatosCalificacionDefinitiva");
		ResponseBean<List<UsuarioSolicitudBean>> respuesta = new ResponseBean<List<UsuarioSolicitudBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<UsuarioSolicitudBean> califiSolicitud = calificacionSolicitudService.listarUsuarioSolicitud(numSolicProg);
		if (!MaestrosUtilidades.isEmpty(califiSolicitud)) {
			respuesta = new ResponseBean<List<UsuarioSolicitudBean>>(califiSolicitud);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarCalificacionUsuario/{numUsuarioSolic}")
	public Response listarCalificacionUsuario(@PathParam("numUsuarioSolic") Long numUsuarioSolic) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudRestController - listarCalificacionUsuario");
		ResponseBean<List<CalificacionUsuarioBean>> respuesta = new ResponseBean<List<CalificacionUsuarioBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<CalificacionUsuarioBean> calificaciones = calificacionSolicitudService.listarCalificacionUsuario(numUsuarioSolic);
		if (!MaestrosUtilidades.isEmpty(calificaciones)) {
			respuesta = new ResponseBean<List<CalificacionUsuarioBean>>(calificaciones);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarCalificacionDefinitiva")
	public Response guardarCalificacionDefinitiva(CalificacionUsuarioBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudRestController - guardarCalificacionDefinitiva");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(calificacionSolicitudService.guardarCalificacionDefinitiva(formulario));
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/enviarCalificacion")
	public Response enviarCalificacion(SolicitudProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudRestController - enviarCalificacion");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(calificacionSolicitudService.enviarCalificacion(formulario));
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cargarDetalleUsuario/{numUsuario}")
	public Response cargarDetalleUsuario(@PathParam("numUsuario") String numUsuario){
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionSolicitudRestController - cargarDetalleUsuario");
		ResponseBean<UsuarioSolicitudBean> respuesta = new ResponseBean<UsuarioSolicitudBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		/*UsuarioSolicitudBean usuarioSolicitud = calificacionSolicitudService.obtenerDatosUsuario(Integer.valueOf(numUsuario));
		if (!MaestrosUtilidades.isEmpty(usuarioSolicitud)) {
			respuesta = new ResponseBean<UsuarioSolicitudBean>(usuarioSolicitud);
		}*/
		return ResponseRestUtil.ok(respuesta);
		/*formulario = calificacionSolicitudService.enviarCalificacion(formulario);
		return ResponseRestUtil.ok(new ResponseBean<SolicitudProgramacionBean>(formulario));*/
	}

}
