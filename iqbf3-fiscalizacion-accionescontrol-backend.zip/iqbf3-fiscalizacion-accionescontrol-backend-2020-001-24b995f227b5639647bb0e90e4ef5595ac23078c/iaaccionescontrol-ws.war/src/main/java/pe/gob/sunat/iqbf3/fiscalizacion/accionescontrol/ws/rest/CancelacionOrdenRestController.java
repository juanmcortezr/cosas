package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.CancelacionOrdenservce;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/cancelacionorden")
public class CancelacionOrdenRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@EJB
	private CancelacionOrdenservce cancelacionOrdenservce;

	@Context
    private HttpServletRequest servletRequest;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarOrdenPrograma")
	public Response listarOrdenPrograma(OrdenAccionBean programacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CancelacionOrdenRestController - listarOrdenPrograma");
		ResponseBean<List<OrdenAccionBean>> respuesta = new ResponseBean<List<OrdenAccionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<OrdenAccionBean> lista = cancelacionOrdenservce.listarOrden(programacion);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<OrdenAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerCancelarOrden/{orden}")
	public Response obtenerCancelarOrden(@PathParam("orden") Long orden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CancelacionOrdenRestController - obtenerCancelarOrden");
		ResponseBean<OrdenAccionBean> respuesta = new ResponseBean<OrdenAccionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);		
		OrdenAccionBean ordenBean = cancelacionOrdenservce.obtenerDatosOrden(orden);
		if (!MaestrosUtilidades.isEmpty(ordenBean)) {
			respuesta = new ResponseBean<OrdenAccionBean>(ordenBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarArchivo")
	public Response eliminarArchivo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CancelacionOrdenRestController - eliminarArchivo");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerArchivo")
	public Response obtenerArchivo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CancelacionOrdenRestController - obtenerArchivo");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarDatosOrden")
	public Response guardarDatosOrden(OrdenAccionBean ordeBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CancelacionOrdenRestController - guardarDatosOrden");
		ResponseBean<OrdenAccion> respuesta = new ResponseBean<OrdenAccion>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		AuditoriaBean auditoriaBean = this.obtenerUsuarioBean(servletRequest);
		ordeBean.setAuditoriaBean(auditoriaBean);
		OrdenAccion ordenBean = cancelacionOrdenservce.actualizarOrden(ordeBean);
		if (!MaestrosUtilidades.isEmpty(ordenBean)) {
			respuesta = new ResponseBean<OrdenAccion>(ordenBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

}
