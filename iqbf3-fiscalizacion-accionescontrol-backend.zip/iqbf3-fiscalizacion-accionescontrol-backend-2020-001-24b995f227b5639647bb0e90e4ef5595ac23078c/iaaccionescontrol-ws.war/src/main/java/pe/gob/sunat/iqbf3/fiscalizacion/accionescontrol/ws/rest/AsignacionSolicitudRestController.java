package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.AsignacionSolicitudService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/asignacionsolicitud")
public class AsignacionSolicitudRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@EJB
	private AsignacionSolicitudService asignacionSolicitudService;

	@Context
	private HttpServletRequest request;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarSolicitudesAsignar")
	public Response listarSolicitudesporAsignar(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionSolicitudRestController - listarSolicitudesporAsignar");
		ResponseBean<List<SolicitudProgramacionBean>> respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(
				false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<SolicitudProgramacionBean> lista = asignacionSolicitudService.listarSolicitudesporAsignar(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cargarAsignacionSolicitud/{numSolicProg}")
	public Response cargarAsignacionSolicitud(@PathParam("numSolicProg") Long numSolicProg) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionSolicitudRestController - cargarAsignacionSolicitud");
		ResponseBean<List<AsignaProgramacionBean> > respuesta = new ResponseBean<List<AsignaProgramacionBean> >(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<AsignaProgramacionBean> listAsignacionSolicitud = asignacionSolicitudService.listarHistoriaAsignaciones(numSolicProg);
		if (!MaestrosUtilidades.isEmpty(listAsignacionSolicitud)) {
			respuesta = new ResponseBean<List<AsignaProgramacionBean>>(listAsignacionSolicitud);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarAsignacionSolicitud")
	public Response guardarAsignacionSolicitud(AsignaProgramacionBean asignacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionSolicitudRestController - guardarAsignacionSolicitud");
		ResponseBean<AsignaProgramacionBean> respuesta = new ResponseBean<AsignaProgramacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		asignacion.setAuditoriaBean(this.obtenerUsuarioBean(request));
		asignacion = asignacionSolicitudService.guardarAsignacionSolicitud(asignacion);
		if (asignacion.getNumAsignacion() != 0) {
			respuesta = new ResponseBean<>(true, asignacion);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
}
