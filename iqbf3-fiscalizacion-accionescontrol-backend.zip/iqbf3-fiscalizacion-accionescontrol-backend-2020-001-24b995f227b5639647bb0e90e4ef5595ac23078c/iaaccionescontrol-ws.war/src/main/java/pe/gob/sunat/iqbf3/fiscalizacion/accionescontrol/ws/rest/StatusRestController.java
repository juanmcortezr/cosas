package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.registro.maestros.bean.VersionBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/status")
public class StatusRestController extends RestControllerBase {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/current")
	public Response current() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio StatusRestController - current");
		return ResponseRestUtil.ok(new VersionBean("OK", "0.0.1"));
	}
}
