package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.config;

import java.util.Set;
import java.util.stream.Collectors;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.glassfish.jersey.jackson.JacksonFeature;
import org.reflections.Reflections;

import pe.gob.sunat.iqbf3.registro.maestros.utils.CORSFilter;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;
import pe.gob.sunat.iqbf3.registro.maestros.utils.exception.mapper.GenericExceptionMapper;
import pe.gob.sunat.iqbf3.registro.maestros.utils.exception.mapper.UnprocessableEntityExceptionMapper;
import pe.gob.sunat.iqbf3.registro.maestros.utils.exception.mapper.WebApplicationExceptionMapper;

@ApplicationPath("")
public class ApplicationConfig extends Application {

    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<Class<?>>();
        resources.add(JacksonFeature.class);
        resources.addAll(getRestClasses());
        return resources;
    }

    private Set<Class<?>> getRestClasses() {
        Reflections reflections = new Reflections("pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest");
        return reflections.getSubTypesOf(RestControllerBase.class).stream()
        		.filter(r -> r.getCanonicalName().endsWith("RestController")).collect(Collectors.toSet());
    }

    public Set<Object> getSingletons() {
        Set<Object> providers = new java.util.HashSet<Object>();
        providers.add(new CORSFilter());
        providers.add(UnprocessableEntityExceptionMapper.class);
        providers.add(WebApplicationExceptionMapper.class);
        providers.add(GenericExceptionMapper.class);
        return providers;
    }

}