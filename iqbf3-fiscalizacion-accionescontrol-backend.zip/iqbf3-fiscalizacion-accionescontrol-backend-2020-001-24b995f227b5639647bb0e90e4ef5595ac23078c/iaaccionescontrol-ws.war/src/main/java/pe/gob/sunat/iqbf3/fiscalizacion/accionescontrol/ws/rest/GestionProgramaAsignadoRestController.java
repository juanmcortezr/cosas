package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.GestionProgramaAsignadoService;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSUnidadOrgBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/gestionprogramaasignado")
public class GestionProgramaAsignadoRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@EJB
	private GestionProgramaAsignadoService gestionProgramaAsignadoService;

	@Context
	private HttpServletRequest request;
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarPrograma")
	public Response listarPrograma(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - listarPrograma");
		ResponseBean<List<ProgramacionBean>> respuesta = new ResponseBean<List<ProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		logger.debug(String.format("filtro.getNumInforme() => %s", filtro.getNumInforme()));

		List<ProgramacionBean> lista = gestionProgramaAsignadoService.listarPrograma(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerCargarFiscalizable/{numProgramacion}")
	public Response obtenerCargarFiscalizable(@PathParam("numProgramacion") Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - obtenerCargarFiscalizable");
		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<ProgramacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ProgramacionBean programacion = gestionProgramaAsignadoService.obtenerCargarFiscalizable(numProgramacion);
		if (!MaestrosUtilidades.isEmpty(programacion)) {
			respuesta = new ResponseBean<>(programacion);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerRegistrarInformeSelec/{numProgramacion}")
	public Response obtenerRegistrarInformeSelec(@PathParam("numProgramacion") Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - obtenerRegistrarInformeSelec");
		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<ProgramacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ProgramacionBean programacion = gestionProgramaAsignadoService.obtenerDatosProgramacion(numProgramacion);
		if (!MaestrosUtilidades.isEmpty(programacion)) {
			respuesta = new ResponseBean<>(programacion);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerPlantillaUniverso")
	public Response obtenerPlantillaUniverso() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - obtenerPlantillaUniverso");
		return ResponseRestUtil.ok(new ResponseBean<ArchivoBean>(gestionProgramaAsignadoService.descargarPlantilla()));
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDetalleError/{numProgramacion}")
	public Response obtenerDetalleError(@PathParam("numProgramacion") Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - obtenerDetalleError");
		ResponseBean<ArchivoBean> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ArchivoBean archivo = gestionProgramaAsignadoService.obtenerDetalleError(numProgramacion);
		if (!MaestrosUtilidades.isEmpty(archivo)) {
			respuesta = new ResponseBean<>(archivo);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarUniversoFiscalizable")
	public Response guardarUniversoFiscalizable(ProgramacionBean programacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - guardarUniversoFiscalizable");
		programacion.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaAsignadoService.guardarUniversoFiscalizable(programacion));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarArchivo")
	public Response eliminarArchivo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - eliminarArchivo");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerArchivo")
	public Response obtenerArchivo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - obtenerArchivo");
		return ResponseRestUtil.ok("prueba");
	}


	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/validarCodigoUUOO/{codUnidadOrganica}")
	public Response validarCodigoUUOO(@PathParam("codUnidadOrganica") String codUnidadOrganica) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - listarUsuario");
		ResponseBean<WSUnidadOrgBean> respuesta = new ResponseBean<WSUnidadOrgBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		WSUnidadOrgBean UnidadOrgBean = gestionProgramaAsignadoService.validarCodigoUUOO(codUnidadOrganica);
		if (!MaestrosUtilidades.isEmpty(UnidadOrgBean)) {
			respuesta = new ResponseBean<WSUnidadOrgBean>(UnidadOrgBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarUsuario")
	public Response listarUsuario(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - listarUsuario");
		ResponseBean<List<UsuarioProgramacionBean>> respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<UsuarioProgramacionBean> lista = gestionProgramaAsignadoService.listarUsuarioProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	 
	
//	@POST
//	@Consumes(MediaType.APPLICATION_JSON)
//	@Produces(MediaType.APPLICATION_JSON)
//	@Path("/listarOtraAccion")
//	public Response listarOtraAccion(UsuarioProgramacionBean filtro) {
//		if (logger.isDebugEnabled())
//			logger.debug("Inicio GestionProgramaAsignadoRestController - listarUsuario");
//		ResponseBean<List<UsuarioProgramacionBean>> respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
//		List<UsuarioProgramacionBean> lista = gestionProgramaAsignadoService.listarOtraAccion(filtro);
//		if (!MaestrosUtilidades.isEmpty(lista)) {
//			respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(lista);
//		}
//		return ResponseRestUtil.ok(respuesta);
//	}
	

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerAccionUsuario")
	public Response obtenerAccionUsuario() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - obtenerAccionUsuario");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerAdjuntarDocVinculado")
	public Response obtenerAdjuntarDocVinculado() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - obtenerAdjuntarDocVinculado");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarDepurarInforme")
	public Response guardarDepurarInforme(UsuarioProgramacionBean usuarioBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - guardarDepurarInforme");
		usuarioBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaAsignadoService.guardarUsuario(usuarioBean));
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarInformeSeleccion")
	public Response guardarInformeSeleccion(InformeSeleccionBean informeBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - guardarInformeSeleccion");
		informeBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaAsignadoService.guardarInformeSeleccion(informeBean));
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/enviarInformeSeleccion")
	public Response enviarInformeSeleccion(InformeSeleccionBean informeBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - guardarInformeSeleccion");
		informeBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaAsignadoService.enviarInformeSeleccion(informeBean));
	}


	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarDocumentoVinculado")
	public Response guardarDocumentoVinculado(UsuarioProgramacionBean usuarioBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - guardarDocumentoVinculado");
		usuarioBean.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaAsignadoService.guardarDocumentoVinculado(usuarioBean));
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/cargarDocumentoVinculado")
	public Response cargarDocumentoVinculado(UsuarioProgramacionBean usuarioBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoRestController - cargarDocumentoVinculado");		
		ResponseBean<List<UsuarioProgramacionBean>> respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<UsuarioProgramacionBean> lista=gestionProgramaAsignadoService.obtenerDatosDocVin(usuarioBean);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);	
		
	}
	

}
