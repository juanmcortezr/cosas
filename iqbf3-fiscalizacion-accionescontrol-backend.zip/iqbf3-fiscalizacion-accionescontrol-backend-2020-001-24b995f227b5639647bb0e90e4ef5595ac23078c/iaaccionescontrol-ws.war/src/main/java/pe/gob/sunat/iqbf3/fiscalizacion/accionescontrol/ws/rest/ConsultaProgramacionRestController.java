package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActividadesBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.ConsultaProgramacionService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.GestionProgramaOtrosService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/consultaprogramacion")
public class ConsultaProgramacionRestController extends RestControllerBase {
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@EJB
    private ConsultaProgramacionService consultaProgramacionService;
	
	@EJB
	private GestionProgramaOtrosService gestionProgramaOtrosService;
	
	@Context
	private HttpServletRequest request;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listaConsultaProgramacion")
	public Response listarConsultaProgramacion (ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ConsultaProgramacionRestController - listarConsultaProgramacion");
		ResponseBean<List<ProgramacionBean>> respuesta = new ResponseBean<List<ProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		
		logger.debug(String.format("filtro.getNroInformeUnion() => %s", filtro.getNroInformeUnion()));
		logger.debug(String.format("filtro.getNumDocAccion() => %s", filtro.getNumDocAccion()));
		logger.debug(String.format("filtro.getNumOrden() => %s", filtro.getNumOrden()));
		logger.debug(String.format("filtro.getNumDocVin() => %s", filtro.getNumDocVin()));
		
		List<ProgramacionBean> lista = consultaProgramacionService.listarConsultaProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarBienFiscalizado/{codTipoBien}")
	public Response listarBienesFiscalizados(@PathParam("codTipoBien") String codTipoBien){
		if(logger.isDebugEnabled())
			logger.debug("Inicio ConsultaProgramacionRestController -  listarBienesFiscalizados");
		ResponseBean<List<ActividadesBean>> respuesta = new ResponseBean<List<ActividadesBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<ActividadesBean> lista = gestionProgramaOtrosService.listarBienFiscalizado(codTipoBien);
		if(!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ActividadesBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerExcel")
	public Response obtenerExcel() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ConsultaProgramacionRestController - obtenerExcel");
		return ResponseRestUtil.ok("prueba");
	}
}
