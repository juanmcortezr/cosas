package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.CompletarInformeService;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/completarinforme")
public class CompletarInformeRestController extends RestControllerBase {
    //CUS14
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@EJB
	private CompletarInformeService completarInformeService;
	@Context
    private HttpServletRequest servletRequest;
	//Pantalla1
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarProgramacion")
	public Response listarProgramacion(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - listarProgramacion");		
		ResponseBean<List<ProgramacionBean>> respuesta = new ResponseBean<List<ProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		try {
			List<ProgramacionBean> lista = completarInformeService.listarProgramacion(filtro);
			if (!MaestrosUtilidades.isEmpty(lista)) {
				respuesta = new ResponseBean<List<ProgramacionBean>>(lista);
				respuesta.setExito(true);
				respuesta.setMensaje("");
			}
		} catch (Exception e) {
			respuesta.setExito(false);
			respuesta.setMensaje(e.getMessage());
		}
		return ResponseRestUtil.ok(respuesta);
	}
	//Pantalla2
	//INPUT	
	//numProgramacion
	//codProgControl
	//OUPUT
	//numProgramacion
	//fecInicioAsignacion
	//desProgramador
	//desFuente
	//desOtraFuente
	//desAlcance
	//desProgramacion
	//perInicio
	//perFin
	//obsProgramacion
	//numInformeSeleccion

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerArchivo")
	public Response obtenerArchivo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - obtenerArchivo");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarUsuarioPrograma")
	public Response listarUsuarioPrograma(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - listarUsuarioPrograma");
		ResponseBean<List<UsuarioProgramacionBean>> respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<UsuarioProgramacionBean> lista = completarInformeService.listarUsuarioProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerRegistrarInforme")
	public Response obtenerRegistrarInforme() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - obtenerRegistrarInforme");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarInformeSeleccion")
	public Response guardarInformeSeleccion(InformeSeleccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - guardarInformeSeleccion");
		ResponseBean<InformeSeleccionBean> respuesta = new ResponseBean<InformeSeleccionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		AuditoriaBean auditoriaBean = this.obtenerUsuarioBean(servletRequest);
		filtro.setAuditoriaBean(auditoriaBean);
		InformeSeleccionBean bean = completarInformeService.guardarInformeSeleccion(filtro);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<InformeSeleccionBean>(bean);
		}	
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerAgregarDocumento")
	public Response obtenerAgregarDocumento() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - obtenerAgregarDocumento");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarDocumentoInforme")
	public Response guardarDocumentoInforme(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - guardarDocumentoInforme");
		ResponseBean<UsuarioProgramacion> respuesta = new ResponseBean<UsuarioProgramacion>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		AuditoriaBean auditoriaBean = this.obtenerUsuarioBean(servletRequest);
		filtro.setAuditoriaBean(auditoriaBean);
		UsuarioProgramacion bean = completarInformeService.guardarDocumentoInforme(filtro);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<UsuarioProgramacion>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarDocumentoAccion")
	public Response guardarDocumentoAccion(DocumentoAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - guardarDocumentoAccion");
		ResponseBean<DocumentoAccionBean> respuesta = new ResponseBean<DocumentoAccionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		AuditoriaBean auditoriaBean = this.obtenerUsuarioBean(servletRequest);
		filtro.setAuditoriaBean(auditoriaBean);
		DocumentoAccionBean bean = completarInformeService.guardarDocumentoAccion(filtro);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<DocumentoAccionBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarArchivo")
	public Response eliminarArchivo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - eliminarArchivo");
		return ResponseRestUtil.ok("prueba");
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDatosAccion/{numUsuarioProgram}")
	public Response obtenerDatosAccion(@PathParam("numUsuarioProgram") Long numUsuarioProgram) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - obtenerDatosAccion");		
		ResponseBean<UsuarioProgramacionBean> respuesta = new ResponseBean<UsuarioProgramacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		UsuarioProgramacionBean bean = completarInformeService.obtenerDatosAccion(numUsuarioProgram);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<UsuarioProgramacionBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarDocumentoAccion/{numUsuarioProgram}")
	public Response listarDocumentoAccion(@PathParam("numUsuarioProgram") Long numUsuarioProgram) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - obtenerDatosAccion");		
		ResponseBean<List<DocumentoAccionBean>> respuesta = new ResponseBean<List<DocumentoAccionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<DocumentoAccionBean> lista = completarInformeService.listarDocumentoAccion(numUsuarioProgram);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<DocumentoAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarDocumentoAccion/{numDocAccion}")
	public Response eliminarDocumentoAccion(@PathParam("numDocAccion") Long numDocAccion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeRestController - obtenerDatosAccion");		
		ResponseBean<DocumentoAccionBean> respuesta = new ResponseBean<DocumentoAccionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		DocumentoAccionBean bean = completarInformeService.eliminarDocumentoAccion(numDocAccion);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<DocumentoAccionBean>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}
}
