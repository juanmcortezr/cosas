package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienFiscalizadoSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CalificacionUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.EstablecimientoUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.GestionSolicitudService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/gestionsolicitud")
public class GestionSolicitudRestController extends RestControllerBase {
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@EJB
    private GestionSolicitudService gestionSolicitudService;

	@Context
	private HttpServletRequest request;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarSolicitudProgramacion")
	public Response listarSolicitudProgramacion(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - listarSolicitudProgramacion");
		ResponseBean<List<SolicitudProgramacionBean>> respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<SolicitudProgramacionBean> lista = gestionSolicitudService.listarSolicitudProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDatosSolicitud/{numSolicProg}")
	public Response obtenerDatosSolicitud(@PathParam("numSolicProg") Long numSolicProg) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - obtenerDatosSolicitud");
		ResponseBean<SolicitudProgramacionBean> respuesta = new ResponseBean<SolicitudProgramacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		SolicitudProgramacionBean objeto = gestionSolicitudService.obtenerDatosSolicitud(numSolicProg);
		if (!MaestrosUtilidades.isEmpty(objeto)) {
			respuesta = new ResponseBean<SolicitudProgramacionBean>(objeto);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarSolicitud")
	public Response guardarSolicitud(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - guardarSolicitud");
		ResponseBean<SolicitudProgramacionBean> respuesta = new ResponseBean<SolicitudProgramacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		SolicitudProgramacionBean objeto = gestionSolicitudService.guardarSolicitud(filtro);
		if (!MaestrosUtilidades.isEmpty(objeto)) {
			respuesta = new ResponseBean<SolicitudProgramacionBean>(objeto);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDetalleSolicitud/{numSolicProg}")
	public Response obtenerDetalleSolicitud(@PathParam("numSolicProg") Long numSolicProg) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - obtenerDetalleSolicitud");
		ResponseBean<List<UsuarioSolicitudBean>> respuesta = new ResponseBean<List<UsuarioSolicitudBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<UsuarioSolicitudBean> lista = gestionSolicitudService.obtenerDetalleSolicitud(numSolicProg);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<UsuarioSolicitudBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/enviarDetalleSolicitudProgram")
	public Response enviarDetalleSolicitudProgram(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - enviarDetalleSolicitudProgram");
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionSolicitudService.enviarDetalleSolicitudProgram(filtro));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/obtenerDatosUsuario")
	public Response obtenerDatosUsuario(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - obtenerDatosUsuario");
		ResponseBean<UsuarioSolicitudBean> respuesta = new ResponseBean<UsuarioSolicitudBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		UsuarioSolicitudBean objeto = gestionSolicitudService.obtenerDatosUsuario(filtro);
		if (!MaestrosUtilidades.isEmpty(objeto)) {
			respuesta = new ResponseBean<UsuarioSolicitudBean>(objeto);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/obtenerDatosEstablecimientoUsuario")
	public Response obtenerDatosEstablecimientoUsuario(EstablecimientoUsuarioBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - obtenerDatosEstablecimientoUsuario");
		ResponseBean<EstablecimientoUsuarioBean> respuesta = new ResponseBean<EstablecimientoUsuarioBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		EstablecimientoUsuarioBean objeto = gestionSolicitudService.obtenerDatosEstablecimientoUsuario(filtro);
		if (!MaestrosUtilidades.isEmpty(objeto)) {
			respuesta = new ResponseBean<EstablecimientoUsuarioBean>(objeto);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenervigenciaUsuario/{tipoDoc}/{numeroDoc}")
	public Response obtenervigenciaUsuario(@PathParam("tipoDoc")String tipoDoc, @PathParam("numeroDoc")String numeroDoc) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - obtenervigenciaUsuario");
		return ResponseRestUtil.ok(gestionSolicitudService.vigenciaUsuarioSolicitud(tipoDoc, numeroDoc));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarUsuario")
	public Response guardarUsuario(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - guardarUsuario");
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionSolicitudService.guardarUsuario(filtro));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/guardarEstablecimiento")
	public Response guardarEstablecimiento(UsuarioSolicitudBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - guardarEstablecimiento");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		ResponseBean<UsuarioSolicitudBean> respuesta = new ResponseBean<UsuarioSolicitudBean>(true, gestionSolicitudService.guardarEstablecimiento(formulario));
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarSolicitudProgramacion/{numSolicProg}")
	public Response eliminarSolicitudProgramacion(@PathParam("numSolicProg") Long numSolicProg) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - eliminarSolicitudProgramacion");
		UsuarioSolicitudBean formulario = new UsuarioSolicitudBean();
		formulario.setNumSolicitud(numSolicProg);
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		ResponseBean<String> response = new ResponseBean<String>();
		response.setExito(false);
		response.setMensaje("");
		if(gestionSolicitudService.eliminarSolicitudProgramacion(formulario)) {
			response.setExito(true);
		}
		return ResponseRestUtil.ok(response);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/eliminarUsuario")
	public Response eliminarUsuario(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - eliminarUsuario");
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		ResponseBean<String> response = new ResponseBean<String>();
		response.setExito(false);
		response.setMensaje("");
		if(gestionSolicitudService.eliminarUsuario(filtro)) {
			response.setExito(true);
		}
		return ResponseRestUtil.ok(response);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/eliminarEstablecimientoUsuario")
	public Response eliminarEstablecimientoUsuario(EstablecimientoUsuarioBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - eliminarEstablecimientoUsuario");
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		ResponseBean<String> response = new ResponseBean<String>();
		response.setExito(false);
		response.setMensaje("");
		if(gestionSolicitudService.eliminarEstablecimientoUsuario(filtro)) {
			response.setExito(true);
		}
		return ResponseRestUtil.ok(response);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDatosCalificacionUsuario/{numUsuSoli}")
	public Response obtenerDatosCalificacionUsuario(@PathParam("numUsuSoli") Long numUsuSoli) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - obtenerPaginaCalificacionPreliminar");
		ResponseBean<CalificacionUsuarioBean> respuesta = new ResponseBean<CalificacionUsuarioBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		CalificacionUsuarioBean datos = gestionSolicitudService.obtenerDatosCaliPre(numUsuSoli);
		if (!MaestrosUtilidades.isEmpty(datos)) {
			respuesta = new ResponseBean<CalificacionUsuarioBean>(true, datos);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarCalificacionPreliminar")
	public Response guardarCalificacionPreliminar(CalificacionUsuarioBean calificacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - guardarCalificacionPreliminar");
		calificacion.setAuditoriaBean(this.obtenerUsuarioBean(request));
		calificacion = gestionSolicitudService.guardarCalificacionPreliminar(calificacion);
		return ResponseRestUtil.ok(new ResponseBean<>(true, calificacion));
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarSolicitudSupervisorSolicitante")
	public Response listarSolicitudSupervisorSolicitante(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - listarSolicitudSupervisorSolicitante");
		ResponseBean<List<SolicitudProgramacionBean>> respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<SolicitudProgramacionBean> lista = gestionSolicitudService.listarSolicitudSupervisorSolicitante(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarBienesFiscalizados/{codTipoBien}")
	public Response listarBienesFiscalizados(@PathParam("codTipoBien") String codTipoBien) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - listarBienesFiscalizados");
		ResponseBean<List<BienFiscalizadoSolicitudBean>> respuesta = new ResponseBean<List<BienFiscalizadoSolicitudBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<BienFiscalizadoSolicitudBean> lista = gestionSolicitudService.listarBienesFiscalizados(codTipoBien);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<BienFiscalizadoSolicitudBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarEstablecimientosUsuario")
	public Response listarEstablecimientosUsuario(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudRestController - listarEstablecimientosUsuario");
		ResponseBean<List<EstablecimientoUsuarioBean>> respuesta = new ResponseBean<List<EstablecimientoUsuarioBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<EstablecimientoUsuarioBean> lista = gestionSolicitudService.listarEstablecimientosUsuario(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<EstablecimientoUsuarioBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
}
