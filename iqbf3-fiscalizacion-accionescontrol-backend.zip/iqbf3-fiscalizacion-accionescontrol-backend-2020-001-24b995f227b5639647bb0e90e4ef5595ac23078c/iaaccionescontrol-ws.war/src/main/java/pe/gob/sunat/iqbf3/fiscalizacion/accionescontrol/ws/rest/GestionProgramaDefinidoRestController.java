package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.GestionProgramaDefinidoService;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/gestionprogramadefinido")
public class GestionProgramaDefinidoRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@EJB
	private GestionProgramaDefinidoService gestionProgramaDefinidoService;

	@Context
	private HttpServletRequest request;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerProgramaControl/{codProgramaControl}")
	public Response obtenerProgramaControl(@PathParam("codProgramaControl") String codProgramaControl){
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosRestController - obtenerPrograma");
		ResponseBean<ProgramaControlBean> respuesta = new ResponseBean<ProgramaControlBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		logger.debug(String.format("codProgramaControl => %s", codProgramaControl));
		ProgramaControlBean programa = gestionProgramaDefinidoService.obtenerProgramaControl(codProgramaControl);
		if (!MaestrosUtilidades.isEmpty(programa)) {
			respuesta = new ResponseBean<ProgramaControlBean>(programa);
		}
		return ResponseRestUtil.ok(respuesta);
	}


	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerRegistrarPrograma")
	public Response obtenerRegistrarPrograma() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - obtenerRegistrarPrograma");
		return ResponseRestUtil.ok("prueba");
	}


	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarProgramaDefinido")
	public Response listarProgramaDefinido(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - listarProgramaDefinido");
		ResponseBean<List<ProgramacionBean>> respuesta = new ResponseBean<List<ProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		logger.debug(String.format("filtro.getNumInforme() => %s", filtro.getNumProgramacion()));
	    List<ProgramacionBean> lista = gestionProgramaDefinidoService.listarProgramaDefinido(filtro);
			
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<ProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDatoscancelar")
	public Response obtenerDatoscancelar() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - obtenerDatoscancelar");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDatosActualizar/{numProgramacion}")
	public Response obtenerDatosActualizar(@PathParam("numProgramacion") Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - obtenerDatosActualizar");
		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<ProgramacionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ProgramacionBean bean = gestionProgramaDefinidoService.obtenerDatosProgramacionDefinido(numProgramacion);
		if (!MaestrosUtilidades.isEmpty(bean)) {
			respuesta = new ResponseBean<>(bean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarPrograma")
	public Response guardarPrograma(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - guardarPrograma");
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaDefinidoService.guardarProgramacionDefinido(formulario));
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarUsuarios")
	public Response listarUsuarios() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - listarUsuarios");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarProgramaActualizado")
	public Response guardarProgramaActualizado(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - guardarProgramaActualizado");
		
		formulario.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaDefinidoService.actualizarProgramacionDefinido(formulario));
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/enviarPrograma")
	public Response enviarPrograma(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - enviarPrograma");
		
		filtro.setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaDefinidoService.enviarPrograma(filtro));

	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/eliminarArchivo")
	public Response eliminarArchivo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - eliminarArchivo");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerArchivo")
	public Response obtenerArchivo() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - obtenerArchivo");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/guardarCancelarPrograma")
	public Response guardarCancelarPrograma() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - guardarCancelarPrograma");
		return ResponseRestUtil.ok("prueba");
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerAccionusuario")
	public Response obtenerAccionusuario() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - obtenerAccionusuario");
		return ResponseRestUtil.ok("prueba");
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarUsuariosDefinidos")
	public Response listarUsuariosDefinidos(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - listarProgramaDefinido");
		ResponseBean<List<UsuarioProgramacionBean>> respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		logger.debug(String.format("filtro.getNumProgramacion() => %s", filtro.getNumProgramacion()));
	    List<UsuarioProgramacionBean> lista = gestionProgramaDefinidoService.listarUsuariosDefinidos(filtro);
			
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta.setExito(true);
			respuesta = new ResponseBean<List<UsuarioProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarMotivoActualizar")
	public Response listarMotivoActualizar() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - listaMotivo");
		ResponseBean<List<DataCatalogoBean>> respuesta = new ResponseBean<List<DataCatalogoBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
	    List<DataCatalogoBean> lista = gestionProgramaDefinidoService.listarMotivoActualizar();
			
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta.setExito(true);
			respuesta = new ResponseBean<List<DataCatalogoBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/actualizarUsuario")
	public Response actualizarUsuario(List<UsuarioProgramacionBean> filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoRestController - actualizarUsuario");
		
		filtro.get(0).setAuditoriaBean(this.obtenerUsuarioBean(request));
		return ResponseRestUtil.ok(gestionProgramaDefinidoService.actualizarUsuario(filtro));
	}
}
