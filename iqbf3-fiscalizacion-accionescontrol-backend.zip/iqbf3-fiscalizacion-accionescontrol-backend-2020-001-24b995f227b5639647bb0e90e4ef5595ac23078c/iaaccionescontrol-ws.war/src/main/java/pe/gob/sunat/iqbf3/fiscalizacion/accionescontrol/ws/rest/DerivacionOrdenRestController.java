package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.DerivacionOrdenService;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/derivacionorden")
public class DerivacionOrdenRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@EJB
	private DerivacionOrdenService derivacionOrdenService;
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/listarProgramacion")
	public Response listarProgramacion(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio DerivacionOrdenRestController - listarPrograma");
		ResponseBean<List<ProgramacionBean>> respuesta = new ResponseBean<List<ProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		try {
			List<ProgramacionBean> lista = derivacionOrdenService.listarProgramacion(filtro);
			if (!MaestrosUtilidades.isEmpty(lista)) {
				respuesta = new ResponseBean<List<ProgramacionBean>>(lista);
				respuesta.setExito(true);
				respuesta.setMensaje("");
			}
		} catch (Exception e) {
			respuesta.setExito(false);
			respuesta.setMensaje(e.getMessage());
		}
		return ResponseRestUtil.ok(respuesta);
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerDerivarOrden/{numProgramacion}")
	public Response obtenerDerivarOrden(@PathParam("numProgramacion") Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio DerivacionOrdenRestController - obtenerDerivarOrden");
		ResponseBean<List<OrdenAccionBean>> respuesta = new ResponseBean<List<OrdenAccionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<OrdenAccionBean> lista = derivacionOrdenService.obtenerDatosOrden(numProgramacion);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<OrdenAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerArchivo/{numArchivo}")
	public Response obtenerArchivo(@PathParam("numArchivo") String numArchivo) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio DerivacionOrdenRestController - obtenerArchivo");
		ResponseBean<ArchivoBean> respuesta = new ResponseBean<ArchivoBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		ArchivoBean archivoBeanBean = derivacionOrdenService.obtenerArchivo(Long.valueOf(numArchivo));
		if (!MaestrosUtilidades.isEmpty(archivoBeanBean)) {
			respuesta = new ResponseBean<ArchivoBean>(archivoBeanBean);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/listarOrdenPrograma")
	public Response listarOrdenPrograma(OrdenAccionBean programacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio DerivacionOrdenRestController - listarOrdenPrograma");
		ResponseBean<List<OrdenAccionBean>> respuesta = new ResponseBean<List<OrdenAccionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		List<OrdenAccionBean> lista = derivacionOrdenService.listarOrden(programacion);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<OrdenAccionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/derivarOrdenes")
	public Response derivarOrdenes(OrdenAccionBean ordenBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio DerivacionOrdenRestController - derivarOrdenes");
		
		ResponseBean<OrdenAccionBean> respuesta = new ResponseBean<OrdenAccionBean>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);	
		try {
			OrdenAccionBean ordenAccionBean = derivacionOrdenService.derivarOrdenes(ordenBean);
			if (!MaestrosUtilidades.isEmpty(ordenAccionBean)) {
				respuesta = new ResponseBean<OrdenAccionBean>(ordenAccionBean);
				respuesta.setExito(true);
				respuesta.setMensaje("");
			}
		} catch (Exception e) {
			respuesta.setExito(false);
			respuesta.setMensaje(e.getMessage());
		}
		
		return ResponseRestUtil.ok(respuesta);
	}
}
