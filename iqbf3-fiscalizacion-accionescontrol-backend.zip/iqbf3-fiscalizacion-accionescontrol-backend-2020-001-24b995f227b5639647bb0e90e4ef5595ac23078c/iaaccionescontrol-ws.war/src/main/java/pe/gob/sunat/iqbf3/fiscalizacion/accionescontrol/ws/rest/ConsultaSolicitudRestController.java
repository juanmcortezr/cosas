package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.ws.rest;

import java.util.List;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service.ConsultaSolicitudService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseRestUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.RestControllerBase;

@Path("/consultasolicitud")
public class ConsultaSolicitudRestController extends RestControllerBase {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@EJB
	private ConsultaSolicitudService ConsultaSolicitudService;
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/consultaSolicitudProgramacion")
	public Response listarConsultaSolicitudProgramacion(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ConsultaSolicitudRestController - listarConsultaSolicitudProgramacion");
		ResponseBean<List<SolicitudProgramacionBean>> respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		logger.debug(String.format("filtro.getNumSolicitudUnion() => %s", filtro.getNumSolicitudUnion()));
		
		List<SolicitudProgramacionBean> lista = ConsultaSolicitudService.listarConsultaSolicitudProgramacion(filtro);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			respuesta = new ResponseBean<List<SolicitudProgramacionBean>>(lista);
		}
		return ResponseRestUtil.ok(respuesta);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/obtenerExcel")
	public Response obtenerExcel() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ConsultaProgramacionRestController - obtenerExcel");
		return ResponseRestUtil.ok("prueba");
	}
	
}
