package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "T10399BLOQDJRO")
public class BloqueoDjro extends Auditoria {

	 @Column(name = "COD_TIP_DOC")
	 private String codTipoDocumento;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_BLOQ_DJRO")
	 private Date fecBloqDjro;
	
	 @Column(name = "IND_EST_BLOQDJRO")
	 private String indEstadoBloqueDjro;
	
	 @Id
	 @Column(name = "NUM_BLOQ_DJRO")
	 private Long numBloqueoDjro;
	
	 @Column(name = "NUM_DOC_IDENT")
	 private String numDocumentoIdentif;
	
	 @Column(name = "NUM_ORDEN")
	 private Integer numOrden;
	
	 @Column(name = "PER_FIN")
	 private String perFin;
	
	 @Column(name = "PER_INICIO")
	 private String perInicio;

	public String getCodTipoDocumento() {
		return codTipoDocumento;
	}

	public void setCodTipoDocumento(String codTipoDocumento) {
		this.codTipoDocumento = codTipoDocumento;
	}

	public Date getFecBloqDjro() {
		return fecBloqDjro;
	}

	public void setFecBloqDjro(Date fecBloqDjro) {
		this.fecBloqDjro = fecBloqDjro;
	}

	public String getIndEstadoBloqueDjro() {
		return indEstadoBloqueDjro;
	}

	public void setIndEstadoBloqueDjro(String indEstadoBloqueDjro) {
		this.indEstadoBloqueDjro = indEstadoBloqueDjro;
	}

	public Long getNumBloqueoDjro() {
		return numBloqueoDjro;
	}

	public void setNumBloqueoDjro(Long numBloqueoDjro) {
		this.numBloqueoDjro = numBloqueoDjro;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public Integer getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Integer numOrden) {
		this.numOrden = numOrden;
	}

	public String getPerFin() {
		return perFin;
	}

	public void setPerFin(String perFin) {
		this.perFin = perFin;
	}

	public String getPerInicio() {
		return perInicio;
	}

	public void setPerInicio(String perInicio) {
		this.perInicio = perInicio;
	}

	
}
