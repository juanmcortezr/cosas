package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Transient;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class UsuarioProgramacionBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private int cantidadDiasAtencion;
	private String codDependencia;
	private String codEstadoRegistro;//codEstadoActual
	private String codEstadoUsuario;
	private String codMotivaDepuracion;//codMotDepuracion
	private String codNivelRiesgo;
	private String codTipoAccion;
	private String codTipoAccionSugerida;
	private String codTipoDocumentoIdentif;
	private String codTipoIntervencion;
	private String codTipoIntervencionSugerida;
	private String codUbigeoDomicilioFiscal;
	private String desSusMotivo;
	private String desDependencia;
	private String desEstadoRegistro;//desEstadoActual
	private String desEstadoUsuario;
	private String desMotDepuracion;//desMotivoDepuracion
	private String desNivelRiesgo;
	private String desTipoAccion;
	private String desTipoAccionSugerida;
	private String desTipoDocumentoIdent;
	private String desTipoIntervencion;
	private String desTipoIntervencionSugerida;
	private String desUbigeoDomicilioFiscal;
	private String fecFinVigencia;
	private String fecInicioCaso;
	private String fecProcesamiento;
	private String horIniCaso;
	private String indNeutralizacion;
	private String desIndNeutralizacion;
	private String nomApellidoUsuario;
	private String numDocumentoIdentif;//opv
	private String numPeridoomisomax;
	private String numPeridoomisomin;
	private Long numProgramacion;
	private Long numUsuarioPrograma;
	private int numVersionRegistro;

	private String alcanceProg;
	private String indDel;
	private String indEst;
	private String numInformeSelecci;
	private String codPers;
	private String codProgctrl;
	private String desProgctrl;
	private String codAuditor;
	private String nomAuditor;
	private String nomRazonSocial;
	
	private String codSubEstadoProgram;
	private String fecModif;
	private String dirIpusumodif;
	private String codUsuModif;
	
	private String nombreRazonSocial;
	private String codEstadoPrograma;
	private String desEstadoOrden;
	private String numProgCorrel;

	private List<UsuarioProgramacionBean> usuariosBean;
	//opv
	private List<ProgramacionBean> programacionBean;//opv
	private ArchivoBean archivoVinculado;//opv
	private String tipoDocumentoVinculado;//opv 
	private String numeroDocumentoVinculado;//opv
	private String numDocumentoAccion   ;//opv   
	//opv
	
	private AuditoriaBean auditoriaBean;
	private String numOrden;
	private boolean seleccionado;
	private String otrasAcciones;
	private String desAlcance;
	private String desTipoDocumentoVinculado;
	private String nroInformeUnion;
	private String numOrdenUnion;
	private Integer cantTiposAccion;
	
	public Integer getCantTiposAccion() {
		return cantTiposAccion;
	}

	public void setCantTiposAccion(Integer cantTiposAccion) {
		this.cantTiposAccion = cantTiposAccion;
	}

	public String getNumOrdenUnion() {
		return numOrdenUnion;
	}

	public void setNumOrdenUnion(String numOrdenUnion) {
		this.numOrdenUnion = numOrdenUnion;
	}

	public String getNroInformeUnion() {
		return nroInformeUnion;
	}

	public void setNroInformeUnion(String nroInformeUnion) {
		this.nroInformeUnion = nroInformeUnion;
	}

	public String getDesTipoDocumentoVinculado() {
		return desTipoDocumentoVinculado;
	}

	public void setDesTipoDocumentoVinculado(String desTipoDocumentoVinculado) {
		this.desTipoDocumentoVinculado = desTipoDocumentoVinculado;
	}

	public String getDesAlcance() {
		return desAlcance;
	}

	public void setDesAlcance(String desAlcance) {
		this.desAlcance = desAlcance;
	}

	public String getNumProgCorrel() {
		return numProgCorrel;
	}

	public void setNumProgCorrel(String numProgCorrel) {
		this.numProgCorrel = numProgCorrel;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}


	public String getCodEstadoPrograma() {
		return codEstadoPrograma;
	}


	public void setCodEstadoPrograma(String codEstadoPrograma) {
		this.codEstadoPrograma = codEstadoPrograma;
	}


	public String getNomRazonSocial() {
		return nomRazonSocial;
	}


	public void setNomRazonSocial(String nomRazonSocial) {
		this.nomRazonSocial = nomRazonSocial;
	}


	public String getCodAuditor() {
		return codAuditor;
	}


	public void setCodAuditor(String codAuditor) {
		this.codAuditor = codAuditor;
	}


	public String getNomAuditor() {
		return nomAuditor;
	}


	public void setNomAuditor(String nomAuditor) {
		this.nomAuditor = nomAuditor;
	}


	public String getDesProgctrl() {
		return desProgctrl;
	}


	public void setDesProgctrl(String desProgctrl) {
		this.desProgctrl = desProgctrl;
	}


	public String getCodProgctrl() {
		return codProgctrl;
	}


	public void setCodProgctrl(String codProgctrl) {
		this.codProgctrl = codProgctrl;
	}


	public String getCodPers() {
		return codPers;
	}


	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}


	public String getNumInformeSelecci() {
		return numInformeSelecci;
	}


	public void setNumInformeSelecci(String numInformeSelecci) {
		this.numInformeSelecci = numInformeSelecci;
	}


	public String getAlcanceProg() {
		return alcanceProg;
	}


	public void setAlcanceProg(String alcanceProg) {
		this.alcanceProg = alcanceProg;
	}
	

	public String getNombreRazonSocial() {
		return nombreRazonSocial;
	}


	public void setNombreRazonSocial(String nombreRazonSocial) {
		this.nombreRazonSocial = nombreRazonSocial;
	}


	public String getCodUsuModif() {
		return codUsuModif;
	}


	public void setCodUsuModif(String codUsuModif) {
		this.codUsuModif = codUsuModif;
	}


	public String getFecModif() {
		return fecModif;
	}


	public void setFecModif(String fecModif) {
		this.fecModif = fecModif;
	}


	public String getDirIpusumodif() {
		return dirIpusumodif;
	}


	public void setDirIpusumodif(String dirIpusumodif) {
		this.dirIpusumodif = dirIpusumodif;
	}


	public String getCodSubEstadoProgram() {
		return codSubEstadoProgram;
	}


	public void setCodSubEstadoProgram(String codSubEstadoProgram) {
		this.codSubEstadoProgram = codSubEstadoProgram;
	}


	public String getIndDel() {
		return indDel;
	}


	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}


	public String getIndEst() {
		return indEst;
	}


	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}


	public UsuarioProgramacionBean() {
		super();
	}
	
	
    //CUS14
	public UsuarioProgramacionBean(String desNivelRiesgo, String codTipoAccion, String codTipoIntervencion,
			String desTipoDocumentoIdent, String desUbigeoDomicilioFiscal, String numDocumentoIdentif, String alcanceProg,
			String numInformeSelecci, String codPers, String codProgctrl, String desProgctrl, String nomAuditor,
			String codAuditor, String nomRazonSocial) {
		super();
		this.desNivelRiesgo = desNivelRiesgo;
		this.codTipoAccion = codTipoAccion;
		this.codTipoIntervencion = codTipoIntervencion;
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
		this.desUbigeoDomicilioFiscal = desUbigeoDomicilioFiscal;
		this.numDocumentoIdentif = numDocumentoIdentif;
		this.alcanceProg = alcanceProg;
		this.numInformeSelecci = numInformeSelecci;
		this.codPers = codPers;
		this.codProgctrl = codProgctrl;
		this.desProgctrl = desProgctrl;
		this.nomAuditor = nomAuditor;
		this.codAuditor = codAuditor;
		this.nomRazonSocial = nomRazonSocial;
	}



	public UsuarioProgramacionBean(int cantidadDiasAtencion, String codDependencia, String codEstadoRegistro,
			String codEstadoUsuario, String codMotivaDepuracion, String codNivelRiesgo, String codTipoAccion,
			String codTipoAccionSugerida, String codTipoDocumentoIdentif, String codTipoIntervencion,
			String codTipoIntervencionSugerida, String codUbigeoDomicilioFiscal, String desSusMotivo,
			String desDependencia, String desEstadoRegistro, String desEstadoUsuario, String desMotDepuracion,
			String desNivelRiesgo, String desTipoAccion, String desTipoAccionSugerida, String desTipoDocumentoIdent,
			String desTipoIntervencion, String desTipoIntervencionSugerida, String desUbigeoDomicilioFiscal,
			String fecFinVigencia, String fecInicioCaso, String fecProcesamiento, String horIniCaso,
			String indNeutralizacion, String nomApellidoUsuario, String numDocumentoIdentif, String numPeridoomisomax,
			String numPeridoomisomin, Long numProgramacion, Long numUsuarioPrograma, int numVersionRegistro) {
		super();
		this.cantidadDiasAtencion = cantidadDiasAtencion;
		this.codDependencia = codDependencia;
		this.codEstadoRegistro = codEstadoRegistro;
		this.codEstadoUsuario = codEstadoUsuario;
		this.codMotivaDepuracion = codMotivaDepuracion;
		this.codNivelRiesgo = codNivelRiesgo;
		this.codTipoAccion = codTipoAccion;
		this.codTipoAccionSugerida = codTipoAccionSugerida;
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
		this.codTipoIntervencion = codTipoIntervencion;
		this.codTipoIntervencionSugerida = codTipoIntervencionSugerida;
		this.codUbigeoDomicilioFiscal = codUbigeoDomicilioFiscal;
		this.desSusMotivo = desSusMotivo;
		this.desDependencia = desDependencia;
		this.desEstadoRegistro = desEstadoRegistro;
		this.desEstadoUsuario = desEstadoUsuario;
		this.desMotDepuracion = desMotDepuracion;
		this.desNivelRiesgo = desNivelRiesgo;
		this.desTipoAccion = desTipoAccion;
		this.desTipoAccionSugerida = desTipoAccionSugerida;
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
		this.desTipoIntervencion = desTipoIntervencion;
		this.desTipoIntervencionSugerida = desTipoIntervencionSugerida;
		this.desUbigeoDomicilioFiscal = desUbigeoDomicilioFiscal;
		this.fecFinVigencia = fecFinVigencia;
		this.fecInicioCaso = fecInicioCaso;
		this.fecProcesamiento = fecProcesamiento;
		this.horIniCaso = horIniCaso;
		this.indNeutralizacion = indNeutralizacion;
		this.nomApellidoUsuario = nomApellidoUsuario;
		this.numDocumentoIdentif = numDocumentoIdentif;
		this.numPeridoomisomax = numPeridoomisomax;
		this.numPeridoomisomin = numPeridoomisomin;
		this.numProgramacion = numProgramacion;
		this.numUsuarioPrograma = numUsuarioPrograma;
		this.numVersionRegistro = numVersionRegistro;
	}

	public int getCantidadDiasAtencion() {
		return cantidadDiasAtencion;
	}

	public void setCantidadDiasAtencion(int cantidadDiasAtencion) {
		this.cantidadDiasAtencion = cantidadDiasAtencion;
	}

	public String getCodDependencia() {
		return codDependencia;
	}

	public void setCodDependencia(String codDependencia) {
		this.codDependencia = codDependencia;
	}

	public String getCodEstadoRegistro() {
		return codEstadoRegistro;
	}

	public void setCodEstadoRegistro(String codEstadoRegistro) {
		this.codEstadoRegistro = codEstadoRegistro;
	}

	public String getCodEstadoUsuario() {
		return codEstadoUsuario;
	}

	public void setCodEstadoUsuario(String codEstadoUsuario) {
		this.codEstadoUsuario = codEstadoUsuario;
	}

	public String getCodMotivaDepuracion() {
		return codMotivaDepuracion;
	}

	public void setCodMotivaDepuracion(String codMotivaDepuracion) {
		this.codMotivaDepuracion = codMotivaDepuracion;
	}

	public String getCodNivelRiesgo() {
		return codNivelRiesgo;
	}

	public void setCodNivelRiesgo(String codNivelRiesgo) {
		this.codNivelRiesgo = codNivelRiesgo;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getCodTipoAccionSugerida() {
		return codTipoAccionSugerida;
	}

	public void setCodTipoAccionSugerida(String codTipoAccionSugerida) {
		this.codTipoAccionSugerida = codTipoAccionSugerida;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getCodTipoIntervencion() {
		return codTipoIntervencion;
	}

	public void setCodTipoIntervencion(String codTipoIntervencion) {
		this.codTipoIntervencion = codTipoIntervencion;
	}

	public String getCodTipoIntervencionSugerida() {
		return codTipoIntervencionSugerida;
	}

	public void setCodTipoIntervencionSugerida(String codTipoIntervencionSugerida) {
		this.codTipoIntervencionSugerida = codTipoIntervencionSugerida;
	}

	public String getCodUbigeoDomicilioFiscal() {
		return codUbigeoDomicilioFiscal;
	}

	public void setCodUbigeoDomicilioFiscal(String codUbigeoDomicilioFiscal) {
		this.codUbigeoDomicilioFiscal = codUbigeoDomicilioFiscal;
	}

	public String getDesSusMotivo() {
		return desSusMotivo;
	}

	public void setDesSusMotivo(String desSusMotivo) {
		this.desSusMotivo = desSusMotivo;
	}

	public String getDesDependencia() {
		return desDependencia;
	}

	public void setDesDependencia(String desDependencia) {
		this.desDependencia = desDependencia;
	}

	public String getDesEstadoRegistro() {
		return desEstadoRegistro;
	}

	public void setDesEstadoRegistro(String desEstadoRegistro) {
		this.desEstadoRegistro = desEstadoRegistro;
	}

	public String getDesEstadoUsuario() {
		return desEstadoUsuario;
	}

	public void setDesEstadoUsuario(String desEstadoUsuario) {
		this.desEstadoUsuario = desEstadoUsuario;
	}

	public String getDesMotDepuracion() {
		return desMotDepuracion;
	}

	public void setDesMotDepuracion(String desMotDepuracion) {
		this.desMotDepuracion = desMotDepuracion;
	}

	public String getDesNivelRiesgo() {
		return desNivelRiesgo;
	}

	public void setDesNivelRiesgo(String desNivelRiesgo) {
		this.desNivelRiesgo = desNivelRiesgo;
	}

	public String getDesTipoAccion() {
		return desTipoAccion;
	}

	public void setDesTipoAccion(String desTipoAccion) {
		this.desTipoAccion = desTipoAccion;
	}

	public String getDesTipoAccionSugerida() {
		return desTipoAccionSugerida;
	}

	public void setDesTipoAccionSugerida(String desTipoAccionSugerida) {
		this.desTipoAccionSugerida = desTipoAccionSugerida;
	}

	public String getDesTipoDocumentoIdent() {
		return desTipoDocumentoIdent;
	}

	public void setDesTipoDocumentoIdent(String desTipoDocumentoIdent) {
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
	}

	public String getDesTipoIntervencion() {
		return desTipoIntervencion;
	}

	public void setDesTipoIntervencion(String desTipoIntervencion) {
		this.desTipoIntervencion = desTipoIntervencion;
	}

	public String getDesTipoIntervencionSugerida() {
		return desTipoIntervencionSugerida;
	}

	public void setDesTipoIntervencionSugerida(String desTipoIntervencionSugerida) {
		this.desTipoIntervencionSugerida = desTipoIntervencionSugerida;
	}

	public String getDesUbigeoDomicilioFiscal() {
		return desUbigeoDomicilioFiscal;
	}

	public void setDesUbigeoDomicilioFiscal(String desUbigeoDomicilioFiscal) {
		this.desUbigeoDomicilioFiscal = desUbigeoDomicilioFiscal;
	}

	public String getFecFinVigencia() {
		return fecFinVigencia;
	}

	public void setFecFinVigencia(String fecFinVigencia) {
		this.fecFinVigencia = fecFinVigencia;
	}

	public String getFecInicioCaso() {
		return fecInicioCaso;
	}

	public void setFecInicioCaso(String fecInicioCaso) {
		this.fecInicioCaso = fecInicioCaso;
	}

	public String getFecProcesamiento() {
		return fecProcesamiento;
	}

	public void setFecProcesamiento(String fecProcesamiento) {
		this.fecProcesamiento = fecProcesamiento;
	}

	public String getHorIniCaso() {
		return horIniCaso;
	}

	public void setHorIniCaso(String horIniCaso) {
		this.horIniCaso = horIniCaso;
	}

	public String getIndNeutralizacion() {
		return indNeutralizacion;		
	}

	public void setIndNeutralizacion(String indNeutralizacion) {
		this.indNeutralizacion = indNeutralizacion;
		this.setDesIndNeutralizacion((indNeutralizacion.equals("1")?"Si":"No"));
	}

	public String getNomApellidoUsuario() {
		return nomApellidoUsuario;
	}

	public void setNomApellidoUsuario(String nomApellidoUsuario) {
		this.nomApellidoUsuario = nomApellidoUsuario;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public String getNumPeridoomisomax() {
		return numPeridoomisomax;
	}

	public void setNumPeridoomisomax(String numPeridoomisomax) {
		this.numPeridoomisomax = numPeridoomisomax;
	}

	public String getNumPeridoomisomin() {
		return numPeridoomisomin;
	}

	public void setNumPeridoomisomin(String numPeridoomisomin) {
		this.numPeridoomisomin = numPeridoomisomin;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {

		this.numProgramacion = numProgramacion;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public int getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(int numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public String getDesEstadoOrden() {
		return desEstadoOrden;
	}

	public void setDesEstadoOrden(String desEstadoOrden) {
		this.desEstadoOrden = desEstadoOrden;
	}

	public List<UsuarioProgramacionBean> getUsuariosBean() {
		return usuariosBean;
	}

	public void setUsuariosBean(List<UsuarioProgramacionBean> usuariosBean) {
		this.usuariosBean = usuariosBean;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}


	public boolean isSeleccionado() {
		return seleccionado;
	}


	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public String getDesIndNeutralizacion() {
		return desIndNeutralizacion;
	}

	public void setDesIndNeutralizacion(String desIndNeutralizacion) {
		this.desIndNeutralizacion = desIndNeutralizacion;
	}


	public List<ProgramacionBean> getProgramacionBean() {
		return programacionBean;
	}


	public void setProgramacionBean(List<ProgramacionBean> programacionBean) {
		this.programacionBean = programacionBean;
	}


	public ArchivoBean getArchivoVinculado() {
		return archivoVinculado;
	}


	public void setArchivoVinculado(ArchivoBean archivoVinculado) {
		this.archivoVinculado = archivoVinculado;
	}


	public String getOtrasAcciones() {
		return otrasAcciones;
	}


	public void setOtrasAcciones(String otrasAcciones) {
		this.otrasAcciones = otrasAcciones;
	}


	public String getTipoDocumentoVinculado() {
		return tipoDocumentoVinculado;
	}


	public void setTipoDocumentoVinculado(String tipoDocumentoVinculado) {
		this.tipoDocumentoVinculado = tipoDocumentoVinculado;
	}


	public String getNumeroDocumentoVinculado() {
		return numeroDocumentoVinculado;
	}


	public void setNumeroDocumentoVinculado(String numeroDocumentoVinculado) {
		this.numeroDocumentoVinculado = numeroDocumentoVinculado;
	}


	public String getNumDocumentoAccion() {
		return numDocumentoAccion;
	}


	public void setNumDocumentoAccion(String numDocumentoAccion) {
		this.numDocumentoAccion = numDocumentoAccion;
	}
	
	
	
	
}
