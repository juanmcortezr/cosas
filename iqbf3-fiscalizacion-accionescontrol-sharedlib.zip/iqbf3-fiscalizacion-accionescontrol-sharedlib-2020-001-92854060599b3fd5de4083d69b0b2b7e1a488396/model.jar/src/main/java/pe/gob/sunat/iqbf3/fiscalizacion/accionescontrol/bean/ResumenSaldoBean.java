package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

public class ResumenSaldoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private double cantidadConsumida;
	private double cantidadDisponible;
	private int codTipobien;
	private String fecFinCalc;
	private String fecInicioCalculo;
	private String indInconsistencia;
	private int numConfirma;
	private int numExistencia;
	private int numInsumoCabecera;
	private String numPeriodo;
	private int numReposicion;
	private int numRuc;
	private int numVersionRegistro;

	private String indDel;
	private List<String> lstEstadoRegistros;
	private String indCondicion;
	private String codEstadoItem;
	
	
	public String getCodEstadoItem() {
		return codEstadoItem;
	}

	public void setCodEstadoItem(String codEstadoItem) {
		this.codEstadoItem = codEstadoItem;
	}

	public String getIndCondicion() {
		return indCondicion;
	}

	public void setIndCondicion(String indCondicion) {
		this.indCondicion = indCondicion;
	}

	public List<String> getLstEstadoRegistros() {
		return lstEstadoRegistros;
	}

	public void setLstEstadoRegistros(List<String> lstEstadoRegistros) {
		this.lstEstadoRegistros = lstEstadoRegistros;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public ResumenSaldoBean() {
		super();
	}

	public ResumenSaldoBean(double cantidadConsumida, double cantidadDisponible, int codTipobien, String fecFinCalc,
			String fecInicioCalculo, String indInconsistencia, int numConfirma, int numExistencia,
			int numInsumoCabecera, String numPeriodo, int numReposicion, int numRuc, int numVersionRegistro) {
		super();
		this.cantidadConsumida = cantidadConsumida;
		this.cantidadDisponible = cantidadDisponible;
		this.codTipobien = codTipobien;
		this.fecFinCalc = fecFinCalc;
		this.fecInicioCalculo = fecInicioCalculo;
		this.indInconsistencia = indInconsistencia;
		this.numConfirma = numConfirma;
		this.numExistencia = numExistencia;
		this.numInsumoCabecera = numInsumoCabecera;
		this.numPeriodo = numPeriodo;
		this.numReposicion = numReposicion;
		this.numRuc = numRuc;
		this.numVersionRegistro = numVersionRegistro;
	}

	public double getCantidadConsumida() {
		return cantidadConsumida;
	}

	public void setCantidadConsumida(double cantidadConsumida) {
		this.cantidadConsumida = cantidadConsumida;
	}

	public double getCantidadDisponible() {
		return cantidadDisponible;
	}

	public void setCantidadDisponible(double cantidadDisponible) {
		this.cantidadDisponible = cantidadDisponible;
	}

	public int getCodTipobien() {
		return codTipobien;
	}

	public void setCodTipobien(int codTipobien) {
		this.codTipobien = codTipobien;
	}

	public String getFecFinCalc() {
		return fecFinCalc;
	}

	public void setFecFinCalc(String fecFinCalc) {
		this.fecFinCalc = fecFinCalc;
	}

	public String getFecInicioCalculo() {
		return fecInicioCalculo;
	}

	public void setFecInicioCalculo(String fecInicioCalculo) {
		this.fecInicioCalculo = fecInicioCalculo;
	}

	public String getIndInconsistencia() {
		return indInconsistencia;
	}

	public void setIndInconsistencia(String indInconsistencia) {
		this.indInconsistencia = indInconsistencia;
	}

	public int getNumConfirma() {
		return numConfirma;
	}

	public void setNumConfirma(int numConfirma) {
		this.numConfirma = numConfirma;
	}

	public int getNumExistencia() {
		return numExistencia;
	}

	public void setNumExistencia(int numExistencia) {
		this.numExistencia = numExistencia;
	}

	public int getNumInsumoCabecera() {
		return numInsumoCabecera;
	}

	public void setNumInsumoCabecera(int numInsumoCabecera) {
		this.numInsumoCabecera = numInsumoCabecera;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public int getNumReposicion() {
		return numReposicion;
	}

	public void setNumReposicion(int numReposicion) {
		this.numReposicion = numReposicion;
	}

	public int getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(int numRuc) {
		this.numRuc = numRuc;
	}

	public int getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(int numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

}
