package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class HistorialEstadosProgramaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codEstadoPrograma;
	private	String	desEstadoProgram;
	private	String	fecEstadoProgram;
	private	int	numHistoriaProgram;
	private	int	numProgramacion;
	
	public HistorialEstadosProgramaBean() {
		super();
	}

	public HistorialEstadosProgramaBean(String codEstadoPrograma, String desEstadoProgram, String fecEstadoProgram,
			int numHistoriaProgram, int numProgramacion) {
		super();
		this.codEstadoPrograma = codEstadoPrograma;
		this.desEstadoProgram = desEstadoProgram;
		this.fecEstadoProgram = fecEstadoProgram;
		this.numHistoriaProgram = numHistoriaProgram;
		this.numProgramacion = numProgramacion;
	}

	public String getCodEstadoPrograma() {
		return codEstadoPrograma;
	}

	public void setCodEstadoPrograma(String codEstadoPrograma) {
		this.codEstadoPrograma = codEstadoPrograma;
	}

	public String getDesEstadoProgram() {
		return desEstadoProgram;
	}

	public void setDesEstadoProgram(String desEstadoProgram) {
		this.desEstadoProgram = desEstadoProgram;
	}

	public String getFecEstadoProgram() {
		return fecEstadoProgram;
	}

	public void setFecEstadoProgram(String fecEstadoProgram) {
		this.fecEstadoProgram = fecEstadoProgram;
	}

	public int getNumHistoriaProgram() {
		return numHistoriaProgram;
	}

	public void setNumHistoriaProgram(int numHistoriaProgram) {
		this.numHistoriaProgram = numHistoriaProgram;
	}

	public int getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(int numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
