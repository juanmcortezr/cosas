package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienFiscalizadoSolicitudBean;
//import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CheckElementBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T9495DocDigit")
public class T9495DocDigit implements Entidad{

	@Id
	@Column(name = "cod_doc_digit")
	private Integer codDocDigit;

	@Column(name = "num_arc_digit")
	private Integer numArcDigit;

	@Column(name = "cod_reg_per")
	private String codRegPersona;

	@Column(name = "cod_tipo")
	private String codTipo;

	@Column(name = "cod_subtipo")
	private String codSubTipo;
	
	@Column(name = "ind_activo")
	private String indActivo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fec_regis")
	private Date fecRegis;
	
	@Column(name = "cod_usuregis")
	private String codUsuregis;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fec_modif")
	private Date fecModif;
	
	@Column(name = "cod_usumodif")
	private String codUsumodif;

	public Integer getCodDocDigit() {
		return codDocDigit;
	}

	public void setCodDocDigit(Integer codDocDigit) {
		this.codDocDigit = codDocDigit;
	}

	public Integer getNumArcDigit() {
		return numArcDigit;
	}

	public void setNumArcDigit(Integer numArcDigit) {
		this.numArcDigit = numArcDigit;
	}

	public String getCodRegPersona() {
		return codRegPersona;
	}

	public void setCodRegPersona(String codRegPersona) {
		this.codRegPersona = codRegPersona;
	}

	public String getCodTipo() {
		return codTipo;
	}

	public void setCodTipo(String codTipo) {
		this.codTipo = codTipo;
	}

	public String getCodSubTipo() {
		return codSubTipo;
	}

	public void setCodSubTipo(String codSubTipo) {
		this.codSubTipo = codSubTipo;
	}

	public String getIndActivo() {
		return indActivo;
	}

	public void setIndActivo(String indActivo) {
		this.indActivo = indActivo;
	}

	public Date getFecRegis() {
		return fecRegis;
	}

	public void setFecRegis(Date fecRegis) {
		this.fecRegis = fecRegis;
	}

	public String getCodUsuregis() {
		return codUsuregis;
	}

	public void setCodUsuregis(String codUsuregis) {
		this.codUsuregis = codUsuregis;
	}

	public Date getFecModif() {
		return fecModif;
	}

	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}

	public String getCodUsumodif() {
		return codUsumodif;
	}

	public void setCodUsumodif(String codUsumodif) {
		this.codUsumodif = codUsumodif;
	}
	
	
}
