package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10388ACTIVIDPROG")
public class ActividadPrograma extends Auditoria {

	@Id
	@Column(name = "NUM_ACT_PROGRAM")
	private Long numActividadPrograma;

	@Column(name = "cod_actividad")
	private String codActividad;

	@Column(name = "num_programacion")
	private Long numProgramacion;

	public String getCodActividad() {
		return codActividad;
	}

	public void setCodActividad(String codActividad) {
		this.codActividad = codActividad;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public Long getNumActividadPrograma() {
		return numActividadPrograma;
	}

	public void setNumActividadPrograma(Long numActividadPrograma) {
		this.numActividadPrograma = numActividadPrograma;
	}

}
