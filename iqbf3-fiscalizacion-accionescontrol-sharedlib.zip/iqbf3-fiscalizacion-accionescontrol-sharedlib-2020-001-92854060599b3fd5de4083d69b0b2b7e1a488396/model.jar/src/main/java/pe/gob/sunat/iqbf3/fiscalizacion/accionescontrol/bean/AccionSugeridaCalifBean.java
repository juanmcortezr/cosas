package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.math.BigDecimal;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class AccionSugeridaCalifBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private	String	desAccionSugerida;
	private	String	indEstadoAccionSugerida;
	private	Long	numAccionSugerida;
	private	BigDecimal	valMaximo;
	private	BigDecimal	valMinimo;
	private AuditoriaBean auditoriaBean;

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public AccionSugeridaCalifBean() {
		super();
	}

	public AccionSugeridaCalifBean(String desAccionSugerida, String indEstadoAccionSugerida, Long numAccionSugerida,
			BigDecimal valMaximo, BigDecimal valMinimo) {
		super();
		this.desAccionSugerida = desAccionSugerida;
		this.indEstadoAccionSugerida = indEstadoAccionSugerida;
		this.numAccionSugerida = numAccionSugerida;
		this.valMaximo = valMaximo;
		this.valMinimo = valMinimo;
	}

	public String getDesAccionSugerida() {
		return desAccionSugerida;
	}

	public void setDesAccionSugerida(String desAccionSugerida) {
		this.desAccionSugerida = desAccionSugerida;
	}

	public String getIndEstadoAccionSugerida() {
		return indEstadoAccionSugerida;
	}

	public void setIndEstadoAccionSugerida(String indEstadoAccionSugerida) {
		this.indEstadoAccionSugerida = indEstadoAccionSugerida;
	}

	public Long getNumAccionSugerida() {
		return numAccionSugerida;
	}

	public void setNumAccionSugerida(Long numAccionSugerida) {
		this.numAccionSugerida = numAccionSugerida;
	}

	public BigDecimal getValMaximo() {
		return valMaximo;
	}

	public void setValMaximo(BigDecimal valMaximo) {
		this.valMaximo = valMaximo;
	}

	public BigDecimal getValMinimo() {
		return valMinimo;
	}

	public void setValMinimo(BigDecimal valMinimo) {
		this.valMinimo = valMinimo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
