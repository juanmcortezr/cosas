package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class TareoAuditorBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String desActividad;
	private String fecActividad;
	private String horEmpleada;
	private int numTareo;
	private int numOrden;
	
	private AuditoriaBean auditoriaBean;
	
	private String indDel;

	private String indEst;
	
	public TareoAuditorBean() {
		super();
	}

	public TareoAuditorBean(String desActividad, String fecActividad, String horEmpleada, int numTareo, int numOrden) {
		super();
		this.desActividad = desActividad;
		this.fecActividad = fecActividad;
		this.horEmpleada = horEmpleada;
		this.numTareo = numTareo;
		this.numOrden = numOrden;
	}

	public String getDesActividad() {
		return desActividad;
	}

	public void setDesActividad(String desActividad) {
		this.desActividad = desActividad;
	}

	public String getFecActividad() {
		return fecActividad;
	}

	public void setFecActividad(String fecActividad) {
		this.fecActividad = fecActividad;
	}

	public String getHorEmpleada() {
		return horEmpleada;
	}

	public void setHorEmpleada(String horEmpleada) {
		this.horEmpleada = horEmpleada;
	}

	public int getNumTareo() {
		return numTareo;
	}

	public void setNumTareo(int numTareo) {
		this.numTareo = numTareo;
	}

	public int getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(int numOrden) {
		this.numOrden = numOrden;
	}
	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}
	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}
}
