package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class BienFiscalizadoUsuarioBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codBienFiscalizado;
	private	String	codTipoBien;
	private	String	desOtroBien;
	private	String	desBienFisca;
	private	String	desTipoBien;
	private	int	numBienFiscaUsuario;
	private	int	numUsuarioSolicitud;
	
	public BienFiscalizadoUsuarioBean() {
		super();
	}

	public BienFiscalizadoUsuarioBean(String codBienFiscalizado, String codTipoBien, String desOtroBien,
			String desBienFisca, String desTipoBien, int numBienFiscaUsuario, int numUsuarioSolicitud) {
		super();
		this.codBienFiscalizado = codBienFiscalizado;
		this.codTipoBien = codTipoBien;
		this.desOtroBien = desOtroBien;
		this.desBienFisca = desBienFisca;
		this.desTipoBien = desTipoBien;
		this.numBienFiscaUsuario = numBienFiscaUsuario;
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getDesOtroBien() {
		return desOtroBien;
	}

	public void setDesOtroBien(String desOtroBien) {
		this.desOtroBien = desOtroBien;
	}

	public String getDesBienFisca() {
		return desBienFisca;
	}

	public void setDesBienFisca(String desBienFisca) {
		this.desBienFisca = desBienFisca;
	}

	public String getDesTipoBien() {
		return desTipoBien;
	}

	public void setDesTipoBien(String desTipoBien) {
		this.desTipoBien = desTipoBien;
	}

	public int getNumBienFiscaUsuario() {
		return numBienFiscaUsuario;
	}

	public void setNumBienFiscaUsuario(int numBienFiscaUsuario) {
		this.numBienFiscaUsuario = numBienFiscaUsuario;
	}

	public int getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(int numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}	
}
