package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "T10405DOCOPERORDEN")
public class DocumentoOperacion extends Auditoria {

	 @Column(name = "COD_TIP_DOCOPERA")
	 private String codTipoDocumentoOperacion;
	
	 @Id
	 @Column(name = "NUM_DOC_OPERORDEN")
	 private Long numDocumentoOperacion;
	
	 @Column(name = "NUM_DOCCOMER")
	 private String numDocumentoComercial;
	 
	 @Column(name = "NUM_ORDEN")
	 private Long numOrden;
	 
	 @Transient
	 private boolean indEliminar;
	 
	 
	public String getCodTipoDocumentoOperacion() {
		return codTipoDocumentoOperacion;
	}

	public void setCodTipoDocumentoOperacion(String codTipoDocumentoOperacion) {
		this.codTipoDocumentoOperacion = codTipoDocumentoOperacion;
	}

	public Long getNumDocumentoOperacion() {
		return numDocumentoOperacion;
	}

	public void setNumDocumentoOperacion(Long numDocumentoOperacion) {
		this.numDocumentoOperacion = numDocumentoOperacion;
	}

	public String getNumDocumentoComercial() {
		return numDocumentoComercial;
	}

	public void setNumDocumentoComercial(String numDocumentoComercial) {
		this.numDocumentoComercial = numDocumentoComercial;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}

	public boolean isIndEliminar() {
		return indEliminar;
	}

	public void setIndEliminar(boolean indEliminar) {
		this.indEliminar = indEliminar;
	}
	
	
 
}
