package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienFiscalizadoSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CheckElementBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;

@Entity
@Table(name = "T10421SOLICPROG")
public class SolicitudProgramacion extends Auditoria {

	@Column(name = "ANN_SOLICITUD")
	private Integer anioSolicitud;

	@Column(name = "COD_EST_SOLICITUD")
	private String codEstadoSolicitud;

	@Column(name = "COD_SOLICITANTE")
	private String codSolicitante;

	@Column(name = "COD_TIP_DOCREFER")
	private String codTipoDocumentoReferencia;

	@Column(name = "COD_UUOO")
	private String codUnidadOrganica;

	@Column(name = "DES_MOT_ASIGNACION")
	private String desMotivoAsignacion;

	@Column(name = "DES_OTRO_SOLICITAN")
	private String desOtroSolicitante;

	@Column(name = "DES_SUS_SOLICITUD")
	private String desSusSolicitud;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEC_GENERACION")
	private Date fecGeneracion;

	@Column(name = "IND_OTRO_SOLICITAN")
	private String indOtroSolicitan;

	@Column(name = "NUM_CORREL")
	private Integer numCorrel;

	@Column(name = "NUM_DOC_REFER")
	private String numDocumentoReferencia;

	@Id
	@Column(name = "NUM_SOLIC_PROG")
	private Long numSolicitud;

	@Column(name = "OBS_SOLICITUD")
	private String obsSolicitud;

	@Column(name = "PER_FIN")
	private String perFin;

	@Column(name = "PER_INICIO")
	private String perInicio;

	@Column(name = "NUM_ARC")
	private Long numArc;

	// Filtro
	@Transient
	private Double calificacionPreliminar;
	@Transient
	private Double calificacionDefinitiva;
	@Transient
	private List<String> estados;
	@Transient
	private String codTipAccion;
	@Transient
	private String codTipInterv;
	@Transient
	private String codTipDocIdent;
	@Transient
	private String numDocIdent;
	@Transient
	private String codProgramador;
	@Transient
	private String codSupervisor;
	@Transient
	private Date fechaEstadoActual;
	@Transient
	private Double medioProbatorio;

	// PARA FILTRO

	@Transient
	private String numSolicitudUnion;
	@Transient
	private String nomApeUsu;
	@Transient
	private String codPers;
	@Transient
	private Integer valCalificacion;
	@Transient
	private String calificacionDesde;
	@Transient
	private String calificacionHasta;
	@Transient
	private String nomSolicitante;
	@Transient
	private Date fechaDesde;
	@Transient
	private Date fechaHasta;
	@Transient
	private List<DataCatalogoBean> inconsistencias;
	@Transient
	private List<DataCatalogoBean> tipoBienes;
	@Transient
	private List<BienFiscalizadoSolicitudBean> bienesFiscalizados;
	@Transient
	private List<CheckElementBean> respInconsistencias;
	@Transient
	private String razonSocial;
	@Transient
	private String nomProgramador;

	
	public String getNomProgramador() {
		return nomProgramador;
	}

	public void setNomProgramador(String nomProgramador) {
		this.nomProgramador = nomProgramador;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public List<CheckElementBean> getRespInconsistencias() {
		return respInconsistencias;
	}

	public void setRespInconsistencias(List<CheckElementBean> respInconsistencias) {
		this.respInconsistencias = respInconsistencias;
	}

	public List<BienFiscalizadoSolicitudBean> getBienesFiscalizados() {
		return bienesFiscalizados;
	}

	public void setBienesFiscalizados(List<BienFiscalizadoSolicitudBean> bienesFiscalizados) {
		this.bienesFiscalizados = bienesFiscalizados;
	}

	public List<DataCatalogoBean> getTipoBienes() {
		return tipoBienes;
	}

	public void setTipoBienes(List<DataCatalogoBean> tipoBienes) {
		this.tipoBienes = tipoBienes;
	}

	public List<DataCatalogoBean> getInconsistencias() {
		return inconsistencias;
	}

	public void setInconsistencias(List<DataCatalogoBean> inconsistencias) {
		this.inconsistencias = inconsistencias;
	}


	public String getNomSolicitante() {
		return nomSolicitante;
	}

	public void setNomSolicitante(String nomSolicitante) {
		this.nomSolicitante = nomSolicitante;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getCodTipAccion() {
		return codTipAccion;
	}

	public void setCodTipAccion(String codTipAccion) {
		this.codTipAccion = codTipAccion;
	}

	public Integer getAnioSolicitud() {
		return anioSolicitud;
	}

	public void setAnioSolicitud(Integer anioSolicitud) {
		this.anioSolicitud = anioSolicitud;
	}

	public String getCodEstadoSolicitud() {
		return codEstadoSolicitud;
	}

	public void setCodEstadoSolicitud(String codEstadoSolicitud) {
		this.codEstadoSolicitud = codEstadoSolicitud;
	}

	public String getCodSolicitante() {
		return codSolicitante;
	}

	public void setCodSolicitante(String codSolicitante) {
		this.codSolicitante = codSolicitante;
	}

	public String getCodTipoDocumentoReferencia() {
		return codTipoDocumentoReferencia;
	}

	public void setCodTipoDocumentoReferencia(String codTipoDocumentoReferencia) {
		this.codTipoDocumentoReferencia = codTipoDocumentoReferencia;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public String getDesMotivoAsignacion() {
		return desMotivoAsignacion;
	}

	public void setDesMotivoAsignacion(String desMotivoAsignacion) {
		this.desMotivoAsignacion = desMotivoAsignacion;
	}

	public String getDesOtroSolicitante() {
		return desOtroSolicitante;
	}

	public void setDesOtroSolicitante(String desOtroSolicitante) {
		this.desOtroSolicitante = desOtroSolicitante;
	}

	public String getDesSusSolicitud() {
		return desSusSolicitud;
	}

	public void setDesSusSolicitud(String desSusSolicitud) {
		this.desSusSolicitud = desSusSolicitud;
	}

	public Date getFecGeneracion() {
		return fecGeneracion;
	}

	public void setFecGeneracion(Date fecGeneracion) {
		this.fecGeneracion = fecGeneracion;
	}

	public String getIndOtroSolicitan() {
		return indOtroSolicitan;
	}

	public void setIndOtroSolicitan(String indOtroSolicitan) {
		this.indOtroSolicitan = indOtroSolicitan;
	}

	public Integer getNumCorrel() {
		return numCorrel;
	}

	public void setNumCorrel(Integer numCorrel) {
		this.numCorrel = numCorrel;
	}

	public String getNumDocumentoReferencia() {
		return numDocumentoReferencia;
	}

	public void setNumDocumentoReferencia(String numDocumentoReferencia) {
		this.numDocumentoReferencia = numDocumentoReferencia;
	}

	public Long getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Long numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public String getObsSolicitud() {
		return obsSolicitud;
	}

	public void setObsSolicitud(String obsSolicitud) {
		this.obsSolicitud = obsSolicitud;
	}

	public String getPerFin() {
		return perFin;
	}

	public void setPerFin(String perFin) {
		this.perFin = perFin;
	}

	public String getPerInicio() {
		return perInicio;
	}

	public void setPerInicio(String perInicio) {
		this.perInicio = perInicio;
	}

	public Double getCalificacionPreliminar() {
		return calificacionPreliminar;
	}

	public void setCalificacionPreliminar(Double calificacionPreliminar) {
		this.calificacionPreliminar = calificacionPreliminar;
	}

	public Double getCalificacionDefinitiva() {
		return calificacionDefinitiva;
	}

	public void setCalificacionDefinitiva(Double calificacionDefinitiva) {
		this.calificacionDefinitiva = calificacionDefinitiva;
	}

	public List<String> getEstados() {
		return estados;
	}

	public void setEstados(List<String> estados) {
		this.estados = estados;
	}

	public String getCodTipInterv() {
		return codTipInterv;
	}

	public void setCodTipInterv(String codTipInterv) {
		this.codTipInterv = codTipInterv;
	}

	public String getCodTipDocIdent() {
		return codTipDocIdent;
	}

	public void setCodTipDocIdent(String codTipDocIdent) {
		this.codTipDocIdent = codTipDocIdent;
	}

	public String getNumDocIdent() {
		return numDocIdent;
	}

	public void setNumDocIdent(String numDocIdent) {
		this.numDocIdent = numDocIdent;
	}

	public SolicitudProgramacion() {
	}

	public Long getNumArc() {
		return numArc;
	}

	public void setNumArc(Long numArc) {
		this.numArc = numArc;
	}

	public String getCodProgramador() {
		return codProgramador;
	}

	public void setCodProgramador(String codProgramador) {
		this.codProgramador = codProgramador;
	}

	public String getCodSupervisor() {
		return codSupervisor;
	}

	public void setCodSupervisor(String codSupervisor) {
		this.codSupervisor = codSupervisor;
	}

	public Integer getValCalificacion() {
		return valCalificacion;
	}

	public void setValCalificacion(Integer valCalificacion) {
		this.valCalificacion = valCalificacion;
	}

	public String getCalificacionDesde() {
		return calificacionDesde;
	}

	public void setCalificacionDesde(String calificacionDesde) {
		this.calificacionDesde = calificacionDesde;
	}

	public String getCalificacionHasta() {
		return calificacionHasta;
	}

	public void setCalificacionHasta(String calificacionHasta) {
		this.calificacionHasta = calificacionHasta;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getNomApeUsu() {
		return nomApeUsu;
	}

	public void setNomApeUsu(String nomApeUsu) {
		this.nomApeUsu = nomApeUsu;
	}

	public String getNumSolicitudUnion() {
		return numSolicitudUnion;
	}

	public void setNumSolicitudUnion(String numSolicitudUnion) {
		this.numSolicitudUnion = numSolicitudUnion;
	}

	public Date getFechaEstadoActual() {
		return fechaEstadoActual;
	}

	public void setFechaEstadoActual(Date fechaEstadoActual) {
		this.fechaEstadoActual = fechaEstadoActual;
	}

	public Double getMedioProbatorio() {
		return medioProbatorio;
	}

	public void setMedioProbatorio(Double medioProbatorio) {
		this.medioProbatorio = medioProbatorio;
	}

}
