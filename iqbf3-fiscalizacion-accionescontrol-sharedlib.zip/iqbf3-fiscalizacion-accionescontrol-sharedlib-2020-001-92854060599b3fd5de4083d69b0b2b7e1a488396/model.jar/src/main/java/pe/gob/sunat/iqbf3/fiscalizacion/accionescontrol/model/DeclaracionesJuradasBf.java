package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "T5284BFCABDJRO")
public class DeclaracionesJuradasBf extends Auditoria{

	@EmbeddedId
	private DeclaracionesJuradasBfPK declaracionesJuradasBfPk;
		
	 @Column(name = "COD_ESTADO")
	 private String codEstado;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_FIN_OMISO")
	 private Date fecFinOmiso;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_FIN_OPE")
	 private Date fecFinOperacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_FIN_PRESEN")
	 private Date fecFinPresentacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_OMISO")
	 private Date fecInicioOmiso;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_OPE")
	 private Date fecInicioOperacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_PRESEN")
	 private Date fecInicioPresentacion;
	
	 @Column(name = "IND_OMISO")
	 private String indOmiso;
	
	 @Column(name = "IND_TIPENV")
	 private Integer indTipenv;
	
	 @Column(name = "NUM_CONFIRMA")
	 private Integer numConfirma;
	
	 @Column(name = "NUM_PERIODO")
	 private String numPeriodo;

	 
	 //Para listado listarUsuariosOmisosDjRop
	 @Transient
	 private String minPeriodo;
	 @Transient
	 private String maxPeriodo;
	 @Transient
	 private Date fecFinvigencia;
	 
	 @Transient
	 private String codTipobien;
	 @Transient
	 private String numRuc;
	 @Transient
	 private Integer numVersionRegistro;
	 
	 
	public String getCodTipobien() {
		return codTipobien;
	}

	public void setCodTipobien(String codTipobien) {
		this.codTipobien = codTipobien;
	}

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public Integer getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(Integer numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public String getMinPeriodo() {
		return minPeriodo;
	}

	public void setMinPeriodo(String minPeriodo) {
		this.minPeriodo = minPeriodo;
	}

	public String getMaxPeriodo() {
		return maxPeriodo;
	}

	public void setMaxPeriodo(String maxPeriodo) {
		this.maxPeriodo = maxPeriodo;
	}

	public Date getFecFinvigencia() {
		return fecFinvigencia;
	}

	public void setFecFinvigencia(Date fecFinvigencia) {
		this.fecFinvigencia = fecFinvigencia;
	}

	
	
	public DeclaracionesJuradasBfPK getDeclaracionesJuradasBfPk() {
		return declaracionesJuradasBfPk;
	}

	public void setDeclaracionesJuradasBfPk(DeclaracionesJuradasBfPK declaracionesJuradasBfPk) {
		this.declaracionesJuradasBfPk = declaracionesJuradasBfPk;
	}


	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public Date getFecFinOmiso() {
		return fecFinOmiso;
	}

	public void setFecFinOmiso(Date fecFinOmiso) {
		this.fecFinOmiso = fecFinOmiso;
	}

	public Date getFecFinOperacion() {
		return fecFinOperacion;
	}

	public void setFecFinOperacion(Date fecFinOperacion) {
		this.fecFinOperacion = fecFinOperacion;
	}

	public Date getFecFinPresentacion() {
		return fecFinPresentacion;
	}

	public void setFecFinPresentacion(Date fecFinPresentacion) {
		this.fecFinPresentacion = fecFinPresentacion;
	}

	public Date getFecInicioOmiso() {
		return fecInicioOmiso;
	}

	public void setFecInicioOmiso(Date fecInicioOmiso) {
		this.fecInicioOmiso = fecInicioOmiso;
	}

	public Date getFecInicioOperacion() {
		return fecInicioOperacion;
	}

	public void setFecInicioOperacion(Date fecInicioOperacion) {
		this.fecInicioOperacion = fecInicioOperacion;
	}

	public Date getFecInicioPresentacion() {
		return fecInicioPresentacion;
	}

	public void setFecInicioPresentacion(Date fecInicioPresentacion) {
		this.fecInicioPresentacion = fecInicioPresentacion;
	}

	public String getIndOmiso() {
		return indOmiso;
	}

	public void setIndOmiso(String indOmiso) {
		this.indOmiso = indOmiso;
	}

	public Integer getIndTipenv() {
		return indTipenv;
	}

	public void setIndTipenv(Integer indTipenv) {
		this.indTipenv = indTipenv;
	}

	public Integer getNumConfirma() {
		return numConfirma;
	}

	public void setNumConfirma(Integer numConfirma) {
		this.numConfirma = numConfirma;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

}
