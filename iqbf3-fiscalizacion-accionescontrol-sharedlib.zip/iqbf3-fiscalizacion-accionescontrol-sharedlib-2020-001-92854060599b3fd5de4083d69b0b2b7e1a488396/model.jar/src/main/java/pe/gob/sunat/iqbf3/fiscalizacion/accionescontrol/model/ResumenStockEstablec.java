package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "T5641RSTOCKESTAB")
public class ResumenStockEstablec extends Auditoria {

	@EmbeddedId
	private ResumenStockEstablecPK resumenStockEstablecPk;
	
	 @Column(name = "CNT_ING_EST")
	 private Double cntIngEst;
	
	 @Column(name = "CNT_SAL_EST")
	 private Double cantidadSalidaEstablec;
	
	 @Column(name = "CNT_STOCK_ACTUAL")
	 private Double cantidadStockActual;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_FIN_CALC")
	 private Date fecFinCalc;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INIC_CALC")
	 private Date fecInicioCalculo;
	
	 @Column(name = "NUM_CONFIRMA")
	 private Integer numConfirma;
	
	 @Column(name = "NUM_STOCK")
	 private Integer numStock;

	// Para filtro
	 @Transient
	 private Long numVersionEstab;
	 @Transient
	 private Long numInscab;
	 @Transient
	 private Long numVersionCabInsumo;
	 @Transient
	 private String codInsumo;
	 @Transient
	 private String numOrden;
	 @Transient
	 private String codTipProd;
	 @Transient
	 private String codUm;
	 @Transient
	 private String desNomProd;
	 @Transient
	 private String desNomComProd;
	 @Transient
	 private String codBienFisca;
	 @Transient
	 private Integer numVersion;
	 @Transient
	 private BigDecimal porMax;
	 @Transient
	 private BigDecimal porMin;
	 @Transient
	 private String codUbigeo;
	 
	 @Transient
	 private Integer numPresentacion;
	 @Transient
	 private String codPresen;
	 @Transient
	 private String codUnidadComercial;
	 @Transient
	 private Double cantidadUnidadFisica;
	 @Transient
	 private String codUnidadFiscal;
	 @Transient
	 private Double cntNetProd;
	 @Transient
	 private Double cntNeteada;
	 @Transient
	 private Integer numVersionRegistroBfPresenta;
	 @Transient
	 private Date fecFinvigencia;
	 @Transient
	 private String codEstado;
	 @Transient
	 private Long numVersionPressentacion;
	 
	 @Transient
	 private Long cantidadStock;
	 
	 @Transient
	 private Long cntStockNegativoVerificacion;
	 
	 @Transient
	 private Integer codTipobien;
		
	 @Transient
	 private Integer numRuc;
	
	 @Transient
	 private Integer numVersionRegistro;
	
	 @Transient
	 private Integer numReposicion;
	 
	 @Transient
	 private String numPeriodo;
	
	 @Transient
	 private String numEstablecimiento;

	 
	 
	 
	public Integer getCodTipobien() {
		return codTipobien;
	}

	public void setCodTipobien(Integer codTipobien) {
		this.codTipobien = codTipobien;
	}

	public Integer getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(Integer numRuc) {
		this.numRuc = numRuc;
	}

	public Integer getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(Integer numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public Integer getNumReposicion() {
		return numReposicion;
	}

	public void setNumReposicion(Integer numReposicion) {
		this.numReposicion = numReposicion;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public String getNumEstablecimiento() {
		return numEstablecimiento;
	}

	public void setNumEstablecimiento(String numEstablecimiento) {
		this.numEstablecimiento = numEstablecimiento;
	}

	public Long getCntStockNegativoVerificacion() {
		return cntStockNegativoVerificacion;
	}

	public void setCntStockNegativoVerificacion(Long cntStockNegativoVerificacion) {
		this.cntStockNegativoVerificacion = cntStockNegativoVerificacion;
	}

	public Long getCantidadStock() {
		return cantidadStock;
	}

	public void setCantidadStock(Long cantidadStock) {
		this.cantidadStock = cantidadStock;
	}

	public Long getNumVersionPressentacion() {
		return numVersionPressentacion;
	}

	public void setNumVersionPressentacion(Long numVersionPressentacion) {
		this.numVersionPressentacion = numVersionPressentacion;
	}

	public Long getNumVersionEstab() {
		return numVersionEstab;
	}

	public void setNumVersionEstab(Long numVersionEstab) {
		this.numVersionEstab = numVersionEstab;
	}

	public Long getNumInscab() {
		return numInscab;
	}

	public void setNumInscab(Long numInscab) {
		this.numInscab = numInscab;
	}

	public Long getNumVersionCabInsumo() {
		return numVersionCabInsumo;
	}

	public void setNumVersionCabInsumo(Long numVersionCabInsumo) {
		this.numVersionCabInsumo = numVersionCabInsumo;
	}

	public String getCodInsumo() {
		return codInsumo;
	}

	public void setCodInsumo(String codInsumo) {
		this.codInsumo = codInsumo;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}

	public String getCodTipProd() {
		return codTipProd;
	}

	public void setCodTipProd(String codTipProd) {
		this.codTipProd = codTipProd;
	}

	public String getCodUm() {
		return codUm;
	}

	public void setCodUm(String codUm) {
		this.codUm = codUm;
	}

	public String getDesNomProd() {
		return desNomProd;
	}

	public void setDesNomProd(String desNomProd) {
		this.desNomProd = desNomProd;
	}

	public String getDesNomComProd() {
		return desNomComProd;
	}

	public void setDesNomComProd(String desNomComProd) {
		this.desNomComProd = desNomComProd;
	}

	public String getCodBienFisca() {
		return codBienFisca;
	}

	public void setCodBienFisca(String codBienFisca) {
		this.codBienFisca = codBienFisca;
	}

	public Integer getNumVersion() {
		return numVersion;
	}

	public void setNumVersion(Integer numVersion) {
		this.numVersion = numVersion;
	}

	public BigDecimal getPorMax() {
		return porMax;
	}

	public void setPorMax(BigDecimal porMax) {
		this.porMax = porMax;
	}

	public BigDecimal getPorMin() {
		return porMin;
	}

	public void setPorMin(BigDecimal porMin) {
		this.porMin = porMin;
	}

	public String getCodUbigeo() {
		return codUbigeo;
	}

	public void setCodUbigeo(String codUbigeo) {
		this.codUbigeo = codUbigeo;
	}

	public Integer getNumPresentacion() {
		return numPresentacion;
	}

	public void setNumPresentacion(Integer numPresentacion) {
		this.numPresentacion = numPresentacion;
	}

	public String getCodPresen() {
		return codPresen;
	}

	public void setCodPresen(String codPresen) {
		this.codPresen = codPresen;
	}

	public String getCodUnidadComercial() {
		return codUnidadComercial;
	}

	public void setCodUnidadComercial(String codUnidadComercial) {
		this.codUnidadComercial = codUnidadComercial;
	}

	public Double getCantidadUnidadFisica() {
		return cantidadUnidadFisica;
	}

	public void setCantidadUnidadFisica(Double cantidadUnidadFisica) {
		this.cantidadUnidadFisica = cantidadUnidadFisica;
	}

	public String getCodUnidadFiscal() {
		return codUnidadFiscal;
	}

	public void setCodUnidadFiscal(String codUnidadFiscal) {
		this.codUnidadFiscal = codUnidadFiscal;
	}

	public Double getCntNetProd() {
		return cntNetProd;
	}

	public void setCntNetProd(Double cntNetProd) {
		this.cntNetProd = cntNetProd;
	}

	public Double getCntNeteada() {
		return cntNeteada;
	}

	public void setCntNeteada(Double cntNeteada) {
		this.cntNeteada = cntNeteada;
	}

	public Integer getNumVersionRegistroBfPresenta() {
		return numVersionRegistroBfPresenta;
	}

	public void setNumVersionRegistroBfPresenta(Integer numVersionRegistroBfPresenta) {
		this.numVersionRegistroBfPresenta = numVersionRegistroBfPresenta;
	}

	public Date getFecFinvigencia() {
		return fecFinvigencia;
	}

	public void setFecFinvigencia(Date fecFinvigencia) {
		this.fecFinvigencia = fecFinvigencia;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public ResumenStockEstablecPK getResumenStockEstablecPk() {
		return resumenStockEstablecPk;
	}

	public void setResumenStockEstablecPk(ResumenStockEstablecPK resumenStockEstablecPk) {
		this.resumenStockEstablecPk = resumenStockEstablecPk;
	}

	public Double getCntIngEst() {
		return cntIngEst;
	}

	public void setCntIngEst(Double cntIngEst) {
		this.cntIngEst = cntIngEst;
	}

	public Double getCantidadSalidaEstablec() {
		return cantidadSalidaEstablec;
	}

	public void setCantidadSalidaEstablec(Double cantidadSalidaEstablec) {
		this.cantidadSalidaEstablec = cantidadSalidaEstablec;
	}

	public Double getCantidadStockActual() {
		return cantidadStockActual;
	}

	public void setCantidadStockActual(Double cantidadStockActual) {
		this.cantidadStockActual = cantidadStockActual;
	}

	public Date getFecFinCalc() {
		return fecFinCalc;
	}

	public void setFecFinCalc(Date fecFinCalc) {
		this.fecFinCalc = fecFinCalc;
	}

	public Date getFecInicioCalculo() {
		return fecInicioCalculo;
	}

	public void setFecInicioCalculo(Date fecInicioCalculo) {
		this.fecInicioCalculo = fecInicioCalculo;
	}

	public Integer getNumConfirma() {
		return numConfirma;
	}

	public void setNumConfirma(Integer numConfirma) {
		this.numConfirma = numConfirma;
	}

	public Integer getNumStock() {
		return numStock;
	}

	public void setNumStock(Integer numStock) {
		this.numStock = numStock;
	}
	
}
