package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10396BIENFISSOLIC")
public class BienFiscalizadoSolicitud extends Auditoria {

	
	 @Column(name = "COD_BIEN_FISCA")
	 private String codBienFiscalizado;
	
	 @Column(name = "COD_TIP_BIEN")
	 private String codTipoBien;
	
	 @Column(name = "DES_OTRO_TIPOBIEN")
	 private String desOtroTipobien;
	
	 @Id
	 @Column(name = "NUM_BIEN_FISCASOLI")
	 private Long numBienFiscaSolicitud;

	 @Column(name = "NUM_SOLIC_PROG")
	 private Long numSolicitud;
	

	 public Long getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Long numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getDesOtroTipobien() {
		return desOtroTipobien;
	}

	public void setDesOtroTipobien(String desOtroTipobien) {
		this.desOtroTipobien = desOtroTipobien;
	}

	public Long getNumBienFiscaSolicitud() {
		return numBienFiscaSolicitud;
	}

	public void setNumBienFiscaSolicitud(Long numBienFiscaSolicitud) {
		this.numBienFiscaSolicitud = numBienFiscaSolicitud;
	}

	

}
