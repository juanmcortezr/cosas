package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T8076DOCUMENTOADM")
public class DocumentoAdm implements Entidad{

	@Id
	 @Column(name = "NUM_ID_DOC")
	 private Long numIdDoc;
	
	 @Column(name = "COD_TIPO_DOC")
	 private String codTipoDoc;
	
	 @Column(name = "COD_TIPO_PROC")
	 private String codTipoProc;
	
	 @Column(name = "NUM_RUC")
	 private String numRuc;
	
	 @Column(name = "NUM_DOC")
	 private String numDoc;
	
	 @Column(name = "COD_PAQUETE")
	 private String codPaquete;
	
	 @Column(name = "COD_TIPO_FMT")
	 private String codTipoFmt;
	
	 @Column(name = "ANN_DOC")
	 private String annDoc;
	
	 @Column(name = "FEC_DOC")
	 private Date fecDoc;
	
	 @Column(name = "FEC_PROYECTADO")
	 private Date fecProyectado;
	
	 @Column(name = "COD_PROYECTA")
	 private String codProyecta;
	
	 @Column(name = "COD_UUOO")
	 private String codUuoo;
	
	 @Column(name = "NOM_UUOO")
	 private String nomUuoo;
	
	 @Column(name = "COD_REVISA")
	 private String codRevisa;
	
	 @Column(name = "FEC_REVISA")
	 private Date fecRevisa;
	
	 @Column(name = "OBS_REVISA")
	 private String obsRevisa;
	
	 @Column(name = "COD_APRUEBA")
	 private String codAprueba;
	
	 @Column(name = "FEC_APRUEBA")
	 private Date fecAprueba;
	
	 @Column(name = "OBS_APRUEBA")
	 private String obsAprueba;
	
	 @Column(name = "COD_ESTADO")
	 private String codEstado;
	
	 @Column(name = "NUM_ID_ECM")
	 private String numIdEcm;
	
	 @Column(name = "IND_ORIGEN")
	 private String indOrigen;
	
	 @Column(name = "NOM_DEP")
	 private String nomDep;
	
	 @Column(name = "NOM_PRO")
	 private String nomPro;
	
	 @Column(name = "NOM_DIS")
	 private String nomDis;
	
	 @Column(name = "DES_DIR")
	 private String desDir;
	
	 @Column(name = "DES_MES_INI")
	 private String desMesIni;
	
	 @Column(name = "DES_MES_FIN")
	 private String desMesFin;
	
	 @Column(name = "MSG_FMT")
	 private String msgFmt;
	
	 @Column(name = "NUM_EXPEDIENTE")
	 private String numExpediente;
	
	 @Column(name = "COD_USUREGIS")
	 private String codUsuregis;
	
	 @Column(name = "FEC_REGIS")
	 private Date fecRegis;
	
	 @Column(name = "COD_USUMODIF")
	 private String codUsumodif;
	
	 @Column(name = "FEC_MODIF")
	 private Date fecModif;
	
	 @Column(name = "NUM_PEDIDO")
	 private String numPedido;

	public Long getNumIdDoc() {
		return numIdDoc;
	}

	public void setNumIdDoc(Long numIdDoc) {
		this.numIdDoc = numIdDoc;
	}

	public String getCodTipoDoc() {
		return codTipoDoc;
	}

	public void setCodTipoDoc(String codTipoDoc) {
		this.codTipoDoc = codTipoDoc;
	}

	public String getCodTipoProc() {
		return codTipoProc;
	}

	public void setCodTipoProc(String codTipoProc) {
		this.codTipoProc = codTipoProc;
	}

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public String getNumDoc() {
		return numDoc;
	}

	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}

	public String getCodPaquete() {
		return codPaquete;
	}

	public void setCodPaquete(String codPaquete) {
		this.codPaquete = codPaquete;
	}

	public String getCodTipoFmt() {
		return codTipoFmt;
	}

	public void setCodTipoFmt(String codTipoFmt) {
		this.codTipoFmt = codTipoFmt;
	}

	public String getAnnDoc() {
		return annDoc;
	}

	public void setAnnDoc(String annDoc) {
		this.annDoc = annDoc;
	}

	public Date getFecDoc() {
		return fecDoc;
	}

	public void setFecDoc(Date fecDoc) {
		this.fecDoc = fecDoc;
	}

	public Date getFecProyectado() {
		return fecProyectado;
	}

	public void setFecProyectado(Date fecProyectado) {
		this.fecProyectado = fecProyectado;
	}

	public String getCodProyecta() {
		return codProyecta;
	}

	public void setCodProyecta(String codProyecta) {
		this.codProyecta = codProyecta;
	}

	public String getCodUuoo() {
		return codUuoo;
	}

	public void setCodUuoo(String codUuoo) {
		this.codUuoo = codUuoo;
	}

	public String getNomUuoo() {
		return nomUuoo;
	}

	public void setNomUuoo(String nomUuoo) {
		this.nomUuoo = nomUuoo;
	}

	public String getCodRevisa() {
		return codRevisa;
	}

	public void setCodRevisa(String codRevisa) {
		this.codRevisa = codRevisa;
	}

	public Date getFecRevisa() {
		return fecRevisa;
	}

	public void setFecRevisa(Date fecRevisa) {
		this.fecRevisa = fecRevisa;
	}

	public String getObsRevisa() {
		return obsRevisa;
	}

	public void setObsRevisa(String obsRevisa) {
		this.obsRevisa = obsRevisa;
	}

	public String getCodAprueba() {
		return codAprueba;
	}

	public void setCodAprueba(String codAprueba) {
		this.codAprueba = codAprueba;
	}

	public Date getFecAprueba() {
		return fecAprueba;
	}

	public void setFecAprueba(Date fecAprueba) {
		this.fecAprueba = fecAprueba;
	}

	public String getObsAprueba() {
		return obsAprueba;
	}

	public void setObsAprueba(String obsAprueba) {
		this.obsAprueba = obsAprueba;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getNumIdEcm() {
		return numIdEcm;
	}

	public void setNumIdEcm(String numIdEcm) {
		this.numIdEcm = numIdEcm;
	}

	public String getIndOrigen() {
		return indOrigen;
	}

	public void setIndOrigen(String indOrigen) {
		this.indOrigen = indOrigen;
	}

	public String getNomDep() {
		return nomDep;
	}

	public void setNomDep(String nomDep) {
		this.nomDep = nomDep;
	}

	public String getNomPro() {
		return nomPro;
	}

	public void setNomPro(String nomPro) {
		this.nomPro = nomPro;
	}

	public String getNomDis() {
		return nomDis;
	}

	public void setNomDis(String nomDis) {
		this.nomDis = nomDis;
	}

	public String getDesDir() {
		return desDir;
	}

	public void setDesDir(String desDir) {
		this.desDir = desDir;
	}

	public String getDesMesIni() {
		return desMesIni;
	}

	public void setDesMesIni(String desMesIni) {
		this.desMesIni = desMesIni;
	}

	public String getDesMesFin() {
		return desMesFin;
	}

	public void setDesMesFin(String desMesFin) {
		this.desMesFin = desMesFin;
	}

	public String getMsgFmt() {
		return msgFmt;
	}

	public void setMsgFmt(String msgFmt) {
		this.msgFmt = msgFmt;
	}

	public String getNumExpediente() {
		return numExpediente;
	}

	public void setNumExpediente(String numExpediente) {
		this.numExpediente = numExpediente;
	}

	public String getCodUsuregis() {
		return codUsuregis;
	}

	public void setCodUsuregis(String codUsuregis) {
		this.codUsuregis = codUsuregis;
	}

	public Date getFecRegis() {
		return fecRegis;
	}

	public void setFecRegis(Date fecRegis) {
		this.fecRegis = fecRegis;
	}

	public String getCodUsumodif() {
		return codUsumodif;
	}

	public void setCodUsumodif(String codUsumodif) {
		this.codUsumodif = codUsumodif;
	}

	public Date getFecModif() {
		return fecModif;
	}

	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}
	

}
