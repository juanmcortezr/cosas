package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10397BIENFISCAUSU")
public class BienFiscalizadoUsuario extends Auditoria {

	
	 @Column(name = "COD_BIEN_FISCA")
	 private String codBienFiscalizado;
	
	 @Column(name = "COD_TIP_BIEN")
	 private String codTipoBien;
	
	 @Column(name = "DES_OTRO_BIEN")
	 private String desOtroBien;
	
	 @Id
	 @Column(name = "NUM_BIEN_FISCAUSUA")
	 private Long numBienFiscaUsuario;

	 @Column(name = "NUM_USU_SOLIC")
	 private Long numUsuarioSolicitud;
	
 
	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getDesOtroBien() {
		return desOtroBien;
	}

	public void setDesOtroBien(String desOtroBien) {
		this.desOtroBien = desOtroBien;
	}

	public Long getNumBienFiscaUsuario() {
		return numBienFiscaUsuario;
	}

	public void setNumBienFiscaUsuario(Long numBienFiscaUsuario) {
		this.numBienFiscaUsuario = numBienFiscaUsuario;
	}

}
