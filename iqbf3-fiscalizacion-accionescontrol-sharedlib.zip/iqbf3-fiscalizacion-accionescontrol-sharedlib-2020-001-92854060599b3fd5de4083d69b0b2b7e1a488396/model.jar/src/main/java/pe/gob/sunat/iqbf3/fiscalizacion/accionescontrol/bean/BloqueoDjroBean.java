package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class BloqueoDjroBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codTipoDocumento;
	private	String	desTipoDocumento;
	private	String	fecBloqDjro;
	private	String	indEstadoBloqueDjro;
	private	int	numBloqueoDjro;
	private	String	numDocumentoIdentif;
	private	int	numOrden;
	private	String	perFin;
	private	String	perInicio;
	
	public BloqueoDjroBean() {
		super();
	}

	public BloqueoDjroBean(String codTipoDocumento, String desTipoDocumento, String fecBloqDjro,
			String indEstadoBloqueDjro, int numBloqueoDjro, String numDocumentoIdentif, int numOrden, String perFin,
			String perInicio) {
		super();
		this.codTipoDocumento = codTipoDocumento;
		this.desTipoDocumento = desTipoDocumento;
		this.fecBloqDjro = fecBloqDjro;
		this.indEstadoBloqueDjro = indEstadoBloqueDjro;
		this.numBloqueoDjro = numBloqueoDjro;
		this.numDocumentoIdentif = numDocumentoIdentif;
		this.numOrden = numOrden;
		this.perFin = perFin;
		this.perInicio = perInicio;
	}

	public String getCodTipoDocumento() {
		return codTipoDocumento;
	}

	public void setCodTipoDocumento(String codTipoDocumento) {
		this.codTipoDocumento = codTipoDocumento;
	}

	public String getDesTipoDocumento() {
		return desTipoDocumento;
	}

	public void setDesTipoDocumento(String desTipoDocumento) {
		this.desTipoDocumento = desTipoDocumento;
	}

	public String getFecBloqDjro() {
		return fecBloqDjro;
	}

	public void setFecBloqDjro(String fecBloqDjro) {
		this.fecBloqDjro = fecBloqDjro;
	}

	public String getIndEstadoBloqueDjro() {
		return indEstadoBloqueDjro;
	}

	public void setIndEstadoBloqueDjro(String indEstadoBloqueDjro) {
		this.indEstadoBloqueDjro = indEstadoBloqueDjro;
	}

	public int getNumBloqueoDjro() {
		return numBloqueoDjro;
	}

	public void setNumBloqueoDjro(int numBloqueoDjro) {
		this.numBloqueoDjro = numBloqueoDjro;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public int getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(int numOrden) {
		this.numOrden = numOrden;
	}

	public String getPerFin() {
		return perFin;
	}

	public void setPerFin(String perFin) {
		this.perFin = perFin;
	}

	public String getPerInicio() {
		return perInicio;
	}

	public void setPerInicio(String perInicio) {
		this.perInicio = perInicio;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
