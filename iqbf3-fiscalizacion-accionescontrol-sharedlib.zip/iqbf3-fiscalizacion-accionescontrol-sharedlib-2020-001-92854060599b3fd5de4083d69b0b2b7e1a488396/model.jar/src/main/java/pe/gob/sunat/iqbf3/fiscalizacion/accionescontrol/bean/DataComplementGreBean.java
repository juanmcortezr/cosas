package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class DataComplementGreBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codigoVerificacion;
	private	String	desMotivoTraslado;
	private	String	fecEntregaProductos;
	private	String	fecInicioTraslado;
	private	int	formaTraslado;
	private	int	motivoEmision;
	private	int	motivoTraslado;
	private	int	numeroGuia;
	private	int	numeroRucRemitente;
	private	int	numeroSerie;
	private	String	rutaFiscal;
	private	int	tipoGuia;
	private	int	tipoTramo;
	private	int	transbordo;
	
	public DataComplementGreBean() {
		super();
	}

	public DataComplementGreBean(String codigoVerificacion, String desMotivoTraslado, String fecEntregaProductos,
			String fecInicioTraslado, int formaTraslado, int motivoEmision, int motivoTraslado, int numeroGuia,
			int numeroRucRemitente, int numeroSerie, String rutaFiscal, int tipoGuia, int tipoTramo, int transbordo) {
		super();
		this.codigoVerificacion = codigoVerificacion;
		this.desMotivoTraslado = desMotivoTraslado;
		this.fecEntregaProductos = fecEntregaProductos;
		this.fecInicioTraslado = fecInicioTraslado;
		this.formaTraslado = formaTraslado;
		this.motivoEmision = motivoEmision;
		this.motivoTraslado = motivoTraslado;
		this.numeroGuia = numeroGuia;
		this.numeroRucRemitente = numeroRucRemitente;
		this.numeroSerie = numeroSerie;
		this.rutaFiscal = rutaFiscal;
		this.tipoGuia = tipoGuia;
		this.tipoTramo = tipoTramo;
		this.transbordo = transbordo;
	}

	public String getCodigoVerificacion() {
		return codigoVerificacion;
	}

	public void setCodigoVerificacion(String codigoVerificacion) {
		this.codigoVerificacion = codigoVerificacion;
	}

	public String getDesMotivoTraslado() {
		return desMotivoTraslado;
	}

	public void setDesMotivoTraslado(String desMotivoTraslado) {
		this.desMotivoTraslado = desMotivoTraslado;
	}

	public String getFecEntregaProductos() {
		return fecEntregaProductos;
	}

	public void setFecEntregaProductos(String fecEntregaProductos) {
		this.fecEntregaProductos = fecEntregaProductos;
	}

	public String getFecInicioTraslado() {
		return fecInicioTraslado;
	}

	public void setFecInicioTraslado(String fecInicioTraslado) {
		this.fecInicioTraslado = fecInicioTraslado;
	}

	public int getFormaTraslado() {
		return formaTraslado;
	}

	public void setFormaTraslado(int formaTraslado) {
		this.formaTraslado = formaTraslado;
	}

	public int getMotivoEmision() {
		return motivoEmision;
	}

	public void setMotivoEmision(int motivoEmision) {
		this.motivoEmision = motivoEmision;
	}

	public int getMotivoTraslado() {
		return motivoTraslado;
	}

	public void setMotivoTraslado(int motivoTraslado) {
		this.motivoTraslado = motivoTraslado;
	}

	public int getNumeroGuia() {
		return numeroGuia;
	}

	public void setNumeroGuia(int numeroGuia) {
		this.numeroGuia = numeroGuia;
	}

	public int getNumeroRucRemitente() {
		return numeroRucRemitente;
	}

	public void setNumeroRucRemitente(int numeroRucRemitente) {
		this.numeroRucRemitente = numeroRucRemitente;
	}

	public int getNumeroSerie() {
		return numeroSerie;
	}

	public void setNumeroSerie(int numeroSerie) {
		this.numeroSerie = numeroSerie;
	}

	public String getRutaFiscal() {
		return rutaFiscal;
	}

	public void setRutaFiscal(String rutaFiscal) {
		this.rutaFiscal = rutaFiscal;
	}

	public int getTipoGuia() {
		return tipoGuia;
	}

	public void setTipoGuia(int tipoGuia) {
		this.tipoGuia = tipoGuia;
	}

	public int getTipoTramo() {
		return tipoTramo;
	}

	public void setTipoTramo(int tipoTramo) {
		this.tipoTramo = tipoTramo;
	}

	public int getTransbordo() {
		return transbordo;
	}

	public void setTransbordo(int transbordo) {
		this.transbordo = transbordo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
