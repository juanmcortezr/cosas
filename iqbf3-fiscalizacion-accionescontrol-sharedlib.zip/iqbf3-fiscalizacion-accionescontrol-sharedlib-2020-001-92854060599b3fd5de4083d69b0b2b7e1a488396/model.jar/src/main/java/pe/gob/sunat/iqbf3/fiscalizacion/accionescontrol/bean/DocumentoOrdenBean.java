package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class DocumentoOrdenBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	ArchivoBean	archivoBean;
	private	String	codOrigen;
	private	String	codTipoDocumento;
	private	String	desDocumento;
	private	String	desOrigen;
	private	String	desTipoDocumento;
	private	String	fecEmision;
	private	String	fecEntrega;
	private	String	fecNotificacion;
	private	String	fecPresentaVisita;
	private	String	fecProrroga;
	private	String	numDocumento;
	private	Long numDocumentoOrden;
	private Long numOrden;
	private Long numArc;
	private String nomArc;
	private AuditoriaBean auditoriaBean;
	private String indDel;
	private String indEst;
	
	
	public DocumentoOrdenBean() {
		super();
	}

	public DocumentoOrdenBean(ArchivoBean archivoBean, String codOrigen, String codTipoDocumento, String desDocumento,
			String desOrigen, String desTipoDocumento, String fecEmision, String fecEntrega, String fecNotificacion,
			String fecPresentaVisita, String fecProrroga, String numDocumento, Long numDocumentoOrden, Long numOrden) {
		super();
		this.archivoBean = archivoBean;
		this.codOrigen = codOrigen;
		this.codTipoDocumento = codTipoDocumento;
		this.desDocumento = desDocumento;
		this.desOrigen = desOrigen;
		this.desTipoDocumento = desTipoDocumento;
		this.fecEmision = fecEmision;
		this.fecEntrega = fecEntrega;
		this.fecNotificacion = fecNotificacion;
		this.fecPresentaVisita = fecPresentaVisita;
		this.fecProrroga = fecProrroga;
		this.numDocumento = numDocumento;
		this.numDocumentoOrden = numDocumentoOrden;
		this.numOrden = numOrden;
	}

	public ArchivoBean getArchivoBean() {
		return archivoBean;
	}

	public void setArchivoBean(ArchivoBean archivoBean) {
		this.archivoBean = archivoBean;
	}

	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}

	public String getCodTipoDocumento() {
		return codTipoDocumento;
	}

	public void setCodTipoDocumento(String codTipoDocumento) {
		this.codTipoDocumento = codTipoDocumento;
	}

	public String getDesDocumento() {
		return desDocumento;
	}

	public void setDesDocumento(String desDocumento) {
		this.desDocumento = desDocumento;
	}

	public String getDesOrigen() {
		return desOrigen;
	}

	public void setDesOrigen(String desOrigen) {
		this.desOrigen = desOrigen;
	}

	public String getDesTipoDocumento() {
		return desTipoDocumento;
	}

	public void setDesTipoDocumento(String desTipoDocumento) {
		this.desTipoDocumento = desTipoDocumento;
	}

	public String getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(String fecEmision) {
		this.fecEmision = fecEmision;
	}

	public String getFecEntrega() {
		return fecEntrega;
	}

	public void setFecEntrega(String fecEntrega) {
		this.fecEntrega = fecEntrega;
	}

	public String getFecNotificacion() {
		return fecNotificacion;
	}

	public void setFecNotificacion(String fecNotificacion) {
		this.fecNotificacion = fecNotificacion;
	}

	public String getFecPresentaVisita() {
		return fecPresentaVisita;
	}

	public void setFecPresentaVisita(String fecPresentaVisita) {
		this.fecPresentaVisita = fecPresentaVisita;
	}

	public String getFecProrroga() {
		return fecProrroga;
	}

	public void setFecProrroga(String fecProrroga) {
		this.fecProrroga = fecProrroga;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public Long getNumDocumentoOrden() {
		return numDocumentoOrden;
	}

	public void setNumDocumentoOrden(Long numDocumentoOrden) {
		this.numDocumentoOrden = numDocumentoOrden;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getNomArc() {
		return nomArc;
	}

	public void setNomArc(String nomArc) {
		this.nomArc = nomArc;
	}

	public Long getNumArc() {
		return numArc;
	}

	public void setNumArc(Long numArc) {
		this.numArc = numArc;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}
	
	
}
