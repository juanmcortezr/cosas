package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10446ARCDATAACF")
public class ArchivoDataAcciones extends Auditoria {

	 @Column(name = "ARC_CONTENIDO")
	 private byte[] archivoContenido;
	
	 @Id
	 @Column(name = "NUM_ARC")
	 private Long numArchAcciones;

	 
	 public ArchivoDataAcciones() {
		super();
	}

	public ArchivoDataAcciones(Long numArchAcciones, String dirIpusucrea, Date fecCrea, String codUsuCrea, String indDel, String indEst) {
		this.numArchAcciones = numArchAcciones;
		this.setDirIpusucrea(dirIpusucrea);
		this.setCodUsuCrea(codUsuCrea);
		this.setFecCrea(fecCrea);
		this.setIndDel(indDel);
		this.setIndEst(indEst);
	}

	public byte[] getArchivoContenido() {
		return archivoContenido;
	}

	public void setArchivoContenido(byte[] archivoContenido) {
		this.archivoContenido = archivoContenido;
	}

	public Long getNumArchAcciones() {
		return numArchAcciones;
	}

	public void setNumArchAcciones(Long numArchAcciones) {
		this.numArchAcciones = numArchAcciones;
	}
	
	 
}
