package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T8414MENSAJEIQBF")
public class MensajeIqbf implements Entidad{

	@Id
	 @Column(name = "COD_MENS")
	 private String codMensaje;
	
	 @Column(name = "COD_TIP_DOC")
	 private String codTipoDocumento;
	
	 @Column(name = "COD_TIPO_PROCESO")
	 private String codTipoProceso;
	
	 @Column(name = "DES_ABREV")
	 private String desAbreviatura;
	
	 @Column(name = "DES_CORTA")
	 private String desCorta;
	
	 @Column(name = "DES_CUERPO")
	 private String desCuerpo;
	
	 @Column(name = "DES_LARGA")
	 private String desLarga;
	
	 @Column(name = "IND_ASUNTO")
	 private String indAsunto;

	public String getCodMensaje() {
		return codMensaje;
	}

	public void setCodMensaje(String codMensaje) {
		this.codMensaje = codMensaje;
	}

	public String getCodTipoDocumento() {
		return codTipoDocumento;
	}

	public void setCodTipoDocumento(String codTipoDocumento) {
		this.codTipoDocumento = codTipoDocumento;
	}

	public String getCodTipoProceso() {
		return codTipoProceso;
	}

	public void setCodTipoProceso(String codTipoProceso) {
		this.codTipoProceso = codTipoProceso;
	}

	public String getDesAbreviatura() {
		return desAbreviatura;
	}

	public void setDesAbreviatura(String desAbreviatura) {
		this.desAbreviatura = desAbreviatura;
	}

	public String getDesCorta() {
		return desCorta;
	}

	public void setDesCorta(String desCorta) {
		this.desCorta = desCorta;
	}

	public String getDesCuerpo() {
		return desCuerpo;
	}

	public void setDesCuerpo(String desCuerpo) {
		this.desCuerpo = desCuerpo;
	}

	public String getDesLarga() {
		return desLarga;
	}

	public void setDesLarga(String desLarga) {
		this.desLarga = desLarga;
	}

	public String getIndAsunto() {
		return indAsunto;
	}

	public void setIndAsunto(String indAsunto) {
		this.indAsunto = indAsunto;
	}
		 
}
