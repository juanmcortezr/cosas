package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class ProgramaIncosistenciaStockBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private double cntIngEst;
	private double cntNetPres;
	private double cntNeteada;
	private double cantidadStockActual;
	private double cantidadUnidadFisica;
	private String codBienFiscalizado;
	private String codInsumo;
	private String codPresen;
	private String codTipprod;
	private String codUnidadMedida;
	private String codUnidadComercial;
	private String codUnidadFiscal;
	private String desNombreComercial;
	private String desNombreProducto;
	private String desBienfisca;
	private String desInsumo;
	private String desPresen;
	private String desTipoProducto;
	private String desUnidadMedida;
	private String desUnidadComercial;
	private String desUnidadFiscal;
	private int numEstablecimiento;
	private int numIncosistenciaStock;
	private int numInsumoCabecera;
	private String numOrden;
	private String numPeriodo;
	private int numPresentacion;
	private String numReposicion;
	private int numVersionEstablecimiento;
	private int numVersionInsumo;
	private int numVersionPressentacion;
	private int numProgramacion;
	private double porMaxInsumo;
	private double porMinInsumo;
	
	//PARA FILTROS
	private String codTipvia;
	
	private String desNomvia;
	
	private String numNumvia;
	
	private String numInter1;
	
	private String codTipzon;
	
	private String desNomzon;
	
	private String desRefer1;
	
	private String numManza;

	private String numLote;
	
	private String numKilom;
	
	private String numDepar;
	
	private Long numUsuarioPrograma;
	
	private String desUnidadFisica;
	
	public ProgramaIncosistenciaStockBean() {
		super();
	}

	public ProgramaIncosistenciaStockBean(double cntIngEst, double cntNetPres, double cntNeteada,
			double cantidadStockActual, double cantidadUnidadFisica, String codBienFiscalizado, String codInsumo,
			String codPresen, String codTipprod, String codUnidadMedida, String codUnidadComercial,
			String codUnidadFiscal, String desNombreComercial, String desNombreProducto, String desBienfisca,
			String desInsumo, String desPresen, String desTipoProducto, String desUnidadMedida,
			String desUnidadComercial, String desUnidadFiscal, int numEstablecimiento, int numIncosistenciaStock,
			int numInsumoCabecera, String numOrden, String numPeriodo, int numPresentacion, String numReposicion,
			int numVersionEstablecimiento, int numVersionInsumo, int numVersionPressentacion, int numProgramacion,
			double porMaxInsumo, double porMinInsumo, String codTipvia, String desNomvia, String numNumvia, String numInter1,
			String codTipzon, String desNomzon, String desRefer1, String numManza, String numLote, String numKilom, String numDepar,
			Long numUsuarioPrograma, String desUnidadFisica) {
		super();
		this.cntIngEst = cntIngEst;
		this.cntNetPres = cntNetPres;
		this.cntNeteada = cntNeteada;
		this.cantidadStockActual = cantidadStockActual;
		this.cantidadUnidadFisica = cantidadUnidadFisica;
		this.codBienFiscalizado = codBienFiscalizado;
		this.codInsumo = codInsumo;
		this.codPresen = codPresen;
		this.codTipprod = codTipprod;
		this.codUnidadMedida = codUnidadMedida;
		this.codUnidadComercial = codUnidadComercial;
		this.codUnidadFiscal = codUnidadFiscal;
		this.desNombreComercial = desNombreComercial;
		this.desNombreProducto = desNombreProducto;
		this.desBienfisca = desBienfisca;
		this.desInsumo = desInsumo;
		this.desPresen = desPresen;
		this.desTipoProducto = desTipoProducto;
		this.desUnidadMedida = desUnidadMedida;
		this.desUnidadComercial = desUnidadComercial;
		this.desUnidadFiscal = desUnidadFiscal;
		this.numEstablecimiento = numEstablecimiento;
		this.numIncosistenciaStock = numIncosistenciaStock;
		this.numInsumoCabecera = numInsumoCabecera;
		this.numOrden = numOrden;
		this.numPeriodo = numPeriodo;
		this.numPresentacion = numPresentacion;
		this.numReposicion = numReposicion;
		this.numVersionEstablecimiento = numVersionEstablecimiento;
		this.numVersionInsumo = numVersionInsumo;
		this.numVersionPressentacion = numVersionPressentacion;
		this.numProgramacion = numProgramacion;
		this.porMaxInsumo = porMaxInsumo;
		this.porMinInsumo = porMinInsumo;
		this.codTipvia = codTipvia;
		this.desNomvia= desNomvia;
		this.numNumvia = numNumvia;
		this.numInter1 = numInter1;
		this.codTipzon = codTipzon;
		this.desNomzon = desNomzon;
		this.desRefer1 = desRefer1;
		this.numManza = numManza;
		this.numLote = numLote;
		this.numKilom = numKilom;
		this.numDepar = numDepar;
		this.numUsuarioPrograma = numUsuarioPrograma;
		this.desUnidadFisica = desUnidadFisica;
	}

	public double getCntIngEst() {
		return cntIngEst;
	}

	public void setCntIngEst(double cntIngEst) {
		this.cntIngEst = cntIngEst;
	}

	public double getCntNetPres() {
		return cntNetPres;
	}

	public void setCntNetPres(double cntNetPres) {
		this.cntNetPres = cntNetPres;
	}

	public double getCntNeteada() {
		return cntNeteada;
	}

	public void setCntNeteada(double cntNeteada) {
		this.cntNeteada = cntNeteada;
	}

	public double getCantidadStockActual() {
		return cantidadStockActual;
	}

	public void setCantidadStockActual(double cantidadStockActual) {
		this.cantidadStockActual = cantidadStockActual;
	}

	public double getCantidadUnidadFisica() {
		return cantidadUnidadFisica;
	}

	public void setCantidadUnidadFisica(double cantidadUnidadFisica) {
		this.cantidadUnidadFisica = cantidadUnidadFisica;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodInsumo() {
		return codInsumo;
	}

	public void setCodInsumo(String codInsumo) {
		this.codInsumo = codInsumo;
	}

	public String getCodPresen() {
		return codPresen;
	}

	public void setCodPresen(String codPresen) {
		this.codPresen = codPresen;
	}

	public String getCodTipprod() {
		return codTipprod;
	}

	public void setCodTipprod(String codTipprod) {
		this.codTipprod = codTipprod;
	}

	public String getCodUnidadMedida() {
		return codUnidadMedida;
	}

	public void setCodUnidadMedida(String codUnidadMedida) {
		this.codUnidadMedida = codUnidadMedida;
	}

	public String getCodUnidadComercial() {
		return codUnidadComercial;
	}

	public void setCodUnidadComercial(String codUnidadComercial) {
		this.codUnidadComercial = codUnidadComercial;
	}

	public String getCodUnidadFiscal() {
		return codUnidadFiscal;
	}

	public void setCodUnidadFiscal(String codUnidadFiscal) {
		this.codUnidadFiscal = codUnidadFiscal;
	}

	public String getDesNombreComercial() {
		return desNombreComercial;
	}

	public void setDesNombreComercial(String desNombreComercial) {
		this.desNombreComercial = desNombreComercial;
	}

	public String getDesNombreProducto() {
		return desNombreProducto;
	}

	public void setDesNombreProducto(String desNombreProducto) {
		this.desNombreProducto = desNombreProducto;
	}

	public String getDesBienfisca() {
		return desBienfisca;
	}

	public void setDesBienfisca(String desBienfisca) {
		this.desBienfisca = desBienfisca;
	}

	public String getDesInsumo() {
		return desInsumo;
	}

	public void setDesInsumo(String desInsumo) {
		this.desInsumo = desInsumo;
	}

	public String getDesPresen() {
		return desPresen;
	}

	public void setDesPresen(String desPresen) {
		this.desPresen = desPresen;
	}

	public String getDesTipoProducto() {
		return desTipoProducto;
	}

	public void setDesTipoProducto(String desTipoProducto) {
		this.desTipoProducto = desTipoProducto;
	}

	public String getDesUnidadMedida() {
		return desUnidadMedida;
	}

	public void setDesUnidadMedida(String desUnidadMedida) {
		this.desUnidadMedida = desUnidadMedida;
	}

	public String getDesUnidadComercial() {
		return desUnidadComercial;
	}

	public void setDesUnidadComercial(String desUnidadComercial) {
		this.desUnidadComercial = desUnidadComercial;
	}

	public String getDesUnidadFiscal() {
		return desUnidadFiscal;
	}

	public void setDesUnidadFiscal(String desUnidadFiscal) {
		this.desUnidadFiscal = desUnidadFiscal;
	}

	public int getNumEstablecimiento() {
		return numEstablecimiento;
	}

	public void setNumEstablecimiento(int numEstablecimiento) {
		this.numEstablecimiento = numEstablecimiento;
	}

	public int getNumIncosistenciaStock() {
		return numIncosistenciaStock;
	}

	public void setNumIncosistenciaStock(int numIncosistenciaStock) {
		this.numIncosistenciaStock = numIncosistenciaStock;
	}

	public int getNumInsumoCabecera() {
		return numInsumoCabecera;
	}

	public void setNumInsumoCabecera(int numInsumoCabecera) {
		this.numInsumoCabecera = numInsumoCabecera;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public int getNumPresentacion() {
		return numPresentacion;
	}

	public void setNumPresentacion(int numPresentacion) {
		this.numPresentacion = numPresentacion;
	}

	public String getNumReposicion() {
		return numReposicion;
	}

	public void setNumReposicion(String numReposicion) {
		this.numReposicion = numReposicion;
	}

	public int getNumVersionEstablecimiento() {
		return numVersionEstablecimiento;
	}

	public void setNumVersionEstablecimiento(int numVersionEstablecimiento) {
		this.numVersionEstablecimiento = numVersionEstablecimiento;
	}

	public int getNumVersionInsumo() {
		return numVersionInsumo;
	}

	public void setNumVersionInsumo(int numVersionInsumo) {
		this.numVersionInsumo = numVersionInsumo;
	}

	public int getNumVersionPressentacion() {
		return numVersionPressentacion;
	}

	public void setNumVersionPressentacion(int numVersionPressentacion) {
		this.numVersionPressentacion = numVersionPressentacion;
	}

	public int getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(int numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public double getPorMaxInsumo() {
		return porMaxInsumo;
	}

	public void setPorMaxInsumo(double porMaxInsumo) {
		this.porMaxInsumo = porMaxInsumo;
	}

	public double getPorMinInsumo() {
		return porMinInsumo;
	}

	public void setPorMinInsumo(double porMinInsumo) {
		this.porMinInsumo = porMinInsumo;
	}

	public String getCodTipvia() {
		return codTipvia;
	}

	public void setCodTipvia(String codTipvia) {
		this.codTipvia = codTipvia;
	}

	public String getDesNomvia() {
		return desNomvia;
	}

	public void setDesNomvia(String desNomvia) {
		this.desNomvia = desNomvia;
	}

	public String getNumNumvia() {
		return numNumvia;
	}

	public void setNumNumvia(String numNumvia) {
		this.numNumvia = numNumvia;
	}

	public String getNumInter1() {
		return numInter1;
	}

	public void setNumInter1(String numInter1) {
		this.numInter1 = numInter1;
	}

	public String getCodTipzon() {
		return codTipzon;
	}

	public void setCodTipzon(String codTipzon) {
		this.codTipzon = codTipzon;
	}

	public String getDesNomzon() {
		return desNomzon;
	}

	public void setDesNomzon(String desNomzon) {
		this.desNomzon = desNomzon;
	}

	public String getDesRefer1() {
		return desRefer1;
	}

	public void setDesRefer1(String desRefer1) {
		this.desRefer1 = desRefer1;
	}

	public String getNumManza() {
		return numManza;
	}

	public void setNumManza(String numManza) {
		this.numManza = numManza;
	}

	public String getNumLote() {
		return numLote;
	}

	public void setNumLote(String numLote) {
		this.numLote = numLote;
	}

	public String getNumKilom() {
		return numKilom;
	}

	public void setNumKilom(String numKilom) {
		this.numKilom = numKilom;
	}

	public String getNumDepar() {
		return numDepar;
	}

	public void setNumDepar(String numDepar) {
		this.numDepar = numDepar;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public String getDesUnidadFisica() {
		return desUnidadFisica;
	}

	public void setDesUnidadFisica(String desUnidadFisica) {
		this.desUnidadFisica = desUnidadFisica;
	}
}
