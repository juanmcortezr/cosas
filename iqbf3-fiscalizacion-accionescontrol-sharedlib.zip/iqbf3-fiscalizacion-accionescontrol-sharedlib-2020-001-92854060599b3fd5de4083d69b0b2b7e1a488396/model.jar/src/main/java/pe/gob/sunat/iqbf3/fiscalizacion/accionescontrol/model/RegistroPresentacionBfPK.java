package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import pe.gob.sunat.iqbf3.registro.maestros.model.EntidadPK;

@Embeddable
public class RegistroPresentacionBfPK implements EntidadPK{

	 @Column(name = "NUM_RUC")
	 private String numRuc;
	 
	 @Column(name = "NUM_INSCAB")
	 private Integer numInsumoCabecera;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_BAJA")
	 private Date fecBaja;

	 @Column(name = "COD_TIPBIEN")
	 private String codTipoBien;

	 @Column(name = "NUM_VERREG")
	 private Integer numVersionRegistro;

	 @Column(name = "NUM_PRESENT")
	 private Integer numPresentacion;
	
	 @Column(name = "NUM_VERSION")
	 private Integer numVersion;

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public Integer getNumInsumoCabecera() {
		return numInsumoCabecera;
	}

	public void setNumInsumoCabecera(Integer numInsumoCabecera) {
		this.numInsumoCabecera = numInsumoCabecera;
	}

	public Date getFecBaja() {
		return fecBaja;
	}

	public void setFecBaja(Date fecBaja) {
		this.fecBaja = fecBaja;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public Integer getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(Integer numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public Integer getNumPresentacion() {
		return numPresentacion;
	}

	public void setNumPresentacion(Integer numPresentacion) {
		this.numPresentacion = numPresentacion;
	}

	public Integer getNumVersion() {
		return numVersion;
	}

	public void setNumVersion(Integer numVersion) {
		this.numVersion = numVersion;
	}

}
