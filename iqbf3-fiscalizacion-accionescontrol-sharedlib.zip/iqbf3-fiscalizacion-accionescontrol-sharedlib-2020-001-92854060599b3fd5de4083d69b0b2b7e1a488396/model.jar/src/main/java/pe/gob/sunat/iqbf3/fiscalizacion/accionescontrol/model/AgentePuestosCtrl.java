package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T10297AGENTECTROL")
public class AgentePuestosCtrl implements Entidad {

	
	 @Id
	 @Column(name = "NUM_REGPERS")
	 private String numRegistroPersonal;
	 
	 @Column(name = "COD_DEP")
	 private String codDep;
	
	 @Column(name = "COD_ESTADO")
	 private String codEstado;
	
	 @Column(name = "COD_PUESTO")
	 private String codPuesto;
	
	 @Column(name = "COD_ROL")
	 private String codRol;
	
	 @Column(name = "COD_UUOO")
	 private String codUnidadOrganica;
	
	 @Column(name = "DES_SUSTENTO")
	 private String desSustento;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_REG")
	 private Date fecRegistro;
	

	 @Column(name = "DIR_IPUSUCREA")
	 private String dirIpusucrea;
	
	 @Column(name = "DIR_IPUSUMODIF")
	 private String dirIpusumodif;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_CREA")
	 private Date fecCrea;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_MODIF")
	 private Date fecModif;
	
	 @Column(name = "COD_USUCREA")
	 private String codUsuCrea;

	 @Column(name = "COD_USUMODIF")
	 private String codUsuModif;
	 
	 @Column(name = "IND_DEL")
	 private String indDel;
	 //
	 
	 @Transient
	 private String codPers;
	 
	 @Transient
	 private String codAuditor;
	 
	 @Transient
	 private String indEst;
	  

	public String getCodAuditor() {
		return codAuditor;
	}

	public void setCodAuditor(String codAuditor) {
		this.codAuditor = codAuditor;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getCodDep() {
		return codDep;
	}

	public void setCodDep(String codDep) {
		this.codDep = codDep;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodPuesto() {
		return codPuesto;
	}

	public void setCodPuesto(String codPuesto) {
		this.codPuesto = codPuesto;
	}

	public String getCodRol() {
		return codRol;
	}

	public void setCodRol(String codRol) {
		this.codRol = codRol;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public String getDesSustento() {
		return desSustento;
	}

	public void setDesSustento(String desSustento) {
		this.desSustento = desSustento;
	}

	public Date getFecRegistro() {
		return fecRegistro;
	}

	public void setFecRegistro(Date fecRegistro) {
		this.fecRegistro = fecRegistro;
	}

	public String getNumRegistroPersonal() {
		return numRegistroPersonal;
	}

	public void setNumRegistroPersonal(String numRegistroPersonal) {
		this.numRegistroPersonal = numRegistroPersonal;
	}

	public String getDirIpusucrea() {
		return dirIpusucrea;
	}

	public void setDirIpusucrea(String dirIpusucrea) {
		this.dirIpusucrea = dirIpusucrea;
	}

	public String getDirIpusumodif() {
		return dirIpusumodif;
	}

	public void setDirIpusumodif(String dirIpusumodif) {
		this.dirIpusumodif = dirIpusumodif;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

	public Date getFecModif() {
		return fecModif;
	}

	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}

	public String getCodUsuCrea() {
		return codUsuCrea;
	}

	public void setCodUsuCrea(String codUsuCrea) {
		this.codUsuCrea = codUsuCrea;
	}

	public String getCodUsuModif() {
		return codUsuModif;
	}

	public void setCodUsuModif(String codUsuModif) {
		this.codUsuModif = codUsuModif;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	
	 
}
