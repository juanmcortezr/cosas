package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10418PROINCOSALDO")
public class ProgramaIncosistenciaSaldo extends Auditoria {

	 @Column(name = "CNT_AUTORIZADA")
	 private Double cantidadAutorizada;
	
	 @Column(name = "CNT_CONSUMIDA")
	 private Double cantidadConsumida;
	
	 @Column(name = "CNT_DISPONIBLE")
	 private Double cantidadDisponible;
	
	 @Column(name = "COD_BIENFISCA")
	 private String codBienFiscalizado;
	
	 @Column(name = "COD_INSUMO")
	 private String codInsumo;
	
	 @Column(name = "COD_TIPPROD")
	 private String codTipprod;
	
	 @Column(name = "COD_UM")
	 private String codUnidadMedida;
	
	 @Column(name = "DES_NOMCOMPROD")
	 private String desNombreComercial;
	
	 @Column(name = "DES_NOMPROD")
	 private String desNombreProducto;
	
	 @Id
	 @Column(name = "NUM_INCO_SALDO")
	 private Long numIncosistemciaSaldo;
	 
	 @Column(name = "NUM_USU_PROGRAM")
	 private Long numUsuarioPrograma;
	
	 @Column(name = "NUM_INSCAB")
	 private Integer numInsumoCabecera;
	
	 @Column(name = "NUM_ORDEN")
	 private String numOrden;
	
	 @Column(name = "NUM_PERIODO")
	 private String numPeriodo;
	
	 @Column(name = "NUM_REPOSICION")
	 private Integer numReposicion;
	
	 @Column(name = "NUM_VERSION_INSU")
	 private Integer numVersionInsumo;
	
	 @Column(name = "POR_MAX_INS")
	 private Double porMaxInsumo;
	
	 @Column(name = "POR_MIN_INS")
	 private Double porMinInsumo;

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public Double getCantidadAutorizada() {
		return cantidadAutorizada;
	}

	public void setCantidadAutorizada(Double cantidadAutorizada) {
		this.cantidadAutorizada = cantidadAutorizada;
	}

	public Double getCantidadConsumida() {
		return cantidadConsumida;
	}

	public void setCantidadConsumida(Double cantidadConsumida) {
		this.cantidadConsumida = cantidadConsumida;
	}

	public Double getCantidadDisponible() {
		return cantidadDisponible;
	}

	public void setCantidadDisponible(Double cantidadDisponible) {
		this.cantidadDisponible = cantidadDisponible;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodInsumo() {
		return codInsumo;
	}

	public void setCodInsumo(String codInsumo) {
		this.codInsumo = codInsumo;
	}

	public String getCodTipprod() {
		return codTipprod;
	}

	public void setCodTipprod(String codTipprod) {
		this.codTipprod = codTipprod;
	}

	public String getCodUnidadMedida() {
		return codUnidadMedida;
	}

	public void setCodUnidadMedida(String codUnidadMedida) {
		this.codUnidadMedida = codUnidadMedida;
	}

	public String getDesNombreComercial() {
		return desNombreComercial;
	}

	public void setDesNombreComercial(String desNombreComercial) {
		this.desNombreComercial = desNombreComercial;
	}

	public String getDesNombreProducto() {
		return desNombreProducto;
	}

	public void setDesNombreProducto(String desNombreProducto) {
		this.desNombreProducto = desNombreProducto;
	}

	public Long getNumIncosistemciaSaldo() {
		return numIncosistemciaSaldo;
	}

	public void setNumIncosistemciaSaldo(Long numIncosistemciaSaldo) {
		this.numIncosistemciaSaldo = numIncosistemciaSaldo;
	}

	public Integer getNumInsumoCabecera() {
		return numInsumoCabecera;
	}

	public void setNumInsumoCabecera(Integer numInsumoCabecera) {
		this.numInsumoCabecera = numInsumoCabecera;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public Integer getNumReposicion() {
		return numReposicion;
	}

	public void setNumReposicion(Integer numReposicion) {
		this.numReposicion = numReposicion;
	}

	public Integer getNumVersionInsumo() {
		return numVersionInsumo;
	}

	public void setNumVersionInsumo(Integer numVersionInsumo) {
		this.numVersionInsumo = numVersionInsumo;
	}

	public Double getPorMaxInsumo() {
		return porMaxInsumo;
	}

	public void setPorMaxInsumo(Double porMaxInsumo) {
		this.porMaxInsumo = porMaxInsumo;
	}

	public Double getPorMinInsumo() {
		return porMinInsumo;
	}

	public void setPorMinInsumo(Double porMinInsumo) {
		this.porMinInsumo = porMinInsumo;
	}
	
}
