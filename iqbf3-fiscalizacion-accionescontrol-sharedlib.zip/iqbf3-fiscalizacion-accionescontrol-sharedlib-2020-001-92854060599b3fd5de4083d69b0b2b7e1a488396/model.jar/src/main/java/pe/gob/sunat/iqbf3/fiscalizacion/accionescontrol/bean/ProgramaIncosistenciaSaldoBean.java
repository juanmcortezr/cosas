package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class ProgramaIncosistenciaSaldoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private double cantidadAutorizada;
	private double cantidadConsumida;
	private double cantidadDisponible;
	private String codBienFiscalizado;
	private String codInsumo;
	private String codTipprod;
	private String codUnidadMedida;
	private String desNombreComercial;
	private String desNombreProducto;
	private String desBienfisca;
	private String desInsumo;
	private String desTipoProducto;
	private String desUnidadMedida;
	private int numIncosistemciaSaldo;
	private int numInsumoCabecera;
	private String numOrden;
	private String numPeriodo;
	private int numReposicion;
	private int numVersionInsumo;
	private int numProgramacion;
	private double porMaxInsumo;
	private double porMinInsumo;

	public ProgramaIncosistenciaSaldoBean() {
		super();
	}

	public ProgramaIncosistenciaSaldoBean(double cantidadAutorizada, double cantidadConsumida,
			double cantidadDisponible, String codBienFiscalizado, String codInsumo, String codTipprod,
			String codUnidadMedida, String desNombreComercial, String desNombreProducto, String desBienfisca,
			String desInsumo, String desTipoProducto, String desUnidadMedida, int numIncosistemciaSaldo,
			int numInsumoCabecera, String numOrden, String numPeriodo, int numReposicion, int numVersionInsumo,
			int numProgramacion, double porMaxInsumo, double porMinInsumo) {
		super();
		this.cantidadAutorizada = cantidadAutorizada;
		this.cantidadConsumida = cantidadConsumida;
		this.cantidadDisponible = cantidadDisponible;
		this.codBienFiscalizado = codBienFiscalizado;
		this.codInsumo = codInsumo;
		this.codTipprod = codTipprod;
		this.codUnidadMedida = codUnidadMedida;
		this.desNombreComercial = desNombreComercial;
		this.desNombreProducto = desNombreProducto;
		this.desBienfisca = desBienfisca;
		this.desInsumo = desInsumo;
		this.desTipoProducto = desTipoProducto;
		this.desUnidadMedida = desUnidadMedida;
		this.numIncosistemciaSaldo = numIncosistemciaSaldo;
		this.numInsumoCabecera = numInsumoCabecera;
		this.numOrden = numOrden;
		this.numPeriodo = numPeriodo;
		this.numReposicion = numReposicion;
		this.numVersionInsumo = numVersionInsumo;
		this.numProgramacion = numProgramacion;
		this.porMaxInsumo = porMaxInsumo;
		this.porMinInsumo = porMinInsumo;
	}

	public double getCantidadAutorizada() {
		return cantidadAutorizada;
	}

	public void setCantidadAutorizada(double cantidadAutorizada) {
		this.cantidadAutorizada = cantidadAutorizada;
	}

	public double getCantidadConsumida() {
		return cantidadConsumida;
	}

	public void setCantidadConsumida(double cantidadConsumida) {
		this.cantidadConsumida = cantidadConsumida;
	}

	public double getCantidadDisponible() {
		return cantidadDisponible;
	}

	public void setCantidadDisponible(double cantidadDisponible) {
		this.cantidadDisponible = cantidadDisponible;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodInsumo() {
		return codInsumo;
	}

	public void setCodInsumo(String codInsumo) {
		this.codInsumo = codInsumo;
	}

	public String getCodTipprod() {
		return codTipprod;
	}

	public void setCodTipprod(String codTipprod) {
		this.codTipprod = codTipprod;
	}

	public String getCodUnidadMedida() {
		return codUnidadMedida;
	}

	public void setCodUnidadMedida(String codUnidadMedida) {
		this.codUnidadMedida = codUnidadMedida;
	}

	public String getDesNombreComercial() {
		return desNombreComercial;
	}

	public void setDesNombreComercial(String desNombreComercial) {
		this.desNombreComercial = desNombreComercial;
	}

	public String getDesNombreProducto() {
		return desNombreProducto;
	}

	public void setDesNombreProducto(String desNombreProducto) {
		this.desNombreProducto = desNombreProducto;
	}

	public String getDesBienfisca() {
		return desBienfisca;
	}

	public void setDesBienfisca(String desBienfisca) {
		this.desBienfisca = desBienfisca;
	}

	public String getDesInsumo() {
		return desInsumo;
	}

	public void setDesInsumo(String desInsumo) {
		this.desInsumo = desInsumo;
	}

	public String getDesTipoProducto() {
		return desTipoProducto;
	}

	public void setDesTipoProducto(String desTipoProducto) {
		this.desTipoProducto = desTipoProducto;
	}

	public String getDesUnidadMedida() {
		return desUnidadMedida;
	}

	public void setDesUnidadMedida(String desUnidadMedida) {
		this.desUnidadMedida = desUnidadMedida;
	}

	public int getNumIncosistemciaSaldo() {
		return numIncosistemciaSaldo;
	}

	public void setNumIncosistemciaSaldo(int numIncosistemciaSaldo) {
		this.numIncosistemciaSaldo = numIncosistemciaSaldo;
	}

	public int getNumInsumoCabecera() {
		return numInsumoCabecera;
	}

	public void setNumInsumoCabecera(int numInsumoCabecera) {
		this.numInsumoCabecera = numInsumoCabecera;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public int getNumReposicion() {
		return numReposicion;
	}

	public void setNumReposicion(int numReposicion) {
		this.numReposicion = numReposicion;
	}

	public int getNumVersionInsumo() {
		return numVersionInsumo;
	}

	public void setNumVersionInsumo(int numVersionInsumo) {
		this.numVersionInsumo = numVersionInsumo;
	}

	public int getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(int numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public double getPorMaxInsumo() {
		return porMaxInsumo;
	}

	public void setPorMaxInsumo(double porMaxInsumo) {
		this.porMaxInsumo = porMaxInsumo;
	}

	public double getPorMinInsumo() {
		return porMinInsumo;
	}

	public void setPorMinInsumo(double porMinInsumo) {
		this.porMinInsumo = porMinInsumo;
	}

}
