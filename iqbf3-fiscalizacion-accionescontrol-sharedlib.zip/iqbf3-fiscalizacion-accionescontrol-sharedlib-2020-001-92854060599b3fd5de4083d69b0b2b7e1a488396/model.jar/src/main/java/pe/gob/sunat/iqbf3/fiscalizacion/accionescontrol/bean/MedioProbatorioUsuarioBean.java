package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;

public class MedioProbatorioUsuarioBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	ArchivoBean	archivoBean;
	private	String	codTipoMedioProbatorio;
	private	String	desMedioProbatorio;
	private	Long	numMedioProbatorioUsuario;
	private	String	numMedioProbatorio;
	private	Long	numUsuarioSolicitud;
	
	public MedioProbatorioUsuarioBean() {
		super();
	}

	public MedioProbatorioUsuarioBean(ArchivoBean archivoBean, String codTipoMedioProbatorio, String desMedioProbatorio,
			Long numMedioProbatorioUsuario, String numMedioProbatorio, Long numUsuarioSolicitud) {
		super();
		this.archivoBean = archivoBean;
		this.codTipoMedioProbatorio = codTipoMedioProbatorio;
		this.desMedioProbatorio = desMedioProbatorio;
		this.numMedioProbatorioUsuario = numMedioProbatorioUsuario;
		this.numMedioProbatorio = numMedioProbatorio;
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public ArchivoBean getArchivoBean() {
		return archivoBean;
	}

	public void setArchivoBean(ArchivoBean archivoBean) {
		this.archivoBean = archivoBean;
	}

	public String getCodTipoMedioProbatorio() {
		return codTipoMedioProbatorio;
	}

	public void setCodTipoMedioProbatorio(String codTipoMedioProbatorio) {
		this.codTipoMedioProbatorio = codTipoMedioProbatorio;
	}

	public String getDesMedioProbatorio() {
		return desMedioProbatorio;
	}

	public void setDesMedioProbatorio(String desMedioProbatorio) {
		this.desMedioProbatorio = desMedioProbatorio;
	}

	public Long getNumMedioProbatorioUsuario() {
		return numMedioProbatorioUsuario;
	}

	public void setNumMedioProbatorioUsuario(Long numMedioProbatorioUsuario) {
		this.numMedioProbatorioUsuario = numMedioProbatorioUsuario;
	}

	public String getNumMedioProbatorio() {
		return numMedioProbatorio;
	}

	public void setNumMedioProbatorio(String numMedioProbatorio) {
		this.numMedioProbatorio = numMedioProbatorio;
	}

	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
