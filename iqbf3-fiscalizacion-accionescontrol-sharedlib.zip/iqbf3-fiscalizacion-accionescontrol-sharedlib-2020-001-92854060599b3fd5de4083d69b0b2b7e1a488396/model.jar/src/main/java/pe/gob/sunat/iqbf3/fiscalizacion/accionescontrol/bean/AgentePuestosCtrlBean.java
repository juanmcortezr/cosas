package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class AgentePuestosCtrlBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codDep;
	private	String	codEstado;
	private	String	codPuesto;
	private	String	codRol;
	private	String	codUnidadOrganica;
	private	String	desSustento;
	private	String	fecRegistro;
	private	String	numRegistroPersonal;
	private String	nomAuditor;
	
	public AgentePuestosCtrlBean() {
		super();
	}

	public AgentePuestosCtrlBean(String codDep, String codEstado, String codPuesto, String codRol,
			String codUnidadOrganica, String desSustento, String fecRegistro, String numRegistroPersonal,
			String nomAuditor) {
		super();
		this.codDep = codDep;
		this.codEstado = codEstado;
		this.codPuesto = codPuesto;
		this.codRol = codRol;
		this.codUnidadOrganica = codUnidadOrganica;
		this.desSustento = desSustento;
		this.fecRegistro = fecRegistro;
		this.numRegistroPersonal = numRegistroPersonal;
		this.nomAuditor = nomAuditor;
	}

	
	public String getNomAuditor() {
		return nomAuditor;
	}

	public void setNomAuditor(String nomAuditor) {
		this.nomAuditor = nomAuditor;
	}

	public String getCodDep() {
		return codDep;
	}

	public void setCodDep(String codDep) {
		this.codDep = codDep;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodPuesto() {
		return codPuesto;
	}

	public void setCodPuesto(String codPuesto) {
		this.codPuesto = codPuesto;
	}

	public String getCodRol() {
		return codRol;
	}

	public void setCodRol(String codRol) {
		this.codRol = codRol;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public String getDesSustento() {
		return desSustento;
	}

	public void setDesSustento(String desSustento) {
		this.desSustento = desSustento;
	}

	public String getFecRegistro() {
		return fecRegistro;
	}

	public void setFecRegistro(String fecRegistro) {
		this.fecRegistro = fecRegistro;
	}

	public String getNumRegistroPersonal() {
		return numRegistroPersonal;
	}

	public void setNumRegistroPersonal(String numRegistroPersonal) {
		this.numRegistroPersonal = numRegistroPersonal;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}	
}
