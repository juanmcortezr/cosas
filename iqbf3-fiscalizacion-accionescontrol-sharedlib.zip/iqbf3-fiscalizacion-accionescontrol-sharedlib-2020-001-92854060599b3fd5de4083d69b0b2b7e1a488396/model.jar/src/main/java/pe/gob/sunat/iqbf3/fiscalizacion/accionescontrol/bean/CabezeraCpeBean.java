package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.Date;

public class CabezeraCpeBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codCpe;
	private	String	codDocumenotRecepcion;
	private	int	codEstadoAnexo;
	private	String	codMoneda;
	private	String	codTipoCpe;
	private	String	desNombreRecepcion;
	private	String	desObservacion;
	private	String	fecEmision;
	private	String	indEstado;
	private	String	indProcedencia;
	private	String	indRechazo;
	private	double	mtoImporteTotal;
	private	double	mtoTotalIgv;
	private	double	mtoTotalVenta;
	private	int	numCpe;
	private	int	numCuoRegven;
	private	String	numDocumentoRecepcion;
	private	int	numIdXml;
	private	String	numPeriodoRegistroCompra;
	private	String	numPeriodoRegistroVenta;
	private	String	numRuc;
	private	String	numSerieCpe;
	
	private String codTipoConfirGre;
	private String codRelacionTransportistaRemitente;
	private Integer codTipoTrasladoPublico;//formaTraslado;
	private String codCPETransportista;
	private String codCPEGuiaRemision;
	private String codTipoDestinatario;
	private String codTipoDocumento;
	private Integer codTipoPersonaTransportista; //personaRelacionadaBfPK.tipoPersona;
	private String codTipoTransportista; //ConfirmacionGre.codTipo;
	private Date periodoInicio; //fecEmision;
	private Date periodoFin; //fecEmision;
	
		
	
	
	public String getCodTipoDocumento() {
		return codTipoDocumento;
	}

	public void setCodTipoDocumento(String codTipoDocumento) {
		this.codTipoDocumento = codTipoDocumento;
	}

	public String getCodTipoDestinatario() {
		return codTipoDestinatario;
	}

	public void setCodTipoDestinatario(String codTipoDestinatario) {
		this.codTipoDestinatario = codTipoDestinatario;
	}

	public Date getPeriodoInicio() {
		return periodoInicio;
	}

	public void setPeriodoInicio(Date periodoInicio) {
		this.periodoInicio = periodoInicio;
	}

	public Date getPeriodoFin() {
		return periodoFin;
	}

	public void setPeriodoFin(Date periodoFin) {
		this.periodoFin = periodoFin;
	}

	public Integer getCodTipoPersonaTransportista() {
		return codTipoPersonaTransportista;
	}

	public void setCodTipoPersonaTransportista(Integer codTipoPersonaTransportista) {
		this.codTipoPersonaTransportista = codTipoPersonaTransportista;
	}

	public String getCodTipoTransportista() {
		return codTipoTransportista;
	}

	public void setCodTipoTransportista(String codTipoTransportista) {
		this.codTipoTransportista = codTipoTransportista;
	}

	public String getCodCPETransportista() {
		return codCPETransportista;
	}

	public void setCodCPETransportista(String codCPETransportista) {
		this.codCPETransportista = codCPETransportista;
	}

	public String getCodCPEGuiaRemision() {
		return codCPEGuiaRemision;
	}

	public void setCodCPEGuiaRemision(String codCPEGuiaRemision) {
		this.codCPEGuiaRemision = codCPEGuiaRemision;
	}

	public Integer getCodTipoTrasladoPublico() {
		return codTipoTrasladoPublico;
	}

	public void setCodTipoTrasladoPublico(Integer codTipoTrasladoPublico) {
		this.codTipoTrasladoPublico = codTipoTrasladoPublico;
	}

	public String getCodRelacionTransportistaRemitente() {
		return codRelacionTransportistaRemitente;
	}

	public void setCodRelacionTransportistaRemitente(String codRelacionTransportistaRemitente) {
		this.codRelacionTransportistaRemitente = codRelacionTransportistaRemitente;
	}

	public String getCodTipoConfirGre() {
		return codTipoConfirGre;
	}

	public void setCodTipoConfirGre(String codTipoConfirGre) {
		this.codTipoConfirGre = codTipoConfirGre;
	}

	public CabezeraCpeBean() {
		super();
	}

	public CabezeraCpeBean(String codCpe, String codDocumenotRecepcion, int codEstadoAnexo, String codMoneda,
			String codTipoCpe, String desNombreRecepcion, String desObservacion, String fecEmision, String indEstado,
			String indProcedencia, String indRechazo, double mtoImporteTotal, double mtoTotalIgv, double mtoTotalVenta,
			int numCpe, int numCuoRegven, String numDocumentoRecepcion, int numIdXml, String numPeriodoRegistroCompra,
			String numPeriodoRegistroVenta, String numRuc, String numSerieCpe) {
		super();
		this.codCpe = codCpe;
		this.codDocumenotRecepcion = codDocumenotRecepcion;
		this.codEstadoAnexo = codEstadoAnexo;
		this.codMoneda = codMoneda;
		this.codTipoCpe = codTipoCpe;
		this.desNombreRecepcion = desNombreRecepcion;
		this.desObservacion = desObservacion;
		this.fecEmision = fecEmision;
		this.indEstado = indEstado;
		this.indProcedencia = indProcedencia;
		this.indRechazo = indRechazo;
		this.mtoImporteTotal = mtoImporteTotal;
		this.mtoTotalIgv = mtoTotalIgv;
		this.mtoTotalVenta = mtoTotalVenta;
		this.numCpe = numCpe;
		this.numCuoRegven = numCuoRegven;
		this.numDocumentoRecepcion = numDocumentoRecepcion;
		this.numIdXml = numIdXml;
		this.numPeriodoRegistroCompra = numPeriodoRegistroCompra;
		this.numPeriodoRegistroVenta = numPeriodoRegistroVenta;
		this.numRuc = numRuc;
		this.numSerieCpe = numSerieCpe;
	}

	public String getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}

	public String getCodDocumenotRecepcion() {
		return codDocumenotRecepcion;
	}

	public void setCodDocumenotRecepcion(String codDocumenotRecepcion) {
		this.codDocumenotRecepcion = codDocumenotRecepcion;
	}

	public int getCodEstadoAnexo() {
		return codEstadoAnexo;
	}

	public void setCodEstadoAnexo(int codEstadoAnexo) {
		this.codEstadoAnexo = codEstadoAnexo;
	}

	public String getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCodTipoCpe() {
		return codTipoCpe;
	}

	public void setCodTipoCpe(String codTipoCpe) {
		this.codTipoCpe = codTipoCpe;
	}

	public String getDesNombreRecepcion() {
		return desNombreRecepcion;
	}

	public void setDesNombreRecepcion(String desNombreRecepcion) {
		this.desNombreRecepcion = desNombreRecepcion;
	}

	public String getDesObservacion() {
		return desObservacion;
	}

	public void setDesObservacion(String desObservacion) {
		this.desObservacion = desObservacion;
	}

	public String getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(String fecEmision) {
		this.fecEmision = fecEmision;
	}

	public String getIndEstado() {
		return indEstado;
	}

	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}

	public String getIndProcedencia() {
		return indProcedencia;
	}

	public void setIndProcedencia(String indProcedencia) {
		this.indProcedencia = indProcedencia;
	}

	public String getIndRechazo() {
		return indRechazo;
	}

	public void setIndRechazo(String indRechazo) {
		this.indRechazo = indRechazo;
	}

	public double getMtoImporteTotal() {
		return mtoImporteTotal;
	}

	public void setMtoImporteTotal(double mtoImporteTotal) {
		this.mtoImporteTotal = mtoImporteTotal;
	}

	public double getMtoTotalIgv() {
		return mtoTotalIgv;
	}

	public void setMtoTotalIgv(double mtoTotalIgv) {
		this.mtoTotalIgv = mtoTotalIgv;
	}

	public double getMtoTotalVenta() {
		return mtoTotalVenta;
	}

	public void setMtoTotalVenta(double mtoTotalVenta) {
		this.mtoTotalVenta = mtoTotalVenta;
	}

	public int getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(int numCpe) {
		this.numCpe = numCpe;
	}

	public int getNumCuoRegven() {
		return numCuoRegven;
	}

	public void setNumCuoRegven(int numCuoRegven) {
		this.numCuoRegven = numCuoRegven;
	}

	public String getNumDocumentoRecepcion() {
		return numDocumentoRecepcion;
	}

	public void setNumDocumentoRecepcion(String numDocumentoRecepcion) {
		this.numDocumentoRecepcion = numDocumentoRecepcion;
	}

	public int getNumIdXml() {
		return numIdXml;
	}

	public void setNumIdXml(int numIdXml) {
		this.numIdXml = numIdXml;
	}

	public String getNumPeriodoRegistroCompra() {
		return numPeriodoRegistroCompra;
	}

	public void setNumPeriodoRegistroCompra(String numPeriodoRegistroCompra) {
		this.numPeriodoRegistroCompra = numPeriodoRegistroCompra;
	}

	public String getNumPeriodoRegistroVenta() {
		return numPeriodoRegistroVenta;
	}

	public void setNumPeriodoRegistroVenta(String numPeriodoRegistroVenta) {
		this.numPeriodoRegistroVenta = numPeriodoRegistroVenta;
	}

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public String getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
