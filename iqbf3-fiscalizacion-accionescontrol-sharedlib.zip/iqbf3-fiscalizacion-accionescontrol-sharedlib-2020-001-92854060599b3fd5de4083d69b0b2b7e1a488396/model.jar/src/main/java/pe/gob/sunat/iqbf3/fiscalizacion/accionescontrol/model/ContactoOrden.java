package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "T10401CONTACTORDEN")
public class ContactoOrden extends Auditoria {

	 @Column(name = "COD_TIP_DOCIDENT")
	 private String codTipoDocumentoIdentif;
	
	 @Column(name = "DES_CARGO")
	 private String desCargo;
	
	 @Column(name = "NOM_APE_CONT")
	 private String nomApellidoContacto;
	
	 @Id
	 @Column(name = "NUM_CONTACTO")
	 private Long numContacto;
	
	 @Column(name = "NUM_ORDEN")
	 private Long numOrden;
	
	 @Column(name = "NUM_DOC_IDENT")
	 private String numDocumentoIdentif;
	
	 @Column(name = "NUM_TELEFONO")
	 private String numTelefono;
	 
	 
	 @Transient
	 private boolean indEliminar;
	 
	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getDesCargo() {
		return desCargo;
	}

	public void setDesCargo(String desCargo) {
		this.desCargo = desCargo;
	}

	public String getNomApellidoContacto() {
		return nomApellidoContacto;
	}

	public void setNomApellidoContacto(String nomApellidoContacto) {
		this.nomApellidoContacto = nomApellidoContacto;
	}

	public Long getNumContacto() {
		return numContacto;
	}

	public void setNumContacto(Long numContacto) {
		this.numContacto = numContacto;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public String getNumTelefono() {
		return numTelefono;
	}

	public void setNumTelefono(String numTelefono) {
		this.numTelefono = numTelefono;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}

	public boolean isIndEliminar() {
		return indEliminar;
	}

	public void setIndEliminar(boolean indEliminar) {
		this.indEliminar = indEliminar;
	}
	
	
}
