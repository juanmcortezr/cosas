package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10445ARCACF")
public class ArchivoAcciones extends Auditoria {

	 @Column(name = "NOM_ARC")
	 private String nombArchivoAcciones;
	
	 @Column(name = "CNT_PESO_ARC")
	 private Double cntPesoArc;
	
	 @Column(name = "COD_TIP_ARC")
	 private String codTipoArchivo;
	
	 @Column(name = "DES_MIME_TYPE")
	 private String desMimeType;
	
	 @Column(name = "NUM_ECM")
	 private String numEcm;
	
	 @Id
	 @Column(name = "NUM_ARC")
	 private Long numArc;
	 	 

	public String getNombArchivoAcciones() {
		return nombArchivoAcciones;
	}

	public void setNombArchivoAcciones(String nombArchivoAcciones) {
		this.nombArchivoAcciones = nombArchivoAcciones;
	}

	public Double getCntPesoArc() {
		return cntPesoArc;
	}

	public void setCntPesoArc(Double cntPesoArc) {
		this.cntPesoArc = cntPesoArc;
	}

	public String getCodTipoArchivo() {
		return codTipoArchivo;
	}

	public void setCodTipoArchivo(String codTipoArchivo) {
		this.codTipoArchivo = codTipoArchivo;
	}

	public String getDesMimeType() {
		return desMimeType;
	}

	public void setDesMimeType(String desMimeType) {
		this.desMimeType = desMimeType;
	}

	public String getNumEcm() {
		return numEcm;
	}

	public void setNumEcm(String numEcm) {
		this.numEcm = numEcm;
	}

	public Long getNumArc() {
		return numArc;
	}

	public void setNumArc(Long numArc) {
		this.numArc = numArc;
	}
	
}
