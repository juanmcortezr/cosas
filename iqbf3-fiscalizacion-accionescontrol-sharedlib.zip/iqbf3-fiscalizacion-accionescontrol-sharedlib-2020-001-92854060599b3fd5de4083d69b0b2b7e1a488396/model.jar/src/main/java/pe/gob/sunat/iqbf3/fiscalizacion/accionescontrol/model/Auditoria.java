package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@MappedSuperclass
public class Auditoria implements Entidad {

	 @Column(name = "DIR_IPUSUCREA")
	 private String dirIpusucrea;
	
	 @Column(name = "DIR_IPUSUMODIF")
	 private String dirIpusumodif;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_CREA")
	 private Date fecCrea;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_MODIF")
	 private Date fecModif;
	
	 @Column(name = "COD_USUCREA")
	 private String codUsuCrea;

	 @Column(name = "COD_USUMODIF")
	 private String codUsuModif;
	 
	 @Column(name = "IND_DEL")
	 private String indDel;
	
	 @Column(name = "IND_EST")
	 private String indEst;
	 
	public String getCodUsuCrea() {
		return codUsuCrea;
	}

	public void setCodUsuCrea(String codUsuCrea) {
		this.codUsuCrea = codUsuCrea;
	}

	public String getCodUsuModif() {
		return codUsuModif;
	}

	public void setCodUsuModif(String codUsuModif) {
		this.codUsuModif = codUsuModif;
	}

	public String getDirIpusucrea() {
		return dirIpusucrea;
	}

	public void setDirIpusucrea(String dirIpusucrea) {
		this.dirIpusucrea = dirIpusucrea;
	}

	public String getDirIpusumodif() {
		return dirIpusumodif;
	}

	public void setDirIpusumodif(String dirIpusumodif) {
		this.dirIpusumodif = dirIpusumodif;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

	public Date getFecModif() {
		return fecModif;
	}

	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

}
