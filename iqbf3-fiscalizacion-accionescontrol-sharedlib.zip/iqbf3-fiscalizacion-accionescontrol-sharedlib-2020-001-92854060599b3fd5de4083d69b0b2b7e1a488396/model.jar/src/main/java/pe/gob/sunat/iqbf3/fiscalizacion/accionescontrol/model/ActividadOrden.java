package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10387ACTIVIDORDEN")
public class ActividadOrden extends Auditoria {

	 @Id
	 @Column(name = "NUM_ACTIV_RESUL")
	 private Long numActividadResultado;

	 @Column(name = "num_orden")
	 private Integer numOrden;

	 @Column(name = "COD_ACTIVIDAD")
	 private String codActividad;
	
	public Integer getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Integer numOrden) {
		this.numOrden = numOrden;
	}

	public String getCodActividad() {
		return codActividad;
	}

	public void setCodActividad(String codActividad) {
		this.codActividad = codActividad;
	}

	public Long getNumActividadResultado() {
		return numActividadResultado;
	}

	public void setNumActividadResultado(Long numActividadResultado) {
		this.numActividadResultado = numActividadResultado;
	}
	

	 
}
