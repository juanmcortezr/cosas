package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10409ESTABUSU")
public class EstablecimientoUsuario extends Auditoria {

	 @Column(name = "COD_DEPARTAMENTO")
	 private String codDepartamento;
	
	 @Column(name = "COD_DISTRITO")
	 private String codDistrito;
	
	 @Column(name = "COD_PROVINCIA")
	 private String codProvincia;
	
	 @Column(name = "DES_DIR_ESTAB")
	 private String desDireccionEstablecimiento;
	
	 @Column(name = "IND_OTRO_ESTAB")
	 private String indOtroEstab;
	
	 @Column(name = "NUM_ESTAB")
	 private Integer numEstablecimiento;
	
	 @Id
	 @Column(name = "NUM_ESTAB_USU")
	 private Long numEstablecimientoUsuario;

	 @Column(name = "NUM_USU_SOLIC")
	 private Long numUsuarioSolicitud;

	public String getCodDepartamento() {
		return codDepartamento;
	}

	public void setCodDepartamento(String codDepartamento) {
		this.codDepartamento = codDepartamento;
	}

	public String getCodDistrito() {
		return codDistrito;
	}

	public void setCodDistrito(String codDistrito) {
		this.codDistrito = codDistrito;
	}

	public String getCodProvincia() {
		return codProvincia;
	}

	public void setCodProvincia(String codProvincia) {
		this.codProvincia = codProvincia;
	}

	public String getDesDireccionEstablecimiento() {
		return desDireccionEstablecimiento;
	}

	public void setDesDireccionEstablecimiento(String desDireccionEstablecimiento) {
		this.desDireccionEstablecimiento = desDireccionEstablecimiento;
	}

	public String getIndOtroEstab() {
		return indOtroEstab;
	}

	public void setIndOtroEstab(String indOtroEstab) {
		this.indOtroEstab = indOtroEstab;
	}

	public Integer getNumEstablecimiento() {
		return numEstablecimiento;
	}

	public void setNumEstablecimiento(Integer numEstablecimiento) {
		this.numEstablecimiento = numEstablecimiento;
	}

	public Long getNumEstablecimientoUsuario() {
		return numEstablecimientoUsuario;
	}

	public void setNumEstablecimientoUsuario(Long numEstablecimientoUsuario) {
		this.numEstablecimientoUsuario = numEstablecimientoUsuario;
	}

	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

}
