package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class CriterioCalificacionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	desCriterio;
	private	Long	numCriterio;
	private	double	porPeso;
	private String indEstado;
	private List<AlternativaCriterioBean> alternativasCriterios;
	private AuditoriaBean auditoriaBean;

	
	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public CriterioCalificacionBean() {
		super();
	}

	public CriterioCalificacionBean(String desCriterio, Long numCriterio, double porPeso, String indEstado) {
		super();
		this.desCriterio = desCriterio;
		this.numCriterio = numCriterio;
		this.porPeso = porPeso;
		this.indEstado = indEstado;
	}

	public String getDesCriterio() {
		return desCriterio;
	}

	public void setDesCriterio(String desCriterio) {
		this.desCriterio = desCriterio;
	}

	public Long getNumCriterio() {
		return numCriterio;
	}

	public void setNumCriterio(Long numCriterio) {
		this.numCriterio = numCriterio;
	}

	public double getPorPeso() {
		return porPeso;
	}

	public void setPorPeso(double porPeso) {
		this.porPeso = porPeso;
	}

	public String getIndEstado() {
		return indEstado;
	}

	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}

	public List<AlternativaCriterioBean> getAlternativasCriterios() {
		return alternativasCriterios;
	}

	public void setAlternativasCriterios(List<AlternativaCriterioBean> alternativasCriterios) {
		this.alternativasCriterios = alternativasCriterios;
	}

}
