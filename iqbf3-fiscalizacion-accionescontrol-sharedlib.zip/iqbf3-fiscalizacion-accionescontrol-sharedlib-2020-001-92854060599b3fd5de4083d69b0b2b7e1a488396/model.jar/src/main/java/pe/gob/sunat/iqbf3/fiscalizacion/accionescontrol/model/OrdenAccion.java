package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


@Entity
@Table(name = "T10415ORDENACCION")
public class OrdenAccion extends Auditoria {

	
	 @Column(name = "ANN_ORDEN")
	 private Integer anioOrden;
	
	 @Column(name = "COD_EST_ORDEN")
	 private String codEstadoOrden;
	
	 @Column(name = "COD_RECOMENDACION")
	 private String codRecomendacion;
	
	 @Column(name = "COD_RESUL_INCONDEF")
	 private String codResultadoInconsistenciaDef;
	
	 @Column(name = "COD_RESUL_INCONSIS")
	 private String codResultadoInconsistenciaPre;
	
	 @Column(name = "COD_RESUL_ORDEN")
	 private String codResulOrden;
	
	 @Column(name = "COD_TIP_ORDEN")
	 private String codTipoOrden;
	
	 @Column(name = "COD_UUOO_ORDEN")
	 private String codUnidadOrganica;
	
	 @Column(name = "DES_RECOMENDACION")
	 private String desRecomendacion;
	
	 @Column(name = "DES_SUS_CANCELA")
	 private String desSusCancela;
	
	 @Column(name = "DES_SUS_DEVOLUCION")
	 private String desSusDevolucion;
	
	 @Column(name = "DES_SUS_NOACCION")
	 private String desSusNoaccion;
	
	 @Column(name = "DES_SUS_RESUL")
	 private String desSusResul;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_ASIG_ORDEN")
	 private Date fecAsigOrden;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_CANCELACION")
	 private Date fecCancelacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_DERIVACION")
	 private Date fecDerivacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_CASO")
	 private Date fecInicioCaso;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_CASONUE")
	 private Date fecInicioCasoNuevo;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_ORDEN")
	 private Date fecOrden;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_PRIMERA_VISIT")
	 private Date fecPrimeraVisit;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_SEGUNDA_VISIT")
	 private Date fecSegundaVisit;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_SOLIC_PRORROGA")
	 private Date fecSolicProrroga;
	
	 @Column(name = "IND_BLOQ_DJRO")
	 private String indBloqDjro;
	
	 @Column(name = "IND_PRIMERA_VISIT")
	 private String indPrimeraVisit;
	
	 @Column(name = "IND_REALIZO_ACCION")
	 private String indRealizoAccion;
	
	 @Column(name = "IND_SEGUNDA_VISIT")
	 private String indSegundaVisit;
	
	 @Column(name = "IND_SOLIC_PRORROGA")
	 private String indSolicProrroga;
	
	 @Column(name = "NUM_CORREL_ORDEN")
	 private Integer numCorrel;
	
	 @Id
	 @Column(name = "NUM_ORDEN")
	 private Long numOrden;
	
	 @Column(name = "OBS_RESULTADO")
	 private String obsResultado;

	 @Column(name = "NUM_USU_PROGRAM")
	 private Long numUsuarioPrograma;
	 
	 @Column(name = "NUM_ARC")
	 private Long numArc;
	 
	 @Transient
	 private String codPers;
	 @Transient
	 private String numDocIdent;
	 @Transient
	 private String codTipDocIdent;
	 @Transient
	 private List<String> estados;
	 
	 @Transient
	 private String codEstadoRegistro;//cod_est_reg
	 @Transient
	 private String codProgctrl; //cod_progctrl
	 @Transient
	 private String codTipoDocumentoIdentif;//COD_TIP_DOCIDENT
	 @Transient
	 private String numDocumentoIdentif;//num_doc_ident
	
	 @Transient
	 private Integer numVersionRegistro;//num_verreg
	 
	 @Transient
	 private Long numDocumentoAccion;//num_doc_accion
	 
	 @Transient
	 private Date fecNotificacion;//FEC_NOTIFICACION
	 
	 @Transient
	 private Date fecFinSubsanacion;//fec_fin_subsanacio
	 
	 // Para filtro
	 
	 @Transient
	 private Long numProgramacion;

	 @Transient
	 private String nomApelAuditor;
	 
	 @Transient
	 private Date fecAsigIni; 
	 
	 @Transient
	 private Date fecAsigFin; 
	 
	 @Transient
	 private String numInforSelec;
	 
	 @Transient
	 private String numInforResul;
	 
	 @Transient
	 private String  codOrigen;
	 
	 @Transient
	 private String numDocAccion;
	 
	 @Transient
	 private String codProgCtrl;

	 @Transient
	 private String desProgCtrl;
	 
	 @Transient
	 private String numProgCorrel;
	 
	 @Transient
	 private String numInfSelecc;

	 @Transient
	 private String noSubSano;

	 @Transient
	 private String parcialmente;

	 @Transient
	 private String codEstOrden;
	 
	 // PARA FILTRO DE BUSQUEDA	 
	 @Transient
	 private String nomApellidoUsuario;
	 
	 @Transient
	 private Integer numProgramaCorrel;
	 	 
	 @Transient
	 private Integer anioInforme;
	 
	 @Transient
	 private String codTipoAccion;
	 
	 @Transient
	 private String numDocumento;
	 
	 @Transient
	 private String numDoc;
	 
	 // FILTROS PARA OBTENER DATOS ORDEN
	 @Transient
	 private Integer numCorrelDoc;
	 
	 @Transient
	 private Integer annDoc;
	 
	 @Transient
	 private String codUuooDoc;
	 
	 @Transient
	 private String codClase;
	 
	 @Transient
	 private String codUnidadOrganicaInforme;
	 
	 //FILTRO PARA DETALLE INCONSISTENCIAS
	 @Transient
	 private String codEstadoUsuario;
	 
	 @Transient
	 private String perInicio;
	 
	 @Transient
	 private String perFin;

	 @Transient
	 private String numPeridoOmisoMin;//num_peridoomisomin
	 @Transient
	 private String numPeridoOmisoMax;//num_peridoomisomax
	 @Transient
	 private String codTipInconsis;//cod_tip_inconsis
	 @Transient
	 private String nomApeUsuario;
	 @Transient
	 private String desDenominacion;
	 @Transient
	 private Long informeNumCorrel;
	 @Transient
	 private Integer informeAnio;
	 @Transient
	 private String informeCodUUOO;
	 @Transient
	 private String codTipAccion;
	 @Transient
	 private String numDocumentoOrden;
	 @Transient
	 private String codCargo;
	 @Transient
	 private String numOrdenUnion;
	 
	 @Transient
	 private Date fecPrimeraVisita;
	 
	 @Transient
	 private String numInformeUnion;
	 
	 public String getNumInformeUnion() {
		return numInformeUnion;
	}

	public void setNumInformeUnion(String numInformeUnion) {
		this.numInformeUnion = numInformeUnion;
	}

	public String getNumOrdenUnion() {
		return numOrdenUnion;
	}

	public void setNumOrdenUnion(String numOrdenUnion) {
		this.numOrdenUnion = numOrdenUnion;
	}

	public String getCodCargo() {
		return codCargo;
	}

	public void setCodCargo(String codCargo) {
		this.codCargo = codCargo;
	}

	public Long getNumDocumentoAccion() {
		return numDocumentoAccion;
	}

	public void setNumDocumentoAccion(Long numDocumentoAccion) {
		this.numDocumentoAccion = numDocumentoAccion;
	}

	public Date getFecNotificacion() {
		return fecNotificacion;
	}

	public void setFecNotificacion(Date fecNotificacion) {
		this.fecNotificacion = fecNotificacion;
	}

	public Date getFecFinSubsanacion() {
		return fecFinSubsanacion;
	}

	public void setFecFinSubsanacion(Date fecFinSubsanacion) {
		this.fecFinSubsanacion = fecFinSubsanacion;
	}

	public Integer getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(Integer numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public String getCodTipInconsis() {
		return codTipInconsis;
	}

	public void setCodTipInconsis(String codTipInconsis) {
		this.codTipInconsis = codTipInconsis;
	}

	public String getNumPeridoOmisoMin() {
		return numPeridoOmisoMin;
	}

	public void setNumPeridoOmisoMin(String numPeridoOmisoMin) {
		this.numPeridoOmisoMin = numPeridoOmisoMin;
	}

	public String getNumPeridoOmisoMax() {
		return numPeridoOmisoMax;
	}

	public void setNumPeridoOmisoMax(String numPeridoOmisoMax) {
		this.numPeridoOmisoMax = numPeridoOmisoMax;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public String getCodEstadoRegistro() {
		return codEstadoRegistro;
	}

	public void setCodEstadoRegistro(String codEstadoRegistro) {
		this.codEstadoRegistro = codEstadoRegistro;
	}

	public String getCodProgctrl() {
		return codProgctrl;
	}

	public void setCodProgctrl(String codProgctrl) {
		this.codProgctrl = codProgctrl;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public String getNumProgCorrel() {
		return numProgCorrel;
	}

	public void setNumProgCorrel(String numProgCorrel) {
		this.numProgCorrel = numProgCorrel;
	}

	public String getNumInfSelecc() {
		return numInfSelecc;
	}

	public void setNumInfSelecc(String numInfSelecc) {
		this.numInfSelecc = numInfSelecc;
	}

	public String getNoSubSano() {
		return noSubSano;
	}

	public void setNoSubSano(String noSubSano) {
		this.noSubSano = noSubSano;
	}

	public String getParcialmente() {
		return parcialmente;
	}

	public void setParcialmente(String parcialmente) {
		this.parcialmente = parcialmente;
	}

	public String getCodEstOrden() {
		return codEstOrden;
	}

	public void setCodEstOrden(String codEstOrden) {
		this.codEstOrden = codEstOrden;
	}

	public Long getNumArc() {
		return numArc;
	}

	public void setNumArc(Long numArc) {
		this.numArc = numArc;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public Integer getAnioOrden() {
		return anioOrden;
	}

	public void setAnioOrden(Integer anioOrden) {
		this.anioOrden = anioOrden;
	}

	public String getCodEstadoOrden() {
		return codEstadoOrden;
	}

	public void setCodEstadoOrden(String codEstadoOrden) {
		this.codEstadoOrden = codEstadoOrden;
	}

	public String getCodRecomendacion() {
		return codRecomendacion;
	}

	public void setCodRecomendacion(String codRecomendacion) {
		this.codRecomendacion = codRecomendacion;
	}

	public String getCodResultadoInconsistenciaDef() {
		return codResultadoInconsistenciaDef;
	}

	public void setCodResultadoInconsistenciaDef(String codResultadoInconsistenciaDef) {
		this.codResultadoInconsistenciaDef = codResultadoInconsistenciaDef;
	}

	public String getCodResultadoInconsistenciaPre() {
		return codResultadoInconsistenciaPre;
	}

	public void setCodResultadoInconsistenciaPre(String codResultadoInconsistenciaPre) {
		this.codResultadoInconsistenciaPre = codResultadoInconsistenciaPre;
	}

	public String getCodResulOrden() {
		return codResulOrden;
	}

	public void setCodResulOrden(String codResulOrden) {
		this.codResulOrden = codResulOrden;
	}

	public String getCodTipoOrden() {
		return codTipoOrden;
	}

	public void setCodTipoOrden(String codTipoOrden) {
		this.codTipoOrden = codTipoOrden;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public String getDesRecomendacion() {
		return desRecomendacion;
	}

	public void setDesRecomendacion(String desRecomendacion) {
		this.desRecomendacion = desRecomendacion;
	}

	public String getDesSusCancela() {
		return desSusCancela;
	}

	public void setDesSusCancela(String desSusCancela) {
		this.desSusCancela = desSusCancela;
	}

	public String getDesSusDevolucion() {
		return desSusDevolucion;
	}

	public void setDesSusDevolucion(String desSusDevolucion) {
		this.desSusDevolucion = desSusDevolucion;
	}

	public String getDesSusNoaccion() {
		return desSusNoaccion;
	}

	public void setDesSusNoaccion(String desSusNoaccion) {
		this.desSusNoaccion = desSusNoaccion;
	}

	public String getDesSusResul() {
		return desSusResul;
	}

	public void setDesSusResul(String desSusResul) {
		this.desSusResul = desSusResul;
	}

	public Date getFecAsigOrden() {
		return fecAsigOrden;
	}

	public void setFecAsigOrden(Date fecAsigOrden) {
		this.fecAsigOrden = fecAsigOrden;
	}

	public Date getFecCancelacion() {
		return fecCancelacion;
	}

	public void setFecCancelacion(Date fecCancelacion) {
		this.fecCancelacion = fecCancelacion;
	}

	public Date getFecDerivacion() {
		return fecDerivacion;
	}

	public void setFecDerivacion(Date fecDerivacion) {
		this.fecDerivacion = fecDerivacion;
	}

	public Date getFecInicioCaso() {
		return fecInicioCaso;
	}

	public void setFecInicioCaso(Date fecInicioCaso) {
		this.fecInicioCaso = fecInicioCaso;
	}

	public Date getFecInicioCasoNuevo() {
		return fecInicioCasoNuevo;
	}

	public void setFecInicioCasoNuevo(Date fecInicioCasoNuevo) {
		this.fecInicioCasoNuevo = fecInicioCasoNuevo;
	}

	public Date getFecOrden() {
		return fecOrden;
	}

	public void setFecOrden(Date fecOrden) {
		this.fecOrden = fecOrden;
	}

	public Date getFecPrimeraVisit() {
		return fecPrimeraVisit;
	}

	public void setFecPrimeraVisiat(Date fecPrimeraVisiat) {
		this.fecPrimeraVisit = fecPrimeraVisiat;
	}

	public Date getFecSegundaVisit() {
		return fecSegundaVisit;
	}

	public void setFecSegundaVisit(Date fecSegundaVisit) {
		this.fecSegundaVisit = fecSegundaVisit;
	}

	public Date getFecSolicProrroga() {
		return fecSolicProrroga;
	}

	public void setFecSolicProrroga(Date fecSolicProrroga) {
		this.fecSolicProrroga = fecSolicProrroga;
	}

	public String getIndBloqDjro() {
		return indBloqDjro;
	}

	public void setIndBloqDjro(String indBloqDjro) {
		this.indBloqDjro = indBloqDjro;
	}

	public String getIndPrimeraVisit() {
		return indPrimeraVisit;
	}

	public void setIndPrimeraVisit(String indPrimeraVisit) {
		this.indPrimeraVisit = indPrimeraVisit;
	}

	public String getIndRealizoAccion() {
		return indRealizoAccion;
	}

	public void setIndRealizoAccion(String indRealizoAccion) {
		this.indRealizoAccion = indRealizoAccion;
	}

	public String getIndSegundaVisit() {
		return indSegundaVisit;
	}

	public void setIndSegundaVisit(String indSegundaVisit) {
		this.indSegundaVisit = indSegundaVisit;
	}

	public String getIndSolicProrroga() {
		return indSolicProrroga;
	}

	public void setIndSolicProrroga(String indSolicProrroga) {
		this.indSolicProrroga = indSolicProrroga;
	}

	public Integer getNumCorrel() {
		return numCorrel;
	}

	public void setNumCorrel(Integer numCorrel) {
		this.numCorrel = numCorrel;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}

	public String getObsResultado() {
		return obsResultado;
	}

	public void setObsResultado(String obsResultado) {
		this.obsResultado = obsResultado;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getNumDocIdent() {
		return numDocIdent;
	}

	public void setNumDocIdent(String numDocIdent) {
		this.numDocIdent = numDocIdent;
	}

	public String getCodTipDocIdent() {
		return codTipDocIdent;
	}

	public void setCodTipDocIdent(String codTipDocIdent) {
		this.codTipDocIdent = codTipDocIdent;
	}

	public List<String> getEstados() {
		return estados;
	}

	public void setEstados(List<String> estados) {
		this.estados = estados;
	}
	
	public String getNomApelAuditor() {
		return nomApelAuditor;
	}

	public void setNomApelAuditor(String nomApelAuditor) {
		this.nomApelAuditor = nomApelAuditor;
	}

	public Date getFecAsigIni() {
		return fecAsigIni;
	}

	public void setFecAsigIni(Date fecAsigIni) {
		this.fecAsigIni = fecAsigIni;
	}

	public Date getFecAsigFin() {
		return fecAsigFin;
	}

	public void setFecAsigFin(Date fecAsigFin) {
		this.fecAsigFin = fecAsigFin;
	}

	public String getNumInforSelec() {
		return numInforSelec;
	}

	public void setNumInforSelec(String numInforSelec) {
		this.numInforSelec = numInforSelec;
	}

	public String getNumInforResul() {
		return numInforResul;
	}

	public void setNumInforResul(String numInforResul) {
		this.numInforResul = numInforResul;
	}

	public String getNumDocAccion() {
		return numDocAccion;
	}

	public void setNumDocAccion(String numDocAccion) {
		this.numDocAccion = numDocAccion;
	}

	public String getCodProgCtrl() {
		return codProgCtrl;
	}

	public void setCodProgCtrl(String codProgCtrl) {
		this.codProgCtrl = codProgCtrl;
	}

	public String getNomApellidoUsuario() {
		return nomApellidoUsuario;
	}

	public void setNomApellidoUsuario(String nomApellidoUsuario) {
		this.nomApellidoUsuario = nomApellidoUsuario;
	}

	public Integer getNumProgramaCorrel() {
		return numProgramaCorrel;
	}

	public void setNumProgramaCorrel(Integer numProgramaCorrel) {
		this.numProgramaCorrel = numProgramaCorrel;
	}
	public String getNomApeUsuario() {
		return nomApeUsuario;
	}

	public void setNomApeUsuario(String nomApeUsuario) {
		this.nomApeUsuario = nomApeUsuario;
	}

	public String getDesDenominacion() {
		return desDenominacion;
	}

	public void setDesDenominacion(String desDenominacion) {
		this.desDenominacion = desDenominacion;
	}

	public Integer getAnioInforme() {
		return anioInforme;
	}

	public void setAnioInforme(Integer anioInforme) {
		this.anioInforme = anioInforme;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public String getNumDoc() {
		return numDoc;
	}

	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}

	public Integer getNumCorrelDoc() {
		return numCorrelDoc;
	}

	public void setNumCorrelDoc(Integer numCorrelDoc) {
		this.numCorrelDoc = numCorrelDoc;
	}

	public Integer getAnnDoc() {
		return annDoc;
	}

	public void setAnnDoc(Integer annDoc) {
		this.annDoc = annDoc;
	}

	public String getCodUuooDoc() {
		return codUuooDoc;
	}

	public void setCodUuooDoc(String codUuooDoc) {
		this.codUuooDoc = codUuooDoc;
	}

	public String getCodClase() {
		return codClase;
	}

	public void setCodClase(String codClase) {
		this.codClase = codClase;
	}

	public String getCodUnidadOrganicaInforme() {
		return codUnidadOrganicaInforme;
	}

	public void setCodUnidadOrganicaInforme(String codUnidadOrganicaInforme) {
		this.codUnidadOrganicaInforme = codUnidadOrganicaInforme;
	}

	public String getCodEstadoUsuario() {
		return codEstadoUsuario;
	}

	public void setCodEstadoUsuario(String codEstadoUsuario) {
		this.codEstadoUsuario = codEstadoUsuario;
	}

	public String getPerInicio() {
		return perInicio;
	}

	public void setPerInicio(String perInicio) {
		this.perInicio = perInicio;
	}

	public String getPerFin() {
		return perFin;
	}

	public void setPerFin(String perFin) {
		this.perFin = perFin;
	}
	public Long getInformeNumCorrel() {
		return informeNumCorrel;
	}

	public void setInformeNumCorrel(Long informeNumCorrel) {
		this.informeNumCorrel = informeNumCorrel;
	}

	public Integer getInformeAnio() {
		return informeAnio;
	}

	public void setInformeAnio(Integer informeAnio) {
		this.informeAnio = informeAnio;
	}

	public String getInformeCodUUOO() {
		return informeCodUUOO;
	}

	public void setInformeCodUUOO(String informeCodUUOO) {
		this.informeCodUUOO = informeCodUUOO;
	}

	public String getCodTipAccion() {
		return codTipAccion;
	}

	public void setCodTipAccion(String codTipAccion) {
		this.codTipAccion = codTipAccion;
	}

	public String getNumDocumentoOrden() {
		return numDocumentoOrden;
	}

	public void setNumDocumentoOrden(String numDocumentoOrden) {
		this.numDocumentoOrden = numDocumentoOrden;
	}

	public String getDesProgCtrl() {
		return desProgCtrl;
	}

	public void setDesProgCtrl(String desProgCtrl) {
		this.desProgCtrl = desProgCtrl;
	}

	public Date getFecPrimeraVisita() {
		return fecPrimeraVisita;
	}

	public void setFecPrimeraVisita(Date fecPrimeraVisita) {
		this.fecPrimeraVisita = fecPrimeraVisita;
	}

	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}
	
}
