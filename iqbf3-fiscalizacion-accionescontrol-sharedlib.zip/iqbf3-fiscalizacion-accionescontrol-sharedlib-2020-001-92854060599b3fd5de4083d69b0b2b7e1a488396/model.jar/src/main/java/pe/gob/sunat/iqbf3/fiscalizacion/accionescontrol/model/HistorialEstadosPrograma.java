package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "T10410HISTESTAPROG")
public class HistorialEstadosPrograma extends Auditoria {

	 @Column(name = "COD_EST_PROGRAM")
	 private String codEstadoPrograma;
	
	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_EST_PROGRAM")
	 private Date fecEstadoProgram;
	
	 @Id
	 @Column(name = "NUM_HIS_PROGRAM")
	 private Long numHistoriaProgram;

	@Column(name = "NUM_PROGRAMACION")
	private Long numProgramacion;

	public String getCodEstadoPrograma() {
		return codEstadoPrograma;
	}

	public void setCodEstadoPrograma(String codEstadoPrograma) {
		this.codEstadoPrograma = codEstadoPrograma;
	}

	public Date getFecEstadoProgram() {
		return fecEstadoProgram;
	}

	public void setFecEstadoProgram(Date fecEstadoProgram) {
		this.fecEstadoProgram = fecEstadoProgram;
	}

	public Long getNumHistoriaProgram() {
		return numHistoriaProgram;
	}

	public void setNumHistoriaProgram(Long numHistoriaProgram) {
		this.numHistoriaProgram = numHistoriaProgram;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}
 
	 
}
