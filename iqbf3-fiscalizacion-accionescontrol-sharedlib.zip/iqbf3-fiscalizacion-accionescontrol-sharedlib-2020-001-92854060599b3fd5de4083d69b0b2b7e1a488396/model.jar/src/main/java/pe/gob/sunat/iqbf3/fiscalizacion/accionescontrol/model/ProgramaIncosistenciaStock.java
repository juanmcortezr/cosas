package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "T10419PROINCOSTOCK")
public class ProgramaIncosistenciaStock extends Auditoria {

	
	 @Column(name = "CNT_ING_EST")
	 private Double cntIngEst;
	
	 @Column(name = "CNT_NET_PRES")
	 private Double cntNetPres;
	
	 @Column(name = "CNT_NETEADA")
	 private Double cntNeteada;
	
	 @Column(name = "CNT_STOCK_ACTUAL")
	 private Double cantidadStockActual;
	
	 @Column(name = "CNT_UNIFISICA")
	 private Double cantidadUnidadFisica;
	
	 @Column(name = "COD_BIENFISCA")
	 private String codBienFiscalizado;
	
	 @Column(name = "COD_INSUMO")
	 private String codInsumo;
	
	 @Column(name = "COD_PRESEN")
	 private String codPresen;
	
	 @Column(name = "COD_TIPPROD")
	 private String codTipprod;
	
	 @Column(name = "COD_UM")
	 private String codUnidadMedida;
	
	 @Column(name = "COD_UNI_COM")
	 private String codUnidadComercial;
	
	 @Column(name = "COD_UNI_FIS")
	 private String codUnidadFiscal;
	
	 @Column(name = "DES_NOMCOMPROD")
	 private String desNombreComercial;
	
	 @Column(name = "DES_NOMPROD")
	 private String desNombreProducto;
	
	 @Column(name = "NUM_ESTAB")
	 private Long numEstablecimiento;
	
	 @Id
	 @Column(name = "NUM_INCO_STOCK")
	 private Long numIncosistenciaStock;
	
	 @Column(name = "NUM_USU_PROGRAM")
	 private Long numUsuarioPrograma;
	 
	 @Column(name = "NUM_INSCAB")
	 private Long numInsumoCabecera;
	
	 @Column(name = "NUM_ORDEN")
	 private String numOrden;
	
	 @Column(name = "NUM_PERIODO")
	 private String numPeriodo;
	
	 @Column(name = "NUM_PRESENT")
	 private Integer numPresentacion;
	
	 @Column(name = "NUM_REPOSICION")
	 private String numReposicion;
	
	 @Column(name = "NUM_VERSION_ESTAB")
	 private Long numVersionEstablecimiento;
	
	 @Column(name = "NUM_VERSION_INSU")
	 private Long numVersionInsumo;
	
	 @Column(name = "NUM_VERSION_PRES")
	 private Long numVersionPressentacion;
	
	 @Column(name = "POR_MAX_INS")
	 private Double porMaxInsumo;
	
	 @Column(name = "POR_MIN_INS")
	 private Double porMinInsumo;

	 @Column(name = "cod_ubigeo")
	 private String codUbigeo;
	 
	 @Column(name = "des_direccion")
	 private String desDireccion;
	 
	 //PARA FILTROS
	 @Transient
	 private String codTipvia;
	 
	 @Transient
	 private String desNomvia;
	 
	 @Transient
	 private String numNumvia;
	 
	 @Transient
	 private String numInter1;
	 
	 @Transient
	 private String codTipzon;
	 
	 @Transient
	 private String desNomzon;
	 
	 @Transient
	 private String desRefer1;
	 
	 @Transient
	 private String numManza;
	 
	 @Transient
	 private String numLote;
	 
	 @Transient
	 private String numKilom;
	 
	 @Transient
	 private String numDepar;
	 
	public String getCodUbigeo() {
		return codUbigeo;
	}

	public void setCodUbigeo(String codUbigeo) {
		this.codUbigeo = codUbigeo;
	}

	public String getDesDireccion() {
		return desDireccion;
	}

	public void setDesDireccion(String desDireccion) {
		this.desDireccion = desDireccion;
	}

	public Double getCntIngEst() {
		return cntIngEst;
	}

	public void setCntIngEst(Double cntIngEst) {
		this.cntIngEst = cntIngEst;
	}

	public Double getCntNetPres() {
		return cntNetPres;
	}

	public void setCntNetPres(Double cntNetPres) {
		this.cntNetPres = cntNetPres;
	}

	public Double getCntNeteada() {
		return cntNeteada;
	}

	public void setCntNeteada(Double cntNeteada) {
		this.cntNeteada = cntNeteada;
	}

	public Double getCantidadStockActual() {
		return cantidadStockActual;
	}

	public void setCantidadStockActual(Double cantidadStockActual) {
		this.cantidadStockActual = cantidadStockActual;
	}

	public Double getCantidadUnidadFisica() {
		return cantidadUnidadFisica;
	}

	public void setCantidadUnidadFisica(Double cantidadUnidadFisica) {
		this.cantidadUnidadFisica = cantidadUnidadFisica;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodInsumo() {
		return codInsumo;
	}

	public void setCodInsumo(String codInsumo) {
		this.codInsumo = codInsumo;
	}

	public String getCodPresen() {
		return codPresen;
	}

	public void setCodPresen(String codPresen) {
		this.codPresen = codPresen;
	}

	public String getCodTipprod() {
		return codTipprod;
	}

	public void setCodTipprod(String codTipprod) {
		this.codTipprod = codTipprod;
	}

	public String getCodUnidadMedida() {
		return codUnidadMedida;
	}

	public void setCodUnidadMedida(String codUnidadMedida) {
		this.codUnidadMedida = codUnidadMedida;
	}

	public String getCodUnidadComercial() {
		return codUnidadComercial;
	}

	public void setCodUnidadComercial(String codUnidadComercial) {
		this.codUnidadComercial = codUnidadComercial;
	}

	public String getCodUnidadFiscal() {
		return codUnidadFiscal;
	}

	public void setCodUnidadFiscal(String codUnidadFiscal) {
		this.codUnidadFiscal = codUnidadFiscal;
	}

	public String getDesNombreComercial() {
		return desNombreComercial;
	}

	public void setDesNombreComercial(String desNombreComercial) {
		this.desNombreComercial = desNombreComercial;
	}

	public String getDesNombreProducto() {
		return desNombreProducto;
	}

	public void setDesNombreProducto(String desNombreProducto) {
		this.desNombreProducto = desNombreProducto;
	}

	public Long getNumEstablecimiento() {
		return numEstablecimiento;
	}

	public void setNumEstablecimiento(Long numEstablecimiento) {
		this.numEstablecimiento = numEstablecimiento;
	}

	public Long getNumIncosistenciaStock() {
		return numIncosistenciaStock;
	}

	public void setNumIncosistenciaStock(Long numIncosistenciaStock) {
		this.numIncosistenciaStock = numIncosistenciaStock;
	}

	public Long getNumInsumoCabecera() {
		return numInsumoCabecera;
	}

	public void setNumInsumoCabecera(Long numInsumoCabecera) {
		this.numInsumoCabecera = numInsumoCabecera;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public Integer getNumPresentacion() {
		return numPresentacion;
	}

	public void setNumPresentacion(Integer numPresentacion) {
		this.numPresentacion = numPresentacion;
	}

	public String getNumReposicion() {
		return numReposicion;
	}

	public void setNumReposicion(String numReposicion) {
		this.numReposicion = numReposicion;
	}

	public Long getNumVersionEstablecimiento() {
		return numVersionEstablecimiento;
	}

	public void setNumVersionEstablecimiento(Long numVersionEstablecimiento) {
		this.numVersionEstablecimiento = numVersionEstablecimiento;
	}

	public Long getNumVersionInsumo() {
		return numVersionInsumo;
	}

	public void setNumVersionInsumo(Long numVersionInsumo) {
		this.numVersionInsumo = numVersionInsumo;
	}

	public Long getNumVersionPressentacion() {
		return numVersionPressentacion;
	}

	public void setNumVersionPressentacion(Long numVersionPressentacion) {
		this.numVersionPressentacion = numVersionPressentacion;
	}

	public Double getPorMaxInsumo() {
		return porMaxInsumo;
	}

	public void setPorMaxInsumo(Double porMaxInsumo) {
		this.porMaxInsumo = porMaxInsumo;
	}

	public Double getPorMinInsumo() {
		return porMinInsumo;
	}

	public void setPorMinInsumo(Double porMinInsumo) {
		this.porMinInsumo = porMinInsumo;
	}

	public String getCodTipvia() {
		return codTipvia;
	}

	public void setCodTipvia(String codTipvia) {
		this.codTipvia = codTipvia;
	}

	public String getDesNomvia() {
		return desNomvia;
	}

	public void setDesNomvia(String desNomvia) {
		this.desNomvia = desNomvia;
	}

	public String getNumNumvia() {
		return numNumvia;
	}

	public void setNumNumvia(String numNumvia) {
		this.numNumvia = numNumvia;
	}

	public String getNumInter1() {
		return numInter1;
	}

	public void setNumInter1(String numInter1) {
		this.numInter1 = numInter1;
	}

	public String getCodTipzon() {
		return codTipzon;
	}

	public void setCodTipzon(String codTipzon) {
		this.codTipzon = codTipzon;
	}

	public String getDesNomzon() {
		return desNomzon;
	}

	public void setDesNomzon(String desNomzon) {
		this.desNomzon = desNomzon;
	}

	public String getDesRefer1() {
		return desRefer1;
	}

	public void setDesRefer1(String desRefer1) {
		this.desRefer1 = desRefer1;
	}

	public String getNumManza() {
		return numManza;
	}

	public void setNumManza(String numManza) {
		this.numManza = numManza;
	}

	public String getNumLote() {
		return numLote;
	}

	public void setNumLote(String numLote) {
		this.numLote = numLote;
	}

	public String getNumKilom() {
		return numKilom;
	}

	public void setNumKilom(String numKilom) {
		this.numKilom = numKilom;
	}

	public String getNumDepar() {
		return numDepar;
	}

	public void setNumDepar(String numDepar) {
		this.numDepar = numDepar;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}
}
