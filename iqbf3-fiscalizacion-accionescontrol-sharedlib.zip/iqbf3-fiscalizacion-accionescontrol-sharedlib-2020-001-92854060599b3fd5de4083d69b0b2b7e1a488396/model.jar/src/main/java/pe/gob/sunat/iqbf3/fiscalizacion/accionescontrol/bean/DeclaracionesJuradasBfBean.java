package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;

public class DeclaracionesJuradasBfBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codEstado;
	private	int	codTipobien;
	private	String	fecFinOmiso;
	private	String	fecFinOperacion;
	private	String	fecFinPresentacion;
	private	String	fecInicioOmiso;
	private	String	fecInicioOperacion;
	private	String	fecInicioPresentacion;
	private	String	indOmiso;
	private	int	indTipenv;
	private	int	numCabecera;
	private	int	numConfirma;
	private	String	numPeriodo;
	private	int	numRuc;
	private	int	numVersionRegistro;
	private String indDel;
	private String indEst;
	private List<String> lstEstadoBfRegistro;
	
	
	
	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public List<String> getLstEstadoBfRegistro() {
		return lstEstadoBfRegistro;
	}

	public void setLstEstadoBfRegistro(List<String> lstEstadoBfRegistro) {
		this.lstEstadoBfRegistro = lstEstadoBfRegistro;
	}

	public DeclaracionesJuradasBfBean() {
		super();
	}

	public DeclaracionesJuradasBfBean(String codEstado, int codTipobien, String fecFinOmiso, String fecFinOperacion,
			String fecFinPresentacion, String fecInicioOmiso, String fecInicioOperacion, String fecInicioPresentacion,
			String indOmiso, int indTipenv, int numCabecera, int numConfirma, String numPeriodo, int numRuc,
			int numVersionRegistro) {
		super();
		this.codEstado = codEstado;
		this.codTipobien = codTipobien;
		this.fecFinOmiso = fecFinOmiso;
		this.fecFinOperacion = fecFinOperacion;
		this.fecFinPresentacion = fecFinPresentacion;
		this.fecInicioOmiso = fecInicioOmiso;
		this.fecInicioOperacion = fecInicioOperacion;
		this.fecInicioPresentacion = fecInicioPresentacion;
		this.indOmiso = indOmiso;
		this.indTipenv = indTipenv;
		this.numCabecera = numCabecera;
		this.numConfirma = numConfirma;
		this.numPeriodo = numPeriodo;
		this.numRuc = numRuc;
		this.numVersionRegistro = numVersionRegistro;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public int getCodTipobien() {
		return codTipobien;
	}

	public void setCodTipobien(int codTipobien) {
		this.codTipobien = codTipobien;
	}

	public String getFecFinOmiso() {
		return fecFinOmiso;
	}

	public void setFecFinOmiso(String fecFinOmiso) {
		this.fecFinOmiso = fecFinOmiso;
	}

	public String getFecFinOperacion() {
		return fecFinOperacion;
	}

	public void setFecFinOperacion(String fecFinOperacion) {
		this.fecFinOperacion = fecFinOperacion;
	}

	public String getFecFinPresentacion() {
		return fecFinPresentacion;
	}

	public void setFecFinPresentacion(String fecFinPresentacion) {
		this.fecFinPresentacion = fecFinPresentacion;
	}

	public String getFecInicioOmiso() {
		return fecInicioOmiso;
	}

	public void setFecInicioOmiso(String fecInicioOmiso) {
		this.fecInicioOmiso = fecInicioOmiso;
	}

	public String getFecInicioOperacion() {
		return fecInicioOperacion;
	}

	public void setFecInicioOperacion(String fecInicioOperacion) {
		this.fecInicioOperacion = fecInicioOperacion;
	}

	public String getFecInicioPresentacion() {
		return fecInicioPresentacion;
	}

	public void setFecInicioPresentacion(String fecInicioPresentacion) {
		this.fecInicioPresentacion = fecInicioPresentacion;
	}

	public String getIndOmiso() {
		return indOmiso;
	}

	public void setIndOmiso(String indOmiso) {
		this.indOmiso = indOmiso;
	}

	public int getIndTipenv() {
		return indTipenv;
	}

	public void setIndTipenv(int indTipenv) {
		this.indTipenv = indTipenv;
	}

	public int getNumCabecera() {
		return numCabecera;
	}

	public void setNumCabecera(int numCabecera) {
		this.numCabecera = numCabecera;
	}

	public int getNumConfirma() {
		return numConfirma;
	}

	public void setNumConfirma(int numConfirma) {
		this.numConfirma = numConfirma;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public int getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(int numRuc) {
		this.numRuc = numRuc;
	}

	public int getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(int numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
