package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;

public class ArchivoProgramacionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	ArchivoBean	archivoBean;
	private	int	numArchivoProgram;
	private	int	numProgramacion;
	
	public ArchivoProgramacionBean() {
		super();
	}

	public ArchivoProgramacionBean(ArchivoBean archivoBean, int numArchivoProgram, int numProgramacion) {
		super();
		this.archivoBean = archivoBean;
		this.numArchivoProgram = numArchivoProgram;
		this.numProgramacion = numProgramacion;
	}

	public ArchivoBean getArchivoBean() {
		return archivoBean;
	}

	public void setArchivoBean(ArchivoBean archivoBean) {
		this.archivoBean = archivoBean;
	}

	public int getNumArchivoProgram() {
		return numArchivoProgram;
	}

	public void setNumArchivoProgram(int numArchivoProgram) {
		this.numArchivoProgram = numArchivoProgram;
	}

	public int getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(int numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
