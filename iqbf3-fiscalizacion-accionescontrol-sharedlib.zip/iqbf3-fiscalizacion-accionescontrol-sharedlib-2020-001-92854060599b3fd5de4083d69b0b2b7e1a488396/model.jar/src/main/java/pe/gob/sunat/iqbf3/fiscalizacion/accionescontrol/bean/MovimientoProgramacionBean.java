package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class MovimientoProgramacionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codEstadoInforme;
	private	String	codEstadoPrograma;
	private	String	codPersonaMovimiento;
	private	String	desSusDevolucion;
	private	String	desEstadoInforme;
	private	String	desEstadoProgram;
	private	String	fecMovimiento;
	private	String	nomPersonal;
	private	int	numMovimientoPrograma;
	private	int	numProgramacion;
	
	public MovimientoProgramacionBean() {
		super();
	}

	public MovimientoProgramacionBean(String codEstadoInforme, String codEstadoPrograma, String codPersonaMovimiento,
			String desSusDevolucion, String desEstadoInforme, String desEstadoProgram, String fecMovimiento,
			String nomPersonal, int numMovimientoPrograma, int numProgramacion) {
		super();
		this.codEstadoInforme = codEstadoInforme;
		this.codEstadoPrograma = codEstadoPrograma;
		this.codPersonaMovimiento = codPersonaMovimiento;
		this.desSusDevolucion = desSusDevolucion;
		this.desEstadoInforme = desEstadoInforme;
		this.desEstadoProgram = desEstadoProgram;
		this.fecMovimiento = fecMovimiento;
		this.nomPersonal = nomPersonal;
		this.numMovimientoPrograma = numMovimientoPrograma;
		this.numProgramacion = numProgramacion;
	}

	public String getCodEstadoInforme() {
		return codEstadoInforme;
	}

	public void setCodEstadoInforme(String codEstadoInforme) {
		this.codEstadoInforme = codEstadoInforme;
	}

	public String getCodEstadoPrograma() {
		return codEstadoPrograma;
	}

	public void setCodEstadoPrograma(String codEstadoPrograma) {
		this.codEstadoPrograma = codEstadoPrograma;
	}

	public String getCodPersonaMovimiento() {
		return codPersonaMovimiento;
	}

	public void setCodPersonaMovimiento(String codPersonaMovimiento) {
		this.codPersonaMovimiento = codPersonaMovimiento;
	}

	public String getDesSusDevolucion() {
		return desSusDevolucion;
	}

	public void setDesSusDevolucion(String desSusDevolucion) {
		this.desSusDevolucion = desSusDevolucion;
	}

	public String getDesEstadoInforme() {
		return desEstadoInforme;
	}

	public void setDesEstadoInforme(String desEstadoInforme) {
		this.desEstadoInforme = desEstadoInforme;
	}

	public String getDesEstadoProgram() {
		return desEstadoProgram;
	}

	public void setDesEstadoProgram(String desEstadoProgram) {
		this.desEstadoProgram = desEstadoProgram;
	}

	public String getFecMovimiento() {
		return fecMovimiento;
	}

	public void setFecMovimiento(String fecMovimiento) {
		this.fecMovimiento = fecMovimiento;
	}

	public String getNomPersonal() {
		return nomPersonal;
	}

	public void setNomPersonal(String nomPersonal) {
		this.nomPersonal = nomPersonal;
	}

	public int getNumMovimientoPrograma() {
		return numMovimientoPrograma;
	}

	public void setNumMovimientoPrograma(int numMovimientoPrograma) {
		this.numMovimientoPrograma = numMovimientoPrograma;
	}

	public int getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(int numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
