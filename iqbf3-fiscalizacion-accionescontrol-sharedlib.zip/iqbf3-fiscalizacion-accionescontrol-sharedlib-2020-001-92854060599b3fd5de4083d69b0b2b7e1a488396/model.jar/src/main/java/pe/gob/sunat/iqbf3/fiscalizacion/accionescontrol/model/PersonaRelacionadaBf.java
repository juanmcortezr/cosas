package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T5231PERSORELAC")
public class PersonaRelacionadaBf implements Entidad {

	@EmbeddedId
	private PersonaRelacionadaBfPK personaRelacionadaBfPk;
	
	 @Column(name = "DES_NOMBRE")
	 private String apellidosNombre;
	
	 @Column(name = "NUM_DOC_IDENT")
	 private String numDocumentoVinculado;
	
	 @Column(name = "NUM_LICENCIA_CONDU")
	 private String numeroLicenciaConducir;
	
	 @Column(name = "IND_SUBCONTRATADO")
	 private Integer subcontratado;
	
	 @Column(name = "COD_TIP_DOC_IDENT")
	 private String tipoDocumento;
	
	

	public String getApellidosNombre() {
		return apellidosNombre;
	}

	public void setApellidosNombre(String apellidosNombre) {
		this.apellidosNombre = apellidosNombre;
	}

	public String getNumDocumentoVinculado() {
		return numDocumentoVinculado;
	}

	public void setNumDocumentoVinculado(String numDocumentoVinculado) {
		this.numDocumentoVinculado = numDocumentoVinculado;
	}

	public String getNumeroLicenciaConducir() {
		return numeroLicenciaConducir;
	}

	public void setNumeroLicenciaConducir(String numeroLicenciaConducir) {
		this.numeroLicenciaConducir = numeroLicenciaConducir;
	}

	public Integer getSubcontratado() {
		return subcontratado;
	}

	public void setSubcontratado(Integer subcontratado) {
		this.subcontratado = subcontratado;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public PersonaRelacionadaBfPK getPersonaRelacionadaBfPk() {
		return personaRelacionadaBfPk;
	}

	public void setPersonaRelacionadaBfPk(PersonaRelacionadaBfPK personaRelacionadaBfPk) {
		this.personaRelacionadaBfPk = personaRelacionadaBfPk;
	}

}
