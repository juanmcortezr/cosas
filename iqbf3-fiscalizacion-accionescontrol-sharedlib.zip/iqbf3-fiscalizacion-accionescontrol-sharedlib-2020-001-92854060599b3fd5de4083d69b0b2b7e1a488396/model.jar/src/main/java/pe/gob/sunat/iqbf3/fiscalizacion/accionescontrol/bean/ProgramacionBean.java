package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;


import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class ProgramacionBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer anioProgramacion;
	private String codEstadoPrograma;
	private String codFuente;
	private String codProceso;
	private String codProgramador;
	private String codSubEstadoProgram;
	private String codTipoProgram;
	private String codProgramaControl;
	private String desAlcance;
	private String desOtraFuente;
	private String desProgramacion;
	private String desSusCancela;
	private String desEstadoProgram;
	private String desFuente;
	private String desProceso;
	private String desProgramaControl;
	private String desProgramador;
	private String desProgramadorAdministrativo;
	private String desSubEstprogram;
	private String desTipoProgram;
	private String fecProgramacion;
	private String indCierre;
	private String numInformeCancelacion;
	private String numPlazoVerificacion;
	private Integer numProgramaCorrel;
	private Long numProgramacion;
	private String obsProgramacion;
	private String perFin;
	private String perInicio;
	private String numOrden;//opv
	private String numUsuarioPrograma;//opv
	private String fecCrea;

	private String fechaDesde;
	private String fechaHasta;
	private String numInforme;
	private String codEstadoInforme;
	private String desEstadoInforme;
	private String fechaIniAsignacion;
	private String fechaFinAsig;
	private List<CheckElementBean> inconsistencias;
	private List<CheckElementBean> respInconsistencias;
	private List<CheckElementBean> tipoBienes;
	private List<CheckElementBean> bienesFiscalizados;
	private List<CheckElementBean> actividades;
	private String desOtroIncosistencia;
	private String desOtroBien;
	private AuditoriaBean auditoriaBean;
	
	private String codProgramadorAdmin;
	private String codEstInforme;
	private String nomProgramador;
	private String nomProgramadorAdmin;
	
	private String codTipoDocumentoIdent;
	private String desTipoDocumentoIdent;
	private String numDocumentoIdent;

	private String CodTipoDocUsuario;
	private String desInconsistecia;
	private String desRespInconsistencia;
	private String codTipoAccion;
	private String desTipoAccion;
	private String codTipoOrden;
	private String desTipOrden;
	private String codEstOrden;
	private String desEstOrden;
	private String codResOrden;
	private String desResOrden;
	private String codTipInterv;
	private String desTipInterv;
	private String nombAuditAsignad;
	private String codBien;
	private String desBien;
	private ArchivoBean archivoBean;
	
	private String codTipoArchivo;
	private String desInconsistencia;
	private String codTipInconsis;
	private InformeSeleccionBean informeSeleccion;
	private String codResulInconsis;
	private String codResulIncondef;
	private String nombApeUsuario;
	private String numDocAccion;
	private String codProgctrl;
	private String numDocVin;
	private String numSolicitudUnion;
	private String nombAuditApoyo;
	private String codClaseAccion;
	private String codClaseVincul;
	private String codCargoPrincipal;
	private String codCargoApoyo;
	private String nroInformeUnion;
	private String codPers;
	private String codPersApoyo;
	private Integer cantUsuariosDepurados;	
	private String desSupervisor;
	private String fecEstadoProgramacion;
	private Integer cantFinalUsuario;
	private String codProgramadorAsignado;
	private String indTipoAsignacion;
	private String indNoDepurado;
	private String indDepurado;	
	private String desProgctrl;
	private Date fecFinAsignacion;
	private String codUsuCrea;
	private String dirIpusucrea;
	private String codUsuModif;
	private String dirIpusumodif;
	private String fecUltimoEstado;
	private String indTipAsignacion;
	private Long numAsignacion;
	private String indTipAsignaProgAdmi;
	private String indTipAsignaProg;
	private String fecInicioAsignacion;
	

	public String getFecInicioAsignacion() {
		return fecInicioAsignacion;
	}

	public void setFecInicioAsignacion(String fecInicioAsignacion) {
		this.fecInicioAsignacion = fecInicioAsignacion;
	}

	public String getIndTipAsignaProg() {
		return indTipAsignaProg;
	}

	public void setIndTipAsignaProg(String indTipAsignaProg) {
		this.indTipAsignaProg = indTipAsignaProg;
	}

	public String getIndTipAsignaProgAdmi() {
		return indTipAsignaProgAdmi;
	}

	public void setIndTipAsignaProgAdmi(String indTipAsignaProgAdmi) {
		this.indTipAsignaProgAdmi = indTipAsignaProgAdmi;
	}

	public Long getNumAsignacion() {
		return numAsignacion;
	}

	public void setNumAsignacion(Long numAsignacion) {
		this.numAsignacion = numAsignacion;
	}

	public String getIndTipAsignacion() {
		return indTipAsignacion;
	}

	public void setIndTipAsignacion(String indTipAsignacion) {
		this.indTipAsignacion = indTipAsignacion;
	}
	private String codigoUnidadOrganica;
	private List<UsuarioProgramacionBean> listUsuarioProgramacionBean;
	
	public List<UsuarioProgramacionBean> getListUsuarioProgramacionBean() {
		return listUsuarioProgramacionBean;
	}

	public void setListUsuarioProgramacionBean(List<UsuarioProgramacionBean> listUsuarioProgramacionBean) {
		this.listUsuarioProgramacionBean = listUsuarioProgramacionBean;
	}

	public String getFecUltimoEstado() {
		return fecUltimoEstado;
	}

	public void setFecUltimoEstado(String fecUltimoEstado) {
		this.fecUltimoEstado = fecUltimoEstado;
	}

	public String getDirIpusumodif() {
		return dirIpusumodif;
	}

	public void setDirIpusumodif(String dirIpusumodif) {
		this.dirIpusumodif = dirIpusumodif;
	}

	public String getCodUsuModif() {
		return codUsuModif;
	}

	public void setCodUsuModif(String codUsuModif) {
		this.codUsuModif = codUsuModif;
	}

	public String getDirIpusucrea() {
		return dirIpusucrea;
	}

	public void setDirIpusucrea(String dirIpusucrea) {
		this.dirIpusucrea = dirIpusucrea;
	}

	public String getCodUsuCrea() {
		return codUsuCrea;
	}

	public void setCodUsuCrea(String codUsuCrea) {
		this.codUsuCrea = codUsuCrea;
	}

	public String getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(String fecCrea) {
		this.fecCrea = fecCrea;
	}

	public Date getFecFinAsignacion() {
		return fecFinAsignacion;
	}

	public void setFecFinAsignacion(Date fecFinAsignacion) {
		this.fecFinAsignacion = fecFinAsignacion;
	}

	public String getIndDepurado() {
		return indDepurado;
	}

	public void setIndDepurado(String indDepurado) {
		this.indDepurado = indDepurado;
	}

	public String getIndNoDepurado() {
		return indNoDepurado;
	}

	public void setIndNoDepurado(String indNoDepurado) {
		this.indNoDepurado = indNoDepurado;
	}

	public String getIndTipoAsignacion() {
		return indTipoAsignacion;
	}

	public void setIndTipoAsignacion(String indTipoAsignacion) {
		this.indTipoAsignacion = indTipoAsignacion;
	}

	public String getDesProgctrl() {
		return desProgctrl;
	}

	public void setDesProgctrl(String desProgctrl) {
		this.desProgctrl = desProgctrl;
	}

	public String getFechaFinAsig() {
		return fechaFinAsig;
	}

	public void setFechaFinAsig(String fechaFinAsig) {
		this.fechaFinAsig = fechaFinAsig;
	}

	public String getDesSupervisor() {
		return desSupervisor;
	}

	public void setDesSupervisor(String desSupervisor) {
		this.desSupervisor = desSupervisor;
	}

	public String getFecEstadoProgramacion() {
		return fecEstadoProgramacion;
	}

	public void setFecEstadoProgramacion(String fecEstadoProgramacion) {
		this.fecEstadoProgramacion = fecEstadoProgramacion;
	}

	public Integer getCantFinalUsuario() {
		return cantFinalUsuario;
	}

	public void setCantFinalUsuario(Integer cantFinalUsuario) {
		this.cantFinalUsuario = cantFinalUsuario;
	}

	public Integer getCantUsuariosDepurados() {
		return cantUsuariosDepurados;
	}

	public void setCantUsuariosDepurados(Integer cantUsuariosDepurados) {
		this.cantUsuariosDepurados = cantUsuariosDepurados;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getCodPersApoyo() {
		return codPersApoyo;
	}

	public void setCodPersApoyo(String codPersApoyo) {
		this.codPersApoyo = codPersApoyo;
	}

	public String getNroInformeUnion() {
		return nroInformeUnion;
	}

	public void setNroInformeUnion(String nroInformeUnion) {
		this.nroInformeUnion = nroInformeUnion;
	}

	public String getCodCargoApoyo() {
		return codCargoApoyo;
	}

	public void setCodCargoApoyo(String codCargoApoyo) {
		this.codCargoApoyo = codCargoApoyo;
	}

	public String getCodClaseVincul() {
		return codClaseVincul;
	}

	public void setCodClaseVincul(String codClaseVincul) {
		this.codClaseVincul = codClaseVincul;
	}

	public String getCodCargoPrincipal() {
		return codCargoPrincipal;
	}

	public void setCodCargoPrincipal(String codCargoPrincipal) {
		this.codCargoPrincipal = codCargoPrincipal;
	}

	public String getCodClaseAccion() {
		return codClaseAccion;
	}

	public void setCodClaseAccion(String codClaseAccion) {
		this.codClaseAccion = codClaseAccion;
	}
	
	private String numAlcanceProgramacion;
	
	public String getNumAlcanceProgramacion() {
		return numAlcanceProgramacion;
	}

	public void setNumAlcanceProgramacion(String numAlcanceProgramacion) {
		this.numAlcanceProgramacion = numAlcanceProgramacion;
	}

	public String getNombAuditApoyo() {
		return nombAuditApoyo;
	}

	public void setNombAuditApoyo(String nombAuditApoyo) {
		this.nombAuditApoyo = nombAuditApoyo;
	}

	public String getNumSolicitudUnion() {
		return numSolicitudUnion;
	}

	public void setNumSolicitudUnion(String numSolicitudUnion) {
		this.numSolicitudUnion = numSolicitudUnion;
	}

	public String getDesTipoDocumentoIdent() {
		return desTipoDocumentoIdent;
	}

	public void setDesTipoDocumentoIdent(String desTipoDocumentoIdent) {
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
	}

	public String getNumDocVin() {
		return numDocVin;
	}

	public void setNumDocVin(String numDocVin) {
		this.numDocVin = numDocVin;
	}

	public String getCodProgctrl() {
		return codProgctrl;
	}

	public void setCodProgctrl(String codProgctrl) {
		this.codProgctrl = codProgctrl;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}

	public String getNumDocAccion() {
		return numDocAccion;
	}

	public void setNumDocAccion(String numDocAccion) {
		this.numDocAccion = numDocAccion;
	}

	public String getNombApeUsuario() {
		return nombApeUsuario;
	}

	public void setNombApeUsuario(String nombApeUsuario) {
		this.nombApeUsuario = nombApeUsuario;
	}

	public String getCodResulIncondef() {
		return codResulIncondef;
	}

	public void setCodResulIncondef(String codResulIncondef) {
		this.codResulIncondef = codResulIncondef;
	}

	public String getCodResulInconsis() {
		return codResulInconsis;
	}

	public void setCodResulInconsis(String codResulInconsis) {
		this.codResulInconsis = codResulInconsis;
	}

	public String getCodTipInconsis() {
		return codTipInconsis;
	}

	public void setCodTipInconsis(String codTipInconsis) {
		this.codTipInconsis = codTipInconsis;
	}

	public String getDesInconsistencia() {
		return desInconsistencia;
	}

	public void setDesInconsistencia(String desInconsistencia) {
		this.desInconsistencia = desInconsistencia;
	}

	public String getCodTipoArchivo() {
		return codTipoArchivo;
	}

	public void setCodTipoArchivo(String codTipoArchivo) {
		this.codTipoArchivo = codTipoArchivo;
	}

	private String codTipoAccionSugerida;
	
	public String getCodBien() {
		return codBien;
	}

	public void setCodBien(String codBien) {
		this.codBien = codBien;
	}

	public String getDesBien() {
		return desBien;
	}

	public void setDesBien(String desBien) {
		this.desBien = desBien;
	}

	public String getNombAuditAsignad() {
		return nombAuditAsignad;
	}

	public void setNombAuditAsignad(String nombAuditAsignad) {
		this.nombAuditAsignad = nombAuditAsignad;
	}

	public String getCodTipInterv() {
		return codTipInterv;
	}

	public void setCodTipInterv(String codTipInterv) {
		this.codTipInterv = codTipInterv;
	}
	
	
	public String getCodTipoAccionSugerida() {
		return codTipoAccionSugerida;
	}

	public void setCodTipoAccionSugerida(String codTipoAccionSugerida) {
		this.codTipoAccionSugerida = codTipoAccionSugerida;
	}

	public String getCodEstOrden() {
		return codEstOrden;
	}

	public void setCodEstOrden(String codEstOrden) {
		this.codEstOrden = codEstOrden;
	}

	public String getDesEstOrden() {
		return desEstOrden;
	}

	public void setDesEstOrden(String desEstOrden) {
		this.desEstOrden = desEstOrden;
	}

	public String getCodResOrden() {
		return codResOrden;
	}

	public void setCodResOrden(String codResOrden) {
		this.codResOrden = codResOrden;
	}

	public String getDesResOrden() {
		return desResOrden;
	}

	public void setDesResOrden(String desResOrden) {
		this.desResOrden = desResOrden;
	}

	public String getDesTipOrden() {
		return desTipOrden;
	}

	public void setDesTipOrden(String desTipOrden) {
		this.desTipOrden = desTipOrden;
	}

	public String getDesTipoAccion() {
		return desTipoAccion;
	}

	public void setDesTipoAccion(String desTipoAccion) {
		this.desTipoAccion = desTipoAccion;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getDesRespInconsistencia() {
		return desRespInconsistencia;
	}

	public void setDesRespInconsistencia(String desRespInconsistencia) {
		this.desRespInconsistencia = desRespInconsistencia;
	}

	public String getDesInconsistecia() {
		return desInconsistecia;
	}

	public void setDesInconsistecia(String desInconsistecia) {
		this.desInconsistecia = desInconsistecia;
	}

	public String getCodTipoDocUsuario() {
		return CodTipoDocUsuario;
	}

	public void setCodTipoDocUsuario(String codTipoDocUsuario) {
		CodTipoDocUsuario = codTipoDocUsuario;
	}

	public String getCodTipoOrden() {
		return codTipoOrden;
	}

	public void setCodTipoOrden(String codTipoOrden) {
		this.codTipoOrden = codTipoOrden;
	}

	public String getNumDocumentoIdent() {
		return numDocumentoIdent;
	}

	public void setNumDocumentoIdent(String numDocumentoIdent) {
		this.numDocumentoIdent = numDocumentoIdent;
	}

	public String getCodTipoDocumentoIdent() {
		return codTipoDocumentoIdent;
	}

	public void setCodTipoDocumentoIdent(String codTipoDocumentoIdent) {
		this.codTipoDocumentoIdent = codTipoDocumentoIdent;
	}

	public String getNomProgramadorAdmin() {
		return nomProgramadorAdmin;
	}

	public void setNomProgramadorAdmin(String nomProgramadorAdmin) {
		this.nomProgramadorAdmin = nomProgramadorAdmin;
	}

	public String getNomProgramador() {
		return nomProgramador;
	}

	public void setNomProgramador(String nomProgramador) {
		this.nomProgramador = nomProgramador;
	}

	public String getCodEstInforme() {
		return codEstInforme;
	}

	public void setCodEstInforme(String codEstInforme) {
		this.codEstInforme = codEstInforme;
	}

	public String getCodProgramadorAdmin() {
		return codProgramadorAdmin;
	}

	public void setCodProgramadorAdmin(String codProgramadorAdmin) {
		this.codProgramadorAdmin = codProgramadorAdmin;
	}



	public ProgramacionBean(String codBien, String desBien){
		this.codBien = codBien;
		this.desBien = desBien;
		
	}
	

	public ProgramacionBean(String codProgramaControl, String codEstadoPrograma, String desEstadoProgram,
			String desProgramaControl, String desProgramador, String fecProgramacion, Long numProgramacion,
			String perFin, String perInicio, String numInforme, String desEstadoInforme, String fecIniAsignacion,
			String codTipoDocumentoIdent, String numDocumentoIdent, String codTipoOrden,String CodTipoDocUsuario,
			String desInconsistecia, String desRespInconsistencia, String codTipInterv, String nombAuditAsignad) {
		this.codProgramaControl = codProgramaControl;
		this.codEstadoPrograma = codEstadoPrograma;
		this.desEstadoProgram = desEstadoProgram;
		this.desProgramaControl = desProgramaControl;
		this.desProgramador = desProgramador;
		this.fecProgramacion = fecProgramacion;
		this.numProgramacion = numProgramacion;
		this.perFin = perFin;
		this.perInicio = perInicio;
		this.numInforme = numInforme;
		this.desEstadoInforme = desEstadoInforme;
		this.fechaIniAsignacion = fecIniAsignacion;
		this.codTipoDocumentoIdent = codTipoDocumentoIdent;
		this.numDocumentoIdent = numDocumentoIdent;
		this.codTipoOrden = codTipoOrden;
		this.codTipInterv = codTipInterv;
		this.nombAuditAsignad = nombAuditAsignad;
	}

	public ProgramacionBean(Integer anioProgramacion, String codEstadoPrograma, String codFuente, String codProceso,
			String codProgramador, String codSubEstadoProgram, String codTipoProgram, String codProgramaControl,
			String desAlcance, String desOtraFuente, String desProgramacion, String desSusCancela,
			String desEstadoProgram, String desFuente, String desProceso, String desProgramaControl,
			String desProgramador, String desSubEstprogram, String desTipoProgram, String fecProgramacion,
			String indCierre, String numInformeCancelacion, String numPlazoVerificacion, Integer numProgramaCorrel,
			Long numProgramacion, String obsProgramacion, String perFin, String perInicio) {
		super();
		this.anioProgramacion = anioProgramacion;
		this.codEstadoPrograma = codEstadoPrograma;
		this.codFuente = codFuente;
		this.codProceso = codProceso;
		this.codProgramador = codProgramador;
		this.codSubEstadoProgram = codSubEstadoProgram;
		this.codTipoProgram = codTipoProgram;
		this.codProgramaControl = codProgramaControl;
		this.desAlcance = desAlcance;
		this.desOtraFuente = desOtraFuente;
		this.desProgramacion = desProgramacion;
		this.desSusCancela = desSusCancela;
		this.desEstadoProgram = desEstadoProgram;
		this.desFuente = desFuente;
		this.desProceso = desProceso;
		this.desProgramaControl = desProgramaControl;
		this.desProgramador = desProgramador;
		this.desSubEstprogram = desSubEstprogram;
		this.desTipoProgram = desTipoProgram;
		this.fecProgramacion = fecProgramacion;
		this.indCierre = indCierre;
		this.numInformeCancelacion = numInformeCancelacion;
		this.numPlazoVerificacion = numPlazoVerificacion;
		this.numProgramaCorrel = numProgramaCorrel;
		this.numProgramacion = numProgramacion;
		this.obsProgramacion = obsProgramacion;
		this.perFin = perFin;
		this.perInicio = perInicio;
	}

	public ProgramacionBean() {
	}

	public Integer getAnioProgramacion() {
		return anioProgramacion;
	}

	public void setAnioProgramacion(Integer anioProgramacion) {
		this.anioProgramacion = anioProgramacion;
	}

	public String getCodEstadoPrograma() {
		return codEstadoPrograma;
	}

	public void setCodEstadoPrograma(String codEstadoPrograma) {
		this.codEstadoPrograma = codEstadoPrograma;
	}

	public String getCodFuente() {
		return codFuente;
	}

	public void setCodFuente(String codFuente) {
		this.codFuente = codFuente;
	}

	public String getCodProceso() {
		return codProceso;
	}

	public void setCodProceso(String codProceso) {
		this.codProceso = codProceso;
	}

	public String getCodProgramador() {
		return codProgramador;
	}

	public void setCodProgramador(String codProgramador) {
		this.codProgramador = codProgramador;
	}

	public String getCodSubEstadoProgram() {
		return codSubEstadoProgram;
	}

	public void setCodSubEstadoProgram(String codSubEstadoProgram) {
		this.codSubEstadoProgram = codSubEstadoProgram;
	}

	public String getCodTipoProgram() {
		return codTipoProgram;
	}

	public void setCodTipoProgram(String codTipoProgram) {
		this.codTipoProgram = codTipoProgram;
	}

	public String getCodProgramaControl() {
		return codProgramaControl;
	}

	public void setCodProgramaControl(String codProgramaControl) {
		this.codProgramaControl = codProgramaControl;
	}

	public String getDesAlcance() {
		return desAlcance;
	}

	public void setDesAlcance(String desAlcance) {
		this.desAlcance = desAlcance;
	}

	public String getDesOtraFuente() {
		return desOtraFuente;
	}

	public void setDesOtraFuente(String desOtraFuente) {
		this.desOtraFuente = desOtraFuente;
	}

	public String getDesProgramacion() {
		return desProgramacion;
	}

	public void setDesProgramacion(String desProgramacion) {
		this.desProgramacion = desProgramacion;
	}

	public String getDesSusCancela() {
		return desSusCancela;
	}

	public void setDesSusCancela(String desSusCancela) {
		this.desSusCancela = desSusCancela;
	}

	public String getDesEstadoProgram() {
		return desEstadoProgram;
	}

	public void setDesEstadoProgram(String desEstadoProgram) {
		this.desEstadoProgram = desEstadoProgram;
	}

	public String getDesFuente() {
		return desFuente;
	}

	public void setDesFuente(String desFuente) {
		this.desFuente = desFuente;
	}

	public String getDesProceso() {
		return desProceso;
	}

	public void setDesProceso(String desProceso) {
		this.desProceso = desProceso;
	}

	public String getDesProgramaControl() {
		return desProgramaControl;
	}

	public void setDesProgramaControl(String desProgramaControl) {
		this.desProgramaControl = desProgramaControl;
	}

	public String getDesProgramador() {
		return desProgramador;
	}

	public void setDesProgramador(String desProgramador) {
		this.desProgramador = desProgramador;
	}

	public String getDesSubEstprogram() {
		return desSubEstprogram;
	}

	public void setDesSubEstprogram(String desSubEstprogram) {
		this.desSubEstprogram = desSubEstprogram;
	}

	public String getDesTipoProgram() {
		return desTipoProgram;
	}

	public void setDesTipoProgram(String desTipoProgram) {
		this.desTipoProgram = desTipoProgram;
	}

	public String getFecProgramacion() {
		return fecProgramacion;
	}

	public void setFecProgramacion(String fecProgramacion) {
		this.fecProgramacion = fecProgramacion;
	}

	public String getIndCierre() {
		return indCierre;
	}

	public void setIndCierre(String indCierre) {
		this.indCierre = indCierre;
	}

	public String getNumInformeCancelacion() {
		return numInformeCancelacion;
	}

	public void setNumInformeCancelacion(String numInformeCancelacion) {
		this.numInformeCancelacion = numInformeCancelacion;
	}

	public String getNumPlazoVerificacion() {
		return numPlazoVerificacion;
	}

	public void setNumPlazoVerificacion(String numPlazoVerificacion) {
		this.numPlazoVerificacion = numPlazoVerificacion;
	}

	public Integer getNumProgramaCorrel() {
		return numProgramaCorrel;
	}

	public void setNumProgramaCorrel(Integer numProgramaCorrel) {
		this.numProgramaCorrel = numProgramaCorrel;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public String getObsProgramacion() {
		return obsProgramacion;
	}

	public void setObsProgramacion(String obsProgramacion) {
		this.obsProgramacion = obsProgramacion;
	}

	public String getPerFin() {
		return perFin;
	}

	public void setPerFin(String perFin) {
		this.perFin = perFin;
	}

	public String getPerInicio() {
		return perInicio;
	}

	public void setPerInicio(String perInicio) {
		this.perInicio = perInicio;
	}

	public String getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(String fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public String getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(String fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getNumInforme() {
		return numInforme;
	}

	public void setNumInforme(String numInforme) {
		this.numInforme = numInforme;
	}

	public String getCodEstadoInforme() {
		return codEstadoInforme;
	}

	public void setCodEstadoInforme(String codEstadoInforme) {
		this.codEstadoInforme = codEstadoInforme;
	}

	public String getDesEstadoInforme() {
		return desEstadoInforme;
	}

	public void setDesEstadoInforme(String desEstadoInforme) {
		this.desEstadoInforme = desEstadoInforme;
	}

	public String getFechaIniAsignacion() {
		return fechaIniAsignacion;
	}

	public void setFechaIniAsignacion(String fechaIniAsignacion) {
		this.fechaIniAsignacion = fechaIniAsignacion;
	}

	public List<CheckElementBean> getInconsistencias() {
		return inconsistencias;
	}

	public void setInconsistencias(List<CheckElementBean> inconsistencias) {
		this.inconsistencias = inconsistencias;
	}

	public List<CheckElementBean> getTipoBienes() {
		return tipoBienes;
	}

	public void setTipoBienes(List<CheckElementBean> tipoBienes) {
		this.tipoBienes = tipoBienes;
	}

	
	public List<CheckElementBean> getRespInconsistencias() {
		return respInconsistencias;
	}

	public void setRespInconsistencias(List<CheckElementBean> respInconsistencias) {
		this.respInconsistencias = respInconsistencias;
	}

	public String getDesOtroIncosistencia() {
		return desOtroIncosistencia;
	}

	public void setDesOtroIncosistencia(String desOtroIncosistencia) {
		this.desOtroIncosistencia = desOtroIncosistencia;
	}

	public String getDesOtroBien() {
		return desOtroBien;
	}

	public void setDesOtroBien(String desOtroBien) {
		this.desOtroBien = desOtroBien;
	}

	public List<CheckElementBean> getBienesFiscalizados() {
		return bienesFiscalizados;
	}

	public void setBienesFiscalizados(List<CheckElementBean> bienesFiscalizados) {
		this.bienesFiscalizados = bienesFiscalizados;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<CheckElementBean> getActividades() {
		return actividades;
	}

	public void setActividades(List<CheckElementBean> actividades) {
		this.actividades = actividades;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	@Override
	public String toString() {
		return "ProgramacionBean [anioProgramacion=" + anioProgramacion + ", codEstadoPrograma=" + codEstadoPrograma
				+ ", codFuente=" + codFuente + ", codProceso=" + codProceso + ", codProgramador=" + codProgramador
				+ ", codSubEstadoProgram=" + codSubEstadoProgram + ", codTipoProgram=" + codTipoProgram
				+ ", codProgramaControl=" + codProgramaControl + ", desAlcance=" + desAlcance + ", desOtraFuente="
				+ desOtraFuente + ", desProgramacion=" + desProgramacion + ", desSusCancela=" + desSusCancela
				+ ", desEstadoProgram=" + desEstadoProgram + ", desFuente=" + desFuente + ", desProceso=" + desProceso
				+ ", desProgramaControl=" + desProgramaControl + ", desProgramador=" + desProgramador
				+ ", desSubEstprogram=" + desSubEstprogram + ", desTipoProgram=" + desTipoProgram + ", fecProgramacion="
				+ fecProgramacion + ", indCierre=" + indCierre + ", numInformeCancelacion=" + numInformeCancelacion
				+ ", numPlazoVerificacion=" + numPlazoVerificacion + ", numProgramaCorrel=" + numProgramaCorrel
				+ ", numProgramacion=" + numProgramacion + ", obsProgramacion=" + obsProgramacion + ", perFin=" + perFin
				+ ", perInicio=" + perInicio + ", fechaDesde=" + fechaDesde + ", fechaHasta=" + fechaHasta
				+ ", numInforme=" + numInforme + ", codEstadoInforme=" + codEstadoInforme + ", desEstadoInforme="
				+ desEstadoInforme + ", fecIniAsignacion=" + fechaIniAsignacion + ", inconsistencias=" + inconsistencias
				+ ", respInconsistencias=" + respInconsistencias + ", tipoBienes=" + tipoBienes
				+ ", bienesFiscalizados=" + bienesFiscalizados + ", actividades=" + actividades
				+ ", desOtroIncosistencia=" + desOtroIncosistencia + ", desOtroBien=" + desOtroBien + ", auditoriaBean="
				+ auditoriaBean + ", codProgramadorAdmin=" + codProgramadorAdmin + ", codEstInforme=" + codEstInforme
				+ ", nomProgramador=" + nomProgramador + ", nomProgramadorAdmin=" + nomProgramadorAdmin
				+ ", codTipoDocumentoIdent=" + codTipoDocumentoIdent + ", numDocumentoIdent=" + numDocumentoIdent
				+ ", codTipoOrden=" + codTipoOrden + ", CodTipoDocUsuario=" + CodTipoDocUsuario + "]";
	}

	public ArchivoBean getArchivoBean() {
		return archivoBean;
	}

	public void setArchivoBean(ArchivoBean archivoBean) {
		this.archivoBean = archivoBean;
	}

	public InformeSeleccionBean getInformeSeleccion() {
		return informeSeleccion;
	}

	public void setInformeSeleccion(InformeSeleccionBean informeSeleccion) {
		this.informeSeleccion = informeSeleccion;
	}

	public String getDesProgramadorAdministrativo() {
		return desProgramadorAdministrativo;
	}

	public void setDesProgramadorAdministrativo(String desProgramadorAdministrativo) {
		this.desProgramadorAdministrativo = desProgramadorAdministrativo;
	}

	public String getDesTipInterv() {
		return desTipInterv;
	}

	public void setDesTipInterv(String desTipInterv) {
		this.desTipInterv = desTipInterv;
	}

	public String getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(String numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public String getCodProgramadorAsignado() {
		return codProgramadorAsignado;
	}

	public void setCodProgramadorAsignado(String codProgramadorAsignado) {
		this.codProgramadorAsignado = codProgramadorAsignado;
	}

	public String getCodigoUnidadOrganica() {
		return codigoUnidadOrganica;
	}

	public void setCodigoUnidadOrganica(String codigoUnidadOrganica) {
		this.codigoUnidadOrganica = codigoUnidadOrganica;
	}
	
}
