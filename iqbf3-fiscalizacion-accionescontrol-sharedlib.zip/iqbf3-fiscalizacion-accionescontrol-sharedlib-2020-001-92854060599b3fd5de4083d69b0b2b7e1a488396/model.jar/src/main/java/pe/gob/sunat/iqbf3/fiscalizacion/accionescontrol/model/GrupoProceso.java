package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T8311GRUPO")
public class GrupoProceso extends Auditoria {

	 @Column(name = "COD_TIPO_PROCESO")
	 private String codTipoProceso;
	
	 @Column(name = "NOM_GRUPO")
	 private String nomGrupo;
	
	 @Id
	 @Column(name = "NUM_GRUPO")
	 private Long numGrupo;

	public String getCodTipoProceso() {
		return codTipoProceso;
	}

	public void setCodTipoProceso(String codTipoProceso) {
		this.codTipoProceso = codTipoProceso;
	}

	public String getNomGrupo() {
		return nomGrupo;
	}

	public void setNomGrupo(String nomGrupo) {
		this.nomGrupo = nomGrupo;
	}

	public Long getNumGrupo() {
		return numGrupo;
	}

	public void setNumGrupo(Long numGrupo) {
		this.numGrupo = numGrupo;
	}
	 
}
