package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10391ARCPROGRAM")
public class ArchivoProgramacion extends Auditoria {

	@Id
	 @Column(name = "NUM_ARC_PROGRAM")
	 private Long numArchivoProgram;

	 @Column(name = "NUM_ARC")
	 private Long numArchivo;
	 
	 @Column(name = "NUM_PROGRAMACION")
	 private Long numProgramacion;

	 
	public Long getNumArchivo() {
		return numArchivo;
	}

	public void setNumArchivo(Long numArchivo) {
		this.numArchivo = numArchivo;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public Long getNumArchivoProgram() {
		return numArchivoProgram;
	}

	public void setNumArchivoProgram(Long numArchivoProgram) {
		this.numArchivoProgram = numArchivoProgram;
	}
	 
	 
}
