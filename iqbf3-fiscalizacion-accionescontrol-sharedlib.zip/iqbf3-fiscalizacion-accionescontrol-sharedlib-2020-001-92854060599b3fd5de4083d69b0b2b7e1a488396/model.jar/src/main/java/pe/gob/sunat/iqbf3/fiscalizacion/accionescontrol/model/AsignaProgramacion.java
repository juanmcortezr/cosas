package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "T10392ASIGNPROGRAM")
public class AsignaProgramacion extends Auditoria {

	 @Column(name = "COD_PERS")
	 private String codProgramador;
	
	 @Column(name = "DES_REASIGNACION")
	 private String desReasignacion;
	
	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_FIN_ASIGNACION")
	 private Date fecFinAsignacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_ASIGNACION")
	 private Date fecInicioAsignacion;
	
	 @Column(name = "IND_TIP_ASIGNACION")
	 private String indTipAsignacion;
	
	 @Id
	 @Column(name = "NUM_ASIGNACION")
	 private Long numAsignacion;

	 @Column(name = "NUM_PROGRAMACION")
	 private Long numProgramacion;
	 
	 //
	 
	 @Transient
	 private String codPers;
	 
	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getCodProgramador() {
		return codProgramador;
	}

	public void setCodProgramador(String codProgramador) {
		this.codProgramador = codProgramador;
	}

	public String getDesReasignacion() {
		return desReasignacion;
	}

	public void setDesReasignacion(String desReasignacion) {
		this.desReasignacion = desReasignacion;
	}

	public Date getFecFinAsignacion() {
		return fecFinAsignacion;
	}

	public void setFecFinAsignacion(Date fecFinAsignacion) {
		this.fecFinAsignacion = fecFinAsignacion;
	}

	public Date getFecInicioAsignacion() {
		return fecInicioAsignacion;
	}

	public void setFecInicioAsignacion(Date fecInicioAsignacion) {
		this.fecInicioAsignacion = fecInicioAsignacion;
	}

	public String getIndTipAsignacion() {
		return indTipAsignacion;
	}

	public void setIndTipAsignacion(String indTipAsignacion) {
		this.indTipAsignacion = indTipAsignacion;
	}

	public Long getNumAsignacion() {
		return numAsignacion;
	}

	public void setNumAsignacion(Long numAsignacion) {
		this.numAsignacion = numAsignacion;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	

	 
}
