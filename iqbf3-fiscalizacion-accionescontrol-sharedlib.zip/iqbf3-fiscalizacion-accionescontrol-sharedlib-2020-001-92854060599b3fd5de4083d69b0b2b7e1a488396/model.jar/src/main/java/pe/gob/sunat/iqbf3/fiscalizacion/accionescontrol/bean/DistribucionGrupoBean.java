package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import com.sun.javafx.geom.transform.CanTransformVec3d;

public class DistribucionGrupoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codCargo;
	private	String	codPersonal;
	private	String	fecFin;
	private	String	fecInicio;
	private	Long	numDistribucionGrupo;
	private	int	numGrupo;
	private String nomAuditorApoyo;
	private String numRegistro;
	private String codTipoProceso;
	private String indTipAsignacion;
	private String codPers;
	private String nomProgramador;
	private String indEst;
	private Long numUsuarioPrograma;	
	private boolean seleccionado;
	private Long cantCarga;
	
	public Long getCantCarga() {
		return cantCarga;
	}

	public void setCantCarga(Long cantCarga) {
		this.cantCarga = cantCarga;
	}

	public boolean isSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}
	public DistribucionGrupoBean() {
		super();
	}

	public DistribucionGrupoBean(String codCargo, String codPersonal, String fecFin, String fecInicio,
			Long numDistribucionGrupo, int numGrupo, String nomAuditorApoyo, String codTipoProceso, String indTipAsignacion,
			String codPers, String nomProgramador) {
		super();
		this.codCargo = codCargo;
		this.codPersonal = codPersonal;
		this.fecFin = fecFin;
		this.fecInicio = fecInicio;
		this.numDistribucionGrupo = numDistribucionGrupo;
		this.numGrupo = numGrupo;
		this.nomAuditorApoyo = nomAuditorApoyo;
		this.codTipoProceso = codTipoProceso;
		this.indTipAsignacion = indTipAsignacion;
		this.codPers = codPers;
		this.nomProgramador = nomProgramador;
	}

	public String getNumRegistro() {
		return numRegistro;
	}

	public void setNumRegistro(String numRegistro) {
		this.numRegistro = numRegistro;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public String getNomProgramador() {
		return nomProgramador;
	}

	public void setNomProgramador(String nomProgramador) {
		this.nomProgramador = nomProgramador;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getIndTipAsignacion() {
		return indTipAsignacion;
	}

	public void setIndTipAsignacion(String indTipAsignacion) {
		this.indTipAsignacion = indTipAsignacion;
	}

	public String getCodTipoProceso() {
		return codTipoProceso;
	}

	public void setCodTipoProceso(String codTipoProceso) {
		this.codTipoProceso = codTipoProceso;
	}

	public String getNomAuditorApoyo() {
		return nomAuditorApoyo;
	}

	public void setNomAuditorApoyo(String nomAuditorApoyo) {
		this.nomAuditorApoyo = nomAuditorApoyo;
	}

	public String getCodCargo() {
		return codCargo;
	}

	public void setCodCargo(String codCargo) {
		this.codCargo = codCargo;
	}

	public String getCodPersonal() {
		return codPersonal;
	}

	public void setCodPersonal(String codPersonal) {
		this.codPersonal = codPersonal;
	}

	public String getFecFin() {
		return fecFin;
	}

	public void setFecFin(String fecFin) {
		this.fecFin = fecFin;
	}

	public String getFecInicio() {
		return fecInicio;
	}

	public void setFecInicio(String fecInicio) {
		this.fecInicio = fecInicio;
	}

	public Long getNumDistribucionGrupo() {
		return numDistribucionGrupo;
	}

	public void setNumDistribucionGrupo(Long numDistribucionGrupo) {
		this.numDistribucionGrupo = numDistribucionGrupo;
	}

	public int getNumGrupo() {
		return numGrupo;
	}

	public void setNumGrupo(int numGrupo) {
		this.numGrupo = numGrupo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
