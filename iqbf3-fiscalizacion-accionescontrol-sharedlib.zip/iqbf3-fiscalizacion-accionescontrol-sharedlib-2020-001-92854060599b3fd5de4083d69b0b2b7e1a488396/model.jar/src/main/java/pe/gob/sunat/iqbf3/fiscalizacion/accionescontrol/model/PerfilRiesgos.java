package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T8048PERRIE")
public class PerfilRiesgos implements Entidad {

	@EmbeddedId
	private PerfilRiesgosPK perfilRiesgosPk;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEC_CALCULO")
	private Date fecCalculo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEC_INIVIG")
	private Date fecInicioVigencia;

	@Column(name = "IND_CALCULO")
	private String indCalculo;

	@Column(name = "IND_NIVRIE")
	private Integer indNivrie;

	@Column(name = "NUM_SCOREGLOB")
	private Integer numScoreglobal;

	public Date getFecCalculo() {
		return fecCalculo;
	}

	public void setFecCalculo(Date fecCalculo) {
		this.fecCalculo = fecCalculo;
	}

	public Date getFecInicioVigencia() {
		return fecInicioVigencia;
	}

	public void setFecInicioVigencia(Date fecInicioVigencia) {
		this.fecInicioVigencia = fecInicioVigencia;
	}

	public String getIndCalculo() {
		return indCalculo;
	}

	public void setIndCalculo(String indCalculo) {
		this.indCalculo = indCalculo;
	}

	public Integer getIndNivrie() {
		return indNivrie;
	}

	public void setIndNivrie(Integer indNivrie) {
		this.indNivrie = indNivrie;
	}

	public Integer getNumScoreglobal() {
		return numScoreglobal;
	}

	public void setNumScoreglobal(Integer numScoreglobal) {
		this.numScoreglobal = numScoreglobal;
	}

	public PerfilRiesgosPK getPerfilRiesgosPk() {
		return perfilRiesgosPk;
	}

	public void setPerfilRiesgosPk(PerfilRiesgosPK perfilRiesgosPk) {
		this.perfilRiesgosPk = perfilRiesgosPk;
	}

}
