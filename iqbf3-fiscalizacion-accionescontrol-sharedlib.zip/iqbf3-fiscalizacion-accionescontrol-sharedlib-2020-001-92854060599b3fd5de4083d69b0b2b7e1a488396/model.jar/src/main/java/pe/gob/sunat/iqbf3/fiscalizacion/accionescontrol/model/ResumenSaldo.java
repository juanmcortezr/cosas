package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "T5642RSALDO")
public class ResumenSaldo extends Auditoria {

	@EmbeddedId
	private ResumenSaldoPK resumenSaldoPk;
	
	@Column(name = "CNT_CONSUMIDA")
	 private Double cantidadConsumida;
	
	 @Column(name = "CNT_DISPONIBLE")
	 private Double cantidadDisponible;
	
	 @Column(name = "FEC_FIN_CALC")
	 private String fecFinCalc;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_CALC")
	 private Date fecInicioCalculo;
	
	 @Column(name = "IND_INCONSISTENCIA")
	 private String indInconsistencia;
	
	 @Column(name = "NUM_CONFIRMA")
	 private Integer numConfirma;
	
	 @Column(name = "NUM_EXISTENCIA")
	 private Integer numExistencia;
	
	 @Transient
	 private Date fecFinvigencia;
	 @Transient
	 private String codEstado;
	 @Transient
	 private String codInsumo;
	 @Transient
	 private String numOrden;
	 @Transient
	 private Integer numVersionIns;
	 @Transient
	 private String codTipProd;
	 @Transient
	 private String codUm;
	 @Transient
	 private String codBienFisca;
	 @Transient
	 private String desNomProd;
	 @Transient
	 private String desNomComProd;
	 @Transient
	 private Double cntAutorizada;
	 @Transient
	 private Double cntDisponible;
	 @Transient
	 private Double cntConsumida;
	 @Transient
	 private BigDecimal porMaxIns;
	 @Transient
	 private BigDecimal porMinIns;
	 
	 @Transient
	 private Long cntSaldoNegativo;
	 
	 
	 @Transient
	 private Integer codTipobien;
	
	 @Transient
	 private Integer numRuc;
	
	 @Transient
	 private Integer numVersionRegistro;
	
	 @Transient
	 private Integer numReposicion;

	 @Transient
	 private String numPeriodo;

	 @Transient
	 private Integer numInsumoCabecera;
	 

	 
	 
	 
	public Integer getCodTipobien() {
		return codTipobien;
	}

	public void setCodTipobien(Integer codTipobien) {
		this.codTipobien = codTipobien;
	}

	public Integer getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(Integer numRuc) {
		this.numRuc = numRuc;
	}

	public Integer getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(Integer numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public Integer getNumReposicion() {
		return numReposicion;
	}

	public void setNumReposicion(Integer numReposicion) {
		this.numReposicion = numReposicion;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public Integer getNumInsumoCabecera() {
		return numInsumoCabecera;
	}

	public void setNumInsumoCabecera(Integer numInsumoCabecera) {
		this.numInsumoCabecera = numInsumoCabecera;
	}

	public Long getCntSaldoNegativo() {
		return cntSaldoNegativo;
	}

	public void setCntSaldoNegativo(Long cntSaldoNegativo) {
		this.cntSaldoNegativo = cntSaldoNegativo;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}

	public Integer getNumVersionIns() {
		return numVersionIns;
	}

	public void setNumVersionIns(Integer numVersionIns) {
		this.numVersionIns = numVersionIns;
	}

	public String getCodTipProd() {
		return codTipProd;
	}

	public void setCodTipProd(String codTipProd) {
		this.codTipProd = codTipProd;
	}

	public String getCodUm() {
		return codUm;
	}

	public void setCodUm(String codUm) {
		this.codUm = codUm;
	}

	public String getCodBienFisca() {
		return codBienFisca;
	}

	public void setCodBienFisca(String codBienFisca) {
		this.codBienFisca = codBienFisca;
	}

	public String getDesNomProd() {
		return desNomProd;
	}

	public void setDesNomProd(String desNomProd) {
		this.desNomProd = desNomProd;
	}

	public String getDesNomComProd() {
		return desNomComProd;
	}

	public void setDesNomComProd(String desNomComProd) {
		this.desNomComProd = desNomComProd;
	}

	public Double getCntAutorizada() {
		return cntAutorizada;
	}

	public void setCntAutorizada(Double cntAutorizada) {
		this.cntAutorizada = cntAutorizada;
	}

	public Double getCntDisponible() {
		return cntDisponible;
	}

	public void setCntDisponible(Double cntDisponible) {
		this.cntDisponible = cntDisponible;
	}

	public Double getCntConsumida() {
		return cntConsumida;
	}

	public void setCntConsumida(Double cntConsumida) {
		this.cntConsumida = cntConsumida;
	}

	public BigDecimal getPorMaxIns() {
		return porMaxIns;
	}

	public void setPorMaxIns(BigDecimal porMaxIns) {
		this.porMaxIns = porMaxIns;
	}

	public BigDecimal getPorMinIns() {
		return porMinIns;
	}

	public void setPorMinIns(BigDecimal porMinIns) {
		this.porMinIns = porMinIns;
	}

	public String getCodInsumo() {
		return codInsumo;
	}

	public void setCodInsumo(String codInsumo) {
		this.codInsumo = codInsumo;
	}

	public Date getFecFinvigencia() {
		return fecFinvigencia;
	}

	public void setFecFinvigencia(Date fecFinvigencia) {
		this.fecFinvigencia = fecFinvigencia;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public ResumenSaldoPK getResumenSaldoPk() {
		return resumenSaldoPk;
	}

	public void setResumenSaldoPk(ResumenSaldoPK resumenSaldoPk) {
		this.resumenSaldoPk = resumenSaldoPk;
	}

	public Double getCantidadConsumida() {
		return cantidadConsumida;
	}

	public void setCantidadConsumida(Double cantidadConsumida) {
		this.cantidadConsumida = cantidadConsumida;
	}

	public Double getCantidadDisponible() {
		return cantidadDisponible;
	}

	public void setCantidadDisponible(Double cantidadDisponible) {
		this.cantidadDisponible = cantidadDisponible;
	}

	public String getFecFinCalc() {
		return fecFinCalc;
	}

	public void setFecFinCalc(String fecFinCalc) {
		this.fecFinCalc = fecFinCalc;
	}

	public Date getFecInicioCalculo() {
		return fecInicioCalculo;
	}

	public void setFecInicioCalculo(Date fecInicioCalculo) {
		this.fecInicioCalculo = fecInicioCalculo;
	}

	public String getIndInconsistencia() {
		return indInconsistencia;
	}

	public void setIndInconsistencia(String indInconsistencia) {
		this.indInconsistencia = indInconsistencia;
	}

	public Integer getNumConfirma() {
		return numConfirma;
	}

	public void setNumConfirma(Integer numConfirma) {
		this.numConfirma = numConfirma;
	}

	public Integer getNumExistencia() {
		return numExistencia;
	}

	public void setNumExistencia(Integer numExistencia) {
		this.numExistencia = numExistencia;
	}
	
}
