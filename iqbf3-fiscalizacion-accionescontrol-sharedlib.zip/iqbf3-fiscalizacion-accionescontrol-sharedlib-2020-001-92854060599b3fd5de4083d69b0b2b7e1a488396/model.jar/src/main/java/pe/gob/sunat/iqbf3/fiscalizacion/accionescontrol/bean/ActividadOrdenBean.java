package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class ActividadOrdenBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codActividad;
	private	String	desActividad;
	private	int	numActividadResultado;
	private	int	numOrden;
	private String indSeleccionado;
	
	private String indDel;
	private String indEst;
	private AuditoriaBean auditoriaBean;
	
	public ActividadOrdenBean() {
		super();
	}

	public ActividadOrdenBean(String codActividad, String desActividad, int numActividadResultado, int numOrden) {
		super();
		this.codActividad = codActividad;
		this.desActividad = desActividad;
		this.numActividadResultado = numActividadResultado;
		this.numOrden = numOrden;
	}

	public String getCodActividad() {
		return codActividad;
	}

	public void setCodActividad(String codActividad) {
		this.codActividad = codActividad;
	}

	public String getDesActividad() {
		return desActividad;
	}

	public void setDesActividad(String desActividad) {
		this.desActividad = desActividad;
	}

	public int getNumActividadResultado() {
		return numActividadResultado;
	}

	public void setNumActividadResultado(int numActividadResultado) {
		this.numActividadResultado = numActividadResultado;
	}

	public int getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(int numOrden) {
		this.numOrden = numOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIndSeleccionado() {
		return indSeleccionado;
	}

	public void setIndSeleccionado(String indSeleccionado) {
		this.indSeleccionado = indSeleccionado;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}	
	
	
}
