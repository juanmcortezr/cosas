package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "T10414MOVSOLIC")
public class MovimientoSolicitud extends Auditoria {

	 @Column(name = "COD_PERS_MOV")
	 private String codPersMov;
	
	 @Column(name = "DES_MOT_DEVOLUCION")
	 private String desMotivoAsignacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_MOVIMIENTO")
	 private Date fecMovimiento;
	
	 @Id
	 @Column(name = "NUM_MOV_PROG")
	 private Long numMovimientoPrograma;

	 @Column(name = "cod_cargo")
	 private String codCargo;

	@Column(name = "NUM_SOLIC_PROG")
	private Long numSolicitud;

	public String getCodPersMov() {
		return codPersMov;
	}

	public void setCodPersMov(String codPersMov) {
		this.codPersMov = codPersMov;
	}

	public String getDesMotivoAsignacion() {
		return desMotivoAsignacion;
	}

	public void setDesMotivoAsignacion(String desMotivoAsignacion) {
		this.desMotivoAsignacion = desMotivoAsignacion;
	}

	public Date getFecMovimiento() {
		return fecMovimiento;
	}

	public void setFecMovimiento(Date fecMovimiento) {
		this.fecMovimiento = fecMovimiento;
	}

	public Long getNumMovimientoPrograma() {
		return numMovimientoPrograma;
	}

	public void setNumMovimientoPrograma(Long numMovimientoPrograma) {
		this.numMovimientoPrograma = numMovimientoPrograma;
	}

	public String getCodCargo() {
		return codCargo;
	}

	public void setCodCargo(String codCargo) {
		this.codCargo = codCargo;
	}

	public Long getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Long numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

}
