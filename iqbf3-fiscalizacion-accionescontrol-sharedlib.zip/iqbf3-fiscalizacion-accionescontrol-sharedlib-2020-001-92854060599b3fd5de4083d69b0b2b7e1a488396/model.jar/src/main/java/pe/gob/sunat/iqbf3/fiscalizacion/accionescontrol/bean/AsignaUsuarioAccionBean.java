package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class AsignaUsuarioAccionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codCargo;
	private	String	codAuditor;
	private	String	desCargo;
	private	String	fecFinAsignacion;
	private	String	fecInicioAsignacion;
	private	String	indTipAsignacion;
	private	String	nomAuditor;
	private	Long	numAsignacionAccion;
	private	Long	numUsuarioPrograma;
	private AuditoriaBean auditoriaBean;
	private String nomAuditorApoyo;
	private String codPers;
	private String indEst;
	private String codUsuCrea;
	private String dirIpusucrea;
	private Boolean seleccionado ;//extra para saber si esta seleccionado
	private String numGrupo;
	private Long cntCarga;
	private String fechaIniAsignacion;
	private Long numInformeSeleccion;
	private Long numProgramacion;
	
	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	private List<DistribucionGrupoBean> listaAsignaUsuario;

	public List<DistribucionGrupoBean> getListaAsignaUsuario() {
		return listaAsignaUsuario;
	}

	public void setListaAsignaUsuario(List<DistribucionGrupoBean> listaAsignaUsuario) {
		this.listaAsignaUsuario = listaAsignaUsuario;
	}

	public Long getNumInformeSeleccion() {
		return numInformeSeleccion;
	}

	public void setNumInformeSeleccion(Long numInformeSeleccion) {
		this.numInformeSeleccion = numInformeSeleccion;
	}

	public AsignaUsuarioAccionBean() {
		super();
	}

	public AsignaUsuarioAccionBean(String codCargo, String codAuditor, String desCargo, String fecFinAsignacion,
			String fecInicioAsignacion, String indTipAsignacion, String nomAuditor, Long numAsignacionAccion,
			Long numUsuarioPrograma) {
		super();
		this.codCargo = codCargo;
		this.codAuditor = codAuditor;
		this.desCargo = desCargo;
		this.fecFinAsignacion = fecFinAsignacion;
		this.fecInicioAsignacion = fecInicioAsignacion;
		this.indTipAsignacion = indTipAsignacion;
		this.nomAuditor = nomAuditor;
		this.numAsignacionAccion = numAsignacionAccion;
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	
	public String getFechaIniAsignacion() {
		return fechaIniAsignacion;
	}

	public void setFechaIniAsignacion(String fechaIniAsignacion) {
		this.fechaIniAsignacion = fechaIniAsignacion;
	}

	public String getDirIpusucrea() {
		return dirIpusucrea;
	}

	public void setDirIpusucrea(String dirIpusucrea) {
		this.dirIpusucrea = dirIpusucrea;
	}

	public String getCodUsuCrea() {
		return codUsuCrea;
	}

	public void setCodUsuCrea(String codUsuCrea) {
		this.codUsuCrea = codUsuCrea;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getNomAuditorApoyo() {
		return nomAuditorApoyo;
	}

	public void setNomAuditorApoyo(String nomAuditorApoyo) {
		this.nomAuditorApoyo = nomAuditorApoyo;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public String getCodCargo() {
		return codCargo;
	}

	public void setCodCargo(String codCargo) {
		this.codCargo = codCargo;
	}

	public String getCodAuditor() {
		return codAuditor;
	}

	public void setCodAuditor(String codAuditor) {
		this.codAuditor = codAuditor;
	}

	public String getDesCargo() {
		return desCargo;
	}

	public void setDesCargo(String desCargo) {
		this.desCargo = desCargo;
	}

	public String getFecFinAsignacion() {
		return fecFinAsignacion;
	}

	public void setFecFinAsignacion(String fecFinAsignacion) {
		this.fecFinAsignacion = fecFinAsignacion;
	}

	public String getFecInicioAsignacion() {
		return fecInicioAsignacion;
	}

	public void setFecInicioAsignacion(String fecInicioAsignacion) {
		this.fecInicioAsignacion = fecInicioAsignacion;
	}

	public String getIndTipAsignacion() {
		return indTipAsignacion;
	}

	public void setIndTipAsignacion(String indTipAsignacion) {
		this.indTipAsignacion = indTipAsignacion;
	}

	public String getNomAuditor() {
		return nomAuditor;
	}

	public void setNomAuditor(String nomAuditor) {
		this.nomAuditor = nomAuditor;
	}

	public Long getNumAsignacionAccion() {
		return numAsignacionAccion;
	}

	public void setNumAsignacionAccion(Long numAsignacionAccion) {
		this.numAsignacionAccion = numAsignacionAccion;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Boolean getSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(Boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public String getNumGrupo() {
		return numGrupo;
	}

	public void setNumGrupo(String numGrupo) {
		this.numGrupo = numGrupo;
	}

	public Long getCntCarga() {
		return cntCarga;
	}

	public void setCntCarga(Long cntCarga) {
		this.cntCarga = cntCarga;
	}		
	
}
