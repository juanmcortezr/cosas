package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TareoAuditor;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class OrdenAccionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private	int	anioOrden;
	private	String	codEstadoOrden;
	private	String	codRecomendacion;
	private	String	codResultadoInconsistenciaDef;
	private String  desResultadoInconsistenciaDef;
	private	String	codResultadoInconsistenciaPre;
	private	String	codResulOrden;
	private	String	codTipoOrden;
	private	String	codUnidadOrganica;
	private	String	desRecomendacion;
	private	String	desProgCtrl;
	private	String	desSusCancela;
	private	String	desSusDevolucion;
	private	String	desSusNoaccion;
	private	String	desSusResul;
	private	String	desDepartamento;
	private	String	desDistrito;
	private	String	desEstadoOrden;
	private	String	desOrigen;
	private	String	desProvincia;
	private	String	desResulInconsis;
	private	String	desResulOrden;
	private	String	codTipoDocumentoIdent;
	private	String	desTipoDocumentoIdent;
	private	String	desTipOrden;
	private	String	desTipoRecomendacion;
	private	String	desUnidadOrganica;
	private	String	fecAsigOrden;
	private	String	fecCancelacion;
	private	String	fecDerivacion;
	private	String	fecInicioCaso;
	private	String	fecInicioCasoNuevo;
	private	String	fecOrden;
	private	String	fecPrimeraVisiat;
	private	String	fecSegundaVisit;
	private	String	fecSolicProrroga;
	private	String	indBloqDjro;
	private	String	indPrimeraVisit;
	private	String	indRealizoAccion;
	private	String	indSegundaVisit;
	private	String	indSolicProrroga;
	private	Integer	numCorrel;
	private	Long	numOrden;
	private	Long	numUsuarioPrograma;
	private	String	obsResultado;
	
	//CAMPOS PARA EL FILTRO
	private String fecAsigIni;
	
	private String fecAsigFin;
	
	private String codTipDocIdent;
	
	private String numInforSelec;
	
	private String numDocAccion;
	
	private	ArchivoBean	archivoBean;
	
	private AuditoriaBean auditoriaBean;
	private String fechaDesde;
	private String fechaHasta;
	private Long numProgramacion;
	 private String nomApeUsuario;
	 private String desDenominacion;
	 private Long informeNumCorrel;
	 private Integer informeAnio;
	 private String informeCodUUOO;
	 private String codTipAccion;
	 private String desTipAccion;
	 private String numDocumentoOrden;
	 private String numInfoResul;
	 
	 
	private List<OrdenAccionBean> listOrden;
	private List<DetalleResultadoOrdenBean> lstDetalleResultOrden;
	private List<DocumentoOrdenBean> lstDocumentosOrden;
	private List<TareoAuditorBean> lstTareoAuditor;
	private List<SuspensionOrdenBean> lstSuspenOrden;
	private List<ActividadOrdenBean> lstActividadOrden;
	
	
	//PARA FILTRO BUSQUEDA
	private String codTipoDocumentoIdentif;
	private String desTipoDocumentoIdentif;
	
	private String numDocumentoIdentif;
	
	private String nomApellidoUsuario;
	
	private Integer numProgramaCorrel;
	
	private String codProgCtrl;
	
	private Integer anioInforme;
	
	private String codTipoAccion;
	
	private String numDocumento;
	
	private String numDoc;
	
	private String desAcronimo;
	
	private String numOrdenAccion;
	
	private String desProgControl;
	
	private String desInformeSelecc;
	
	private String desTipoAccion;
	
	// FILTROS PARA OBTENER DATOS ORDEN
	private Integer numCorrelDoc;
	
	private Integer annDoc;
	
	private String codUuooDoc;
	
	private String codEstadoRegistro;
	
	private String codClase;
	
	private String desTipSigOrden;
	
	private String desEstadoRegistro;
	
	private String desResultadoInconsistencia;
	
	private String codUnidadOrganicaInforme;
	
	private String fecPrimeraVisit;
	
	// FILTRO PARA DETALLE INCONSISTENCIAS
	private String codEstadoUsuario;
	
	private String perInicio;

	private String perFin;
	
	private Date fecCrea;
	
	private Long numDocumentoAccion;
	
	private String numDocumentoUsuario;
	
	//FILTRO PARA CONTACTO ORDEN
	private List<ContactoOrdenBean> listaContactoOrden;
	private String codOrigen;
	
	private List<TipoInconsistenciaOrdenBean> lstInconsistencia;
	
	private String codCargo;
	
	private String numOrdenUnion;
	
	private String seleccionado;	
	
	// LISTA DE OTROS DOCUMENTOS
	private List<DocumentoOrdenBean> listaOtrosDocumentos;
	
	private String numInformeUnion;
	
	public String getNumInformeUnion() {
		return numInformeUnion;
	}

	public void setNumInformeUnion(String numInformeUnion) {
		this.numInformeUnion = numInformeUnion;
	}

	public String getSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(String seleccionado) {
		this.seleccionado = seleccionado;
	}

	public String getNumOrdenUnion() {
		return numOrdenUnion;
	}

	public void setNumOrdenUnion(String numOrdenUnion) {
		this.numOrdenUnion = numOrdenUnion;
	}

	public String getCodCargo() {
		return codCargo;
	}

	public void setCodCargo(String codCargo) {
		this.codCargo = codCargo;
	}

	public String getNumDocumentoUsuario() {
		return numDocumentoUsuario;
	}

	public void setNumDocumentoUsuario(String numDocumentoUsuario) {
		this.numDocumentoUsuario = numDocumentoUsuario;
	}

	public List<OrdenAccionBean> getListOrden() {
		return listOrden;
	}
	
	public void setListNumOrden(List<OrdenAccionBean> listOrden) {
		this.listOrden = listOrden;
	}

	public ArchivoBean getArchivoBean() {
		return archivoBean;
	}

	public void setArchivoBean(ArchivoBean archivoBean) {
		this.archivoBean = archivoBean;
	}

	//para filtros
	private String numDocIdent;
	private String nomApelAuditor;
	private ArrayList<String> EstadosOrden;
	
	public ArrayList<String> getEstadosOrden() {
		return EstadosOrden;
	}

	public void setEstadosOrden(ArrayList<String> estadosOrden) {
		EstadosOrden = estadosOrden;
	}

	public String getNumDocIdent() {
		return numDocIdent;
	}

	public void setNumDocIdent(String numDocIdent) {
		this.numDocIdent = numDocIdent;
	}

	public String getNomApelAuditor() {
		return nomApelAuditor;
	}

	public void setNomApelAuditor(String nomApelAuditor) {
		this.nomApelAuditor = nomApelAuditor;
	}

	public OrdenAccionBean() {
		super();
	}

	public OrdenAccionBean(int anioOrden, String codEstadoOrden, String codRecomendacion,
			String codResultadoInconsistenciaDef, String codResultadoInconsistenciaPre, String codResulOrden,
			String codTipoOrden, String codUnidadOrganica, String desRecomendacion, String desSusCancela,
			String desSusDevolucion, String desSusNoaccion, String desSusResul, String desDepartamento,
			String desDistrito, String desEstadoOrden, String desOrigen, String desProvincia, String desResulInconsis,
			String desResulOrden, String desTipoDocumentoIdent, String desTipOrden, String desTipoRecomendacion,
			String desUnidadOrganica, String fecAsigOrden, String fecCancelacion, String fecDerivacion,
			String fecInicioCaso, String fecInicioCasoNuevo, String fecOrden, String fecPrimeraVisiat,
			String fecSegundaVisit, String fecSolicProrroga, String indBloqDjro, String indPrimeraVisit,
			String indRealizoAccion, String indSegundaVisit, String indSolicProrroga, Integer numCorrel, Long numOrden,
			Long numUsuarioPrograma, String obsResultado, String fecAsigIni, String fecAsigFin, String codTipDocIdent, String numInforSelec,
			String numDocAccion, String codProgCtrl, String codTipoDocumentoIdentif, String numDocumentoIdentif, String nomApellidoUsuario,
			Integer numProgramaCorrel, String desDenominacion, Integer anioInforme, String codTipoAccion, String numDocumento, String numDoc,
			String desAcronimo, String numOrdenAccion, String desProgControl, String desInformeSelecc, String desTipoAccion, Long numProgramacion,
			Integer numCorrelDoc, Integer annDoc, String codUuooDoc, String codEstadoRegistro, String codClase, String desTipSigOrden,
			String desEstadoRegistro, String desResultadoInconsistencia, String codUnidadOrganicaInforme, String codEstadoUsuario, String perInicio,
			String perFin, Date fecCrea, String fecPrimeraVisit) {
		super();
		this.anioOrden = anioOrden;
		this.codEstadoOrden = codEstadoOrden;
		this.codRecomendacion = codRecomendacion;
		this.codResultadoInconsistenciaDef = codResultadoInconsistenciaDef;
		this.codResultadoInconsistenciaPre = codResultadoInconsistenciaPre;
		this.codResulOrden = codResulOrden;
		this.codTipoOrden = codTipoOrden;
		this.codUnidadOrganica = codUnidadOrganica;
		this.desRecomendacion = desRecomendacion;
		this.desSusCancela = desSusCancela;
		this.desSusDevolucion = desSusDevolucion;
		this.desSusNoaccion = desSusNoaccion;
		this.desSusResul = desSusResul;
		this.desDepartamento = desDepartamento;
		this.desDistrito = desDistrito;
		this.desEstadoOrden = desEstadoOrden;
		this.desOrigen = desOrigen;
		this.desProvincia = desProvincia;
		this.desResulInconsis = desResulInconsis;
		this.desResulOrden = desResulOrden;
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
		this.desTipOrden = desTipOrden;
		this.desTipoRecomendacion = desTipoRecomendacion;
		this.desUnidadOrganica = desUnidadOrganica;
		this.fecAsigOrden = fecAsigOrden;
		this.fecCancelacion = fecCancelacion;
		this.fecDerivacion = fecDerivacion;
		this.fecInicioCaso = fecInicioCaso;
		this.fecInicioCasoNuevo = fecInicioCasoNuevo;
		this.fecOrden = fecOrden;
		this.fecPrimeraVisiat = fecPrimeraVisiat;
		this.fecSegundaVisit = fecSegundaVisit;
		this.fecSolicProrroga = fecSolicProrroga;
		this.indBloqDjro = indBloqDjro;
		this.indPrimeraVisit = indPrimeraVisit;
		this.indRealizoAccion = indRealizoAccion;
		this.indSegundaVisit = indSegundaVisit;
		this.indSolicProrroga = indSolicProrroga;
		this.numCorrel = numCorrel;
		this.numOrden = numOrden;
		this.numUsuarioPrograma = numUsuarioPrograma;
		this.obsResultado = obsResultado;
		this.fecAsigIni = fecAsigIni;
		this.fecAsigFin = fecAsigFin;
		this.codTipDocIdent = codTipDocIdent;
		this.numInforSelec = numInforSelec;
		this.numDocAccion = numDocAccion;
		this.codProgCtrl = codProgCtrl;
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
		this.numDocumentoIdentif = numDocumentoIdentif;
		this.nomApellidoUsuario = nomApellidoUsuario;
		this.numProgramaCorrel = numProgramaCorrel;
		this.desDenominacion = desDenominacion;
		this.anioInforme = anioInforme;
		this.codTipoAccion = codTipoAccion;
		this.numDocumento = numDocumento;
		this.numDoc = numDoc;
		this.desAcronimo = desAcronimo;
		this.numOrdenAccion = numOrdenAccion;
		this.desProgControl = desProgControl;
		this.desInformeSelecc = desInformeSelecc;
		this.desTipoAccion = desTipoAccion;
		this.numProgramacion = numProgramacion;
		this.numCorrelDoc = numCorrelDoc;
		this.annDoc = annDoc;
		this.codUuooDoc = codUuooDoc;
		this.codEstadoRegistro = codEstadoRegistro;
		this.codClase = codClase;
		this.desTipSigOrden = desTipSigOrden;
		this.desEstadoRegistro = desEstadoRegistro;
		this.desResultadoInconsistencia = desResultadoInconsistencia;
		this.codUnidadOrganicaInforme = codUnidadOrganicaInforme;
		this.codEstadoUsuario = codEstadoUsuario;
		this.perInicio = perInicio;
		this.perFin = perFin;
		this.fecCrea = fecCrea;
		this.fecPrimeraVisit = fecPrimeraVisit;
	}

	public int getAnioOrden() {
		return anioOrden;
	}

	public void setAnioOrden(int anioOrden) {
		this.anioOrden = anioOrden;
	}

	public String getCodEstadoOrden() {
		return codEstadoOrden;
	}

	public void setCodEstadoOrden(String codEstadoOrden) {
		this.codEstadoOrden = codEstadoOrden;
	}

	public String getCodRecomendacion() {
		return codRecomendacion;
	}

	public void setCodRecomendacion(String codRecomendacion) {
		this.codRecomendacion = codRecomendacion;
	}

	public String getCodResultadoInconsistenciaDef() {
		return codResultadoInconsistenciaDef;
	}

	public void setCodResultadoInconsistenciaDef(String codResultadoInconsistenciaDef) {
		this.codResultadoInconsistenciaDef = codResultadoInconsistenciaDef;
	}

	public String getCodResultadoInconsistenciaPre() {
		return codResultadoInconsistenciaPre;
	}

	public void setCodResultadoInconsistenciaPre(String codResultadoInconsistenciaPre) {
		this.codResultadoInconsistenciaPre = codResultadoInconsistenciaPre;
	}

	public String getCodResulOrden() {
		return codResulOrden;
	}

	public void setCodResulOrden(String codResulOrden) {
		this.codResulOrden = codResulOrden;
	}

	public String getCodTipoOrden() {
		return codTipoOrden;
	}

	public void setCodTipoOrden(String codTipoOrden) {
		this.codTipoOrden = codTipoOrden;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public String getDesRecomendacion() {
		return desRecomendacion;
	}

	public void setDesRecomendacion(String desRecomendacion) {
		this.desRecomendacion = desRecomendacion;
	}

	public String getDesSusCancela() {
		return desSusCancela;
	}

	public void setDesSusCancela(String desSusCancela) {
		this.desSusCancela = desSusCancela;
	}

	public String getDesSusDevolucion() {
		return desSusDevolucion;
	}

	public void setDesSusDevolucion(String desSusDevolucion) {
		this.desSusDevolucion = desSusDevolucion;
	}

	public String getDesSusNoaccion() {
		return desSusNoaccion;
	}

	public void setDesSusNoaccion(String desSusNoaccion) {
		this.desSusNoaccion = desSusNoaccion;
	}

	public String getDesSusResul() {
		return desSusResul;
	}

	public void setDesSusResul(String desSusResul) {
		this.desSusResul = desSusResul;
	}

	public String getDesDepartamento() {
		return desDepartamento;
	}

	public void setDesDepartamento(String desDepartamento) {
		this.desDepartamento = desDepartamento;
	}

	public String getDesDistrito() {
		return desDistrito;
	}

	public void setDesDistrito(String desDistrito) {
		this.desDistrito = desDistrito;
	}

	public String getDesEstadoOrden() {
		return desEstadoOrden;
	}

	public void setDesEstadoOrden(String desEstadoOrden) {
		this.desEstadoOrden = desEstadoOrden;
	}

	public String getDesOrigen() {
		return desOrigen;
	}

	public void setDesOrigen(String desOrigen) {
		this.desOrigen = desOrigen;
	}

	public String getDesProvincia() {
		return desProvincia;
	}

	public void setDesProvincia(String desProvincia) {
		this.desProvincia = desProvincia;
	}

	public String getDesResulInconsis() {
		return desResulInconsis;
	}

	public void setDesResulInconsis(String desResulInconsis) {
		this.desResulInconsis = desResulInconsis;
	}

	public String getDesResulOrden() {
		return desResulOrden;
	}

	public void setDesResulOrden(String desResulOrden) {
		this.desResulOrden = desResulOrden;
	}

	public String getDesTipoDocumentoIdent() {
		return desTipoDocumentoIdent;
	}

	public void setDesTipoDocumentoIdent(String desTipoDocumentoIdent) {
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
	}

	public String getDesTipOrden() {
		return desTipOrden;
	}

	public void setDesTipOrden(String desTipOrden) {
		this.desTipOrden = desTipOrden;
	}

	public String getDesTipoRecomendacion() {
		return desTipoRecomendacion;
	}

	public void setDesTipoRecomendacion(String desTipoRecomendacion) {
		this.desTipoRecomendacion = desTipoRecomendacion;
	}

	public String getDesUnidadOrganica() {
		return desUnidadOrganica;
	}

	public void setDesUnidadOrganica(String desUnidadOrganica) {
		this.desUnidadOrganica = desUnidadOrganica;
	}

	public String getFecAsigOrden() {
		return fecAsigOrden;
	}

	public void setFecAsigOrden(String fecAsigOrden) {
		this.fecAsigOrden = fecAsigOrden;
	}

	public String getFecCancelacion() {
		return fecCancelacion;
	}

	public void setFecCancelacion(String fecCancelacion) {
		this.fecCancelacion = fecCancelacion;
	}

	public String getFecDerivacion() {
		return fecDerivacion;
	}

	public void setFecDerivacion(String fecDerivacion) {
		this.fecDerivacion = fecDerivacion;
	}

	public String getFecInicioCaso() {
		return fecInicioCaso;
	}

	public void setFecInicioCaso(String fecInicioCaso) {
		this.fecInicioCaso = fecInicioCaso;
	}

	public String getFecInicioCasoNuevo() {
		return fecInicioCasoNuevo;
	}

	public void setFecInicioCasoNuevo(String fecInicioCasoNuevo) {
		this.fecInicioCasoNuevo = fecInicioCasoNuevo;
	}

	public String getFecOrden() {
		return fecOrden;
	}

	public void setFecOrden(String fecOrden) {
		this.fecOrden = fecOrden;
	}

	public String getFecPrimeraVisiat() {
		return fecPrimeraVisiat;
	}

	public void setFecPrimeraVisiat(String fecPrimeraVisiat) {
		this.fecPrimeraVisiat = fecPrimeraVisiat;
	}

	public String getFecSegundaVisit() {
		return fecSegundaVisit;
	}

	public void setFecSegundaVisit(String fecSegundaVisit) {
		this.fecSegundaVisit = fecSegundaVisit;
	}

	public String getFecSolicProrroga() {
		return fecSolicProrroga;
	}

	public void setFecSolicProrroga(String fecSolicProrroga) {
		this.fecSolicProrroga = fecSolicProrroga;
	}

	public String getIndBloqDjro() {
		return indBloqDjro;
	}

	public void setIndBloqDjro(String indBloqDjro) {
		this.indBloqDjro = indBloqDjro;
	}

	public String getIndPrimeraVisit() {
		return indPrimeraVisit;
	}

	public void setIndPrimeraVisit(String indPrimeraVisit) {
		this.indPrimeraVisit = indPrimeraVisit;
	}

	public String getIndRealizoAccion() {
		return indRealizoAccion;
	}

	public void setIndRealizoAccion(String indRealizoAccion) {
		this.indRealizoAccion = indRealizoAccion;
	}

	public String getIndSegundaVisit() {
		return indSegundaVisit;
	}

	public void setIndSegundaVisit(String indSegundaVisit) {
		this.indSegundaVisit = indSegundaVisit;
	}

	public String getIndSolicProrroga() {
		return indSolicProrroga;
	}

	public void setIndSolicProrroga(String indSolicProrroga) {
		this.indSolicProrroga = indSolicProrroga;
	}

	public Integer getNumCorrel() {
		return numCorrel;
	}

	public void setNumCorrel(Integer numCorrel) {
		this.numCorrel = numCorrel;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public String getObsResultado() {
		return obsResultado;
	}

	public void setObsResultado(String obsResultado) {
		this.obsResultado = obsResultado;
	}
	
	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public String getFecAsigIni() {
		return fecAsigIni;
	}

	public void setFecAsigIni(String fecAsigIni) {
		this.fecAsigIni = fecAsigIni;
	}

	public String getFecAsigFin() {
		return fecAsigFin;
	}

	public void setFecAsigFin(String fecAsigFin) {
		this.fecAsigFin = fecAsigFin;
	}

	public String getCodTipDocIdent() {
		return codTipDocIdent;
	}

	public void setCodTipDocIdent(String codTipDocIdent) {
		this.codTipDocIdent = codTipDocIdent;
	}
	
	public String getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(String fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public String getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(String fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getCodTipoDocumentoIdent() {
		return codTipoDocumentoIdent;
	}

	public void setCodTipoDocumentoIdent(String codTipoDocumentoIdent) {
		this.codTipoDocumentoIdent = codTipoDocumentoIdent;
	}

	public String getNumInforSelec() {
		return numInforSelec;
	}

	public void setNumInforSelec(String numInforSelec) {
		this.numInforSelec = numInforSelec;
	}

	public String getNumDocAccion() {
		return numDocAccion;
	}

	public void setNumDocAccion(String numDocAccion) {
		this.numDocAccion = numDocAccion;
	}

	public String getCodProgCtrl() {
		return codProgCtrl;
	}

	public void setCodProgCtrl(String codProgCtrl) {
		this.codProgCtrl = codProgCtrl;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public String getNomApellidoUsuario() {
		return nomApellidoUsuario;
	}

	public void setNomApellidoUsuario(String nomApellidoUsuario) {
		this.nomApellidoUsuario = nomApellidoUsuario;
	}

	public Integer getNumProgramaCorrel() {
		return numProgramaCorrel;
	}

	public void setNumProgramaCorrel(Integer numProgramaCorrel) {
		this.numProgramaCorrel = numProgramaCorrel;
	}
	
	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public String getNomApeUsuario() {
		return nomApeUsuario;
	}

	public void setNomApeUsuario(String nomApeUsuario) {
		this.nomApeUsuario = nomApeUsuario;
	}

	public String getDesDenominacion() {
		return desDenominacion;
	}

	public void setDesDenominacion(String desDenominacion) {
		this.desDenominacion = desDenominacion;
	}

	public Integer getAnioInforme() {
		return anioInforme;
	}

	public void setAnioInforme(Integer anioInforme) {
		this.anioInforme = anioInforme;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public String getNumDoc() {
		return numDoc;
	}

	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}

	public String getDesAcronimo() {
		return desAcronimo;
	}

	public void setDesAcronimo(String desAcronimo) {
		this.desAcronimo = desAcronimo;
	}

	public String getNumOrdenAccion() {
		return numOrdenAccion;
	}

	public void setNumOrdenAccion(String numOrdenAccion) {
		this.numOrdenAccion = numOrdenAccion;
	}

	public String getDesProgControl() {
		return desProgControl;
	}

	public void setDesProgControl(String desProgControl) {
		this.desProgControl = desProgControl;
	}

	public String getDesInformeSelecc() {
		return desInformeSelecc;
	}

	public void setDesInformeSelecc(String desInformeSelecc) {
		this.desInformeSelecc = desInformeSelecc;
	}

	public String getDesTipoAccion() {
		return desTipoAccion;
	}

	public void setDesTipoAccion(String desTipoAccion) {
		this.desTipoAccion = desTipoAccion;
	}
	
	public Integer getNumCorrelDoc() {
		return numCorrelDoc;
	}

	public void setNumCorrelDoc(Integer numCorrelDoc) {
		this.numCorrelDoc = numCorrelDoc;
	}

	public Integer getAnnDoc() {
		return annDoc;
	}

	public void setAnnDoc(Integer annDoc) {
		this.annDoc = annDoc;
	}

	public String getCodUuooDoc() {
		return codUuooDoc;
	}

	public void setCodUuooDoc(String codUuooDoc) {
		this.codUuooDoc = codUuooDoc;
	}

	public String getCodEstadoRegistro() {
		return codEstadoRegistro;
	}

	public void setCodEstadoRegistro(String codEstadoRegistro) {
		this.codEstadoRegistro = codEstadoRegistro;
	}

	public String getCodClase() {
		return codClase;
	}

	public void setCodClase(String codClase) {
		this.codClase = codClase;
	}

	public String getDesTipSigOrden() {
		return desTipSigOrden;
	}

	public void setDesTipSigOrden(String desTipSigOrden) {
		this.desTipSigOrden = desTipSigOrden;
	}

	public String getDesEstadoRegistro() {
		return desEstadoRegistro;
	}

	public void setDesEstadoRegistro(String desEstadoRegistro) {
		this.desEstadoRegistro = desEstadoRegistro;
	}

	public String getDesResultadoInconsistencia() {
		return desResultadoInconsistencia;
	}

	public void setDesResultadoInconsistencia(String desResultadoInconsistencia) {
		this.desResultadoInconsistencia = desResultadoInconsistencia;
	}

	public String getCodUnidadOrganicaInforme() {
		return codUnidadOrganicaInforme;
	}

	public void setCodUnidadOrganicaInforme(String codUnidadOrganicaInforme) {
		this.codUnidadOrganicaInforme = codUnidadOrganicaInforme;
	}

	public String getCodEstadoUsuario() {
		return codEstadoUsuario;
	}

	public void setCodEstadoUsuario(String codEstadoUsuario) {
		this.codEstadoUsuario = codEstadoUsuario;
	}

	public String getPerInicio() {
		return perInicio;
	}

	public void setPerInicio(String perInicio) {
		this.perInicio = perInicio;
	}

	public String getPerFin() {
		return perFin;
	}

	public void setPerFin(String perFin) {
		this.perFin = perFin;
	}

	public Date getFecCrea() {
		return fecCrea;
	}

	public void setFecCrea(Date fecCrea) {
		this.fecCrea = fecCrea;
	}

	public Long getInformeNumCorrel() {
		return informeNumCorrel;
	}

	public void setInformeNumCorrel(Long informeNumCorrel) {
		this.informeNumCorrel = informeNumCorrel;
	}

	public Integer getInformeAnio() {
		return informeAnio;
	}

	public void setInformeAnio(Integer informeAnio) {
		this.informeAnio = informeAnio;
	}

	public String getInformeCodUUOO() {
		return informeCodUUOO;
	}

	public void setInformeCodUUOO(String informeCodUUOO) {
		this.informeCodUUOO = informeCodUUOO;
	}

	public String getCodTipAccion() {
		return codTipAccion;
	}

	public void setCodTipAccion(String codTipAccion) {
		this.codTipAccion = codTipAccion;
	}

	public String getNumDocumentoOrden() {
		return numDocumentoOrden;
	}

	public void setNumDocumentoOrden(String numDocumentoOrden) {
		this.numDocumentoOrden = numDocumentoOrden;
	}

	public String getDesProgCtrl() {
		return desProgCtrl;
	}

	public void setDesProgCtrl(String desProgCtrl) {
		this.desProgCtrl = desProgCtrl;
	}

	public String getDesTipAccion() {
		return desTipAccion;
	}

	public void setDesTipAccion(String desTipAccion) {
		this.desTipAccion = desTipAccion;
	}

	public Long getNumDocumentoAccion() {
		return numDocumentoAccion;
	}

	public void setNumDocumentoAccion(Long numDocumentoAccion) {
		this.numDocumentoAccion = numDocumentoAccion;
	}

	public void setListOrden(List<OrdenAccionBean> listOrden) {
		this.listOrden = listOrden;
	}

	public List<ContactoOrdenBean> getListaContactoOrden() {
		return listaContactoOrden;
	}

	public void setListaContactoOrden(List<ContactoOrdenBean> listaContactoOrden) {
		this.listaContactoOrden = listaContactoOrden;
	}

	public String getFecPrimeraVisit() {
		return fecPrimeraVisit;
	}

	public void setFecPrimeraVisit(String fecPrimeraVisit) {
		this.fecPrimeraVisit = fecPrimeraVisit;
	}
	
	public String getNumInfoResul() {
		return numInfoResul;
	}

	public void setNumInfoResul(String numInfoResul) {
		this.numInfoResul = numInfoResul;
	}

	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}

	public String getDesTipoDocumentoIdentif() {
		return desTipoDocumentoIdentif;
	}

	public void setDesTipoDocumentoIdentif(String desTipoDocumentoIdentif) {
		this.desTipoDocumentoIdentif = desTipoDocumentoIdentif;
	}

	public List<TipoInconsistenciaOrdenBean> getLstInconsistencia() {
		return lstInconsistencia;
	}

	public void setLstInconsistencia(List<TipoInconsistenciaOrdenBean> lstInconsistencia) {
		this.lstInconsistencia = lstInconsistencia;
	}

	public List<DetalleResultadoOrdenBean> getLstDetalleResultOrden() {
		return lstDetalleResultOrden;
	}

	public void setLstDetalleResultOrden(List<DetalleResultadoOrdenBean> lstDetalleResultOrden) {
		this.lstDetalleResultOrden = lstDetalleResultOrden;
	}

	public List<DocumentoOrdenBean> getLstDocumentosOrden() {
		return lstDocumentosOrden;
	}

	public void setLstDocumentosOrden(List<DocumentoOrdenBean> lstDocumentosOrden) {
		this.lstDocumentosOrden = lstDocumentosOrden;
	}

	public String getDesResultadoInconsistenciaDef() {
		return desResultadoInconsistenciaDef;
	}

	public void setDesResultadoInconsistenciaDef(String desResultadoInconsistenciaDef) {
		this.desResultadoInconsistenciaDef = desResultadoInconsistenciaDef;
	}

	public List<TareoAuditorBean> getLstTareoAuditor() {
		return lstTareoAuditor;
	}

	public void setLstTareoAuditor(List<TareoAuditorBean> lstTareoAuditor) {
		this.lstTareoAuditor = lstTareoAuditor;
	}

	public List<SuspensionOrdenBean> getLstSuspenOrden() {
		return lstSuspenOrden;
	}

	public void setLstSuspenOrden(List<SuspensionOrdenBean> lstSuspenOrden) {
		this.lstSuspenOrden = lstSuspenOrden;
	}

	public List<DocumentoOrdenBean> getListaOtrosDocumentos() {
		return listaOtrosDocumentos;
	}

	public void setListaOtrosDocumentos(List<DocumentoOrdenBean> listaOtrosDocumentos) {
		this.listaOtrosDocumentos = listaOtrosDocumentos;
	}

	public List<ActividadOrdenBean> getLstActividadOrden() {
		return lstActividadOrden;
	}

	public void setLstActividadOrden(List<ActividadOrdenBean> lstActividadOrden) {
		this.lstActividadOrden = lstActividadOrden;
	}
	
	
	
}
