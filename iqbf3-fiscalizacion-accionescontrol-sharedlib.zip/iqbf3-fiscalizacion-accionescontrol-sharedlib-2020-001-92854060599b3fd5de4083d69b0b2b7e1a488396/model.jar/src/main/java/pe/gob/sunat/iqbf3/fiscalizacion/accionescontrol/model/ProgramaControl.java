package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "T8276CATPROGCTRL")
public class ProgramaControl extends Auditoria {

	 @Column(name = "COD_FRECTIEMPO")
	 private String codFrecuenciaTiempo;
	
	 @Id
	 @Column(name = "COD_PROGCTRL")
	 private String codProgctrl;
	
	 @Column(name = "COD_UUOO")
	 private String codUnidadOrganica;
	
	 @Column(name = "DES_ALCANCE")
	 private String desAlcance;
	
	 @Column(name = "DES_CRUCE")
	 private String desCruce;
	
	 @Column(name = "DES_DENOMINACION")
	 private String desDenominacion;
	
	 @Column(name = "DES_RESUMEN")
	 private String desResumen;
	
	 @Column(name = "IND_CIERRE")
	 private String indCierre;
	
	 @Column(name = "IND_INF_SELEC")
	 private String indInformeSelec;
	
	 @Column(name = "NUM_PLAZO")
	 private Integer numPlazo;
	 
	 @Column(name = "IND_EST")
	 private String indEst;
	 
	 //filtros
	 @Transient
	 private Integer numProgramacion;
	 @Transient 
	 private String numInforme;
	 
	 @Transient
	 private Long numOrden;
	
	public Integer getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Integer numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public String getNumInforme() {
		return numInforme;
	}

	public void setNumInforme(String numInforme) {
		this.numInforme = numInforme;
	}

	public String getCodFrecuenciaTiempo() {
		return codFrecuenciaTiempo;
	}

	public void setCodFrecuenciaTiempo(String codFrecuenciaTiempo) {
		this.codFrecuenciaTiempo = codFrecuenciaTiempo;
	}

	public String getCodProgctrl() {
		return codProgctrl;
	}

	public void setCodProgctrl(String codProgctrl) {
		this.codProgctrl = codProgctrl;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public String getDesAlcance() {
		return desAlcance;
	}

	public void setDesAlcance(String desAlcance) {
		this.desAlcance = desAlcance;
	}

	public String getDesCruce() {
		return desCruce;
	}

	public void setDesCruce(String desCruce) {
		this.desCruce = desCruce;
	}

	public String getDesDenominacion() {
		return desDenominacion;
	}

	public void setDesDenominacion(String desDenominacion) {
		this.desDenominacion = desDenominacion;
	}

	public String getDesResumen() {
		return desResumen;
	}

	public void setDesResumen(String desResumen) {
		this.desResumen = desResumen;
	}

	public String getIndCierre() {
		return indCierre;
	}

	public void setIndCierre(String indCierre) {
		this.indCierre = indCierre;
	}

	public String getIndInformeSelec() {
		return indInformeSelec;
	}

	public void setIndInformeSelec(String indInformeSelec) {
		this.indInformeSelec = indInformeSelec;
	}

	public Integer getNumPlazo() {
		return numPlazo;
	}

	public void setNumPlazo(Integer numPlazo) {
		this.numPlazo = numPlazo;
	}
	

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}	 
}
