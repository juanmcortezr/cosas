package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class MovimientoSolicitudBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codPersMov;
	private	String	desMotivoAsignacion;
	private	String	desPersonalMovimiento;
	private	String	fecMovimiento;
	private	int	numMovimientoPrograma;
	private	int	numSolicitud;
	
	public MovimientoSolicitudBean() {
		super();
	}

	public MovimientoSolicitudBean(String codPersMov, String desMotivoAsignacion, String desPersonalMovimiento,
			String fecMovimiento, int numMovimientoPrograma, int numSolicitud) {
		super();
		this.codPersMov = codPersMov;
		this.desMotivoAsignacion = desMotivoAsignacion;
		this.desPersonalMovimiento = desPersonalMovimiento;
		this.fecMovimiento = fecMovimiento;
		this.numMovimientoPrograma = numMovimientoPrograma;
		this.numSolicitud = numSolicitud;
	}

	public String getCodPersMov() {
		return codPersMov;
	}

	public void setCodPersMov(String codPersMov) {
		this.codPersMov = codPersMov;
	}

	public String getDesMotivoAsignacion() {
		return desMotivoAsignacion;
	}

	public void setDesMotivoAsignacion(String desMotivoAsignacion) {
		this.desMotivoAsignacion = desMotivoAsignacion;
	}

	public String getDesPersonalMovimiento() {
		return desPersonalMovimiento;
	}

	public void setDesPersonalMovimiento(String desPersonalMovimiento) {
		this.desPersonalMovimiento = desPersonalMovimiento;
	}

	public String getFecMovimiento() {
		return fecMovimiento;
	}

	public void setFecMovimiento(String fecMovimiento) {
		this.fecMovimiento = fecMovimiento;
	}

	public int getNumMovimientoPrograma() {
		return numMovimientoPrograma;
	}

	public void setNumMovimientoPrograma(int numMovimientoPrograma) {
		this.numMovimientoPrograma = numMovimientoPrograma;
	}

	public int getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(int numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
