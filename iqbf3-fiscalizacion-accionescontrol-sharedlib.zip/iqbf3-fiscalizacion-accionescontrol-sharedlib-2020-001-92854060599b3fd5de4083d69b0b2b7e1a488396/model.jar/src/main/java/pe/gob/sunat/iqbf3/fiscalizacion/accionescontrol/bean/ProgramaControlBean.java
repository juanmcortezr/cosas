package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class ProgramaControlBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codFrecuenciaTiempo;
	private	String	codProgctrl;
	private	String	codUnidadOrganica;
	private	String	desAlcance;
	private	String	desCruce;
	private	String	desDenominacion;
	private	String	desResumen;
	private	String	indCierre;
	private	String	indInformeSelec;
	private String  desEstado;
	private String  indEstado;
	private	int	numPlazo;
	
	private String numInfSelecc;
	private String noSubSano;
	private String parcialmente;
	private String codEstOrden;
	private String codResulOrden;

	 public String getNumInfSelecc() {
		return numInfSelecc;
	}

	public void setNumInfSelecc(String numInfSelecc) {
		this.numInfSelecc = numInfSelecc;
	}

	public String getNoSubSano() {
		return noSubSano;
	}

	public void setNoSubSano(String noSubSano) {
		this.noSubSano = noSubSano;
	}

	public String getParcialmente() {
		return parcialmente;
	}

	public void setParcialmente(String parcialmente) {
		this.parcialmente = parcialmente;
	}

	public String getCodEstOrden() {
		return codEstOrden;
	}

	public void setCodEstOrden(String codEstOrden) {
		this.codEstOrden = codEstOrden;
	}

	public String getCodResulOrden() {
		return codResulOrden;
	}

	public void setCodResulOrden(String codResulOrden) {
		this.codResulOrden = codResulOrden;
	}

	public String getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(String numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public String getNumInforme() {
		return numInforme;
	}

	public void setNumInforme(String numInforme) {
		this.numInforme = numInforme;
	}

	private String numProgramacion;
	 private String numInforme;
	 
	// para filtro
	private Long numOrden;
	
	private AuditoriaBean auditoriaBean;

	public ProgramaControlBean() {
		super();
	}

	public ProgramaControlBean(String codFrecuenciaTiempo, String codProgctrl, String codUnidadOrganica,
			String desAlcance, String desCruce, String desDenominacion, String desResumen, String indCierre,
			String indInformeSelec, int numPlazo, Long numOrden) {
		super();
		this.codFrecuenciaTiempo = codFrecuenciaTiempo;
		this.codProgctrl = codProgctrl;
		this.codUnidadOrganica = codUnidadOrganica;
		this.desAlcance = desAlcance;
		this.desCruce = desCruce;
		this.desDenominacion = desDenominacion;
		this.desResumen = desResumen;
		this.indCierre = indCierre;
		this.indInformeSelec = indInformeSelec;
		this.numPlazo = numPlazo;
		this.numOrden = numOrden;
	}

	public String getCodFrecuenciaTiempo() {
		return codFrecuenciaTiempo;
	}

	public void setCodFrecuenciaTiempo(String codFrecuenciaTiempo) {
		this.codFrecuenciaTiempo = codFrecuenciaTiempo;
	}

	public String getCodProgctrl() {
		return codProgctrl;
	}

	public void setCodProgctrl(String codProgctrl) {
		this.codProgctrl = codProgctrl;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public String getDesAlcance() {
		return desAlcance;
	}

	public void setDesAlcance(String desAlcance) {
		this.desAlcance = desAlcance;
	}

	public String getDesCruce() {
		return desCruce;
	}

	public void setDesCruce(String desCruce) {
		this.desCruce = desCruce;
	}

	public String getDesDenominacion() {
		return desDenominacion;
	}

	public void setDesDenominacion(String desDenominacion) {
		this.desDenominacion = desDenominacion;
	}

	public String getDesResumen() {
		return desResumen;
	}

	public void setDesResumen(String desResumen) {
		this.desResumen = desResumen;
	}

	public String getIndCierre() {
		return indCierre;
	}

	public void setIndCierre(String indCierre) {
		this.indCierre = indCierre;
	}

	public String getIndInformeSelec() {
		return indInformeSelec;
	}

	public void setIndInformeSelec(String indInformeSelec) {
		this.indInformeSelec = indInformeSelec;
	}

	public int getNumPlazo() {
		return numPlazo;
	}

	public void setNumPlazo(int numPlazo) {
		this.numPlazo = numPlazo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public String getDesEstado() {
		return desEstado;
	}

	public void setDesEstado(String desEstado) {
		this.desEstado = desEstado;
	}
	
	
	public String getIndEstado() {
		return indEstado;
	}

	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}
	
	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}
}
