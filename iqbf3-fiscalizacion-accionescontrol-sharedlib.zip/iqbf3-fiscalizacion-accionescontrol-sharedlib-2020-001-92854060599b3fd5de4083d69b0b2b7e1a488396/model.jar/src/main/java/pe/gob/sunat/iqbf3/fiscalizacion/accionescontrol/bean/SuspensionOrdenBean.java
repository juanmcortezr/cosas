package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class SuspensionOrdenBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codSustentoSuspencion;
	private String desSusSusp;
	private int numSusSuporden;
	private int numOrden;
	private String indSeleccionado;

	private String indDel;
	private String indEst;
	private AuditoriaBean auditoriaBean;
	
	public SuspensionOrdenBean() {
		super();
	}

	public SuspensionOrdenBean(String codSustentoSuspencion, String desSusSusp, int numSusSuporden, int numOrden) {
		super();
		this.codSustentoSuspencion = codSustentoSuspencion;
		this.desSusSusp = desSusSusp;
		this.numSusSuporden = numSusSuporden;
		this.numOrden = numOrden;
	}

	public String getCodSustentoSuspencion() {
		return codSustentoSuspencion;
	}

	public void setCodSustentoSuspencion(String codSustentoSuspencion) {
		this.codSustentoSuspencion = codSustentoSuspencion;
	}

	public String getDesSusSusp() {
		return desSusSusp;
	}

	public void setDesSusSusp(String desSusSusp) {
		this.desSusSusp = desSusSusp;
	}

	public int getNumSusSuporden() {
		return numSusSuporden;
	}

	public void setNumSusSuporden(int numSusSuporden) {
		this.numSusSuporden = numSusSuporden;
	}

	public int getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(int numOrden) {
		this.numOrden = numOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIndSeleccionado() {
		return indSeleccionado;
	}

	public void setIndSeleccionado(String indSeleccionado) {
		this.indSeleccionado = indSeleccionado;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

}
