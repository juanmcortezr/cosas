package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class AsignacionMasivaAuditoresBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String numRegistro;
	private String nomApellidoUsuario;
	private String cargoLaboral;
	
	private String numGrupo;
	private String nomGrupo;
	
	public String getNumGrupo() {
		return numGrupo;
	}

	public void setNumGrupo(String numGrupo) {
		this.numGrupo = numGrupo;
	}

	public String getNomGrupo() {
		return nomGrupo;
	}

	public void setNomGrupo(String nomGrupo) {
		this.nomGrupo = nomGrupo;
	}

	public AsignacionMasivaAuditoresBean(){
		super();	
	}
	
	public AsignacionMasivaAuditoresBean(String numRegistro, String nomApellidoUsuario, String cargoLaboral) {
		this.numRegistro = numRegistro;
		this.nomApellidoUsuario = nomApellidoUsuario;
		this.cargoLaboral = cargoLaboral;
	}
	
	public AsignacionMasivaAuditoresBean(String numGrupo, String nomGrupo) {
		super();
		this.numGrupo = numGrupo;
		this.nomGrupo = nomGrupo;
	}

	public String getNumRegistro() {
		return numRegistro;
	}
	public void setNumRegistro(String numRegistro) {
		this.numRegistro = numRegistro;
	}
	public String getNomApellidoUsuario() {
		return nomApellidoUsuario;
	}
	public void setNomApellidoUsuario(String nomApellidoUsuario) {
		this.nomApellidoUsuario = nomApellidoUsuario;
	}
	public String getCargoLaboral() {
		return cargoLaboral;
	}
	public void setCargoLaboral(String cargoLaboral) {
		this.cargoLaboral = cargoLaboral;
	}

}
