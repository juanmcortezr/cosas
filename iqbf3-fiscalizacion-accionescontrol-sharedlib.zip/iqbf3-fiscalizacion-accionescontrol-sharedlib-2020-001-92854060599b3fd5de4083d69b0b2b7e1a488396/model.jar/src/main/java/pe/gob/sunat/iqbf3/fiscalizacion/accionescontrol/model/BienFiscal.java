package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "t7883bienfiscal")
public class BienFiscal extends Auditoria {

	@Id
	@Column(name = "cod_bien")
	private String codBien;

	@Column(name = "cod_tip_bien")
	private String codTipoBien;

	@Column(name = "des_bien")
	private String desBien;

	public BienFiscal(){
		
	}
	
	public BienFiscal(String codBien, String desBien) {
		super();
		this.codBien = codBien;
		this.desBien = desBien;
	}

	public String getCodBien() {
		return codBien;
	}

	public void setCodBien(String codBien) {
		this.codBien = codBien;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getDesBien() {
		return desBien;
	}

	public void setDesBien(String desBien) {
		this.desBien = desBien;
	}

}
