package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


@Entity
@Table(name = "T10423TAREOAUDITOR")
public class TareoAuditor extends Auditoria {

	 @Column(name = "DES_ACTIVIDAD")
	 private String desActividad;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_ACTIVIDAD")
	 private Date fecActividad;
	
	 @Temporal(TemporalType.TIME)
	 @Column(name = "HOR_EMPLEADA")
	 private Date horEmpleada;
	
	 @Id
	 @Column(name = "NUM_TAREO")
	 private Long numTareo;
	 
	 @Column(name = "NUM_ORDEN")
	 private Long numOrden;
	 
	 @Transient
	 private boolean indEliminar;
	 
	public String getDesActividad() {
		return desActividad;
	}

	public void setDesActividad(String desActividad) {
		this.desActividad = desActividad;
	}

	public Date getFecActividad() {
		return fecActividad;
	}

	public void setFecActividad(Date fecActividad) {
		this.fecActividad = fecActividad;
	}

	public Date getHorEmpleada() {
		return horEmpleada;
	}

	public void setHorEmpleada(Date horEmpleada) {
		this.horEmpleada = horEmpleada;
	}

	public Long getNumTareo() {
		return numTareo;
	}

	public void setNumTareo(Long numTareo) {
		this.numTareo = numTareo;
	}
	
	public boolean isIndEliminar() {
		return indEliminar;
	}

	public void setIndEliminar(boolean indEliminar) {
		this.indEliminar = indEliminar;
	}
	
	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	} 
}
