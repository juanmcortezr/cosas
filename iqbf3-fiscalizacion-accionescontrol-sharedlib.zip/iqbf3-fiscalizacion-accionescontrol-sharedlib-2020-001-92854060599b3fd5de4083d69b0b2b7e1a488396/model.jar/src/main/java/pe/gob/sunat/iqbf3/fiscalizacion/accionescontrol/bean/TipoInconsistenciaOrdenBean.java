package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class TipoInconsistenciaOrdenBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codOrigen;
	private String codResultadoInconsistencia;
	private String codTipoInconsistencia;
	private String desOtraInconsistencia;
	private String desSusInconsis;
	private String desOrigen;
	private String desResulInconsis;
	private String desTipoInconsistencia;
	private int numInconsistenciaOrden;
	private int numOrden;

	
	private String indDel;
	private String indEst;
	private AuditoriaBean auditoriaBean;
	
	public TipoInconsistenciaOrdenBean() {
		super();
	}

	public TipoInconsistenciaOrdenBean(String codOrigen, String codResultadoInconsistencia,
			String codTipoInconsistencia, String desOtraInconsistencia, String desSusInconsis, String desOrigen,
			String desResulInconsis, String desTipoInconsistencia, int numInconsistenciaOrden, int numOrden) {
		super();
		this.codOrigen = codOrigen;
		this.codResultadoInconsistencia = codResultadoInconsistencia;
		this.codTipoInconsistencia = codTipoInconsistencia;
		this.desOtraInconsistencia = desOtraInconsistencia;
		this.desSusInconsis = desSusInconsis;
		this.desOrigen = desOrigen;
		this.desResulInconsis = desResulInconsis;
		this.desTipoInconsistencia = desTipoInconsistencia;
		this.numInconsistenciaOrden = numInconsistenciaOrden;
		this.numOrden = numOrden;
	}

	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}

	public String getCodResultadoInconsistencia() {
		return codResultadoInconsistencia;
	}

	public void setCodResultadoInconsistencia(String codResultadoInconsistencia) {
		this.codResultadoInconsistencia = codResultadoInconsistencia;
	}

	public String getCodTipoInconsistencia() {
		return codTipoInconsistencia;
	}

	public void setCodTipoInconsistencia(String codTipoInconsistencia) {
		this.codTipoInconsistencia = codTipoInconsistencia;
	}

	public String getDesOtraInconsistencia() {
		return desOtraInconsistencia;
	}

	public void setDesOtraInconsistencia(String desOtraInconsistencia) {
		this.desOtraInconsistencia = desOtraInconsistencia;
	}

	public String getDesSusInconsis() {
		return desSusInconsis;
	}

	public void setDesSusInconsis(String desSusInconsis) {
		this.desSusInconsis = desSusInconsis;
	}

	public String getDesOrigen() {
		return desOrigen;
	}

	public void setDesOrigen(String desOrigen) {
		this.desOrigen = desOrigen;
	}

	public String getDesResulInconsis() {
		return desResulInconsis;
	}

	public void setDesResulInconsis(String desResulInconsis) {
		this.desResulInconsis = desResulInconsis;
	}

	public String getDesTipoInconsistencia() {
		return desTipoInconsistencia;
	}

	public void setDesTipoInconsistencia(String desTipoInconsistencia) {
		this.desTipoInconsistencia = desTipoInconsistencia;
	}

	public int getNumInconsistenciaOrden() {
		return numInconsistenciaOrden;
	}

	public void setNumInconsistenciaOrden(int numInconsistenciaOrden) {
		this.numInconsistenciaOrden = numInconsistenciaOrden;
	}

	public int getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(int numOrden) {
		this.numOrden = numOrden;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

}
