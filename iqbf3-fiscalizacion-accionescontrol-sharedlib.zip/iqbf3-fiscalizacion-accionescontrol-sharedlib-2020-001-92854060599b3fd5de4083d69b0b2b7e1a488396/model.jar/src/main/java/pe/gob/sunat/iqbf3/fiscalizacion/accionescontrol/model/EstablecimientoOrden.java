package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "T10408ESTABORDEN")
public class EstablecimientoOrden extends Auditoria {

	 @Column(name = "COD_DEPARTAMENTO")
	 private String codDepartamento;
	
	 @Column(name = "COD_DISTRITO")
	 private String codDistrito;
	
	 @Column(name = "COD_ORIGEN")
	 private String codOrigen;
	
	 @Column(name = "COD_PROVINCIA")
	 private String codProvincia;
	
	 @Column(name = "COD_TIP_DOCNEUT")
	 private String codTipoDocumentoIdentif;
	
	 @Column(name = "DES_DIRECCION")
	 private String desDireccion;
	
	 @Column(name = "NUM_ESTAB")
	 private Integer numEstablecimiento;
	
	 @Id
	 @Column(name = "NUM_ESTAB_ORDEN")
	 private Long numEstablecimientoOrden;
	
	 @Column(name = "NUM_OTRO_RUC")
	 private String numOtroRuc;
	
	 @Column(name = "NUM_SOL_NEU")
	 private String numSolicitudNuetralizacion;
	
	 @Column(name = "NUM_XUTM")
	 private Double numXutm;
	
	 @Column(name = "NUM_YUTM")
	 private Double numYutm;
	
	 @Column(name = "NUM_ZONA")
	 private Double numZona;
	 
	 @Column(name = "NUM_ORDEN")
	 private Long numOrden;
	 
	 @Transient
	 private boolean indEliminar;

	public String getCodDepartamento() {
		return codDepartamento;
	}

	public void setCodDepartamento(String codDepartamento) {
		this.codDepartamento = codDepartamento;
	}

	public String getCodDistrito() {
		return codDistrito;
	}

	public void setCodDistrito(String codDistrito) {
		this.codDistrito = codDistrito;
	}

	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}

	public String getCodProvincia() {
		return codProvincia;
	}

	public void setCodProvincia(String codProvincia) {
		this.codProvincia = codProvincia;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getDesDireccion() {
		return desDireccion;
	}

	public void setDesDireccion(String desDireccion) {
		this.desDireccion = desDireccion;
	}

	public Integer getNumEstablecimiento() {
		return numEstablecimiento;
	}

	public void setNumEstablecimiento(Integer numEstablecimiento) {
		this.numEstablecimiento = numEstablecimiento;
	}

	public Long getNumEstablecimientoOrden() {
		return numEstablecimientoOrden;
	}

	public void setNumEstablecimientoOrden(Long numEstablecimientoOrden) {
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public String getNumOtroRuc() {
		return numOtroRuc;
	}

	public void setNumOtroRuc(String numOtroRuc) {
		this.numOtroRuc = numOtroRuc;
	}

	public String getNumSolicitudNuetralizacion() {
		return numSolicitudNuetralizacion;
	}

	public void setNumSolicitudNuetralizacion(String numSolicitudNuetralizacion) {
		this.numSolicitudNuetralizacion = numSolicitudNuetralizacion;
	}

	public Double getNumXutm() {
		return numXutm;
	}

	public void setNumXutm(Double numXutm) {
		this.numXutm = numXutm;
	}

	public Double getNumYutm() {
		return numYutm;
	}

	public void setNumYutm(Double numYutm) {
		this.numYutm = numYutm;
	}

	public Double getNumZona() {
		return numZona;
	}

	public void setNumZona(Double numZona) {
		this.numZona = numZona;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}

	public boolean isIndEliminar() {
		return indEliminar;
	}

	public void setIndEliminar(boolean indEliminar) {
		this.indEliminar = indEliminar;
	}
	 
	
	
}
