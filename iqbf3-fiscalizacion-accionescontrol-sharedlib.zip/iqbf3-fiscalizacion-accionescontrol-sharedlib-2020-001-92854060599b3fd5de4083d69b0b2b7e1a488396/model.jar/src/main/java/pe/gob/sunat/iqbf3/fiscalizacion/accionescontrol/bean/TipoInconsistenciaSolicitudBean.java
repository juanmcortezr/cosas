package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class TipoInconsistenciaSolicitudBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codTipoInconsistencia;
	private String desOtraInconsistencia;
	private String desTipoInconsistencia;
	private int numInconsistenciaSolicitud;
	private int numSolicitud;

	public TipoInconsistenciaSolicitudBean() {
		super();
	}

	public TipoInconsistenciaSolicitudBean(String codTipoInconsistencia, String desOtraInconsistencia,
			String desTipoInconsistencia, int numInconsistenciaSolicitud, int numSolicitud) {
		super();
		this.codTipoInconsistencia = codTipoInconsistencia;
		this.desOtraInconsistencia = desOtraInconsistencia;
		this.desTipoInconsistencia = desTipoInconsistencia;
		this.numInconsistenciaSolicitud = numInconsistenciaSolicitud;
		this.numSolicitud = numSolicitud;
	}

	public String getCodTipoInconsistencia() {
		return codTipoInconsistencia;
	}

	public void setCodTipoInconsistencia(String codTipoInconsistencia) {
		this.codTipoInconsistencia = codTipoInconsistencia;
	}

	public String getDesOtraInconsistencia() {
		return desOtraInconsistencia;
	}

	public void setDesOtraInconsistencia(String desOtraInconsistencia) {
		this.desOtraInconsistencia = desOtraInconsistencia;
	}

	public String getDesTipoInconsistencia() {
		return desTipoInconsistencia;
	}

	public void setDesTipoInconsistencia(String desTipoInconsistencia) {
		this.desTipoInconsistencia = desTipoInconsistencia;
	}

	public int getNumInconsistenciaSolicitud() {
		return numInconsistenciaSolicitud;
	}

	public void setNumInconsistenciaSolicitud(int numInconsistenciaSolicitud) {
		this.numInconsistenciaSolicitud = numInconsistenciaSolicitud;
	}

	public int getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(int numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
