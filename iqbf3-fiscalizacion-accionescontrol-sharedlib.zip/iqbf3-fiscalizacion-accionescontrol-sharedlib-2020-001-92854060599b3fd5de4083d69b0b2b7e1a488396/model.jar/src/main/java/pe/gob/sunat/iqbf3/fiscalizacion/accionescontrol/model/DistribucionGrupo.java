package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "T8303DISTRIGRUPO")
public class DistribucionGrupo extends Auditoria {

	@Column(name = "COD_CARGO")
	private String codCargo;

	@Column(name = "COD_PERS")
	private String codPersonal;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEC_FIN")
	private Date fecFin;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEC_INICIO")
	private Date fecInicio;

	@Id
	@Column(name = "NUM_DIST_GRUPO")
	private Long numDistribucionGrupo;

	@Column(name = "NUM_GRUPO")
	private Integer numGrupo;

	//
	@Transient
	private Long cantCarga;
	
	@Transient
	private String codEstOrden;
	
	@Transient
	private String codTipoProceso;
	
	@Transient
	private String indDel;
	
	@Transient
	private String indTipAsignacion;
	
	@Transient
	private String indEst;
	
	@Transient
	private String codPers;
	@Transient
	private Long numUsuarioPrograma;	
	
	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public String getIndTipAsignacion() {
		return indTipAsignacion;
	}

	public void setIndTipAsignacion(String indTipAsignacion) {
		this.indTipAsignacion = indTipAsignacion;
	}

	public String getCodTipoProceso() {
		return codTipoProceso;
	}

	public void setCodTipoProceso(String codTipoProceso) {
		this.codTipoProceso = codTipoProceso;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getCodEstOrden() {
		return codEstOrden;
	}

	public void setCodEstOrden(String codEstOrden) {
		this.codEstOrden = codEstOrden;
	}

	public Long getCantCarga() {
		return cantCarga;
	}

	public void setCantCarga(Long cantCarga) {
		this.cantCarga = cantCarga;
	}

	public String getCodCargo() {
		return codCargo;
	}

	public void setCodCargo(String codCargo) {
		this.codCargo = codCargo;
	}

	public String getCodPersonal() {
		return codPersonal;
	}

	public void setCodPersonal(String codPersonal) {
		this.codPersonal = codPersonal;
	}

	public Date getFecFin() {
		return fecFin;
	}

	public void setFecFin(Date fecFin) {
		this.fecFin = fecFin;
	}

	public Date getFecInicio() {
		return fecInicio;
	}

	public void setFecInicio(Date fecInicio) {
		this.fecInicio = fecInicio;
	}

	public Long getNumDistribucionGrupo() {
		return numDistribucionGrupo;
	}

	public void setNumDistribucionGrupo(Long numDistribucionGrupo) {
		this.numDistribucionGrupo = numDistribucionGrupo;
	}

	public Integer getNumGrupo() {
		return numGrupo;
	}

	public void setNumGrupo(Integer numGrupo) {
		this.numGrupo = numGrupo;
	}

}
