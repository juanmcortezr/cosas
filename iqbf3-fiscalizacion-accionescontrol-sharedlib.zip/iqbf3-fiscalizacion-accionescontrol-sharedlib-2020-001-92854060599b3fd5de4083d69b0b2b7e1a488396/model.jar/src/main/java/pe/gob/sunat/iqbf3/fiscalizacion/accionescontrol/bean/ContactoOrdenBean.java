package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class ContactoOrdenBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codTipoDocumentoIdentif;
	private	String	desCargo;
	private	String	desTipoDocumentoIdent;
	private	String	nomApellidoContacto;
	private	Long numContacto;
	private	String	numDocumentoIdentif;
	private	String	numTelefono;
	private	Long numOrden;
	private AuditoriaBean auditoriaBean;

	private String indDel;
	private String indEst;
	
	public ContactoOrdenBean() {
		super();
	}

	public ContactoOrdenBean(String codTipoDocumentoIdentif, String desCargo, String desTipoDocumentoIdent,
			String nomApellidoContacto, Long numContacto, String numDocumentoIdentif, String numTelefono, Long numOrden, AuditoriaBean auditoriaBean) {
		super();
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
		this.desCargo = desCargo;
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
		this.nomApellidoContacto = nomApellidoContacto;
		this.numContacto = numContacto;
		this.numDocumentoIdentif = numDocumentoIdentif;
		this.numTelefono = numTelefono;
		this.numOrden = numOrden;
		this.auditoriaBean = auditoriaBean;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getDesCargo() {
		return desCargo;
	}

	public void setDesCargo(String desCargo) {
		this.desCargo = desCargo;
	}

	public String getDesTipoDocumentoIdent() {
		return desTipoDocumentoIdent;
	}

	public void setDesTipoDocumentoIdent(String desTipoDocumentoIdent) {
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
	}

	public String getNomApellidoContacto() {
		return nomApellidoContacto;
	}

	public void setNomApellidoContacto(String nomApellidoContacto) {
		this.nomApellidoContacto = nomApellidoContacto;
	}

	public Long getNumContacto() {
		return numContacto;
	}

	public void setNumContacto(Long numContacto) {
		this.numContacto = numContacto;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public String getNumTelefono() {
		return numTelefono;
	}

	public void setNumTelefono(String numTelefono) {
		this.numTelefono = numTelefono;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}


	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}
	
	
}
