package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import pe.gob.sunat.iqbf3.registro.maestros.bean.WSDomicilioRUCBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSRegistroRUCBean;

public class UsuarioRegistroBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private WSDomicilioRUCBean wsDomicilioRucBean;
	
	private PerfilRiesgosBean perfilRiesgosBean;
	
	private List<PerfilRiesgosBean> lstPerfilRiesgo;
	
	private WSRegistroRUCBean regBeanRuc;

	private Integer nivelRiesgo;

	//BFRegistro
	private String codEstado;
	private Date fecFinvigencia;
	private Integer numVerreg;
	
	
	
	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public Date getFecFinvigencia() {
		return fecFinvigencia;
	}

	public void setFecFinvigencia(Date fecFinvigencia) {
		this.fecFinvigencia = fecFinvigencia;
	}

	public Integer getNumVerreg() {
		return numVerreg;
	}

	public void setNumVerreg(Integer numVerreg) {
		this.numVerreg = numVerreg;
	}

	public WSDomicilioRUCBean getWsDomicilioRucBean() {
		return wsDomicilioRucBean;
	}

	public void setWsDomicilioRucBean(WSDomicilioRUCBean wsDomicilioRucBean) {
		this.wsDomicilioRucBean = wsDomicilioRucBean;
	}

	public PerfilRiesgosBean getPerfilRiesgosBean() {
		return perfilRiesgosBean;
	}

	public void setPerfilRiesgosBean(PerfilRiesgosBean perfilRiesgosBean) {
		this.perfilRiesgosBean = perfilRiesgosBean;
	}

	public List<PerfilRiesgosBean> getLstPerfilRiesgo() {
		return lstPerfilRiesgo;
	}

	public void setLstPerfilRiesgo(List<PerfilRiesgosBean> lstPerfilRiesgo) {
		this.lstPerfilRiesgo = lstPerfilRiesgo;
	}

	public WSRegistroRUCBean getRegBeanRuc() {
		return regBeanRuc;
	}

	public void setRegBeanRuc(WSRegistroRUCBean regBeanRuc) {
		this.regBeanRuc = regBeanRuc;
	}

	public Integer getNivelRiesgo() {
		return nivelRiesgo;
	}

	public void setNivelRiesgo(Integer nivelRiesgo) {
		this.nivelRiesgo = nivelRiesgo;
	}
		
}
