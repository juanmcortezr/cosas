package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T5257CONFIR")
public class ConfirmacionGre implements Entidad{

	@Id
	@Column(name = "COD_CONFIRMACION")
	 private Long codConfirmacion;
	
	@Column(name = "COD_CPE")
	 private Integer codCpe;
	
	@Column(name = "NUM_CPE")
	 private Integer numCpe;
	
	@Column(name = "NUM_RUC")
	 private Integer numRuc;
	
	@Column(name = "NUM_SERIE_CPE")
	 private Integer numSerieCpe;
	
	 @Column(name = "COD_RESULTADO")
	 private String codResultado;
	
	 @Column(name = "COD_TIPO")
	 private String codTipo;
	
	 @Column(name = "DIR_LLEGADA")
	 private String dirLlegada;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_CONFIRMACION")
	 private Date fecConfirmacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_LLEGADA")
	 private Date fecLlegada;
	
	 @Column(name = "NUM_RUC_CONFIR")
	 private String numRucConfirmacion;
	
	 @Column(name = "OBS_CONFIRMACION")
	 private String obsConfirmacion;

	 private Long cantidad;
	 
	 
	 
	public Long getCantidad() {
		return cantidad;
	}

	public void setCantidad(Long cantidad) {
		this.cantidad = cantidad;
	}

	public Integer getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(Integer codCpe) {
		this.codCpe = codCpe;
	}

	public Integer getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(Integer numCpe) {
		this.numCpe = numCpe;
	}

	public Integer getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(Integer numRuc) {
		this.numRuc = numRuc;
	}

	public Integer getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(Integer numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public Long getCodConfirmacion() {
		return codConfirmacion;
	}

	public void setCodConfirmacion(Long codConfirmacion) {
		this.codConfirmacion = codConfirmacion;
	}

	public String getCodResultado() {
		return codResultado;
	}

	public void setCodResultado(String codResultado) {
		this.codResultado = codResultado;
	}

	public String getCodTipo() {
		return codTipo;
	}

	public void setCodTipo(String codTipo) {
		this.codTipo = codTipo;
	}

	public String getDirLlegada() {
		return dirLlegada;
	}

	public void setDirLlegada(String dirLlegada) {
		this.dirLlegada = dirLlegada;
	}

	public Date getFecConfirmacion() {
		return fecConfirmacion;
	}

	public void setFecConfirmacion(Date fecConfirmacion) {
		this.fecConfirmacion = fecConfirmacion;
	}

	public Date getFecLlegada() {
		return fecLlegada;
	}

	public void setFecLlegada(Date fecLlegada) {
		this.fecLlegada = fecLlegada;
	}

	public String getNumRucConfirmacion() {
		return numRucConfirmacion;
	}

	public void setNumRucConfirmacion(String numRucConfirmacion) {
		this.numRucConfirmacion = numRucConfirmacion;
	}

	public String getObsConfirmacion() {
		return obsConfirmacion;
	}

	public void setObsConfirmacion(String obsConfirmacion) {
		this.obsConfirmacion = obsConfirmacion;
	}
	

}
