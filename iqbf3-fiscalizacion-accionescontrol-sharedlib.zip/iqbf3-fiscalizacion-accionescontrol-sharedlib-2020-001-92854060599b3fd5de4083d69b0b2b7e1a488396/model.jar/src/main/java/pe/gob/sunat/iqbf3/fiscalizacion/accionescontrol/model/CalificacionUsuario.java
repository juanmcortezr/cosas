package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10400CALIUSUA")
public class CalificacionUsuario extends Auditoria{

	
	 @Column(name = "DES_SUS_ACCSUGE")
	 private String desSusAccsuge;
	
	 @Column(name = "IND_TIP_CALI")
	 private String indTipCali;
	
	 @Id
	 @Column(name = "NUM_USU_CALI")
	 private Long numUsuarioCalifiicacion;
	
	 @Column(name = "VAL_CALIFICACION")
	 private Double valCalificacion;

	 @Column(name = "NUM_ACC_SUGERIDA")
	 private Long numAccionSugerida;

	@Column(name = "NUM_USU_SOLIC")
	 private Long numUsuarioSolicitud;
	

	public Long getNumAccionSugerida() {
		return numAccionSugerida;
	}

	public void setNumAccionSugerida(Long numAccionSugerida) {
		this.numAccionSugerida = numAccionSugerida;
	}

	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public String getDesSusAccsuge() {
		return desSusAccsuge;
	}

	public void setDesSusAccsuge(String desSusAccsuge) {
		this.desSusAccsuge = desSusAccsuge;
	}

	public String getIndTipCali() {
		return indTipCali;
	}

	public void setIndTipCali(String indTipCali) {
		this.indTipCali = indTipCali;
	}

	public Long getNumUsuarioCalifiicacion() {
		return numUsuarioCalifiicacion;
	}

	public void setNumUsuarioCalifiicacion(Long numUsuarioCalifiicacion) {
		this.numUsuarioCalifiicacion = numUsuarioCalifiicacion;
	}

	public Double getValCalificacion() {
		return valCalificacion;
	}

	public void setValCalificacion(Double valCalificacion) {
		this.valCalificacion = valCalificacion;
	}

}
