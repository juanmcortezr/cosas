package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T4429DOCREL")
public class DocumentoRelacionado implements Entidad{

	@EmbeddedId
	 private DocumentoRelacionadoPK documentoRelacionadoPk;
	
	 @Column(name = "COD_RELACION")
	 private String codRelacion;

	public DocumentoRelacionadoPK getDocumentoRelacionadoPk() {
		return documentoRelacionadoPk;
	}

	public void setDocumentoRelacionadoPk(DocumentoRelacionadoPK documentoRelacionadoPk) {
		this.documentoRelacionadoPk = documentoRelacionadoPk;
	}

	public String getCodRelacion() {
		return codRelacion;
	}

	public void setCodRelacion(String codRelacion) {
		this.codRelacion = codRelacion;
	}
	
	

}
