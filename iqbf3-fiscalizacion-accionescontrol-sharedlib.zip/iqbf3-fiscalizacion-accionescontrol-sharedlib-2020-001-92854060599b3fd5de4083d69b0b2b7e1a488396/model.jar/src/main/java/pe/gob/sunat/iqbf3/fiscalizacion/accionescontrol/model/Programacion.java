package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienFiscalizadoSolicitudBean;
//import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CheckElementBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;

@Entity
@Table(name = "T10420PROGRAMACION")
public class Programacion extends Auditoria {

	@Id
	@Column(name = "NUM_PROGRAMACION")
	private Long numProgramacion;

	@Column(name = "ANN_PROGRAMACION")
	private Integer anioProgramacion;

	@Column(name = "COD_EST_PROGRAM")
	private String codEstadoPrograma;

	@Column(name = "COD_FUENTE")
	private String codFuente;

	@Column(name = "COD_PROCESO")
	private String codProceso;

	@Column(name = "COD_PROGRAMADOR")
	private String codProgramador;

	@Column(name = "COD_SUB_ESTPROGRAM")
	private String codSubEstadoProgram;

	@Column(name = "COD_TIP_PROGRAM")
	private String codTipoProgram;

	@Column(name = "DES_ALCANCE")
	private String desAlcance;

	@Column(name = "DES_OTRA_FUENTE")
	private String desOtraFuente;

	@Column(name = "DES_PROGRAMACION")
	private String desProgramacion;

	@Column(name = "DES_SUS_CANCELA")
	private String desSusCancela;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEC_PROGRAMACION")
	private Date fecProgramacion;

	@Column(name = "IND_CIERRE")
	private String indCierre;

	@Column(name = "NUM_INF_CANCELA")
	private String numInformeCancelacion;

	@Column(name = "NUM_PLAZO_VERIF")
	private String numPlazoVerificacion;

	@Column(name = "NUM_PROG_CORREL")
	private Integer numProgramaCorrel;

	@Column(name = "OBS_PROGRAMACION")
	private String obsProgramacion;

	@Column(name = "PER_FIN")
	private String perFin;

	@Column(name = "PER_INICIO")
	private String perInicio;

	@Column(name = "COD_PROGCTRL")
	private String codProgctrl;
	
	//@Column(name = "IND_ASIGMASORDENNOCONF")
	

	@Column(name = "IND_ASIGMASORDENNO")
	private String indAsigMasOrdenNoConf;

	// Para filtro
	@Transient
	private Date fechaDesde;
	@Transient
	private Date fechaHasta;
	@Transient
	private Date fechaIniAsignacion;
	@Transient
	private String numInforme;
	@Transient
	private String codEstadoInforme;
	@Transient
	private String desProgctrl;
	@Transient
	private String codProgramadorAdmin;
	@Transient
	private String codEstInforme;
	@Transient
	private String codTipoDocumentoIdent;
	@Transient
	private String numDocumentoIdent;
	@Transient
	private String codResulInconsis;
	@Transient
	private String codResulIncondef;

	@Transient
	private List<DataCatalogoBean> inconsistencias;
	@Transient
	private List<DataCatalogoBean> tipoBienes;
	@Transient
	private List<BienFiscalizadoSolicitudBean> bienesFiscalizados;
	@Transient
	private List<DataCatalogoBean> respInconsistencias;
	@Transient
	private String codTipoAccion;
	@Transient
	private String desTipoAccion;
	@Transient
	private String codTipoOrden;
	@Transient
	private String desTipoOrden;
	@Transient
	private String codEstOrden;
	@Transient
	private String numOrden;
	@Transient
	private String desEstOrden;
	@Transient
	private String codResOrden;
	@Transient
	private String desResOrden;
	@Transient
	private List<String> estadosPrograma;
	@Transient
	private List<String> estadosProgramaDefinido;
	@Transient
	private String codTipInterv;
	@Transient
	private String nombAuditAsignad;
	@Transient
	private String codTipoBien;
	@Transient
	private String codTipoArchivo;
	@Transient
	private String codTipInconsis;
	@Transient
	private String nombApeUsuario;
	@Transient
	private String numDocAccion;
	@Transient
	private String codBien;
	@Transient
	private String codPers;
	@Transient
	private String codPersApoyo;
	@Transient
	private String numDocVin;
	@Transient
	private String numSolicitudUnion;
	@Transient
	private String nombAuditApoyo;
	@Transient
	private String codClaseAccion;
	@Transient
	private String codClaseVincul;
	@Transient
	private String codCargoPrincipal;
	@Transient
	private String codCargoApoyo;
	@Transient
	private String nroInformeUnion;
	@Transient
	private Date fecIniAsignacion;
	@Transient
	private Date fechaFinAsig;
	@Transient
	private String numGrupo;
	@Transient
	private String desEstadoInforme;
	@Transient
	private String numAlcanceProgramacion;
	@Transient
	private String indTipoAsignacion;
	@Transient
	private Integer cantFinalUsuario;
	@Transient
	private Integer cantUsuariosDepurados;
	@Transient
	private String indNoDepurado;
	@Transient
	private String indDepurado;	
	@Transient
	private Date fecUltimoEstado;
	@Transient
	private String codProgramaControl;
	@Transient
	private String nomProgramador;
	@Transient
	private String nomProgramadorAdmin;
	@Transient
	private String numProgramacionUnion;
	@Transient
	private String fecEstPrograma;
	@Transient 
	private String indTipAsignacion;
	@Transient 
	private String indTipAsignaProg;
	@Transient 
	private String indTipAsignaProgAdmi;
	
	
	public String getIndTipAsignaProgAdmi() {
		return indTipAsignaProgAdmi;
	}

	public void setIndTipAsignaProgAdmi(String indTipAsignaProgAdmi) {
		this.indTipAsignaProgAdmi = indTipAsignaProgAdmi;
	}

	public String getIndTipAsignaProg() {
		return indTipAsignaProg;
	}

	public void setIndTipAsignaProg(String indTipAsignaProg) {
		this.indTipAsignaProg = indTipAsignaProg;
	}

	public String getIndTipAsignacion() {
		return indTipAsignacion;
	}

	public void setIndTipAsignacion(String indTipAsignacion) {
		this.indTipAsignacion = indTipAsignacion;
	}

	public String getFecEstPrograma() {
		return fecEstPrograma;
	}

	public void setFecEstPrograma(String fecEstPrograma) {
		this.fecEstPrograma = fecEstPrograma;
	}

	public String getNumProgramacionUnion() {
		return numProgramacionUnion;
	}

	public void setNumProgramacionUnion(String numProgramacionUnion) {
		this.numProgramacionUnion = numProgramacionUnion;
	}

	public String getNomProgramadorAdmin() {
		return nomProgramadorAdmin;
	}

	public void setNomProgramadorAdmin(String nomProgramadorAdmin) {
		this.nomProgramadorAdmin = nomProgramadorAdmin;
	}

	public String getNomProgramador() {
		return nomProgramador;
	}

	public void setNomProgramador(String nomProgramador) {
		this.nomProgramador = nomProgramador;
	}

	public String getCodProgramaControl() {
		return codProgramaControl;
	}

	public void setCodProgramaControl(String codProgramaControl) {
		this.codProgramaControl = codProgramaControl;
	}

	public Date getFecUltimoEstado() {
		return fecUltimoEstado;
	}

	public void setFecUltimoEstado(Date fecUltimoEstado) {
		this.fecUltimoEstado = fecUltimoEstado;
	}

	public Integer getCantUsuariosDepurados() {
		return cantUsuariosDepurados;
	}

	public void setCantUsuariosDepurados(Integer cantUsuariosDepurados) {
		this.cantUsuariosDepurados = cantUsuariosDepurados;
	}

	public Integer getCantFinalUsuario() {
		return cantFinalUsuario;
	}

	public void setCantFinalUsuario(Integer cantFinalUsuario) {
		this.cantFinalUsuario = cantFinalUsuario;
	}

	public String getIndDepurado() {
		return indDepurado;
	}

	public void setIndDepurado(String indDepurado) {
		this.indDepurado = indDepurado;
	}

	public String getIndNoDepurado() {
		return indNoDepurado;
	}

	public void setIndNoDepurado(String indNoDepurado) {
		this.indNoDepurado = indNoDepurado;
	}
	public String getIndTipoAsignacion() {
		return indTipoAsignacion;
	}

	public void setIndTipoAsignacion(String indTipoAsignacion) {
		this.indTipoAsignacion = indTipoAsignacion;
	}

	public String getNumAlcanceProgramacion() {
		return numAlcanceProgramacion;
	}

	public void setNumAlcanceProgramacion(String numAlcanceProgramacion) {
		this.numAlcanceProgramacion = numAlcanceProgramacion;
	}

	public String getDesEstadoInforme() {
		return desEstadoInforme;
	}

	public void setDesEstadoInforme(String desEstadoInforme) {
		this.desEstadoInforme = desEstadoInforme;
	}

	public String getNumGrupo() {
		return numGrupo;
	}

	public void setNumGrupo(String numGrupo) {
		this.numGrupo = numGrupo;
	}

	public Date getFecIniAsignacion() {
		return fecIniAsignacion;
	}

	public void setFecIniAsignacion(Date fecIniAsignacion) {
		this.fecIniAsignacion = fecIniAsignacion;
	}

	public Date getFechaFinAsig() {
		return fechaFinAsig;
	}

	public void setFechaFinAsig(Date fechaFinAsig) {
		this.fechaFinAsig = fechaFinAsig;
	}

	public List<String> getEstadosProgramaDefinido() {
		return estadosProgramaDefinido;
	}

	public void setEstadosProgramaDefinido(List<String> estadosProgramaDefinido) {
		this.estadosProgramaDefinido = estadosProgramaDefinido;
	}

	public String getCodPersApoyo() {
		return codPersApoyo;
	}

	public void setCodPersApoyo(String codPersApoyo) {
		this.codPersApoyo = codPersApoyo;
	}

	public String getNroInformeUnion() {
		return nroInformeUnion;
	}

	public void setNroInformeUnion(String nroInformeUnion) {
		this.nroInformeUnion = nroInformeUnion;
	}

	public String getCodCargoApoyo() {
		return codCargoApoyo;
	}

	public void setCodCargoApoyo(String codCargoApoyo) {
		this.codCargoApoyo = codCargoApoyo;
	}

	public String getCodClaseVincul() {
		return codClaseVincul;
	}

	public void setCodClaseVincul(String codClaseVincul) {
		this.codClaseVincul = codClaseVincul;
	}

	public String getCodCargoPrincipal() {
		return codCargoPrincipal;
	}

	public void setCodCargoPrincipal(String codCargoPrincipal) {
		this.codCargoPrincipal = codCargoPrincipal;
	}

	public String getCodClaseAccion() {
		return codClaseAccion;
	}

	public void setCodClaseAccion(String codClaseAccion) {
		this.codClaseAccion = codClaseAccion;
	}

	public String getNombAuditApoyo() {
		return nombAuditApoyo;
	}

	public void setNombAuditApoyo(String nombAuditApoyo) {
		this.nombAuditApoyo = nombAuditApoyo;
	}

	public String getNumSolicitudUnion() {
		return numSolicitudUnion;
	}

	public void setNumSolicitudUnion(String numSolicitudUnion) {
		this.numSolicitudUnion = numSolicitudUnion;
	}

	public String getNumDocVin() {
		return numDocVin;
	}

	public void setNumDocVin(String numDocVin) {
		this.numDocVin = numDocVin;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getCodBien() {
		return codBien;
	}

	public void setCodBien(String codBien) {
		this.codBien = codBien;
	}

	public String getNumDocAccion() {
		return numDocAccion;
	}

	public void setNumDocAccion(String numDocAccion) {
		this.numDocAccion = numDocAccion;
	}

	public String getNombApeUsuario() {
		return nombApeUsuario;
	}

	public void setNombApeUsuario(String nombApeUsuario) {
		this.nombApeUsuario = nombApeUsuario;
	}

	public String getCodResulInconsis() {
		return codResulInconsis;
	}

	public void setCodResulInconsis(String codResulInconsis) {
		this.codResulInconsis = codResulInconsis;
	}

	public String getCodResulIncondef() {
		return codResulIncondef;
	}

	public void setCodResulIncondef(String codResulIncondef) {
		this.codResulIncondef = codResulIncondef;
	}

	public String getCodTipInconsis() {
		return codTipInconsis;
	}

	public void setCodTipInconsis(String codTipInconsis) {
		this.codTipInconsis = codTipInconsis;
	}

	public String getCodTipoArchivo() {
		return codTipoArchivo;
	}

	public void setCodTipoArchivo(String codTipoArchivo) {
		this.codTipoArchivo = codTipoArchivo;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getNombAuditAsignad() {
		return nombAuditAsignad;
	}

	public void setNombAuditAsignad(String nombAuditAsignad) {
		this.nombAuditAsignad = nombAuditAsignad;
	}

	public String getCodTipInterv() {
		return codTipInterv;
	}

	public void setCodTipInterv(String codTipInterv) {
		this.codTipInterv = codTipInterv;
	}

	@Transient
	private Long numUsuarioPrograma;
	
	
	
	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public String getCodEstOrden() {
		return codEstOrden;
	}

	public void setCodEstOrden(String codEstOrden) {
		this.codEstOrden = codEstOrden;
	}

	public String getDesEstOrden() {
		return desEstOrden;
	}

	public void setDesEstOrden(String desEstOrden) {
		this.desEstOrden = desEstOrden;
	}

	public String getCodResOrden() {
		return codResOrden;
	}

	public void setCodResOrden(String codResOrden) {
		this.codResOrden = codResOrden;
	}

	public String getDesResOrden() {
		return desResOrden;
	}

	public void setDesResOrden(String desResOrden) {
		this.desResOrden = desResOrden;
	}

	public String getDesTipoOrden() {
		return desTipoOrden;
	}

	public void setDesTipoOrden(String desTipoOrden) {
		this.desTipoOrden = desTipoOrden;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String setCodTipoAccion) {
		this.codTipoAccion = setCodTipoAccion;
	}

	public String getDesTipoAccion() {
		return desTipoAccion;
	}

	public void setDesTipoAccion(String setDesTipoAccion) {
		this.desTipoAccion = setDesTipoAccion;
	}

	public List<DataCatalogoBean> getInconsistencias() {
		return inconsistencias;
	}

	public void setInconsistencias(List<DataCatalogoBean> inconsistencias) {
		this.inconsistencias = inconsistencias;
	}

	public List<DataCatalogoBean> getTipoBienes() {
		return tipoBienes;
	}

	public void setTipoBienes(List<DataCatalogoBean> tipoBienes) {
		this.tipoBienes = tipoBienes;
	}

	public List<DataCatalogoBean> getRespInconsistencias() {
		return respInconsistencias;
	}

	public void setRespInconsistencias(List<DataCatalogoBean> respInconsistencias) {
		this.respInconsistencias = respInconsistencias;
	}

	public List<BienFiscalizadoSolicitudBean> getBienesFiscalizados() {
		return bienesFiscalizados;
	}

	public void setBienesFiscalizados(List<BienFiscalizadoSolicitudBean> bienesFiscalizados) {
		this.bienesFiscalizados = bienesFiscalizados;
	}

	public String getCodTipoOrden() {
		return codTipoOrden;
	}

	public void setCodTipoOrden(String codTipoOrden) {
		this.codTipoOrden = codTipoOrden;
	}

	public String getCodTipoDocumentoIdent() {
		return codTipoDocumentoIdent;
	}

	public void setCodTipoDocumentoIdent(String codTipoDocumentoIdent) {
		this.codTipoDocumentoIdent = codTipoDocumentoIdent;
	}

	public String getNumDocumentoIdent() {
		return numDocumentoIdent;
	}

	public void setNumDocumentoIdent(String numDocumentoIdent) {
		this.numDocumentoIdent = numDocumentoIdent;
	}

	public String getCodEstInforme() {
		return codEstInforme;
	}

	public void setCodEstInforme(String codEstInforme) {
		this.codEstInforme = codEstInforme;
	}

	public String getCodProgramadorAdmin() {
		return codProgramadorAdmin;
	}

	public void setCodProgramadorAdmin(String codProgramadorAdmin) {
		this.codProgramadorAdmin = codProgramadorAdmin;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public Integer getAnioProgramacion() {
		return anioProgramacion;
	}

	public void setAnioProgramacion(Integer anioProgramacion) {
		this.anioProgramacion = anioProgramacion;
	}

	public String getCodEstadoPrograma() {
		return codEstadoPrograma;
	}

	public void setCodEstadoPrograma(String codEstadoPrograma) {
		this.codEstadoPrograma = codEstadoPrograma;
	}

	public String getCodFuente() {
		return codFuente;
	}

	public void setCodFuente(String codFuente) {
		this.codFuente = codFuente;
	}

	public String getCodProceso() {
		return codProceso;
	}

	public void setCodProceso(String codProceso) {
		this.codProceso = codProceso;
	}

	public String getCodProgramador() {
		return codProgramador;
	}

	public void setCodProgramador(String codProgramador) {
		this.codProgramador = codProgramador;
	}

	public String getCodSubEstadoProgram() {
		return codSubEstadoProgram;
	}

	public void setCodSubEstadoProgram(String codSubEstadoProgram) {
		this.codSubEstadoProgram = codSubEstadoProgram;
	}

	public String getCodTipoProgram() {
		return codTipoProgram;
	}

	public void setCodTipoProgram(String codTipoProgram) {
		this.codTipoProgram = codTipoProgram;
	}

	public String getDesAlcance() {
		return desAlcance;
	}

	public void setDesAlcance(String desAlcance) {
		this.desAlcance = desAlcance;
	}

	public String getDesOtraFuente() {
		return desOtraFuente;
	}

	public void setDesOtraFuente(String desOtraFuente) {
		this.desOtraFuente = desOtraFuente;
	}

	public String getDesProgramacion() {
		return desProgramacion;
	}

	public void setDesProgramacion(String desProgramacion) {
		this.desProgramacion = desProgramacion;
	}

	public String getDesSusCancela() {
		return desSusCancela;
	}

	public void setDesSusCancela(String desSusCancela) {
		this.desSusCancela = desSusCancela;
	}

	public Date getFecProgramacion() {
		return fecProgramacion;
	}

	public void setFecProgramacion(Date fecProgramacion) {
		this.fecProgramacion = fecProgramacion;
	}

	public String getIndCierre() {
		return indCierre;
	}

	public void setIndCierre(String indCierre) {
		this.indCierre = indCierre;
	}

	public String getNumInformeCancelacion() {
		return numInformeCancelacion;
	}

	public void setNumInformeCancelacion(String numInformeCancelacion) {
		this.numInformeCancelacion = numInformeCancelacion;
	}

	public String getNumPlazoVerificacion() {
		return numPlazoVerificacion;
	}

	public void setNumPlazoVerificacion(String numPlazoVerificacion) {
		this.numPlazoVerificacion = numPlazoVerificacion;
	}

	public Integer getNumProgramaCorrel() {
		return numProgramaCorrel;
	}

	public void setNumProgramaCorrel(Integer numProgramaCorrel) {
		this.numProgramaCorrel = numProgramaCorrel;
	}

	public String getObsProgramacion() {
		return obsProgramacion;
	}

	public void setObsProgramacion(String obsProgramacion) {
		this.obsProgramacion = obsProgramacion;
	}

	public String getPerFin() {
		return perFin;
	}

	public void setPerFin(String perFin) {
		this.perFin = perFin;
	}

	public String getPerInicio() {
		return perInicio;
	}

	public void setPerInicio(String perInicio) {
		this.perInicio = perInicio;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getNumInforme() {
		return numInforme;
	}

	public void setNumInforme(String numInforme) {
		this.numInforme = numInforme;
	}

	public String getCodEstadoInforme() {
		return codEstadoInforme;
	}

	public void setCodEstadoInforme(String codEstadoInforme) {
		this.codEstadoInforme = codEstadoInforme;
	}

	public String getDesProgctrl() {
		return desProgctrl;
	}

	public void setDesProgctrl(String desProgctrl) {
		this.desProgctrl = desProgctrl;
	}

	public String getCodProgctrl() {
		return codProgctrl;
	}

	public void setCodProgctrl(String codProgctrl) {
		this.codProgctrl = codProgctrl;
	}

	public Date getFechaIniAsignacion() {
		return fechaIniAsignacion;
	}

	public void setFechaIniAsignacion(Date fechaIniAsignacion) {
		this.fechaIniAsignacion = fechaIniAsignacion;
	}
	
	public List<String> getEstadosPrograma() {
		return estadosPrograma;
	}

	public void setEstadosPrograma(List<String> estadosPrograma) {
		this.estadosPrograma = estadosPrograma;
	}
	
	public String getIndAsigMasOrdenNoConf() {
		return indAsigMasOrdenNoConf;
	}

	public void setIndAsigMasOrdenNoConf(String indAsigMasOrdenNoConf) {
		this.indAsigMasOrdenNoConf = indAsigMasOrdenNoConf;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}

}
