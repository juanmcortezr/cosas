package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class BienEstablecimientoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	double	cantidadStockFisico;
	private	String	codBienFiscalizado;
	private	String	codTipoBien;
	private	String	codUnidadMedida;
	private	String	desBien;
	private	String	desBienFisca;
	private	String	desTipoBien;
	private	String	desUnidadMedida;
	private	String	fecStockFisico;
	private	String	horStockFisico;
	private	int	numBienEstablecimiento;
	private	int	numEstablecimientoOrden;
	private boolean indObtenerActa; 
	private List<ActaBienOrdenBean> lstActaBienEstablecimiento;
	
	private String indDel;
	private String indEst;
	private AuditoriaBean auditoriaBean;
	
	public BienEstablecimientoBean() {
		super();
	}

	public BienEstablecimientoBean(double cantidadStockFisico, String codBienFiscalizado, String codTipoBien,
			String codUnidadMedida, String desBien, String desBienFisca, String desTipoBien, String desUnidadMedida,
			String fecStockFisico, String horStockFisico, int numBienEstablecimiento, int numEstablecimientoOrden) {
		super();
		this.cantidadStockFisico = cantidadStockFisico;
		this.codBienFiscalizado = codBienFiscalizado;
		this.codTipoBien = codTipoBien;
		this.codUnidadMedida = codUnidadMedida;
		this.desBien = desBien;
		this.desBienFisca = desBienFisca;
		this.desTipoBien = desTipoBien;
		this.desUnidadMedida = desUnidadMedida;
		this.fecStockFisico = fecStockFisico;
		this.horStockFisico = horStockFisico;
		this.numBienEstablecimiento = numBienEstablecimiento;
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public double getCantidadStockFisico() {
		return cantidadStockFisico;
	}

	public void setCantidadStockFisico(double cantidadStockFisico) {
		this.cantidadStockFisico = cantidadStockFisico;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getCodUnidadMedida() {
		return codUnidadMedida;
	}

	public void setCodUnidadMedida(String codUnidadMedida) {
		this.codUnidadMedida = codUnidadMedida;
	}

	public String getDesBien() {
		return desBien;
	}

	public void setDesBien(String desBien) {
		this.desBien = desBien;
	}

	public String getDesBienFisca() {
		return desBienFisca;
	}

	public void setDesBienFisca(String desBienFisca) {
		this.desBienFisca = desBienFisca;
	}

	public String getDesTipoBien() {
		return desTipoBien;
	}

	public void setDesTipoBien(String desTipoBien) {
		this.desTipoBien = desTipoBien;
	}

	public String getDesUnidadMedida() {
		return desUnidadMedida;
	}

	public void setDesUnidadMedida(String desUnidadMedida) {
		this.desUnidadMedida = desUnidadMedida;
	}

	public String getFecStockFisico() {
		return fecStockFisico;
	}

	public void setFecStockFisico(String fecStockFisico) {
		this.fecStockFisico = fecStockFisico;
	}

	public String getHorStockFisico() {
		return horStockFisico;
	}

	public void setHorStockFisico(String horStockFisico) {
		this.horStockFisico = horStockFisico;
	}

	public int getNumBienEstablecimiento() {
		return numBienEstablecimiento;
	}

	public void setNumBienEstablecimiento(int numBienEstablecimiento) {
		this.numBienEstablecimiento = numBienEstablecimiento;
	}

	public int getNumEstablecimientoOrden() {
		return numEstablecimientoOrden;
	}

	public void setNumEstablecimientoOrden(int numEstablecimientoOrden) {
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isIndObtenerActa() {
		return indObtenerActa;
	}

	public void setIndObtenerActa(boolean indObtenerActa) {
		this.indObtenerActa = indObtenerActa;
	}

	public List<ActaBienOrdenBean> getLstActaBienEstablecimiento() {
		return lstActaBienEstablecimiento;
	}

	public void setLstActaBienEstablecimiento(List<ActaBienOrdenBean> lstActaBienEstablecimiento) {
		this.lstActaBienEstablecimiento = lstActaBienEstablecimiento;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}
	
	
	
	
}
