package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

public class ResumenStockEstablecBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private double cntIngEst;
	private double cantidadSalidaEstablec;
	private double cantidadStockActual;
	private String codTipobien;
	private String fecFinCalc;
	private String fecInicioCalculo;
	private int numConfirma;
	private String numEstablecimiento;
	private String numPeriodo;
	private int numPresentacion;
	private int numReposicion;
	private int numStock;
	private int numRuc;
	private int numVersionRegistro;
	private String indDel;
	private String indEst;
	private String indCondicion;
	
	private List<String> lstEstadoUsuarios;
	
	private String codEstadoItem;
	
	
	
	public String getCodEstadoItem() {
		return codEstadoItem;
	}

	public void setCodEstadoItem(String codEstadoItem) {
		this.codEstadoItem = codEstadoItem;
	}

	public List<String> getLstEstadoUsuarios() {
		return lstEstadoUsuarios;
	}

	public void setLstEstadoUsuarios(List<String> lstEstadoUsuarios) {
		this.lstEstadoUsuarios = lstEstadoUsuarios;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public String getIndCondicion() {
		return indCondicion;
	}

	public void setIndCondicion(String indCondicion) {
		this.indCondicion = indCondicion;
	}

	public ResumenStockEstablecBean() {
		super();
	}

	public ResumenStockEstablecBean(double cntIngEst, double cantidadSalidaEstablec, double cantidadStockActual,
			String codTipobien, String fecFinCalc, String fecInicioCalculo, int numConfirma, String numEstablecimiento,
			String numPeriodo, int numPresentacion, int numReposicion, int numStock, int numRuc,
			int numVersionRegistro) {
		super();
		this.cntIngEst = cntIngEst;
		this.cantidadSalidaEstablec = cantidadSalidaEstablec;
		this.cantidadStockActual = cantidadStockActual;
		this.codTipobien = codTipobien;
		this.fecFinCalc = fecFinCalc;
		this.fecInicioCalculo = fecInicioCalculo;
		this.numConfirma = numConfirma;
		this.numEstablecimiento = numEstablecimiento;
		this.numPeriodo = numPeriodo;
		this.numPresentacion = numPresentacion;
		this.numReposicion = numReposicion;
		this.numStock = numStock;
		this.numRuc = numRuc;
		this.numVersionRegistro = numVersionRegistro;
	}

	public double getCntIngEst() {
		return cntIngEst;
	}

	public void setCntIngEst(double cntIngEst) {
		this.cntIngEst = cntIngEst;
	}

	public double getCantidadSalidaEstablec() {
		return cantidadSalidaEstablec;
	}

	public void setCantidadSalidaEstablec(double cantidadSalidaEstablec) {
		this.cantidadSalidaEstablec = cantidadSalidaEstablec;
	}

	public double getCantidadStockActual() {
		return cantidadStockActual;
	}

	public void setCantidadStockActual(double cantidadStockActual) {
		this.cantidadStockActual = cantidadStockActual;
	}

	public String getCodTipobien() {
		return codTipobien;
	}

	public void setCodTipobien(String codTipobien) {
		this.codTipobien = codTipobien;
	}

	public String getFecFinCalc() {
		return fecFinCalc;
	}

	public void setFecFinCalc(String fecFinCalc) {
		this.fecFinCalc = fecFinCalc;
	}

	public String getFecInicioCalculo() {
		return fecInicioCalculo;
	}

	public void setFecInicioCalculo(String fecInicioCalculo) {
		this.fecInicioCalculo = fecInicioCalculo;
	}

	public int getNumConfirma() {
		return numConfirma;
	}

	public void setNumConfirma(int numConfirma) {
		this.numConfirma = numConfirma;
	}

	public String getNumEstablecimiento() {
		return numEstablecimiento;
	}

	public void setNumEstablecimiento(String numEstablecimiento) {
		this.numEstablecimiento = numEstablecimiento;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public int getNumPresentacion() {
		return numPresentacion;
	}

	public void setNumPresentacion(int numPresentacion) {
		this.numPresentacion = numPresentacion;
	}

	public int getNumReposicion() {
		return numReposicion;
	}

	public void setNumReposicion(int numReposicion) {
		this.numReposicion = numReposicion;
	}

	public int getNumStock() {
		return numStock;
	}

	public void setNumStock(int numStock) {
		this.numStock = numStock;
	}

	public int getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(int numRuc) {
		this.numRuc = numRuc;
	}

	public int getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(int numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

}
