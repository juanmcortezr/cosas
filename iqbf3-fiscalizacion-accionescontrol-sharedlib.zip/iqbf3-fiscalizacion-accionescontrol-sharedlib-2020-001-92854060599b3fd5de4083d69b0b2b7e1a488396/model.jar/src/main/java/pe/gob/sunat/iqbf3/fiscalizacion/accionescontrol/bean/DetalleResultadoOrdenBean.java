package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class DetalleResultadoOrdenBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codResulOrden;
	private	String	desOtroResultado;
	private	String	desResulOrden;
	private	int	numDetalleResultadoOrden;
	private	int	numOrden;
	private String indSeleccionado;
	
	private String indDel;
	private String indEst;
	private AuditoriaBean auditoriaBean;
	
	public DetalleResultadoOrdenBean() {
		super();
	}

	public DetalleResultadoOrdenBean(String codResulOrden, String desOtroResultado, String desResulOrden,
			int numDetalleResultadoOrden, int numOrden) {
		super();
		this.codResulOrden = codResulOrden;
		this.desOtroResultado = desOtroResultado;
		this.desResulOrden = desResulOrden;
		this.numDetalleResultadoOrden = numDetalleResultadoOrden;
		this.numOrden = numOrden;
	}

	public String getCodResulOrden() {
		return codResulOrden;
	}

	public void setCodResulOrden(String codResulOrden) {
		this.codResulOrden = codResulOrden;
	}

	public String getDesOtroResultado() {
		return desOtroResultado;
	}

	public void setDesOtroResultado(String desOtroResultado) {
		this.desOtroResultado = desOtroResultado;
	}

	public String getDesResulOrden() {
		return desResulOrden;
	}

	public void setDesResulOrden(String desResulOrden) {
		this.desResulOrden = desResulOrden;
	}

	public int getNumDetalleResultadoOrden() {
		return numDetalleResultadoOrden;
	}

	public void setNumDetalleResultadoOrden(int numDetalleResultadoOrden) {
		this.numDetalleResultadoOrden = numDetalleResultadoOrden;
	}

	public int getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(int numOrden) {
		this.numOrden = numOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIndSeleccionado() {
		return indSeleccionado;
	}

	public void setIndSeleccionado(String indSeleccionado) {
		this.indSeleccionado = indSeleccionado;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}
	
	
	
}
