package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "T10393ASIGNASOLIC")
public class AsignaSolicitud extends Auditoria {

	 @Column(name = "COD_PERS")
	 private String codProgramador;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_FIN_ASIGNACION")
	 private Date fecFinAsignacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_ASIGNACION")
	 private Date fecInicioAsignacion;
	
	 @Id
	 @Column(name = "NUM_ASIG_SOLIC")
	 private Long numAsignacionSolic;

	 @Column(name = "NUM_SOLIC_PROG")
	 private Long numSolicitud;
	

	public Long getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Long numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public String getCodProgramador() {
		return codProgramador;
	}

	public void setCodProgramador(String codProgramador) {
		this.codProgramador = codProgramador;
	}

	public Date getFecFinAsignacion() {
		return fecFinAsignacion;
	}

	public void setFecFinAsignacion(Date fecFinAsignacion) {
		this.fecFinAsignacion = fecFinAsignacion;
	}

	public Date getFecInicioAsignacion() {
		return fecInicioAsignacion;
	}

	public void setFecInicioAsignacion(Date fecInicioAsignacion) {
		this.fecInicioAsignacion = fecInicioAsignacion;
	}

	public Long getNumAsignacionSolic() {
		return numAsignacionSolic;
	}

	public void setNumAsignacionSolic(Long numAsignacionSolic) {
		this.numAsignacionSolic = numAsignacionSolic;
	}
	 
}
