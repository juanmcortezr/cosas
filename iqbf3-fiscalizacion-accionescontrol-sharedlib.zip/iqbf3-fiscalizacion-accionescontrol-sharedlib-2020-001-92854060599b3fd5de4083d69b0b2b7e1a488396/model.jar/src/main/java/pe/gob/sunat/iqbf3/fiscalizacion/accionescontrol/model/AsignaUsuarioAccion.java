package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


@Entity
@Table(name = "T10394ASIGNAUSUACC")
public class AsignaUsuarioAccion extends Auditoria {

	
	 @Column(name = "COD_CARGO")
	 private String codCargo;
	
	 @Column(name = "COD_PERS")
	 private String codAuditor;

	 //@Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_FIN_ASIGNACION")
	 private Date fecFinAsignacion;

	 //@Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_ASIGNACION")
	 private Date fecInicioAsignacion;
	
	 @Column(name = "IND_TIP_ASIGNACION")
	 private String indTipAsignacion;
	
	 @Id
	 @Column(name = "NUM_ASIG_ACCION")
	 private Long numAsignacionAccion;

	 @Column(name = "NUM_USU_PROGRAM")
	 private Long numUsuarioPrograma;

	 @Transient
	 private List<String> estadoOrden;
	 
	 @Transient
	 private String codPers;
	 
	 @Transient
	 private Long numProgramacion;
	 
	 @Transient
	 private String codTipIntControl;
	 
	 @Transient
	 private String codTipoProceso;
	 
	 @Transient
	 private String numGrupo;
	 
	 @Transient
	 private String asignaUsuarioAccion;

	 @Transient
	 private Long cntCarga;

	public String getAsignaUsuarioAccion() {
		return asignaUsuarioAccion;
	}

	public void setAsignaUsuarioAccion(String asignaUsuarioAccion) {
		this.asignaUsuarioAccion = asignaUsuarioAccion;
	}

	public String getNumGrupo() {
		return numGrupo;
	}

	public void setNumGrupo(String numGrupo) {
		this.numGrupo = numGrupo;
	}

	public String getCodTipoProceso() {
		return codTipoProceso;
	}

	public void setCodTipoProceso(String codTipoProceso) {
		this.codTipoProceso = codTipoProceso;
	}
	 	 
	public Long getCntCarga() {
		return cntCarga;
	}

	public void setCntCarga(Long cntCarga) {
		this.cntCarga = cntCarga;
	}

	public String getCodTipIntControl() {
		return codTipIntControl;
	}

	public void setCodTipIntControl(String codTipIntControl) {
		this.codTipIntControl = codTipIntControl;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public List<String> getEstadoOrden() {
		return estadoOrden;
	}

	public void setEstadoOrden(List<String> estadoOrden) {
		this.estadoOrden = estadoOrden;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public String getCodCargo() {
		return codCargo;
	}

	public void setCodCargo(String codCargo) {
		this.codCargo = codCargo;
	}

	public Date getFecInicioAsignacion() {
		return fecInicioAsignacion;
	}

	public void setFecInicioAsignacion(Date fecInicioAsignacion) {
		this.fecInicioAsignacion = fecInicioAsignacion;
	}

	public String getCodAuditor() {
		return codAuditor;
	}

	public void setCodAuditor(String codAuditor) {
		this.codAuditor = codAuditor;
	}

	public Date getFecFinAsignacion() {
		return fecFinAsignacion;
	}

	public void setFecFinAsignacion(Date fecFinAsignacion) {
		this.fecFinAsignacion = fecFinAsignacion;
	}


	public String getIndTipAsignacion() {
		return indTipAsignacion;
	}

	public void setIndTipAsignacion(String indTipAsignacion) {
		this.indTipAsignacion = indTipAsignacion;
	}

	public Long getNumAsignacionAccion() {
		return numAsignacionAccion;
	}

	public void setNumAsignacionAccion(Long numAsignacionAccion) {
		this.numAsignacionAccion = numAsignacionAccion;
	}

	public void setEstadoOrden(ArrayList<String> estadoOrden) {
		this.estadoOrden = estadoOrden;
	}

		 
}
