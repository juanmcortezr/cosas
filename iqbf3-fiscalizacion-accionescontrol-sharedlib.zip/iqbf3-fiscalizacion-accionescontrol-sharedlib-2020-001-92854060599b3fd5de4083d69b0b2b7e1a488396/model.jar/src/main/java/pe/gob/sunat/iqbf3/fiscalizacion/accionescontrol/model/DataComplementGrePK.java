package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import pe.gob.sunat.iqbf3.registro.maestros.model.EntidadPK;

@Embeddable
public class DataComplementGrePK implements EntidadPK{

	 @Column(name = "NUMEROGUIA")
	 private Integer numeroGuia;
	
	 @Column(name = "NUMERORUREMITENTE")
	 private Integer numeroRucRemitente;
	
	 @Column(name = "NUMEROSERIE")
	 private Integer numeroSerie;
	
	 @Column(name = "TIPOGUIA")
	 private Integer tipoGuia;

	public Integer getNumeroGuia() {
		return numeroGuia;
	}

	public void setNumeroGuia(Integer numeroGuia) {
		this.numeroGuia = numeroGuia;
	}

	public Integer getNumeroRucRemitente() {
		return numeroRucRemitente;
	}

	public void setNumeroRucRemitente(Integer numeroRucRemitente) {
		this.numeroRucRemitente = numeroRucRemitente;
	}

	public Integer getNumeroSerie() {
		return numeroSerie;
	}

	public void setNumeroSerie(Integer numeroSerie) {
		this.numeroSerie = numeroSerie;
	}

	public Integer getTipoGuia() {
		return tipoGuia;
	}

	public void setTipoGuia(Integer tipoGuia) {
		this.tipoGuia = tipoGuia;
	}
	

}
