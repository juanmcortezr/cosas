package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class PersonaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String codPers;
	private String nombreCompleto;

	public PersonaBean() {
		super();
	}

	public PersonaBean(String codPers, String nombreCompleto) {
		super();
		this.codPers = codPers;
		this.nombreCompleto = nombreCompleto;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

}
