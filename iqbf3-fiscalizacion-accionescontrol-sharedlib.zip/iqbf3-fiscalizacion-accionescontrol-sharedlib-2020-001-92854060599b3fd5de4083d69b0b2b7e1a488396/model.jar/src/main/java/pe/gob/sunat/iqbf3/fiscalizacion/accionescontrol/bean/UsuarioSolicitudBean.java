package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;

public class UsuarioSolicitudBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private ArchivoBean archivoBean;
	private String codTipoAccion;
	private String codTipoDocumentoIdentif;
	private String codTipoDocumentoReferencia;
	private String codTipoIntervencion;
	private String desTipoAccionControl;
	private String desTipoDocumentoIdent;
	private String desTipoDocumentoRef;
	private String desTipoIntervencion;
	private String fecSugeridaVisita;
	private String horSugeVisit;
	private String nomApellidoUsuario;
	private String numDocumentoIdentif;
	private String numDocumentoReferencia;
	private Long numSolicitud;
	private Long numUsuarioSolicitud;

	private int numInconsistenciaUsuario;
	private int numBienFiscaUsuario;

	// Ini extra
	private String desOtraInconsistencia;
	private String desOtraTipoBien;
	private List<EstablecimientoUsuarioBean> establecimientos;
	private List<MedioProbatorioUsuarioBean> mediosProbatorios;
	private List<DataCatalogoBean> inconsistencias;
	private List<DataCatalogoBean> tipoBienes;
	private List<BienFiscalizadoSolicitudBean> bienesFiscalizados;
	private Double totalInconsistencia;
	private Double totalBien;
	private Double totalMedioProbatorio;
	private Double valCalificacionPreliminar;
	private Double valCalificacionDefinitiva;
	private AuditoriaBean auditoriaBean;
	// Fin extra
	public UsuarioSolicitudBean() {
		super();
	}

	public UsuarioSolicitudBean(String codTipoAccion, String horSugeVisit, String codTipoDocumentoReferencia,
			String numDocumentoReferencia, Long numUsuarioSolicitud, String desTipoIntervencion,
			String numDocumentoIdentif, String codTipoIntervencion, ArchivoBean archivoBean, String desTipoDocumentoRef,
			String codTipoDocumentoIdentif, String nomApellidoUsuario, String desTipoAccionControl, Long numSolicitud,
			String desTipoDocumentoIdent, String fecSugeridaVisita) {
		super();
		this.codTipoAccion = codTipoAccion;
		this.horSugeVisit = horSugeVisit;
		this.codTipoDocumentoReferencia = codTipoDocumentoReferencia;
		this.numDocumentoReferencia = numDocumentoReferencia;
		this.numUsuarioSolicitud = numUsuarioSolicitud;
		this.desTipoIntervencion = desTipoIntervencion;
		this.numDocumentoIdentif = numDocumentoIdentif;
		this.codTipoIntervencion = codTipoIntervencion;
		this.archivoBean = archivoBean;
		this.desTipoDocumentoRef = desTipoDocumentoRef;
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
		this.nomApellidoUsuario = nomApellidoUsuario;
		this.desTipoAccionControl = desTipoAccionControl;
		this.numSolicitud = numSolicitud;
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
		this.fecSugeridaVisita = fecSugeridaVisita;
	}

	public ArchivoBean getArchivoBean() {
		return archivoBean;
	}

	public void setArchivoBean(ArchivoBean archivoBean) {
		this.archivoBean = archivoBean;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getCodTipoDocumentoReferencia() {
		return codTipoDocumentoReferencia;
	}

	public void setCodTipoDocumentoReferencia(String codTipoDocumentoReferencia) {
		this.codTipoDocumentoReferencia = codTipoDocumentoReferencia;
	}

	public String getCodTipoIntervencion() {
		return codTipoIntervencion;
	}

	public void setCodTipoIntervencion(String codTipoIntervencion) {
		this.codTipoIntervencion = codTipoIntervencion;
	}

	public String getDesTipoAccionControl() {
		return desTipoAccionControl;
	}

	public void setDesTipoAccionControl(String desTipoAccionControl) {
		this.desTipoAccionControl = desTipoAccionControl;
	}

	public String getDesTipoDocumentoIdent() {
		return desTipoDocumentoIdent;
	}

	public void setDesTipoDocumentoIdent(String desTipoDocumentoIdent) {
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
	}

	public String getDesTipoDocumentoRef() {
		return desTipoDocumentoRef;
	}

	public void setDesTipoDocumentoRef(String desTipoDocumentoRef) {
		this.desTipoDocumentoRef = desTipoDocumentoRef;
	}

	public String getDesTipoIntervencion() {
		return desTipoIntervencion;
	}

	public void setDesTipoIntervencion(String desTipoIntervencion) {
		this.desTipoIntervencion = desTipoIntervencion;
	}

	public String getFecSugeridaVisita() {
		return fecSugeridaVisita;
	}

	public void setFecSugeridaVisita(String fecSugeridaVisita) {
		this.fecSugeridaVisita = fecSugeridaVisita;
	}

	public String getHorSugeVisit() {
		return horSugeVisit;
	}

	public void setHorSugeVisit(String horSugeVisit) {
		this.horSugeVisit = horSugeVisit;
	}

	public String getNomApellidoUsuario() {
		return nomApellidoUsuario;
	}

	public void setNomApellidoUsuario(String nomApellidoUsuario) {
		this.nomApellidoUsuario = nomApellidoUsuario;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public String getNumDocumentoReferencia() {
		return numDocumentoReferencia;
	}

	public void setNumDocumentoReferencia(String numDocumentoReferencia) {
		this.numDocumentoReferencia = numDocumentoReferencia;
	}

	public Long getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Long numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public int getNumBienFiscaUsuario() {
		return numBienFiscaUsuario;
	}

	public void setNumBienFiscaUsuario(int numBienFiscaUsuario) {
		this.numBienFiscaUsuario = numBienFiscaUsuario;
	}

	public int getNumInconsistenciaUsuario() {
		return numInconsistenciaUsuario;
	}

	public void setNumInconsistenciaUsuario(int numInconsistenciaUsuario) {
		this.numInconsistenciaUsuario = numInconsistenciaUsuario;
	}

	// Ini extra
	public String getDesOtraInconsistencia() {
		return desOtraInconsistencia;
	}

	public void setDesOtraInconsistencia(String desOtraInconsistencia) {
		this.desOtraInconsistencia = desOtraInconsistencia;
	}

	public String getDesOtraTipoBien() {
		return desOtraTipoBien;
	}

	public void setDesOtraTipoBien(String desOtraTipoBien) {
		this.desOtraTipoBien = desOtraTipoBien;
	}
	
	public List<EstablecimientoUsuarioBean> getEstablecimientos() {
		return establecimientos;
	}

	public void setEstablecimientos(List<EstablecimientoUsuarioBean> establecimientos) {
		this.establecimientos = establecimientos;
	}

	public List<MedioProbatorioUsuarioBean> getMediosProbatorios() {
		return mediosProbatorios;
	}

	public void setMediosProbatorios(List<MedioProbatorioUsuarioBean> mediosProbatorios) {
		this.mediosProbatorios = mediosProbatorios;
	}

	public List<DataCatalogoBean> getInconsistencias() {
		return inconsistencias;
	}

	public void setInconsistencias(List<DataCatalogoBean> inconsistencias) {
		this.inconsistencias = inconsistencias;
	}

	public List<DataCatalogoBean> getTipoBienes() {
		return tipoBienes;
	}

	public void setTipoBienes(List<DataCatalogoBean> tipoBienes) {
		this.tipoBienes = tipoBienes;
	}

	public List<BienFiscalizadoSolicitudBean> getBienesFiscalizados() {
		return bienesFiscalizados;
	}

	public void setBienesFiscalizados(List<BienFiscalizadoSolicitudBean> bienesFiscalizados) {
		this.bienesFiscalizados = bienesFiscalizados;
	}
	// Fin extra

	public Double getTotalInconsistencia() {
		return totalInconsistencia;
	}

	public void setTotalInconsistencia(Double totalInconsistencia) {
		this.totalInconsistencia = totalInconsistencia;
	}

	public Double getTotalBien() {
		return totalBien;
	}

	public void setTotalBien(Double totalBien) {
		this.totalBien = totalBien;
	}

	public Double getTotalMedioProbatorio() {
		return totalMedioProbatorio;
	}

	public void setTotalMedioProbatorio(Double totalMedioProbatorio) {
		this.totalMedioProbatorio = totalMedioProbatorio;
	}

	public Double getValCalificacionPreliminar() {
		return valCalificacionPreliminar;
	}

	public void setValCalificacionPreliminar(Double valCalificacionPreliminar) {
		this.valCalificacionPreliminar = valCalificacionPreliminar;
	}

	public Double getValCalificacionDefinitiva() {
		return valCalificacionDefinitiva;
	}

	public void setValCalificacionDefinitiva(Double valCalificacionDefinitiva) {
		this.valCalificacionDefinitiva = valCalificacionDefinitiva;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	@Override
	public String toString() {
		return "UsuarioSolicitudBean [archivoBean=" + archivoBean + ", codTipoAccion=" + codTipoAccion
				+ ", codTipoDocumentoIdentif=" + codTipoDocumentoIdentif + ", codTipoDocumentoReferencia="
				+ codTipoDocumentoReferencia + ", codTipoIntervencion=" + codTipoIntervencion
				+ ", desTipoAccionControl=" + desTipoAccionControl + ", desTipoDocumentoIdent=" + desTipoDocumentoIdent
				+ ", desTipoDocumentoRef=" + desTipoDocumentoRef + ", desTipoIntervencion=" + desTipoIntervencion
				+ ", fecSugeridaVisita=" + fecSugeridaVisita + ", horSugeVisit=" + horSugeVisit
				+ ", nomApellidoUsuario=" + nomApellidoUsuario + ", numDocumentoIdentif=" + numDocumentoIdentif
				+ ", numDocumentoReferencia=" + numDocumentoReferencia + ", numSolicitud=" + numSolicitud
				+ ", numUsuarioSolicitud=" + numUsuarioSolicitud + ", numInconsistenciaUsuario="
				+ numInconsistenciaUsuario + ", numBienFiscaUsuario=" + numBienFiscaUsuario + ", desOtraInconsistencia="
				+ desOtraInconsistencia + ", desOtraTipoBien=" + desOtraTipoBien + ", establecimientos="
				+ establecimientos + ", mediosProbatorios=" + mediosProbatorios + ", inconsistencias=" + inconsistencias
				+ ", tipoBienes=" + tipoBienes + ", bienesFiscalizados=" + bienesFiscalizados + ", totalInconsistencia="
				+ totalInconsistencia + ", totalBien=" + totalBien + ", totalMedioProbatorio=" + totalMedioProbatorio
				+ ", valCalificacionPreliminar=" + valCalificacionPreliminar + ", valCalificacionDefinitiva="
				+ valCalificacionDefinitiva + ", auditoriaBean=" + auditoriaBean + "]";
	}

}
