package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T4241CABCPE")
public class CabezeraCpe implements Entidad {

	@EmbeddedId
	private CabezeraCpePK cabezeraCpePk;
	
	 @Column(name = "COD_DOCIDE_RECEP")
	 private String codDocumenotRecepcion;
	
	 @Column(name = "COD_EST_ANEXO")
	 private Integer codEstadoAnexo;
	
	 @Column(name = "COD_MONEDA")
	 private String codMoneda;
	
	 @Column(name = "COD_TIPO_CPE")
	 private String codTipoCpe;
	
	 @Column(name = "DES_NOMBRE_RECEP")
	 private String desNombreRecepcion;
	
	 @Column(name = "DES_OBSERVACION")
	 private String desObservacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_EMISION")
	 private Date fecEmision;
	
	 @Column(name = "IND_ESTADO")
	 private String indEstado;
	
	 @Column(name = "IND_PROCEDENCIA")
	 private String indProcedencia;
	
	 @Column(name = "IND_RECHAZO")
	 private String indRechazo;
	
	 @Column(name = "MTO_IMPORTE_TOTAL")
	 private Double mtoImporteTotal;
	
	 @Column(name = "MTO_TOTAL_IGV")
	 private Double mtoTotalIgv;
	
	 @Column(name = "MTO_TOTAL_VENTA")
	 private Double mtoTotalVenta;
	
	 @Column(name = "NUM_CUO_REGVEN")
	 private Integer numCuoRegven;
	
	 @Column(name = "NUM_DOCIDE_RECEP")
	 private String numDocumentoRecepcion;
	
	 @Column(name = "NUM_ID_XML")
	 private Integer numIdXml;
	
	 @Column(name = "NUM_PER_REGCOM")
	 private String numPeriodoRegistroCompra;
	
	 @Column(name = "NUM_PER_REGVEN")
	 private String numPeriodoRegistroVenta;

	 @Transient
	 private String numDocumentoVinculado;
	 @Transient
	 private String tipoDocumentoVinculado;
	 
	 @Transient
	 private String numRuc;

	 @Transient
	 private String codCpe;

	 @Transient
	 private String numSerieCpe;

	 @Transient
	 private Integer numCpe;
	 
	 
	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public String getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}

	public String getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public Integer getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(Integer numCpe) {
		this.numCpe = numCpe;
	}

	public String getNumDocumentoVinculado() {
		return numDocumentoVinculado;
	}

	public void setNumDocumentoVinculado(String numDocumentoVinculado) {
		this.numDocumentoVinculado = numDocumentoVinculado;
	}

	public String getTipoDocumentoVinculado() {
		return tipoDocumentoVinculado;
	}

	public void setTipoDocumentoVinculado(String tipoDocumentoVinculado) {
		this.tipoDocumentoVinculado = tipoDocumentoVinculado;
	}

	public CabezeraCpePK getCabezeraCpePk() {
		return cabezeraCpePk;
	}

	public void setCabezeraCpePk(CabezeraCpePK cabezeraCpePk) {
		this.cabezeraCpePk = cabezeraCpePk;
	}

	public String getCodDocumenotRecepcion() {
		return codDocumenotRecepcion;
	}

	public void setCodDocumenotRecepcion(String codDocumenotRecepcion) {
		this.codDocumenotRecepcion = codDocumenotRecepcion;
	}

	public Integer getCodEstadoAnexo() {
		return codEstadoAnexo;
	}

	public void setCodEstadoAnexo(Integer codEstadoAnexo) {
		this.codEstadoAnexo = codEstadoAnexo;
	}

	public String getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCodTipoCpe() {
		return codTipoCpe;
	}

	public void setCodTipoCpe(String codTipoCpe) {
		this.codTipoCpe = codTipoCpe;
	}

	public String getDesNombreRecepcion() {
		return desNombreRecepcion;
	}

	public void setDesNombreRecepcion(String desNombreRecepcion) {
		this.desNombreRecepcion = desNombreRecepcion;
	}

	public String getDesObservacion() {
		return desObservacion;
	}

	public void setDesObservacion(String desObservacion) {
		this.desObservacion = desObservacion;
	}

	public Date getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(Date fecEmision) {
		this.fecEmision = fecEmision;
	}

	public String getIndEstado() {
		return indEstado;
	}

	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}

	public String getIndProcedencia() {
		return indProcedencia;
	}

	public void setIndProcedencia(String indProcedencia) {
		this.indProcedencia = indProcedencia;
	}

	public String getIndRechazo() {
		return indRechazo;
	}

	public void setIndRechazo(String indRechazo) {
		this.indRechazo = indRechazo;
	}

	public Double getMtoImporteTotal() {
		return mtoImporteTotal;
	}

	public void setMtoImporteTotal(Double mtoImporteTotal) {
		this.mtoImporteTotal = mtoImporteTotal;
	}

	public Double getMtoTotalIgv() {
		return mtoTotalIgv;
	}

	public void setMtoTotalIgv(Double mtoTotalIgv) {
		this.mtoTotalIgv = mtoTotalIgv;
	}

	public Double getMtoTotalVenta() {
		return mtoTotalVenta;
	}

	public void setMtoTotalVenta(Double mtoTotalVenta) {
		this.mtoTotalVenta = mtoTotalVenta;
	}

	public Integer getNumCuoRegven() {
		return numCuoRegven;
	}

	public void setNumCuoRegven(Integer numCuoRegven) {
		this.numCuoRegven = numCuoRegven;
	}

	public String getNumDocumentoRecepcion() {
		return numDocumentoRecepcion;
	}

	public void setNumDocumentoRecepcion(String numDocumentoRecepcion) {
		this.numDocumentoRecepcion = numDocumentoRecepcion;
	}

	public Integer getNumIdXml() {
		return numIdXml;
	}

	public void setNumIdXml(Integer numIdXml) {
		this.numIdXml = numIdXml;
	}

	public String getNumPeriodoRegistroCompra() {
		return numPeriodoRegistroCompra;
	}

	public void setNumPeriodoRegistroCompra(String numPeriodoRegistroCompra) {
		this.numPeriodoRegistroCompra = numPeriodoRegistroCompra;
	}

	public String getNumPeriodoRegistroVenta() {
		return numPeriodoRegistroVenta;
	}

	public void setNumPeriodoRegistroVenta(String numPeriodoRegistroVenta) {
		this.numPeriodoRegistroVenta = numPeriodoRegistroVenta;
	}
	
}
