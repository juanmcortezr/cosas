package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class InformeSeleccionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	int	anioInforme;
	private	String	codEstadoInforme;
	private	String	codUnidadOrganica;
	private	String	desEstadoInforme;
	private	String	desUnidadOrganica;
	private	Long	numCorrel;
	private	Long	numInformeSeleccion;
	private	Long	numProgramacion;
	
	private AuditoriaBean auditoriaBean;
	private ArchivoBean archivoInforme;
	private ArchivoBean archivoReporte;
	private String numInformeUnion;
	
	public String getNumInformeUnion() {
		return numInformeUnion;
	}

	public void setNumInformeUnion(String numInformeUnion) {
		this.numInformeUnion = numInformeUnion;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public InformeSeleccionBean() {
		super();
	}

	public InformeSeleccionBean(int anioInforme, String codEstadoInforme, String codUnidadOrganica,
			String desEstadoInforme, String desUnidadOrganica, Long numCorrel, Long numInformeSeleccion,
			Long numProgramacion) {
		super();
		this.anioInforme = anioInforme;
		this.codEstadoInforme = codEstadoInforme;
		this.codUnidadOrganica = codUnidadOrganica;
		this.desEstadoInforme = desEstadoInforme;
		this.desUnidadOrganica = desUnidadOrganica;
		this.numCorrel = numCorrel;
		this.numInformeSeleccion = numInformeSeleccion;
		this.numProgramacion = numProgramacion;
	}

	public int getAnioInforme() {
		return anioInforme;
	}

	public void setAnioInforme(int anioInforme) {
		this.anioInforme = anioInforme;
	}

	public String getCodEstadoInforme() {
		return codEstadoInforme;
	}

	public void setCodEstadoInforme(String codEstadoInforme) {
		this.codEstadoInforme = codEstadoInforme;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public String getDesEstadoInforme() {
		return desEstadoInforme;
	}

	public void setDesEstadoInforme(String desEstadoInforme) {
		this.desEstadoInforme = desEstadoInforme;
	}

	public String getDesUnidadOrganica() {
		return desUnidadOrganica;
	}

	public void setDesUnidadOrganica(String desUnidadOrganica) {
		this.desUnidadOrganica = desUnidadOrganica;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getNumCorrel() {
		return numCorrel;
	}

	public void setNumCorrel(Long numCorrel) {
		this.numCorrel = numCorrel;
	}

	public Long getNumInformeSeleccion() {
		return numInformeSeleccion;
	}

	public void setNumInformeSeleccion(Long numInformeSeleccion) {
		this.numInformeSeleccion = numInformeSeleccion;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public ArchivoBean getArchivoInforme() {
		return archivoInforme;
	}

	public void setArchivoInforme(ArchivoBean archivoInforme) {
		this.archivoInforme = archivoInforme;
	}

	public ArchivoBean getArchivoReporte() {
		return archivoReporte;
	}

	public void setArchivoReporte(ArchivoBean archivoReporte) {
		this.archivoReporte = archivoReporte;
	}

}
