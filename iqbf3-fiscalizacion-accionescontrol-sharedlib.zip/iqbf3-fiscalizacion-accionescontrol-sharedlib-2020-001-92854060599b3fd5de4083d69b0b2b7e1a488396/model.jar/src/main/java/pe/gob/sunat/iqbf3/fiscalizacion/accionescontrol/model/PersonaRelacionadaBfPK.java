package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import pe.gob.sunat.iqbf3.registro.maestros.model.EntidadPK;

@Embeddable
public class PersonaRelacionadaBfPK implements EntidadPK{

	 @Column(name = "COD_TIPO_PERSONA")
	 private Integer tipoPersona;
	 
	 @Column(name = "NUM_PERSONA")
	 private Integer numeroPersona;
	 
	  @Column(name = "NUM_CPE")
	 private Integer numeroGuia;
	
	 @Column(name = "NUM_RUC")
	 private String numeroRucRemitente;
	
	 @Column(name = "NUM_SERIE_CPE")
	 private String numeroSerie;
	
	 @Column(name = "COD_CPE")
	 private Integer tipoGuia;

	public Integer getTipoPersona() {
		return tipoPersona;
	}

	public void setTipoPersona(Integer tipoPersona) {
		this.tipoPersona = tipoPersona;
	}

	public Integer getNumeroPersona() {
		return numeroPersona;
	}

	public void setNumeroPersona(Integer numeroPersona) {
		this.numeroPersona = numeroPersona;
	}

	public Integer getNumeroGuia() {
		return numeroGuia;
	}

	public void setNumeroGuia(Integer numeroGuia) {
		this.numeroGuia = numeroGuia;
	}

	public String getNumeroRucRemitente() {
		return numeroRucRemitente;
	}

	public void setNumeroRucRemitente(String numeroRucRemitente) {
		this.numeroRucRemitente = numeroRucRemitente;
	}

	public String getNumeroSerie() {
		return numeroSerie;
	}

	public void setNumeroSerie(String numeroSerie) {
		this.numeroSerie = numeroSerie;
	}

	public Integer getTipoGuia() {
		return tipoGuia;
	}

	public void setTipoGuia(Integer tipoGuia) {
		this.tipoGuia = tipoGuia;
	}
	
	 

}
