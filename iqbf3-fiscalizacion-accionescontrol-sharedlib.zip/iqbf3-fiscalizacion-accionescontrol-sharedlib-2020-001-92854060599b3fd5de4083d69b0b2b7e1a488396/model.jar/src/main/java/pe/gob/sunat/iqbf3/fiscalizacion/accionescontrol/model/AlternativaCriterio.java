package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10389ALTERNATCRIT")
public class AlternativaCriterio extends Auditoria {

	
	 @Column(name = "DES_ALTERNATIVA")
	 private String desAlternativa;
	
	 @Id
	 @Column(name = "NUM_ALTERNATIVA")
	 private Long numAlternativa;
	
	 @Column(name = "VAL_ALTERNATIVA")
	 private Integer valAlternativa;

	 @Column(name = "NUM_CRITERIO")
	 private Long numCriterio;
	 
	  
	public Long getNumCriterio() {
		return numCriterio;
	}

	public void setNumCriterio(Long numCriterio) {
		this.numCriterio = numCriterio;
	}

	public String getDesAlternativa() {
		return desAlternativa;
	}

	public void setDesAlternativa(String desAlternativa) {
		this.desAlternativa = desAlternativa;
	}

	public Long getNumAlternativa() {
		return numAlternativa;
	}

	public void setNumAlternativa(Long numAlternativa) {
		this.numAlternativa = numAlternativa;
	}

	public Integer getValAlternativa() {
		return valAlternativa;
	}

	public void setValAlternativa(Integer valAlternativa) {
		this.valAlternativa = valAlternativa;
	}

}
