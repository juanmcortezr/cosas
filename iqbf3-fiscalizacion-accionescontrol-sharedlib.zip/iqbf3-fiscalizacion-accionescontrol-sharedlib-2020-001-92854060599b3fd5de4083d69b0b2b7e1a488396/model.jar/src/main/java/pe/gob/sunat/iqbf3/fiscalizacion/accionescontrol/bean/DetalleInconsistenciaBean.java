package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

public class DetalleInconsistenciaBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5113441064487199951L;
	
	private OrdenAccionBean detalleInconsistencia;
	
	private List<ProgramaIncosistenciaStockBean> listaStockNegativo;
	
	private List<ProgramaIncosistenciaSaldoBean> listaSaldoNegativo;
	
	private List<ProgramaIncosistenciaGreNCBean> listaGreNC;

	public DetalleInconsistenciaBean() {
		
	}
	
	public DetalleInconsistenciaBean(OrdenAccionBean detalleInconsistencia,
			List<ProgramaIncosistenciaStockBean> listaStockNegativo,
			List<ProgramaIncosistenciaSaldoBean> listaSaldoNegativo, List<ProgramaIncosistenciaGreNCBean> listaGreNC) {
		super();
		this.detalleInconsistencia = detalleInconsistencia;
		this.listaStockNegativo = listaStockNegativo;
		this.listaSaldoNegativo = listaSaldoNegativo;
		this.listaGreNC = listaGreNC;
	}

	public OrdenAccionBean getDetalleInconsistencia() {
		return detalleInconsistencia;
	}

	public void setDetalleInconsistencia(OrdenAccionBean detalleInconsistencia) {
		this.detalleInconsistencia = detalleInconsistencia;
	}

	public List<ProgramaIncosistenciaStockBean> getListaStockNegativo() {
		return listaStockNegativo;
	}

	public void setListaStockNegativo(List<ProgramaIncosistenciaStockBean> listaStockNegativo) {
		this.listaStockNegativo = listaStockNegativo;
	}

	public List<ProgramaIncosistenciaSaldoBean> getListaSaldoNegativo() {
		return listaSaldoNegativo;
	}

	public void setListaSaldoNegativo(List<ProgramaIncosistenciaSaldoBean> listaSaldoNegativo) {
		this.listaSaldoNegativo = listaSaldoNegativo;
	}

	public List<ProgramaIncosistenciaGreNCBean> getListaGreNC() {
		return listaGreNC;
	}

	public void setListaGreNC(List<ProgramaIncosistenciaGreNCBean> listaGreNC) {
		this.listaGreNC = listaGreNC;
	}
}
