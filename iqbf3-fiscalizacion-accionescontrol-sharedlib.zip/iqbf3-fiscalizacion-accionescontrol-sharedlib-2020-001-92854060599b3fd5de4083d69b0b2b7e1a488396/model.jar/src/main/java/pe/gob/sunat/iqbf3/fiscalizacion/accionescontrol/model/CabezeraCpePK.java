package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import pe.gob.sunat.iqbf3.registro.maestros.model.EntidadPK;

@Embeddable
public class CabezeraCpePK implements EntidadPK {

	 @Column(name = "NUM_RUC")
	 private String numRuc;

	 @Column(name = "COD_CPE")
	 private String codCpe;

	 @Column(name = "NUM_SERIE_CPE")
	 private String numSerieCpe;

	 @Column(name = "NUM_CPE")
	 private Integer numCpe;

	public CabezeraCpePK() {
	}
	 
	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public String getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}

	public String getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public Integer getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(Integer numCpe) {
		this.numCpe = numCpe;
	}

	 
}
