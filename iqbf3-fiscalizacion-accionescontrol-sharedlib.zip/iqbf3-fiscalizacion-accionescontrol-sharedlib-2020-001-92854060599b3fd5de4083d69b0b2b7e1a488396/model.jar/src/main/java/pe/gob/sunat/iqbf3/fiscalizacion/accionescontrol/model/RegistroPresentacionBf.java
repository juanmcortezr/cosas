package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "T5074BFPRESENTA")
public class RegistroPresentacionBf extends Auditoria {

	@EmbeddedId
	private RegistroPresentacionBfPK registroPresentacionBfPk;
	
	 @Column(name = "CNT_NET_PROD")
	 private Double cntNetProd;
	
	 @Column(name = "CNT_PESO_BRUTO")
	 private Double cntPesoBruto;
	
	 @Column(name = "CNT_UNIFISICA")
	 private Double cantidadUnidadFisica;
	
	 @Column(name = "COD_ESTADO")
	 private String codEstado;
	
	 @Column(name = "COD_ORIGEN")
	 private String codOrigen;
	
	 @Column(name = "COD_PARTARANCEL")
	 private String codPartidaArancelaria;
	
	 @Column(name = "COD_PRESEN")
	 private String codPresen;
	
	 @Column(name = "COD_PRESEN_USU")
	 private String codPresenUsu;
	
	 @Column(name = "COD_UM_CTRL")
	 private String codUnidadMedidaControl;
	
	 @Column(name = "COD_UNI_COM")
	 private String codUnidadComercial;
	
	 @Column(name = "COD_UNI_FIS")
	 private String codUnidadFiscal;
	
	 @Column(name = "DES_SUSTENTO")
	 private String desSustento;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_ALTA")
	 private Date fecAlta;
	
	 @Column(name = "IND_CONDICION")
	 private String indCondicion;
	
	 @Column(name = "IND_USOARTE")
	 private String indUsoarte;
	
	 @Column(name = "IND_USODOME")
	 private String indUsodome;
		
	 @Column(name = "NUM_ORD_INS")
	 private String numOrdenInsumo;
	
	 @Column(name = "NUM_REFMODIF")
	 private Integer numReferencianModifica;

	 
	 
	public RegistroPresentacionBfPK getRegistroPresentacionBfPk() {
		return registroPresentacionBfPk;
	}

	public void setRegistroPresentacionBfPk(RegistroPresentacionBfPK registroPresentacionBfPk) {
		this.registroPresentacionBfPk = registroPresentacionBfPk;
	}

	public Double getCntNetProd() {
		return cntNetProd;
	}

	public void setCntNetProd(Double cntNetProd) {
		this.cntNetProd = cntNetProd;
	}

	public Double getCntPesoBruto() {
		return cntPesoBruto;
	}

	public void setCntPesoBruto(Double cntPesoBruto) {
		this.cntPesoBruto = cntPesoBruto;
	}

	public Double getCantidadUnidadFisica() {
		return cantidadUnidadFisica;
	}

	public void setCantidadUnidadFisica(Double cantidadUnidadFisica) {
		this.cantidadUnidadFisica = cantidadUnidadFisica;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}

	public String getCodPartidaArancelaria() {
		return codPartidaArancelaria;
	}

	public void setCodPartidaArancelaria(String codPartidaArancelaria) {
		this.codPartidaArancelaria = codPartidaArancelaria;
	}

	public String getCodPresen() {
		return codPresen;
	}

	public void setCodPresen(String codPresen) {
		this.codPresen = codPresen;
	}

	public String getCodPresenUsu() {
		return codPresenUsu;
	}

	public void setCodPresenUsu(String codPresenUsu) {
		this.codPresenUsu = codPresenUsu;
	}

	public String getCodUnidadMedidaControl() {
		return codUnidadMedidaControl;
	}

	public void setCodUnidadMedidaControl(String codUnidadMedidaControl) {
		this.codUnidadMedidaControl = codUnidadMedidaControl;
	}

	public String getCodUnidadComercial() {
		return codUnidadComercial;
	}

	public void setCodUnidadComercial(String codUnidadComercial) {
		this.codUnidadComercial = codUnidadComercial;
	}

	public String getCodUnidadFiscal() {
		return codUnidadFiscal;
	}

	public void setCodUnidadFiscal(String codUnidadFiscal) {
		this.codUnidadFiscal = codUnidadFiscal;
	}

	public String getDesSustento() {
		return desSustento;
	}

	public void setDesSustento(String desSustento) {
		this.desSustento = desSustento;
	}

	public Date getFecAlta() {
		return fecAlta;
	}

	public void setFecAlta(Date fecAlta) {
		this.fecAlta = fecAlta;
	}

	public String getIndCondicion() {
		return indCondicion;
	}

	public void setIndCondicion(String indCondicion) {
		this.indCondicion = indCondicion;
	}

	public String getIndUsoarte() {
		return indUsoarte;
	}

	public void setIndUsoarte(String indUsoarte) {
		this.indUsoarte = indUsoarte;
	}

	public String getIndUsodome() {
		return indUsodome;
	}

	public void setIndUsodome(String indUsodome) {
		this.indUsodome = indUsodome;
	}

	public String getNumOrdenInsumo() {
		return numOrdenInsumo;
	}

	public void setNumOrdenInsumo(String numOrdenInsumo) {
		this.numOrdenInsumo = numOrdenInsumo;
	}

	public Integer getNumReferencianModifica() {
		return numReferencianModifica;
	}

	public void setNumReferencianModifica(Integer numReferencianModifica) {
		this.numReferencianModifica = numReferencianModifica;
	}
	
}
