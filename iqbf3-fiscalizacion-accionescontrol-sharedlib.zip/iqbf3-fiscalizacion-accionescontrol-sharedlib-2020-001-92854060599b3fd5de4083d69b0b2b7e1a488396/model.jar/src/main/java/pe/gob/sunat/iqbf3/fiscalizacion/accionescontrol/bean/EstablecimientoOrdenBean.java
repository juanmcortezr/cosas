package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class EstablecimientoOrdenBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codDepartamento;
	private	String	codDistrito;
	private	String	codOrigen;
	private	String	codProvincia;
	private	String	codTipoDocumentoIdentif;
	private	String	desDireccion;
	private	int	numEstablecimiento;
	private	int	numEstablecimientoOrden;
	private	String	numOtroRuc;
	private	String	numSolicitudNuetralizacion;
	private	double	numXutm;
	private	double	numYutm;
	private	double	numZona;
	private	int	numOrden;
	private String indDel;
	private String indEst;
	private AuditoriaBean auditoriaBean;
	private	String	desDepartamento;
	private	String	desDistrito;
	private	String	desOrigen;
	private	String	desProvincia;
	private String  desUbigeo;
	
	private List<ActividadEstablecimientoBean> lstActividadEstablecimiento;
	private List<BienEstablecimientoBean> lstBienEstablecimiento;
	private List<ActaEstablecimientoBean> lstActaEstablecimiento;
	
	public EstablecimientoOrdenBean() {
		super();
	}

	public EstablecimientoOrdenBean(String codDepartamento, String codDistrito, String codOrigen, String codProvincia,
			String codTipoDocumentoIdentif, String desDireccion, int numEstablecimiento, int numEstablecimientoOrden,
			String numOtroRuc, String numSolicitudNuetralizacion, double numXutm, double numYutm, double numZona,
			int numOrden) {
		super();
		this.codDepartamento = codDepartamento;
		this.codDistrito = codDistrito;
		this.codOrigen = codOrigen;
		this.codProvincia = codProvincia;
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
		this.desDireccion = desDireccion;
		this.numEstablecimiento = numEstablecimiento;
		this.numEstablecimientoOrden = numEstablecimientoOrden;
		this.numOtroRuc = numOtroRuc;
		this.numSolicitudNuetralizacion = numSolicitudNuetralizacion;
		this.numXutm = numXutm;
		this.numYutm = numYutm;
		this.numZona = numZona;
		this.numOrden = numOrden;
	}

	public String getCodDepartamento() {
		return codDepartamento;
	}

	public void setCodDepartamento(String codDepartamento) {
		this.codDepartamento = codDepartamento;
	}

	public String getCodDistrito() {
		return codDistrito;
	}

	public void setCodDistrito(String codDistrito) {
		this.codDistrito = codDistrito;
	}

	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}

	public String getCodProvincia() {
		return codProvincia;
	}

	public void setCodProvincia(String codProvincia) {
		this.codProvincia = codProvincia;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getDesDireccion() {
		return desDireccion;
	}

	public void setDesDireccion(String desDireccion) {
		this.desDireccion = desDireccion;
	}

	public int getNumEstablecimiento() {
		return numEstablecimiento;
	}

	public void setNumEstablecimiento(int numEstablecimiento) {
		this.numEstablecimiento = numEstablecimiento;
	}

	public int getNumEstablecimientoOrden() {
		return numEstablecimientoOrden;
	}

	public void setNumEstablecimientoOrden(int numEstablecimientoOrden) {
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public String getNumOtroRuc() {
		return numOtroRuc;
	}

	public void setNumOtroRuc(String numOtroRuc) {
		this.numOtroRuc = numOtroRuc;
	}

	public String getNumSolicitudNuetralizacion() {
		return numSolicitudNuetralizacion;
	}

	public void setNumSolicitudNuetralizacion(String numSolicitudNuetralizacion) {
		this.numSolicitudNuetralizacion = numSolicitudNuetralizacion;
	}

	public double getNumXutm() {
		return numXutm;
	}

	public void setNumXutm(double numXutm) {
		this.numXutm = numXutm;
	}

	public double getNumYutm() {
		return numYutm;
	}

	public void setNumYutm(double numYutm) {
		this.numYutm = numYutm;
	}

	public double getNumZona() {
		return numZona;
	}

	public void setNumZona(double numZona) {
		this.numZona = numZona;
	}

	public int getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(int numOrden) {
		this.numOrden = numOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public List<ActividadEstablecimientoBean> getLstActividadEstablecimiento() {
		return lstActividadEstablecimiento;
	}

	public void setLstActividadEstablecimiento(List<ActividadEstablecimientoBean> lstActividadEstablecimiento) {
		this.lstActividadEstablecimiento = lstActividadEstablecimiento;
	}

	public List<BienEstablecimientoBean> getLstBienEstablecimiento() {
		return lstBienEstablecimiento;
	}

	public void setLstBienEstablecimiento(List<BienEstablecimientoBean> lstBienEstablecimiento) {
		this.lstBienEstablecimiento = lstBienEstablecimiento;
	}

	public List<ActaEstablecimientoBean> getLstActaEstablecimiento() {
		return lstActaEstablecimiento;
	}

	public void setLstActaEstablecimiento(List<ActaEstablecimientoBean> lstActaEstablecimiento) {
		this.lstActaEstablecimiento = lstActaEstablecimiento;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public String getDesDepartamento() {
		return desDepartamento;
	}

	public void setDesDepartamento(String desDepartamento) {
		this.desDepartamento = desDepartamento;
	}

	public String getDesDistrito() {
		return desDistrito;
	}

	public void setDesDistrito(String desDistrito) {
		this.desDistrito = desDistrito;
	}

	public String getDesOrigen() {
		return desOrigen;
	}

	public void setDesOrigen(String desOrigen) {
		this.desOrigen = desOrigen;
	}

	public String getDesProvincia() {
		return desProvincia;
	}

	public void setDesProvincia(String desProvincia) {
		this.desProvincia = desProvincia;
	}

	public String getDesUbigeo() {
		return desUbigeo;
	}

	public void setDesUbigeo(String desUbigeo) {
		this.desUbigeo = desUbigeo;
	}
	
	
	
}
