package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "T10411INFORMESELEC")
public class InformeSeleccion extends Auditoria {

	
	 @Column(name = "ANN_INFORME")
	 private Integer anioInforme;
	
	 @Column(name = "COD_EST_INFORME")
	 private String codEstadoInforme;
	
	 @Column(name = "COD_UUOO")
	 private String codUnidadOrganica;
	
	 @Column(name = "NUM_CORREL")
	 private Long numCorrel;
	
	 @Id
	 @Column(name = "NUM_INF_SELECC")
	 private Long numInformeSeleccion;

	 @Column(name = "NUM_PROGRAMACION")
	 private Long numProgramacion;

	 //
	 
	 @Transient
	 private Long numUsuarioPrograma;
	 
	 @Transient
	 private String numInformeUnion;	 
	 
	public String getNumInformeUnion() {
		return numInformeUnion;
	}

	public void setNumInformeUnion(String numInformeUnion) {
		this.numInformeUnion = numInformeUnion;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public Integer getAnioInforme() {
		return anioInforme;
	}

	public void setAnioInforme(Integer anioInforme) {
		this.anioInforme = anioInforme;
	}

	public String getCodEstadoInforme() {
		return codEstadoInforme;
	}

	public void setCodEstadoInforme(String codEstadoInforme) {
		this.codEstadoInforme = codEstadoInforme;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public Long getNumCorrel() {
		return numCorrel;
	}

	public void setNumCorrel(Long numCorrel) {
		this.numCorrel = numCorrel;
	}

	public Long getNumInformeSeleccion() {
		return numInformeSeleccion;
	}

	public void setNumInformeSeleccion(Long numInformeSeleccion) {
		this.numInformeSeleccion = numInformeSeleccion;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

}
