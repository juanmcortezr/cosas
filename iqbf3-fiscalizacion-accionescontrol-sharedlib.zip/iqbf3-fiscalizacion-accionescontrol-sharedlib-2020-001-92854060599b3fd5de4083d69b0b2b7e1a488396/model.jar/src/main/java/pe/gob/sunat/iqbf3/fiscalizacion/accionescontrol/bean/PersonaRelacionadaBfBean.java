package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class PersonaRelacionadaBfBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	apellidosNombre;
	private	String	numDocumentoVinculado;
	private	int	numeroGuia;
	private	String	numeroLicenciaConducir;
	private	int	numeroPersona;
	private	int	numeroRucRemitente;
	private	int	numeroSerie;
	private	int	subcontratado;
	private	String	tipoDocumento;
	private	int	tipoGuia;
	private	int	tipoPersona;
	
	public PersonaRelacionadaBfBean() {
		super();
	}

	public PersonaRelacionadaBfBean(String apellidosNombre, String numDocumentoVinculado, int numeroGuia,
			String numeroLicenciaConducir, int numeroPersona, int numeroRucRemitente, int numeroSerie,
			int subcontratado, String tipoDocumento, int tipoGuia, int tipoPersona) {
		super();
		this.apellidosNombre = apellidosNombre;
		this.numDocumentoVinculado = numDocumentoVinculado;
		this.numeroGuia = numeroGuia;
		this.numeroLicenciaConducir = numeroLicenciaConducir;
		this.numeroPersona = numeroPersona;
		this.numeroRucRemitente = numeroRucRemitente;
		this.numeroSerie = numeroSerie;
		this.subcontratado = subcontratado;
		this.tipoDocumento = tipoDocumento;
		this.tipoGuia = tipoGuia;
		this.tipoPersona = tipoPersona;
	}

	public String getApellidosNombre() {
		return apellidosNombre;
	}

	public void setApellidosNombre(String apellidosNombre) {
		this.apellidosNombre = apellidosNombre;
	}

	public String getNumDocumentoVinculado() {
		return numDocumentoVinculado;
	}

	public void setNumDocumentoVinculado(String numDocumentoVinculado) {
		this.numDocumentoVinculado = numDocumentoVinculado;
	}

	public int getNumeroGuia() {
		return numeroGuia;
	}

	public void setNumeroGuia(int numeroGuia) {
		this.numeroGuia = numeroGuia;
	}

	public String getNumeroLicenciaConducir() {
		return numeroLicenciaConducir;
	}

	public void setNumeroLicenciaConducir(String numeroLicenciaConducir) {
		this.numeroLicenciaConducir = numeroLicenciaConducir;
	}

	public int getNumeroPersona() {
		return numeroPersona;
	}

	public void setNumeroPersona(int numeroPersona) {
		this.numeroPersona = numeroPersona;
	}

	public int getNumeroRucRemitente() {
		return numeroRucRemitente;
	}

	public void setNumeroRucRemitente(int numeroRucRemitente) {
		this.numeroRucRemitente = numeroRucRemitente;
	}

	public int getNumeroSerie() {
		return numeroSerie;
	}

	public void setNumeroSerie(int numeroSerie) {
		this.numeroSerie = numeroSerie;
	}

	public int getSubcontratado() {
		return subcontratado;
	}

	public void setSubcontratado(int subcontratado) {
		this.subcontratado = subcontratado;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public int getTipoGuia() {
		return tipoGuia;
	}

	public void setTipoGuia(int tipoGuia) {
		this.tipoGuia = tipoGuia;
	}

	public int getTipoPersona() {
		return tipoPersona;
	}

	public void setTipoPersona(int tipoPersona) {
		this.tipoPersona = tipoPersona;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
