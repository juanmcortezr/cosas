package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T7882ACTIVIDAD")
public class Actividades extends Auditoria {

	 @Id
	 @Column(name = "COD_ACTIVIDAD")
	 private String codActividad;
	
	 @Column(name = "DES_ACTIVIDAD")
	 private String desActividad;
	
	 @Column(name = "DES_DET_ACTIVIDAD")
	 private String desDetalleActividad;
	
	 @Column(name = "IND_SERVICIO")
	 private String indServicio;
	
	 @Column(name = "NOM_ACTIVIDAD")
	 private String nomActividad;
	
	 @Column(name = "NUM_ORDEN")
	 private Integer numOrden;

	public String getCodActividad() {
		return codActividad;
	}

	public void setCodActividad(String codActividad) {
		this.codActividad = codActividad;
	}

	public String getDesActividad() {
		return desActividad;
	}

	public void setDesActividad(String desActividad) {
		this.desActividad = desActividad;
	}

	public String getDesDetalleActividad() {
		return desDetalleActividad;
	}

	public void setDesDetalleActividad(String desDetalleActividad) {
		this.desDetalleActividad = desDetalleActividad;
	}

	public String getIndServicio() {
		return indServicio;
	}

	public void setIndServicio(String indServicio) {
		this.indServicio = indServicio;
	}

	public String getNomActividad() {
		return nomActividad;
	}

	public void setNomActividad(String nomActividad) {
		this.nomActividad = nomActividad;
	}

	public Integer getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Integer numOrden) {
		this.numOrden = numOrden;
	}
	
}
