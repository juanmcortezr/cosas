package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10402CRITERIOCALI")
public class CriterioCalificacion extends Auditoria{

	 @Column(name = "DES_CRITERIO")
	 private String desCriterio;
	
	 @Id
	 @Column(name = "NUM_CRITERIO")
	 private Long numCriterio;
	
	 @Column(name = "POR_PESO")
	 private Double porPeso;

	public String getDesCriterio() {
		return desCriterio;
	}

	public void setDesCriterio(String desCriterio) {
		this.desCriterio = desCriterio;
	}

	public Long getNumCriterio() {
		return numCriterio;
	}

	public void setNumCriterio(Long numCriterio) {
		this.numCriterio = numCriterio;
	}

	public Double getPorPeso() {
		return porPeso;
	}

	public void setPorPeso(Double porPeso) {
		this.porPeso = porPeso;
	}
	
	
}
