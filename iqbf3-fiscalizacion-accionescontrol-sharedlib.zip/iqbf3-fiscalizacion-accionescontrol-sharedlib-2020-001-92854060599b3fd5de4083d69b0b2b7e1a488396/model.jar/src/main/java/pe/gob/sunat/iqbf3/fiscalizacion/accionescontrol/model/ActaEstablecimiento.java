package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "T10385ACTAESTAB")
public class ActaEstablecimiento extends Auditoria{
	 
	 @Id
	 @Column(name = "NUM_ACTA_ESTAB")
	 private Long numActaEstablecimiento;
	
	@Column(name = "num_estab_orden")
	 private Integer numEstablecimientoOrden;
	 
	 @Column(name = "COD_TIP_ACTA")
	 private String codTipoActa;

	 @Column(name = "NUM_ACTA")
	 private String numActa;

	 @Column(name = "DES_OTRA_ACTA")
	 private String desOtraActa;
	 
	 @Column(name = "COD_TIP_DOCVIN")
	 private String codTipoDocumentoReferencia;

	 @Column(name = "NUM_DOC_VIND")
	 private String numDocumentoVinculado;

	 @Column(name = "DES_OTRO_DOCVIN")
	 private String desOtroDocumentoVinculado;

	 @Column(name = "COD_TIP_INFORME")
	 private String codTipoInforme;
	
	 @Column(name = "DES_OTRO_INFORME")
	 private String desOtroInforme;
	
	 @Transient
	 private boolean indEliminar;

	public Integer getNumEstablecimientoOrden() {
		return numEstablecimientoOrden;
	}

	public void setNumEstablecimientoOrden(Integer numEstablecimientoOrden) {
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public String getCodTipoActa() {
		return codTipoActa;
	}

	public void setCodTipoActa(String codTipoActa) {
		this.codTipoActa = codTipoActa;
	}

	public String getCodTipoDocumentoReferencia() {
		return codTipoDocumentoReferencia;
	}

	public void setCodTipoDocumentoReferencia(String codTipoDocumentoReferencia) {
		this.codTipoDocumentoReferencia = codTipoDocumentoReferencia;
	}

	public String getCodTipoInforme() {
		return codTipoInforme;
	}

	public void setCodTipoInforme(String codTipoInforme) {
		this.codTipoInforme = codTipoInforme;
	}

	public String getDesOtraActa() {
		return desOtraActa;
	}

	public void setDesOtraActa(String desOtraActa) {
		this.desOtraActa = desOtraActa;
	}

	public String getDesOtroDocumentoVinculado() {
		return desOtroDocumentoVinculado;
	}

	public void setDesOtroDocumentoVinculado(String desOtroDocumentoVinculado) {
		this.desOtroDocumentoVinculado = desOtroDocumentoVinculado;
	}

	public String getDesOtroInforme() {
		return desOtroInforme;
	}

	public void setDesOtroInforme(String desOtroInforme) {
		this.desOtroInforme = desOtroInforme;
	}

	public String getNumActa() {
		return numActa;
	}

	public void setNumActa(String numActa) {
		this.numActa = numActa;
	}

	public Long getNumActaEstablecimiento() {
		return numActaEstablecimiento;
	}

	public void setNumActaEstablecimiento(Long numActaEstablecimiento) {
		this.numActaEstablecimiento = numActaEstablecimiento;
	}

	public String getNumDocumentoVinculado() {
		return numDocumentoVinculado;
	}

	public void setNumDocumentoVinculado(String numDocumentoVinculado) {
		this.numDocumentoVinculado = numDocumentoVinculado;
	}

	public boolean isIndEliminar() {
		return indEliminar;
	}

	public void setIndEliminar(boolean indEliminar) {
		this.indEliminar = indEliminar;
	}
	 
	 
}
