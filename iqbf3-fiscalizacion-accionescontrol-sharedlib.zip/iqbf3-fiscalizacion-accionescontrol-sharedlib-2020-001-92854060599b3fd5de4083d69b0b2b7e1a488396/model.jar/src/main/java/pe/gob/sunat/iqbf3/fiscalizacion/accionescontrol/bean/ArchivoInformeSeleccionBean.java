package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class ArchivoInformeSeleccionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	ArchivoBean	archivoBean;
	private	Long	numArchivoDoc;
	private	Long	numInformeSeleccion;
	private	Long	numArchivo;
	
	private AuditoriaBean auditoriaBean;
	
	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public ArchivoInformeSeleccionBean() {
		super();
	}

	public ArchivoInformeSeleccionBean(ArchivoBean archivoBean, Long numArchivoDoc, Long numInformeSeleccion) {
		super();
		this.archivoBean = archivoBean;
		this.numArchivoDoc = numArchivoDoc;
		this.numInformeSeleccion = numInformeSeleccion;
	}

	public ArchivoBean getArchivoBean() {
		return archivoBean;
	}

	public void setArchivoBean(ArchivoBean archivoBean) {
		this.archivoBean = archivoBean;
	}

	public Long getNumArchivoDoc() {
		return numArchivoDoc;
	}

	public void setNumArchivoDoc(Long numArchivoDoc) {
		this.numArchivoDoc = numArchivoDoc;
	}

	public Long getNumInformeSeleccion() {
		return numInformeSeleccion;
	}

	public void setNumInformeSeleccion(Long numInformeSeleccion) {
		this.numInformeSeleccion = numInformeSeleccion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	public Long getNumArchivo() {
		return numArchivo;
	}

	public void setNumArchivo(Long numArchivo) {
		this.numArchivo = numArchivo;
	}
}
