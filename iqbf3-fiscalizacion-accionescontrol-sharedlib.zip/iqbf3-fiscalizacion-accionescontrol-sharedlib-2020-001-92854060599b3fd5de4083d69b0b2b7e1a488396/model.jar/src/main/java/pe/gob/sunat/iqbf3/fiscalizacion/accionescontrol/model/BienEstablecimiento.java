package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "T10395BIENESTAB")
public class BienEstablecimiento extends Auditoria {

	
	 @Column(name = "CNT_STOCK_FISICO")
	 private Double cantidadStockFisico;
	
	 @Column(name = "COD_BIEN_FISCA")
	 private String codBienFiscalizado;
	
	 @Column(name = "COD_TIP_BIEN")
	 private String codTipoBien;
	
	 @Column(name = "COD_UND_MEDIDA")
	 private String codUnidadMedida;
	
	 @Column(name = "DES_BIEN")
	 private String desBien;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_STOCK_FISICO")
	 private Date fecStockFisico;
	 
	 @Temporal(TemporalType.TIME)
	 @Column(name = "HOR_STOCK_FISICO")
	 private Date horStockFisico;
	
	 @Id
	 @Column(name = "NUM_BIEN_ESTAB")
	 private Long numBienEstablecimiento;

	 @Column(name = "NUM_ESTAB_ORDEN")
	 private Long numEstablecimientoOrden;
	
	 
	 @Transient
	 private String desBienFiscalizado;

	public Long getNumEstablecimientoOrden() {
		return numEstablecimientoOrden;
	}

	public void setNumEstablecimientoOrden(Long numEstablecimientoOrden) {
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public Double getCantidadStockFisico() {
		return cantidadStockFisico;
	}

	public void setCantidadStockFisico(Double cantidadStockFisico) {
		this.cantidadStockFisico = cantidadStockFisico;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getCodUnidadMedida() {
		return codUnidadMedida;
	}

	public void setCodUnidadMedida(String codUnidadMedida) {
		this.codUnidadMedida = codUnidadMedida;
	}

	public String getDesBien() {
		return desBien;
	}

	public void setDesBien(String desBien) {
		this.desBien = desBien;
	}

	public Date getFecStockFisico() {
		return fecStockFisico;
	}

	public void setFecStockFisico(Date fecStockFisico) {
		this.fecStockFisico = fecStockFisico;
	}

	public Date getHorStockFisico() {
		return horStockFisico;
	}

	public void setHorStockFisico(Date horStockFisico) {
		this.horStockFisico = horStockFisico;
	}

	public Long getNumBienEstablecimiento() {
		return numBienEstablecimiento;
	}

	public void setNumBienEstablecimiento(Long numBienEstablecimiento) {
		this.numBienEstablecimiento = numBienEstablecimiento;
	}

	public String getDesBienFiscalizado() {
		return desBienFiscalizado;
	}

	public void setDesBienFiscalizado(String desBienFiscalizado) {
		this.desBienFiscalizado = desBienFiscalizado;
	}

	
	
}
