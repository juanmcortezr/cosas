package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class GrupoProcesoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codTipoProceso;
	private	String	nomGrupo;
	private	Long	numGrupo;
	
	public GrupoProcesoBean() {
		super();
	}

	public GrupoProcesoBean(String codTipoProceso, String nomGrupo, Long numGrupo) {
		super();
		this.codTipoProceso = codTipoProceso;
		this.nomGrupo = nomGrupo;
		this.numGrupo = numGrupo;
	}

	public String getCodTipoProceso() {
		return codTipoProceso;
	}

	public void setCodTipoProceso(String codTipoProceso) {
		this.codTipoProceso = codTipoProceso;
	}

	public String getNomGrupo() {
		return nomGrupo;
	}

	public void setNomGrupo(String nomGrupo) {
		this.nomGrupo = nomGrupo;
	}

	public Long getNumGrupo() {
		return numGrupo;
	}

	public void setNumGrupo(Long numGrupo) {
		this.numGrupo = numGrupo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
