package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


@Entity
@Table(name = "T10429USUARIOSOLIC")
public class UsuarioSolicitud extends Auditoria {
	
	 @Column(name = "COD_TIP_ACCION")
	 private String codTipoAccion;
	
	 @Column(name = "COD_TIP_DOCIDENT")
	 private String codTipoDocumentoIdentif;
	
	 @Column(name = "COD_TIP_DOCREFER")
	 private String codTipoDocumentoReferencia;
	
	 @Column(name = "COD_TIP_INTERV")
	 private String codTipoIntervencion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_SUGE_VISIT")
	 private Date fecSugeridaVisita;

	 @Temporal(TemporalType.TIME)
	 @Column(name = "HOR_SUGE_VISIT")
	 private Date horSugeVisit;
	
	 @Column(name = "NOM_APE_USU")
	 private String nomApellidoUsuario;
	
	 @Column(name = "NUM_DOC_IDENT")
	 private String numDocumentoIdentif;
	
	 @Column(name = "NUM_DOC_REFER")
	 private String numDocumentoReferencia;
	
	 @Id
	 @Column(name = "NUM_USU_SOLIC")
	 private Long numUsuarioSolicitud;

	 @Column(name = "NUM_ARC")
	 private Long numArc;

	 @Column(name = "NUM_SOLIC_PROG")
	 private Long numSolicitud;

	 // Extras
	 @Transient
	 private Double totalInconsistencia;
	 @Transient
	 private Double totalBien;
	 @Transient
	 private Double totalMedioProbatorio;
	 @Transient
	 private Double valCalificacionPreliminar;
	 @Transient
	 private Double valCalificacionDefinitiva;

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getCodTipoDocumentoReferencia() {
		return codTipoDocumentoReferencia;
	}

	public void setCodTipoDocumentoReferencia(String codTipoDocumentoReferencia) {
		this.codTipoDocumentoReferencia = codTipoDocumentoReferencia;
	}

	public String getCodTipoIntervencion() {
		return codTipoIntervencion;
	}

	public void setCodTipoIntervencion(String codTipoIntervencion) {
		this.codTipoIntervencion = codTipoIntervencion;
	}

	public Date getFecSugeridaVisita() {
		return fecSugeridaVisita;
	}

	public void setFecSugeridaVisita(Date fecSugeridaVisita) {
		this.fecSugeridaVisita = fecSugeridaVisita;
	}

	public Date getHorSugeVisit() {
		return horSugeVisit;
	}

	public void setHorSugeVisit(Date horSugeVisit) {
		this.horSugeVisit = horSugeVisit;
	}

	public String getNomApellidoUsuario() {
		return nomApellidoUsuario;
	}

	public void setNomApellidoUsuario(String nomApellidoUsuario) {
		this.nomApellidoUsuario = nomApellidoUsuario;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public String getNumDocumentoReferencia() {
		return numDocumentoReferencia;
	}

	public void setNumDocumentoReferencia(String numDocumentoReferencia) {
		this.numDocumentoReferencia = numDocumentoReferencia;
	}

	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public Long getNumArc() {
		return numArc;
	}

	public void setNumArc(Long numArc) {
		this.numArc = numArc;
	}

	public Double getTotalInconsistencia() {
		return totalInconsistencia;
	}

	public void setTotalInconsistencia(Double totalInconsistencia) {
		this.totalInconsistencia = totalInconsistencia;
	}

	public Double getTotalBien() {
		return totalBien;
	}

	public void setTotalBien(Double totalBien) {
		this.totalBien = totalBien;
	}

	public Double getTotalMedioProbatorio() {
		return totalMedioProbatorio;
	}

	public void setTotalMedioProbatorio(Double totalMedioProbatorio) {
		this.totalMedioProbatorio = totalMedioProbatorio;
	}

	public Long getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Long numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public Double getValCalificacionPreliminar() {
		return valCalificacionPreliminar;
	}

	public void setValCalificacionPreliminar(Double valCalificacionPreliminar) {
		this.valCalificacionPreliminar = valCalificacionPreliminar;
	}

	public Double getValCalificacionDefinitiva() {
		return valCalificacionDefinitiva;
	}

	public void setValCalificacionDefinitiva(Double valCalificacionDefinitiva) {
		this.valCalificacionDefinitiva = valCalificacionDefinitiva;
	}

}
