package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


@Entity
@Table(name = "T10428USUARIOPROG")
public class UsuarioProgramacion extends Auditoria {

	 @Column(name = "CNT_DIAS_ATENCION")
	 private Integer cantidadDiasAtencion;
	
	 @Column(name = "COD_DEPENDENCIA")
	 private String codDependencia;
	
	 @Column(name = "COD_EST_REG")
	 private String codEstadoRegistro;
	
	 @Column(name = "COD_EST_USU")
	 private String codEstadoUsuario;
	
	 @Column(name = "COD_MOT_DEPURACION")
	 private String codMotivaDepuracion;
	
	 @Column(name = "COD_NIVEL_RIESGO")
	 private String codNivelRiesgo;
	
	 @Column(name = "COD_TIP_ACCION")
	 private String codTipoAccion;
	
	 @Column(name = "COD_TIP_ACCSUGE")
	 private String codTipoAccionSugerida;
	
	 @Column(name = "COD_TIP_DOCIDENT")
	 private String codTipoDocumentoIdentif;
	
	 @Column(name = "COD_TIP_INTERV")
	 private String codTipoIntervencion;
	
	 @Column(name = "COD_TIP_INTERVSUGE")
	 private String codTipoIntervencionSugerida;
	
	 @Column(name = "COD_UBI_DOMFISCAL")
	 private String codUbigeoDomicilioFiscal;
	
	 @Column(name = "DES_SUS_MOTIVO")
	 private String desSusMotivo;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_FIN_VIGENCIA")
	 private Date fecFinVigencia;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INI_CASO")
	 private Date fecInicioCaso;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_PROCESAMIENTO")
	 private Date fecProcesamiento;
	
	 @Column(name = "HOR_INI_CASO")
	 private String horIniCaso;
	
	 @Column(name = "IND_NEUTRALIZACION")
	 private String indNeutralizacion;
	
	 @Column(name = "NOM_APE_USU")
	 private String nomApellidoUsuario;
	
	 @Column(name = "NUM_DOC_IDENT")
	 private String numDocumentoIdentif;
	
	 @Column(name = "NUM_PERIDOOMISOMAX")
	 private String numPeridoomisomax;
	
	 @Column(name = "NUM_PERIDOOMISOMIN")
	 private String numPeridoomisomin;

	 @Id
	 @Column(name = "NUM_USU_PROGRAM")
	 private Long numUsuarioPrograma;
	
	 @Column(name = "num_programacion")
	 private Long numProgramacion;
		 
	 @Column(name = "NUM_VERREG")
	 private Integer numVersionRegistro;
	 
	 @Column(name = "cod_tip_inconsis")
	 private String codTipInconsis;
	 
	 @Column(name = "ind_depuracion")
	 private String indDepuracion;
	 
	 @Transient
	 private Integer cantidadRegistros;
	 
	 @Transient
	 private String alcanceProg;
	 
	 @Transient
	 private String NumInformeSelecci;
	 
	 @Transient
	 private String codPers;
	 
	 @Transient
	 private String desProgctrl;
	 
	 @Transient
	 private String codAuditor;
	 
	 @Transient
	 private String nomAuditor;
	 
	 @Transient
	 private String nomRazonSocial;
	 
	 @Transient
	 private String codProgctrl;
	 
	 @Transient
	 private String codEstadoPrograma;
	 
	 @Transient
	 private List<String> estadosPrograma;

	 @Transient
	 private String codEstPrograma;
	 
	 @Transient
	 private String desAlcance;
	 
	 @Transient
	 private String numOrden;
	 
	 @Transient
	 private String codTipInterv;
	 
	 @Transient
	 private String codTipAccion;
	 
	 @Transient
	 private String numProgCorrel;
	 
	 @Transient
	 private String nroInformeUnion;
	 
	 @Transient
	 private String numOrdenUnion;
	 @Transient
	 private String numDocumentoAccion;
	 @Transient
	 private String codCargo;	 
	 @Transient
	 private Integer cantTiposAccion;
	 
	public String getNumDocumentoAccion() {
		return numDocumentoAccion;
	}

	public void setNumDocumentoAccion(String numDocumentoAccion) {
		this.numDocumentoAccion = numDocumentoAccion;
	}

	public String getCodCargo() {
		return codCargo;
	}

	public void setCodCargo(String codCargo) {
		this.codCargo = codCargo;
	}

	public String getNumOrdenUnion() {
		return numOrdenUnion;
	}

	public void setNumOrdenUnion(String numOrdenUnion) {
		this.numOrdenUnion = numOrdenUnion;
	}

	public String getNroInformeUnion() {
		return nroInformeUnion;
	}

	public void setNroInformeUnion(String nroInformeUnion) {
		this.nroInformeUnion = nroInformeUnion;
	}

	public String getCodTipInterv() {
		return codTipInterv;
	}

	public void setCodTipInterv(String codTipInterv) {
		this.codTipInterv = codTipInterv;
	}

	public String getCodTipAccion() {
		return codTipAccion;
	}

	public void setCodTipAccion(String codTipAccion) {
		this.codTipAccion = codTipAccion;
	}

	public String getNumProgCorrel() {
		return numProgCorrel;
	}

	public void setNumProgCorrel(String numProgCorrel) {
		this.numProgCorrel = numProgCorrel;
	}

	public String getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(String numOrden) {
		this.numOrden = numOrden;
	}

	public String getDesAlcance() {
		return desAlcance;
	}

	public void setDesAlcance(String desAlcance) {
		this.desAlcance = desAlcance;
	}

	public List<String> getEstadosPrograma() {
		return estadosPrograma;
	}

	public void setEstadosPrograma(List<String> estadosPrograma) {
		this.estadosPrograma = estadosPrograma;
	}

	public String getCodEstadoPrograma() {
		return codEstadoPrograma;
	}

	public void setCodEstadoPrograma(String codEstadoPrograma) {
		this.codEstadoPrograma = codEstadoPrograma;
	}

	public String getNomRazonSocial() {
		return nomRazonSocial;
	}

	public void setNomRazonSocial(String nomRazonSocial) {
		this.nomRazonSocial = nomRazonSocial;
	}

	public String getCodAuditor() {
		return codAuditor;
	}

	public void setCodAuditor(String codAuditor) {
		this.codAuditor = codAuditor;
	}

	public String getNomAuditor() {
		return nomAuditor;
	}

	public void setNomAuditor(String nomAuditor) {
		this.nomAuditor = nomAuditor;
	}

	public String getDesProgctrl() {
		return desProgctrl;
	}

	public void setDesProgctrl(String desProgctrl) {
		this.desProgctrl = desProgctrl;
	}
	 
	 
	public String getIndDepuracion() {
		return indDepuracion;
	}

	public void setIndDepuracion(String indDepuracion) {
		this.indDepuracion = indDepuracion;
	}

	public String getCodProgctrl() {
		return codProgctrl;
	}

	public void setCodProgctrl(String codProgctrl) {
		this.codProgctrl = codProgctrl;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getNumInformeSelecci() {
		return NumInformeSelecci;
	}

	public void setNumInformeSelecci(String numInformeSelecci) {
		NumInformeSelecci = numInformeSelecci;
	}

	public String getAlcanceProg() {
		return alcanceProg;
	}

	public void setAlcanceProg(String alcanceProg) {
		this.alcanceProg = alcanceProg;
	}

	public String getCodTipInconsis() {
		return codTipInconsis;
	}

	public void setCodTipInconsis(String codTipInconsis) {
		this.codTipInconsis = codTipInconsis;
	}

	public Integer getCantidadRegistros() {
		return cantidadRegistros;
	}

	public void setCantidadRegistros(Integer cantidadRegistros) {
		this.cantidadRegistros = cantidadRegistros;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public Integer getCantidadDiasAtencion() {
		return cantidadDiasAtencion;
	}

	public void setCantidadDiasAtencion(Integer cantidadDiasAtencion) {
		this.cantidadDiasAtencion = cantidadDiasAtencion;
	}

	public String getCodDependencia() {
		return codDependencia;
	}

	public void setCodDependencia(String codDependencia) {
		this.codDependencia = codDependencia;
	}

	public String getCodEstadoRegistro() {
		return codEstadoRegistro;
	}

	public void setCodEstadoRegistro(String codEstadoRegistro) {
		this.codEstadoRegistro = codEstadoRegistro;
	}

	public String getCodEstadoUsuario() {
		return codEstadoUsuario;
	}

	public void setCodEstadoUsuario(String codEstadoUsuario) {
		this.codEstadoUsuario = codEstadoUsuario;
	}

	public String getCodMotivaDepuracion() {
		return codMotivaDepuracion;
	}

	public void setCodMotivaDepuracion(String codMotivaDepuracion) {
		this.codMotivaDepuracion = codMotivaDepuracion;
	}

	public String getCodNivelRiesgo() {
		return codNivelRiesgo;
	}

	public void setCodNivelRiesgo(String codNivelRiesgo) {
		this.codNivelRiesgo = codNivelRiesgo;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getCodTipoAccionSugerida() {
		return codTipoAccionSugerida;
	}

	public void setCodTipoAccionSugerida(String codTipoAccionSugerida) {
		this.codTipoAccionSugerida = codTipoAccionSugerida;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getCodTipoIntervencion() {
		return codTipoIntervencion;
	}

	public void setCodTipoIntervencion(String codTipoIntervencion) {
		this.codTipoIntervencion = codTipoIntervencion;
	}

	public String getCodTipoIntervencionSugerida() {
		return codTipoIntervencionSugerida;
	}

	public void setCodTipoIntervencionSugerida(String codTipoIntervencionSugerida) {
		this.codTipoIntervencionSugerida = codTipoIntervencionSugerida;
	}

	public String getCodUbigeoDomicilioFiscal() {
		return codUbigeoDomicilioFiscal;
	}

	public void setCodUbigeoDomicilioFiscal(String codUbigeoDomicilioFiscal) {
		this.codUbigeoDomicilioFiscal = codUbigeoDomicilioFiscal;
	}

	public String getDesSusMotivo() {
		return desSusMotivo;
	}

	public void setDesSusMotivo(String desSusMotivo) {
		this.desSusMotivo = desSusMotivo;
	}

	public Date getFecFinVigencia() {
		return fecFinVigencia;
	}

	public void setFecFinVigencia(Date fecFinVigencia) {
		this.fecFinVigencia = fecFinVigencia;
	}

	public Date getFecInicioCaso() {
		return fecInicioCaso;
	}

	public void setFecInicioCaso(Date fecInicioCaso) {
		this.fecInicioCaso = fecInicioCaso;
	}

	public Date getFecProcesamiento() {
		return fecProcesamiento;
	}

	public void setFecProcesamiento(Date fecProcesamiento) {
		this.fecProcesamiento = fecProcesamiento;
	}

	public String getHorIniCaso() {
		return horIniCaso;
	}

	public void setHorIniCaso(String horIniCaso) {
		this.horIniCaso = horIniCaso;
	}

	public String getIndNeutralizacion() {
		return indNeutralizacion;
	}

	public void setIndNeutralizacion(String indNeutralizacion) {
		this.indNeutralizacion = indNeutralizacion;
	}

	public String getNomApellidoUsuario() {
		return nomApellidoUsuario;
	}

	public void setNomApellidoUsuario(String nomApellidoUsuario) {
		this.nomApellidoUsuario = nomApellidoUsuario;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public String getNumPeridoomisomax() {
		return numPeridoomisomax;
	}

	public void setNumPeridoomisomax(String numPeridoomisomax) {
		this.numPeridoomisomax = numPeridoomisomax;
	}

	public String getNumPeridoomisomin() {
		return numPeridoomisomin;
	}

	public void setNumPeridoomisomin(String numPeridoomisomin) {
		this.numPeridoomisomin = numPeridoomisomin;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public Integer getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(Integer numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public String getCodEstPrograma() {
		return codEstPrograma;
	}

	public void setCodEstPrograma(String codEstPrograma) {
		this.codEstPrograma = codEstPrograma;
	}

	public Integer getCantTiposAccion() {
		return cantTiposAccion;
	}

	public void setCantTiposAccion(Integer cantTiposAccion) {
		this.cantTiposAccion = cantTiposAccion;
	}
	 
}
