package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10422SUSPENSORDEN")
public class SuspensionOrden extends Auditoria {

	 @Column(name = "COD_SUS_SUSP")
	 private String codSustentoSuspencion;
	
	 @Id
	 @Column(name = "NUM_SUS_SUPORDEN")
	 private Long numSusSuporden;
	 
	 @Column(name = "num_orden")
	 private Long numOrden;
	 
	 
	public String getCodSustentoSuspencion() {
		return codSustentoSuspencion;
	}

	public void setCodSustentoSuspencion(String codSustentoSuspencion) {
		this.codSustentoSuspencion = codSustentoSuspencion;
	}

	public Long getNumSusSuporden() {
		return numSusSuporden;
	}

	public void setNumSusSuporden(Long numSusSuporden) {
		this.numSusSuporden = numSusSuporden;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}

	
	
}
