package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import pe.gob.sunat.iqbf3.registro.maestros.model.EntidadPK;

@Embeddable
public class PerfilRiesgosPK implements EntidadPK {

	@Column(name = "COD_CIC")
	private Integer codCic;

	@Column(name = "COD_PERVAGG")
	private Integer codPervagg;

	@Column(name = "COD_TIPIDENTI")
	private Integer codTipoDocumentoIdent;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FEC_FINVIG")
	private Date fecFinVigencia;

	@Column(name = "NUM_DOCIDENTI")
	private String numDocumentoIdentif;

	public Integer getCodCic() {
		return codCic;
	}

	public void setCodCic(Integer codCic) {
		this.codCic = codCic;
	}

	public Integer getCodPervagg() {
		return codPervagg;
	}

	public void setCodPervagg(Integer codPervagg) {
		this.codPervagg = codPervagg;
	}

	public Integer getCodTipoDocumentoIdent() {
		return codTipoDocumentoIdent;
	}

	public void setCodTipoDocumentoIdent(Integer codTipoDocumentoIdent) {
		this.codTipoDocumentoIdent = codTipoDocumentoIdent;
	}

	public Date getFecFinVigencia() {
		return fecFinVigencia;
	}

	public void setFecFinVigencia(Date fecFinVigencia) {
		this.fecFinVigencia = fecFinVigencia;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

}
