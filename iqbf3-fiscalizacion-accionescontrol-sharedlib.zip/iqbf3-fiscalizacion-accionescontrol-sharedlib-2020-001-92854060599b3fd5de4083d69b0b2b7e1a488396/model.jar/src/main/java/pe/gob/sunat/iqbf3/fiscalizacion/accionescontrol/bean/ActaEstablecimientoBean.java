package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class ActaEstablecimientoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codTipoActa;
	private	String	codTipoDocumentoReferencia;
	private	String	codTipoInforme;
	private	String	desOtraActa;
	private	String	desOtroDocumentoVinculado;
	private	String	desOtroInforme;
	private	String	desTipoActa;
	private	String	desTipoDocumentoVinculado;
	private	String	desTipoInforme;
	private	String	numActa;
	private	int	numActaEstablecimiento;
	private	String	numDocumentoVinculado;
	private	int	numEstablecimientoOrden;
	
	private String indDel;
	private String indEst;
	private AuditoriaBean auditoriaBean;
	
	public ActaEstablecimientoBean() {
		super();
	}

	public ActaEstablecimientoBean(String codTipoActa, String codTipoDocumentoReferencia, String codTipoInforme,
			String desOtraActa, String desOtroDocumentoVinculado, String desOtroInforme, String desTipoActa,
			String desTipoDocumentoVinculado, String desTipoInforme, String numActa, int numActaEstablecimiento,
			String numDocumentoVinculado, int numEstablecimientoOrden) {
		super();
		this.codTipoActa = codTipoActa;
		this.codTipoDocumentoReferencia = codTipoDocumentoReferencia;
		this.codTipoInforme = codTipoInforme;
		this.desOtraActa = desOtraActa;
		this.desOtroDocumentoVinculado = desOtroDocumentoVinculado;
		this.desOtroInforme = desOtroInforme;
		this.desTipoActa = desTipoActa;
		this.desTipoDocumentoVinculado = desTipoDocumentoVinculado;
		this.desTipoInforme = desTipoInforme;
		this.numActa = numActa;
		this.numActaEstablecimiento = numActaEstablecimiento;
		this.numDocumentoVinculado = numDocumentoVinculado;
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public String getCodTipoActa() {
		return codTipoActa;
	}

	public void setCodTipoActa(String codTipoActa) {
		this.codTipoActa = codTipoActa;
	}

	public String getCodTipoDocumentoReferencia() {
		return codTipoDocumentoReferencia;
	}

	public void setCodTipoDocumentoReferencia(String codTipoDocumentoReferencia) {
		this.codTipoDocumentoReferencia = codTipoDocumentoReferencia;
	}

	public String getCodTipoInforme() {
		return codTipoInforme;
	}

	public void setCodTipoInforme(String codTipoInforme) {
		this.codTipoInforme = codTipoInforme;
	}

	public String getDesOtraActa() {
		return desOtraActa;
	}

	public void setDesOtraActa(String desOtraActa) {
		this.desOtraActa = desOtraActa;
	}

	public String getDesOtroDocumentoVinculado() {
		return desOtroDocumentoVinculado;
	}

	public void setDesOtroDocumentoVinculado(String desOtroDocumentoVinculado) {
		this.desOtroDocumentoVinculado = desOtroDocumentoVinculado;
	}

	public String getDesOtroInforme() {
		return desOtroInforme;
	}

	public void setDesOtroInforme(String desOtroInforme) {
		this.desOtroInforme = desOtroInforme;
	}

	public String getDesTipoActa() {
		return desTipoActa;
	}

	public void setDesTipoActa(String desTipoActa) {
		this.desTipoActa = desTipoActa;
	}

	public String getDesTipoDocumentoVinculado() {
		return desTipoDocumentoVinculado;
	}

	public void setDesTipoDocumentoVinculado(String desTipoDocumentoVinculado) {
		this.desTipoDocumentoVinculado = desTipoDocumentoVinculado;
	}

	public String getDesTipoInforme() {
		return desTipoInforme;
	}

	public void setDesTipoInforme(String desTipoInforme) {
		this.desTipoInforme = desTipoInforme;
	}

	public String getNumActa() {
		return numActa;
	}

	public void setNumActa(String numActa) {
		this.numActa = numActa;
	}

	public int getNumActaEstablecimiento() {
		return numActaEstablecimiento;
	}

	public void setNumActaEstablecimiento(int numActaEstablecimiento) {
		this.numActaEstablecimiento = numActaEstablecimiento;
	}

	public String getNumDocumentoVinculado() {
		return numDocumentoVinculado;
	}

	public void setNumDocumentoVinculado(String numDocumentoVinculado) {
		this.numDocumentoVinculado = numDocumentoVinculado;
	}

	public int getNumEstablecimientoOrden() {
		return numEstablecimientoOrden;
	}

	public void setNumEstablecimientoOrden(int numEstablecimientoOrden) {
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}	
	
	
}
