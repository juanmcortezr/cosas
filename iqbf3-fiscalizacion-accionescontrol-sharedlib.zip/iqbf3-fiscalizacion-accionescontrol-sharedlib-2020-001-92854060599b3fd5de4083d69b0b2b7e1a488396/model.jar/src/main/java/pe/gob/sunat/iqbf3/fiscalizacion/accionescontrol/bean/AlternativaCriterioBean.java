package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class AlternativaCriterioBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private	String	desAlternativa;
	private	String	desCriterio;
	private	Long	numAlternativa;
	private	Long	numCriterio;
	private	int	valAlternativa;
	private String indEstado;
	
	private AuditoriaBean auditoriaBean;
	private boolean seleccionado;

	private Double pesoCriterio;

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public AlternativaCriterioBean() {
		super();
	}

	public AlternativaCriterioBean(String desAlternativa, Long numAlternativa, Long numCriterio, int valAlternativa,
			String indEstado) {
		super();
		this.desAlternativa = desAlternativa;
		this.numAlternativa = numAlternativa;
		this.numCriterio = numCriterio;
		this.valAlternativa = valAlternativa;
		this.indEstado = indEstado;
	}

	public String getDesAlternativa() {
		return desAlternativa;
	}

	public void setDesAlternativa(String desAlternativa) {
		this.desAlternativa = desAlternativa;
	}

	public Long getNumAlternativa() {
		return numAlternativa;
	}

	public void setNumAlternativa(Long numAlternativa) {
		this.numAlternativa = numAlternativa;
	}

	public Long getNumCriterio() {
		return numCriterio;
	}

	public void setNumCriterio(Long numCriterio) {
		this.numCriterio = numCriterio;
	}

	public int getValAlternativa() {
		return valAlternativa;
	}

	public void setValAlternativa(int valAlternativa) {
		this.valAlternativa = valAlternativa;
	}

	public String getIndEstado() {
		return indEstado;
	}

	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}

	public boolean isSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

	public String getDesCriterio() {
		return desCriterio;
	}

	public void setDesCriterio(String desCriterio) {
		this.desCriterio = desCriterio;
	}

	public void setPesoCriterio(Double pesoCriterio) {
		this.pesoCriterio = pesoCriterio;
	}

	public Double getPesoCriterio() {
		return pesoCriterio;
	}

	

}
