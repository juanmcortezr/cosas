package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "T10407DOCUMENORDEN")
public class DocumentoOrden extends Auditoria{

	 @Column(name = "COD_ORIGEN")
	 private String codOrigen;
	
	 @Column(name = "COD_TIP_DOC")
	 private String codTipoDocumento;
	
	 @Column(name = "DES_DOC")
	 private String desDocumento;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_EMISION")
	 private Date fecEmision;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_ENTREGA")
	 private Date fecEntrega;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_NOTIFICACION")
	 private Date fecNotificacion;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_PRES_VISITA")
	 private Date fecPresentaVisita;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_PRORROGA")
	 private Date fecProrroga;
	
	 @Column(name = "NUM_DOC")
	 private String numDocumento;
	
	 @Id
	 @Column(name = "NUM_DOC_ORDEN")
	 private Long numDocumentoOrden;
	 
	 //PARA FILTROS
//	 @Transient
//	 private Long numArc;
	 
	 @Column(name = "num_orden")
	 private Long numOrden;
	 
	 @Column(name="num_arc")
	 private Long numArc;
	 
	 @Transient
	 private boolean indEliminar;
	 
	 @Transient
	 private String nomArc;
	 
	 
	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}

	public String getCodTipoDocumento() {
		return codTipoDocumento;
	}

	public void setCodTipoDocumento(String codTipoDocumento) {
		this.codTipoDocumento = codTipoDocumento;
	}

	public String getDesDocumento() {
		return desDocumento;
	}

	public void setDesDocumento(String desDocumento) {
		this.desDocumento = desDocumento;
	}

	public Date getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(Date fecEmision) {
		this.fecEmision = fecEmision;
	}

	public Date getFecEntrega() {
		return fecEntrega;
	}

	public void setFecEntrega(Date fecEntrega) {
		this.fecEntrega = fecEntrega;
	}

	public Date getFecNotificacion() {
		return fecNotificacion;
	}

	public void setFecNotificacion(Date fecNotificacion) {
		this.fecNotificacion = fecNotificacion;
	}

	public Date getFecPresentaVisita() {
		return fecPresentaVisita;
	}

	public void setFecPresentaVisita(Date fecPresentaVisita) {
		this.fecPresentaVisita = fecPresentaVisita;
	}

	public Date getFecProrroga() {
		return fecProrroga;
	}

	public void setFecProrroga(Date fecProrroga) {
		this.fecProrroga = fecProrroga;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public Long getNumDocumentoOrden() {
		return numDocumentoOrden;
	}

	public void setNumDocumentoOrden(Long numDocumentoOrden) {
		this.numDocumentoOrden = numDocumentoOrden;
	}


	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}

	public Long getNumArc() {
		return numArc;
	}

	public void setNumArc(Long numArc) {
		this.numArc = numArc;
	}

	public String getNomArc() {
		return nomArc;
	}

	public void setNomArc(String nomArc) {
		this.nomArc = nomArc;
	}

	public boolean isIndEliminar() {
		return indEliminar;
	}

	public void setIndEliminar(boolean indEliminar) {
		this.indEliminar = indEliminar;
	}
 
	 
}
