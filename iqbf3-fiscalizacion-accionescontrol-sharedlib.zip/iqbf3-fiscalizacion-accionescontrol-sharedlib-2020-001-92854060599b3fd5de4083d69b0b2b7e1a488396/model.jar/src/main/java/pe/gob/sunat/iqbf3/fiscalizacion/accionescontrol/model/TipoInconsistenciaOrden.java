package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10424TIPINCOORDEN")
public class TipoInconsistenciaOrden extends Auditoria {

	 @Column(name = "COD_ORIGEN")
	 private String codOrigen;
	
	 @Column(name = "COD_RESUL_INCONSIS")
	 private String codResultadoInconsistencia;
	
	 @Column(name = "COD_TIP_INCONSIS")
	 private String codTipoInconsistencia;
	
	 @Column(name = "DES_OTRA_INCONSIS")
	 private String desOtraInconsistencia;
	
	 @Column(name = "DES_SUS_INCONSIS")
	 private String desSusInconsis;
	
	 @Id
	 @Column(name = "NUM_INCON_ORDEN")
	 private Long numInconsistenciaOrden;
	 
	 @Column(name="NUM_ORDEN")
	 private Long numOrden;
	 
	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}

	public String getCodResultadoInconsistencia() {
		return codResultadoInconsistencia;
	}

	public void setCodResultadoInconsistencia(String codResultadoInconsistencia) {
		this.codResultadoInconsistencia = codResultadoInconsistencia;
	}

	public String getCodTipoInconsistencia() {
		return codTipoInconsistencia;
	}

	public void setCodTipoInconsistencia(String codTipoInconsistencia) {
		this.codTipoInconsistencia = codTipoInconsistencia;
	}

	public String getDesOtraInconsistencia() {
		return desOtraInconsistencia;
	}

	public void setDesOtraInconsistencia(String desOtraInconsistencia) {
		this.desOtraInconsistencia = desOtraInconsistencia;
	}

	public String getDesSusInconsis() {
		return desSusInconsis;
	}

	public void setDesSusInconsis(String desSusInconsis) {
		this.desSusInconsis = desSusInconsis;
	}

	public Long getNumInconsistenciaOrden() {
		return numInconsistenciaOrden;
	}

	public void setNumInconsistenciaOrden(Long numInconsistenciaOrden) {
		this.numInconsistenciaOrden = numInconsistenciaOrden;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}
 
	
	
}
