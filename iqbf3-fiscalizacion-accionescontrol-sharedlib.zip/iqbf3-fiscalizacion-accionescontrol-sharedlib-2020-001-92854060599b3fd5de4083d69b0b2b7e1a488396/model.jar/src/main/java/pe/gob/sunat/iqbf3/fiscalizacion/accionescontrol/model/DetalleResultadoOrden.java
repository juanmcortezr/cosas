package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10404DETARESORDEN")
public class DetalleResultadoOrden extends Auditoria{

	 @Column(name = "COD_RESUL_ORDEN")
	 private String codResulOrden;
	
	 @Column(name = "DES_OTRO_RESUL")
	 private String desOtroResultado;
	
	 @Id
	 @Column(name = "NUM_DET_RESULORDEN")
	 private Long numDetalleResultadoOrden;
	 
	 @Column(name = "num_orden")
	 private Long numOrden;
	 
	public String getCodResulOrden() {
		return codResulOrden;
	}

	public void setCodResulOrden(String codResulOrden) {
		this.codResulOrden = codResulOrden;
	}

	public String getDesOtroResultado() {
		return desOtroResultado;
	}

	public void setDesOtroResultado(String desOtroResultado) {
		this.desOtroResultado = desOtroResultado;
	}

	public Long getNumDetalleResultadoOrden() {
		return numDetalleResultadoOrden;
	}

	public void setNumDetalleResultadoOrden(Long numDetalleResultadoOrden) {
		this.numDetalleResultadoOrden = numDetalleResultadoOrden;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}
	
	
	
}
