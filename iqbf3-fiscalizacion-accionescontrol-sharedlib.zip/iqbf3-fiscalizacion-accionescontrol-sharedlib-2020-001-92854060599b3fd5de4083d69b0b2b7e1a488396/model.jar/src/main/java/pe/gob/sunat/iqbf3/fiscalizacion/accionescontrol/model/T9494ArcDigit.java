package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienFiscalizadoSolicitudBean;
//import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CheckElementBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T9494ArcDigit")
public class T9494ArcDigit implements Entidad{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "num_arc_digit")
	private Integer numArcDigit;
	
	@Column(name = "nom_archivo")
	private String nombreArchivo;
	
	@Column(name = "num_tamano")
	private Long numTamanio;
	
	@Column(name = "ind_activo")
	private String indActivo;
	
	@Column(name = "arc_digit")
	private byte[] arcDigit;

	public Integer getNumArcDigit() {
		return numArcDigit;
	}

	public void setNumArcDigit(Integer numArcDigit) {
		this.numArcDigit = numArcDigit;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public Long getNumTamanio() {
		return numTamanio;
	}

	public void setNumTamanio(Long numTamanio) {
		this.numTamanio = numTamanio;
	}

	public String getIndActivo() {
		return indActivo;
	}

	public void setIndActivo(String indActivo) {
		this.indActivo = indActivo;
	}

	public byte[] getArcDigit() {
		return arcDigit;
	}

	public void setArcDigit(byte[] arcDigit) {
		this.arcDigit = arcDigit;
	}
	
	
}
