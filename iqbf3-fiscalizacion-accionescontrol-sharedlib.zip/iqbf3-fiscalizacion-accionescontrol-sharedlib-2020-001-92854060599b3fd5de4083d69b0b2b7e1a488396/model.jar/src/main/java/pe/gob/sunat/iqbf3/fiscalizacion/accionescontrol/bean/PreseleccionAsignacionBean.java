package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class PreseleccionAsignacionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codAuditor;
	private	String	codTipoAccion;
	private	String	desTipoAccion;
	private	String	nomAuditor;
	private	Long numAsignacionTemp;
	private	Long numProgramacion;
	
	//filtro
	private String numInfSelecc;
	
	public String getNumInfSelecc() {
		return numInfSelecc;
	}

	public void setNumInfSelecc(String numInfSelecc) {
		this.numInfSelecc = numInfSelecc;
	}

	private AuditoriaBean auditoriaBean;
	
	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public PreseleccionAsignacionBean() {
		super();
	}

	public PreseleccionAsignacionBean(String codAuditor, String codTipoAccion, String desTipoAccion, String nomAuditor,
			Long numAsignacionTemp, Long numProgramacion) {
		super();
		this.codAuditor = codAuditor;
		this.codTipoAccion = codTipoAccion;
		this.desTipoAccion = desTipoAccion;
		this.nomAuditor = nomAuditor;
		this.numAsignacionTemp = numAsignacionTemp;
		this.numProgramacion = numProgramacion;
	}

	public String getCodAuditor() {
		return codAuditor;
	}

	public void setCodAuditor(String codAuditor) {
		this.codAuditor = codAuditor;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getDesTipoAccion() {
		return desTipoAccion;
	}

	public void setDesTipoAccion(String desTipoAccion) {
		this.desTipoAccion = desTipoAccion;
	}

	public String getNomAuditor() {
		return nomAuditor;
	}

	public void setNomAuditor(String nomAuditor) {
		this.nomAuditor = nomAuditor;
	}

	public Long getNumAsignacionTemp() {
		return numAsignacionTemp;
	}

	public void setNumAsignacionTemp(Long numAsignacionTemp) {
		this.numAsignacionTemp = numAsignacionTemp;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
