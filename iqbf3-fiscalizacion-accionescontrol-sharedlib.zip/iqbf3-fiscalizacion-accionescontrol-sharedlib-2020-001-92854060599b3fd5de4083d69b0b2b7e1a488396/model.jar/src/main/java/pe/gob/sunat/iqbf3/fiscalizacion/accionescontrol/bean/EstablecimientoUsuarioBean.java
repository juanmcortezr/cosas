package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

public class EstablecimientoUsuarioBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codDepartamento;
	private	String	codDistrito;
	private	String	codProvincia;
	private	String	desDireccionEstablecimiento;
	private	String	desDepartamento;
	private	String	desDistrito;
	private	String	desProvincia;
	private	String	indOtroEstab;
	private	Long	numEstablecimiento;
	private	Long	numEstablecimientoUsuario;
	private	Long	numUsuarioPrograma;
	private AuditoriaBean auditoriaBean;

	private String desUbigeo;
	private Long numUsuarioSolicitud;
	
	public EstablecimientoUsuarioBean() {
		super();
	}

	public EstablecimientoUsuarioBean(String codDepartamento, String codDistrito, String codProvincia,
			String desDireccionEstablecimiento, String desDepartamento, String desDistrito, String desProvincia,
			String indOtroEstab, Long numEstablecimiento, Long numEstablecimientoUsuario, Long numUsuarioPrograma) {
		super();
		this.codDepartamento = codDepartamento;
		this.codDistrito = codDistrito;
		this.codProvincia = codProvincia;
		this.desDireccionEstablecimiento = desDireccionEstablecimiento;
		this.desDepartamento = desDepartamento;
		this.desDistrito = desDistrito;
		this.desProvincia = desProvincia;
		this.indOtroEstab = indOtroEstab;
		this.numEstablecimiento = numEstablecimiento;
		this.numEstablecimientoUsuario = numEstablecimientoUsuario;
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public String getCodDepartamento() {
		return codDepartamento;
	}

	public void setCodDepartamento(String codDepartamento) {
		this.codDepartamento = codDepartamento;
	}

	public String getCodDistrito() {
		return codDistrito;
	}

	public void setCodDistrito(String codDistrito) {
		this.codDistrito = codDistrito;
	}

	public String getCodProvincia() {
		return codProvincia;
	}

	public void setCodProvincia(String codProvincia) {
		this.codProvincia = codProvincia;
	}

	public String getDesDireccionEstablecimiento() {
		return desDireccionEstablecimiento;
	}

	public void setDesDireccionEstablecimiento(String desDireccionEstablecimiento) {
		this.desDireccionEstablecimiento = desDireccionEstablecimiento;
	}

	public String getDesDepartamento() {
		return desDepartamento;
	}

	public void setDesDepartamento(String desDepartamento) {
		this.desDepartamento = desDepartamento;
	}

	public String getDesDistrito() {
		return desDistrito;
	}

	public void setDesDistrito(String desDistrito) {
		this.desDistrito = desDistrito;
	}

	public String getDesProvincia() {
		return desProvincia;
	}

	public void setDesProvincia(String desProvincia) {
		this.desProvincia = desProvincia;
	}

	public String getIndOtroEstab() {
		return indOtroEstab;
	}

	public void setIndOtroEstab(String indOtroEstab) {
		this.indOtroEstab = indOtroEstab;
	}

	public Long getNumEstablecimiento() {
		return numEstablecimiento;
	}

	public void setNumEstablecimiento(Long numEstablecimiento) {
		this.numEstablecimiento = numEstablecimiento;
	}

	public Long getNumEstablecimientoUsuario() {
		return numEstablecimientoUsuario;
	}

	public void setNumEstablecimientoUsuario(Long numEstablecimientoUsuario) {
		this.numEstablecimientoUsuario = numEstablecimientoUsuario;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public String getDesUbigeo() {
		return String.format("%s%s%s %s-%s-%s", MaestrosUtilidades.toBlank(this.getCodDepartamento()), MaestrosUtilidades.toBlank(this.getCodDistrito()),
				MaestrosUtilidades.toBlank(this.getCodProvincia()), MaestrosUtilidades.toBlank(this.getDesDepartamento()), MaestrosUtilidades.toBlank(this.getDesProvincia()),
				MaestrosUtilidades.toBlank(this.getDesDistrito()));
	}

	public void setDesUbigeo(String desUbigeo) {
		this.desUbigeo = desUbigeo;
	}

	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

}
