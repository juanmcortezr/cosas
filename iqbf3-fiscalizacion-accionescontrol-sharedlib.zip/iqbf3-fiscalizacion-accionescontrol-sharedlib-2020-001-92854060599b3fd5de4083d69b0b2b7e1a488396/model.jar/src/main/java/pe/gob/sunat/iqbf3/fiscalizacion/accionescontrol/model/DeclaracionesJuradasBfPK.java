package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import pe.gob.sunat.iqbf3.registro.maestros.model.EntidadPK;

@Embeddable
public class DeclaracionesJuradasBfPK implements EntidadPK{

	 @Column(name = "NUM_CAB")
	 private Integer numCabecera;

	  @Column(name = "COD_TIPBIEN")
	 private String codTipobien;
	
	  @Column(name = "NUM_RUC")
	 private String numRuc;
	
	 @Column(name = "NUM_VERREG")
	 private Integer numVersionRegistro;

	public Integer getNumCabecera() {
		return numCabecera;
	}

	public void setNumCabecera(Integer numCabecera) {
		this.numCabecera = numCabecera;
	}

	public String getCodTipobien() {
		return codTipobien;
	}

	public void setCodTipobien(String codTipobien) {
		this.codTipobien = codTipobien;
	}

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public Integer getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(Integer numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}
	

}
