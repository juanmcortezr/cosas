package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class MensajeIqbfBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codMensaje;
	private	String	codTipoDocumento;
	private	String	codTipoProceso;
	private	String	desAbreviatura;
	private	String	desCorta;
	private	String	desCuerpo;
	private	String	desLarga;
	private	String	indAsunto;
	
	public MensajeIqbfBean() {
		super();
	}

	public MensajeIqbfBean(String codMensaje, String codTipoDocumento, String codTipoProceso,
			String desAbreviatura, String desCorta, String desCuerpo, String desLarga, String indAsunto) {
		super();
		this.codMensaje = codMensaje;
		this.codTipoDocumento = codTipoDocumento;
		this.codTipoProceso = codTipoProceso;
		this.desAbreviatura = desAbreviatura;
		this.desCorta = desCorta;
		this.desCuerpo = desCuerpo;
		this.desLarga = desLarga;
		this.indAsunto = indAsunto;
	}

	public String getCodMensaje() {
		return codMensaje;
	}

	public void setCodMensaje(String codMensaje) {
		this.codMensaje = codMensaje;
	}

	public String getCodTipoDocumento() {
		return codTipoDocumento;
	}

	public void setCodTipoDocumento(String codTipoDocumento) {
		this.codTipoDocumento = codTipoDocumento;
	}

	public String getCodTipoProceso() {
		return codTipoProceso;
	}

	public void setCodTipoProceso(String codTipoProceso) {
		this.codTipoProceso = codTipoProceso;
	}

	public String getDesAbreviatura() {
		return desAbreviatura;
	}

	public void setDesAbreviatura(String desAbreviatura) {
		this.desAbreviatura = desAbreviatura;
	}

	public String getDesCorta() {
		return desCorta;
	}

	public void setDesCorta(String desCorta) {
		this.desCorta = desCorta;
	}

	public String getDesCuerpo() {
		return desCuerpo;
	}

	public void setDesCuerpo(String desCuerpo) {
		this.desCuerpo = desCuerpo;
	}

	public String getDesLarga() {
		return desLarga;
	}

	public void setDesLarga(String desLarga) {
		this.desLarga = desLarga;
	}

	public String getIndAsunto() {
		return indAsunto;
	}

	public void setIndAsunto(String indAsunto) {
		this.indAsunto = indAsunto;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
