package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class RegistroUsuarioBfBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codEstado;
	private String codMotivoBaja;
	private String codTipoBien;
	private String fecAlta;
	private String fecBaja;
	private String fecFinVigencia;
	private String fecLevanteSuspencion;
	private String fecSuspension;
	private String indAutoriza;
	private String indDesvio;
	private String indExoneracion;
	private String indmineria;
	private String indOmiso;
	private String indTrafico;
	private String indZonare;
	private int numCalificacion;
	private int numCarga;
	private String numOsinergmin;
	private int numReferencianModifica;
	private String numRegistroMtc;
	private String numRegistroAlta;
	private String numRuc;
	private int numSolicitud;
	private int numVersionRegistro;
	
	public RegistroUsuarioBfBean() {
		super();
	}

	public RegistroUsuarioBfBean(String codEstado, String codMotivoBaja, String codTipoBien, String fecAlta,
			String fecBaja, String fecFinVigencia, String fecLevanteSuspencion, String fecSuspension,
			String indAutoriza, String indDesvio, String indExoneracion, String indmineria, String indOmiso,
			String indTrafico, String indZonare, int numCalificacion, int numCarga, String numOsinergmin,
			int numReferencianModifica, String numRegistroMtc, String numRegistroAlta, String numRuc, int numSolicitud,
			int numVersionRegistro) {
		super();
		this.codEstado = codEstado;
		this.codMotivoBaja = codMotivoBaja;
		this.codTipoBien = codTipoBien;
		this.fecAlta = fecAlta;
		this.fecBaja = fecBaja;
		this.fecFinVigencia = fecFinVigencia;
		this.fecLevanteSuspencion = fecLevanteSuspencion;
		this.fecSuspension = fecSuspension;
		this.indAutoriza = indAutoriza;
		this.indDesvio = indDesvio;
		this.indExoneracion = indExoneracion;
		this.indmineria = indmineria;
		this.indOmiso = indOmiso;
		this.indTrafico = indTrafico;
		this.indZonare = indZonare;
		this.numCalificacion = numCalificacion;
		this.numCarga = numCarga;
		this.numOsinergmin = numOsinergmin;
		this.numReferencianModifica = numReferencianModifica;
		this.numRegistroMtc = numRegistroMtc;
		this.numRegistroAlta = numRegistroAlta;
		this.numRuc = numRuc;
		this.numSolicitud = numSolicitud;
		this.numVersionRegistro = numVersionRegistro;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodMotivoBaja() {
		return codMotivoBaja;
	}

	public void setCodMotivoBaja(String codMotivoBaja) {
		this.codMotivoBaja = codMotivoBaja;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getFecAlta() {
		return fecAlta;
	}

	public void setFecAlta(String fecAlta) {
		this.fecAlta = fecAlta;
	}

	public String getFecBaja() {
		return fecBaja;
	}

	public void setFecBaja(String fecBaja) {
		this.fecBaja = fecBaja;
	}

	public String getFecFinVigencia() {
		return fecFinVigencia;
	}

	public void setFecFinVigencia(String fecFinVigencia) {
		this.fecFinVigencia = fecFinVigencia;
	}

	public String getFecLevanteSuspencion() {
		return fecLevanteSuspencion;
	}

	public void setFecLevanteSuspencion(String fecLevanteSuspencion) {
		this.fecLevanteSuspencion = fecLevanteSuspencion;
	}

	public String getFecSuspension() {
		return fecSuspension;
	}

	public void setFecSuspension(String fecSuspension) {
		this.fecSuspension = fecSuspension;
	}

	public String getIndAutoriza() {
		return indAutoriza;
	}

	public void setIndAutoriza(String indAutoriza) {
		this.indAutoriza = indAutoriza;
	}

	public String getIndDesvio() {
		return indDesvio;
	}

	public void setIndDesvio(String indDesvio) {
		this.indDesvio = indDesvio;
	}

	public String getIndExoneracion() {
		return indExoneracion;
	}

	public void setIndExoneracion(String indExoneracion) {
		this.indExoneracion = indExoneracion;
	}

	public String getIndmineria() {
		return indmineria;
	}

	public void setIndmineria(String indmineria) {
		this.indmineria = indmineria;
	}

	public String getIndOmiso() {
		return indOmiso;
	}

	public void setIndOmiso(String indOmiso) {
		this.indOmiso = indOmiso;
	}

	public String getIndTrafico() {
		return indTrafico;
	}

	public void setIndTrafico(String indTrafico) {
		this.indTrafico = indTrafico;
	}

	public String getIndZonare() {
		return indZonare;
	}

	public void setIndZonare(String indZonare) {
		this.indZonare = indZonare;
	}

	public int getNumCalificacion() {
		return numCalificacion;
	}

	public void setNumCalificacion(int numCalificacion) {
		this.numCalificacion = numCalificacion;
	}

	public int getNumCarga() {
		return numCarga;
	}

	public void setNumCarga(int numCarga) {
		this.numCarga = numCarga;
	}

	public String getNumOsinergmin() {
		return numOsinergmin;
	}

	public void setNumOsinergmin(String numOsinergmin) {
		this.numOsinergmin = numOsinergmin;
	}

	public int getNumReferencianModifica() {
		return numReferencianModifica;
	}

	public void setNumReferencianModifica(int numReferencianModifica) {
		this.numReferencianModifica = numReferencianModifica;
	}

	public String getNumRegistroMtc() {
		return numRegistroMtc;
	}

	public void setNumRegistroMtc(String numRegistroMtc) {
		this.numRegistroMtc = numRegistroMtc;
	}

	public String getNumRegistroAlta() {
		return numRegistroAlta;
	}

	public void setNumRegistroAlta(String numRegistroAlta) {
		this.numRegistroAlta = numRegistroAlta;
	}

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public int getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(int numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public int getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(int numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

}
