package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class ActividadProgramaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	int	codActividad;
	private	String	desActividad;
	private	int	numActividadPrograma;
	private	int	numProgramacion;
	
	public ActividadProgramaBean() {
		super();
	}

	public ActividadProgramaBean(int codActividad, String desActividad, int numActividadPrograma, int numProgramacion) {
		super();
		this.codActividad = codActividad;
		this.desActividad = desActividad;
		this.numActividadPrograma = numActividadPrograma;
		this.numProgramacion = numProgramacion;
	}

	public int getCodActividad() {
		return codActividad;
	}

	public void setCodActividad(int codActividad) {
		this.codActividad = codActividad;
	}

	public String getDesActividad() {
		return desActividad;
	}

	public void setDesActividad(String desActividad) {
		this.desActividad = desActividad;
	}

	public int getNumActividadPrograma() {
		return numActividadPrograma;
	}

	public void setNumActividadPrograma(int numActividadPrograma) {
		this.numActividadPrograma = numActividadPrograma;
	}

	public int getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(int numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}	

}
