package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class ActividadesBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codActividad;
	private	String	desActividad;
	private	String	desDetalleActividad;
	private	String	indServicio;
	private	String	nomActividad;
	private	Integer	numOrden;
	private String codTipoBien;
	
	public ActividadesBean() {
		super();
	}

	public ActividadesBean(String codActividad, String nomActividad){
		this.codActividad = codActividad;
		this.nomActividad = nomActividad;
	}
	
	public ActividadesBean(String codActividad, String nomActividad, String codTipoBien) {
		this.codActividad = codActividad;
		this.nomActividad = nomActividad;
		this.codTipoBien = codTipoBien;
	}


	public ActividadesBean(String codActividad, String desActividad, String desDetalleActividad, String indServicio,
			String nomActividad, Integer numOrden) {
		super();
		this.codActividad = codActividad;
		this.desActividad = desActividad;
		this.desDetalleActividad = desDetalleActividad;
		this.indServicio = indServicio;
		this.nomActividad = nomActividad;
		this.numOrden = numOrden;
	}

	
	public String getCodTipoBien() {
		return codTipoBien;
	}


	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}


	public String getCodActividad() {
		return codActividad;
	}

	public void setCodActividad(String codActividad) {
		this.codActividad = codActividad;
	}

	public String getDesActividad() {
		return desActividad;
	}

	public void setDesActividad(String desActividad) {
		this.desActividad = desActividad;
	}

	public String getDesDetalleActividad() {
		return desDetalleActividad;
	}

	public void setDesDetalleActividad(String desDetalleActividad) {
		this.desDetalleActividad = desDetalleActividad;
	}

	public String getIndServicio() {
		return indServicio;
	}

	public void setIndServicio(String indServicio) {
		this.indServicio = indServicio;
	}

	public String getNomActividad() {
		return nomActividad;
	}

	public void setNomActividad(String nomActividad) {
		this.nomActividad = nomActividad;
	}

	public Integer getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Integer numOrden) {
		this.numOrden = numOrden;
	}

}
