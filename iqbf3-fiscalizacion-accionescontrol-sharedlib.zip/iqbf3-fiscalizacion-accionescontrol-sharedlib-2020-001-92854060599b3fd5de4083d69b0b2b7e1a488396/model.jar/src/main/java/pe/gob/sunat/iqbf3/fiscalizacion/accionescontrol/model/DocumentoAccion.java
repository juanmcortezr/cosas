package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "T10406DOCUMEACCION")
public class DocumentoAccion extends Auditoria {

	 @Column(name = "NUM_PEDIDO")
	 private String numPedido;
	
	 @Column(name = "NUM_ARC")
	 private Long numArc;
	
	 @Id
	 @Column(name = "NUM_DOC_ACCION")
	 private Long numDocumentoAccion;
	
	 @Column(name = "NUM_USU_PROGRAM")
	 private Long numUsuarioPrograma;

	 @Column(name = "IND_ORIGEN")
	 private String indOrigen;
	
	 @Column(name = "ANN_DOC")
	 private Integer annDoc;
		 
	 @Column(name = "NUM_CORREL_DOC")
	 private Integer numCorrelDoc;

	 @Column(name = "COD_UUOO_DOC")
	 private String codUuooDoc;

	 @Column(name = "COD_EST_DOC")
	 private String codEstadoDocumento;
	
	 @Column(name = "COD_TIP_DOC")
	 private String codTipoDocumento;
	
	 @Column(name = "COD_CLASE")
	 private String codClase;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_EMISION")
	 private Date fecEmision;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_NOTIFICACION")
	 private Date fecNotificacion;
	
	 @Column(name = "NUM_DOCUMENTO")
	 private String numDocumento;
	 
	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "fec_fin_subsanacio")
	 private Date fecFinSubsanacion;
	 
	 
	 @Column(name = "num_id_doc")
	 private String numIdDoc;
	 
	 @Column(name = "ind_del")
	 private String indDel;
	 
	 @Column(name = "ind_est")
	 private String indEst;
	 @Transient
	 private Long numProgramacion;//num_programacion
	 
	 @Transient
	 private Integer numPlazoVerif;
	 
	 // PARA FILTROS
	 @Transient
	 private Long numOrden;
	 
	 
	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public Date getFecFinSubsanacion() {
		return fecFinSubsanacion;
	}

	public void setFecFinSubsanacion(Date fecFinSubsanacion) {
		this.fecFinSubsanacion = fecFinSubsanacion;
	}

	public String getNumIdDoc() {
		return numIdDoc;
	}

	public void setNumIdDoc(String numIdDoc) {
		this.numIdDoc = numIdDoc;
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

	public Long getNumArc() {
		return numArc;
	}

	public void setNumArc(Long numArc) {
		this.numArc = numArc;
	}

	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public String getIndOrigen() {
		return indOrigen;
	}

	public void setIndOrigen(String indOrigen) {
		this.indOrigen = indOrigen;
	}

	public Integer getAnnDoc() {
		return annDoc;
	}

	public void setAnnDoc(Integer annDoc) {
		this.annDoc = annDoc;
	}

	public Integer getNumCorrelDoc() {
		return numCorrelDoc;
	}

	public void setNumCorrelDoc(Integer numCorrelDoc) {
		this.numCorrelDoc = numCorrelDoc;
	}

	public String getCodUuooDoc() {
		return codUuooDoc;
	}

	public void setCodUuooDoc(String codUuooDoc) {
		this.codUuooDoc = codUuooDoc;
	}

	public String getCodEstadoDocumento() {
		return codEstadoDocumento;
	}

	public void setCodEstadoDocumento(String codEstadoDocumento) {
		this.codEstadoDocumento = codEstadoDocumento;
	}

	public String getCodTipoDocumento() {
		return codTipoDocumento;
	}

	public void setCodTipoDocumento(String codTipoDocumento) {
		this.codTipoDocumento = codTipoDocumento;
	}

	public String getCodClase() {
		return codClase;
	}

	public void setCodClase(String codClase) {
		this.codClase = codClase;
	}

	public Date getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(Date fecEmision) {
		this.fecEmision = fecEmision;
	}

	public Date getFecNotificacion() {
		return fecNotificacion;
	}

	public void setFecNotificacion(Date fecNotificacion) {
		this.fecNotificacion = fecNotificacion;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public Long getNumDocumentoAccion() {
		return numDocumentoAccion;
	}

	public void setNumDocumentoAccion(Long numDocumentoAccion) {
		this.numDocumentoAccion = numDocumentoAccion;
	}

	public Integer getNumPlazoVerif() {
		return numPlazoVerif;
	}

	public void setNumPlazoVerif(Integer numPlazoVerif) {
		this.numPlazoVerif = numPlazoVerif;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}
}
