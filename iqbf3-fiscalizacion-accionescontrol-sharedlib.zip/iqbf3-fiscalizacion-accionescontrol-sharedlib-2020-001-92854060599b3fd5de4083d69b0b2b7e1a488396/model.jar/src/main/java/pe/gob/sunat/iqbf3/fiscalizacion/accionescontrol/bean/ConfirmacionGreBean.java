package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class ConfirmacionGreBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	int	codConfirmacion;
	private	String	codResultado;
	private	String	codTipo;
	private	int	codCpe;
	private	String	dirLlegada;
	private	String	fecConfirmacion;
	private	String	fecLlegada;
	private	String	numRucConfirmacion;
	private	int	numCpe;
	private	int	numRuc;
	private	int	numSerieCpe;
	private	String	obsConfirmacion;
	
	public ConfirmacionGreBean() {
		super();
	}

	public ConfirmacionGreBean(int codConfirmacion, String codResultado, String codTipo, int codCpe, String dirLlegada,
			String fecConfirmacion, String fecLlegada, String numRucConfirmacion, int numCpe, int numRuc,
			int numSerieCpe, String obsConfirmacion) {
		super();
		this.codConfirmacion = codConfirmacion;
		this.codResultado = codResultado;
		this.codTipo = codTipo;
		this.codCpe = codCpe;
		this.dirLlegada = dirLlegada;
		this.fecConfirmacion = fecConfirmacion;
		this.fecLlegada = fecLlegada;
		this.numRucConfirmacion = numRucConfirmacion;
		this.numCpe = numCpe;
		this.numRuc = numRuc;
		this.numSerieCpe = numSerieCpe;
		this.obsConfirmacion = obsConfirmacion;
	}

	public int getCodConfirmacion() {
		return codConfirmacion;
	}

	public void setCodConfirmacion(int codConfirmacion) {
		this.codConfirmacion = codConfirmacion;
	}

	public String getCodResultado() {
		return codResultado;
	}

	public void setCodResultado(String codResultado) {
		this.codResultado = codResultado;
	}

	public String getCodTipo() {
		return codTipo;
	}

	public void setCodTipo(String codTipo) {
		this.codTipo = codTipo;
	}

	public int getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(int codCpe) {
		this.codCpe = codCpe;
	}

	public String getDirLlegada() {
		return dirLlegada;
	}

	public void setDirLlegada(String dirLlegada) {
		this.dirLlegada = dirLlegada;
	}

	public String getFecConfirmacion() {
		return fecConfirmacion;
	}

	public void setFecConfirmacion(String fecConfirmacion) {
		this.fecConfirmacion = fecConfirmacion;
	}

	public String getFecLlegada() {
		return fecLlegada;
	}

	public void setFecLlegada(String fecLlegada) {
		this.fecLlegada = fecLlegada;
	}

	public String getNumRucConfirmacion() {
		return numRucConfirmacion;
	}

	public void setNumRucConfirmacion(String numRucConfirmacion) {
		this.numRucConfirmacion = numRucConfirmacion;
	}

	public int getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(int numCpe) {
		this.numCpe = numCpe;
	}

	public int getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(int numRuc) {
		this.numRuc = numRuc;
	}

	public int getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(int numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public String getObsConfirmacion() {
		return obsConfirmacion;
	}

	public void setObsConfirmacion(String obsConfirmacion) {
		this.obsConfirmacion = obsConfirmacion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
