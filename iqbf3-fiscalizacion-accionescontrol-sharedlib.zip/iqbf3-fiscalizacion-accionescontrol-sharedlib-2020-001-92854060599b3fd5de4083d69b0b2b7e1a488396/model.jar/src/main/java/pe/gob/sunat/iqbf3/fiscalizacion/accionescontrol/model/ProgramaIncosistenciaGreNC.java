package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10417PROINCOGRENC")
public class ProgramaIncosistenciaGreNC extends Auditoria {

	 @Column(name = "COD_CPE")
	 private String codCpe;
	
	 @Column(name = "FEC_EMISION")
	 private Date fecEmision;
	
	 @Column(name = "NUM_CPE")
	 private Integer numCpe;
	
	 @Id
	 @Column(name = "NUM_INCO_GRE")
	 private Long numIncoGre;
	
	 @Column(name = "NUM_USU_PROGRAM")
	 private Long numUsuarioPrograma;
	 
	 @Column(name = "NUM_RUC")
	 private String numRuc;
	
	 @Column(name = "NUM_SERIE_CPE")
	 private String numSerieCpe;

	 
	 
	public Long getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Long numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public String getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}

	public Date getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(Date fecEmision) {
		this.fecEmision = fecEmision;
	}

	public Integer getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(Integer numCpe) {
		this.numCpe = numCpe;
	}

	public Long getNumIncoGre() {
		return numIncoGre;
	}

	public void setNumIncoGre(Long numIncoGre) {
		this.numIncoGre = numIncoGre;
	}

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public String getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}
	 
}
