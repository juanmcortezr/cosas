package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class CalificacionUsuarioBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private	String	desSusAccsuge;
	private	String	desTipoAccionSugerida;
	private	String	indTipCali;
	private	Long	numAccionSugerida;
	private String 	descAccionSugerida;
	private	Long	numUsuarioCalifiicacion;
	private	Long	numUsuarioSolicitud;
	private	double	valCalificacion;

	// Extras
	private String numSolicitudUnion;
	private String nomSolicitante;
	private String codTipoIntervension;
	private String codTipoAccion;
	private String desTipoIntervencion;
	private String desTipoAccionControl;
	private String codTipoDocumentoIdentif;
	private String numDocumentoIdentif;
	private String nomApellidoUsuario;
	private String desTipoDocumentoIdent;
	private List<AlternativaCriterioBean> alternativasCriterios;
	// Extras

	private AuditoriaBean auditoriaBean;
	
	public CalificacionUsuarioBean() {
		super();
	}

	public CalificacionUsuarioBean( String desSusAccsuge, String desTipoAccionSugerida,
			String indTipCali, Long numAccionSugerida, Long numUsuarioCalifiicacion, Long numUsuarioSolicitud,
			double valCalificacion) {
		super();
		this.desSusAccsuge = desSusAccsuge;
		this.desTipoAccionSugerida = desTipoAccionSugerida;
		this.indTipCali = indTipCali;
		this.numAccionSugerida = numAccionSugerida;
		this.numUsuarioCalifiicacion = numUsuarioCalifiicacion;
		this.numUsuarioSolicitud = numUsuarioSolicitud;
		this.valCalificacion = valCalificacion;
	}

	public String getDesSusAccsuge() {
		return desSusAccsuge;
	}

	public void setDesSusAccsuge(String desSusAccsuge) {
		this.desSusAccsuge = desSusAccsuge;
	}

	public String getDesTipoAccionSugerida() {
		return desTipoAccionSugerida;
	}

	public void setDesTipoAccionSugerida(String desTipoAccionSugerida) {
		this.desTipoAccionSugerida = desTipoAccionSugerida;
	}

	public String getIndTipCali() {
		return indTipCali;
	}

	public void setIndTipCali(String indTipCali) {
		this.indTipCali = indTipCali;
	}

	public Long getNumAccionSugerida() {
		return numAccionSugerida;
	}

	public void setNumAccionSugerida(Long numAccionSugerida) {
		this.numAccionSugerida = numAccionSugerida;
	}

	public Long getNumUsuarioCalifiicacion() {
		return numUsuarioCalifiicacion;
	}

	public void setNumUsuarioCalifiicacion(Long numUsuarioCalifiicacion) {
		this.numUsuarioCalifiicacion = numUsuarioCalifiicacion;
	}

	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public double getValCalificacion() {
		return valCalificacion;
	}

	public void setValCalificacion(double valCalificacion) {
		this.valCalificacion = valCalificacion;
	}

	public String getNumSolicitudUnion() {
		return numSolicitudUnion;
	}

	public void setNumSolicitudUnion(String numSolicitudUnion) {
		this.numSolicitudUnion = numSolicitudUnion;
	}

	public String getNomSolicitante() {
		return nomSolicitante;
	}

	public void setNomSolicitante(String nomSolicitante) {
		this.nomSolicitante = nomSolicitante;
	}

	public String getCodTipoIntervension() {
		return codTipoIntervension;
	}

	public void setCodTipoIntervension(String codTipoIntervension) {
		this.codTipoIntervension = codTipoIntervension;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getDesTipoIntervencion() {
		return desTipoIntervencion;
	}

	public void setDesTipoIntervencion(String desTipoIntervencion) {
		this.desTipoIntervencion = desTipoIntervencion;
	}

	public String getDesTipoAccionControl() {
		return desTipoAccionControl;
	}

	public void setDesTipoAccionControl(String desTipoAccionControl) {
		this.desTipoAccionControl = desTipoAccionControl;
	}

	public String getCodTipoDocumentoIdentif() {
		return codTipoDocumentoIdentif;
	}

	public void setCodTipoDocumentoIdentif(String codTipoDocumentoIdentif) {
		this.codTipoDocumentoIdentif = codTipoDocumentoIdentif;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public String getNomApellidoUsuario() {
		return nomApellidoUsuario;
	}

	public void setNomApellidoUsuario(String nomApellidoUsuario) {
		this.nomApellidoUsuario = nomApellidoUsuario;
	}

	public String getDesTipoDocumentoIdent() {
		return desTipoDocumentoIdent;
	}

	public void setDesTipoDocumentoIdent(String desTipoDocumentoIdent) {
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public List<AlternativaCriterioBean> getAlternativasCriterios() {
		return alternativasCriterios;
	}

	public void setAlternativasCriterios(List<AlternativaCriterioBean> alternativasCriterios) {
		this.alternativasCriterios = alternativasCriterios;
	}

	public String getDescAccionSugerida() {
		return descAccionSugerida;
	}

	public void setDescAccionSugerida(String descAccionSugerida) {
		this.descAccionSugerida = descAccionSugerida;
	}

}
