package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10403DETACALIUSUA")
public class DetalleCalificacionUsuario extends Auditoria{

	@Id
	 @Column(name = "NUM_DET_CALI")
	 private Long numDetalleCalificacion;

	 @Column(name = "VAL_PUNTAJE")
	 private Integer valPuntaje;

	 @Column(name = "NUM_ALTERNATIVA")
	 private Long numAlternativa;
	
	 @Column(name = "NUM_CRITERIO")
	 private Long numCriterio;
	
	 @Column(name = "NUM_USU_CALI")
	 private Long numUsuarioCalifiicacion;
	

	public Long getNumAlternativa() {
		return numAlternativa;
	}

	public void setNumAlternativa(Long numAlternativa) {
		this.numAlternativa = numAlternativa;
	}

	public Long getNumCriterio() {
		return numCriterio;
	}

	public void setNumCriterio(Long numCriterio) {
		this.numCriterio = numCriterio;
	}

	public Long getNumUsuarioCalifiicacion() {
		return numUsuarioCalifiicacion;
	}

	public void setNumUsuarioCalifiicacion(Long numUsuarioCalifiicacion) {
		this.numUsuarioCalifiicacion = numUsuarioCalifiicacion;
	}

	public Long getNumDetalleCalificacion() {
		return numDetalleCalificacion;
	}

	public void setNumDetalleCalificacion(Long numDetalleCalificacion) {
		this.numDetalleCalificacion = numDetalleCalificacion;
	}

	public Integer getValPuntaje() {
		return valPuntaje;
	}

	public void setValPuntaje(Integer valPuntaje) {
		this.valPuntaje = valPuntaje;
	}
	 
	 
}
