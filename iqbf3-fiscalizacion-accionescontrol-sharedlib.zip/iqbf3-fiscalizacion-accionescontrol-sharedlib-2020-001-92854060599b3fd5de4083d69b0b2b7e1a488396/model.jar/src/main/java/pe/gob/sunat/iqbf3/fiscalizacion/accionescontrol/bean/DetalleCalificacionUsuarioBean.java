package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class DetalleCalificacionUsuarioBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	int	numDetalleCalificacion;
	private	int	numAlternativa;
	private	int	numCriterio;
	private	int	numUsuarioCalifiicacion;
	private	int	valPuntaje;
	
	public DetalleCalificacionUsuarioBean() {
		super();
	}

	public DetalleCalificacionUsuarioBean(int numDetalleCalificacion, int numAlternativa, int numCriterio,
			int numUsuarioCalifiicacion, int valPuntaje) {
		super();
		this.numDetalleCalificacion = numDetalleCalificacion;
		this.numAlternativa = numAlternativa;
		this.numCriterio = numCriterio;
		this.numUsuarioCalifiicacion = numUsuarioCalifiicacion;
		this.valPuntaje = valPuntaje;
	}

	public int getNumDetalleCalificacion() {
		return numDetalleCalificacion;
	}

	public void setNumDetalleCalificacion(int numDetalleCalificacion) {
		this.numDetalleCalificacion = numDetalleCalificacion;
	}

	public int getNumAlternativa() {
		return numAlternativa;
	}

	public void setNumAlternativa(int numAlternativa) {
		this.numAlternativa = numAlternativa;
	}

	public int getNumCriterio() {
		return numCriterio;
	}

	public void setNumCriterio(int numCriterio) {
		this.numCriterio = numCriterio;
	}

	public int getNumUsuarioCalifiicacion() {
		return numUsuarioCalifiicacion;
	}

	public void setNumUsuarioCalifiicacion(int numUsuarioCalifiicacion) {
		this.numUsuarioCalifiicacion = numUsuarioCalifiicacion;
	}

	public int getValPuntaje() {
		return valPuntaje;
	}

	public void setValPuntaje(int valPuntaje) {
		this.valPuntaje = valPuntaje;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
