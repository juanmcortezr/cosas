package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class AsignaSolicitudBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codProgramador;
	private	String	fecFinAsignacion;
	private	String	fecInicioAsignacion;
	private	String	nomProgramador;
	private	int	numAsignacionSolic;
	private	int	numSolicitud;
	
	public AsignaSolicitudBean() {
		super();
	}

	public AsignaSolicitudBean(String codProgramador, String fecFinAsignacion, String fecInicioAsignacion,
			String nomProgramador, int numAsignacionSolic, int numSolicitud) {
		super();
		this.codProgramador = codProgramador;
		this.fecFinAsignacion = fecFinAsignacion;
		this.fecInicioAsignacion = fecInicioAsignacion;
		this.nomProgramador = nomProgramador;
		this.numAsignacionSolic = numAsignacionSolic;
		this.numSolicitud = numSolicitud;
	}

	public String getCodProgramador() {
		return codProgramador;
	}

	public void setCodProgramador(String codProgramador) {
		this.codProgramador = codProgramador;
	}

	public String getFecFinAsignacion() {
		return fecFinAsignacion;
	}

	public void setFecFinAsignacion(String fecFinAsignacion) {
		this.fecFinAsignacion = fecFinAsignacion;
	}

	public String getFecInicioAsignacion() {
		return fecInicioAsignacion;
	}

	public void setFecInicioAsignacion(String fecInicioAsignacion) {
		this.fecInicioAsignacion = fecInicioAsignacion;
	}

	public String getNomProgramador() {
		return nomProgramador;
	}

	public void setNomProgramador(String nomProgramador) {
		this.nomProgramador = nomProgramador;
	}

	public int getNumAsignacionSolic() {
		return numAsignacionSolic;
	}

	public void setNumAsignacionSolic(int numAsignacionSolic) {
		this.numAsignacionSolic = numAsignacionSolic;
	}

	public int getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(int numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
