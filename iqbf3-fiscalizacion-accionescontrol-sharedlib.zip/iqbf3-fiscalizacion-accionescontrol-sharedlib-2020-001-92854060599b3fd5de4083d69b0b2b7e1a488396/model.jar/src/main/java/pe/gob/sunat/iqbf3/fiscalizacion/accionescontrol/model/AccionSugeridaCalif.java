package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "T10444ACCSUGECALIF")
public class AccionSugeridaCalif extends Auditoria{

	 @Id
	 @Column(name = "NUM_ACC_SUGERIDA")
	 private Long numAccionSugerida;
	 
 	 @Column(name = "DES_ACC_SUGERIDA")
	 private String desAccionSugerida;

	@Column(name = "VAL_MAXIMO")
	private BigDecimal valMaximo;
	
	@Column(name = "VAL_MINIMO")
	private BigDecimal valMinimo;

	@Column(name = "IND_EST_ACCSUGE")
	private String indEstadoAccionSugerida;

	@Transient
	private String strValMaximo;

	@Transient
	private String strValMinimo;

	public String getStrValMaximo() {
		return strValMaximo;
	}

	public void setStrValMaximo(String strValMaximo) {
		this.strValMaximo = strValMaximo;
	}

	public String getStrValMinimo() {
		return strValMinimo;
	}

	public void setStrValMinimo(String strValMinimo) {
		this.strValMinimo = strValMinimo;
	}

	public String getDesAccionSugerida() {
		return desAccionSugerida;
	}

	public void setDesAccionSugerida(String desAccionSugerida) {
		this.desAccionSugerida = desAccionSugerida;
	}

	public String getIndEstadoAccionSugerida() {
		return indEstadoAccionSugerida;
	}

	public void setIndEstadoAccionSugerida(String indEstadoAccionSugerida) {
		this.indEstadoAccionSugerida = indEstadoAccionSugerida;
	}

	public Long getNumAccionSugerida() {
		return numAccionSugerida;
	}

	public void setNumAccionSugerida(Long numAccionSugerida) {
		this.numAccionSugerida = numAccionSugerida;
	}
	
	public BigDecimal getValMaximo() {
		return valMaximo;
	}

	public void setValMaximo(BigDecimal valMaximo) {
		this.valMaximo = valMaximo;
	}

	public BigDecimal getValMinimo() {
		return valMinimo;
	}

	public void setValMinimo(BigDecimal valMinimo) {
		this.valMinimo = valMinimo;
	}
}
