package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class ProgramaIncosistenciaGreNCBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codCpe;
	private String desCpe;
	private String fecEmision;
	private int numCpe;
	private int numIncoGre;
	private String numRuc;
	private String numSerieCpe;
	private int numProgramacion;

	public ProgramaIncosistenciaGreNCBean() {
		super();
	}

	public ProgramaIncosistenciaGreNCBean(String codCpe, String desCpe, String fecEmision, int numCpe, int numIncoGre,
			String numRuc, String numSerieCpe, int numProgramacion) {
		super();
		this.codCpe = codCpe;
		this.desCpe = desCpe;
		this.fecEmision = fecEmision;
		this.numCpe = numCpe;
		this.numIncoGre = numIncoGre;
		this.numRuc = numRuc;
		this.numSerieCpe = numSerieCpe;
		this.numProgramacion = numProgramacion;
	}

	public String getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(String codCpe) {
		this.codCpe = codCpe;
	}

	public String getDesCpe() {
		return desCpe;
	}

	public void setDesCpe(String desCpe) {
		this.desCpe = desCpe;
	}

	public String getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(String fecEmision) {
		this.fecEmision = fecEmision;
	}

	public int getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(int numCpe) {
		this.numCpe = numCpe;
	}

	public int getNumIncoGre() {
		return numIncoGre;
	}

	public void setNumIncoGre(int numIncoGre) {
		this.numIncoGre = numIncoGre;
	}

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public String getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(String numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public int getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(int numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

}
