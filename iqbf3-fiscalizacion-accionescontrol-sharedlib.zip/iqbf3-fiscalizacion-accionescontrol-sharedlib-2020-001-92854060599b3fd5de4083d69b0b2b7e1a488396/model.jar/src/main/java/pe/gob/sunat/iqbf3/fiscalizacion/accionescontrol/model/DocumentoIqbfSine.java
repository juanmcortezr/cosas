package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T9917DOCIQBFSINE")
public class DocumentoIqbfSine implements Entidad{

	@Id
	 @Column(name = "NUM_ID_DOC")
	 private Long numIdDoc;
	
	 @Column(name = "NUM_SINE")
	 private String numSine;
	
	 @Column(name = "IND_ESTADO_DOC")
	 private String indEstadoDoc;
	
	 @Column(name = "FEC_REAL_NOTIF")
	 private Date fecRealNotif;
	
	 @Column(name = "FEC_REAL_LECT")
	 private Date fecRealLect;
	
	 @Column(name = "COD_USUREGIS")
	 private String codUsuregis;
	
	 @Column(name = "COD_USUMODIF")
	 private String codUsumodif;
	
	 @Column(name = "FEC_MODIF")
	 private Date fecModif;
	
	 @Column(name = "NUM_PEDIDO")
	 private String numPedido;
	
	 @Column(name = "COD_TIPDOCUMENTO")
	 private String codTipdocumento;
	
	 @Column(name = "NUM_DOC")
	 private String numDoc;
	
	 @Column(name = "FEC_PUBLICA")
	 private Date fecPublica;
	
	 @Column(name = "IND_FECPUBLICA")
	 private String indFecpublica;

	public Long getNumIdDoc() {
		return numIdDoc;
	}

	public void setNumIdDoc(Long numIdDoc) {
		this.numIdDoc = numIdDoc;
	}

	public String getNumSine() {
		return numSine;
	}

	public void setNumSine(String numSine) {
		this.numSine = numSine;
	}

	public String getIndEstadoDoc() {
		return indEstadoDoc;
	}

	public void setIndEstadoDoc(String indEstadoDoc) {
		this.indEstadoDoc = indEstadoDoc;
	}

	public Date getFecRealNotif() {
		return fecRealNotif;
	}

	public void setFecRealNotif(Date fecRealNotif) {
		this.fecRealNotif = fecRealNotif;
	}

	public Date getFecRealLect() {
		return fecRealLect;
	}

	public void setFecRealLect(Date fecRealLect) {
		this.fecRealLect = fecRealLect;
	}

	public String getCodUsuregis() {
		return codUsuregis;
	}

	public void setCodUsuregis(String codUsuregis) {
		this.codUsuregis = codUsuregis;
	}

	public String getCodUsumodif() {
		return codUsumodif;
	}

	public void setCodUsumodif(String codUsumodif) {
		this.codUsumodif = codUsumodif;
	}

	public Date getFecModif() {
		return fecModif;
	}

	public void setFecModif(Date fecModif) {
		this.fecModif = fecModif;
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

	public String getCodTipdocumento() {
		return codTipdocumento;
	}

	public void setCodTipdocumento(String codTipdocumento) {
		this.codTipdocumento = codTipdocumento;
	}

	public String getNumDoc() {
		return numDoc;
	}

	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}

	public Date getFecPublica() {
		return fecPublica;
	}

	public void setFecPublica(Date fecPublica) {
		this.fecPublica = fecPublica;
	}

	public String getIndFecpublica() {
		return indFecpublica;
	}

	public void setIndFecpublica(String indFecpublica) {
		this.indFecpublica = indFecpublica;
	}
	

	
}
