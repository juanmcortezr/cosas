package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class BienProgramacionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codBien;
	private	String	codTipoBien;
	private	String	desBien;
	private	int	numBienPrograma;
	private	int	numProgramacion;
	
	public BienProgramacionBean() {
		super();
	}

	public BienProgramacionBean(String codBien, String codTipoBien, String desBien, int numBienPrograma,
			int numProgramacion) {
		super();
		this.codBien = codBien;
		this.codTipoBien = codTipoBien;
		this.desBien = desBien;
		this.numBienPrograma = numBienPrograma;
		this.numProgramacion = numProgramacion;
	}

	public String getCodBien() {
		return codBien;
	}

	public void setCodBien(String codBien) {
		this.codBien = codBien;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getDesBien() {
		return desBien;
	}

	public void setDesBien(String desBien) {
		this.desBien = desBien;
	}

	public int getNumBienPrograma() {
		return numBienPrograma;
	}

	public void setNumBienPrograma(int numBienPrograma) {
		this.numBienPrograma = numBienPrograma;
	}

	public int getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(int numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
