package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class DocumentoRelacionadoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codDocumentoRelacionado;
	private	String	codRelacion;
	private	int	codCpe;
	private	String	numDocumentoRelacionado;
	private	String	numRucRelacionado;
	private	String	numSerieDocumentoRelacionado;
	private	int	numCpe;
	private	int	numRuc;
	private	int	numSerieCpe;
	
	public DocumentoRelacionadoBean() {
		super();
	}

	public DocumentoRelacionadoBean(String codDocumentoRelacionado, String codRelacion, int codCpe,
			String numDocumentoRelacionado, String numRucRelacionado, String numSerieDocumentoRelacionado, int numCpe,
			int numRuc, int numSerieCpe) {
		super();
		this.codDocumentoRelacionado = codDocumentoRelacionado;
		this.codRelacion = codRelacion;
		this.codCpe = codCpe;
		this.numDocumentoRelacionado = numDocumentoRelacionado;
		this.numRucRelacionado = numRucRelacionado;
		this.numSerieDocumentoRelacionado = numSerieDocumentoRelacionado;
		this.numCpe = numCpe;
		this.numRuc = numRuc;
		this.numSerieCpe = numSerieCpe;
	}

	public String getCodDocumentoRelacionado() {
		return codDocumentoRelacionado;
	}

	public void setCodDocumentoRelacionado(String codDocumentoRelacionado) {
		this.codDocumentoRelacionado = codDocumentoRelacionado;
	}

	public String getCodRelacion() {
		return codRelacion;
	}

	public void setCodRelacion(String codRelacion) {
		this.codRelacion = codRelacion;
	}

	public int getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(int codCpe) {
		this.codCpe = codCpe;
	}

	public String getNumDocumentoRelacionado() {
		return numDocumentoRelacionado;
	}

	public void setNumDocumentoRelacionado(String numDocumentoRelacionado) {
		this.numDocumentoRelacionado = numDocumentoRelacionado;
	}

	public String getNumRucRelacionado() {
		return numRucRelacionado;
	}

	public void setNumRucRelacionado(String numRucRelacionado) {
		this.numRucRelacionado = numRucRelacionado;
	}

	public String getNumSerieDocumentoRelacionado() {
		return numSerieDocumentoRelacionado;
	}

	public void setNumSerieDocumentoRelacionado(String numSerieDocumentoRelacionado) {
		this.numSerieDocumentoRelacionado = numSerieDocumentoRelacionado;
	}

	public int getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(int numCpe) {
		this.numCpe = numCpe;
	}

	public int getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(int numRuc) {
		this.numRuc = numRuc;
	}

	public int getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(int numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
