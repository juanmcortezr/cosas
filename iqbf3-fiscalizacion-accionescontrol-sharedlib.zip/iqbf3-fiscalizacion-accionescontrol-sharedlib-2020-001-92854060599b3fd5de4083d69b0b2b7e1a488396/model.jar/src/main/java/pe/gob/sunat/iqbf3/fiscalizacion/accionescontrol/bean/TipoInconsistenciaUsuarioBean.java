package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class TipoInconsistenciaUsuarioBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String codTipoInconsistencia;
	private String desOtraInconsistencia;
	private String desTipoInconsistencia;
	private int numInconsistenciaUsuario;
	private int numUsuarioSolicitud;

	public TipoInconsistenciaUsuarioBean() {
		super();
	}

	public TipoInconsistenciaUsuarioBean(String codTipoInconsistencia, String desOtraInconsistencia,
			String desTipoInconsistencia, int numInconsistenciaUsuario, int numUsuarioSolicitud) {
		super();
		this.codTipoInconsistencia = codTipoInconsistencia;
		this.desOtraInconsistencia = desOtraInconsistencia;
		this.desTipoInconsistencia = desTipoInconsistencia;
		this.numInconsistenciaUsuario = numInconsistenciaUsuario;
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public String getCodTipoInconsistencia() {
		return codTipoInconsistencia;
	}

	public void setCodTipoInconsistencia(String codTipoInconsistencia) {
		this.codTipoInconsistencia = codTipoInconsistencia;
	}

	public String getDesOtraInconsistencia() {
		return desOtraInconsistencia;
	}

	public void setDesOtraInconsistencia(String desOtraInconsistencia) {
		this.desOtraInconsistencia = desOtraInconsistencia;
	}

	public String getDesTipoInconsistencia() {
		return desTipoInconsistencia;
	}

	public void setDesTipoInconsistencia(String desTipoInconsistencia) {
		this.desTipoInconsistencia = desTipoInconsistencia;
	}

	public int getNumInconsistenciaUsuario() {
		return numInconsistenciaUsuario;
	}

	public void setNumInconsistenciaUsuario(int numInconsistenciaUsuario) {
		this.numInconsistenciaUsuario = numInconsistenciaUsuario;
	}

	public int getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(int numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

}
