package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CORREOS")
public class Correos extends Auditoria {

	 @Column(name = "ALIAS")
	 private String alias;
	 
	 @Id
	 @Column(name = "CODPERS")
	 private String codpers;
	 
	 @Column(name = "SMTP")
	 private String smtp;

	 
	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getCodpers() {
		return codpers;
	}

	public void setCodpers(String codpers) {
		this.codpers = codpers;
	}

	public String getSmtp() {
		return smtp;
	}

	public void setSmtp(String smtp) {
		this.smtp = smtp;
	}

}
