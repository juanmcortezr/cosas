package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class PerfilRiesgosBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	int	codCic;
	private	int	codPervagg;
	private	int	codTipoDocumentoIdent;
	private	String	fecCalculo;
	private	String	fecFinVigencia;
	private	String	fecInicioVigencia;
	private	String	indCalculo;
	private	int	indNivrie;
	private	String	numDocumentoIdentif;
	private	int	numScoreglobal;
	
	public PerfilRiesgosBean() {
		super();
	}

	public PerfilRiesgosBean(int codCic, int codPervagg, int codTipoDocumentoIdent, String fecCalculo,
			String fecFinVigencia, String fecInicioVigencia, String indCalculo, int indNivrie,
			String numDocumentoIdentif, int numScoreglobal) {
		super();
		this.codCic = codCic;
		this.codPervagg = codPervagg;
		this.codTipoDocumentoIdent = codTipoDocumentoIdent;
		this.fecCalculo = fecCalculo;
		this.fecFinVigencia = fecFinVigencia;
		this.fecInicioVigencia = fecInicioVigencia;
		this.indCalculo = indCalculo;
		this.indNivrie = indNivrie;
		this.numDocumentoIdentif = numDocumentoIdentif;
		this.numScoreglobal = numScoreglobal;
	}

	public int getCodCic() {
		return codCic;
	}

	public void setCodCic(int codCic) {
		this.codCic = codCic;
	}

	public int getCodPervagg() {
		return codPervagg;
	}

	public void setCodPervagg(int codPervagg) {
		this.codPervagg = codPervagg;
	}

	public int getCodTipoDocumentoIdent() {
		return codTipoDocumentoIdent;
	}

	public void setCodTipoDocumentoIdent(int codTipoDocumentoIdent) {
		this.codTipoDocumentoIdent = codTipoDocumentoIdent;
	}

	public String getFecCalculo() {
		return fecCalculo;
	}

	public void setFecCalculo(String fecCalculo) {
		this.fecCalculo = fecCalculo;
	}

	public String getFecFinVigencia() {
		return fecFinVigencia;
	}

	public void setFecFinVigencia(String fecFinVigencia) {
		this.fecFinVigencia = fecFinVigencia;
	}

	public String getFecInicioVigencia() {
		return fecInicioVigencia;
	}

	public void setFecInicioVigencia(String fecInicioVigencia) {
		this.fecInicioVigencia = fecInicioVigencia;
	}

	public String getIndCalculo() {
		return indCalculo;
	}

	public void setIndCalculo(String indCalculo) {
		this.indCalculo = indCalculo;
	}

	public int getIndNivrie() {
		return indNivrie;
	}

	public void setIndNivrie(int indNivrie) {
		this.indNivrie = indNivrie;
	}

	public String getNumDocumentoIdentif() {
		return numDocumentoIdentif;
	}

	public void setNumDocumentoIdentif(String numDocumentoIdentif) {
		this.numDocumentoIdentif = numDocumentoIdentif;
	}

	public int getNumScoreglobal() {
		return numScoreglobal;
	}

	public void setNumScoreglobal(int numScoreglobal) {
		this.numScoreglobal = numScoreglobal;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
