package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class DocumentoOperacionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codTipoDocumentoOperacion;
	private	String	desTipoDocumentoOperacion;
	private	int	numDocumentoOperacion;
	private	String	numDocumentoComercial;
	private	int	numOrden;
	private AuditoriaBean auditoriaBean;
	private String indDel;
	private String indEst;
	
	
	public DocumentoOperacionBean() {
		super();
	}

	public DocumentoOperacionBean(String codTipoDocumentoOperacion, String desTipoDocumentoOperacion,
			int numDocumentoOperacion, String numDocumentoComercial, int numOrden) {
		super();
		this.codTipoDocumentoOperacion = codTipoDocumentoOperacion;
		this.desTipoDocumentoOperacion = desTipoDocumentoOperacion;
		this.numDocumentoOperacion = numDocumentoOperacion;
		this.numDocumentoComercial = numDocumentoComercial;
		this.numOrden = numOrden;
	}

	public String getCodTipoDocumentoOperacion() {
		return codTipoDocumentoOperacion;
	}

	public void setCodTipoDocumentoOperacion(String codTipoDocumentoOperacion) {
		this.codTipoDocumentoOperacion = codTipoDocumentoOperacion;
	}

	public String getDesTipoDocumentoOperacion() {
		return desTipoDocumentoOperacion;
	}

	public void setDesTipoDocumentoOperacion(String desTipoDocumentoOperacion) {
		this.desTipoDocumentoOperacion = desTipoDocumentoOperacion;
	}

	public int getNumDocumentoOperacion() {
		return numDocumentoOperacion;
	}

	public void setNumDocumentoOperacion(int numDocumentoOperacion) {
		this.numDocumentoOperacion = numDocumentoOperacion;
	}

	public String getNumDocumentoComercial() {
		return numDocumentoComercial;
	}

	public void setNumDocumentoComercial(String numDocumentoComercial) {
		this.numDocumentoComercial = numDocumentoComercial;
	}

	public int getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(int numOrden) {
		this.numOrden = numOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}
	
	
}
