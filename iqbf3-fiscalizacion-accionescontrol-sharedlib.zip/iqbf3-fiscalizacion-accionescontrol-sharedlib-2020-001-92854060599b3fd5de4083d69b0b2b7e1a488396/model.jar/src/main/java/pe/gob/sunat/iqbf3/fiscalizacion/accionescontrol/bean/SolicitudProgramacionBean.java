package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;
import java.util.List;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;

public class SolicitudProgramacionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	int	anioSolicitud;
	private	ArchivoBean	archivoBean;
	private	String	codEstadoSolicitud;
	private	String	codSolicitante;
	private	String	codTipoDocumentoReferencia;
	private	String	codUnidadOrganica;
	private	String	desMotivoAsignacion;
	private	String	desOtroSolicitante;
	private	String	desSusSolicitud;
	private	String	desEstadoSolicitud;
	private	String	desTipoDocumentoIdenti;
	private	String	desTipoAccionControl;
	private	String	desTipoDocumentoIdent;
	private	String	desTipoDocumentoRef;
	private	String	desTipoIntervencion;
	private	String	desUnidadOrganica;
	private	String	fecGeneracion;
	private	String	indOtroSolicitan;
	private	String	nomProgramador;
	private	String	nomSolicitante;
	private	String	nomSupervisor;
	private	Integer	numCorrel;
	private	String	numDocumentoReferencia;
	private	Long	numSolicitud;
	private	String	obsSolicitud;
	private	String	perFin;
	private	String	perInicio;
	private Double calificacionPreliminar;
	private Double calificacionDefinitiva;
	
	//Ini extra
	private String numSolicitudUnion;
	private	String codTipDocIdent;
	private	String numDocIdent;
	private	String codTipoIntervension;
	private String DesTipoIntervension;
	private	String codTipoAccion;
	private String indcalipreliminar ;
	private String indcalidefinitiva ;
	private Double numMedProbausu;
	private String fechaDesde;
	private String fechaHasta;
	private String calificacionDesde ;
	private String calificacionHasta;
	private String desOtraInconsistencia;
	private String desOtraTipoBien;
	private String codPers;
	private int valCalificacion;
	private List<DataCatalogoBean> inconsistencias;
	private List<DataCatalogoBean> tipoBienes;
	private List<BienFiscalizadoSolicitudBean> bienesFiscalizados;
	private List<UsuarioSolicitudBean> usuarios;
	private String codTipoBien;
	private String codProgramador;
	private String razonSocial;

	private String codTipoDocUsuario;
	private String numDocUsuario;
	private AuditoriaBean auditoriaBean;
	private String fecEstadoActual;
	//Fin extra

	private boolean esSupervisorSolicitante;
	private boolean esSupervisorProgramador;

	private List<AsignaProgramacionBean> listaHistoriaAsignaciones;

	private List<ProgramacionBean> listaProgramador;

	public SolicitudProgramacionBean() {
		super();
	}

	public SolicitudProgramacionBean(int anioSolicitud, ArchivoBean archivoBean, String codEstadoSolicitud,
			String codSolicitante, String codTipoDocumentoReferencia, String codUnidadOrganica,
			String desMotivoAsignacion, String desOtroSolicitante, String desSusSolicitud, String desEstadoSolicitud,
			String desTipoDocumentoIdenti, String desTipoAccionControl, String desTipoDocumentoIdent,
			String desTipoDocumentoRef, String desTipoIntervencion, String desUnidadOrganica, String fecGeneracion,
			String indOtroSolicitan, String nomProgramador, String nomSolicitante, String nomSupervisor, int numCorrel,
			String numDocumentoReferencia, String codPers, Long numSolicitud, String obsSolicitud, String perFin, String perInicio,
			String indcalipreliminar, String indcalidefinitiva, Double numMedProbausu, String fechaDesde, String fechaHasta,
			String calificacionDesde, String calificacionHasta, String DesTipoIntervension, int valCalificacion,
			String numDocIdent){
		super();
		this.anioSolicitud = anioSolicitud;
		this.archivoBean = archivoBean;
		this.codEstadoSolicitud = codEstadoSolicitud;
		this.codSolicitante = codSolicitante;
		this.codTipoDocumentoReferencia = codTipoDocumentoReferencia;
		this.codUnidadOrganica = codUnidadOrganica;
		this.desMotivoAsignacion = desMotivoAsignacion;
		this.desOtroSolicitante = desOtroSolicitante;
		this.desSusSolicitud = desSusSolicitud;
		this.desEstadoSolicitud = desEstadoSolicitud;
		this.desTipoDocumentoIdenti = desTipoDocumentoIdenti;
		this.desTipoAccionControl = desTipoAccionControl;
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
		this.desTipoDocumentoRef = desTipoDocumentoRef;
		this.desTipoIntervencion = desTipoIntervencion;
		this.desUnidadOrganica = desUnidadOrganica;
		this.fecGeneracion = fecGeneracion;
		this.indOtroSolicitan = indOtroSolicitan;
		this.nomProgramador = nomProgramador;
		this.nomSolicitante = nomSolicitante;
		this.nomSupervisor = nomSupervisor;
		this.numCorrel = numCorrel;
		this.numDocumentoReferencia = numDocumentoReferencia;
		this.numSolicitud = numSolicitud;
		this.obsSolicitud = obsSolicitud;
		this.perFin = perFin;
		this.perInicio = perInicio;
		this.indcalipreliminar = indcalipreliminar;
		this.indcalidefinitiva = indcalipreliminar;
		this.numMedProbausu = numMedProbausu;
		this.fechaDesde = fechaDesde;
		this.fechaHasta = fechaHasta;
		this.calificacionDesde = calificacionDesde;
		this.calificacionHasta = calificacionHasta;
		this.codPers = codPers;
		this.DesTipoIntervension = DesTipoIntervension;
		this.valCalificacion = valCalificacion;
		this.numDocIdent = numDocIdent;
	}

	
	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public int getAnioSolicitud() {
		return anioSolicitud;
	}

	public void setAnioSolicitud(int anioSolicitud) {
		this.anioSolicitud = anioSolicitud;
	}

	public ArchivoBean getArchivoBean() {
		return archivoBean;
	}

	public void setArchivoBean(ArchivoBean archivoBean) {
		this.archivoBean = archivoBean;
	}

	public String getCodEstadoSolicitud() {
		return codEstadoSolicitud;
	}

	public void setCodEstadoSolicitud(String codEstadoSolicitud) {
		this.codEstadoSolicitud = codEstadoSolicitud;
	}

	public String getCodSolicitante() {
		return codSolicitante;
	}

	public void setCodSolicitante(String codSolicitante) {
		this.codSolicitante = codSolicitante;
	}

	public String getCodTipoDocumentoReferencia() {
		return codTipoDocumentoReferencia;
	}

	public void setCodTipoDocumentoReferencia(String codTipoDocumentoReferencia) {
		this.codTipoDocumentoReferencia = codTipoDocumentoReferencia;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public String getDesMotivoAsignacion() {
		return desMotivoAsignacion;
	}

	public void setDesMotivoAsignacion(String desMotivoAsignacion) {
		this.desMotivoAsignacion = desMotivoAsignacion;
	}

	public String getDesOtroSolicitante() {
		return desOtroSolicitante;
	}

	public void setDesOtroSolicitante(String desOtroSolicitante) {
		this.desOtroSolicitante = desOtroSolicitante;
	}

	public String getDesSusSolicitud() {
		return desSusSolicitud;
	}

	public void setDesSusSolicitud(String desSusSolicitud) {
		this.desSusSolicitud = desSusSolicitud;
	}

	public String getDesEstadoSolicitud() {
		return desEstadoSolicitud;
	}

	public void setDesEstadoSolicitud(String desEstadoSolicitud) {
		this.desEstadoSolicitud = desEstadoSolicitud;
	}

	public String getDesTipoDocumentoIdenti() {
		return desTipoDocumentoIdenti;
	}

	public void setDesTipoDocumentoIdenti(String desTipoDocumentoIdenti) {
		this.desTipoDocumentoIdenti = desTipoDocumentoIdenti;
	}

	public String getDesTipoAccionControl() {
		return desTipoAccionControl;
	}

	public void setDesTipoAccionControl(String desTipoAccionControl) {
		this.desTipoAccionControl = desTipoAccionControl;
	}

	public String getDesTipoDocumentoIdent() {
		return desTipoDocumentoIdent;
	}

	public void setDesTipoDocumentoIdent(String desTipoDocumentoIdent) {
		this.desTipoDocumentoIdent = desTipoDocumentoIdent;
	}

	public String getDesTipoDocumentoRef() {
		return desTipoDocumentoRef;
	}

	public void setDesTipoDocumentoRef(String desTipoDocumentoRef) {
		this.desTipoDocumentoRef = desTipoDocumentoRef;
	}

	public String getDesTipoIntervencion() {
		return desTipoIntervencion;
	}

	public void setDesTipoIntervencion(String desTipoIntervencion) {
		this.desTipoIntervencion = desTipoIntervencion;
	}

	public String getDesUnidadOrganica() {
		return desUnidadOrganica;
	}

	public void setDesUnidadOrganica(String desUnidadOrganica) {
		this.desUnidadOrganica = desUnidadOrganica;
	}

	public String getFecGeneracion() {
		return fecGeneracion;
	}

	public void setFecGeneracion(String fecGeneracion) {
		this.fecGeneracion = fecGeneracion;
	}

	public String getIndOtroSolicitan() {
		return indOtroSolicitan;
	}

	public void setIndOtroSolicitan(String indOtroSolicitan) {
		this.indOtroSolicitan = indOtroSolicitan;
	}

	public String getNomProgramador() {
		return nomProgramador;
	}

	public void setNomProgramador(String nomProgramador) {
		this.nomProgramador = nomProgramador;
	}

	public String getNomSolicitante() {
		return nomSolicitante;
	}

	public void setNomSolicitante(String nomSolicitante) {
		this.nomSolicitante = nomSolicitante;
	}

	public String getNomSupervisor() {
		return nomSupervisor;
	}

	public void setNomSupervisor(String nomSupervisor) {
		this.nomSupervisor = nomSupervisor;
	}

	public Integer getNumCorrel() {
		return numCorrel;
	}

	public void setNumCorrel(Integer numCorrel) {
		this.numCorrel = numCorrel;
	}

	public String getNumDocumentoReferencia() {
		return numDocumentoReferencia;
	}

	public void setNumDocumentoReferencia(String numDocumentoReferencia) {
		this.numDocumentoReferencia = numDocumentoReferencia;
	}

	public Long getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Long numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public String getObsSolicitud() {
		return obsSolicitud;
	}

	public void setObsSolicitud(String obsSolicitud) {
		this.obsSolicitud = obsSolicitud;
	}

	public String getPerFin() {
		return perFin;
	}

	public void setPerFin(String perFin) {
		this.perFin = perFin;
	}

	public String getPerInicio() {
		return perInicio;
	}

	public void setPerInicio(String perInicio) {
		this.perInicio = perInicio;
	}

	public Double getCalificacionPreliminar() {
		return calificacionPreliminar;
	}

	public void setCalificacionPreliminar(Double calificacionPreliminar) {
		this.calificacionPreliminar = calificacionPreliminar;
	}

	public Double getCalificacionDefinitiva() {
		return calificacionDefinitiva;
	}

	public void setCalificacionDefinitiva(Double calificacionDefinitiva) {
		this.calificacionDefinitiva = calificacionDefinitiva;
	}

	public String getNumSolicitudUnion() {
		return this.numSolicitudUnion;
	}

	public void setNumSolicitudUnion(String numSolicitudUnion) {
		this.numSolicitudUnion = numSolicitudUnion;
	}

	public String getNumDocIdent() {
		return numDocIdent;
	}

	public void setNumDocIdent(String numDocIdent) {
		this.numDocIdent = numDocIdent;
	}

	public String getCodTipoIntervension() {
		return codTipoIntervension;
	}

	public void setCodTipoIntervension(String codTipoIntervension) {
		this.codTipoIntervension = codTipoIntervension;
	}

	public String getDesTipoIntervension() {
		return DesTipoIntervension;
	}

	public void setDesTipoIntervension(String desTipoIntervension) {
		DesTipoIntervension = desTipoIntervension;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public String getIndcalipreliminar() {
		return indcalipreliminar;
	}

	public void setIndcalipreliminar(String indcalipreliminar) {
		this.indcalipreliminar = indcalipreliminar;
	}

	public String getIndcalidefinitiva() {
		return indcalidefinitiva;
	}

	public void setIndcalidefinitiva(String indcalidefinitiva) {
		this.indcalidefinitiva = indcalidefinitiva;
	}

	public Double getNumMedProbausu() {
		return numMedProbausu;
	}

	public void setNumMedProbausu(Double numMedProbausu) {
		this.numMedProbausu = numMedProbausu;
	}

	public String getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(String fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public String getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(String fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public String getCalificacionDesde() {
		return calificacionDesde;
	}

	public void setCalificacionDesde(String calificacionDesde) {
		this.calificacionDesde = calificacionDesde;
	}

	public String getCalificacionHasta() {
		return calificacionHasta;
	}

	public void setCalificacionHasta(String calificacionHasta) {
		this.calificacionHasta = calificacionHasta;
	}

	public String getDesOtraInconsistencia() {
		return desOtraInconsistencia;
	}

	public void setDesOtraInconsistencia(String desOtraInconsistencia) {
		this.desOtraInconsistencia = desOtraInconsistencia;
	}

	public String getDesOtraTipoBien() {
		return desOtraTipoBien;
	}

	public void setDesOtraTipoBien(String desOtraTipoBien) {
		this.desOtraTipoBien = desOtraTipoBien;
	}

	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public int getValCalificacion() {
		return valCalificacion;
	}

	public void setValCalificacion(int valCalificacion) {
		this.valCalificacion = valCalificacion;
	}

	public List<DataCatalogoBean> getInconsistencias() {
		return inconsistencias;
	}

	public void setInconsistencias(List<DataCatalogoBean> inconsistencias) {
		this.inconsistencias = inconsistencias;
	}

	public List<DataCatalogoBean> getTipoBienes() {
		return tipoBienes;
	}

	public void setTipoBienes(List<DataCatalogoBean> tipoBienes) {
		this.tipoBienes = tipoBienes;
	}

	public List<BienFiscalizadoSolicitudBean> getBienesFiscalizados() {
		return bienesFiscalizados;
	}

	public void setBienesFiscalizados(List<BienFiscalizadoSolicitudBean> bienesFiscalizados) {
		this.bienesFiscalizados = bienesFiscalizados;
	}

	public List<UsuarioSolicitudBean> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<UsuarioSolicitudBean> usuarios) {
		this.usuarios = usuarios;
	}

	public List<AsignaProgramacionBean> getListaHistoriaAsignaciones() {
		return listaHistoriaAsignaciones;
	}

	public void setListaHistoriaAsignaciones(List<AsignaProgramacionBean> listaHistoriaAsignaciones) {
		this.listaHistoriaAsignaciones = listaHistoriaAsignaciones;
	}

	public List<ProgramacionBean> getListaProgramador() {
		return listaProgramador;
	}

	public void setListaProgramador(List<ProgramacionBean> listaProgramador) {
		this.listaProgramador = listaProgramador;
	}

	//Fin extra


	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}
	//Fin extra
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public boolean isEsSupervisorSolicitante() {
		return esSupervisorSolicitante;
	}

	public void setEsSupervisorSolicitante(boolean esSupervisorSolicitante) {
		this.esSupervisorSolicitante = esSupervisorSolicitante;
	}

	public boolean isEsSupervisorProgramador() {
		return esSupervisorProgramador;
	}

	public void setEsSupervisorProgramador(boolean esSupervisorProgramador) {
		this.esSupervisorProgramador = esSupervisorProgramador;
	}

	public String getCodProgramador() {
		return codProgramador;
	}

	public void setCodProgramador(String codProgramador) {
		this.codProgramador = codProgramador;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getCodTipDocIdent() {
		return codTipDocIdent;
	}

	public void setCodTipDocIdent(String codTipDocIdent) {
		this.codTipDocIdent = codTipDocIdent;
	}

	public String getCodTipoDocUsuario() {
		return codTipoDocUsuario;
	}

	public void setCodTipoDocUsuario(String codTipoDocUsuario) {
		this.codTipoDocUsuario = codTipoDocUsuario;
	}

	public String getNumDocUsuario() {
		return numDocUsuario;
	}

	public void setNumDocUsuario(String numDocUsuario) {
		this.numDocUsuario = numDocUsuario;
	}

	public String getFecEstadoActual() {
		return fecEstadoActual;
	}

	public void setFecEstadoActual(String fecEstadoActual) {
		this.fecEstadoActual = fecEstadoActual;
	}
	
}
