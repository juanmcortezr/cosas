package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10412MEDIOPROBUSU")
public class MedioProbatorioUsuario extends Auditoria {

	
	 @Column(name = "COD_TIP_MEDPROBAT")
	 private String codTipoMedioProbatorio;
	
	 @Id
	 @Column(name = "NUM_MED_PROBAUSU")
	 private Long numMedioProbatorioUsuario;
	
	 @Column(name = "NUM_MEDPROBAT")
	 private String numMedioProbatorio;

	 @Column(name = "num_usu_solic")
	 private Long numUsuarioSolicitud;

	 @Column(name = "num_arc")
	 private Long numArc;

	public String getCodTipoMedioProbatorio() {
		return codTipoMedioProbatorio;
	}

	public void setCodTipoMedioProbatorio(String codTipoMedioProbatorio) {
		this.codTipoMedioProbatorio = codTipoMedioProbatorio;
	}

	public Long getNumMedioProbatorioUsuario() {
		return numMedioProbatorioUsuario;
	}

	public void setNumMedioProbatorioUsuario(Long numMedioProbatorioUsuario) {
		this.numMedioProbatorioUsuario = numMedioProbatorioUsuario;
	}

	public String getNumMedioProbatorio() {
		return numMedioProbatorio;
	}

	public void setNumMedioProbatorio(String numMedioProbatorio) {
		this.numMedioProbatorio = numMedioProbatorio;
	}

	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}

	public Long getNumArc() {
		return numArc;
	}

	public void setNumArc(Long numArc) {
		this.numArc = numArc;
	}
 	 
}
