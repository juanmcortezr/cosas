package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import pe.gob.sunat.iqbf3.registro.maestros.model.EntidadPK;

@Embeddable
public class ResumenStockEstablecPK implements EntidadPK{

	 @Column(name = "COD_TIPBIEN")
	 private Integer codTipobien;
	
	 @Column(name = "NUM_RUC")
	 private Integer numRuc;
	
	 @Column(name = "NUM_VERREG")
	 private Integer numVersionRegistro;
	
	 @Column(name = "NUM_REPOSICION")
	 private Integer numReposicion;
	 
	 @Column(name = "NUM_PERIODO")
	 private String numPeriodo;
	
	 @Column(name = "NUM_ESTAB")
	 private String numEstablecimiento;

	 @Column(name = "NUM_PRESENT")
	 private Integer numPresentacion;

	public Integer getCodTipobien() {
		return codTipobien;
	}

	public void setCodTipobien(Integer codTipobien) {
		this.codTipobien = codTipobien;
	}

	public Integer getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(Integer numRuc) {
		this.numRuc = numRuc;
	}

	public Integer getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(Integer numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public Integer getNumReposicion() {
		return numReposicion;
	}

	public void setNumReposicion(Integer numReposicion) {
		this.numReposicion = numReposicion;
	}

	public String getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(String numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public String getNumEstablecimiento() {
		return numEstablecimiento;
	}

	public void setNumEstablecimiento(String numEstablecimiento) {
		this.numEstablecimiento = numEstablecimiento;
	}

	public Integer getNumPresentacion() {
		return numPresentacion;
	}

	public void setNumPresentacion(Integer numPresentacion) {
		this.numPresentacion = numPresentacion;
	}
	
}
