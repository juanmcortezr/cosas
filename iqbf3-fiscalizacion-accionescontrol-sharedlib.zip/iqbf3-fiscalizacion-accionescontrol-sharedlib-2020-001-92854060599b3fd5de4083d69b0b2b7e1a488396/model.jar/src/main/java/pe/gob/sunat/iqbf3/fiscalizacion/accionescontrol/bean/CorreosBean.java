package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class CorreosBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	alias;
	private	String	codpers;
	private	String	smtp;
	
	public CorreosBean() {
		super();
	}

	public CorreosBean(String alias, String codpers, String smtp) {
		super();
		this.alias = alias;
		this.codpers = codpers;
		this.smtp = smtp;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getCodpers() {
		return codpers;
	}

	public void setCodpers(String codpers) {
		this.codpers = codpers;
	}

	public String getSmtp() {
		return smtp;
	}

	public void setSmtp(String smtp) {
		this.smtp = smtp;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
