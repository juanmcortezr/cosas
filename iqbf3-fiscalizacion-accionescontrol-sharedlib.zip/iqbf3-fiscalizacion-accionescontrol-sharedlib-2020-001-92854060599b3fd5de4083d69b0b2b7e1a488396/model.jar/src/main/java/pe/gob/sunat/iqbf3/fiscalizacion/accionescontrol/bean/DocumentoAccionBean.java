package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class DocumentoAccionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	ArchivoBean	archivoBean;
	private	String	codEstadoDocumento;
	private	String	codTipoDocumento;
	private	String	codClase;
	private	String	desClase;
	private	String	desEstadoDocumento;
	private	String	desTipoDocumento;
	private	String	fecEmision;
	private	String	fecNotificacion;
	private	String	numDocumento;
	private	Long	numDocumentoAccion;
	private	Integer	numUsuarioPrograma;
	
	private String indOrigen;
	private String indDel;
	
	private String codUnidadOrganica;
	private Integer annDoc;
	
	private AuditoriaBean auditoriaBean;
	
	// para filtros
	private Long numOrden;
	
	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndOrigen() {
		return indOrigen;
	}

	public void setIndOrigen(String indOrigen) {
		this.indOrigen = indOrigen;
	}

	public String getCodUnidadOrganica() {
		return codUnidadOrganica;
	}

	public void setCodUnidadOrganica(String codUnidadOrganica) {
		this.codUnidadOrganica = codUnidadOrganica;
	}

	public Integer getAnnDoc() {
		return annDoc;
	}

	public void setAnnDoc(Integer annDoc) {
		this.annDoc = annDoc;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

	public DocumentoAccionBean() {
		super();
	}

	public DocumentoAccionBean(ArchivoBean archivoBean, String codEstadoDocumento, String codTipoDocumento,
			String codClase, String desClase, String desEstadoDocumento, String desTipoDocumento, String fecEmision,
			String fecNotificacion, String numDocumento, Long numDocumentoAccion, Integer numUsuarioPrograma, Long numOrden) {
		super();
		this.archivoBean = archivoBean;
		this.codEstadoDocumento = codEstadoDocumento;
		this.codTipoDocumento = codTipoDocumento;
		this.codClase = codClase;
		this.desClase = desClase;
		this.desEstadoDocumento = desEstadoDocumento;
		this.desTipoDocumento = desTipoDocumento;
		this.fecEmision = fecEmision;
		this.fecNotificacion = fecNotificacion;
		this.numDocumento = numDocumento;
		this.numDocumentoAccion = numDocumentoAccion;
		this.numUsuarioPrograma = numUsuarioPrograma;
		this.numOrden = numOrden;
	}

	public ArchivoBean getArchivoBean() {
		return archivoBean;
	}

	public void setArchivoBean(ArchivoBean archivoBean) {
		this.archivoBean = archivoBean;
	}

	public String getCodEstadoDocumento() {
		return codEstadoDocumento;
	}

	public void setCodEstadoDocumento(String codEstadoDocumento) {
		this.codEstadoDocumento = codEstadoDocumento;
	}

	public String getCodTipoDocumento() {
		return codTipoDocumento;
	}

	public void setCodTipoDocumento(String codTipoDocumento) {
		this.codTipoDocumento = codTipoDocumento;
	}

	public String getCodClase() {
		return codClase;
	}

	public void setCodClase(String codClase) {
		this.codClase = codClase;
	}

	public String getDesClase() {
		return desClase;
	}

	public void setDesClase(String desClase) {
		this.desClase = desClase;
	}

	public String getDesEstadoDocumento() {
		return desEstadoDocumento;
	}

	public void setDesEstadoDocumento(String desEstadoDocumento) {
		this.desEstadoDocumento = desEstadoDocumento;
	}

	public String getDesTipoDocumento() {
		return desTipoDocumento;
	}

	public void setDesTipoDocumento(String desTipoDocumento) {
		this.desTipoDocumento = desTipoDocumento;
	}

	public String getFecEmision() {
		return fecEmision;
	}

	public void setFecEmision(String fecEmision) {
		this.fecEmision = fecEmision;
	}

	public String getFecNotificacion() {
		return fecNotificacion;
	}

	public void setFecNotificacion(String fecNotificacion) {
		this.fecNotificacion = fecNotificacion;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public Long getNumDocumentoAccion() {
		return numDocumentoAccion;
	}

	public void setNumDocumentoAccion(Long numDocumentoAccion) {
		this.numDocumentoAccion = numDocumentoAccion;
	}

	public Integer getNumUsuarioPrograma() {
		return numUsuarioPrograma;
	}

	public void setNumUsuarioPrograma(Integer numUsuarioPrograma) {
		this.numUsuarioPrograma = numUsuarioPrograma;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Long numOrden) {
		this.numOrden = numOrden;
	}
}
