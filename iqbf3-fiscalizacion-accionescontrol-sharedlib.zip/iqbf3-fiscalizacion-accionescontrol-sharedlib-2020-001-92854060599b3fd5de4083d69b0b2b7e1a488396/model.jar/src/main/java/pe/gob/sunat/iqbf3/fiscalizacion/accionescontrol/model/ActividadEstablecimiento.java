package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10386ACTIVIDESTAB")
public class ActividadEstablecimiento extends Auditoria {

	 @Id
	 @Column(name = "NUM_ACTIV_ESTAB")
	 private Long numActividadEstablecimiento;

	 @Column(name = "num_estab_orden")
	 private Integer numEstablecimientoOrden;
	
	 @Column(name = "COD_ACTIVIDAD")
	 private String codActividad;
	 
	public String getCodActividad() {
		return codActividad;
	}

	public Integer getNumEstablecimientoOrden() {
		return numEstablecimientoOrden;
	}



	public void setNumEstablecimientoOrden(Integer numEstablecimientoOrden) {
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}



	public void setCodActividad(String codActividad) {
		this.codActividad = codActividad;
	}

	public Long getNumActividadEstablecimiento() {
		return numActividadEstablecimiento;
	}

	public void setNumActividadEstablecimiento(Long numActividadEstablecimiento) {
		this.numActividadEstablecimiento = numActividadEstablecimiento;
	}

	 
}
