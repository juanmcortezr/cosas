package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class AsignaProgramacionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codProgramador;
	private	String	desReasignacion;
	private	String	fecFinAsignacion;
	private	String	fecInicioAsignacion;
	private	String	indTipAsignacion;
	private	String	nomProgramador;
	private	Long	numAsignacion;
	private	Long	numProgramacion;
	private String codPers;
	
	private	Long	numSolicitud;
	private AuditoriaBean auditoriaBean;
	
	
	public AsignaProgramacionBean() {
		super();
	}

	public AsignaProgramacionBean(String codProgramador, String desReasignacion, String fecFinAsignacion,
			String fecInicioAsignacion, String indTipAsignacion, String nomProgramador, Long numAsignacion,
			Long numProgramacion, String codPers) {
		super();
		this.codProgramador = codProgramador;
		this.desReasignacion = desReasignacion;
		this.fecFinAsignacion = fecFinAsignacion;
		this.fecInicioAsignacion = fecInicioAsignacion;
		this.indTipAsignacion = indTipAsignacion;
		this.nomProgramador = nomProgramador;
		this.numAsignacion = numAsignacion;
		this.numProgramacion = numProgramacion;
		this.codPers = codPers;
	}

	
	public String getCodPers() {
		return codPers;
	}

	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}

	public String getCodProgramador() {
		return codProgramador;
	}

	public void setCodProgramador(String codProgramador) {
		this.codProgramador = codProgramador;
	}

	public String getDesReasignacion() {
		return desReasignacion;
	}

	public void setDesReasignacion(String desReasignacion) {
		this.desReasignacion = desReasignacion;
	}

	public String getFecFinAsignacion() {
		return fecFinAsignacion;
	}

	public void setFecFinAsignacion(String fecFinAsignacion) {
		this.fecFinAsignacion = fecFinAsignacion;
	}

	public String getFecInicioAsignacion() {
		return fecInicioAsignacion;
	}

	public void setFecInicioAsignacion(String fecInicioAsignacion) {
		this.fecInicioAsignacion = fecInicioAsignacion;
	}

	public String getIndTipAsignacion() {
		return indTipAsignacion;
	}

	public void setIndTipAsignacion(String indTipAsignacion) {
		this.indTipAsignacion = indTipAsignacion;
	}

	public String getNomProgramador() {
		return nomProgramador;
	}

	public void setNomProgramador(String nomProgramador) {
		this.nomProgramador = nomProgramador;
	}

	public Long getNumAsignacion() {
		return numAsignacion;
	}

	public void setNumAsignacion(Long numAsignacion) {
		this.numAsignacion = numAsignacion;
	}

	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public Long getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Long numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}

}
