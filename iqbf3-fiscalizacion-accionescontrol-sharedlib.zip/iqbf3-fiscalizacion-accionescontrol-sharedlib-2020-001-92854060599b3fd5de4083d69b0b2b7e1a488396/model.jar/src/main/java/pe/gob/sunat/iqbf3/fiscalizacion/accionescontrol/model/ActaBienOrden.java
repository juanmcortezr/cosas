package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name = "T10384ACTBIENORDEN")
public class ActaBienOrden extends Auditoria {

	 @Id
	 @Column(name = "NUM_ACT_BIENORDEN")
	 private Long numActaBienOrden;

	 @Column(name = "num_bien_estab")
	 private Integer numBienEstablecimiento;
	 
     @Column(name = "COD_TIP_ACTA")
	 private String codTipoActa;
	
	 @Column(name = "COD_TIP_DOCVIN")
	 private String codTipoDocumentoVinculado;
	
	 @Column(name = "COD_TIP_INFORME")
	 private String codTipoInforme;
	
	 @Column(name = "DES_OTRA_ACTA")
	 private String desOtraActa;
	
	 @Column(name = "DES_OTRO_DOCVIN")
	 private String desOtroDocumentoinculado;
	
	 @Column(name = "DES_OTRO_INFORME")
	 private String desOtroInforme;
	
	 @Column(name = "NUM_ACTA")
	 private String numActa;
	
	 @Column(name = "NUM_DOC_VIN")
	 private String numDocumentoVinculado;

	 
	public String getCodTipoActa() {
		return codTipoActa;
	}

	public void setCodTipoActa(String codTipoActa) {
		this.codTipoActa = codTipoActa;
	}

	public String getCodTipoDocumentoVinculado() {
		return codTipoDocumentoVinculado;
	}

	public void setCodTipoDocumentoVinculado(String codTipoDocumentoVinculado) {
		this.codTipoDocumentoVinculado = codTipoDocumentoVinculado;
	}

	public String getCodTipoInforme() {
		return codTipoInforme;
	}

	public void setCodTipoInforme(String codTipoInforme) {
		this.codTipoInforme = codTipoInforme;
	}

	public String getDesOtraActa() {
		return desOtraActa;
	}

	public void setDesOtraActa(String desOtraActa) {
		this.desOtraActa = desOtraActa;
	}

	public String getDesOtroDocumentoinculado() {
		return desOtroDocumentoinculado;
	}

	public void setDesOtroDocumentoinculado(String desOtroDocumentoinculado) {
		this.desOtroDocumentoinculado = desOtroDocumentoinculado;
	}

	public String getDesOtroInforme() {
		return desOtroInforme;
	}

	public void setDesOtroInforme(String desOtroInforme) {
		this.desOtroInforme = desOtroInforme;
	}

	public Long getNumActaBienOrden() {
		return numActaBienOrden;
	}

	public void setNumActaBienOrden(Long numActaBienOrden) {
		this.numActaBienOrden = numActaBienOrden;
	}

	public String getNumActa() {
		return numActa;
	}

	public void setNumActa(String numActa) {
		this.numActa = numActa;
	}

	public String getNumDocumentoVinculado() {
		return numDocumentoVinculado;
	}

	public void setNumDocumentoVinculado(String numDocumentoVinculado) {
		this.numDocumentoVinculado = numDocumentoVinculado;
	}

	public Integer getNumBienEstablecimiento() {
		return numBienEstablecimiento;
	}

	public void setNumBienEstablecimiento(Integer numBienEstablecimiento) {
		this.numBienEstablecimiento = numBienEstablecimiento;
	}

	


}
