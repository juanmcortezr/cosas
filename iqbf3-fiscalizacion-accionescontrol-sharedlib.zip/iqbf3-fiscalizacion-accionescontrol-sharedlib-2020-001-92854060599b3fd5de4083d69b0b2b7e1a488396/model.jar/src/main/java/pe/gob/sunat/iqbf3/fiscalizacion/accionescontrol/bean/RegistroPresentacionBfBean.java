package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class RegistroPresentacionBfBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private double cntNetProd;
	private double cntPesoBruto;
	private double cantidadUnidadFisica;
	private String codEstado;
	private String codOrigen;
	private String codPartidaArancelaria;
	private String codPresen;
	private String codPresenUsu;
	private String codTipoBien;
	private String codUnidadMedidaControl;
	private String codUnidadComercial;
	private String codUnidadFiscal;
	private String desSustento;
	private String fecAlta;
	private String fecBaja;
	private String indCondicion;
	private String indUsoarte;
	private String indUsodome;
	private int numInsumoCabecera;
	private String numOrdenInsumo;
	private int numPresentacion;
	private int numReferencianModifica;
	private String numRuc;
	private int numVersionRegistro;
	private int numVersion;

	public RegistroPresentacionBfBean() {
		super();
	}

	public RegistroPresentacionBfBean(double cntNetProd, double cntPesoBruto, double cantidadUnidadFisica,
			String codEstado, String codOrigen, String codPartidaArancelaria, String codPresen, String codPresenUsu,
			String codTipoBien, String codUnidadMedidaControl, String codUnidadComercial, String codUnidadFiscal,
			String desSustento, String fecAlta, String fecBaja, String indCondicion, String indUsoarte,
			String indUsodome, int numInsumoCabecera, String numOrdenInsumo, int numPresentacion,
			int numReferencianModifica, String numRuc, int numVersionRegistro, int numVersion) {
		super();
		this.cntNetProd = cntNetProd;
		this.cntPesoBruto = cntPesoBruto;
		this.cantidadUnidadFisica = cantidadUnidadFisica;
		this.codEstado = codEstado;
		this.codOrigen = codOrigen;
		this.codPartidaArancelaria = codPartidaArancelaria;
		this.codPresen = codPresen;
		this.codPresenUsu = codPresenUsu;
		this.codTipoBien = codTipoBien;
		this.codUnidadMedidaControl = codUnidadMedidaControl;
		this.codUnidadComercial = codUnidadComercial;
		this.codUnidadFiscal = codUnidadFiscal;
		this.desSustento = desSustento;
		this.fecAlta = fecAlta;
		this.fecBaja = fecBaja;
		this.indCondicion = indCondicion;
		this.indUsoarte = indUsoarte;
		this.indUsodome = indUsodome;
		this.numInsumoCabecera = numInsumoCabecera;
		this.numOrdenInsumo = numOrdenInsumo;
		this.numPresentacion = numPresentacion;
		this.numReferencianModifica = numReferencianModifica;
		this.numRuc = numRuc;
		this.numVersionRegistro = numVersionRegistro;
		this.numVersion = numVersion;
	}

	public double getCntNetProd() {
		return cntNetProd;
	}

	public void setCntNetProd(double cntNetProd) {
		this.cntNetProd = cntNetProd;
	}

	public double getCntPesoBruto() {
		return cntPesoBruto;
	}

	public void setCntPesoBruto(double cntPesoBruto) {
		this.cntPesoBruto = cntPesoBruto;
	}

	public double getCantidadUnidadFisica() {
		return cantidadUnidadFisica;
	}

	public void setCantidadUnidadFisica(double cantidadUnidadFisica) {
		this.cantidadUnidadFisica = cantidadUnidadFisica;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodOrigen() {
		return codOrigen;
	}

	public void setCodOrigen(String codOrigen) {
		this.codOrigen = codOrigen;
	}

	public String getCodPartidaArancelaria() {
		return codPartidaArancelaria;
	}

	public void setCodPartidaArancelaria(String codPartidaArancelaria) {
		this.codPartidaArancelaria = codPartidaArancelaria;
	}

	public String getCodPresen() {
		return codPresen;
	}

	public void setCodPresen(String codPresen) {
		this.codPresen = codPresen;
	}

	public String getCodPresenUsu() {
		return codPresenUsu;
	}

	public void setCodPresenUsu(String codPresenUsu) {
		this.codPresenUsu = codPresenUsu;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getCodUnidadMedidaControl() {
		return codUnidadMedidaControl;
	}

	public void setCodUnidadMedidaControl(String codUnidadMedidaControl) {
		this.codUnidadMedidaControl = codUnidadMedidaControl;
	}

	public String getCodUnidadComercial() {
		return codUnidadComercial;
	}

	public void setCodUnidadComercial(String codUnidadComercial) {
		this.codUnidadComercial = codUnidadComercial;
	}

	public String getCodUnidadFiscal() {
		return codUnidadFiscal;
	}

	public void setCodUnidadFiscal(String codUnidadFiscal) {
		this.codUnidadFiscal = codUnidadFiscal;
	}

	public String getDesSustento() {
		return desSustento;
	}

	public void setDesSustento(String desSustento) {
		this.desSustento = desSustento;
	}

	public String getFecAlta() {
		return fecAlta;
	}

	public void setFecAlta(String fecAlta) {
		this.fecAlta = fecAlta;
	}

	public String getFecBaja() {
		return fecBaja;
	}

	public void setFecBaja(String fecBaja) {
		this.fecBaja = fecBaja;
	}

	public String getIndCondicion() {
		return indCondicion;
	}

	public void setIndCondicion(String indCondicion) {
		this.indCondicion = indCondicion;
	}

	public String getIndUsoarte() {
		return indUsoarte;
	}

	public void setIndUsoarte(String indUsoarte) {
		this.indUsoarte = indUsoarte;
	}

	public String getIndUsodome() {
		return indUsodome;
	}

	public void setIndUsodome(String indUsodome) {
		this.indUsodome = indUsodome;
	}

	public int getNumInsumoCabecera() {
		return numInsumoCabecera;
	}

	public void setNumInsumoCabecera(int numInsumoCabecera) {
		this.numInsumoCabecera = numInsumoCabecera;
	}

	public String getNumOrdenInsumo() {
		return numOrdenInsumo;
	}

	public void setNumOrdenInsumo(String numOrdenInsumo) {
		this.numOrdenInsumo = numOrdenInsumo;
	}

	public int getNumPresentacion() {
		return numPresentacion;
	}

	public void setNumPresentacion(int numPresentacion) {
		this.numPresentacion = numPresentacion;
	}

	public int getNumReferencianModifica() {
		return numReferencianModifica;
	}

	public void setNumReferencianModifica(int numReferencianModifica) {
		this.numReferencianModifica = numReferencianModifica;
	}

	public String getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}

	public int getNumVersionRegistro() {
		return numVersionRegistro;
	}

	public void setNumVersionRegistro(int numVersionRegistro) {
		this.numVersionRegistro = numVersionRegistro;
	}

	public int getNumVersion() {
		return numVersion;
	}

	public void setNumVersion(int numVersion) {
		this.numVersion = numVersion;
	}

}
