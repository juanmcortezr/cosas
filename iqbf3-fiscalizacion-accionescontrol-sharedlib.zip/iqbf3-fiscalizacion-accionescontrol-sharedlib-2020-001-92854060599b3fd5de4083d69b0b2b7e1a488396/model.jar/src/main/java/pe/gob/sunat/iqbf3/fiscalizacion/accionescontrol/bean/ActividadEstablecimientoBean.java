package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public class ActividadEstablecimientoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codActividad;
	private	String	desActividad;
	private	int	numActividadEstablecimiento;
	private	int	numEstablecimientoOrden;
	private String indSeleccionado;
	private String indDel;
	private String indEst;
	private AuditoriaBean auditoriaBean;
	
	public ActividadEstablecimientoBean() {
		super();
	}

	public ActividadEstablecimientoBean(String codActividad, String desActividad, int numActividadEstablecimiento,
			int numEstablecimientoOrden) {
		super();
		this.codActividad = codActividad;
		this.desActividad = desActividad;
		this.numActividadEstablecimiento = numActividadEstablecimiento;
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public String getCodActividad() {
		return codActividad;
	}

	public void setCodActividad(String codActividad) {
		this.codActividad = codActividad;
	}

	public String getDesActividad() {
		return desActividad;
	}

	public void setDesActividad(String desActividad) {
		this.desActividad = desActividad;
	}

	public int getNumActividadEstablecimiento() {
		return numActividadEstablecimiento;
	}

	public void setNumActividadEstablecimiento(int numActividadEstablecimiento) {
		this.numActividadEstablecimiento = numActividadEstablecimiento;
	}

	public int getNumEstablecimientoOrden() {
		return numEstablecimientoOrden;
	}

	public void setNumEstablecimientoOrden(int numEstablecimientoOrden) {
		this.numEstablecimientoOrden = numEstablecimientoOrden;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIndSeleccionado() {
		return indSeleccionado;
	}

	public void setIndSeleccionado(String indSeleccionado) {
		this.indSeleccionado = indSeleccionado;
	}

	public String getIndDel() {
		return indDel;
	}

	public void setIndDel(String indDel) {
		this.indDel = indDel;
	}

	public String getIndEst() {
		return indEst;
	}

	public void setIndEst(String indEst) {
		this.indEst = indEst;
	}

	public AuditoriaBean getAuditoriaBean() {
		return auditoriaBean;
	}

	public void setAuditoriaBean(AuditoriaBean auditoriaBean) {
		this.auditoriaBean = auditoriaBean;
	}	
	
	
}
