package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10427TIPINCONUSU")
public class TipoInconsistenciaUsuario extends Auditoria {

	 @Column(name = "COD_TIP_INCONSIS")
	 private String codTipoInconsistencia;
	
	 @Column(name = "DES_OTRA_INCONSIS")
	 private String desOtraInconsistencia;
	
	 @Id
	 @Column(name = "NUM_INCON_USU")
	 private Long numInconsistenciaUsuario;

	 @Column(name = "num_usu_solic")
	 private Long numUsuarioSolicitud;

	public String getCodTipoInconsistencia() {
		return codTipoInconsistencia;
	}

	public void setCodTipoInconsistencia(String codTipoInconsistencia) {
		this.codTipoInconsistencia = codTipoInconsistencia;
	}

	public String getDesOtraInconsistencia() {
		return desOtraInconsistencia;
	}

	public void setDesOtraInconsistencia(String desOtraInconsistencia) {
		this.desOtraInconsistencia = desOtraInconsistencia;
	}

	public Long getNumInconsistenciaUsuario() {
		return numInconsistenciaUsuario;
	}

	public void setNumInconsistenciaUsuario(Long numInconsistenciaUsuario) {
		this.numInconsistenciaUsuario = numInconsistenciaUsuario;
	}

	public Long getNumUsuarioSolicitud() {
		return numUsuarioSolicitud;
	}

	public void setNumUsuarioSolicitud(Long numUsuarioSolicitud) {
		this.numUsuarioSolicitud = numUsuarioSolicitud;
	}
	 
}
