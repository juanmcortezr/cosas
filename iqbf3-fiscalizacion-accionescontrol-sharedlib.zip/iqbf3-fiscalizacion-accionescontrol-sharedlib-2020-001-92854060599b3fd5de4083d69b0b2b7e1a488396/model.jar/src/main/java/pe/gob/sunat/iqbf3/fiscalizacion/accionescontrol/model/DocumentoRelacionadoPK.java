package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import pe.gob.sunat.iqbf3.registro.maestros.model.EntidadPK;

@Embeddable
public class DocumentoRelacionadoPK implements EntidadPK{

	
	@Column(name = "COD_CPE")
	 private Integer codCpe;
	
	 @Column(name = "NUM_CPE")
	 private Integer numCpe;
	
	 @Column(name = "NUM_RUC")
	 private Integer numRuc;
	
	 @Column(name = "NUM_SERIE_CPE")
	 private Integer numSerieCpe;
	 
	@Column(name = "COD_DOC_REL")
	 private String codDocumentoRelacionado;
	
	 @Column(name = "NUM_DOC_REL")
	 private String numDocumentoRelacionado;
	
	 @Column(name = "NUM_RUC_REL")
	 private String numRucRelacionado;
	
	 @Column(name = "NUM_SERIE_DOC_REL")
	 private String numSerieDocumentoRelacionado;

	public Integer getCodCpe() {
		return codCpe;
	}

	public void setCodCpe(Integer codCpe) {
		this.codCpe = codCpe;
	}

	public Integer getNumCpe() {
		return numCpe;
	}

	public void setNumCpe(Integer numCpe) {
		this.numCpe = numCpe;
	}

	public Integer getNumRuc() {
		return numRuc;
	}

	public void setNumRuc(Integer numRuc) {
		this.numRuc = numRuc;
	}

	public Integer getNumSerieCpe() {
		return numSerieCpe;
	}

	public void setNumSerieCpe(Integer numSerieCpe) {
		this.numSerieCpe = numSerieCpe;
	}

	public String getCodDocumentoRelacionado() {
		return codDocumentoRelacionado;
	}

	public void setCodDocumentoRelacionado(String codDocumentoRelacionado) {
		this.codDocumentoRelacionado = codDocumentoRelacionado;
	}

	public String getNumDocumentoRelacionado() {
		return numDocumentoRelacionado;
	}

	public void setNumDocumentoRelacionado(String numDocumentoRelacionado) {
		this.numDocumentoRelacionado = numDocumentoRelacionado;
	}

	public String getNumRucRelacionado() {
		return numRucRelacionado;
	}

	public void setNumRucRelacionado(String numRucRelacionado) {
		this.numRucRelacionado = numRucRelacionado;
	}

	public String getNumSerieDocumentoRelacionado() {
		return numSerieDocumentoRelacionado;
	}

	public void setNumSerieDocumentoRelacionado(String numSerieDocumentoRelacionado) {
		this.numSerieDocumentoRelacionado = numSerieDocumentoRelacionado;
	}
	 
}
