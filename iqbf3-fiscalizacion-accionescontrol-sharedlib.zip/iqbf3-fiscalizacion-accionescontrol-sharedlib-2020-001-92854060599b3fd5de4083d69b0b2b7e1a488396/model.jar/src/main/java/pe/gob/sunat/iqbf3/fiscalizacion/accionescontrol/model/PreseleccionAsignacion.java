package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "T10416PRESELECASIG")
public class PreseleccionAsignacion extends Auditoria {

	 @Column(name = "COD_PERS")
	 private String codAuditor;
	
	 @Column(name = "COD_TIP_ACCION")
	 private String codTipoAccion;
	
	 @Id
	 @Column(name = "NUM_ASIG_TEMP")
	 private Long numAsignacionTemp;
	 
	 @Column(name = "NUM_PROGRAMACION")
	 private Long numProgramacion;
	 
	 //Filtros
	 @Transient
	 private String numInfSelecc;

	public String getNumInfSelecc() {
		return numInfSelecc;
	}

	public void setNumInfSelecc(String numInfSelecc) {
		this.numInfSelecc = numInfSelecc;
	}

	public String getCodAuditor() {
		return codAuditor;
	}

	public void setCodAuditor(String codAuditor) {
		this.codAuditor = codAuditor;
	}

	public String getCodTipoAccion() {
		return codTipoAccion;
	}

	public void setCodTipoAccion(String codTipoAccion) {
		this.codTipoAccion = codTipoAccion;
	}

	public Long getNumAsignacionTemp() {
		return numAsignacionTemp;
	}

	public void setNumAsignacionTemp(Long numAsignacionTemp) {
		this.numAsignacionTemp = numAsignacionTemp;
	}
	
	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}
 
}
