package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean;

import java.io.Serializable;

public class BienFiscalizadoSolicitudBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private	String	codBienFiscalizado;
	private	String	codTipoBien;
	private	String	desOtroTipobien;
	private	String	desBienFisca;
	private	String	desTipoBien;
	private	Integer	numBienFiscaSolicitud;
	private	Integer	numSolicitud;
	private boolean seleccionado;
	
	public BienFiscalizadoSolicitudBean() {
		super();
	}
	
	public BienFiscalizadoSolicitudBean(String codBienFiscalizado, String codTipoBien, String desOtroTipobien) {
		super();
		this.codBienFiscalizado = codBienFiscalizado;
		this.codTipoBien = codTipoBien;
		this.desOtroTipobien = desOtroTipobien;
	}

	public BienFiscalizadoSolicitudBean(String codBienFiscalizado, String codTipoBien, String desOtroTipobien,
			String desBienFisca) {
		super();
		this.codBienFiscalizado = codBienFiscalizado;
		this.codTipoBien = codTipoBien;
		this.desOtroTipobien = desOtroTipobien;
		this.desBienFisca = desBienFisca;
	}

	public BienFiscalizadoSolicitudBean(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public BienFiscalizadoSolicitudBean(String codBienFiscalizado, String codTipoBien, String desOtroTipobien,
			String desBienFisca, String desTipoBien, Integer numBienFiscaSolicitud, Integer numSolicitud) {
		super();
		this.codBienFiscalizado = codBienFiscalizado;
		this.codTipoBien = codTipoBien;
		this.desOtroTipobien = desOtroTipobien;
		this.desBienFisca = desBienFisca;
		this.desTipoBien = desTipoBien;
		this.numBienFiscaSolicitud = numBienFiscaSolicitud;
		this.numSolicitud = numSolicitud;
	}

	public String getCodBienFiscalizado() {
		return codBienFiscalizado;
	}

	public void setCodBienFiscalizado(String codBienFiscalizado) {
		this.codBienFiscalizado = codBienFiscalizado;
	}

	public String getCodTipoBien() {
		return codTipoBien;
	}

	public void setCodTipoBien(String codTipoBien) {
		this.codTipoBien = codTipoBien;
	}

	public String getDesOtroTipobien() {
		return desOtroTipobien;
	}

	public void setDesOtroTipobien(String desOtroTipobien) {
		this.desOtroTipobien = desOtroTipobien;
	}

	public String getDesBienFisca() {
		return desBienFisca;
	}

	public void setDesBienFisca(String desBienFisca) {
		this.desBienFisca = desBienFisca;
	}

	public String getDesTipoBien() {
		return desTipoBien;
	}

	public void setDesTipoBien(String desTipoBien) {
		this.desTipoBien = desTipoBien;
	}

	public Integer getNumBienFiscaSolicitud() {
		return numBienFiscaSolicitud;
	}

	public void setNumBienFiscaSolicitud(Integer numBienFiscaSolicitud) {
		this.numBienFiscaSolicitud = numBienFiscaSolicitud;
	}

	public Integer getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Integer numSolicitud) {
		this.numSolicitud = numSolicitud;
	}

	public boolean isSeleccionado() {
		return seleccionado;
	}

	public void setSeleccionado(boolean seleccionado) {
		this.seleccionado = seleccionado;
	}

}
