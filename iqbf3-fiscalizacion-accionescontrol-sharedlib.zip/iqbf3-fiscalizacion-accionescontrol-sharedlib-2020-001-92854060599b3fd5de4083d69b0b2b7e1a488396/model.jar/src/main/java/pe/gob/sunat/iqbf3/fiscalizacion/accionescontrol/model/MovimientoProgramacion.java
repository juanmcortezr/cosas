package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10413MOVPROGRAM")
public class MovimientoProgramacion extends Auditoria {

	 @Column(name = "COD_EST_INFORME")
	 private String codEstadoInforme;
	
	 @Column(name = "COD_EST_PROGRAM")
	 private String codEstadoPrograma;
	
	 @Column(name = "COD_PERS_MOV")
	 private String codPersonaMovimiento;
	
	 @Column(name = "DES_SUS_DEVOLUCION")
	 private String desSusDevolucion;
	
	 @Column(name = "FEC_MOVIMIENTO")
	 private Date fecMovimiento;
	
	 @Id
	 @Column(name = "NUM_MOV_PROGRAM")
	 private Long numMovimientoPrograma;
	 
	 @Column(name = "NUM_PROGRAMACION")
	 private Long numProgramacion;
	 
	public Long getNumProgramacion() {
		return numProgramacion;
	}

	public void setNumProgramacion(Long numProgramacion) {
		this.numProgramacion = numProgramacion;
	}

	public String getCodEstadoInforme() {
		return codEstadoInforme;
	}

	public void setCodEstadoInforme(String codEstadoInforme) {
		this.codEstadoInforme = codEstadoInforme;
	}

	public String getCodEstadoPrograma() {
		return codEstadoPrograma;
	}

	public void setCodEstadoPrograma(String codEstadoPrograma) {
		this.codEstadoPrograma = codEstadoPrograma;
	}

	public String getCodPersonaMovimiento() {
		return codPersonaMovimiento;
	}

	public void setCodPersonaMovimiento(String codPersonaMovimiento) {
		this.codPersonaMovimiento = codPersonaMovimiento;
	}

	public String getDesSusDevolucion() {
		return desSusDevolucion;
	}

	public void setDesSusDevolucion(String desSusDevolucion) {
		this.desSusDevolucion = desSusDevolucion;
	}

	public Date getFecMovimiento() {
		return fecMovimiento;
	}

	public void setFecMovimiento(Date fecMovimiento) {
		this.fecMovimiento = fecMovimiento;
	}

	public Long getNumMovimientoPrograma() {
		return numMovimientoPrograma;
	}

	public void setNumMovimientoPrograma(Long numMovimientoPrograma) {
		this.numMovimientoPrograma = numMovimientoPrograma;
	}
 
}
