package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;

@Entity
@Table(name = "T5228DATCOMPLEME")
public class DataComplementGre implements Entidad{

	@EmbeddedId
	 private DataComplementGrePK dataComplementGrePk;
	
	 @Column(name = "COD_VERIFICACION")
	 private String codigoVerificacion;
	
	 @Column(name = "DESC_MOTI_TRASLADO")
	 private String desMotivoTraslado;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_ENTREGA_PRODUC")
	 private Date fecEntregaProductos;

	 @Temporal(TemporalType.TIMESTAMP)
	 @Column(name = "FEC_INICIO_TRASLAD")
	 private Date fecInicioTraslado;
	
	 @Column(name = "COD_TIP_TRASLADO")
	 private Integer formaTraslado;
	
	 @Column(name = "COD_MOTI_EMISION")
	 private Integer motivoEmision;
	
	 @Column(name = "COD_MOTI_TRASLADO")
	 private Integer motivoTraslado;
	
	 @Column(name = "DES_RUTA_FISCAL")
	 private String rutaFiscal;
	
	 @Column(name = "COD_TIP_TRAMO")
	 private Integer tipoTramo;
	
	 @Column(name = "IND_TRANSBORDO")
	 private Integer transbordo;

	public String getCodigoVerificacion() {
		return codigoVerificacion;
	}

	public void setCodigoVerificacion(String codigoVerificacion) {
		this.codigoVerificacion = codigoVerificacion;
	}

	public String getDesMotivoTraslado() {
		return desMotivoTraslado;
	}

	public void setDesMotivoTraslado(String desMotivoTraslado) {
		this.desMotivoTraslado = desMotivoTraslado;
	}

	public Date getFecEntregaProductos() {
		return fecEntregaProductos;
	}

	public void setFecEntregaProductos(Date fecEntregaProductos) {
		this.fecEntregaProductos = fecEntregaProductos;
	}

	public Date getFecInicioTraslado() {
		return fecInicioTraslado;
	}

	public void setFecInicioTraslado(Date fecInicioTraslado) {
		this.fecInicioTraslado = fecInicioTraslado;
	}

	public Integer getFormaTraslado() {
		return formaTraslado;
	}

	public void setFormaTraslado(Integer formaTraslado) {
		this.formaTraslado = formaTraslado;
	}

	public Integer getMotivoEmision() {
		return motivoEmision;
	}

	public void setMotivoEmision(Integer motivoEmision) {
		this.motivoEmision = motivoEmision;
	}

	public Integer getMotivoTraslado() {
		return motivoTraslado;
	}

	public void setMotivoTraslado(Integer motivoTraslado) {
		this.motivoTraslado = motivoTraslado;
	}

	public String getRutaFiscal() {
		return rutaFiscal;
	}

	public void setRutaFiscal(String rutaFiscal) {
		this.rutaFiscal = rutaFiscal;
	}

	public Integer getTipoTramo() {
		return tipoTramo;
	}

	public void setTipoTramo(Integer tipoTramo) {
		this.tipoTramo = tipoTramo;
	}

	public Integer getTransbordo() {
		return transbordo;
	}

	public void setTransbordo(Integer transbordo) {
		this.transbordo = transbordo;
	}

}
