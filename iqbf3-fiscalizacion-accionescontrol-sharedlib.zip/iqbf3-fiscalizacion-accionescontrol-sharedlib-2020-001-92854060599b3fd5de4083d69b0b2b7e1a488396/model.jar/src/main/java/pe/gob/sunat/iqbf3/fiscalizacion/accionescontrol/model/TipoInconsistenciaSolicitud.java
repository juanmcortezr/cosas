package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "T10426TIPINCONSOLI")
public class TipoInconsistenciaSolicitud extends Auditoria {

	 @Column(name = "COD_TIP_INCONSIS")
	 private String codTipoInconsistencia;
	
	 @Column(name = "DES_OTRA_INCONSIS")
	 private String desOtraInconsistencia;
	
	 @Id
	 @Column(name = "NUM_INCON_SSOLI")
	 private Long numInconsistenciaSolicitud;

	 @Column(name = "num_solic_prog")
	 private Long numSolicitud;

	public String getCodTipoInconsistencia() {
		return codTipoInconsistencia;
	}

	public void setCodTipoInconsistencia(String codTipoInconsistencia) {
		this.codTipoInconsistencia = codTipoInconsistencia;
	}

	public String getDesOtraInconsistencia() {
		return desOtraInconsistencia;
	}

	public void setDesOtraInconsistencia(String desOtraInconsistencia) {
		this.desOtraInconsistencia = desOtraInconsistencia;
	}

	public Long getNumInconsistenciaSolicitud() {
		return numInconsistenciaSolicitud;
	}

	public void setNumInconsistenciaSolicitud(Long numInconsistenciaSolicitud) {
		this.numInconsistenciaSolicitud = numInconsistenciaSolicitud;
	}

	public Long getNumSolicitud() {
		return numSolicitud;
	}

	public void setNumSolicitud(Long numSolicitud) {
		this.numSolicitud = numSolicitud;
	}
	 
}
