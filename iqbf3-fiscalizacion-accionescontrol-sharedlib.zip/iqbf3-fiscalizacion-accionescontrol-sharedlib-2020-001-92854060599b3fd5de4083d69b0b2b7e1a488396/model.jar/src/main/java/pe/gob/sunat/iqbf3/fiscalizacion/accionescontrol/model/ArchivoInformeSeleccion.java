package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T10390ARCINFORME")
public class ArchivoInformeSeleccion extends Auditoria{

	@Id
	 @Column(name = "NUM_ARC_DOC")
	 private Long numArchivoDoc;

	 @Column(name = "NUM_ARC")
	 private Long numArchivo;
	 
	 @Column(name = "NUM_INF_SELECC")
	 private Long numInformeSeleccion;

	 
	public Long getNumArchivo() {
		return numArchivo;
	}

	public void setNumArchivo(Long numArchivo) {
		this.numArchivo = numArchivo;
	}

	public Long getNumInformeSeleccion() {
		return numInformeSeleccion;
	}

	public void setNumInformeSeleccion(Long numInformeSeleccion) {
		this.numInformeSeleccion = numInformeSeleccion;
	}

	public Long getNumArchivoDoc() {
		return numArchivoDoc;
	}

	public void setNumArchivoDoc(Long numArchivoDoc) {
		this.numArchivoDoc = numArchivoDoc;
	}

}
