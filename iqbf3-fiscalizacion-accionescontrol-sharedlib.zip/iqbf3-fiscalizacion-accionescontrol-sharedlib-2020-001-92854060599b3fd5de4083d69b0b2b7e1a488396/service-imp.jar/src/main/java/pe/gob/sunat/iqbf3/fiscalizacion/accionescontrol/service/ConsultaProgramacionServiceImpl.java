package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienFiscalizadoSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10398BienProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10425TipInconProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ConsultaProgramacionServiceImpl implements ConsultaProgramacionService{

	private static final Logger logger = LoggerFactory.getLogger(ConsultaProgramacionServiceImpl.class);

	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;
	
	@EJB
	private DataCatalogoService dataCatalogoService;
	
	@EJB
	private T10425TipInconProgDAO t10425TipInconProgDAO;
	
	@EJB
	private T10398BienProgDAO t10398BienProgDAO;
	@EJB
	private ServicioWebService servicioWebServiceImpl;
	
	
	@Override
	public List<ProgramacionBean> listarConsultaProgramacion (ProgramacionBean filtro) {
		if(logger.isDebugEnabled())
			logger.debug("Inicio de ConsultaProgramacionServiceImpl - listarConsultaProgramacion");

		Programacion filtroModel = new Programacion();
		filtroModel.setCodProgctrl(filtro.getCodProgramaControl());
		filtroModel.setCodTipoDocumentoIdent(filtro.getCodTipoDocumentoIdent());
		filtroModel.setNumDocumentoIdent(filtro.getNumDocumentoIdent());
		filtroModel.setNumInforme(filtro.getNumInforme());
		filtroModel.setCodTipoOrden(filtro.getCodTipoOrden());
		filtroModel.setPerInicio(filtro.getPerInicio());
		filtroModel.setPerFin(filtro.getPerFin());
//		filtroModel.setFechaDesde(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
//		filtroModel.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
		filtroModel.setCodTipInterv(filtro.getCodTipInterv());
		filtroModel.setCodTipoAccion(filtro.getCodTipoAccion());
		filtroModel.setCodEstadoInforme(filtro.getCodEstadoInforme());
		filtroModel.setNombAuditAsignad(filtro.getNombAuditAsignad());
		filtroModel.setCodEstOrden(filtro.getCodEstOrden());
		filtroModel.setNumDocVin(filtro.getNumDocVin());
		filtroModel.setNombAuditApoyo(filtro.getNombAuditApoyo());
		filtroModel.setNombApeUsuario(filtro.getNombApeUsuario());
		filtroModel.setCodTipoDocumentoIdent(filtro.getCodTipoDocumentoIdent());
		filtroModel.setNumDocumentoIdent(filtro.getNumDocumentoIdent());
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNroInformeUnion())) {
			filtroModel.setNroInformeUnion(filtro.getNroInformeUnion());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocAccion())) {
			filtroModel.setNumDocAccion(filtro.getNumDocAccion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumOrden())) {
			filtroModel.setNumOrden(filtro.getNumOrden());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocVin())) {
			filtroModel.setNumDocVin(filtro.getNumDocVin());
		}
		
		/*System.out.println("filtro.getNumSolicitudUnion() => " + filtro.getNroInformeUnion());
		System.out.println("filtro.getNumDocAccion() => " + filtro.getNumDocAccion());
		System.out.println("filtro.getNumOrden() => " + filtro.getNumOrden());
		System.out.println("filtro.getNumDocVin() => " + filtro.getNumDocVin());*/
		
		if (!MaestrosUtilidades.isEmpty(filtro.getInconsistencias())) {
			filtroModel.setInconsistencias(filtro.getInconsistencias().stream()
					.map(a -> new DataCatalogoBean(a.getCodigo()))
					.collect(Collectors.toList()));
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getTipoBienes())) {
			filtroModel.setTipoBienes(filtro.getTipoBienes().stream()
					.map(a -> new DataCatalogoBean(a.getCodigo()))
					.collect(Collectors.toList()));
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getBienesFiscalizados())) {
			filtroModel.setBienesFiscalizados(filtro.getBienesFiscalizados().stream()
					.map(a -> new BienFiscalizadoSolicitudBean(a.getCodigo()))
					.collect(Collectors.toList()));
		}
		
		List<ProgramacionBean> lista = new ArrayList<ProgramacionBean>();
		List<Programacion> t10420lista = t10420ProgramacionDAO.listarConsultaProgramacion(filtroModel);
		logger.debug(String.format("t10420lista => %s", t10420lista));
		if(!MaestrosUtilidades.isEmpty(t10420lista)){
			for(Programacion t10420 : t10420lista){
				ProgramacionBean bean = new ProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10420, bean);
				bean.setCodProgramaControl(t10420.getCodProgctrl());
				bean.setDesProgramaControl(t10420.getDesProgctrl());
				bean.setPerFin(t10420.getPerFin());
				bean.setPerInicio(t10420.getPerInicio());
				bean.setNumInforme(t10420.getNumInforme());
				bean.setNumDocVin(t10420.getNumDocVin());

				bean.setCodTipoDocumentoIdent(t10420.getCodTipoDocumentoIdent());
				DataCatalogoBean tipo3 = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF,
						bean.getCodTipoDocumentoIdent());
				bean.setDesTipoDocumentoIdent("");
				if (!MaestrosUtilidades.isEmpty(tipo3)) {
					bean.setDesTipoDocumentoIdent(tipo3.getDescripcionDataCatalogo());
				}
				
				bean.setCodEstadoInforme(t10420.getCodEstadoInforme());
				DataCatalogoBean tipo4 = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_INFORMESELECCION,
						bean.getCodEstadoInforme());
				bean.setDesEstadoInforme("");
				if (!MaestrosUtilidades.isEmpty(tipo4)) {
					bean.setDesEstadoInforme(tipo4.getDescripcionDataCatalogo());
				}
				
				bean.setCodTipoAccion(t10420.getCodTipoAccion());
				DataCatalogoBean tipo5 = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL,
						bean.getCodTipoAccion());
				bean.setDesTipoAccion("");
				if (!MaestrosUtilidades.isEmpty(tipo5)) {
					bean.setDesTipoAccion(tipo5.getDescripcionDataCatalogo());
				}
				
				bean.setCodTipoOrden(t10420.getCodTipoOrden());
				DataCatalogoBean tipo6 = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_ORDENES,
						bean.getCodTipoOrden());
				bean.setDesTipOrden("");
				if (!MaestrosUtilidades.isEmpty(tipo6)) {
					bean.setDesTipOrden(tipo6.getDescripcionDataCatalogo());
				}
				
				bean.setCodEstOrden(t10420.getCodEstOrden());
				DataCatalogoBean estado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_ORDEN,
						bean.getCodEstOrden());
				bean.setDesEstOrden("");
				if (!MaestrosUtilidades.isEmpty(estado)) {
					bean.setDesEstOrden(estado.getDescripcionDataCatalogo());
				}
				
				bean.setCodResOrden(t10420.getCodResOrden());
				DataCatalogoBean tipo7 = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_RESULTADO_ORDEN,
						bean.getCodResOrden());
				bean.setDesResOrden("");
				if (!MaestrosUtilidades.isEmpty(tipo7)) {
					bean.setDesResOrden(tipo7.getDescripcionDataCatalogo());
				}
				
				WSPersonalIqbfBean auditorPrincipal = servicioWebServiceImpl.obtenerPersonalIqbf(t10420.getCodPers());
				//System.out.println("t10420.getCodPers() => " + auditorPrincipal);
				if (!MaestrosUtilidades.isEmpty(auditorPrincipal)) {
					//System.out.println("t10420.getCodPers() => " + auditorPrincipal.getNomCompleto());
					bean.setNombAuditAsignad(auditorPrincipal.getNomCompleto());			
				}else{
					bean.setNombAuditAsignad("");
    			}
				
				
				WSPersonalIqbfBean auditorApoyo = servicioWebServiceImpl.obtenerPersonalIqbf(t10420.getCodPersApoyo());
				//System.out.println("t10420.getCodPers() => " + auditorApoyo);
				if (!MaestrosUtilidades.isEmpty(auditorApoyo)) {
					//System.out.println("t10420.getCodPers() => " + auditorApoyo.getNomCompleto());
					bean.setNombAuditApoyo(auditorApoyo.getNombres());
				}else{
					bean.setNombAuditApoyo("");
    			}
				
				lista.add(bean);
			}

			if (!MaestrosUtilidades.isEmpty(filtro.getCodPers()) || !MaestrosUtilidades.isEmpty(filtro.getCodPersApoyo())) {
				lista.stream().filter(bean -> {
					return (bean.getNombAuditAsignad().contains(filtro.getCodPers()) || bean.getCodPers().equals(filtro.getCodPers()) 
							|| bean.getNombAuditApoyo().contains(filtro.getCodPersApoyo()) || bean.getCodPersApoyo().equals(filtro.getCodPersApoyo()) );
				});	
			}
			if(!MaestrosUtilidades.isEmpty(filtro.getNombAuditAsignad())){
				lista = listByNomAuditorAsiganado(lista, filtro);
			}
			if(!MaestrosUtilidades.isEmpty(filtro.getNombAuditApoyo())){
				lista = listByNomAuditorApoyo(lista, filtro);
			}
		}
		
		return lista;
	}
	private List<ProgramacionBean> listByNomAuditorApoyo(List<ProgramacionBean> lista,ProgramacionBean filtro){
		List<ProgramacionBean> lista2= new ArrayList<ProgramacionBean>();
		for (ProgramacionBean bean : lista) {
			if(bean.getNombAuditApoyo()!=null && bean.getNombAuditApoyo().toLowerCase().contains(filtro.getNombAuditApoyo().toLowerCase())){
				lista2.add(bean);
			}
		}
		return lista2;
	}
	private List<ProgramacionBean> listByNomAuditorAsiganado(List<ProgramacionBean> lista,ProgramacionBean filtro){
		List<ProgramacionBean> lista2= new ArrayList<ProgramacionBean>();
		for (ProgramacionBean bean : lista) {
			if(bean.getNombAuditApoyo()!=null && bean.getNombAuditAsignad().toLowerCase().contains(filtro.getNombAuditAsignad().toLowerCase())){
				lista2.add(bean);
			}
		}
		return lista2;
	}
}

