package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10421SolicProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ConsultaSolicitudServiceImpl implements ConsultaSolicitudService {

	private static final Logger logger = LoggerFactory.getLogger(ConsultaSolicitudServiceImpl.class);

	@EJB
	private T10421SolicProgDAO t10421SolicProgDAO;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private ServicioWebService servicioWebServiceImpl;

	@EJB(name="accionescontrol.comunService")
	private ComunService comunService;


	@Override
	public List<SolicitudProgramacionBean> listarConsultaSolicitudProgramacion(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
		logger.debug("Inicio ConsultaSolicitudServiceImpl - listarConsultaSolicitudProgramacion");

		SolicitudProgramacion filtroModel = new SolicitudProgramacion();

		filtroModel.setNumSolicitud(filtro.getNumSolicitud());
		filtroModel.setCodTipDocIdent(filtro.getCodTipDocIdent());
		filtroModel.setNumDocIdent(filtro.getNumDocIdent());
		filtroModel.setCodEstadoSolicitud(filtro.getCodEstadoSolicitud());
		filtroModel.setFechaDesde(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
		filtroModel.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
		filtroModel.setNomSolicitante(filtro.getNomSolicitante());
		filtroModel.setCodTipInterv(filtro.getCodTipoIntervension());
		filtroModel.setCodTipAccion(filtro.getCodTipoAccion());
		filtroModel.setNumDocumentoReferencia(filtro.getNumDocumentoReferencia());
		filtroModel.setCodProgramador(filtro.getCodProgramador());
		filtroModel.setCalificacionDesde(filtro.getCalificacionDesde());
		filtroModel.setCalificacionHasta(filtro.getCalificacionHasta());
		filtroModel.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		filtroModel.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				
		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			filtroModel.setNumSolicitudUnion(filtro.getNumSolicitudUnion());
		}
		
		List<SolicitudProgramacionBean> lista = new ArrayList<SolicitudProgramacionBean>();
		List<SolicitudProgramacion> t10421lista = t10421SolicProgDAO.listarConsultaSolicitudProgramacion(filtroModel);
		if (!MaestrosUtilidades.isEmpty(t10421lista)) {
			for (SolicitudProgramacion t10421 : t10421lista) {
				SolicitudProgramacionBean bean = new SolicitudProgramacionBean();
				bean.setNumSolicitudUnion(AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
				bean.setNumSolicitud(t10421.getNumSolicitud());
				bean.setRazonSocial(t10421.getRazonSocial());
				bean.setFecGeneracion(MaestrosUtilidades.dateToStringDDMMYYYY(t10421.getFecGeneracion()));
				bean.setPerInicio(t10421.getPerInicio());
				bean.setPerFin(t10421.getPerFin());
				bean.setCalificacionDefinitiva(t10421.getCalificacionDefinitiva());
				bean.setCalificacionPreliminar(t10421.getCalificacionPreliminar());
				bean.setNumDocIdent(t10421.getNumDocIdent());
				bean.setDesSusSolicitud(t10421.getDesSusSolicitud());
				bean.setNumMedProbausu(t10421.getMedioProbatorio());
				bean.setFecEstadoActual(MaestrosUtilidades.dateToStringDDMMYYYY(t10421.getFechaEstadoActual()));
				
				bean.setCodProgramador(t10421.getCodProgramador());
				bean.setNomProgramador(t10421.getNomProgramador());

				bean.setCodTipDocIdent(t10421.getCodTipDocIdent());
				DataCatalogoBean catalogoTipoDocIdentif = dataCatalogoService.obtenerCatalogo(
						AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF, bean.getCodTipDocIdent());
				bean.setDesTipoDocumentoIdent("");
				if (!MaestrosUtilidades.isEmpty(catalogoTipoDocIdentif)) {
					bean.setDesTipoDocumentoIdent(catalogoTipoDocIdentif.getDescripcionDataCatalogo());
				}
				bean.setNumDocIdent(t10421.getNumDocIdent());
				
				bean.setCodTipoIntervension(t10421.getCodTipInterv());
				DataCatalogoBean cataTipoInterv = dataCatalogoService.obtenerCatalogo(
						AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INTERVENCION,
						bean.getCodTipoIntervension());
				bean.setDesTipoIntervencion("");
				if (!MaestrosUtilidades.isEmpty(cataTipoInterv)) {
					bean.setDesTipoIntervencion(cataTipoInterv.getDescripcionDataCatalogo());
				}

				bean.setCodTipoAccion(t10421.getCodTipAccion());
				DataCatalogoBean cataTipoAccion = dataCatalogoService.obtenerCatalogo(
						AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL, bean.getCodTipoAccion());
				bean.setDesTipoAccionControl("");
				if (!MaestrosUtilidades.isEmpty(cataTipoAccion)) {
					bean.setDesTipoAccionControl(cataTipoAccion.getDescripcionDataCatalogo());
				}

				bean.setCodTipoDocumentoReferencia(t10421.getCodTipoDocumentoReferencia());
				DataCatalogoBean cataTipoReferencia = dataCatalogoService.obtenerCatalogo(
						AccionesControlConstantes.COD_CATALOGO_TIPO_DOCUMENTO_REFERENCIAAC,
						bean.getCodEstadoSolicitud());
				bean.setDesTipoDocumentoRef("");
				if (!MaestrosUtilidades.isEmpty(cataTipoReferencia)) {
					bean.setDesTipoDocumentoRef(cataTipoReferencia.getDescripcionDataCatalogo());
				}

				bean.setCodEstadoSolicitud(t10421.getCodEstadoSolicitud());
				DataCatalogoBean estado = dataCatalogoService.obtenerCatalogo(
						AccionesControlConstantes.COD_CATALOGO_ESTADO_SOLICITUD, bean.getCodEstadoSolicitud());
				bean.setDesEstadoSolicitud("");
				if (!MaestrosUtilidades.isEmpty(estado)) {
					bean.setDesEstadoSolicitud(estado.getDescripcionDataCatalogo());
				}

				if (!MaestrosUtilidades.isEmpty(estado)) {
					bean.setCalificacionDesde(t10421.getCalificacionDesde());
				}

				if (!MaestrosUtilidades.isEmpty(estado)) {
					bean.setCalificacionHasta(t10421.getCalificacionHasta());
				}

				bean.setNomSolicitante("");
				WSPersonalIqbfBean solicitante = servicioWebServiceImpl.obtenerPersonalIqbf(t10421.getCodSolicitante());
				if (!MaestrosUtilidades.isEmpty(solicitante)) {
					bean.setNomSolicitante(solicitante.getNomCompleto());
				}

				// Archivo Bean
				ArchivoBean archivoBean = comunService.obtenerArchivo(t10421.getNumArc());
				if (!MaestrosUtilidades.isEmpty(archivoBean)) {
					bean.setArchivoBean(archivoBean);
				}

				lista.add(bean);
			}
		}
		return lista;

	}

}