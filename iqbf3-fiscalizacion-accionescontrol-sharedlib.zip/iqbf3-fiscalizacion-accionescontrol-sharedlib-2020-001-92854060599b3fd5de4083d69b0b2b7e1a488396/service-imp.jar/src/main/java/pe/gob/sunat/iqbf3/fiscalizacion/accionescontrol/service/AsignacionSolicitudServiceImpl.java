package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10393AsignaSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10414MovSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10421SolicProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class AsignacionSolicitudServiceImpl implements AsignacionSolicitudService {

	private static final Logger logger = LoggerFactory.getLogger(AsignacionSolicitudServiceImpl.class);

	@EJB
	private T10421SolicProgDAO t10421SolicProgDAO;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private T8303DistriGrupoDAO t8303DistriGrupoDAO;

	@EJB
	private T10393AsignaSolicDAO t10393AsignaSolicDAO;

	@EJB
	private T10414MovSolicDAO t10414MovSolicDAO;

	@EJB
	private T8414MensajeIqbfDAO t8414MensajeIqbfDAO;

	public AsignacionSolicitudServiceImpl() {
	}

	@Override
	public List<SolicitudProgramacionBean> listarSolicitudesporAsignar(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionSolicitudServiceImpl - listarSolicitudesporAsignar");
		SolicitudProgramacion filtroModel = new SolicitudProgramacion();
		filtroModel.setEstados(Arrays.asList(AccionesControlConstantes.COD_ESTADO_SOLICITUD_AUTORIZADO, AccionesControlConstantes.COD_ESTADO_SOLICITUD_ASIGNADO));
		filtroModel.setCodTipAccion(filtro.getCodTipoAccion());
		filtroModel.setCodTipInterv(filtro.getCodTipoIntervension());
		filtroModel.setCodTipDocIdent(filtro.getCodTipoDocUsuario());
		filtroModel.setNumDocIdent(filtro.getNumDocUsuario());
		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			filtroModel.setNumSolicitudUnion(filtro.getNumSolicitudUnion());
		}
		filtroModel.setCodSolicitante(filtro.getCodSolicitante()); // verificar debe ser programador.
		List<SolicitudProgramacionBean> lista = new ArrayList<>();
		List<SolicitudProgramacion> t10421lista = t10421SolicProgDAO.listarSolicitudesporAsignarCalificar(filtroModel);
		if (!MaestrosUtilidades.isEmpty(t10421lista)) {
			for (SolicitudProgramacion t10421 : t10421lista) {
				SolicitudProgramacionBean bean = new SolicitudProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10421, bean);
				bean.setNumSolicitudUnion(AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
				bean.setFecGeneracion(MaestrosUtilidades.dateToStringDDMMYYYY(t10421.getFecGeneracion()));
				bean.setDesEstadoSolicitud("");
				bean.setCalificacionDefinitiva(t10421.getCalificacionDefinitiva());
				bean.setCalificacionPreliminar(t10421.getCalificacionPreliminar());
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_SOLICITUD,
						t10421.getCodEstadoSolicitud());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesEstadoSolicitud(catalogo.getDescripcionDataCatalogo().trim());
				}
				WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(t10421.getCodSolicitante());
				if (!MaestrosUtilidades.isEmpty(solicitante)) {
					bean.setNomSolicitante(solicitante.getNomCompleto());
				}
				WSPersonalIqbfBean programador = servicioWebService.obtenerPersonalIqbf(t10421.getCodProgramador());
				if (!MaestrosUtilidades.isEmpty(programador)) {
					bean.setNomProgramador(programador.getNomCompleto());
				}
				WSPersonalIqbfBean supervisor = servicioWebService.obtenerPersonalIqbf(t10421.getCodSupervisor());
				if (!MaestrosUtilidades.isEmpty(supervisor)) {
					bean.setNomSupervisor(supervisor.getNomCompleto());
				}
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	public List<AsignaProgramacionBean> listarHistoriaAsignaciones(Long numSolic) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionSolicitudServiceImpl - listarHistoriaAsignaciones");
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numSolicitud", numSolic);
		List<AsignaProgramacionBean> lista = new ArrayList<>();
		List<AsignaSolicitud> t10393lista = t10393AsignaSolicDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10393lista)) {
			for (AsignaSolicitud t10393 : t10393lista) {
				AsignaProgramacionBean bean = new AsignaProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10393, bean);
				bean.setFecFinAsignacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10393.getFecFinAsignacion()));
				bean.setFecInicioAsignacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10393.getFecInicioAsignacion()));
				bean.setNomProgramador("");
				WSPersonalIqbfBean programador = servicioWebService.obtenerPersonalIqbf(bean.getCodProgramador());
				if (!MaestrosUtilidades.isEmpty(programador)) {
					bean.setNomProgramador(programador.getNomCompleto());
				}
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	public AsignaProgramacionBean guardarAsignacionSolicitud(AsignaProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignacionSolicitudServiceImpl - guardarAsignacionSolicitud");
		// Dar de baja
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numSolicitud", formulario.getNumSolicitud());
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<AsignaSolicitud> t10393lista = t10393AsignaSolicDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if(!MaestrosUtilidades.isEmpty(t10393lista)) {
			for (AsignaSolicitud t10393 : t10393lista) {
				t10393.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
				t10393.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10393.setFecFinAsignacion(new Date());
				t10393.setFecModif(new Date());
				t10393.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
				t10393.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
				t10393AsignaSolicDAO.update(t10393, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}
		// Insertar
		AsignaSolicitud t10393 = new AsignaSolicitud();
		t10393.setCodProgramador(formulario.getCodProgramador());
		t10393.setFecInicioAsignacion(new Date());
		t10393.setFecFinAsignacion(MaestrosUtilidades.stringToDate(AccionesControlConstantes.FECHA_ESTANDAR, MaestrosConstantes.FORMAT_FECHAHORA_YYYYMMDDHHMMSS));
		t10393.setNumSolicitud(formulario.getNumSolicitud());
		t10393.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10393.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10393.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10393.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10393.setFecCrea(new Date());
		t10393.setNumAsignacionSolic(t10393AsignaSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ASIGNACION_SOLICITUD, AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10393AsignaSolicDAO.save(t10393, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// Actualizar estado
		SolicitudProgramacion t10421 = t10421SolicProgDAO.findById(formulario.getNumSolicitud(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (AccionesControlConstantes.COD_ESTADO_SOLICITUD_AUTORIZADO.equals(t10421.getCodEstadoSolicitud())) {
			t10421.setCodEstadoSolicitud(AccionesControlConstantes.COD_ESTADO_SOLICITUD_ASIGNADO);
			t10421.setFecModif(new Date());
			t10421.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			t10421.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			t10421SolicProgDAO.update(t10421, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			// Parseo
			SolicitudProgramacionBean bean = new SolicitudProgramacionBean();
			MaestrosUtilidades.copiarValoresBean(t10421, bean);

			// Registrar movimiento
			MovimientoSolicitud t10414 = new MovimientoSolicitud();
			t10414.setCodPersMov(formulario.getAuditoriaBean().getNroRegistro());
			t10414.setFecMovimiento(new Date());
			t10414.setNumSolicitud(formulario.getNumSolicitud());
			t10414.setNumMovimientoPrograma(t10414MovSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_MOVIMIENTO_SOLICITUD, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10414.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10414.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10414.setFecCrea(new Date());
			t10414.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10414.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10414.setCodCargo(AccionesControlConstantes.COD_CARGO_SUPERVISOR_PROG);
			t10414MovSolicDAO.save(t10414, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			try {
				String codProgramador = formulario.getCodProgramador();
				String codSupervisor = t8303DistriGrupoDAO.obtenerSupervisorPersonal(codProgramador);
				WSPersonalIqbfBean programador = servicioWebService.obtenerPersonalIqbf(codProgramador);
				String dirReceptor = "";
				String dirCopia = "";
				if (!MaestrosUtilidades.isEmpty(programador)) {
					dirReceptor = programador.getDirCorreo().trim();
				}
				WSPersonalIqbfBean supervisor = servicioWebService.obtenerPersonalIqbf(codSupervisor);
				if (!MaestrosUtilidades.isEmpty(supervisor)) {
					dirCopia = supervisor.getDirCorreo().trim();
				}
				MensajeIqbf t8414 = t8414MensajeIqbfDAO.findById(AccionesControlConstantes.COD_MENSAJE_CORREO_F03, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(t8414) && !MaestrosUtilidades.isEmpty(dirReceptor)) {
					Map<String, Object> parametros = new HashMap<String, Object>();
					parametros.put("numeroSolicitudProgramacion", AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
					CorreoBean correoBean = new CorreoBean();
					correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
					correoBean.setAsunto(t8414.getDesCorta());
					correoBean.setReceptor(dirReceptor);
					//correoBean.setCopia(dirCopia);
					correoBean.setMensaje(AccionesControlUtil.generarMensaje(t8414.getDesCuerpo(), parametros));
					CorreoUtil.enviarCorreo(correoBean);
				}
			} catch(Exception e) {
				logger.error(String.format("errorEnviarCorreo %s", e.getMessage()), e);
			}
		}
		formulario.setNumAsignacion(t10393.getNumAsignacionSolic());
		return formulario;
	}

}
