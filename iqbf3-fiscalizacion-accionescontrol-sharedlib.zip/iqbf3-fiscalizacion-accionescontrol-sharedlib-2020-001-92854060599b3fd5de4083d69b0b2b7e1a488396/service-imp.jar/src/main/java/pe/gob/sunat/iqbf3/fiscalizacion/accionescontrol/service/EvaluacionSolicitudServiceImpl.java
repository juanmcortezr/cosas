package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.TipoInconsistenciaSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10414MovSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10421SolicProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class EvaluacionSolicitudServiceImpl implements EvaluacionSolicitudService {

	private static final Logger logger = LoggerFactory.getLogger(GestionSolicitudServiceImpl.class);

	List<SolicitudProgramacionBean> listaSolicitud;
	List<TipoInconsistenciaSolicitudBean> listaTipoInconsistencia;

	@EJB
	private T10421SolicProgDAO t10421SolicProgDAO;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private GestionSolicitudService gestionSolicitudService;

	@EJB
	private T10414MovSolicDAO t10414MovSolicDAO;

	@EJB
	private T8414MensajeIqbfDAO t8414MensajeIqbfDAO;

	@EJB
	private T8303DistriGrupoDAO t8303DistriGrupoDAO;
	
	public EvaluacionSolicitudServiceImpl() {
	}

	@Override
	public List<SolicitudProgramacionBean> listarSolicitudSupervisorProgramador(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionSolicitudServiceImpl - listarSolicitudSupervisorProgramador");
		SolicitudProgramacion filtroModel = new SolicitudProgramacion();
		filtroModel.setCodEstadoSolicitud(AccionesControlConstantes.COD_ESTADO_SOLICITUD_CALIFICADO);
		filtroModel.setCodTipAccion(filtro.getCodTipoAccion());
		filtroModel.setCodTipInterv(filtro.getCodTipoIntervension());
		filtroModel.setCodTipDocIdent(filtro.getCodTipoDocUsuario());
		filtroModel.setNumDocIdent(filtro.getNumDocUsuario());
		filtroModel.setCodSolicitante(filtro.getCodSolicitante());
		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			filtroModel.setNumSolicitudUnion(filtro.getNumSolicitudUnion());
		}
		List<SolicitudProgramacionBean> lista = new ArrayList<>();
		List<SolicitudProgramacion> t10421lista = t10421SolicProgDAO.listarSolicitudSupervisorProgramador(filtroModel);
		if (!MaestrosUtilidades.isEmpty(t10421lista)) {
			for (SolicitudProgramacion t10421 : t10421lista) {
				SolicitudProgramacionBean bean = new SolicitudProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10421, bean);
				bean.setNumSolicitudUnion(AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
				bean.setFecGeneracion(MaestrosUtilidades.dateToStringDDMMYYYY(t10421.getFecGeneracion()));
				bean.setDesEstadoSolicitud("");
				bean.setCalificacionDefinitiva(t10421.getCalificacionDefinitiva());
				bean.setCalificacionPreliminar(t10421.getCalificacionPreliminar());
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_SOLICITUD,
						t10421.getCodEstadoSolicitud());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesEstadoSolicitud(catalogo.getDescripcionDataCatalogo().trim());
				}
				WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(t10421.getCodSolicitante());
				if (!MaestrosUtilidades.isEmpty(solicitante)) {
					bean.setNomSolicitante(solicitante.getNomCompleto());
				}
				WSPersonalIqbfBean programador = servicioWebService.obtenerPersonalIqbf(t10421.getCodProgramador());
				if (!MaestrosUtilidades.isEmpty(programador)) {
					bean.setNomProgramador(programador.getNomCompleto());
				}
				WSPersonalIqbfBean supervisor = servicioWebService.obtenerPersonalIqbf(t10421.getCodSupervisor());
				if (!MaestrosUtilidades.isEmpty(supervisor)) {
					bean.setNomSupervisor(supervisor.getNomCompleto());
				}
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	public SolicitudProgramacionBean obtenerDatosSolicitud(Long numSolicProg) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionSolicitudServiceImpl - obtenerDatosSolicitud");
		SolicitudProgramacionBean bean = gestionSolicitudService.obtenerDatosSolicitud(numSolicProg);
		System.out.println("bean.getBienesFiscalizados().size()  1=> " + bean.getBienesFiscalizados().size());
		DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_SOLICITUD,
				bean.getCodEstadoSolicitud());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			bean.setDesEstadoSolicitud(catalogo.getDescripcionDataCatalogo().trim());
		}
		
		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF,
				bean.getCodTipoDocumentoReferencia());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			bean.setDesTipoDocumentoRef(catalogo.getDescripcionDataCatalogo().trim());
		}
		bean.setUsuarios(gestionSolicitudService.obtenerDetalleSolicitud(numSolicProg));
		System.out.println("bean.getBienesFiscalizados().size() 2 => " + bean.getBienesFiscalizados().size());
		return bean;
	}

	@Override
	public UsuarioSolicitudBean obtenerUsuarioSeleccionado(Long numUsuarioSolicitud) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionSolicitudServiceImpl - obtenerUsuarioSeleccionado");
		UsuarioSolicitudBean filtro = new UsuarioSolicitudBean();
		filtro.setNumUsuarioSolicitud(numUsuarioSolicitud);
		UsuarioSolicitudBean bean = gestionSolicitudService.obtenerDatosUsuario(filtro);
		DataCatalogoBean catalogo = dataCatalogoService
				.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_DOCUMENTO_REFERENCIAAC, bean.getCodTipoDocumentoReferencia());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			bean.setDesTipoDocumentoRef(catalogo.getDescripcionDataCatalogo());
		}
		catalogo = dataCatalogoService
				.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL, bean.getCodTipoAccion());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			bean.setDesTipoAccionControl(catalogo.getDescripcionDataCatalogo());
		}
		catalogo = dataCatalogoService
				.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INTERVENCION, bean.getCodTipoIntervencion());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			bean.setDesTipoIntervencion(catalogo.getDescripcionDataCatalogo());
		}
		catalogo = dataCatalogoService
				.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF, bean.getCodTipoDocumentoIdentif());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			bean.setDesTipoDocumentoIdent(catalogo.getDescripcionDataCatalogo());
		}
		bean.setNumUsuarioSolicitud(numUsuarioSolicitud);
		bean.setEstablecimientos(gestionSolicitudService.listarEstablecimientosUsuario(filtro));
		return bean;
	}

	@Override
	public SolicitudProgramacionBean guardarEvaluacion(SolicitudProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionSolicitudServiceImpl - guardarEvaluacion");
		String codCargo = null;
		String codEstado = null;
		String desMotivoAsignacion = null;
		String codMensaje = null;
		if (formulario.isEsSupervisorSolicitante()) {
			codCargo = AccionesControlConstantes.COD_CARGO_SUPERVISOR;
			if (AccionesControlConstantes.COD_ESTADO_SOLICITUD_AUTORIZADO.equals(formulario.getCodEstadoSolicitud())) {
				codEstado = AccionesControlConstantes.COD_ESTADO_SOLICITUD_AUTORIZADO;
				codMensaje = AccionesControlConstantes.COD_MENSAJE_CORREO_F02;
			}
			else if (AccionesControlConstantes.COD_ESTADO_SOLICITUD_DEVUELTO.equals(formulario.getCodEstadoSolicitud())) {
				codEstado = AccionesControlConstantes.COD_ESTADO_SOLICITUD_DEVUELTO;
				codMensaje = AccionesControlConstantes.COD_MENSAJE_CORREO_F01;
				desMotivoAsignacion = formulario.getDesSusSolicitud();
			}
		}
		else if (formulario.isEsSupervisorProgramador()) {
			codCargo = AccionesControlConstantes.COD_CARGO_SUPERVISOR_PROG;
			if (AccionesControlConstantes.COD_ESTADO_SOLICITUD_APROBADO.equals(formulario.getCodEstadoSolicitud())) {
				codEstado = AccionesControlConstantes.COD_ESTADO_SOLICITUD_APROBADO;
				codMensaje = AccionesControlConstantes.COD_MENSAJE_CORREO_F05;
			}
			else if (AccionesControlConstantes.COD_ESTADO_SOLICITUD_ARCHIVADO.equals(formulario.getCodEstadoSolicitud())) {
				codEstado = AccionesControlConstantes.COD_ESTADO_SOLICITUD_ARCHIVADO;
				codMensaje = AccionesControlConstantes.COD_MENSAJE_CORREO_F06;
			}
		}

		// Registrar solicitud
		if (!MaestrosUtilidades.isEmpty(codCargo) && !MaestrosUtilidades.isEmpty(codEstado)) {
			SolicitudProgramacion t10421 = t10421SolicProgDAO.findById(formulario.getNumSolicitud(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
			t10421.setCodEstadoSolicitud(codEstado);
			t10421.setFecModif(new Date());
			t10421.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			t10421.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			t10421SolicProgDAO.update(t10421, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			// Parseo
			SolicitudProgramacionBean bean = new SolicitudProgramacionBean();
			MaestrosUtilidades.copiarValoresBean(t10421, bean);

			// Registrar movimiento
			MovimientoSolicitud t10414 = new MovimientoSolicitud();
			t10414.setCodPersMov(formulario.getAuditoriaBean().getNroRegistro());
			t10414.setFecMovimiento(new Date());
			t10414.setNumSolicitud(formulario.getNumSolicitud());
			t10414.setNumMovimientoPrograma(t10414MovSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_MOVIMIENTO_SOLICITUD, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10414.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10414.setDesMotivoAsignacion(desMotivoAsignacion);
			t10414.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10414.setFecCrea(new Date());
			t10414.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10414.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10414.setCodCargo(codCargo);
			t10414MovSolicDAO.save(t10414, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			try {
				String codSolicitante = t10421.getCodSolicitante();
				String codSupervisor = t8303DistriGrupoDAO.obtenerSupervisorPersonal(codSolicitante);
				WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(codSolicitante);
				String dirReceptor = "";
				String dirCopia = "";
				if (!MaestrosUtilidades.isEmpty(solicitante)) {
					dirReceptor = solicitante.getDirCorreo().trim();
				}
				WSPersonalIqbfBean supervisor = servicioWebService.obtenerPersonalIqbf(codSupervisor);
				if (!MaestrosUtilidades.isEmpty(supervisor)) {
					dirCopia = supervisor.getDirCorreo().trim();
				}
				MensajeIqbf t8414 = t8414MensajeIqbfDAO.findById(codMensaje, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(t8414) && !MaestrosUtilidades.isEmpty(dirReceptor)) {
					Map<String, Object> parametros = new HashMap<String, Object>();
					parametros.put("numeroSolicitudProgramacion", AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
					CorreoBean correoBean = new CorreoBean();
					correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
					correoBean.setAsunto(t8414.getDesCorta());
					correoBean.setReceptor(dirReceptor);
					correoBean.setCopia(dirCopia);
					correoBean.setMensaje(AccionesControlUtil.generarMensaje(t8414.getDesCuerpo(), parametros));
					CorreoUtil.enviarCorreo(correoBean);
				}
			} catch(Exception e) {
				logger.error(String.format("errorEnviarCorreo %s", e.getMessage()), e);
			}
		}
		return formulario;
	}

}
