package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoDataAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PerfilRiesgos;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10391ArcProgramDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10445ArcAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10446ArcDataAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8048PerRieDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.MensajesExcepciones;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.BfRegistroBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoAsociacionBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSDomicilioRUCBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSRegistroRUCBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.ComunService;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.FileManagerService;
import pe.gob.sunat.iqbf3.registro.maestros.service.RegistroBfService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;


@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
@Local(CargaUsuarioBatchService.class)
public class CargaUsuarioBatchServiceImpl implements CargaUsuarioBatchService{

	private static final Logger logger = LoggerFactory.getLogger(CargaUsuarioBatchServiceImpl.class);
	
	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private ComunService comunService;

	@EJB
	private RegistroBfService registroBfService;
	
	@EJB
	private T10420ProgramacionDAO programacionDAO;
	
	@EJB
	private T10428UsuarioProgDAO usuarioProgDAO;

	@EJB
	private T8048PerRieDAO perfilRiesgoDAO;

	@EJB
	private T10391ArcProgramDAO archivoProgramacionDAO;
	
	@EJB
	private T10445ArcAcfDAO archivoAccionesDAO;

	@EJB
	private T10446ArcDataAcfDAO archivoDataAccionesDAO;
	
	@EJB
	private DataCatalogoService dataCatalogoService;
	
	@EJB
	private FileManagerService fileManagerService;
	/**
	 * Metodo que realiza la validacion del archivo cargado del CUS08
	 */
	public ResponseBean<String> validarArchivoCarga(Long	numProgramacion) {
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - validarArchivoCarga");

		ResponseBean<String> respuesta = new ResponseBean<>();
		byte[] archivo = obtenerArchivoProgramacion(numProgramacion);
		if (MaestrosUtilidades.isEmpty(archivo)) {
			respuesta.setExito(false);
			respuesta.setMensaje("No existe Archivo de programacion");
			return respuesta;
		}
		//ProgramacionBean bProgramacion, String rutaArchivo
		ProgramacionBean bProgramacion = new ProgramacionBean(); 
		String estado = AccionesControlConstantes.COD_EST_PROGRAM_EN_PROCESO_CARGA; // En proceso de carga
		
		bProgramacion.setCodEstadoPrograma(estado);
		bProgramacion.setNumProgramacion(numProgramacion);
		/** Actualizar el estado inicial de la programacion */
		actualizarEstadoProgramacion(bProgramacion);
		
		/** Procesar el archivo cargado */
		Map<String, Object> resultado = procesarArchivo(archivo);
		List<String> lstErrores = (List<String>) resultado.get("lstErrores");
		List<UsuarioProgramacionBean> lstUsrProgramacion = (List<UsuarioProgramacionBean>) resultado.get("lstUsrProgramacion");
		
		/** Verificar si existe error en la informacion cargada */
		String rutaErrores = "";
		if (!MaestrosUtilidades.isEmpty(lstErrores)) {
			rutaErrores = generarArchivoErrores(bProgramacion, lstErrores);
			respuesta.setData(rutaErrores);
			estado =  AccionesControlConstantes.COD_EST_PROGRAM_ERROR_CARGA; // Error en carga
			respuesta.setExito(false);
		}
		else if (!MaestrosUtilidades.isEmpty(lstUsrProgramacion)) {
			ingresarUsrProgramacion(lstUsrProgramacion, bProgramacion);
			estado = AccionesControlConstantes.COD_EST_PROGRAM_EJECUTADO; // Ejecutado
			bProgramacion.setPerFin(MaestrosUtilidades.dateToStringDDMMYYYY(new Date()));// fecha fin de programacion
			respuesta.setExito(true);
		}
		bProgramacion.setCodEstadoPrograma(estado);
		/** Actualizar el estado de la programacion*/
		actualizarEstadoProgramacion(bProgramacion);
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - validarArchivoCarga");
		
		return respuesta;
	}
	
	private Map<String, Object> procesarArchivo(byte[] archivo) {
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - procesarArchivo");
		
		Map<String, Object> resultado = new HashMap<String, Object>();
		if (MaestrosUtilidades.isEmpty(archivo)) {
			return resultado;
		}
		List<String> errores = new ArrayList<>();
		List<UsuarioProgramacionBean> lstUsrProgramacion = new ArrayList<>();
		UsuarioProgramacionBean usrProgr = new UsuarioProgramacionBean();

		//		try (FileInputStream file = new FileInputStream(new File(rutaArchivo))) {

		try (InputStream file = new ByteArrayInputStream(archivo)) {
			// leer archivo excel
			HSSFWorkbook  worbook = new HSSFWorkbook(file);
			//obtener la hoja que se va leer
			HSSFSheet  sheet = worbook.getSheetAt(0);
			//obtener todas las filas de la hoja excel
			Iterator<Row> rowIterator = sheet.iterator();

			Row row;
			String tipoDocu, numDocu, nomApe;
			int linea = 1;
			// se recorre cada fila hasta el final
			while (rowIterator.hasNext()) {
				row = rowIterator.next();
				//se obtiene las celdas por fila
				Iterator<Cell> cellIterator = row.cellIterator();
				Cell cell;
				//se recorre cada celda
				DataFormatter formatter = new DataFormatter();
				while (cellIterator.hasNext()) {
					// se obtiene la celda en espec�fico y se la imprime
					cell = cellIterator.next();
					tipoDocu = formatter.formatCellValue(cell);
					System.out.println("tipoDocu => " + MaestrosUtilidades.toBlank(tipoDocu));
					cell = cellIterator.next();
					numDocu = formatter.formatCellValue(cell);
					System.out.println("numDocu => " + MaestrosUtilidades.toBlank(numDocu));
                    cell = cellIterator.next();
                    nomApe = formatter.formatCellValue(cell);
					System.out.println("nomApe => " + MaestrosUtilidades.toBlank(nomApe));
                    List<String> listaError = new ArrayList<>();

                    if (MaestrosUtilidades.isEmpty(tipoDocu) && MaestrosUtilidades.isEmpty(numDocu) && 
                    		MaestrosUtilidades.isEmpty(nomApe)) {
                    	break;
                    }
                    
                    listaError = validarEstructuraDatos(String.valueOf(linea), tipoDocu, numDocu, nomApe);
                    
                    if (!listaError.isEmpty()){
                    	errores.addAll(listaError);	
                    }
                    
                    usrProgr = new UsuarioProgramacionBean();
                    usrProgr.setCodTipoDocumentoIdentif(tipoDocu);
                    usrProgr.setNumDocumentoIdentif(numDocu);
                    usrProgr.setNomApellidoUsuario(nomApe);
                    
                    lstUsrProgramacion.add(usrProgr);
                    
                    linea++;
				}
			}
			
			
		} catch (Exception e) {
			errores = Arrays.asList("Error al leer el archivo");
			logger.error(e.getMessage(), e);
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - procesarArchivo");

		resultado.put("lstErrores", errores);
		resultado.put("lstUsrProgramacion", lstUsrProgramacion);
		return resultado;
	}
	
	private int inactivarArchivoErrorProgramacion(Long numProgramacion)
	{
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - inactivarArchivoErrorProgramacion");
		
		int exito = 0;
		ArchivoDataAcciones bT10446ArcDataAcf = null; 
		
		// consulta a programacion 
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", numProgramacion);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		List<ArchivoProgramacion>  lstArchivoProgramacion = archivoProgramacionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);

		if (!MaestrosUtilidades.isEmpty(lstArchivoProgramacion)){
			for(ArchivoProgramacion bArchivoProgramacion : lstArchivoProgramacion){
				propertyParams = new PropertyParams();
				
				propertyParams.addProperty("numArc", bArchivoProgramacion.getNumArchivo());
				propertyParams.addProperty("codTipoArchivo", AccionesControlConstantes.COD_TIP_ARC_ERROR_CARGA_USUARIO);
				propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
				
				List<ArchivoAcciones>  lstArchivoAcciones = archivoAccionesDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				
				if (!MaestrosUtilidades.isEmpty(lstArchivoAcciones)){
					ArchivoAcciones archivoAcciones = lstArchivoAcciones.get(0);
					bT10446ArcDataAcf = archivoDataAccionesDAO.findById(archivoAcciones.getNumArc(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
					
					if (!MaestrosUtilidades.isEmpty(bT10446ArcDataAcf)){
						//actualizar las tres tablas a inativo
						bT10446ArcDataAcf.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
						bT10446ArcDataAcf.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
						
						bT10446ArcDataAcf.setFecModif(new Date());
						bT10446ArcDataAcf.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
						bT10446ArcDataAcf.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);

						archivoDataAccionesDAO.update(bT10446ArcDataAcf, AccionesControlConstantes.DATASOURCE_DGSICOBF);
						
						archivoAcciones.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
						archivoAcciones.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
						
						archivoAcciones.setFecModif(new Date());
						archivoAcciones.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
						archivoAcciones.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
						
						archivoAccionesDAO.update(archivoAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
						
						bArchivoProgramacion.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
						bArchivoProgramacion.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
						
						bArchivoProgramacion.setFecModif(new Date());
						bArchivoProgramacion.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
						bArchivoProgramacion.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
						
						archivoProgramacionDAO.update(bArchivoProgramacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
						
						exito = 1;
					}
				}
			}
		}
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - inactivarArchivoErrorProgramacion");
		
		return exito;
	}
	
	private int registrarArchivoErrorProgramacion(ProgramacionBean bProgramacion, ArchivoBean archivo){
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - registrarArchivoErrorProgramacion");
		
		int exito = 0;
		
		// archivo: SEARCACF
		ArchivoAcciones arcAcc = new ArchivoAcciones(); 
		Long secArcAcci = archivoAccionesDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ARCHIVOS_ACCIONES, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		arcAcc.setNumArc(secArcAcci);
		arcAcc.setCodTipoArchivo(AccionesControlConstantes.COD_TIP_ARC_ERROR_CARGA_USUARIO);
		arcAcc.setNombArchivoAcciones(archivo.getNomArchivo());
		arcAcc.setDesMimeType(archivo.getDesMimeType());
		arcAcc.setCntPesoArc(archivo.getCntPesArch());

		arcAcc.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		arcAcc.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		arcAcc.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
		arcAcc.setFecCrea(new Date());
		arcAcc.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
		
		
        archivoAccionesDAO.save(arcAcc, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
        // archivo data : SEARCDATAACF
        ArchivoDataAcciones arcDataAcciones = new ArchivoDataAcciones();
        arcDataAcciones.setNumArchAcciones(secArcAcci);
        arcDataAcciones.setArchivoContenido(archivo.getBlob());

        arcDataAcciones.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
        arcDataAcciones.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
        arcDataAcciones.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
        arcDataAcciones.setFecCrea(new Date());
        arcDataAcciones.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
        
        archivoDataAccionesDAO.save(arcDataAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
        
        // archivo programacion : SEARCPROGRAM SECUENCIA_ARCHIVOS_PROGRAMACION
        ArchivoProgramacion archProgra = new ArchivoProgramacion();
        Long secArcProgra = archivoProgramacionDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ARCHIVOS_PROGRAMACION, AccionesControlConstantes.DATASOURCE_DCSICOBF);
        
        archProgra.setNumArchivoProgram(secArcProgra);
        archProgra.setNumProgramacion(bProgramacion.getNumProgramacion());
        archProgra.setNumArchivo(secArcAcci);

        archProgra.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
        archProgra.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
        archProgra.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
        archProgra.setFecCrea(new Date());
        archProgra.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);

        
        archivoProgramacionDAO.save(archProgra, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
        if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - registrarArchivoErrorProgramacion");
        
		return exito;
	}
	
	private String generarArchivoErrores(ProgramacionBean bProgramacion, List<String> lstErrores){
		
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - generarArchivoErrores");
		
		String ruta = StringUtils.EMPTY;
		String nomArchivo = StringUtils.EMPTY;
		try{
			ArchivoBean archivo = new ArchivoBean() ;
			inactivarArchivoErrorProgramacion(bProgramacion.getNumProgramacion());
			
			//ERROR_CARGA_DDMMYYYY_HHMMSS.txt
	        /** String sfechaHoy = fechaHoy.getFormatDate("yyyyMMddHHmmss"); */
			String sfechaHoy =  MaestrosUtilidades.dateToString(new Date(), "ddMMyyyyHHmmss");
			
			nomArchivo = AccionesControlConstantes.NOM_ARCHIVO_ERROR.replace("{1}", sfechaHoy);
			
			ruta =  MaestrosConstantes.URL_TEMP + nomArchivo;
			
			Path path = Paths.get(ruta);
			
			Files.write(path, lstErrores, Charset.defaultCharset());
			
			byte[] archivoBite = fileManagerService.descargarArchivoTemporal(nomArchivo);
			archivo.setBlob(archivoBite);
			archivo.setNomArchivo(nomArchivo);
			archivo.setDesMimeType("application/text-plain");
			archivo.setCntPesArch( archivoBite.length*1.0 );
			
			registrarArchivoErrorProgramacion(bProgramacion, archivo);
			
		}catch(Exception e) {
			logger.error(e.getMessage(), e);
			return StringUtils.EMPTY;
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - generarArchivoErrores");
		
		return ruta;
	}
	
	private byte[] obtenerArchivoProgramacion(Long numProgramacion){
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - obtenerArchivoProgramacion");
		
		
		byte[] ruta = null ;
		ArchivoDataAcciones bT10446ArcDataAcf = null; 
		
		// consulta a programacion 
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", numProgramacion);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		List<ArchivoProgramacion>  lstArchivoProgramacion = archivoProgramacionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(lstArchivoProgramacion)){
			for(ArchivoProgramacion bArchivoProgramacion : lstArchivoProgramacion){
				propertyParams = new PropertyParams();
				
				propertyParams.addProperty("numArc", bArchivoProgramacion.getNumArchivo());
				propertyParams.addProperty("codTipoArchivo", AccionesControlConstantes.COD_TIP_ARC_CARGA_USUARIO);
				propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
				
				List<ArchivoAcciones>  lstArchivoAcciones = archivoAccionesDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				
				if (!MaestrosUtilidades.isEmpty(lstArchivoAcciones)){
					ArchivoAcciones archivoAcciones = lstArchivoAcciones.get(0);
					bT10446ArcDataAcf = archivoDataAccionesDAO.findById(archivoAcciones.getNumArc(), AccionesControlConstantes.DATASOURCE_DGSICOBF);

					if (!MaestrosUtilidades.isEmpty(bT10446ArcDataAcf)) {
						ruta = bT10446ArcDataAcf.getArchivoContenido();
					}

					// Eliminar archivo
					archivoAcciones.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
					archivoAcciones.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
					archivoAcciones.setFecModif(new Date());
					archivoAcciones.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					archivoAcciones.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					archivoAccionesDAO.update(archivoAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					// Eliminar archivo
					bT10446ArcDataAcf.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
					bT10446ArcDataAcf.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
					bT10446ArcDataAcf.setFecModif(new Date());
					bT10446ArcDataAcf.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					bT10446ArcDataAcf.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					archivoDataAccionesDAO.update(bT10446ArcDataAcf, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					
					bArchivoProgramacion.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
					bArchivoProgramacion.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
					bArchivoProgramacion.setFecModif(new Date());
					bArchivoProgramacion.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					bArchivoProgramacion.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					archivoProgramacionDAO.update(bArchivoProgramacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - obtenerArchivoProgramacion");
		
		return ruta;
	}
	
	private void validarDniRuc(String fila, String tipDoc, String numDoc, List<String> errores){
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - validarDniRuc");
		
		if( !numDoc.matches("\\d+")){
			errores.add(MensajesExcepciones.CUS08_EXCP_003.replace("Fila n:", fila));  // E3
		}else if(MaestrosConstantes.TIPO_DOCUMENTO_DNI.equals(tipDoc)){
			if ((numDoc.length() != 8)){
				errores.add(MensajesExcepciones.CUS08_EXCP_004.replace("Fila n:", fila) );  // E4
			} else if (!existeDNI(numDoc)){
				errores.add(MensajesExcepciones.CUS08_EXCP_005.replace("Fila n:", fila));  // E5
			}
		}else if (MaestrosConstantes.TIPO_DOCUMENTO_RUC.equals(tipDoc)){
			if ((numDoc.length() != 11)){
				errores.add(MensajesExcepciones.CUS08_EXCP_004.replace("Fila n:", fila));  // E4
			}else if (!existeRUC(numDoc)){
				errores.add(MensajesExcepciones.CUS08_EXCP_005.replace("Fila n:", fila));  // E5
			}
		}

		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - validarDniRuc");
	}
	
	private boolean existeDNI(String numDoc){
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - existeDNI");
		
		boolean existeDni = false;
		
		if (servicioWebService.obtenerPersonaDNI(numDoc) == null){
			existeDni = true;
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - existeDNI");
		
		return existeDni;
	}
	
	private boolean existeRUC(String numDoc){
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - existeRUC");
		
		boolean existeRuc = false;
		
		if (!MaestrosUtilidades.isEmpty(servicioWebService.obtenerRegistroRuc(numDoc))) {
			existeRuc = true;
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - existeRUC");
		
		return existeRuc;
	}
	
	private List<String> validarEstructuraDatos(String linea, String tipDoc, String numDoc, String nomApe){

		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - validarEstructuraDatos");
		
		List<String> errores = new ArrayList<>();
		String fila = String.format("Fila %s: ", linea);

		if(MaestrosUtilidades.isEmpty(tipDoc)){
			errores.add(MensajesExcepciones.CUS08_EXCP_001.replace("Fila n:", fila) ); // E1
		}
		
		if(MaestrosUtilidades.isEmpty(numDoc)){
			errores.add(MensajesExcepciones.CUS08_EXCP_002.replace("Fila n:", fila));  // E2
		}else if ( MaestrosConstantes.TIPO_DOCUMENTO_DNI.equals(tipDoc) || 
				   MaestrosConstantes.TIPO_DOCUMENTO_RUC.equals(tipDoc)  )
		{
			validarDniRuc(fila, tipDoc, numDoc, errores);
		}
		
		if (!(MaestrosConstantes.TIPO_DOCUMENTO_DNI.equals(tipDoc) ||  
			  MaestrosConstantes.TIPO_DOCUMENTO_RUC.equals(tipDoc) ) )
		{
			if( MaestrosUtilidades.isEmpty(nomApe)){
				errores.add(MensajesExcepciones.CUS08_EXCP_006.replace("Fila n:", fila)); // E6
			}else if (nomApe.length()< 5 ){
					errores.add(MensajesExcepciones.CUS08_EXCP_007.replace("Fila n:", fila) ); // E7
			}
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - validarEstructuraDatos");
		
		return errores;
	}
		
	public int actualizarEstadoProgramacion(ProgramacionBean bProgramacion){
		if (logger.isWarnEnabled())
			logger.warn("Inicio GestionProgramaOtrosServiceImpl - actualizarEstadoProgramacion");

		String sfechaHoy = MaestrosUtilidades.dateToString(new Date(), MaestrosConstantes.FORMAT_FECHAHORA_DDMMYYYYHHMMSS);

		Programacion programacion = programacionDAO.findById(bProgramacion.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DCSICOBF);

		programacion.setCodEstadoPrograma(bProgramacion.getCodEstadoPrograma());
		//programacion.setPerFin(MaestrosUtilidades.dateToStringDDMMYYYY(new Date()));
		programacion.setFecModif(new Date());
		programacion.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
		programacion.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
		
		programacion = programacionDAO.update(programacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
		if (logger.isDebugEnabled())
			logger.debug("Fin GestionProgramaOtrosServiceImpl - actualizarEstadoProgramacion");
		return 1;
	}
	
	private int ingresarUsrProgramacion(List<UsuarioProgramacionBean> lstUsrProgramacion, ProgramacionBean bProgramacion){
		if (logger.isWarnEnabled())
			logger.warn("Inicio GestionProgramaOtrosServiceImpl - ingresarUsrProgramacion");
		UsuarioProgramacion usrProgr;
		
		for(UsuarioProgramacionBean bUsrProgra: lstUsrProgramacion){
			
			usrProgr = new UsuarioProgramacion();
			
            usrProgr.setCodTipoDocumentoIdentif(bUsrProgra.getCodTipoDocumentoIdentif());
            usrProgr.setNumDocumentoIdentif(bUsrProgra.getNumDocumentoIdentif());
            
            if (!(MaestrosConstantes.TIPO_DOCUMENTO_RUC.equals(bUsrProgra.getCodTipoDocumentoIdentif()) ||
            		MaestrosConstantes.TIPO_DOCUMENTO_DNI.equals(bUsrProgra.getCodTipoDocumentoIdentif())
            	))
            {
            	usrProgr.setNomApellidoUsuario(bUsrProgra.getNomApellidoUsuario());	
            }
            
            if (MaestrosConstantes.TIPO_DOCUMENTO_RUC.equals(bUsrProgra.getCodTipoDocumentoIdentif())) {
            	
            	UsuarioProgramacionBean usrProgrVal = new UsuarioProgramacionBean();

            	usrProgrVal = obtenerTipoAccionSugerida(bUsrProgra.getNumDocumentoIdentif());
            	
            	usrProgr.setCodTipoAccionSugerida(usrProgrVal.getCodTipoAccionSugerida());
            	usrProgr.setCodNivelRiesgo(usrProgrVal.getCodNivelRiesgo());
            	
            	WSRegistroRUCBean regBeanRuc = servicioWebService.obtenerRegistroRuc(bUsrProgra.getNumDocumentoIdentif());
            	usrProgr.setCodDependencia(regBeanRuc.getDdpNumreg()); // consultar la dependencia
                
            }else{
            	usrProgr.setCodTipoAccionSugerida(AccionesControlConstantes.COD_TIP_ACCION_VISITA_NO_PROGRAMADA);
            }
            
            
            //numUsuarioPrograma
            Long secUsrProgr = usuarioProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_USUARIO_FISCALIZABLE, AccionesControlConstantes.DATASOURCE_DCSICOBF);
            usrProgr.setNumUsuarioPrograma(secUsrProgr);
            usrProgr.setNumProgramacion(bProgramacion.getNumProgramacion());
            usrProgr.setCodTipoIntervencion(obtenerCodigoTipoIntervencion(usrProgr.getCodTipoAccionSugerida()));
            usrProgr.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
            usrProgr.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
            usrProgr.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
            usrProgr.setFecCrea(new Date());
            usrProgr.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
            
            usuarioProgDAO.save(usrProgr, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin GestionProgramaOtrosServiceImpl - ingresarUsrProgramacion");
		
		return 1;
	}
	
	private String obtenerCodigoTipoIntervencion(String codTipoAccionSugerida){
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - obtenerCodigoTipoIntervencion");
		
		String codTipoIntervencion = "";
		
		DataCatalogoAsociacionBean dataCatalogo = new DataCatalogoAsociacionBean();

		dataCatalogo.setCodAsocCat(MaestrosConstantes.COD_CATALOGO_TIPO_INTERVENCION);
		dataCatalogo.setCodigoDataCatalogoAsoc(codTipoAccionSugerida);
		dataCatalogo = dataCatalogoService.obtenerCatalogo(dataCatalogo);
		codTipoIntervencion = dataCatalogo.getCodigoDataCatalogo();
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - obtenerCodigoTipoIntervencion");
		
		
		return codTipoIntervencion;
		
	}
	
	private UsuarioProgramacionBean obtenerTipoAccionSugerida(String numDoc){
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - obtenerTipoAccionSugerida");
		
		UsuarioProgramacionBean usrProgrVal = new UsuarioProgramacionBean();
		String codTipoAccionSugerida = AccionesControlConstantes.COD_TIP_ACCION_VISITA_NO_PROGRAMADA;
		usrProgrVal.setCodTipoAccionSugerida(codTipoAccionSugerida);
		/**Para los usuarios con tipo de documento RUC inscritos en el RCBF*/
		BfRegistroBean bfRegistroBean =  registroBfService.obtenerRegistroBf(numDoc, null);

		if (!MaestrosUtilidades.isEmpty(bfRegistroBean)) {
			PropertyParams propertyParams = new PropertyParams();
			//se determina el tipo de acci�n sugerida seg�n el ubigeo del domicilio fiscal y el nivel de riesgo.
			WSDomicilioRUCBean wsDomicilioRUCBean = servicioWebService.obtenerDomicilioFiscal(numDoc);
			if (!MaestrosUtilidades.isEmpty(wsDomicilioRUCBean)) {
				//15 es el departamento de lima
				String codUbigeoDepa = wsDomicilioRUCBean.getCodUbigeo().substring(0,2); 
				
				// nivel de riesgo
				propertyParams.addProperty("codTipoDocumentoIdent", MaestrosConstantes.TIPO_DOCUMENTO_RUC);
				propertyParams.addProperty("numDocumentoIdentif", numDoc);
				
				List<PerfilRiesgos> t8048Lista = perfilRiesgoDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				
				if (!MaestrosUtilidades.isEmpty(t8048Lista)) {
					PerfilRiesgos bPerfilRiesgoRuc = t8048Lista.get(0);
					
					Integer nivRiesgo = bPerfilRiesgoRuc.getIndNivrie();
					codTipoAccionSugerida = obtenerTipoAccionSugerida(codUbigeoDepa, nivRiesgo);
					usrProgrVal.setCodTipoAccionSugerida(codTipoAccionSugerida);
					usrProgrVal.setCodNivelRiesgo(String.valueOf(nivRiesgo));
				}
			}
			
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - obtenerTipoAccionSugerida");
		
		return usrProgrVal;
	}
	
	private String obtenerTipoAccionSugerida(String codUbigeoDepa, Integer nivRiesgo){
		
		if (logger.isWarnEnabled())
			logger.warn("Inicio CargaUsuarioServiceImpl - obtenerTipoAccionSugerida");
		
		String tipoAccionSugerida;
		String sNivRiesgo = "0" + String.valueOf(nivRiesgo);
		
		DataCatalogoAsociacionBean dataCatalogo = new DataCatalogoAsociacionBean();
		
		if (AccionesControlConstantes.COD_UBIG_DEPA_LIMA.equals(codUbigeoDepa))
		{
			dataCatalogo.setCodAsocCat(MaestrosConstantes.TIPO_PARAMETRO_UBIGEO_LIMA_CALLAO);
			dataCatalogo.setCodigoDataCatalogo(sNivRiesgo);
			dataCatalogo = dataCatalogoService.obtenerCatalogoAsociacion(dataCatalogo);
			tipoAccionSugerida = dataCatalogo.getCodigoDataCatalogoAsoc();
		}else{
			dataCatalogo.setCodAsocCat(MaestrosConstantes.TIPO_PARAMETRO_UBIGEO_PROVINCIA);
			dataCatalogo.setCodigoDataCatalogo(sNivRiesgo);
			dataCatalogo = dataCatalogoService.obtenerCatalogoAsociacion(dataCatalogo);
			tipoAccionSugerida = dataCatalogo.getCodigoDataCatalogoAsoc();
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin CargaUsuarioServiceImpl - obtenerTipoAccionSugerida");
		
		
		return tipoAccionSugerida;
	}
}
