package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CabezeraCpeBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DeclaracionesJuradasBfBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PerfilRiesgosBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenSaldoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenStockEstablecBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioRegistroBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CabezeraCpe;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DeclaracionesJuradasBf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PerfilRiesgos;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaGreNC;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaSaldo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaStock;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenSaldo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenStockEstablec;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10417ProIncoGreNCDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10418ProIncoSaldoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10419ProIncoStockDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T4241CabCpeDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5284BfCabJroDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5641RStockEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5642RSaldoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8048PerRieDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.bean.BfRegistroBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSDomicilioRUCBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSRegistroRUCBean;
import pe.gob.sunat.iqbf3.registro.maestros.model.BfRegistro;
import pe.gob.sunat.iqbf3.registro.maestros.service.RegistroBfService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class DeterminarSeleccionUsuariosBatchServiceImpl implements DeterminarSeleccionUsuariosBatchService {
//CUS23
	private static final Logger logger = LoggerFactory.getLogger(DeterminarSeleccionUsuariosBatchServiceImpl.class);
	
	@EJB
	private CargaUsuarioBatchService cargaUsuarioBatchService;
	
	@EJB
	private T10420ProgramacionDAO programacionDAO;
	
	@EJB
	private T5284BfCabJroDAO t5284BfCabJroDAO;
	
	@EJB
	private T5641RStockEstabDAO t5641RStockEstabDAO;

	@EJB
	private T4241CabCpeDAO t4241CabCpeDAO;
	
	@EJB
	private ServicioWebService servicioWebService;
	
	@EJB
	private T8048PerRieDAO t8048PerRieDAO;
	
	@EJB
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;
	
	@EJB
	private T10419ProIncoStockDAO t10419ProIncoStockDAO;
	
	@EJB
	private T5642RSaldoDAO t5642RSaldoDAO;
	
	@EJB
	private T10418ProIncoSaldoDAO t10418ProIncoSaldoDao; 
	
	@EJB
	private T10417ProIncoGreNCDAO t10417ProIncoGreNCDAO;
	
	@EJB
	private RegistroBfService registroBfService;
	
	public ResponseBean<String> iniciarProcesamiento(Long numProgramacion) {
		if (logger.isWarnEnabled())
			logger.warn("Inicio DeterminarSeleccionUsuariosBatchServiceImpl - iniciarProcesamiento");
		
		ResponseBean<String> respuesta = new ResponseBean<>();
		ProgramacionBean bProgramacion = new ProgramacionBean(); 
		int cntProcesamiento = 0;
		try{
			bProgramacion.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_EN_PROCESO_SELECCION);
			bProgramacion.setNumProgramacion(numProgramacion);
			/** Actualizar el estado inicial de la programacion */
			cargaUsuarioBatchService.actualizarEstadoProgramacion(bProgramacion);
			
			Programacion programacion = programacionDAO.findById(numProgramacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			
		//-	Determinar los usuarios e inconsistencias de acuerdo al tipo de programa de control:
			//-	Para el CodProgramaControl = constantes.COD_TIP_PROG_OMISOS_DJ  se invocado
			if(AccionesControlConstantes.COD_TIP_PROG_OMISOS_DJ.equals(programacion.getCodProgctrl())) {
				cntProcesamiento = procesarProgramaControlOmisosDj(bProgramacion);
			}
	
			//-	Para el CodProgramaControl = constantes.COD_TIP_PROG_USU_VIGENTES_STOCK_SALDO_NEGATIVO  se invocado
			if(AccionesControlConstantes.COD_TIP_PROG_USU_VIGENTES_STOCK_SALDO_NEGATIVO.equals(programacion.getCodProgctrl())){
				cntProcesamiento = procesarProgramaStockSaldoNegativo(bProgramacion);
			}
			
			if(AccionesControlConstantes.COD_TIP_PROG_USU_BAJA_STOCK.equals(programacion.getCodProgctrl())){
				cntProcesamiento = procesarProgramaControlBajaOmisoStockNegativo(bProgramacion);
			}
			
			if(AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_DESTINATARIO.equals(programacion.getCodProgctrl())){
				cntProcesamiento = procesarProgramaControlGreNoConfirmadasDestinatario(bProgramacion);
			}
			
			//-	Para el CodProgramaControl = constantes.COD_TIP_PROG_GRE_NOCONFIMADAS_TRANSPORTISTA  se invocado 
			if(AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_TRANSPORTISTA.equals(programacion.getCodProgctrl())){
				bProgramacion.setPerFin(programacion.getPerFin());
				bProgramacion.setPerInicio(programacion.getPerInicio());
				cntProcesamiento = procesarProgramaControlGreNoConfirmadasTransportista(bProgramacion);
			 }
		
		
		//	Culminado el procesamiento la programaci�n del programa de control definido
			String codEstado = null;
			if(cntProcesamiento > 0){
				codEstado = AccionesControlConstantes.COD_EST_PROGRAM_SELECCION_PROCESADA;
			}
			if(cntProcesamiento == 0 ){
				codEstado = AccionesControlConstantes.COD_EST_PROGRAM_SIN_USUR_SELECCIONADOS;
			}
			if (codEstado != null){
				bProgramacion.setCodEstadoPrograma(codEstado);
				cargaUsuarioBatchService.actualizarEstadoProgramacion(bProgramacion);
			}
		
		} catch(Exception e) {
			logger.error(e.getMessage(), e);
			bProgramacion.setCodEstadoPrograma(AccionesControlConstantes.COD_ESTADO_PROG_ERRORSELECCION);
			cargaUsuarioBatchService.actualizarEstadoProgramacion(bProgramacion);
		}
		if (logger.isDebugEnabled())
			logger.debug("Fin DeterminarSeleccionUsuariosBatchServiceImpl - iniciarProcesamiento");
		
		return respuesta;
	}
	
	private int procesarProgramaControlBajaOmisoStockNegativo(ProgramacionBean bProgramacion){
		if (logger.isWarnEnabled())
			logger.warn(
					"Inicio DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaControlBajaOmisoStockNegativo");
		
		int cntProcesamiento = 0;
		List<String> lstEstadoUsuario;

		BfRegistroBean bfRegistroBean = new BfRegistroBean();
		bfRegistroBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		bfRegistroBean.setCodEstadoBaja(AccionesControlConstantes.COD_ESTADO_REGISTRO_DEBAJA);
		
		List<BfRegistro> lstUsuarioInconsistencia = registroBfService.listaUsuarioBaja(bfRegistroBean);
		
		String numPeridoomisomin = "";
		String numPperidoomisomax = ""; 
				
		if (!MaestrosUtilidades.isEmpty(lstUsuarioInconsistencia)) {
			for( BfRegistro bfRegistro: lstUsuarioInconsistencia ){
				//Para verificar si el usuario se encuentra omiso invocar:
				bfRegistroBean = new BfRegistroBean();
				bfRegistroBean.setNumRuc(bfRegistro.getBfregistroPk().getNumRuc());
				bfRegistroBean.setCodEstado(AccionesControlConstantes.COD_ESTADO_DJROP_PENDIENTE);//cCodEstadoPendiente
				bfRegistroBean.setNumConfirma(AccionesControlConstantes.NUM_CONFIRMACION_SIN_ENVIO );
				lstEstadoUsuario = new ArrayList<>();
				lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
				lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
				bfRegistroBean.setLstEstadoUsuario(lstEstadoUsuario);
				bfRegistroBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				bfRegistroBean.setIndOmiso(AccionesControlConstantes.COD_ESTADO_DJROP_EXONERADO_DEL_MES);
				
				List<BfRegistro> lstUsrRegistro = registroBfService.cntOmiso(bfRegistroBean);
				Integer cntOmiso = lstUsrRegistro.size();
				//Para verificar si tiene stock negativo 

				ResumenStockEstablecBean resumenStockEstablecBean = new ResumenStockEstablecBean();
				resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_ESTADO_REGISTRO_DEBAJA);
				resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
				resumenStockEstablecBean.setNumRuc(Integer.valueOf(bfRegistro.getBfregistroPk().getNumRuc()));
				resumenStockEstablecBean.setCodTipobien(AccionesControlConstantes.COD_TIPOBIEN_REGISTRO);
				List<ResumenStockEstablec> lstStockNegativo =  t5641RStockEstabDAO.cntStockNegativoBaja(resumenStockEstablecBean);
				
				Integer cntStockNegativo = lstStockNegativo.size();
				
				//Setea el tipo de inconsistencia para el usuario seg�n las siguientes condiciones:
				String codTipInconsis=	obtenerTipoIncosistenciaBaja(cntOmiso, cntStockNegativo);
				/*
				if(cntOmiso>0 || cntStockNegativo>0){
					if(cntOmiso>0 && cntStockNegativo>0){
						codTipInconsis = AccionesControlConstantes.COD_TIPO_INCON_BAJA_STOCK_OMISO;
					}else if (cntOmiso  > 0 &&  cntStockNegativo == 0){
						codTipInconsis = AccionesControlConstantes.COD_TIPO_INCON_BAJA_OMISO;
					}else if(cntOmiso  == 0 && cntStockNegativo > 0 ){
						codTipInconsis = AccionesControlConstantes.COD_TIPO_INCON_BAJA_STOCK;
					}
					 //Obtiene los datos del usuario omiso 
				}
				*/
				
				DeclaracionesJuradasBf bDeclaJurBfOmision = new DeclaracionesJuradasBf();
				if (cntOmiso>0){
					// insertar el detalle de la inconsistencia 
					
					DeclaracionesJuradasBfBean declaracionesJuradasBfBean = new DeclaracionesJuradasBfBean();
					
					declaracionesJuradasBfBean.setCodEstado(AccionesControlConstantes.COD_ESTADO_DJROP_PENDIENTE);
					declaracionesJuradasBfBean.setNumConfirma(AccionesControlConstantes.NUM_CONFIRMACION_SIN_ENVIO);
					declaracionesJuradasBfBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					declaracionesJuradasBfBean.setIndOmiso(AccionesControlConstantes.COD_ESTADO_DJROP_EXONERADO_DEL_MES);
					declaracionesJuradasBfBean.setNumVersionRegistro(bfRegistro.getBfregistroPk().getNumVerreg().intValue());
					declaracionesJuradasBfBean.setNumRuc(Integer.valueOf(bfRegistro.getBfregistroPk().getNumRuc()));
					
					List<DeclaracionesJuradasBf>  lstDeclaracionesJuradasBf = t5284BfCabJroDAO.periodosOmisosPorUsuario(declaracionesJuradasBfBean);
					
					if (!MaestrosUtilidades.isEmpty(lstDeclaracionesJuradasBf)) {
						bDeclaJurBfOmision = lstDeclaracionesJuradasBf.get(0);
						numPeridoomisomin = bDeclaJurBfOmision.getMinPeriodo();
						numPperidoomisomax = bDeclaJurBfOmision.getMaxPeriodo(); 
					}
				}
				
				List<ResumenStockEstablec> listInconsistenciasStock = new ArrayList<>();
				
				if (cntStockNegativo > 0){
					 //obtiene las presentaciones con stock negativo
					ResumenStockEstablecBean rsmStockEstablecBean = new ResumenStockEstablecBean();
					rsmStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					rsmStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_ESTADO_REGISTRO_DEBAJA);
					rsmStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
					rsmStockEstablecBean.setNumRuc(Integer.valueOf(bfRegistro.getBfregistroPk().getNumRuc()));
					rsmStockEstablecBean.setNumVersionRegistro(bfRegistro.getBfregistroPk().getNumVerreg().intValue());
					rsmStockEstablecBean.setCodTipobien(bfRegistro.getBfregistroPk().getCodTipbien());

					 listInconsistenciasStock = t5641RStockEstabDAO.listarStockNegativoBaja(resumenStockEstablecBean);
					
					cntStockNegativo = listInconsistenciasStock.size();
				}
				
				 //	Inserta los datos del usuario:

					UsuarioRegistroBean datosUsuarioBean = datosUsuario(String.valueOf(bfRegistro.getBfregistroPk().getNumRuc() ));
				/*
					Params
						num_programacion = programacion.num_programacion
						cod_tip_docident = UsuarioInconsistencia.tipoDocumento
						num_doc_ident= UsuarioOmiso.numDcumento
						num_verreg = DatosUsuarioBean.numVerreg
						fec_fin_vigencia = DatosUsuarioBean.fecFinvigencia
						cod_est_reg = DatosUsuarioBean.codEstado
						cod_ubi_domfiscal= DatosUsuarioBean.codUbigeo
						cod_nivel_riesgo = DatosUsuarioBean.NivelRiesgo
						cod_dependencia= DatosUsuarioBean.dependencia
					cod_tip_accion = constantes.COD_TIP_ACCION_CARTA
						cod_tip_interv = constantes.COD_TIP_INTERVENCION_CONTROL
						cod_tip_intervsuge= constantes.COD_TIP_ACCION_CARTA
						cod_tip_accsuge = constantes.COD_TIP_INTERVENCION_CONTROL
						cod_est_usu= constantes. COD_ESTADO_USUARIO_CARGADO
						cod_tip_inconsis = codTipInconsis
						num_peridoomisomin = numPeridoomisomin
						num_peridoomisomax= numPperidoomisomax
					
					numUsuProgram = t10428usuarioprogDAO.insertUsuarioProg(Params)
				*/
					UsuarioProgramacion usrProgr = new UsuarioProgramacion();
		            Long secUsrProgr = t10428UsuarioProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_USUARIO_FISCALIZABLE, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		            
		            usrProgr.setNumUsuarioPrograma(secUsrProgr);
		            usrProgr.setNumProgramacion(bProgramacion.getNumProgramacion());
		            usrProgr.setCodTipoDocumentoIdentif(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC);
		            usrProgr.setNumDocumentoIdentif(String.valueOf(bDeclaJurBfOmision.getNumRuc() ));
		          usrProgr.setNumVersionRegistro(datosUsuarioBean.getNumVerreg() );//
		          usrProgr.setFecFinVigencia(datosUsuarioBean.getFecFinvigencia());
		          usrProgr.setCodEstadoRegistro(datosUsuarioBean.getCodEstado());
		            usrProgr.setCodUbigeoDomicilioFiscal(datosUsuarioBean.getWsDomicilioRucBean().getCodUbigeo());
		            usrProgr.setCodNivelRiesgo(String.valueOf(datosUsuarioBean.getNivelRiesgo()));		
		            usrProgr.setCodDependencia(datosUsuarioBean.getRegBeanRuc().getDdpNumreg());// codigo de dependencia
		            usrProgr.setCodTipoAccion(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
		            usrProgr.setCodTipoIntervencion(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
		            usrProgr.setCodTipoIntervencionSugerida(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
		            usrProgr.setCodTipoAccionSugerida(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
		            usrProgr.setCodEstadoUsuario(AccionesControlConstantes.COD_ESTADO_USUARIO_CARGADO);
		            usrProgr.setCodTipInconsis(codTipInconsis);
		            usrProgr.setNumPeridoomisomax(numPperidoomisomax);
		            usrProgr.setNumPeridoomisomin(numPeridoomisomin);

		            /*
						num_verreg = DatosUsuarioBean.numVerreg
						fec_fin_vigencia = DatosUsuarioBean.fecFinvigencia
						cod_est_reg = DatosUsuarioBean.codEstado
		             * 
		             */
		            
		            usrProgr.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
		            usrProgr.setFecCrea(new Date());
		            usrProgr.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
		            
		            t10428UsuarioProgDAO.save(usrProgr, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					
		            for(ResumenStockEstablec resumenStockEstablec :listInconsistenciasStock){
		            	ProgramaIncosistenciaStock progIncoStock = new ProgramaIncosistenciaStock();
			            
			            Long seProIncoStock = t10419ProIncoStockDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_PROGRAM_INCONSISTOCK, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			            
			            progIncoStock.setNumIncosistenciaStock(seProIncoStock);
			            progIncoStock.setNumEstablecimiento(Long.parseLong(resumenStockEstablec.getNumEstablecimiento()));
			            progIncoStock.setNumVersionEstablecimiento(resumenStockEstablec.getNumVersionEstab());
			            progIncoStock.setNumInsumoCabecera(resumenStockEstablec.getNumInscab());
			            progIncoStock.setCodTipprod(resumenStockEstablec.getCodTipProd());
			            progIncoStock.setCodBienFiscalizado(resumenStockEstablec.getCodBienFisca());
			            progIncoStock.setCodInsumo(resumenStockEstablec.getCodInsumo());
			            progIncoStock.setNumOrden(resumenStockEstablec.getNumOrden());
			            progIncoStock.setNumVersionInsumo(resumenStockEstablec.getNumVersionCabInsumo());
			            progIncoStock.setCodUnidadMedida(resumenStockEstablec.getCodUm());
			            progIncoStock.setDesNombreComercial(resumenStockEstablec.getDesNomComProd());
			            progIncoStock.setDesNombreProducto(resumenStockEstablec.getDesNomProd());
			            progIncoStock.setPorMinInsumo(resumenStockEstablec.getPorMin().doubleValue());
			            progIncoStock.setPorMaxInsumo(resumenStockEstablec.getPorMax().doubleValue());
			            progIncoStock.setNumPresentacion(resumenStockEstablec.getNumPresentacion());
			            progIncoStock.setNumVersionPressentacion(resumenStockEstablec.getNumVersionPressentacion());
			            progIncoStock.setCodPresen(resumenStockEstablec.getCodPresen());
			            progIncoStock.setCodUnidadComercial(resumenStockEstablec.getCodUnidadComercial());
			            progIncoStock.setCodUnidadFiscal(resumenStockEstablec.getCodUnidadFiscal());
			            progIncoStock.setCantidadUnidadFisica(resumenStockEstablec.getCantidadUnidadFisica());
			            progIncoStock.setNumPeriodo(resumenStockEstablec.getNumPeriodo());
			            progIncoStock.setCantidadStockActual(resumenStockEstablec.getCantidadStockActual());
			            progIncoStock.setCntIngEst(resumenStockEstablec.getCntIngEst());
			            progIncoStock.setCntNetPres(resumenStockEstablec.getCntNetProd());//cnt_net_pres = listInconsistenciasStock.cntnetapresentacion
			            progIncoStock.setCntNeteada(resumenStockEstablec.getCntNeteada());
			            progIncoStock.setNumReposicion(String.valueOf(resumenStockEstablec.getNumReposicion()));
			            //progIncoStock.setCodUbigeo(datosUsuarioBean.getWsDomicilioRucBean().getCodUbigeo());
			            //progIncoStock.setDesDireccion(null);//
			            
			            progIncoStock.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
			            progIncoStock.setFecCrea(new Date());
			            progIncoStock.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
			            
			            t10419ProIncoStockDAO.save(progIncoStock, MaestrosConstantes.DATASOURCE_DGSICOBF);
			            
		            }
		            cntProcesamiento++;	
			}
		}
		
		if (logger.isDebugEnabled())
			logger.debug(
					"Fin DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaControlBajaOmisoStockNegativo");
		
		return cntProcesamiento;
	}
	
	private int procesarProgramaControlGreNoConfirmadasTransportista(ProgramacionBean bProgramacion){
		if (logger.isWarnEnabled())
			logger.warn(
					"Inicio DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaControlGreNoConfirmadasTransportista");
		
 	 int cntProcesamiento = 0;

	 CabezeraCpeBean cabezeraCpeBean = new CabezeraCpeBean();
		
	 cabezeraCpeBean.setCodTipoTransportista(AccionesControlConstantes.COD_TIP_TRANSPORTISTA);
	 cabezeraCpeBean.setCodTipoPersonaTransportista(AccionesControlConstantes.COD_TIP_PERSONA_TRANSPORTISTA);
	 cabezeraCpeBean.setCodCPEGuiaRemision(AccionesControlConstantes.COD_TIP_GUIA_REMITENTE);
	 cabezeraCpeBean.setCodTipoTrasladoPublico(AccionesControlConstantes.COD_TIP_TRASLADO_PUBLICO);
	 cabezeraCpeBean.setIndEstado(AccionesControlConstantes.IND_ESTADO_ACTIVO_GUIA);
	 cabezeraCpeBean.setPeriodoInicio(MaestrosUtilidades.stringToDateDDMMYYYY(bProgramacion.getPerInicio()));
	 cabezeraCpeBean.setPeriodoFin(MaestrosUtilidades.stringToDateDDMMYYYY(bProgramacion.getPerFin()));
	 
	 /* cCodTipoTransportista =  Constantes.COD_TIP_TRANSPORTISTA
		iCodTipoPersonaTransportista= constantes. COD_TIP_PERSONA_TRANSPORTISTA
		cCodCPEGuiaRemision= constantes.COD_TIP_GUIA_REMITENTE
		iCodTipoTrasladoPublico= constantes. COD_TIP_TRASLADO_PUBLICO
		cIndEstActivo = constantes.IND_ESTADO_ACTIVO_GUIA
		programacionBean.peridoInicio
		programacionBean.PeriodoFin    
	 */
	 List<CabezeraCpe>  lstUsuarioInconsistencia = t4241CabCpeDAO.listarTransportistasGreNoConfirmadas(cabezeraCpeBean);
		
		//-	Recorrer la lista de usuarios  �UsuarioInconsistencia�
		if (!MaestrosUtilidades.isEmpty(lstUsuarioInconsistencia)) {
			for( CabezeraCpe cabezeraCpe: lstUsuarioInconsistencia ){
				
				UsuarioRegistroBean usuarioRegistroBean = datosUsuario(String.valueOf(cabezeraCpe.getCabezeraCpePk().getNumRuc() ));
				
				if(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE.equals(usuarioRegistroBean.getCodEstado())){
					if(AccionesControlConstantes.COD_ESTADO_ACTIVO_RUC.equals(usuarioRegistroBean.getRegBeanRuc().getDdpEstado())){
						////obtener las GRE no confirmadas por usuario:

						cabezeraCpeBean = new CabezeraCpeBean();
						cabezeraCpeBean.setNumDocumentoRecepcion(cabezeraCpe.getNumDocumentoRecepcion());
						
						List<CabezeraCpe>  lstGreNoConfirmadas = t4241CabCpeDAO.listarGreNoConfirmadasPorTransportista(cabezeraCpeBean);
						
						if(lstGreNoConfirmadas.size() > 0){
							UsuarioRegistroBean usrRegistroBean = datosUsuario(cabezeraCpe.getNumDocumentoRecepcion());
							
							for(CabezeraCpe insCabeceraCpe : lstGreNoConfirmadas){
								
								UsuarioProgramacion usrProgr = new UsuarioProgramacion();
					            Long secUsrProgr = t10428UsuarioProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_USUARIO_FISCALIZABLE, AccionesControlConstantes.DATASOURCE_DCSICOBF);
					            
					            usrProgr.setNumUsuarioPrograma(secUsrProgr);
					            usrProgr.setNumProgramacion(bProgramacion.getNumProgramacion());
					            usrProgr.setCodTipoDocumentoIdentif(insCabeceraCpe.getCodDocumenotRecepcion());
					            usrProgr.setNumDocumentoIdentif(String.valueOf(insCabeceraCpe.getNumDocumentoRecepcion() ));
					            usrProgr.setNumVersionRegistro(usrRegistroBean.getNumVerreg() );//
					            usrProgr.setFecFinVigencia(usrRegistroBean.getFecFinvigencia());
					            usrProgr.setCodEstadoRegistro(usrRegistroBean.getCodEstado());
					            usrProgr.setCodUbigeoDomicilioFiscal(usuarioRegistroBean.getWsDomicilioRucBean().getCodUbigeo());
					            usrProgr.setCodNivelRiesgo(String.valueOf(usuarioRegistroBean.getNivelRiesgo()));		
					            usrProgr.setCodDependencia(usuarioRegistroBean.getRegBeanRuc().getDdpNumreg());// codigo de dependencia
					            usrProgr.setCodTipoAccion(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
					            usrProgr.setCodTipoIntervencion(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
					            usrProgr.setCodTipoIntervencionSugerida(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
					            usrProgr.setCodTipoAccionSugerida(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
					            usrProgr.setCodEstadoUsuario(AccionesControlConstantes.COD_ESTADO_USUARIO_CARGADO);
					            
					            /*
									�	num_verreg = DatosUsuarioBean.numVerreg
									�	fec_fin_vigencia = DatosUsuarioBean.fecFinvigencia
									�	cod_est_reg = DatosUsuarioBean.codEstado
					             * 
					             */
					            
					            usrProgr.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					            usrProgr.setFecCrea(new Date());
					            usrProgr.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					            
					            t10428UsuarioProgDAO.save(usrProgr, AccionesControlConstantes.DATASOURCE_DGSICOBF);
								
					            cntProcesamiento++;
							
							//fuera del loop?
							//Recorre la lista �ListaGreNoConfirmadas� e invocar al siguiente m�todo para insertar las inconsistencias
							
							Long seProIncoGreNc = t10417ProIncoGreNCDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_PROGRAM_INCONSISGRE, AccionesControlConstantes.DATASOURCE_DCSICOBF);
							
							ProgramaIncosistenciaGreNC insProgrIncosGreNC = new ProgramaIncosistenciaGreNC();
							//numIncoGre
							insProgrIncosGreNC.setNumIncoGre(seProIncoGreNc);
							
							insProgrIncosGreNC.setNumUsuarioPrograma(secUsrProgr);
							insProgrIncosGreNC.setNumRuc(insCabeceraCpe.getNumRuc());
							insProgrIncosGreNC.setCodCpe(insCabeceraCpe.getCodCpe());
							insProgrIncosGreNC.setNumSerieCpe(insCabeceraCpe.getNumSerieCpe());
							insProgrIncosGreNC.setNumCpe(insCabeceraCpe.getNumCpe());
							insProgrIncosGreNC.setFecEmision(insCabeceraCpe.getFecEmision());
							
							insProgrIncosGreNC.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
							insProgrIncosGreNC.setFecCrea(new Date());
							insProgrIncosGreNC.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
							
							t10417ProIncoGreNCDAO.save(insProgrIncosGreNC, AccionesControlConstantes.DATASOURCE_DGSICOBF);
							
						   }
						}
					}
					
				}
			}
		}
		
		if (logger.isDebugEnabled())
			logger.debug(
					"Fin DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaControlGreNoConfirmadasTransportista");
		
	 return cntProcesamiento;
	}
	
	private int procesarProgramaControlGreNoConfirmadasDestinatario(ProgramacionBean bProgramacion){
		if (logger.isWarnEnabled())
			logger.warn(
					"Inicio DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaControlGreNoConfirmadasDestinatario");
		
	 int cntProcesamiento = 0;
	 
	 //Obtiene el universo de usuarios (destinatario) que no confirmaron las GRE
	 	CabezeraCpeBean cabezeraCpeBean = new CabezeraCpeBean();
		
	 	cabezeraCpeBean.setCodTipoDestinatario(AccionesControlConstantes.COD_TIP_DESTNATARIO);
	 	
		cabezeraCpeBean.setCodTipoConfirGre(AccionesControlConstantes.COD_TIP_DESTNATARIO);
		cabezeraCpeBean.setCodRelacionTransportistaRemitente(AccionesControlConstantes.COD_RELACION_TRANSPORTISTA_REMITENTE);
		cabezeraCpeBean.setCodCPETransportista(AccionesControlConstantes.COD_TIP_GUIA_TRANSPORTISTA);
		cabezeraCpeBean.setCodCPEGuiaRemision(AccionesControlConstantes.COD_TIP_GUIA_REMITENTE);
		cabezeraCpeBean.setIndEstado(AccionesControlConstantes.IND_ESTADO_ACTIVO_GUIA);
		cabezeraCpeBean.setCodTipoDocumento(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC);//COD_TIP_DOCIDENT_RUC
		cabezeraCpeBean.setCodTipoTrasladoPublico(AccionesControlConstantes.COD_TIP_TRASLADO_PUBLICO);
		
															
		List<CabezeraCpe>  lstUsuarioInconsistencia = t4241CabCpeDAO.listarDestinatariosGreNoConfirmadas(cabezeraCpeBean);
	
		//-	Recorrer la lista de usuarios  �UsuarioInconsistencia�
		if (!MaestrosUtilidades.isEmpty(lstUsuarioInconsistencia)) {
			for( CabezeraCpe cabezeraCpe: lstUsuarioInconsistencia ){
				
				UsuarioRegistroBean usuarioRegistroBean = datosUsuario(String.valueOf(cabezeraCpe.getCabezeraCpePk().getNumRuc() ));
				
				if(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE.equals(usuarioRegistroBean.getCodEstado())){
					if(AccionesControlConstantes.COD_ESTADO_ACTIVO_RUC.equals(usuarioRegistroBean.getRegBeanRuc().getDdpEstado())){
						////obtener las GRE no confirmadas por usuario:

						cabezeraCpeBean = new CabezeraCpeBean();
						cabezeraCpeBean.setNumDocumentoRecepcion(cabezeraCpe.getNumDocumentoRecepcion());
						
						List<CabezeraCpe>  lstGreNoConfirmadas = t4241CabCpeDAO.listarGreNoConfirmadasPorDestinatario(cabezeraCpeBean);
						
						if(lstGreNoConfirmadas.size() > 0){
							UsuarioRegistroBean usrRegistroBean = datosUsuario(cabezeraCpe.getNumDocumentoRecepcion());
							
							for(CabezeraCpe insCabeceraCpe : lstGreNoConfirmadas){
								
								UsuarioProgramacion usrProgr = new UsuarioProgramacion();
					            Long secUsrProgr = t10428UsuarioProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_USUARIO_FISCALIZABLE, AccionesControlConstantes.DATASOURCE_DCSICOBF);
					            
					            usrProgr.setNumUsuarioPrograma(secUsrProgr);
					            usrProgr.setNumProgramacion(bProgramacion.getNumProgramacion());
					            usrProgr.setCodTipoDocumentoIdentif(insCabeceraCpe.getCodDocumenotRecepcion());
					            usrProgr.setNumDocumentoIdentif(String.valueOf(insCabeceraCpe.getNumDocumentoRecepcion() ));
					            usrProgr.setNumVersionRegistro(usrRegistroBean.getNumVerreg() );//
					            usrProgr.setFecFinVigencia(usrRegistroBean.getFecFinvigencia());
					            usrProgr.setCodEstadoRegistro(usrRegistroBean.getCodEstado());
					            usrProgr.setCodUbigeoDomicilioFiscal(usuarioRegistroBean.getWsDomicilioRucBean().getCodUbigeo());
					            usrProgr.setCodNivelRiesgo(String.valueOf(usuarioRegistroBean.getNivelRiesgo()));		
					            usrProgr.setCodDependencia(usuarioRegistroBean.getRegBeanRuc().getDdpNumreg());// codigo de dependencia
					            usrProgr.setCodTipoAccion(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
					            usrProgr.setCodTipoIntervencion(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
					            usrProgr.setCodTipoIntervencionSugerida(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
					            usrProgr.setCodTipoAccionSugerida(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
					            usrProgr.setCodEstadoUsuario(AccionesControlConstantes.COD_ESTADO_USUARIO_CARGADO);
					            
					            /*
									�	num_verreg = DatosUsuarioBean.numVerreg
									�	fec_fin_vigencia = DatosUsuarioBean.fecFinvigencia
									�	cod_est_reg = DatosUsuarioBean.codEstado
					             * 
					             */
					            
					            usrProgr.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					            usrProgr.setFecCrea(new Date());
					            usrProgr.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					            
					            t10428UsuarioProgDAO.save(usrProgr, AccionesControlConstantes.DATASOURCE_DGSICOBF);
								
					            cntProcesamiento++;
							
							//fuera del loop?
							//Recorre la lista �ListaGreNoConfirmadas� e invocar al siguiente m�todo para insertar las inconsistencias
							
							Long seProIncoGreNc = t10417ProIncoGreNCDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_PROGRAM_INCONSISGRE, AccionesControlConstantes.DATASOURCE_DCSICOBF);
							
							ProgramaIncosistenciaGreNC insProgrIncosGreNC = new ProgramaIncosistenciaGreNC();
							//numIncoGre
							insProgrIncosGreNC.setNumIncoGre(seProIncoGreNc);
							
							insProgrIncosGreNC.setNumUsuarioPrograma(secUsrProgr);
							insProgrIncosGreNC.setNumRuc(insCabeceraCpe.getNumRuc());
							insProgrIncosGreNC.setCodCpe(insCabeceraCpe.getCodCpe());
							insProgrIncosGreNC.setNumSerieCpe(insCabeceraCpe.getNumSerieCpe());
							insProgrIncosGreNC.setNumCpe(insCabeceraCpe.getNumCpe());
							insProgrIncosGreNC.setFecEmision(insCabeceraCpe.getFecEmision());
							
							insProgrIncosGreNC.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
							insProgrIncosGreNC.setFecCrea(new Date());
							insProgrIncosGreNC.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
							
							t10417ProIncoGreNCDAO.save(insProgrIncosGreNC, AccionesControlConstantes.DATASOURCE_DGSICOBF);
							
						   }
						}
					}
					
				}
			}
		}
		
		if (logger.isDebugEnabled())
			logger.debug(
					"Fin DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaControlGreNoConfirmadasDestinatario");
		
	 return cntProcesamiento;
	}
	
	private int procesarProgramaStockSaldoNegativo(ProgramacionBean bProgramacion){
		if (logger.isWarnEnabled())
			logger.warn("Inicio DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaStockSaldoNegativo");
		
		int cntProcesamiento = 0;
		List<String> lstEstadoUsuario = new ArrayList<>();
		List<String> lstEstadoRegistros;
	  ////stock negativo
		ResumenStockEstablecBean resumenStockEstablecBean = new ResumenStockEstablecBean();
		
		
		resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_IND_CONDICION_ITEM_REGISTRO);
		lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
		lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
		resumenStockEstablecBean.setLstEstadoUsuarios(lstEstadoUsuario);
		resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);

		
		List<ResumenStockEstablec> lstUsuarioStockNegativo = t5641RStockEstabDAO.listarUsuarioStockNegativo(resumenStockEstablecBean);
		
       ////Para saldo negativo 
		resumenStockEstablecBean = new ResumenStockEstablecBean();
		resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_IND_CONDICION_ITEM_REGISTRO);
		lstEstadoUsuario = new ArrayList<>();
		lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
		lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
		resumenStockEstablecBean.setLstEstadoUsuarios(lstEstadoUsuario);
		resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
		resumenStockEstablecBean.setNumRuc(lstUsuarioStockNegativo.get(0).getNumRuc());
		
		List<ResumenStockEstablec> listInconsistenciasStock = t5641RStockEstabDAO.listarStockNegativo(resumenStockEstablecBean);
		Integer cntstocknegativo = listInconsistenciasStock.size();
		if (!MaestrosUtilidades.isEmpty(listInconsistenciasStock)) {
			
			for( ResumenStockEstablec resumenStockEstablec: listInconsistenciasStock ){
				
				UsuarioRegistroBean usuarioRegistroBean = datosUsuario(String.valueOf(resumenStockEstablec.getNumRuc() ));
				
				UsuarioProgramacion usrProgr = new UsuarioProgramacion();
	            Long secUsrProgr = t10428UsuarioProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_USUARIO_FISCALIZABLE, AccionesControlConstantes.DATASOURCE_DCSICOBF);
	            
	            usrProgr.setNumUsuarioPrograma(secUsrProgr);
	            usrProgr.setNumProgramacion(bProgramacion.getNumProgramacion());
	            usrProgr.setCodTipoDocumentoIdentif(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC);
	            usrProgr.setNumDocumentoIdentif(String.valueOf(resumenStockEstablec.getNumRuc() ));
	            usrProgr.setNumVersionRegistro(resumenStockEstablec.getNumVersion() );
	            usrProgr.setFecFinVigencia(resumenStockEstablec.getFecFinvigencia());
	            usrProgr.setCodEstadoRegistro(resumenStockEstablec.getCodEstado());
	            usrProgr.setCodUbigeoDomicilioFiscal(usuarioRegistroBean.getWsDomicilioRucBean().getCodUbigeo());
	            usrProgr.setCodNivelRiesgo(String.valueOf(usuarioRegistroBean.getNivelRiesgo()));		
	            usrProgr.setCodDependencia(usuarioRegistroBean.getRegBeanRuc().getDdpNumreg());// codigo de dependencia
	            usrProgr.setCodTipoAccion(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
	            usrProgr.setCodTipoIntervencion(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
	            usrProgr.setCodTipoIntervencionSugerida(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
	            usrProgr.setCodTipoAccionSugerida(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
	            usrProgr.setCodEstadoUsuario(AccionesControlConstantes.COD_ESTADO_USUARIO_CARGADO);
	            
	            usrProgr.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
	            usrProgr.setFecCrea(new Date());
	            usrProgr.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
	            
	            t10428UsuarioProgDAO.save(usrProgr, MaestrosConstantes.DATASOURCE_DGSICOBF);
	            
	            
	            // t10419ProIncoStockDAO
	            // Registra las inconsistencias de cada usuario (stock negativo)
	            ProgramaIncosistenciaStock progIncoStock = new ProgramaIncosistenciaStock();
	            
	            Long seProIncoStock = t10419ProIncoStockDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_PROGRAM_INCONSISTOCK, AccionesControlConstantes.DATASOURCE_DCSICOBF);
	            
	            progIncoStock.setNumIncosistenciaStock(seProIncoStock);
	            progIncoStock.setNumEstablecimiento(Long.parseLong(resumenStockEstablec.getNumEstablecimiento()));
	            progIncoStock.setNumVersionEstablecimiento(resumenStockEstablec.getNumVersionEstab());
	            progIncoStock.setNumInsumoCabecera(resumenStockEstablec.getNumInscab());
	            progIncoStock.setCodTipprod(resumenStockEstablec.getCodTipProd());
	            progIncoStock.setCodBienFiscalizado(resumenStockEstablec.getCodBienFisca());
	            progIncoStock.setCodInsumo(resumenStockEstablec.getCodInsumo());
	            progIncoStock.setNumOrden(resumenStockEstablec.getNumOrden());
	            progIncoStock.setNumVersionInsumo(resumenStockEstablec.getNumVersionCabInsumo());
	            progIncoStock.setCodUnidadMedida(resumenStockEstablec.getCodUm());
	            progIncoStock.setDesNombreComercial(resumenStockEstablec.getDesNomComProd());
	            progIncoStock.setDesNombreProducto(resumenStockEstablec.getDesNomProd());
	            progIncoStock.setPorMinInsumo(resumenStockEstablec.getPorMin().doubleValue());
	            progIncoStock.setPorMaxInsumo(resumenStockEstablec.getPorMax().doubleValue());
	            progIncoStock.setNumPresentacion(resumenStockEstablec.getNumPresentacion());
	            progIncoStock.setNumVersionPressentacion(resumenStockEstablec.getNumVersionPressentacion());
	            progIncoStock.setCodPresen(resumenStockEstablec.getCodPresen());
	            progIncoStock.setCodUnidadComercial(resumenStockEstablec.getCodUnidadComercial());
	            progIncoStock.setCodUnidadFiscal(resumenStockEstablec.getCodUnidadFiscal());
	            progIncoStock.setCantidadUnidadFisica(resumenStockEstablec.getCantidadUnidadFisica());
	            progIncoStock.setNumPeriodo(resumenStockEstablec.getNumPeriodo());
	            progIncoStock.setCantidadStockActual(resumenStockEstablec.getCantidadStockActual());
	            progIncoStock.setCntIngEst(resumenStockEstablec.getCntIngEst());
	            progIncoStock.setCntNetPres(resumenStockEstablec.getCntNetProd());//cnt_net_pres = listInconsistenciasStock.cntnetapresentacion
	            progIncoStock.setCntNeteada(resumenStockEstablec.getCntNeteada());
	            progIncoStock.setNumReposicion(String.valueOf(resumenStockEstablec.getResumenStockEstablecPk().getNumReposicion()));
	            //progIncoStock.setCodUbigeo(usuarioRegistroBean.getWsDomicilioRucBean().getCodUbigeo());
	            //progIncoStock.setDesDireccion(null);
	            
	            
	            progIncoStock.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
	            progIncoStock.setFecCrea(new Date());
	            progIncoStock.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
	            
	            t10419ProIncoStockDAO.save(progIncoStock, MaestrosConstantes.DATASOURCE_DGSICOBF);
	            cntProcesamiento++;
			}
			
		}
		
		//-	Obtiene el universo de usuarios con saldo negativo:
		ResumenSaldoBean resumenSaldoBean = new ResumenSaldoBean();
		resumenSaldoBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		resumenSaldoBean.setNumReposicion(AccionesControlConstantes.NUM_ULTIMA_REPOSICION);
		lstEstadoRegistros = new ArrayList<>();
		lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
		lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
		resumenSaldoBean.setLstEstadoRegistros(lstEstadoRegistros);
		resumenSaldoBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
		
		List<ResumenSaldo>  lstUsuarioInconsistenciaBean = t5642RSaldoDAO.listarUsuarioSaldoNegativo(resumenSaldoBean);
		
		if (!MaestrosUtilidades.isEmpty(lstUsuarioInconsistenciaBean)) {
			for( ResumenSaldo resumenSaldo: lstUsuarioInconsistenciaBean ){
				
				UsuarioProgramacionBean usuarioProgramacionBean = new UsuarioProgramacionBean();
				usuarioProgramacionBean.setNumProgramacion(bProgramacion.getNumProgramacion());
				usuarioProgramacionBean.setCodTipoDocumentoIdentif(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC);
				usuarioProgramacionBean.setNumDocumentoIdentif(String.valueOf(resumenSaldo.getNumRuc()));
				usuarioProgramacionBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				usuarioProgramacionBean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				
				List<UsuarioProgramacion> lstUserPro = t10428UsuarioProgDAO.verificarUsuario(usuarioProgramacionBean);
				Integer cntSaldo = 0;
				if (MaestrosUtilidades.isEmpty(lstUserPro)) {
					//insertar el usuario 
					
					UsuarioRegistroBean usuarioRegistroBean= datosUsuario(String.valueOf(resumenSaldo.getNumRuc()));
					
					UsuarioProgramacion usrProgr = new UsuarioProgramacion();
		            Long secUsrProgr = t10428UsuarioProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_USUARIO_FISCALIZABLE, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		            
		            usrProgr.setNumUsuarioPrograma(secUsrProgr);
		            usrProgr.setNumProgramacion(bProgramacion.getNumProgramacion());
		            usrProgr.setCodTipoDocumentoIdentif(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC);
		            usrProgr.setNumDocumentoIdentif(String.valueOf(resumenSaldo.getNumRuc()));
		            usrProgr.setNumVersionRegistro(resumenSaldo.getNumVersionRegistro());
		            usrProgr.setFecFinVigencia(resumenSaldo.getFecFinvigencia());
		            usrProgr.setCodEstadoRegistro(resumenSaldo.getCodEstado());
		            usrProgr.setCodUbigeoDomicilioFiscal(usuarioRegistroBean.getWsDomicilioRucBean().getCodUbigeo());
		            usrProgr.setCodNivelRiesgo(String.valueOf(usuarioRegistroBean.getNivelRiesgo()));		
		            usrProgr.setCodDependencia(usuarioRegistroBean.getRegBeanRuc().getDdpNumreg());// codigo de dependencia
		            usrProgr.setCodTipoAccion(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
		            usrProgr.setCodTipoIntervencion(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
		            usrProgr.setCodTipoIntervencionSugerida(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
		            usrProgr.setCodTipoAccionSugerida(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
		            usrProgr.setCodEstadoUsuario(AccionesControlConstantes.COD_ESTADO_USUARIO_CARGADO);
		           		            
		            usrProgr.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
		            usrProgr.setFecCrea(new Date());
		            usrProgr.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
		            
		            t10428UsuarioProgDAO.save(usrProgr, MaestrosConstantes.DATASOURCE_DGSICOBF);
				}else{
					//inserta los bienes con saldo negativo
					/**
					 * Obtiene los bienes con saldo negativo del usuario*/
						resumenSaldoBean = new ResumenSaldoBean();
						resumenSaldoBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						resumenSaldoBean.setNumReposicion(AccionesControlConstantes.NUM_ULTIMA_REPOSICION);
						lstEstadoRegistros = new ArrayList<>();
						lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
						lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
						resumenSaldoBean.setLstEstadoRegistros(lstEstadoRegistros);
						resumenSaldoBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
						
						List<ResumenSaldo>  lstUsrInconsistenciaBean = t5642RSaldoDAO.listarSaldoNegativo(resumenSaldoBean);
						
						cntSaldo = lstUsrInconsistenciaBean.size();
						
					 for(ResumenSaldo rsmSaldo :lstUsrInconsistenciaBean){
						
						Long seProIncoSaldo = t10418ProIncoSaldoDao.obtenerSequencia(AccionesControlConstantes.SECUENCIA_PROGRAM_INCONSISSALDO, AccionesControlConstantes.DATASOURCE_DCSICOBF);
						
						ProgramaIncosistenciaSaldo programaIncosistenciaSaldo = new ProgramaIncosistenciaSaldo();
						
						programaIncosistenciaSaldo.setNumIncosistemciaSaldo(seProIncoSaldo);
						programaIncosistenciaSaldo.setNumUsuarioPrograma(lstUserPro.get(0).getNumUsuarioPrograma());//num_usu_program= numUsuProgram  
						programaIncosistenciaSaldo.setNumPeriodo(rsmSaldo.getNumPeriodo());
						programaIncosistenciaSaldo.setNumInsumoCabecera(rsmSaldo.getNumInsumoCabecera());
						programaIncosistenciaSaldo.setCodInsumo(rsmSaldo.getCodInsumo());
						programaIncosistenciaSaldo.setNumOrden(rsmSaldo.getNumOrden());
						programaIncosistenciaSaldo.setNumVersionInsumo(rsmSaldo.getNumVersionIns());
						programaIncosistenciaSaldo.setDesNombreComercial(rsmSaldo.getDesNomComProd());
						programaIncosistenciaSaldo.setDesNombreProducto(rsmSaldo.getDesNomProd());
						programaIncosistenciaSaldo.setCodTipprod(rsmSaldo.getCodTipProd());
						programaIncosistenciaSaldo.setCodUnidadMedida(rsmSaldo.getCodUm());
						programaIncosistenciaSaldo.setCodBienFiscalizado(rsmSaldo.getCodBienFisca());
						programaIncosistenciaSaldo.setPorMinInsumo(rsmSaldo.getPorMinIns().doubleValue());
						programaIncosistenciaSaldo.setPorMaxInsumo(rsmSaldo.getPorMaxIns().doubleValue());
						programaIncosistenciaSaldo.setCantidadAutorizada(rsmSaldo.getCntAutorizada());
						programaIncosistenciaSaldo.setCantidadConsumida(rsmSaldo.getCntConsumida());
						programaIncosistenciaSaldo.setCantidadDisponible(rsmSaldo.getCntDisponible());
						
						t10418ProIncoSaldoDao.save(programaIncosistenciaSaldo, AccionesControlConstantes.DATASOURCE_DGSICOBF);
						cntProcesamiento++;
					 }

						//Actualizar el tipo de inconsistencia por cada usuario bajo las siguientes condiciones:
					 	String codTipInconsis = obtenerTipoIncosistencia(cntSaldo, cntstocknegativo );
				
						UsuarioProgramacion updUsrProgram= t10428UsuarioProgDAO.findById(lstUserPro.get(0).getNumUsuarioPrograma(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
						
						updUsrProgram.setCodTipInconsis(codTipInconsis);
						updUsrProgram.setFecModif(new Date());
						updUsrProgram.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
						updUsrProgram.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
						
						t10428UsuarioProgDAO.update(updUsrProgram, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				  }
				
				// fuera del loop
				
			}
		  }
		
		if (logger.isDebugEnabled())
			logger.debug("Fin DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaStockSaldoNegativo");
		
		return cntProcesamiento;
	}
	
	private String obtenerTipoIncosistencia(int cntSaldo, int cntstocknegativo ){
		if (logger.isWarnEnabled())
			logger.warn("Inicio DeterminarSeleccionUsuariosBatchServiceImpl - obtenerTipoIncosistencia");
		
		String codTipInconsis = "";
		if (cntSaldo > 0 || cntstocknegativo > 0){
			if (cntSaldo > 0 && cntstocknegativo > 0){
				codTipInconsis = AccionesControlConstantes.COD_TIPO_INCON_STOCK_SALDO_NEGATIVO;
			}else if(cntSaldo > 0 && cntstocknegativo == 0){
				codTipInconsis = AccionesControlConstantes.COD_TIPO_INCON_SALDO_NEGATIVO;
			}else if (cntSaldo == 0 && cntstocknegativo > 0){
				codTipInconsis = AccionesControlConstantes.COD_TIPO_INCON_STOCK_NEGATIVO;
			}
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin DeterminarSeleccionUsuariosBatchServiceImpl - obtenerTipoIncosistencia");
		
		return codTipInconsis;
	}
	
	private String obtenerTipoIncosistenciaBaja(int cntOmiso, int cntStockNegativo ){
		if (logger.isWarnEnabled())
			logger.warn("Inicio DeterminarSeleccionUsuariosBatchServiceImpl - obtenerTipoIncosistenciaBaja");
		
		
		String codTipInconsis = "";
		if(cntOmiso>0 || cntStockNegativo>0){
			if(cntOmiso>0 && cntStockNegativo>0){
				codTipInconsis = AccionesControlConstantes.COD_TIPO_INCON_BAJA_STOCK_OMISO;
			}else if (cntOmiso  > 0 &&  cntStockNegativo == 0){
				codTipInconsis = AccionesControlConstantes.COD_TIPO_INCON_BAJA_OMISO;
			}else if(cntOmiso  == 0 && cntStockNegativo > 0 ){
				codTipInconsis = AccionesControlConstantes.COD_TIPO_INCON_BAJA_STOCK;
			}
			 //Obtiene los datos del usuario omiso 

		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin DeterminarSeleccionUsuariosBatchServiceImpl - obtenerTipoIncosistenciaBaja");
		
		return codTipInconsis;
	}
	
	private int procesarProgramaControlOmisosDj(ProgramacionBean bProgramacion){
		if (logger.isWarnEnabled())
			logger.warn("Inicio DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaControlOmisosDj");
		
		int cntProcesamiento = 0;
		DeclaracionesJuradasBfBean declaracionesJuradasBfBean = new DeclaracionesJuradasBfBean();
		
		declaracionesJuradasBfBean.setCodEstado(AccionesControlConstantes.COD_ESTADO_DJROP_PENDIENTE);
		declaracionesJuradasBfBean.setNumConfirma(AccionesControlConstantes.NUM_CONFIRMACION_SIN_ENVIO);
		List<String> lstCodEstado = new ArrayList<>();
		lstCodEstado.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);
		lstCodEstado.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);
		declaracionesJuradasBfBean.setLstEstadoBfRegistro(lstCodEstado);
		declaracionesJuradasBfBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		declaracionesJuradasBfBean.setIndOmiso(AccionesControlConstantes.COD_ESTADO_DJROP_EXONERADO_DEL_MES);
		
		List<DeclaracionesJuradasBf>  lstDeclaracionesJuradasBf = t5284BfCabJroDAO.listarUsuariosOmisosDjRop(declaracionesJuradasBfBean);
		
		if (!MaestrosUtilidades.isEmpty(lstDeclaracionesJuradasBf)) {
			for (DeclaracionesJuradasBf declaraJuradasBf: lstDeclaracionesJuradasBf){
				
				UsuarioRegistroBean usuarioRegistroBean = datosUsuario(declaraJuradasBf.getNumRuc());
                
				UsuarioProgramacion usrProgr = new UsuarioProgramacion();
	            Long secUsrProgr = t10428UsuarioProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_USUARIO_FISCALIZABLE, AccionesControlConstantes.DATASOURCE_DCSICOBF);
	            
	            usrProgr.setNumUsuarioPrograma(secUsrProgr);
	            usrProgr.setNumProgramacion(bProgramacion.getNumProgramacion());
	            usrProgr.setCodTipoDocumentoIdentif(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC);
	            usrProgr.setNumDocumentoIdentif(declaraJuradasBf.getNumRuc());
	            usrProgr.setNumVersionRegistro(declaraJuradasBf.getNumVersionRegistro());
	            usrProgr.setFecFinVigencia(declaraJuradasBf.getFecFinOmiso());
	            usrProgr.setCodEstadoRegistro(declaraJuradasBf.getCodEstado());
	            usrProgr.setCodUbigeoDomicilioFiscal(usuarioRegistroBean.getWsDomicilioRucBean().getCodUbigeo());
	            usrProgr.setCodNivelRiesgo(String.valueOf(usuarioRegistroBean.getNivelRiesgo()));		
	            usrProgr.setCodDependencia(usuarioRegistroBean.getRegBeanRuc().getDdpNumreg());// codigo de dependencia
	            usrProgr.setCodTipoAccion(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
	            usrProgr.setCodTipoIntervencion(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
	            usrProgr.setCodTipoIntervencionSugerida(AccionesControlConstantes.COD_TIP_ACCION_CARTA);
	            usrProgr.setCodTipoAccionSugerida(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
	            usrProgr.setCodEstadoUsuario(AccionesControlConstantes.COD_ESTADO_USUARIO_CARGADO);
	            usrProgr.setNumPeridoomisomin(declaraJuradasBf.getMinPeriodo());
	            usrProgr.setNumPeridoomisomax(declaraJuradasBf.getMaxPeriodo());
	            
	            usrProgr.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
	            usrProgr.setFecCrea(new Date());
	            usrProgr.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
	            
	            t10428UsuarioProgDAO.save(usrProgr, MaestrosConstantes.DATASOURCE_DGSICOBF);
	            cntProcesamiento++;
			}
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin DeterminarSeleccionUsuariosBatchServiceImpl - procesarProgramaControlOmisosDj");
		
		return cntProcesamiento;
	}
	
	private UsuarioRegistroBean datosUsuario(String numeroDocumento){
		if (logger.isWarnEnabled())
			logger.warn("Inicio DeterminarSeleccionUsuariosBatchServiceImpl - datosUsuario");
		
		UsuarioRegistroBean usuarioRegistroBean = new UsuarioRegistroBean();
		
		
		//Obtener el ubigeo del domicilio fiscal (consumir el servicio)
		WSDomicilioRUCBean wSDomicilioRucBean = servicioWebService.obtenerDomicilioFiscal(numeroDocumento);
		
		usuarioRegistroBean.setWsDomicilioRucBean(wSDomicilioRucBean);
		
		//Para obtener el nivel de riesgo :
		//NivelRiesgo String  = t8048PerRieDAO.obtenerNivelRiesgo(constantes.COD_TIP_DOCUMENTO_IDENT_RUC, UsuarioOmiso.numRuc)
		PerfilRiesgosBean perfilRiesgosBean = new PerfilRiesgosBean();
		perfilRiesgosBean.setCodTipoDocumentoIdent(Integer.parseInt(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC));
		perfilRiesgosBean.setNumDocumentoIdentif(numeroDocumento);
		
		List<PerfilRiesgos> lstPerfilRiesgo =  t8048PerRieDAO.obtenerNivelRiesgo(perfilRiesgosBean);
		List<PerfilRiesgosBean> lstPerfilRiesgoBean = new ArrayList<>();
		PerfilRiesgos perfilRiesgos = new PerfilRiesgos();
		if (!MaestrosUtilidades.isEmpty(lstPerfilRiesgo)) {
			if (!MaestrosUtilidades.isEmpty(lstPerfilRiesgo.get(0))) {
			perfilRiesgos = lstPerfilRiesgo.get(0);
			for (PerfilRiesgos perfil : lstPerfilRiesgo) {
				PerfilRiesgosBean perfilRiesgoBean = new PerfilRiesgosBean();
				perfilRiesgoBean.setCodCic(perfil.getPerfilRiesgosPk().getCodCic());
				lstPerfilRiesgoBean.add(perfilRiesgoBean);
			}
			}
		}
		Integer nivelRiesgo = perfilRiesgos.getIndNivrie();

		usuarioRegistroBean.setLstPerfilRiesgo(lstPerfilRiesgoBean);
		usuarioRegistroBean.setNivelRiesgo(nivelRiesgo);
		
		
		// Para obtener la dependencia :
		WSRegistroRUCBean regBeanRuc = servicioWebService.obtenerRegistroRuc(numeroDocumento);
    	//usrProgr.setCodDependencia(regBeanRuc.getDdpNumreg()); // consultar la dependencia
		
		usuarioRegistroBean.setRegBeanRuc(regBeanRuc);
		
		BfRegistroBean bfRegistroBean = new BfRegistroBean();
		bfRegistroBean.setNumRuc(numeroDocumento);
		
		List<BfRegistro>  lstBfRegistro = registroBfService.obtenerDatosUsuario(bfRegistroBean);
		
		if (!MaestrosUtilidades.isEmpty(lstBfRegistro)) {
			BfRegistro bfRegistro = lstBfRegistro.get(0);
			usuarioRegistroBean.setCodEstado(bfRegistro.getCodEstado());
			usuarioRegistroBean.setFecFinvigencia(bfRegistro.getFecFinvigencia());
			usuarioRegistroBean.setNumVerreg(bfRegistro.getBfregistroPk().getNumVerreg());
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin DeterminarSeleccionUsuariosBatchServiceImpl - datosUsuario");
		
		return usuarioRegistroBean;
	}
}
