
package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AccionSugeridaCalifBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AlternativaCriterioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CriterioCalificacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AccionSugeridaCalif;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AlternativaCriterio;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CriterioCalificacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10389AlternatCritDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10402CriterioCaliDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10444AccSugeCalifDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;


@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class MantenimientoCriterioServiceImpl implements MantenimientoCriterioService {

	private static final Logger logger = LoggerFactory.getLogger(MantenimientoCriterioServiceImpl.class);

	@EJB
	private T10402CriterioCaliDAO t10402CriterioCaliDAO;
	
	@EJB
	private T10389AlternatCritDAO t10389AlternatCritDAO;
	
	@EJB
	private T10444AccSugeCalifDAO t10444AccSugeCalifDAO;

	public MantenimientoCriterioServiceImpl() {
	
	}

	@Override
	public List<CriterioCalificacionBean> listarCriterioCalificacion(Integer numCriterio) {		
		List<CriterioCalificacionBean> lista = new ArrayList<CriterioCalificacionBean>();
		//List<CriterioCalificacion> t10402CriterioCali=t10402CriterioCaliDAO.findAll(AccionesControlConstantes.DATASOURCE_DCSICOBF);
		PropertyParams propertyParams=new PropertyParams();
		propertyParams.addPropertyOperador("indDel", MaestrosConstantes.REGISTRO_ELIMINADO, "<>");
		List<CriterioCalificacion> t10402CriterioCali=t10402CriterioCaliDAO.findByProperties(propertyParams,AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10402CriterioCali)) {
			CriterioCalificacionBean criterioCalificacionBean = null;
			for (CriterioCalificacion valores : t10402CriterioCali) {
				criterioCalificacionBean = new CriterioCalificacionBean();
				MaestrosUtilidades.copiarValoresBean(valores, criterioCalificacionBean);
				criterioCalificacionBean.setIndEstado(valores.getIndEst());
				lista.add(criterioCalificacionBean);
			}
		}
		return lista;
	}
	
	

	@Override
	public List<AlternativaCriterioBean> listarAlternativaCriterio(Long numCriterio, String indEst, String indDel) {
		
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numCriterio", numCriterio);
		if (!MaestrosUtilidades.isEmpty(indEst)) {
			propertyParams.addProperty("indEst", indEst);	
		}
		if (!MaestrosUtilidades.isEmpty(indDel)) {
			propertyParams.addProperty("indDel", indDel);	
		}
		List<AlternativaCriterioBean> lista = new ArrayList<AlternativaCriterioBean>();
		List<AlternativaCriterio> t10389AlternatCrit=t10389AlternatCritDAO.findByProperties(propertyParams,AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10389AlternatCrit)) {
			AlternativaCriterioBean alternativaCriterioBean = null;
			for (AlternativaCriterio valores : t10389AlternatCrit) {
				alternativaCriterioBean = new AlternativaCriterioBean();
				MaestrosUtilidades.copiarValoresBean(valores, alternativaCriterioBean);
				alternativaCriterioBean.setIndEstado(valores.getIndEst());
				lista.add(alternativaCriterioBean);
			}
		}
		
		return lista;
	}
	
	@Override 
	public CriterioCalificacionBean guardarCriterio(CriterioCalificacionBean criterioCalificacionBean) {
		Long numCriterio =t10402CriterioCaliDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_CRITERIOS_CALIFICACION, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		CriterioCalificacion registrar=new CriterioCalificacion();
		registrar.setNumCriterio(numCriterio);
		registrar.setDesCriterio(criterioCalificacionBean.getDesCriterio());
		registrar.setPorPeso(criterioCalificacionBean.getPorPeso());
		registrar.setIndEst(AccionesControlConstantes.COD_ESTADO_INDICADOR_ACTIVO);
		criterioCalificacionBean.setIndEstado(AccionesControlConstantes.COD_ESTADO_INDICADOR_ACTIVO);
		// auditoria
		registrar.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		registrar.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		registrar.setFecCrea(new Date());
		registrar.setDirIpusucrea(criterioCalificacionBean.getAuditoriaBean().getNumIp());
		registrar.setCodUsuCrea(criterioCalificacionBean.getAuditoriaBean().getLogin());
		// auditoria
		t10402CriterioCaliDAO.save(registrar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		return criterioCalificacionBean;
	}
	
	@Override
	//public CriterioCalificacionBean guardarEstadoCriterio(CriterioCalificacionBean criterioCalificacionBean) {
	public CriterioCalificacionBean actualizarCriterio(CriterioCalificacionBean criterioCalificacionBean) {
		
		    CriterioCalificacion actualizar = t10402CriterioCaliDAO.findById(criterioCalificacionBean.getNumCriterio(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
			actualizar.setNumCriterio(criterioCalificacionBean.getNumCriterio());
			actualizar.setIndEst(criterioCalificacionBean.getIndEstado());		
			// auditoria
			actualizar.setDirIpusumodif(criterioCalificacionBean.getAuditoriaBean().getNumIp());
			actualizar.setCodUsuModif(criterioCalificacionBean.getAuditoriaBean().getLogin());
			// auditoria
			t10402CriterioCaliDAO.update(actualizar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			return criterioCalificacionBean;
	}
	
	@Override
	public CriterioCalificacionBean eliminarCriterio(CriterioCalificacionBean criterioCalificacionBean){
		CriterioCalificacion actualizar = t10402CriterioCaliDAO.findById(criterioCalificacionBean.getNumCriterio(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		actualizar.setNumCriterio(criterioCalificacionBean.getNumCriterio());
		actualizar.setIndDel(AccionesControlConstantes.REGISTRO_ELIMINADO);
		actualizar.setIndEst(AccionesControlConstantes.REGISTRO_INACTIVO);
		// auditoria
		actualizar.setDirIpusumodif(criterioCalificacionBean.getAuditoriaBean().getNumIp());
		actualizar.setCodUsuModif(criterioCalificacionBean.getAuditoriaBean().getLogin());
		// auditoria
		t10402CriterioCaliDAO.update(actualizar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		return criterioCalificacionBean;
	}
	
	@Override
	public List<AlternativaCriterioBean> guardarAlternativa(AlternativaCriterioBean alternativaCriterioBean) {
		
		Long numAlternativa =t10389AlternatCritDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ALTERNATIVAS_CRITERIOS, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		AlternativaCriterio registrar=new AlternativaCriterio();
		registrar.setNumAlternativa(numAlternativa);
		registrar.setNumCriterio(alternativaCriterioBean.getNumCriterio());
		registrar.setDesAlternativa(alternativaCriterioBean.getDesAlternativa());
		registrar.setValAlternativa(alternativaCriterioBean.getValAlternativa());
		registrar.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		
		// auditoria
		registrar.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		registrar.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		registrar.setFecCrea(new Date());
		registrar.setDirIpusucrea(alternativaCriterioBean.getAuditoriaBean().getNumIp());
		registrar.setCodUsuCrea(alternativaCriterioBean.getAuditoriaBean().getLogin());
		// auditoria
		t10389AlternatCritDAO.save(registrar, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		return this.listarAlternativaCriterio(alternativaCriterioBean.getNumCriterio(), null, MaestrosConstantes.REGISTRO_NO_ELIMINADO);
	}
		

	@Override
	//public AlternativaCriterioBean guardarEstadoAlternativa(AlternativaCriterioBean alternativaCriterioBean) {
	public AlternativaCriterioBean actualizarAlternativa(AlternativaCriterioBean alternativaCriterioBean) {
		AlternativaCriterio actualizar = t10389AlternatCritDAO.findById(alternativaCriterioBean.getNumAlternativa(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			actualizar.setNumAlternativa(alternativaCriterioBean.getNumAlternativa());
			actualizar.setIndEst(alternativaCriterioBean.getIndEstado());
			//actualizar.setNumCriterio(alternativaCriterioBean.getNumCriterio());
			
			// auditoria
			actualizar.setDirIpusumodif(alternativaCriterioBean.getAuditoriaBean().getNumIp());
			actualizar.setCodUsuModif(alternativaCriterioBean.getAuditoriaBean().getLogin());
			// auditoria
			t10389AlternatCritDAO.update(actualizar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			return alternativaCriterioBean;
	}	
	
	@Override
	public AlternativaCriterioBean eliminarAlternativa (AlternativaCriterioBean alternativaCriterioBean){
		AlternativaCriterio actualizar = t10389AlternatCritDAO.findById(alternativaCriterioBean.getNumAlternativa(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		actualizar.setNumAlternativa(alternativaCriterioBean.getNumAlternativa());
		actualizar.setIndDel(AccionesControlConstantes.REGISTRO_ELIMINADO);
		actualizar.setIndEst(AccionesControlConstantes.REGISTRO_INACTIVO);
		// auditoria
		actualizar.setDirIpusumodif(alternativaCriterioBean.getAuditoriaBean().getNumIp());
		actualizar.setCodUsuModif(alternativaCriterioBean.getAuditoriaBean().getLogin());
		// auditoria
		t10389AlternatCritDAO.update(actualizar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		return alternativaCriterioBean;
	}
	
	@Override
	public  List<AccionSugeridaCalifBean> listarAccionesSugeridas(String indEstado) {
		
		List<AccionSugeridaCalifBean> lista = new ArrayList<AccionSugeridaCalifBean>();

		List<AccionSugeridaCalif> t10444AccSugeCalif = t10444AccSugeCalifDAO.listarAccionesSugeridas(indEstado);
		if (!MaestrosUtilidades.isEmpty(t10444AccSugeCalif)) {
			AccionSugeridaCalifBean accionSugeridaCalifBean = null;
			for (AccionSugeridaCalif valores : t10444AccSugeCalif) {
				accionSugeridaCalifBean = new AccionSugeridaCalifBean();
				accionSugeridaCalifBean.setNumAccionSugerida(valores.getNumAccionSugerida());
				accionSugeridaCalifBean.setDesAccionSugerida(valores.getDesAccionSugerida());
				System.out.println("valores.getStrValMinimo() => " + valores.getStrValMinimo());
				System.out.println("valores.getStrValMaximo() => " + valores.getStrValMaximo());
				accionSugeridaCalifBean.setValMinimo(new BigDecimal(valores.getStrValMinimo()));
				accionSugeridaCalifBean.setValMaximo(new BigDecimal(valores.getStrValMaximo()));
				//MaestrosUtilidades.copiarValoresBean(valores, accionSugeridaCalifBean);
				accionSugeridaCalifBean.setIndEstadoAccionSugerida(valores.getIndEstadoAccionSugerida());
				lista.add(accionSugeridaCalifBean);
			}
		}
		return lista;
	}
	
	@Override
	public AccionSugeridaCalifBean guardarAccionSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean) {

		Long numAccionSugerida =t10444AccSugeCalifDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ACCION_SUGERIDA, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		AccionSugeridaCalif registrar=new AccionSugeridaCalif();
		registrar.setNumAccionSugerida(numAccionSugerida);
		registrar.setDesAccionSugerida(accionSugeridaCalifBean.getDesAccionSugerida());

		registrar.setValMinimo(accionSugeridaCalifBean.getValMinimo());
		registrar.setValMaximo(accionSugeridaCalifBean.getValMaximo());
		registrar.setIndEstadoAccionSugerida(AccionesControlConstantes.COD_ESTADO_INDICADOR_ACTIVO);
		// auditoria
		registrar.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		registrar.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		registrar.setFecCrea(new Date());
		registrar.setDirIpusucrea(accionSugeridaCalifBean.getAuditoriaBean().getNumIp());
		registrar.setCodUsuCrea(accionSugeridaCalifBean.getAuditoriaBean().getLogin());
		// auditoria
		accionSugeridaCalifBean.setIndEstadoAccionSugerida(AccionesControlConstantes.COD_ESTADO_INDICADOR_ACTIVO);
		t10444AccSugeCalifDAO.save(registrar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		return accionSugeridaCalifBean;
	}
	

	@Override
	//public AccionSugeridaCalifBean guardarEstadoAccSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean) {
	public AccionSugeridaCalifBean actualizarAccSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean) {
		 
		 AccionSugeridaCalif actualizar = t10444AccSugeCalifDAO.findById(accionSugeridaCalifBean.getNumAccionSugerida(), AccionesControlConstantes.DATASOURCE_DGSICOBF);

			actualizar.setNumAccionSugerida(accionSugeridaCalifBean.getNumAccionSugerida());
			actualizar.setIndEstadoAccionSugerida(accionSugeridaCalifBean.getIndEstadoAccionSugerida());	
			// auditoria
			actualizar.setDirIpusumodif(accionSugeridaCalifBean.getAuditoriaBean().getNumIp());
			actualizar.setCodUsuModif(accionSugeridaCalifBean.getAuditoriaBean().getLogin());
			// auditoria
			t10444AccSugeCalifDAO.update(actualizar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			return accionSugeridaCalifBean;
	}
	
	@Override
	public AccionSugeridaCalifBean eliminarAccSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean){
		AccionSugeridaCalif actualizar = t10444AccSugeCalifDAO.findById(accionSugeridaCalifBean.getNumAccionSugerida(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		actualizar.setNumAccionSugerida(accionSugeridaCalifBean.getNumAccionSugerida());
		actualizar.setIndDel(AccionesControlConstantes.REGISTRO_ELIMINADO);
		actualizar.setIndEst(AccionesControlConstantes.REGISTRO_INACTIVO);
		actualizar.setIndEstadoAccionSugerida(AccionesControlConstantes.REGISTRO_INACTIVO);
		// auditoria
		actualizar.setDirIpusumodif(accionSugeridaCalifBean.getAuditoriaBean().getNumIp());
		actualizar.setCodUsuModif(accionSugeridaCalifBean.getAuditoriaBean().getLogin());
		// auditoria
		t10444AccSugeCalifDAO.update(actualizar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		return accionSugeridaCalifBean;
	}

	@Override
	public List<CriterioCalificacionBean> listarCriterioCalificacion() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio MantenimientoCriterioServiceImpl - listarCriterioCalificacion");
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		propertyParams.addPropertyOperador("indDel", MaestrosConstantes.REGISTRO_ELIMINADO, "<>");
		List<CriterioCalificacionBean> lista = new ArrayList<>();
		List<CriterioCalificacion> t10402lista = t10402CriterioCaliDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10402lista)) {
			for (CriterioCalificacion t10402 : t10402lista) {
				CriterioCalificacionBean bean = new CriterioCalificacionBean();
				MaestrosUtilidades.copiarValoresBean(t10402, bean);
				PropertyParams detalle = new PropertyParams();
				detalle.addProperty("numCriterio", t10402.getNumCriterio());
				detalle.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
				List<AlternativaCriterio> t10389lista = t10389AlternatCritDAO.findByProperties(detalle, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				List<AlternativaCriterioBean> alternativasCriterios = new ArrayList<>();
				if (!MaestrosUtilidades.isEmpty(t10389lista)) {
					for (AlternativaCriterio t10389 : t10389lista) {
						AlternativaCriterioBean tbean = new AlternativaCriterioBean();
						MaestrosUtilidades.copiarValoresBean(t10389, tbean);
						alternativasCriterios.add(tbean);
					}
				}
				bean.setAlternativasCriterios(alternativasCriterios);
				lista.add(bean);
			}
		}
		return lista;
	}
	
}
