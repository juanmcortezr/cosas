package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jdk.internal.dynalink.beans.StaticClass;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.HistorialEstadosProgramaBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DistribucionGrupo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.HistorialEstadosPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10392AsignProgramDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10410HistEstadoProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ReasignacionProgramaServiceImpl implements ReasignacionProgramaService {

	private static final Logger logger = LoggerFactory.getLogger(GestionProgramaOtrosServiceImpl.class);

	@EJB
	private ServicioWebService servicioWebServiceImpl;

	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;

	@EJB
	private T10392AsignProgramDAO t10392AsignProgramDAO;

	@EJB
	private T8303DistriGrupoDAO t8303DistriGrupoDAO;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private T10410HistEstadoProgDAO t10410HistEstadoProgDAO;
	
	@EJB
	private T8414MensajeIqbfDAO t8414MensajeIqbfDAO;
	

	@Override
	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro) {

		Programacion parametros = new Programacion();
		parametros.setNumProgramacion(filtro.getNumProgramacion());
		parametros.setCodProgctrl(filtro.getCodProgramaControl());
		parametros.setDesProgramacion(filtro.getDesProgramacion());
		parametros.setNumInforme(filtro.getNumInforme());
		parametros.setCodProgramador(filtro.getCodProgramador());
		parametros.setCodProgramadorAdmin(filtro.getCodProgramadorAdmin());
		parametros.setCodEstadoInforme(filtro.getCodEstadoInforme());
		parametros.setCodPers(filtro.getCodPers());
		parametros.setFechaIniAsignacion(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaIniAsignacion()));
		parametros.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaFinAsig()));
		parametros.setCodEstadoPrograma(filtro.getCodEstadoPrograma());
		parametros.setDesEstadoInforme(filtro.getDesEstadoInforme());
		parametros.setNumAlcanceProgramacion(filtro.getNumAlcanceProgramacion());
		parametros.setDesAlcance(filtro.getDesAlcance());
		parametros.setFecUltimoEstado(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFecUltimoEstado()));
		parametros.setIndTipAsignaProg(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR);
		parametros.setIndTipAsignaProgAdmi(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR_ADMIN);
		parametros.setNomProgramador(filtro.getNomProgramador());
		parametros.setNomProgramadorAdmin(filtro.getNomProgramadorAdmin());
		

		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
			parametros.setCodEstadoPrograma(filtro.getCodEstadoPrograma());
		} else {
			parametros.setEstadosProgramaDefinido(
					Arrays.asList(AccionesControlConstantes.COD_EST_PROGRAM_SELECCION_PROCESADA));
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
			parametros.setCodEstadoPrograma(filtro.getCodEstadoPrograma());
		} else {
			parametros.setEstadosPrograma(Arrays.asList(AccionesControlConstantes.COD_EST_PROGRAM_ASIGNADO,
					AccionesControlConstantes.COD_EST_PROGRAM_EJECUTADO));
		}

		List<ProgramacionBean> listaPrograma = new ArrayList<ProgramacionBean>();
		List<Programacion> t10420Programacion = t10420ProgramacionDAO.listarReasignacionProgramacion (parametros);
		logger.debug(String.format("t10420Programacion => %s", t10420Programacion));

		if (!MaestrosUtilidades.isEmpty(t10420Programacion)) {
			for (Programacion valores : t10420Programacion) {
				ProgramacionBean programacionBean = new ProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(valores, programacionBean);
				programacionBean = new ProgramacionBean();
				programacionBean.setNumProgramacion(valores.getNumProgramacion());
				programacionBean.setCodProgctrl(valores.getCodProgctrl());
				programacionBean.setDesProgctrl(valores.getDesProgctrl());
				programacionBean.setDesProgramacion(valores.getDesProgramacion());
				programacionBean.setIndTipAsignaProg(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR);
				programacionBean.setIndTipAsignaProgAdmi(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR_ADMIN);
				programacionBean
						.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(valores.getFecProgramacion()));
				programacionBean
						.setFechaIniAsignacion(MaestrosUtilidades.dateToStringDDMMYYYY(valores.getFecIniAsignacion()));
				programacionBean.setFechaFinAsig(MaestrosUtilidades.dateToStringDDMMYYYY(valores.getFechaFinAsig()));
				programacionBean.setPerInicio(valores.getPerInicio());
				programacionBean.setPerFin(valores.getPerFin());
				programacionBean.setNumInforme(valores.getNumInforme());
				programacionBean.setCodProgramadorAdmin(valores.getCodProgramadorAdmin());
				programacionBean.setCodEstadoPrograma(valores.getCodEstadoPrograma());
				programacionBean.setCodEstadoInforme(valores.getCodEstadoInforme());
				programacionBean.setDesEstadoInforme(valores.getDesEstadoInforme());
				programacionBean.setNumAlcanceProgramacion(valores.getNumAlcanceProgramacion());
				programacionBean.setDesAlcance(valores.getDesAlcance());
				programacionBean.setFecUltimoEstado(MaestrosUtilidades.dateToStringDDMMYYYY(valores.getFecUltimoEstado()));
				programacionBean.setIndTipAsignacion(valores.getIndTipAsignacion());
				
				if (!MaestrosUtilidades.isEmpty(valores.getCodProgramador())) {
					WSPersonalIqbfBean servicioWebService = servicioWebServiceImpl
							.obtenerPersonalIqbf(valores.getCodProgramador());
					if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
						programacionBean.setNomProgramador(servicioWebService.getNomCompleto());
					} else {
						programacionBean.setNomProgramador("");
					}
				}

				DataCatalogoBean catalogo = null;
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_FUENTES_PROGRAMAS,
						valores.getCodFuente());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesFuente(catalogo.getDescripcionDataCatalogo());
				}
				
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_INFORMESELECCION,
						valores.getCodEstadoInforme());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesEstadoInforme(catalogo.getDescripcionDataCatalogo());
				}

				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_PROGRAMACION,
						valores.getCodTipoProgram());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesTipoProgram(catalogo.getDescripcionDataCatalogo());
				}

				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,
						valores.getCodEstadoPrograma());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesEstadoProgram(catalogo.getDescripcionDataCatalogo());
				}

				catalogo = dataCatalogoService.obtenerCatalogo(
						AccionesControlConstantes.COD_CATALOGO_SUBESTADOS_PROGRAMACION,
						valores.getCodSubEstadoProgram());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesSubEstprogram(catalogo.getDescripcionDataCatalogo());
				}

				catalogo = dataCatalogoService.obtenerCatalogo(
						AccionesControlConstantes.COD_CATALOGO_PROCESOS_PROGRAMACION, valores.getCodProceso());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesProceso(catalogo.getDescripcionDataCatalogo());
				}

				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_ESTADOS_INFORME_SELECCION,
						valores.getCodEstadoInforme());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesEstadoInforme(catalogo.getDescripcionDataCatalogo());
				}

					WSPersonalIqbfBean nomProgramador = servicioWebServiceImpl
							.obtenerPersonalIqbf(valores.getCodProgramador());
					if (!MaestrosUtilidades.isEmpty(nomProgramador)) {
						programacionBean.setNomProgramador(nomProgramador.getNomCompleto());
					} else {
						programacionBean.setNomProgramador("");
					}

					WSPersonalIqbfBean nomProgramadorAdmin = servicioWebServiceImpl
							.obtenerPersonalIqbf(valores.getCodProgramadorAdmin());
					if (!MaestrosUtilidades.isEmpty(nomProgramadorAdmin)) {
						programacionBean.setNomProgramadorAdmin(nomProgramadorAdmin.getNomCompleto());
					} else {
						programacionBean.setNomProgramadorAdmin("");
					}

				listaPrograma.add(programacionBean);
			}
			
			if (!MaestrosUtilidades.isEmpty(filtro.getCodProgramador()) || !MaestrosUtilidades.isEmpty(filtro.getCodProgramadorAdmin())) {
				listaPrograma.stream().filter(programacionBean -> {
					return (programacionBean.getNomProgramador().contains(filtro.getCodProgramador()) || programacionBean.getCodProgramador().equals(filtro.getCodProgramador()) 
							|| programacionBean.getNomProgramadorAdmin().contains(filtro.getCodProgramadorAdmin()) || programacionBean.getCodProgramadorAdmin().equals(filtro.getCodProgramadorAdmin()) );
				});	
			}
			if(!MaestrosUtilidades.isEmpty(filtro.getNomProgramadorAdmin())){
				listaPrograma = listByNomProgramadorAdministrador(listaPrograma, filtro);
			}
			if(!MaestrosUtilidades.isEmpty(filtro.getNomProgramador())){
				listaPrograma = listByNomProgramador(listaPrograma, filtro);
			}
		}

		return listaPrograma;
	}
	
	private List<ProgramacionBean> listByNomProgramador(List<ProgramacionBean> lista,ProgramacionBean filtro){
		List<ProgramacionBean> lista2= new ArrayList<ProgramacionBean>();
		for (ProgramacionBean programacionBean : lista) {
			if(programacionBean.getNomProgramador()!=null && programacionBean.getNomProgramador().toLowerCase().contains(filtro.getNomProgramador().toLowerCase())){
				lista2.add(programacionBean);
			}
		}
		return lista2;
	}
	private List<ProgramacionBean> listByNomProgramadorAdministrador(List<ProgramacionBean> lista,ProgramacionBean filtro){
		List<ProgramacionBean> lista2= new ArrayList<ProgramacionBean>();
		for (ProgramacionBean programacionBean : lista) {
			if(programacionBean.getNomProgramadorAdmin()!=null && programacionBean.getNomProgramadorAdmin().toLowerCase().contains(filtro.getNomProgramadorAdmin().toLowerCase())){
				lista2.add(programacionBean);
			}
		}
		return lista2;
	}

	
	@Override
	public List<AsignaProgramacionBean> listarAsignadoProgramacion(String numProgramacion) {

		List<AsignaProgramacionBean> lista = new ArrayList<AsignaProgramacionBean>();
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", numProgramacion);
		List<AsignaProgramacion> t10392AsignProgram = t10392AsignProgramDAO.findByProperties(propertyParams,
				AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10392AsignProgram)) {

			AsignaProgramacionBean asignaProgramacionBean = null;
			for (AsignaProgramacion programacion : t10392AsignProgram) {
				asignaProgramacionBean = new AsignaProgramacionBean();

				if (!MaestrosUtilidades.isEmpty(programacion.getCodProgramador())) {
					WSPersonalIqbfBean servicioWebService = servicioWebServiceImpl
							.obtenerPersonalIqbf(programacion.getCodProgramador());
					if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
						asignaProgramacionBean.setNomProgramador(servicioWebService.getNomCompleto());
					} else {
						asignaProgramacionBean.setNomProgramador("");
					}
				}
				lista.add(asignaProgramacionBean);
			}
		}
		return lista;
	}


	@Override
	public List<AsignaProgramacionBean> listarHistorialAsignaciones(Long numProgramacion, String indTipAsignacion) {
		if (logger.isDebugEnabled())
			logger.debug("ReasignacionProgramaServiceImpl - listarHistorialAsignaciones");

		AsignaProgramacion filtroModel = new AsignaProgramacion();
		filtroModel.setNumProgramacion(numProgramacion);
		filtroModel.setIndTipAsignacion(indTipAsignacion);


		List<AsignaProgramacionBean> lista = new ArrayList<AsignaProgramacionBean>();
		
		
		List<AsignaProgramacion> t10392lista = t10392AsignProgramDAO.listarAsignaProg(filtroModel);
		logger.debug(String.format("t10392lista => %s", t10392lista));
		if (!MaestrosUtilidades.isEmpty(t10392lista)) {
			for (AsignaProgramacion t10392 : t10392lista) {
				AsignaProgramacionBean bean = new AsignaProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10392, bean);

				bean.setNumProgramacion(t10392.getNumProgramacion());
				bean.setIndTipAsignacion(t10392.getIndTipAsignacion());

				WSPersonalIqbfBean nombreProgramador = servicioWebServiceImpl.obtenerPersonalIqbf(t10392.getCodProgramador());
				if (!MaestrosUtilidades.isEmpty(nombreProgramador)) {
					bean.setNomProgramador(nombreProgramador.getNomCompleto());
				} else {
					bean.setNomProgramador("");
				}

				lista.add(bean);
			}

		}
		return lista;
	}

	@Override
	public List<DistribucionGrupoBean> listarProgramador(String indTipAsignacion) {
		if (logger.isDebugEnabled())
			logger.debug("ReasignacionProgramaServiceImpl - listarProgramador");
		List<DistribucionGrupoBean> listaProgramador = new ArrayList<DistribucionGrupoBean>();
		DistribucionGrupo filtroModel = new DistribucionGrupo();
		filtroModel.setCodTipoProceso(AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);
		if (!MaestrosUtilidades.isEmpty(indTipAsignacion)) {	
			if(indTipAsignacion.trim().equals(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR)){	
				filtroModel.setCodCargo(AccionesControlConstantes.COD_CARGO_PROGRAMADOR);
			}else{
				filtroModel.setCodCargo(AccionesControlConstantes.COD_CARGO_PROGRAMADOR_ADMIN);
			}
		}

		List<DistribucionGrupo> t8303distrigrupo = t8303DistriGrupoDAO.listarProgramador(filtroModel);
		logger.debug(String.format("t8303lista => %s", t8303distrigrupo));
		if (!MaestrosUtilidades.isEmpty(t8303distrigrupo)) {
			DistribucionGrupoBean distribucionGrupoBean = null;
			for (DistribucionGrupo distribucionGrupo : t8303distrigrupo) {
				distribucionGrupoBean = new DistribucionGrupoBean();
				distribucionGrupoBean.setCodCargo(distribucionGrupo.getCodCargo());
				distribucionGrupoBean.setCodPersonal(distribucionGrupo.getCodPersonal());
				distribucionGrupoBean.setCodTipoProceso(distribucionGrupo.getCodTipoProceso());
				distribucionGrupoBean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				if (!MaestrosUtilidades.isEmpty(distribucionGrupo.getCodPersonal())) {
					WSPersonalIqbfBean servicioWebService = servicioWebServiceImpl
							.obtenerPersonalIqbf(distribucionGrupo.getCodPersonal());
					if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
						distribucionGrupoBean.setNomProgramador(servicioWebService.getNomCompleto());
					} else {
						distribucionGrupoBean.setNomProgramador("");
					}
				}
				listaProgramador.add(distribucionGrupoBean);
			}
		}
		return listaProgramador;
	}
	
	@Override
	public ResponseBean<ProgramacionBean> guardarAsignacionProgramacion(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("ReasignacionProgramaServiceImpl - guardarAsignacionProgramacion");
		AsignaProgramacion asignaProgramacionMaxFecha = new AsignaProgramacion();

		asignaProgramacionMaxFecha.setNumAsignacion(formulario.getNumAsignacion());
		asignaProgramacionMaxFecha.setCodProgramador(formulario.getCodProgramador());
		asignaProgramacionMaxFecha.setNumProgramacion(formulario.getNumProgramacion());
		asignaProgramacionMaxFecha.setIndTipAsignacion(formulario.getIndTipAsignacion());
		AsignaProgramacion t10392Update = t10392AsignProgramDAO.ultimoAsignaProg(asignaProgramacionMaxFecha);
		if(!MaestrosUtilidades.isEmpty(t10392Update)){
			t10392Update.setFecFinAsignacion(new Date());
			t10392Update.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			t10392Update.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			t10392Update.setFecModif(new Date());
			t10392AsignProgramDAO.update(t10392Update, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}	
		AsignaProgramacion asignaProgramacionInsert = new AsignaProgramacion();
		
		/*asignaProgramacionInsert.setNumAsignacion(t10392AsignProgramDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ASIGNACION_PROGRAMAS,  AccionesControlConstantes.DATASOURCE_DGSICOBF));
		asignaProgramacionInsert.setNumProgramacion(formulario.getNumProgramacion());
		asignaProgramacionInsert.setIndTipAsignacion(formulario.getIndTipAsignacion());
		asignaProgramacionInsert.setCodProgramador(formulario.getCodProgramador());
		asignaProgramacionInsert.setFecInicioAsignacion(new Date());
		asignaProgramacionInsert.setFecFinAsignacion(MaestrosUtilidades.stringToDate(AccionesControlConstantes.FECHA_ESTANDAR, MaestrosConstantes.FORMAT_FECHAHORA_YYYYMMDDHHMMSS));
		asignaProgramacionInsert.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		asignaProgramacionInsert.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		asignaProgramacionInsert.setFecCrea(new Date());
		List<AsignaProgramacion> t8303insert = t10392AsignProgramDAO.insertarAsignaProg(asignaProgramacionInsert);*/
		asignaProgramacionInsert.setNumAsignacion(t10392AsignProgramDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ASIGNACION_PROGRAMAS,  AccionesControlConstantes.DATASOURCE_DGSICOBF));
		asignaProgramacionInsert.setNumProgramacion(formulario.getNumProgramacion());
		asignaProgramacionInsert.setIndTipAsignacion(formulario.getIndTipAsignacion());
		asignaProgramacionInsert.setCodProgramador(formulario.getCodProgramador());
		asignaProgramacionInsert.setFecInicioAsignacion(new Date());
		asignaProgramacionInsert.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		asignaProgramacionInsert.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		asignaProgramacionInsert.setFecFinAsignacion(MaestrosUtilidades.stringToDate(AccionesControlConstantes.FECHA_ESTANDAR, MaestrosConstantes.FORMAT_FECHAHORA_YYYYMMDDHHMMSS));
		asignaProgramacionInsert.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		asignaProgramacionInsert.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		asignaProgramacionInsert.setFecCrea(new Date());
		t10392AsignProgramDAO.save(asignaProgramacionInsert, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
		// Enviar correo
		
		try{
			String codSolicitante=(formulario.getAuditoriaBean().getLogin());
			WSPersonalIqbfBean programador = servicioWebServiceImpl.obtenerPersonalIqbf(codSolicitante);
			MensajeIqbf t8414 = t8414MensajeIqbfDAO.findById(AccionesControlConstantes.COD_MENSAJE_CORREO_F19, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t8414) && !MaestrosUtilidades.isEmpty(programador)) {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("numeroProgramacion", "");
				parametros.put("nombreProgramaControl", "XXXX");
				CorreoBean correoBean = new CorreoBean();
				correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
				correoBean.setAsunto(t8414.getDesCorta());
				correoBean.setReceptor(programador.getDirCorreo().trim());
				correoBean.setMensaje(AccionesControlUtil.generarMensaje(t8414.getDesCuerpo(), parametros));
				CorreoUtil.enviarCorreo(correoBean);
			}
		}catch(Exception e){
			logger.error(String.format("errorEnviarCorreo %s", e.getMessage()), e);
		}
		
		return new ResponseBean<ProgramacionBean>(formulario);
	}
}
