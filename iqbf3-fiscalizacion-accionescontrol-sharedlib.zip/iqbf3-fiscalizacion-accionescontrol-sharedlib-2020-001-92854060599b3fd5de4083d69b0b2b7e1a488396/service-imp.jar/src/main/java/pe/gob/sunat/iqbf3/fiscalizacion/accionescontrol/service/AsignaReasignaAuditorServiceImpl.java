package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AgentePuestosCtrlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaUsuarioAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.GrupoProcesoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AgentePuestosCtrl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaUsuarioAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DistribucionGrupo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.GrupoProceso;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10297AgenteCtrolDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10394AsignaUsuAccDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8311GrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class AsignaReasignaAuditorServiceImpl implements AsignaReasignaAuditorService {

	private static final Logger logger = LoggerFactory.getLogger(GestionProgramaOtrosServiceImpl.class);

	@EJB
	private T10428UsuarioProgDAO t10428usuarioprogDAO;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private ServicioWebService servicioWebServiceimpl;

	@EJB
	private T10394AsignaUsuAccDAO t10394asignausuaccDAO;

	@EJB
	private T8303DistriGrupoDAO t8303DistriGrupoDAO;

	@EJB
	private T10297AgenteCtrolDAO t10297AgenteCtrolDAO;
	
	@EJB
	private T10415OrdenAccionDAO t10415OrdenAccionDAO;
	
	@EJB
	private T10411InformeSelecDAO t10411informeselecDAO;
	
	@EJB
	private T8311GrupoDAO t8311grupoDAO;

	@Override
	public List<UsuarioProgramacionBean> listarUsuarioProgramacion(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("AsignaReasignaAuditorServiceImpl - listarUsuarioProgramacion");

		UsuarioProgramacion filtroModel = new UsuarioProgramacion();
		filtroModel.setNumProgCorrel(filtro.getNumProgCorrel());
		filtroModel.setNumProgramacion(filtro.getNumProgramacion());
		filtroModel.setAlcanceProg(filtro.getAlcanceProg());
		filtroModel.setDesAlcance(filtro.getDesAlcance());
		filtroModel.setNumInformeSelecci(filtro.getNumInformeSelecci());
		filtroModel.setNroInformeUnion(filtro.getNroInformeUnion());
		filtroModel.setNumOrdenUnion(filtro.getNumOrdenUnion());
		filtroModel.setCodTipoDocumentoIdentif(filtro.getCodTipoDocumentoIdentif());
		filtroModel.setNumDocumentoIdentif(filtro.getNumDocumentoIdentif());
		filtroModel.setCodPers(filtro.getCodPers());
		filtroModel.setDesProgctrl(filtro.getDesProgctrl());
		filtroModel.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
		filtroModel.setIndEst(AccionesControlConstantes.REGISTRO_ACTIVO);
		filtroModel.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
		filtroModel.setCodEstadoPrograma(filtro.getCodEstadoPrograma());
		}else{
			filtroModel.setEstadosPrograma(Arrays.asList(AccionesControlConstantes.COD_EST_PROGRAM_ASIGNADO));
		}
		List<UsuarioProgramacionBean> lista = new ArrayList<UsuarioProgramacionBean>();
		List<UsuarioProgramacion> t10428lista = t10428usuarioprogDAO.listarUsuarioProg(filtroModel);
		logger.debug(String.format("t10428lista => %s", t10428lista));
		if (!MaestrosUtilidades.isEmpty(t10428lista)) {
			for (UsuarioProgramacion t10428 : t10428lista) {
				UsuarioProgramacionBean bean = new UsuarioProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10428, bean);
				
				bean.setNumProgCorrel(t10428.getNumProgCorrel());
				
				bean.setCodTipoDocumentoIdentif(t10428.getCodTipoDocumentoIdentif());				
				DataCatalogoBean tipoDocIdentif = dataCatalogoService.obtenerCatalogo(
				AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF, bean.getCodTipoDocumentoIdentif());
				bean.setDesTipoDocumentoIdent("");
				if (!MaestrosUtilidades.isEmpty(tipoDocIdentif)) {
					bean.setDesTipoDocumentoIdent(tipoDocIdentif.getDescripcionDataCatalogo());
				}				
				bean.setNumDocumentoIdentif(t10428.getNumDocumentoIdentif());				
				bean.setNomApellidoUsuario(t10428.getNomApellidoUsuario());
				bean.setNumProgramacion(t10428.getNumProgramacion());
				bean.setCodProgctrl(t10428.getCodProgctrl());
				bean.setDesProgctrl(t10428.getDesProgctrl());
				bean.setNumInformeSelecci(t10428.getNumInformeSelecci());
				bean.setNroInformeUnion(t10428.getNroInformeUnion());
				bean.setNumDocumentoAccion(t10428.getNumDocumentoAccion());
				bean.setCodTipoIntervencion(t10428.getCodTipoIntervencion());
				DataCatalogoBean cataTipoIntervencion = dataCatalogoService.obtenerCatalogo(
						AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INTERVENCION,
						bean.getCodTipoIntervencion());
				bean.setDesTipoIntervencion("");
				if (!MaestrosUtilidades.isEmpty(cataTipoIntervencion)) {
					bean.setDesTipoIntervencion(cataTipoIntervencion.getDescripcionDataCatalogo());
				}
				
				bean.setCodTipoAccion(t10428.getCodTipoAccion());
				DataCatalogoBean cataTipoAccion = dataCatalogoService
						.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL, t10428.getCodTipoAccion());
				bean.setDesTipoAccion("");
				if (!MaestrosUtilidades.isEmpty(cataTipoAccion)) {
					bean.setDesTipoAccion(cataTipoAccion.getDescripcionDataCatalogo());
				}
				WSPersonalIqbfBean nomAuditor = servicioWebServiceimpl.obtenerPersonalIqbf(t10428.getCodPers());
				if (!MaestrosUtilidades.isEmpty(nomAuditor)) {
					bean.setNomAuditor(nomAuditor.getNomCompleto());
				}else{
					bean.setNomAuditor("");
    			}
				bean.setNumOrden(t10428.getNumOrden());
				bean.setDesAlcance(t10428.getDesAlcance());
				bean.setCodAuditor(t10428.getCodPers());
				bean.setNumUsuarioPrograma(t10428.getNumUsuarioPrograma());
//				bean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
//				bean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
//				bean.setCodProgctrl(AccionesControlConstantes.COD_OTROS_PROGRAMAS);
				bean.setNomRazonSocial(t10428.getNomRazonSocial());
				
				lista.add(bean);
			}
			if(!MaestrosUtilidades.isEmpty(filtro.getNomAuditor())){
				lista = listByNomAuditor(lista, filtro);
			}
		}
		
		return lista;
	}
	private List<UsuarioProgramacionBean> listByNomAuditor(List<UsuarioProgramacionBean> lista,UsuarioProgramacionBean filtro){
		List<UsuarioProgramacionBean> lista2= new ArrayList<UsuarioProgramacionBean>();
		for (UsuarioProgramacionBean bean : lista) {
			if(bean.getNomAuditor()!=null && bean.getNomAuditor().toLowerCase().contains(filtro.getNomAuditor().toLowerCase())){
				lista2.add(bean);
			}
		}
		return lista2;
	}
	@Override
	public List<AsignaUsuarioAccionBean> listarAuditoresAgentes(AsignaUsuarioAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("AsignaReasignaAuditorServiceImpl - listarAuditoresAgentes");		
		List<AsignaUsuarioAccionBean> lista = new ArrayList<AsignaUsuarioAccionBean>();
		if (!MaestrosUtilidades.isEmpty(filtro.getNumGrupo())){
			lista=	listarAuditorPrincipal(filtro.getNumGrupo()); 
		}else if(!MaestrosUtilidades.isEmpty(filtro.getCodCargo())){
			String codPuesto=(filtro.getCodCargo());
			String codRol=(AccionesControlConstantes.COD_PUESTO_CONTROL_ROL_AGENTE_DE_CONTROL);
			List<AgentePuestosCtrlBean> agentePuestosCtrlBean= new ArrayList<AgentePuestosCtrlBean>();
			agentePuestosCtrlBean=  listarAgentePuesto(codPuesto, codRol); 
			if(!MaestrosUtilidades.isEmpty(agentePuestosCtrlBean)){
				for (AgentePuestosCtrlBean agentePuestos : agentePuestosCtrlBean) {
					AsignaUsuarioAccionBean asignaUsuario = new AsignaUsuarioAccionBean();					
					asignaUsuario.setCodAuditor(agentePuestos.getNumRegistroPersonal());
					AsignaUsuarioAccion asignaUsu = new AsignaUsuarioAccion();
					asignaUsu.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
					asignaUsu.setIndEst(AccionesControlConstantes.REGISTRO_ACTIVO);
					asignaUsu.setCodAuditor(agentePuestos.getNumRegistroPersonal());
					List<AsignaUsuarioAccion> listaUsuAccion=t10394asignausuaccDAO.listarCargaAuditorPrincipal(asignaUsu);
					if (!MaestrosUtilidades.isEmpty(listaUsuAccion)) {
						asignaUsuario.setCntCarga(listaUsuAccion.get(0).getCntCarga());
					} else {
						asignaUsuario.setCntCarga(Long.parseLong("0"));
					}
					asignaUsuario.setNomAuditor(agentePuestos.getNomAuditor());
					asignaUsuario.setCodCargo(agentePuestos.getCodRol());
					
					lista.add(asignaUsuario);
				}				
			}			
		}
		return lista;
	}
	
	
	@Override
	@Transactional
	public AsignaUsuarioAccionBean guardarAuditorPrincipal (AsignaUsuarioAccionBean formulario){
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorServiceImpl - guardarAuditorPrincipal");
		logger.debug(String.format("formulario => %s", formulario.toString()));
		
		//boolean esRegistro = (MaestrosUtilidades.isEmpty(formulario.getNumAsignacionAccion()) || formulario.getNumAsignacionAccion() == 0);
		//AsignaUsuarioAccion asignaUsuarioAccion = esRegistro ? new AsignaUsuarioAccion() : t10394asignausuaccDAO.findById(formulario.getNumAsignacionAccion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		AsignaUsuarioAccion asignaUsuarioAccion = new AsignaUsuarioAccion();// : t10394asignausuaccDAO.findById(formulario.getNumAsignacionAccion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(formulario.getNumUsuarioPrograma())) {
		asignaUsuarioAccion.setNumUsuarioPrograma(formulario.getNumUsuarioPrograma());
		}
		asignaUsuarioAccion.setNumAsignacionAccion(t10394asignausuaccDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ASIGNACION_USUARIOS, AccionesControlConstantes.DATASOURCE_DCSICOBF));		
		asignaUsuarioAccion.setIndTipAsignacion(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR_MANUAL);
		//asignaUsuarioAccion.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		//asignaUsuarioAccion.setCodPers(formulario.getCodPers());
		asignaUsuarioAccion.setNumProgramacion(formulario.getNumProgramacion());
		asignaUsuarioAccion.setFecInicioAsignacion(new Date());
		asignaUsuarioAccion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		asignaUsuarioAccion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		
		asignaUsuarioAccion.setFecCrea(new Date());
		//asignaUsuarioAccion.setIndTipAsignacion(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR_MANUAL);
		asignaUsuarioAccion.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		asignaUsuarioAccion.setCodAuditor(formulario.getCodAuditor());
		asignaUsuarioAccion.setFecFinAsignacion(new Date());
		asignaUsuarioAccion.setCodUsuCrea(formulario.getCodUsuCrea());
		asignaUsuarioAccion.setDirIpusucrea(formulario.getDirIpusucrea());
		t10394asignausuaccDAO.save(asignaUsuarioAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
		PropertyParams propertyOrden = new PropertyParams();
		propertyOrden.addProperty("numUsuarioPrograma", formulario.getNumUsuarioPrograma());
		propertyOrden.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyOrden.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<OrdenAccion> t10415lita = t10415OrdenAccionDAO.findByProperties(propertyOrden, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if(!MaestrosUtilidades.isEmpty(t10415lita)) {
			for(OrdenAccion ordenAccion : t10415lita){
				ordenAccion.setFecModif(new Date());
				ordenAccion.setNumUsuarioPrograma(formulario.getNumUsuarioPrograma());
				ordenAccion.setCodEstadoOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_ENPROCESO);
				ordenAccion.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
				ordenAccion.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
				t10415OrdenAccionDAO.update(ordenAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}
		if(!MaestrosUtilidades.isEmpty(formulario.getNumInformeSeleccion())){
			PropertyParams propertyInforme = new PropertyParams();
			propertyInforme.addProperty("numInformeSeleccion", formulario.getNumInformeSeleccion());
			propertyInforme.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyInforme.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<InformeSeleccion> t10411lista = t10411informeselecDAO.findByProperties(propertyInforme, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if(!MaestrosUtilidades.isEmpty(t10411lista)) {
				for(InformeSeleccion informeSeleccion : t10411lista){
					informeSeleccion.setFecModif(new Date());
					informeSeleccion.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_ORDEN_ENPROCESO);
					informeSeleccion.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
					informeSeleccion.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
					t10411informeselecDAO.update(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
		}
		
		return formulario;
	}
	
	
	@Override
	public List<AsignaUsuarioAccionBean> obtenerAsigUsuarioAccion(AsignaUsuarioAccionBean filtro) {
		List<AsignaUsuarioAccionBean> listaAsignacion = new ArrayList<AsignaUsuarioAccionBean>();
		PropertyParams propertyParams = new PropertyParams();
		if (!MaestrosUtilidades.isEmpty(filtro.getNumUsuarioPrograma())) {
			propertyParams.addProperty("numUsuarioPrograma", filtro.getNumUsuarioPrograma());	
		}
		propertyParams.addProperty("codCargo", AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		System.out.println("parametros.getNumUsuarioPrograma() => " + filtro.getNumUsuarioPrograma());
		List<AsignaUsuarioAccion> t10394asignausuacc = t10394asignausuaccDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10394asignausuacc)) {
			AsignaUsuarioAccionBean asignaUsuarioAccionBean = null;
			for (AsignaUsuarioAccion asignaUsuarioAccion : t10394asignausuacc) {
				asignaUsuarioAccionBean = new AsignaUsuarioAccionBean();
				asignaUsuarioAccionBean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				asignaUsuarioAccionBean.setNumUsuarioPrograma(asignaUsuarioAccion.getNumUsuarioPrograma());
				asignaUsuarioAccionBean.setCodAuditor(asignaUsuarioAccion.getCodAuditor());
				
				asignaUsuarioAccionBean.setDesCargo(String.valueOf(dataCatalogoService.obtenerCatalogo(
						asignaUsuarioAccion.getCodCargo(), AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL)));
				
				WSPersonalIqbfBean nomAuditor = servicioWebServiceimpl.obtenerPersonalIqbf(asignaUsuarioAccion.getCodAuditor());
				if (!MaestrosUtilidades.isEmpty(nomAuditor)) {
					asignaUsuarioAccionBean.setNomAuditor(nomAuditor.getNomCompleto());
				}else{
					asignaUsuarioAccionBean.setNomAuditor("");
    			}
				
				listaAsignacion.add(asignaUsuarioAccionBean);
			}
		}
		return listaAsignacion;
	}
	
	//CONSULTAR
	@Override
	public List<AsignaUsuarioAccionBean> listaCargaAuditoresPrincipales(String numProgramacion) {
		List<AsignaUsuarioAccionBean> listaAsignacion = new ArrayList<AsignaUsuarioAccionBean>();
		AsignaUsuarioAccion filtro = new AsignaUsuarioAccion();
		PropertyParams propertyParams = new PropertyParams();
		//parametros.setNumUsuarioPrograma(Long.valueOf(numProgramacion));
		//parametros.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);

		propertyParams.addProperty("codTipIntControl", AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
		propertyParams.addProperty("codTipIntFiscalizacion",
				AccionesControlConstantes.COD_TIP_INTERVENCION_FISCALIZACION);
		propertyParams.addProperty("numProgramacion", numProgramacion);
		propertyParams.addProperty("codCargo", AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		
		List<String> estadosOrdenes = new ArrayList<String>();
		estadosOrdenes.add(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		estadosOrdenes.add(AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA);
		
		filtro.setEstadoOrden(estadosOrdenes);
		
		
		/*ArrayList<String> estadoOrden = new ArrayList<String>();
		estadoOrden.add(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		estadoOrden.add(AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA);
		parametros.setEstadoOrden(estadoOrden);*/

		//String codTipIntControl = AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL;
		//String codTipIntFiscalizacion = AccionesControlConstantes.COD_TIP_INTERVENCION_FISCALIZACION;

		//List<AsignaUsuarioAccion> t10394asignausuacc = t10394asignausuaccDAO.listarCargaAuditorPrincipal(parametros, numProgramacion, codTipIntControl, codTipIntFiscalizacion);
		List<AsignaUsuarioAccion> t10394asignausuacc = t10394asignausuaccDAO.listarCargaAuditorPrincipal(filtro);
		if (!MaestrosUtilidades.isEmpty(t10394asignausuacc)) {
			AsignaUsuarioAccionBean asignaUsuarioAccionBean = null;
			for (AsignaUsuarioAccion asignaUsuarioAccion : t10394asignausuacc) {
				asignaUsuarioAccionBean = new AsignaUsuarioAccionBean();
				WSPersonalIqbfBean auditor = servicioWebServiceimpl.obtenerPersonalIqbf(asignaUsuarioAccion.getCodAuditor());
				if (!MaestrosUtilidades.isEmpty(auditor)) {
					asignaUsuarioAccionBean.setNomAuditor(auditor.getNomCompleto());
				}	
				asignaUsuarioAccionBean.setCntCarga(asignaUsuarioAccion.getCntCarga());			
				listaAsignacion.add(asignaUsuarioAccionBean);
			}
		}

		return listaAsignacion;
	}

	@Override
	public List<GrupoProcesoBean> listarSupervisionAuditor() {
		List<GrupoProcesoBean> lista = new ArrayList<GrupoProcesoBean>();
		PropertyParams propertyParams = new PropertyParams();
		
		propertyParams.addProperty("codTipoProceso", AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);
		List<GrupoProceso> t8311grupo = t8311grupoDAO.findByProperties(propertyParams,
				AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t8311grupo)) {
			GrupoProcesoBean grupoProcesoBean = null;
			for (GrupoProceso grupoProceso : t8311grupo) {
				grupoProcesoBean=new GrupoProcesoBean();
				if (!MaestrosUtilidades.isEmpty(grupoProceso.getCodTipoProceso())) {
					grupoProcesoBean.setCodTipoProceso(grupoProceso.getCodTipoProceso());
				}
				if (!MaestrosUtilidades.isEmpty(grupoProceso.getNumGrupo())) {
					grupoProcesoBean.setNumGrupo(grupoProceso.getNumGrupo());
				}
				grupoProcesoBean.setNomGrupo(grupoProceso.getNomGrupo());
				lista.add(grupoProcesoBean);
			}
		}
		return lista;
	}

	@Override
	public List<AgentePuestosCtrlBean> listarAgentePuesto(String codPuesto, String codRol) {

		List<AgentePuestosCtrlBean> listaAgentePuesto = new ArrayList<AgentePuestosCtrlBean>();

		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("codPuesto", codPuesto);
		propertyParams.addProperty("codRol", codRol);
		//bean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		List<AgentePuestosCtrl> t10297AgenteCtrol = t10297AgenteCtrolDAO.findByProperties(propertyParams,
				AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10297AgenteCtrol)) {
			AgentePuestosCtrlBean agentePuestosCtrlBean = null;
			for (AgentePuestosCtrl agentePuestosCtrl : t10297AgenteCtrol) {
				agentePuestosCtrlBean = new AgentePuestosCtrlBean();
				agentePuestosCtrlBean.setNumRegistroPersonal(agentePuestosCtrl.getNumRegistroPersonal());
				agentePuestosCtrlBean.setCodDep(agentePuestosCtrl.getCodDep());
				agentePuestosCtrlBean.setCodPuesto(agentePuestosCtrl.getCodPuesto());
				agentePuestosCtrlBean.setCodUnidadOrganica(agentePuestosCtrl.getCodUnidadOrganica());
				agentePuestosCtrlBean.setCodRol(agentePuestosCtrl.getCodRol());
				agentePuestosCtrlBean.setCodEstado(agentePuestosCtrl.getCodEstado());
				agentePuestosCtrlBean.setDesSustento(agentePuestosCtrl.getDesSustento());
				agentePuestosCtrlBean.setFecRegistro(agentePuestosCtrl.getFecCrea().toString());
				if (!MaestrosUtilidades.isEmpty(agentePuestosCtrl.getNumRegistroPersonal())) {
					WSPersonalIqbfBean codAuditor = servicioWebServiceimpl
							.obtenerPersonalIqbf(agentePuestosCtrl.getNumRegistroPersonal());
					if (!MaestrosUtilidades.isEmpty(codAuditor)) {
						agentePuestosCtrlBean.setNomAuditor(codAuditor.getNomCompleto());
					} 

				}
				listaAgentePuesto.add(agentePuestosCtrlBean);
			}
		}
		return listaAgentePuesto;
	}
	
	// CONSULTAR
	@Override
	public List<AsignaUsuarioAccionBean> listarAuditorPrincipal(String numGrupo) {
		List<AsignaUsuarioAccionBean> listaAuditorPrincipal = new ArrayList<AsignaUsuarioAccionBean>();
		AsignaUsuarioAccion filtro = new AsignaUsuarioAccion();
		//PropertyParams propertyParams = new PropertyParams();
		
		filtro.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		filtro.setCodTipoProceso(AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);
		filtro.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		filtro.setNumGrupo(numGrupo);
		
		List<String> estadosOrdenes = new ArrayList<String>();
		estadosOrdenes.add(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		estadosOrdenes.add(AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA);
		filtro.setEstadoOrden(estadosOrdenes);
		/*String codCargo = AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL;
		//String codTipoProceso = AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD;
		//String indEst = AccionesControlConstantes.REGISTRO_ACTIVO;
		List<String> codEstOrdenExc = new ArrayList<String>();
		codEstOrdenExc.add(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		codEstOrdenExc.add(AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA);

		PropertyParams propertyParamas = new PropertyParams();
		propertyParamas.addProperty("codTipoProceso", AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);
		propertyParamas.addProperty("numGrupo", numGrupo);*/
		String codCargo = AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL;
		String codTipoProceso = null;//AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD;
		String indEst = AccionesControlConstantes.REGISTRO_ACTIVO;
		ArrayList<String> codEstOrdenExc = new ArrayList<String>();
		codEstOrdenExc.add(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		codEstOrdenExc.add(AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA);
		
		List<AsignaUsuarioAccion> t8303distrigrupo = t8303DistriGrupoDAO.listarAuditor(filtro);
		if (!MaestrosUtilidades.isEmpty(t8303distrigrupo)) {
			AsignaUsuarioAccionBean asignaUsuarioAccionBean = null;
			for (AsignaUsuarioAccion asignaUsuarioAccion : t8303distrigrupo) {
				asignaUsuarioAccionBean = new AsignaUsuarioAccionBean();
				asignaUsuarioAccionBean.setNumGrupo(asignaUsuarioAccion.getNumGrupo());
				asignaUsuarioAccionBean.setCodCargo(asignaUsuarioAccion.getCodCargo());
				asignaUsuarioAccionBean.setCodAuditor(asignaUsuarioAccion.getCodAuditor());
				asignaUsuarioAccionBean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				asignaUsuarioAccionBean.setFechaIniAsignacion(MaestrosUtilidades.dateToStringDDMMYYYY(asignaUsuarioAccion.getFecInicioAsignacion()));

				if (!MaestrosUtilidades.isEmpty(asignaUsuarioAccion.getCodAuditor())) {
					WSPersonalIqbfBean servicioWebService = servicioWebServiceimpl
							.obtenerPersonalIqbf(asignaUsuarioAccion.getCodAuditor());
					if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
						asignaUsuarioAccionBean.setNomAuditor(servicioWebService.getNomCompleto());
					} else {
						asignaUsuarioAccionBean.setNomAuditor("");
					}
				}
				asignaUsuarioAccionBean.setCntCarga(asignaUsuarioAccion.getCntCarga());				
				asignaUsuarioAccionBean.setNumUsuarioPrograma(asignaUsuarioAccion.getNumUsuarioPrograma());
				if(!MaestrosUtilidades.isEmpty(asignaUsuarioAccion.getCntCarga())){
					asignaUsuarioAccionBean.setCntCarga(asignaUsuarioAccion.getCntCarga());	
				} else{
					asignaUsuarioAccionBean.setCntCarga(Long.valueOf("0"));	
				}
				listaAuditorPrincipal.add(asignaUsuarioAccionBean);
			}
		}
		return listaAuditorPrincipal;
	}

	
	@Override
	public boolean eliminarAuditorApoyo(AsignaUsuarioAccionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorServiceImpl - guardarAuditorPrincipal");
		logger.debug(String.format("formulario => %s", filtro.toString()));
		
		boolean exito = true;
		try{
		AsignaUsuarioAccion t10394 = t10394asignausuaccDAO.findById(filtro.getNumAsignacionAccion(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		t10394.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
		t10394.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
		t10394.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
		t10394.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
		t10394asignausuaccDAO.update(t10394, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
		}
		catch(Exception e){
			logger.error(e.getMessage(), e);
			exito = false;
		}
		return exito;
	}
	
	// LISTO
	@Override
	public List<DistribucionGrupoBean> listarAuditorApoyo(DistribucionGrupoBean filtroBean) {
		List<DistribucionGrupoBean> listaAuditoApoyo = new ArrayList<DistribucionGrupoBean>();
		DistribucionGrupo filtroModel = new DistribucionGrupo();
		if(!MaestrosUtilidades.isEmpty(filtroBean.getNumRegistro())){
			filtroModel.setCodPersonal(filtroBean.getNumRegistro());					
		}
		filtroModel.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_APOYO);
		//filtroModel.setCodTipoProceso(AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);	
		//String codCargo = AccionesControlConstantes.COD_CARGO_AUDITOR_APOYO;
		//String codTipProceso = AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD;
		//String indEst = AccionesControlConstantes.REGISTRO_ACTIVO;

//		PropertyParams propertyParams = new PropertyParams();		
		//List<DistribucionGrupo> t8303distrigrupo = t8303DistriGrupoDAO.listarAuditorApoyo(codCargo, codTipProceso, indEst);
		
		/*propertyParams.addProperty("codCargo", AccionesControlConstantes.COD_CARGO_AUDITOR_APOYO);
		propertyParams.addProperty("codTipoProceso", AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);
		propertyParams.addProperty("indEst", AccionesControlConstantes.REGISTRO_ACTIVO);
		//bean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);*/
		//List<DistribucionGrupo> t8303distrigrupo = t8303DistriGrupoDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		List<DistribucionGrupo> t8303distrigrupo = t8303DistriGrupoDAO.listarAuditorApoyo(filtroModel);
		
		if (!MaestrosUtilidades.isEmpty(t8303distrigrupo)) {
			DistribucionGrupoBean distribucionGrupoBean = null;
			for (DistribucionGrupo distribucionGrupo : t8303distrigrupo) {
				distribucionGrupoBean = new DistribucionGrupoBean();
				/*filtroModel.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_APOYO);
				filtroModel.setCodTipoProceso(AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);
				filtroModel.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);*/
				if (!MaestrosUtilidades.isEmpty(distribucionGrupo.getCodPersonal())) {
					WSPersonalIqbfBean servicioWebService = servicioWebServiceimpl
							.obtenerPersonalIqbf(distribucionGrupo.getCodPersonal());
					if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
						distribucionGrupoBean.setNomAuditorApoyo(servicioWebService.getNomCompleto());
					} else {
						distribucionGrupoBean.setNomAuditorApoyo("");
					}
				}
				distribucionGrupoBean.setNumUsuarioPrograma(distribucionGrupo.getNumUsuarioPrograma());
				distribucionGrupoBean.setNumRegistro(distribucionGrupo.getCodPersonal());
				//listaAuditoApoyo.add(asignaUsuarioAccionBean);				
				listaAuditoApoyo.add(distribucionGrupoBean);
			}
			if (!MaestrosUtilidades.isEmpty(filtroBean.getNomAuditorApoyo())) {
				listaAuditoApoyo = listByNomAuditorApoyo(listaAuditoApoyo, filtroBean);
			}
		}
		return listaAuditoApoyo;
	}
	private List<DistribucionGrupoBean> listByNomAuditorApoyo(List<DistribucionGrupoBean> lista,DistribucionGrupoBean filtro){
		List<DistribucionGrupoBean> lista2= new ArrayList<DistribucionGrupoBean>();
		for (DistribucionGrupoBean bean : lista) {
			if(bean.getNomAuditorApoyo()!=null && bean.getNomAuditorApoyo().toLowerCase().contains(filtro.getNomAuditorApoyo().toLowerCase())){
				lista2.add(bean);
			}
		}
		return lista2;
	}
	@Override
	public List<DistribucionGrupoBean> listarAuditorApoyoAsignado(Long numUsuarioProgram) {
		List<DistribucionGrupoBean> listaAudiApoyoAccion = new ArrayList<DistribucionGrupoBean>();

		String codCargo = AccionesControlConstantes.COD_CARGO_AUDITOR_APOYO;
		String indEst = AccionesControlConstantes.REGISTRO_ACTIVO;
		DistribucionGrupo filtroModel = new DistribucionGrupo();
		filtroModel.setNumUsuarioPrograma(numUsuarioProgram);
		filtroModel.setCodCargo(codCargo);
		filtroModel.setCodTipoProceso(AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);
		filtroModel.setIndEst(indEst);
		List<DistribucionGrupo> t8303distrigrupo = t8303DistriGrupoDAO.listarAuditorApoyo(filtroModel);
		if (!MaestrosUtilidades.isEmpty(t8303distrigrupo)) {
			DistribucionGrupoBean distribucionGrupoBean = null;
			for (DistribucionGrupo distribucionGrupo : t8303distrigrupo) {
				distribucionGrupoBean = new DistribucionGrupoBean();
				MaestrosUtilidades.copiarValoresBean(distribucionGrupo, distribucionGrupoBean);
				if (!MaestrosUtilidades.isEmpty(distribucionGrupo.getCodPersonal())) {
					WSPersonalIqbfBean servicioWebService = servicioWebServiceimpl
							.obtenerPersonalIqbf(distribucionGrupo.getCodPersonal());
					if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
						distribucionGrupoBean.setNomAuditorApoyo(servicioWebService.getNomCompleto());
					} else {
						distribucionGrupoBean.setNomAuditorApoyo("");
					}
				}
				distribucionGrupoBean.setNumRegistro(distribucionGrupo.getCodPersonal());
//				DataCatalogoBean catalogo = null;
//				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL,
//						distribucionGrupo.getCodCargo());
//				if (!MaestrosUtilidades.isEmpty(catalogo)) {
//					distribucionGrupoBean.setDesCargo(catalogo.getDescripcionDataCatalogo());
//				}
				listaAudiApoyoAccion.add(distribucionGrupoBean);
			}
		}
		return listaAudiApoyoAccion;
	}


	@Override
	@Transactional
	public AsignaUsuarioAccionBean guardarAuditorApoyo(AsignaUsuarioAccionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio AsignaReasignaAuditorServiceImpl - guardarAuditorApoyo");
		logger.debug(String.format("formulario => %s", formulario.toString()));
		// Calendar today = Calendar.getInstance();
		for (DistribucionGrupoBean element : formulario.getListaAsignaUsuario()) {
			boolean esRegistro = (MaestrosUtilidades.isEmpty(formulario.getNumAsignacionAccion())
					|| formulario.getNumAsignacionAccion() == 0);
			AsignaUsuarioAccion asignaUsuarioAccion = esRegistro ? new AsignaUsuarioAccion()
					: t10394asignausuaccDAO.findById(formulario.getNumAsignacionAccion(),
							AccionesControlConstantes.DATASOURCE_DCSICOBF);
			asignaUsuarioAccion.setNumAsignacionAccion(
					t10394asignausuaccDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ASIGNACION_USUARIOS,
							AccionesControlConstantes.DATASOURCE_DCSICOBF));
			asignaUsuarioAccion.setNumUsuarioPrograma(formulario.getNumUsuarioPrograma());
			asignaUsuarioAccion.setIndTipAsignacion(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR_MANUAL);
			asignaUsuarioAccion.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_APOYO);
			asignaUsuarioAccion.setCodPers(element.getCodPers());
			asignaUsuarioAccion.setFecInicioAsignacion(new Date());
			asignaUsuarioAccion.setFecFinAsignacion(new Date());
			asignaUsuarioAccion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			asignaUsuarioAccion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			asignaUsuarioAccion.setFecCrea(new Date());
			asignaUsuarioAccion.setNumProgramacion(formulario.getNumProgramacion());
			t10394asignausuaccDAO.save(asignaUsuarioAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			PropertyParams propertyOrden = new PropertyParams();
			propertyOrden.addProperty("numUsuarioPrograma", formulario.getNumUsuarioPrograma());
			propertyOrden.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyOrden.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<OrdenAccion> t10415lita = t10415OrdenAccionDAO.findByProperties(propertyOrden,
					AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10415lita)) {
				for (OrdenAccion ordenAccion : t10415lita) {
					ordenAccion.setFecModif(new Date());
					ordenAccion.setNumUsuarioPrograma(formulario.getNumUsuarioPrograma());
					ordenAccion.setCodEstadoOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_ENPROCESO);
					ordenAccion.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
					ordenAccion.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
					t10415OrdenAccionDAO.update(ordenAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
		}
		actualizaInformeSeleccion(formulario);

		/*
		 * respuesta.setExito(true);
		 * respuesta.setData(Long.valueOf(asignaUsuarioAccion.
		 * getNumAsignacionAccion()));
		 * respuesta.setMensaje(String.format(AccionesControlMensajes.
		 * CUS13_REGISTRO_EXITO,
		 * MaestrosUtilidades.toBlank(asignaUsuarioAccion.getNumAsignacionAccion
		 * ()))); return respuesta;
		 */
		return formulario;
	}

	private void actualizaInformeSeleccion(AsignaUsuarioAccionBean formulario) {
		if (!MaestrosUtilidades.isEmpty(formulario.getNumInformeSeleccion())) {
			PropertyParams propertyInforme = new PropertyParams();
			propertyInforme.addProperty("numInformeSeleccion", formulario.getNumInformeSeleccion());
			propertyInforme.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyInforme.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<InformeSeleccion> t10411lista = t10411informeselecDAO.findByProperties(propertyInforme,
					AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10411lista)) {
				for (InformeSeleccion informeSeleccion : t10411lista) {
					informeSeleccion.setFecModif(new Date());
					informeSeleccion.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_ORDEN_ENPROCESO);
					informeSeleccion.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
					informeSeleccion.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
					t10411informeselecDAO.update(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
		}
	}
}
