package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAdm;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoIqbfSine;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10406DocumentoAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8076DocumentoAdmDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T9917DocumentoIqbfSineDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.ComunService;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class VerificarEstadoNotificacionBatchServiceImpl implements VerificarEstadoNotificacionBatchService{
//CUS27
	
	private static final Logger logger = LoggerFactory.getLogger(VerificarEstadoNotificacionBatchServiceImpl.class);
	
	@EJB
	private T10406DocumentoAccionDAO t10406DocumentoAccionDAO; 

	@EJB
	private T10415OrdenAccionDAO t10415OrdenAccionDAO;

	@EJB
	private T9917DocumentoIqbfSineDAO t9917DocumentoIqbfSineDAO;
	
	@EJB
	private T8076DocumentoAdmDAO t8076DocumentoAdmDAO;

	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;
	
	@EJB
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;

	@EJB
	CargaUsuarioBatchService cargaUsuarioBatchService;
	
	@EJB
	private GenerarOrdenesOtrosProgramasBatchService generarOrdenesOtrosProgramasBatchService;

	@EJB
	private ComunService comunService;
	
	public ResponseBean<String> verificarEstadoNotificacion(){
		
		if (logger.isWarnEnabled())
			logger.warn("Inicio VerificarEstadoNotificacionBatchServiceImpl - verificarEstadoNotificacion");
		
		ResponseBean<String> respuesta = new ResponseBean<>();
		
		DocumentoAccionBean filtroDocumentacion = new DocumentoAccionBean();
		filtroDocumentacion.setCodEstadoDocumento(AccionesControlConstantes.COD_ESTADO_DOCACCION_PENDIENTENOTIF);
		filtroDocumentacion.setIndOrigen(AccionesControlConstantes.COD_IND_ORIGEN_DOCUMENTOACC_ELETRONICO);
		filtroDocumentacion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		
		List<DocumentoAccion> listaDocumentoAcion = t10406DocumentoAccionDAO.listarDocumentoPendienteNotificacion(filtroDocumentacion);
		
		OrdenAccionBean ordnAcc; 
		UsuarioProgramacion usrProg;
		
		List<Long> lstNumProgramaciones = new ArrayList<>();
		
		if (!MaestrosUtilidades.isEmpty(listaDocumentoAcion)) {
			for (DocumentoAccion docuAccion: listaDocumentoAcion){
				
				DocumentoIqbfSine documentoIqbfSine = this.validarNotificacion(docuAccion); 
				

				if (!MaestrosUtilidades.isEmpty(documentoIqbfSine)){
					logger.debug("no es vacio documentoIqbfSine ");
					
					DocumentoAccion docuAccionUpd = t10406DocumentoAccionDAO.findById(docuAccion.getNumDocumentoAccion(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
					
					usrProg = t10428UsuarioProgDAO.findById(docuAccion.getNumUsuarioPrograma(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
					lstNumProgramaciones.add(usrProg.getNumProgramacion());
					
					docuAccionUpd.setCodEstadoDocumento(AccionesControlConstantes.COD_ESTADO_DOCACCION_NOTIFICADO);
					docuAccionUpd.setFecNotificacion(documentoIqbfSine.getFecRealLect());
					docuAccionUpd.setFecModif(new Date());
					docuAccionUpd.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					docuAccionUpd.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					
					Date fecFinSubsanacion = comunService.obtenerFechaConDiasHabiles(documentoIqbfSine.getFecRealLect(), docuAccion.getNumPlazoVerif(),false);
					docuAccionUpd.setFecFinSubsanacion(fecFinSubsanacion);

					t10406DocumentoAccionDAO.update(docuAccionUpd, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					
					// Generar orden de accion
					ordnAcc = new OrdenAccionBean();
					ordnAcc.setNumUsuarioPrograma(docuAccion.getNumUsuarioPrograma());
					ordnAcc.setCodTipoOrden(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
					ordnAcc.setCodEstadoOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_GENERADA);
					
					generarOrdenesOtrosProgramasBatchService.ingresarOrdenOtroPrograma(ordnAcc);
				}
			}

			//-	Verificar si todos los documentos (accion) fueron notificados, 
			//de ser el caso se actualiza el estado de la programaci�n
			logger.debug(" actualizarProgramacion lstNumProgramaciones ==> " + lstNumProgramaciones.size());
			actualizarProgramacion(lstNumProgramaciones);
			
			//fuera de loop
			
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin VerificarEstadoNotificacionBatchServiceImpl - verificarEstadoNotificacion");
		
		return respuesta;
	}
	
	private DocumentoIqbfSine validarNotificacion(DocumentoAccion docuAccion){
		//Seg�n lo coordinado con Gresia debe devolver el objeto
		if (logger.isWarnEnabled())
			logger.warn("Inicio VerificarEstadoNotificacionBatchServiceImpl - validarNotificacion");
		
		//boolean estaNotificado = false;
		DocumentoIqbfSine documentoIqbfSine = null;
		PropertyParams propertyParams = new PropertyParams();
		
		/** buscar si esta notificado el codigo de pedido */
		
		/*
		propertyParams.addProperty("numPedido", String.valueOf(docuAccion.getNumPedido()) );
		propertyParams.addProperty("codTipdocumento", String.valueOf(docuAccion.getCodTipoDocumento()));
		propertyParams.addProperty("numDoc", String.valueOf(docuAccion.getNumDocumento()));
		propertyParams.addProperty("fecRealLect", MaestrosUtilidades.stringToDate(AccionesControlConstantes.FECHA_ESTANDAR, MaestrosConstantes.FORMAT_FECHAHORA_DDMMYYYYHHMMSS));//<>
		
		List<DocumentoIqbfSine> lstDomtoIqbf = t9917DocumentoIqbfSineDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		*/
		logger.warn("NumIdDoc ==> " + docuAccion.getNumIdDoc());
		
		DocumentoIqbfSine lstDomtoIqbf = t9917DocumentoIqbfSineDAO.findById(Long.parseLong(docuAccion.getNumIdDoc()), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		if (!MaestrosUtilidades.isEmpty(lstDomtoIqbf)) {
			//for(DocumentoIqbfSine docIqbfSine : lstDomtoIqbf){
				
				DocumentoAdm docuAdm = t8076DocumentoAdmDAO.findById(lstDomtoIqbf.getNumIdDoc(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
				
				if (!MaestrosUtilidades.isEmpty(docuAdm)) {
					logger.warn(" no es empty docuAdm ==> " + docuAdm);	
					documentoIqbfSine = lstDomtoIqbf;//docIqbfSine;
					//break;
				}
				
			//}
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin VerificarEstadoNotificacionBatchServiceImpl - validarNotificacion");
		
		return documentoIqbfSine;
	}
	
	private void actualizarProgramacion(List<Long> lstNumProgramaciones){
		if (logger.isWarnEnabled())
			logger.warn("Inicio VerificarEstadoNotificacionBatchServiceImpl - actualizarProgramacion");
		
		UsuarioProgramacion usrProg = new UsuarioProgramacion();
		
		Set<Long> hashSet = new HashSet<>(lstNumProgramaciones);
		lstNumProgramaciones.clear();
		lstNumProgramaciones.addAll(hashSet);
		
		logger.warn("size actualizarProgramacion = " + lstNumProgramaciones.size());
		
		PropertyParams propertyParams = new PropertyParams();
		
		propertyParams.addPropertyOperador("codEstadoDocumento", AccionesControlConstantes.COD_ESTADO_DOCACCION_NOTIFICADO, "<>");
		propertyParams.addProperty("indOrigen", AccionesControlConstantes.COD_IND_ORIGEN_DOCUMENTOACC_ELETRONICO);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		List<DocumentoAccion> lstDocumAccion = t10406DocumentoAccionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		logger.warn("size lstDocumAccion = " + lstDocumAccion.size());
		
		List<Long> lstNumProgramacionesActualizar = new ArrayList<>();
		
		if (!MaestrosUtilidades.isEmpty(lstDocumAccion)) {
			for (DocumentoAccion docuAccion: lstDocumAccion){
				usrProg = t10428UsuarioProgDAO.findById(docuAccion.getNumUsuarioPrograma(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
				for(Long numProgramacion : lstNumProgramaciones){
					logger.warn("numProgramacion == usrProg.getNumProgramacion() ==> " + numProgramacion + " == "+ usrProg.getNumProgramacion() );
					if(numProgramacion == usrProg.getNumProgramacion()){
						lstNumProgramacionesActualizar.add(numProgramacion);
					}
				}
			}
			
			hashSet = new HashSet<>(lstNumProgramacionesActualizar);
			lstNumProgramacionesActualizar.clear();
			lstNumProgramacionesActualizar.addAll(hashSet);
			
			logger.warn("size lstNumProgramacionesActualizar = " + lstNumProgramacionesActualizar.size());
			
			for(Long numProgramacion : lstNumProgramacionesActualizar){
				
				ProgramacionBean bProgramacion = new ProgramacionBean();
				
				bProgramacion.setNumProgramacion(numProgramacion);
				bProgramacion.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_NOTIFICADA);
				
				cargaUsuarioBatchService.actualizarEstadoProgramacion(bProgramacion);
			}
			
		 }
		if (logger.isDebugEnabled())
			logger.debug("Fin VerificarEstadoNotificacionBatchServiceImpl - actualizarProgramacion");
	}
}
