package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.HistorialEstadosPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10394AsignaUsuAccDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10406DocumentoAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10410HistEstadoProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10413MovProgramDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.MensajeIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.MensajeIqbfService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class EvaluacionProgramaServiceImpl implements EvaluacionProgramaService {

	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@EJB
	private ServicioWebService servicioWebService;
	@EJB
	private GestionProgramaAsignadoService gestionProgramaAsignadoService;
	@EJB
	private ComunService comunService;
	@EJB
	private T8276CatProgCtrlDAO t8276CatProgCtrlDAO;
	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;
	@EJB
	private T10410HistEstadoProgDAO t10410HistEstadoProgDAO;
	@EJB
	private T10411InformeSelecDAO t10411InformeSelecDAO;
	@EJB
	private T10413MovProgramDAO t10413MovProgramDAO;
	@EJB
	private DataCatalogoService dataCatalogoService;
	@EJB
	private MensajeIqbfService mensajeIqbfService;
	@EJB
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;
	@EJB
	private T10406DocumentoAccionDAO t10406DocumentoAccionDAO;
	@EJB
	private T10394AsignaUsuAccDAO t10394asignausuaccDAO;
	@Override
	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaServiceImpl - listarProgramacion");
		Programacion filtroModel = new Programacion();
		filtroModel.setNumProgramacion(filtro.getNumProgramacion());
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
			filtroModel.setCodEstadoPrograma(filtro.getCodEstadoPrograma());	
		}
//		else {
//			if(filtro.getCodCargoPrincipal().equals(AccionesControlConstantes.COD_CARGO_SUPERVISOR) || filtro.getCodCargoPrincipal().equals(AccionesControlConstantes.COD_CARGO_SUPERVISOR_PROG)){
//				filtroModel.setEstadosPrograma(Arrays.asList(AccionesControlConstantes.COD_EST_PROGRAM_PROGRAMADO,
//						AccionesControlConstantes.COD_EST_PROGRAM_DEVUELTO_GERENCIA));	
//			}else if(filtro.getCodCargoPrincipal().equals(AccionesControlConstantes.COD_CARGO_GERENTE)){
//				// PERFIL GERENTE DEVUELVE AccionesControlConstantes.COD_EST_PROGRAM_APROBADO
//				filtroModel.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_APROBADO);
//			}
//		}
		filtroModel.setNumInforme(filtro.getNumInforme());
		filtroModel.setNroInformeUnion(filtro.getNroInformeUnion());
		filtroModel.setCodProgctrl(filtro.getCodProgramaControl());
		filtroModel.setCodProgramador(filtro.getCodProgramador());
		filtroModel.setCodProgramadorAdmin(filtro.getCodProgramadorAdmin());
		filtroModel.setCodEstadoInforme(filtro.getCodEstadoInforme());	
		filtroModel.setIndTipoAsignacion(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR);
		filtroModel.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		filtroModel.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		List<Programacion> t10420Programacion  = t10420ProgramacionDAO.listarProgramacion(filtroModel);
		List<ProgramacionBean> listaPrograma=new ArrayList<ProgramacionBean>();
		 if (!MaestrosUtilidades.isEmpty(t10420Programacion)) {
			    ProgramacionBean programacionBean = null;
				for (Programacion valores : t10420Programacion) {
					programacionBean = new ProgramacionBean();
					programacionBean.setCodEstadoInforme(valores.getCodEstadoInforme());
					programacionBean.setNumInforme(valores.getNumInforme());
					programacionBean.setNroInformeUnion(valores.getNroInformeUnion());
					programacionBean.setCodProgramaControl(valores.getCodProgctrl());
					programacionBean.setDesProgramaControl(valores.getDesProgctrl());
					programacionBean.setNumProgramacion(valores.getNumProgramacion());
					programacionBean.setCodProgramador(valores.getCodProgramador());
					programacionBean.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(valores.getFecProgramacion()));
		          	obtenerDatosCatalogo( programacionBean, valores);
		          	programacionBean.setCantFinalUsuario(valores.getCantFinalUsuario());
		          	programacionBean.setCantUsuariosDepurados(valores.getCantUsuariosDepurados());
					PropertyParams mvPropertyParams = new PropertyParams();
					boolean descendente=true;
					mvPropertyParams.addProperty("numProgramacion",valores.getNumProgramacion());
					mvPropertyParams.addPropertyOrder("numMovimientoPrograma", descendente);
					List<MovimientoProgramacion> lista= t10413MovProgramDAO.findByProperties(mvPropertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
					if(!MaestrosUtilidades.isEmpty(lista)){
						programacionBean.setFecEstadoProgramacion(MaestrosUtilidades.dateToStringYYYYMMDD(lista.get(0).getFecMovimiento()));	
						if(lista.get(0).getCodPersonaMovimiento()!=null){
							WSPersonalIqbfBean servicioWebServ = servicioWebService.obtenerPersonalIqbf(lista.get(0).getCodPersonaMovimiento());
							programacionBean.setDesSupervisor(servicioWebServ.getNomCompleto());	
						}						
					}
										
//					PropertyParams uPropertyParams = new PropertyParams();
//					uPropertyParams.addProperty("numUsuarioPrograma",valores.getNumUsuarioPrograma());
////					uPropertyParams.addProperty("codPers",valores.getCodPers());
//					uPropertyParams.addProperty("codCargo",AccionesControlConstantes.COD_CARGO_SUPERVISOR);
//					List<AsignaUsuarioAccion> listaSupervisor= t10394asignausuaccDAO.findByProperties(uPropertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
//					if(!MaestrosUtilidades.isEmpty(listaSupervisor)){
//						WSPersonalIqbfBean servicioWebServ = servicioWebService.obtenerPersonalIqbf(listaSupervisor.get(0).getCodPers());
//						programacionBean.setDesSupervisor(servicioWebServ.getNomCompleto());						
//					}
					programacionBean.setNumUsuarioPrograma(String.valueOf(valores.getNumUsuarioPrograma()));
		          	listaPrograma.add(programacionBean);
				}
			if (!MaestrosUtilidades.isEmpty(filtro.getDesProgramador())) {
				listaPrograma = AccionesControlUtil.listByDesProgramador(listaPrograma, filtro);
			}
			}
		return listaPrograma;
	}
	
	private void obtenerDatosCatalogo(ProgramacionBean programacionBean,Programacion valores){
		DataCatalogoBean catalogo = null;
		if (!MaestrosUtilidades.isEmpty(valores.getCodProgramador())) {
			WSPersonalIqbfBean servicioWebServ = servicioWebService.obtenerPersonalIqbf(valores.getCodProgramador());
			if (!MaestrosUtilidades.isEmpty(servicioWebServ)) {
				programacionBean.setDesProgramador(servicioWebServ.getNomCompleto()); 
				programacionBean.setNomProgramador(servicioWebServ.getNomCompleto());
			} else {
				programacionBean.setDesProgramador("");
				programacionBean.setNomProgramador("");
			}
		}
		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_FUENTES_PROGRAMAS,
				valores.getCodFuente());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesFuente(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_PROGRAMACION,
				valores.getCodTipoProgram());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesTipoProgram(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,
				valores.getCodEstadoPrograma());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesEstadoProgram(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_SUBESTADOS_PROGRAMACION,
				valores.getCodSubEstadoProgram());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesSubEstprogram(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_PROCESOS_PROGRAMACION,
				valores.getCodProceso());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesProceso(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_INFORMESELECCION,
				valores.getCodEstadoInforme());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesEstadoInforme(catalogo.getDescripcionDataCatalogo());
		}
		if (!MaestrosUtilidades.isEmpty(valores.getCodProgramadorAdmin())) {
			WSPersonalIqbfBean servicioWebServ = servicioWebService
					.obtenerPersonalIqbf(valores.getCodProgramadorAdmin());
			if (!MaestrosUtilidades.isEmpty(servicioWebServ)) {
				programacionBean.setNomProgramadorAdmin(servicioWebServ.getNomCompleto());
			} else {
				programacionBean.setNomProgramadorAdmin("");
			}
		}
	}
	
	@Override
	public List<ProgramaControlBean> obtenerTipoProgramaControl(Integer numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaServiceImpl - obtenerTipoProgramaControl");

		List<ProgramaControlBean> listProgramaControlBean = null;
		List<ProgramaControl> t8276 = t8276CatProgCtrlDAO.obtenerTipoProgCtrl(numProgramacion);
		if (!MaestrosUtilidades.isEmpty(t8276)) {
			listProgramaControlBean = new ArrayList<>();
			MaestrosUtilidades.copiarValoresBean(t8276, listProgramaControlBean);
		}
		return listProgramaControlBean;
	}

	@Override
	public List<DataCatalogoBean> obtenerEstadosProgramacion(){
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaServiceImpl - obtenerEstadosProgramacion");
		return dataCatalogoService.listarCatalogos(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS);
	}
	@Override
	public List<DataCatalogoBean> obtenerEstadosInformeSeleccion(){
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaServiceImpl - obtenerEstadosInformeSeleccion");
		return dataCatalogoService.listarCatalogos(AccionesControlConstantes.COD_ESTADOS_INFORME_SELECCION);		
	}
	
	@Override
	public List<UsuarioProgramacionBean> listarUsuarioProgramacion(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaServiceImpl - listarUsuarioProgramacion");
		List<UsuarioProgramacionBean> lista= gestionProgramaAsignadoService.listarUsuarioProgramacion(filtro);
		return lista;
	}
	@Override
	public ArchivoBean obtenerArchivo(Long numArc) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaServiceImpl - obtenerArchivo");
		 ArchivoBean archivoBean = comunService.obtenerArchivo(Long.valueOf(numArc));
		return archivoBean;
	}
	@Override
	@Transactional
	public Programacion guardarProgramacion(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio EvaluacionProgramaServiceImpl - guardarEvaluacionProgramacion");	
			
		Programacion programacion=  t10420ProgramacionDAO.findById(filtro.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		HistorialEstadosPrograma historialEstadosPrograma= new HistorialEstadosPrograma();
		
		MovimientoProgramacion mv = new MovimientoProgramacion();
		String codEstadoProgram = filtro.getCodEstadoPrograma();
		MensajeIqbfBean plantillaMensajeAutorizacion = null;
		DataCatalogoBean dataCatalogoBean = null;	
		String codMensajeCorreo="";
		String codEstadoInforme = "";
		if(codEstadoProgram.equals(AccionesControlConstantes.COD_EST_PROGRAM_APROBADO)){
			codEstadoInforme=AccionesControlConstantes.COD_ESTADO_INFORME_APROBADO;
			codMensajeCorreo=AccionesControlConstantes.COD_MENSAJE_CORREO_F09;
			 plantillaMensajeAutorizacion = mensajeIqbfService.obtenerPlantillaMensajeIQBF(codMensajeCorreo, AccionesControlConstantes.COD_TIPO_PROCESO);
			 dataCatalogoBean = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CORREO_AUTORIZACION, AccionesControlConstantes.COD_CATALOGO_CORREO_AUTORIZACION_RECEPTOR);	
			
		}else if(codEstadoProgram.equals(AccionesControlConstantes.COD_EST_PROGRAM_AUTORIZADO)){
			codEstadoInforme=AccionesControlConstantes.COD_ESTADO_INFORME_AUTORIZADO;
			codMensajeCorreo=AccionesControlConstantes.COD_MENSAJE_CORREO_F10;
			 plantillaMensajeAutorizacion = mensajeIqbfService.obtenerPlantillaMensajeIQBF(codMensajeCorreo, AccionesControlConstantes.COD_TIPO_PROCESO);
			 dataCatalogoBean = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CORREO_AUTORIZACION, AccionesControlConstantes.COD_CATALOGO_CORREO_AUTORIZACION_RECEPTOR);
		}
		if(!codEstadoProgram.equals(AccionesControlConstantes.COD_EST_PROGRAM_DEVUELTO_GERENCIA) && 
		   !codEstadoProgram.equals(AccionesControlConstantes.COD_EST_PROGRAM_DEVUELTO_SUPERVISOR)){
			programacion.setNumInforme(filtro.getNumInforme());
			programacion.setCodEstadoPrograma(codEstadoProgram);
			programacion.setNumProgramacion(filtro.getNumProgramacion());
			programacion.setFecModif(new Date());
			programacion.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
			programacion.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
			t10420ProgramacionDAO.update(programacion,AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			historialEstadosPrograma.setNumHistoriaProgram(t10410HistEstadoProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_HISTORIAL_ESTADOPROG, AccionesControlConstantes.DATASOURCE_DCSICOBF));
			historialEstadosPrograma.setNumProgramacion(filtro.getNumProgramacion());
			historialEstadosPrograma.setCodEstadoPrograma(codEstadoProgram);
			historialEstadosPrograma.setFecEstadoProgram(new Date());
			historialEstadosPrograma.setFecCrea(new Date());
			historialEstadosPrograma.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
			historialEstadosPrograma.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
			historialEstadosPrograma.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			historialEstadosPrograma.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10410HistEstadoProgDAO.save(historialEstadosPrograma, AccionesControlConstantes.DATASOURCE_DGSICOBF);		
		}else{
			codEstadoProgram=AccionesControlConstantes.COD_EST_PROGRAM_PROGRAMADO;
			if(codEstadoProgram.equals(AccionesControlConstantes.COD_EST_PROGRAM_DEVUELTO_GERENCIA)){
				codEstadoInforme=AccionesControlConstantes.COD_EST_INFOR_SELEC_DEVUELTO_X_GERENCIA;
			}else if(codEstadoProgram.equals(AccionesControlConstantes.COD_EST_PROGRAM_DEVUELTO_SUPERVISOR)){
				codEstadoInforme=AccionesControlConstantes.COD_EST_INFOR_SELEC_DEVUELTO_X_SUPERVISOR;
			}
			codMensajeCorreo=AccionesControlConstantes.COD_MENSAJE_CORREO_F10;
			 plantillaMensajeAutorizacion = mensajeIqbfService.obtenerPlantillaMensajeIQBF(codMensajeCorreo, AccionesControlConstantes.COD_TIPO_PROCESO);
			 dataCatalogoBean = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CORREO_AUTORIZACION, AccionesControlConstantes.COD_CATALOGO_CORREO_AUTORIZACION_RECEPTOR);			
		}
		if(!("").equals(filtro.getNumInforme()) && filtro.getNumInforme()!=null){
			InformeSeleccion informeSeleccion = t10411InformeSelecDAO.findById(Long.valueOf(filtro.getNumInforme()),  AccionesControlConstantes.DATASOURCE_DCSICOBF);
			informeSeleccion.setNumInformeSeleccion(Long.valueOf(filtro.getNumInforme()));
			informeSeleccion.setCodEstadoInforme(codEstadoInforme);	
			informeSeleccion.setFecModif(new Date());
			informeSeleccion.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
			informeSeleccion.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
			t10411InformeSelecDAO.update(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);						
		}
		mv.setNumMovimientoPrograma(t10413MovProgramDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_MOVIMIENTO_PROGRAMA, AccionesControlConstantes.DATASOURCE_DCSICOBF));
		mv.setNumProgramacion(filtro.getNumProgramacion());
		mv.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
		mv.setCodEstadoPrograma(filtro.getCodEstadoPrograma());
		mv.setCodEstadoInforme(codEstadoInforme);
		mv.setDesSusDevolucion(filtro.getDesSusCancela());
		mv.setFecCrea(new Date());
		mv.setFecMovimiento(new Date());
		mv.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
		mv.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
		t10413MovProgramDAO.save(mv, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		ResponseBean<String> respuestaCorreo = null;
		if(dataCatalogoBean!=null){
			respuestaCorreo = enviaCorreoAutorizacion(dataCatalogoBean.getDescripcionDataCatalogo(),programacion,plantillaMensajeAutorizacion);
			if(respuestaCorreo.isExito()) logger.debug("Envio Correo Autorizacion");			
		}			
		
		return programacion;
	}

	private ResponseBean<String> enviaCorreoAutorizacion(String correoReceptor,Programacion programacion,
			MensajeIqbfBean mensaje) {
		CorreoBean correoBean = new CorreoBean();
		correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
		correoBean.setAsunto(mensaje.getDesCorta());
		correoBean.setReceptor(correoReceptor);
		String estadoProgramacion="-";
		DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,
				programacion.getCodEstadoPrograma());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			estadoProgramacion = catalogo.getDescripcionDataCatalogo();
		}
		
		String cuerpoMensaje = mensaje.getDesCuerpo()
					.replace(AccionesControlConstantes.MENSAJE_IQBF_PARAMETROS_NUMERO_SOLICITUD,programacion.getNumProgramacion().toString())
					.replace(AccionesControlConstantes.MENSAJE_IQBF_PARAMETROS_NUMERO_PROGRAMACION, programacion.getNumProgramacion().toString())
					.replace(AccionesControlConstantes.MENSAJE_IQBF_PARAMETROS_ESTADO_PROGRAMACION,estadoProgramacion);		
		if(programacion.getNumInforme()!=null){
			cuerpoMensaje = mensaje.getDesCuerpo()
					.replace(AccionesControlConstantes.MENSAJE_IQBF_PARAMETROS_NRO_INFORME_SELECCION, programacion.getNumInforme());
		}
				
		correoBean.setMensaje(cuerpoMensaje);
		return CorreoUtil.enviarCorreo(correoBean);
	}

	@Override
	public UsuarioProgramacionBean obtenerDocumentoVinculado(UsuarioProgramacionBean formulario) {
		PropertyParams propertyParams = new PropertyParams();
		UsuarioProgramacionBean bean= new UsuarioProgramacionBean();
		//Parametros de Consulta
		if(!MaestrosUtilidades.isEmpty(formulario.getNumUsuarioPrograma())) {
			propertyParams.addProperty("numUsuarioPrograma", formulario.getNumUsuarioPrograma());//Validar Existencia
			propertyParams.addProperty("codClase", AccionesControlConstantes.COD_CLASE_DOCUMENTO_VINCULADO);// PIDEN ESTE PARAMETRO PARA VALIDAR
		}			
	    List<DocumentoAccion> existe = t10406DocumentoAccionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
        if (!MaestrosUtilidades.isEmpty(existe)) {  
        	//Parametros de retorno
        	DocumentoAccion bexiste = existe.get(0);        	
        	bean.setNumDocumentoAccion(bexiste.getNumDocumentoAccion().toString());
        	bean.setNumUsuarioPrograma(bexiste.getNumUsuarioPrograma());        	      	
        	bean.setTipoDocumentoVinculado(bexiste.getCodTipoDocumento());
        	bean.setNumeroDocumentoVinculado(bexiste.getNumDocumento());  
        	bean.setIndDel(AccionesControlConstantes.COD_ESTADO_DOCACCION_GENERADO);
        	bean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
        	bean.setCodEstadoPrograma(AccionesControlConstantes.COD_ESTADO_DOCACCION_GENERADO);   	
        	bean.setNumUsuarioPrograma(bexiste.getNumUsuarioPrograma());        	
        	bean.setArchivoVinculado(comunService.obtenerArchivo(bexiste.getNumArc()) );
        	DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_DOCUMENTO_VINCULADO,
        			bexiste.getCodTipoDocumento());
        	if (!MaestrosUtilidades.isEmpty(catalogo)) {
            	bean.setDesTipoDocumentoVinculado(catalogo.getDescripcionDataCatalogo());        		
        	}
        	bean.setAuditoriaBean(formulario.getAuditoriaBean());
        }        
		return bean;
	}

	@Override
	public MovimientoProgramacion obtenerEvaluarPrograma(ProgramacionBean filtro) {
		PropertyParams propertyParams = new PropertyParams();
		boolean descendente= true;
		MovimientoProgramacion mv = null;
		propertyParams.addProperty("numProgramacion",filtro.getNumProgramacion());
		propertyParams.addPropertyOrder("numMovimientoPrograma", descendente);
		List<MovimientoProgramacion> lista= t10413MovProgramDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if(!MaestrosUtilidades.isEmpty(lista)){
			mv=lista.get(0);			
		}
		return mv;
	}
}
