package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class GenerarOrdenesOtrosProgramasBatchServiceImpl implements GenerarOrdenesOtrosProgramasBatchService
{

	private static final Logger logger = LoggerFactory.getLogger(GenerarOrdenesOtrosProgramasBatchServiceImpl.class);
	
	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private ServicioWebService servicioWebService;
	
	@EJB
	private T10411InformeSelecDAO informeSeleccionDAO;
	
	@EJB
	private T10428UsuarioProgDAO usuarioProgDAO;
	
	@EJB
	private T10415OrdenAccionDAO ordenAccionDAO;
	
	@EJB
	private T8414MensajeIqbfDAO mensajeIqbfDAO;
	
	@EJB
	private T10420ProgramacionDAO programacionDAO;
	
	
	public ResponseBean<String> generarOrdenesOtrosProgramas(Long numInformeSeleccion){
		if (logger.isWarnEnabled())
			logger.warn("Inicio GenerarOrdenesOtrosProgramasBatchServiceImpl - generarOrdenesOtrosProgramas");
		
		
		ResponseBean<String> respuesta = new ResponseBean<>();
		InformeSeleccionBean infSelec = new InformeSeleccionBean();
		boolean procesoCorrecto = false;
		
		infSelec.setNumInformeSeleccion(numInformeSeleccion);
		infSelec.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_GENERADO); 
		
		//1. Actualizar selecci�n a 'Generando OC/OF'.
		actualizarInformeSeleccion(infSelec);
		
		//2. Procesar las ordenes
		procesoCorrecto = procesarOrdenes(numInformeSeleccion);
		
		if(procesoCorrecto){
			infSelec.setCodEstadoInforme(AccionesControlConstantes.COD_EST_INFOR_SELEC_CONCLUIDO);
			
			respuesta.setExito(true);
			respuesta.setMensaje("OK");
		}else{
			infSelec.setCodEstadoInforme(AccionesControlConstantes.COD_EST_INFOR_SELEC_ERROR_GENERA_ORDENES);
			
			respuesta.setExito(false);
			respuesta.setMensaje("Error al generar las ordenes");
		}
		
		//3. actualizar el estado final de la ejecucion
		actualizarInformeSeleccion(infSelec);
		
		
		//4. envio de correo al programador administrativo
		// mensaje 11
		enviarCorreo(infSelec);
		
		if (logger.isDebugEnabled())
			logger.debug("Fin GenerarOrdenesOtrosProgramasBatchServiceImpl - generarOrdenesOtrosProgramas");
		
		return respuesta;
	}
	
	private void enviarCorreo(InformeSeleccionBean infSelec)
	{
		if (logger.isWarnEnabled())
			logger.warn("Inicio GenerarOrdenesOtrosProgramasBatchServiceImpl - enviarCorreo");
		
		String idMensaje = "";
		if(infSelec.getCodEstadoInforme().equals(AccionesControlConstantes.COD_EST_INFOR_SELEC_CONCLUIDO)){
			idMensaje = AccionesControlConstantes.COD_MENSAJE_CORREO_F11_2;
		}else{
			idMensaje = AccionesControlConstantes.COD_MENSAJE_CORREO_F11_4;
		}
				
		Long idNumInfrSelec = infSelec.getNumInformeSeleccion();
		InformeSeleccion infSelecModel = informeSeleccionDAO.findById(idNumInfrSelec, AccionesControlConstantes.DATASOURCE_DCSICOBF);

		Long numProgramacion = infSelecModel.getNumProgramacion();
		
		Programacion progamacion = programacionDAO.findById(numProgramacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		String codProgrEnvio = progamacion.getCodProgramador();
		
		WSPersonalIqbfBean personal = servicioWebService.obtenerPersonalIqbf(codProgrEnvio);
		
		String correo = personal.getDirCorreo();
		
		MensajeIqbf mensaje = mensajeIqbfDAO.findById(idMensaje, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		String asunto = mensaje.getDesCorta();
		String desCuerpo = mensaje.getDesCuerpo();
		
		Map<String, Object> parametros = new HashMap<>();
		parametros.put("nroProgramacion", progamacion.getNumProgramacion());
		parametros.put("desAlcance", progamacion.getDesAlcance());//0028
		CorreoBean correoBean = new CorreoBean();
		correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
		correoBean.setAsunto(asunto);
		correoBean.setReceptor(correo.trim());
		correoBean.setMensaje(AccionesControlUtil.generarMensaje(desCuerpo, parametros));
		CorreoUtil.enviarCorreo(correoBean);
		
		if (logger.isDebugEnabled())
			logger.debug("Fin GenerarOrdenesOtrosProgramasBatchServiceImpl - enclosing_method");
	}
	
	private int actualizarInformeSeleccion (InformeSeleccionBean infSelec){
		if (logger.isWarnEnabled())
			logger.warn("Inicio GenerarOrdenesOtrosProgramasBatchServiceImpl - actualizarInformeSeleccion");
		
		Long idNumInfrSelec = infSelec.getNumInformeSeleccion();
		InformeSeleccion infSelecModel = informeSeleccionDAO.findById(idNumInfrSelec, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		infSelecModel.setCodEstadoInforme(infSelec.getCodEstadoInforme());
		
		infSelecModel.setFecModif(new Date());
		infSelecModel.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
		infSelecModel.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
		
		informeSeleccionDAO.update(infSelecModel, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
		if (logger.isDebugEnabled())
			logger.debug("Fin GenerarOrdenesOtrosProgramasBatchServiceImpl - actualizarInformeSeleccion");
		
		return 1;
	}
	
	private boolean procesarOrdenes(Long numInformeSeleccion){
		if (logger.isWarnEnabled())
			logger.warn("Inicio GenerarOrdenesOtrosProgramasBatchServiceImpl - procesarOrdenes");
		
		boolean procesoCorreto = false;
		
		InformeSeleccion infrmSeleccion =  informeSeleccionDAO.findById(numInformeSeleccion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", infrmSeleccion.getNumProgramacion());
		
		List<UsuarioProgramacion> lst10420UsuarioProg  = usuarioProgDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		int correlativoControl = 1;
		int correlativoFiscalizacion = 1;
		OrdenAccionBean ordnAcc; 
		if (!MaestrosUtilidades.isEmpty(lst10420UsuarioProg)) {
			for(UsuarioProgramacion usrProgr : lst10420UsuarioProg){
				if(usrProgr.getCodTipoIntervencion().equals(AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL ))
				{
					//indicador �OF� (2 d�gitos).
					usrProgr.getCodTipoIntervencion();
					usrProgr.getNumUsuarioPrograma();
					//N�mero entero correlativo �nico. (4 d�gitos)
					//El a�o: AAAA (4 d�gitos).
					//C�digo de la Unidad Organizacional de 6 d�gitos.
					//ordnAcc.
					correlativoControl++;
				}else if(usrProgr.getCodTipoIntervencion().equals(AccionesControlConstantes.COD_TIP_INTERVENCION_FISCALIZACION )){
					
					correlativoFiscalizacion++;
				}
				ordnAcc = new OrdenAccionBean();
				ordnAcc.setNumUsuarioPrograma(usrProgr.getNumUsuarioPrograma());
				ordnAcc.setCodTipoOrden(usrProgr.getCodTipoIntervencion());
				ordnAcc.setCodUnidadOrganica(infrmSeleccion.getCodUnidadOrganica());
				ordnAcc.setCodEstadoOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_GENERADA);
				
				ingresarOrdenOtroPrograma(ordnAcc);
			}
			procesoCorreto = true;
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin GenerarOrdenesOtrosProgramasBatchServiceImpl - procesarOrdenes");
		
		return procesoCorreto;
	}
	
	public int ingresarOrdenOtroPrograma(OrdenAccionBean ordnAcc){
	
		if (logger.isWarnEnabled())
			logger.warn("Inicio GenerarOrdenesOtrosProgramasBatchServiceImpl - ingresarOrdenOtroPrograma");
		
		
		OrdenAccion ordnAccion = new OrdenAccion();
		Calendar fecha = Calendar.getInstance();
        int anio = fecha.get(Calendar.YEAR);
        
		Long secOrden = ordenAccionDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ORDENES_ACCION, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		//ordnAccion.setNumCorrel(secOrden.intValue());
		ordnAccion.setNumOrden(secOrden);
		ordnAccion.setNumUsuarioPrograma(ordnAcc.getNumUsuarioPrograma());
		ordnAccion.setCodTipoOrden(ordnAcc.getCodTipoOrden());
		
		//obtener el numero correlativo unico
		PropertyParams propertyParams = new PropertyParams();
		
		propertyParams.addProperty("codTipoOrden", ordnAcc.getCodTipoOrden() );
		propertyParams.addProperty("anioOrden", anio );
		
		Long cantidadResult = ordenAccionDAO.countByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(cantidadResult)) {
			cantidadResult++;
		}else {
			cantidadResult = (long) 1; }
		
		//ordenAccionDAO.findByJPQL(query, propertyParams, dataSource, clazz)
		
		ordnAccion.setNumCorrel(cantidadResult.intValue());
		ordnAccion.setAnioOrden(anio);
		
		ordnAccion.setCodUnidadOrganica(ordnAcc.getCodUnidadOrganica());
		ordnAccion.setCodEstadoOrden(ordnAcc.getCodEstadoOrden());
		
		ordnAccion.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
		ordnAccion.setFecCrea(new Date());
		ordnAccion.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
		ordnAccion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		ordnAccion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		
		ordenAccionDAO.save(ordnAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
		if (logger.isDebugEnabled())
			logger.debug("Fin GenerarOrdenesOtrosProgramasBatchServiceImpl - ingresarOrdenOtroPrograma");
		
		return 1;
	}
	
	public static String agregarCeros(String string, int largo)
	{
		if (logger.isWarnEnabled())
			logger.warn("Inicio GenerarOrdenesOtrosProgramasBatchServiceImpl - agregarCeros");
		
		
		StringBuilder ceros = new StringBuilder();
		int cantidad = largo - string.length();
		if (cantidad >= 1)
		{
			for(int i=0;i<cantidad;i++)
			{
				ceros.append("0");
			}
			
			if (logger.isDebugEnabled())
				logger.debug("Fin GenerarOrdenesOtrosProgramasBatchServiceImpl - agregarCeros");
			
			return (ceros.append(string).toString());
		}
		else{
			
			if (logger.isDebugEnabled())
				logger.debug("Fin GenerarOrdenesOtrosProgramasBatchServiceImpl - agregarCeros");
			
			return string; 
			
		}
		
	}
}
