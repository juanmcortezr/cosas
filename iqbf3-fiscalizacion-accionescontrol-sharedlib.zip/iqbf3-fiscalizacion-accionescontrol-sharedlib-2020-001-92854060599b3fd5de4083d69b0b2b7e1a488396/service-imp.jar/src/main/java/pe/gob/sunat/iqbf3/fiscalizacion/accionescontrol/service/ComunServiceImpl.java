package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoDataAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10445ArcAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10446ArcDataAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ParametrosBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.FileManagerService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ParametrosService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

@Stateless(name="accionescontrol.comunService")
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ComunServiceImpl implements ComunService {

	private static final Logger logger = LoggerFactory.getLogger(ComunServiceImpl.class);

	@EJB
	private T10445ArcAcfDAO t10445ArcAcfDAO;
	
	@EJB
	private T10446ArcDataAcfDAO t10446ArcDataAcfDAO;

	@EJB
	private FileManagerService fileManagerService;
	
	@EJB
	private DataCatalogoService dataCatalogoService;
	
	@EJB
	private ParametrosService parametrosService;
	
	@Override
	public Long guardarArchivo(ArchivoBean archivoBean, AuditoriaBean auditoriaBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ComunServiceImpl - guardarArchivo");
		if (!AccionesControlConstantes.TIPO_ARCHIVO_TMP.equals(archivoBean.getTipo())) {
			return archivoBean.getNumArc();
		}
		boolean esRegistro = MaestrosUtilidades.isEmpty(archivoBean.getNumArc());
		ArchivoAcciones archivoAcciones = esRegistro ? new ArchivoAcciones() : t10445ArcAcfDAO.findById(archivoBean.getNumArc(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		archivoAcciones.setCodTipoArchivo(archivoBean.getCategoria());
		archivoAcciones.setNombArchivoAcciones(archivoBean.getNomArchivo());
		archivoAcciones.setDesMimeType(archivoBean.getDesMimeType());
		archivoAcciones.setCntPesoArc(archivoBean.getCntPesArch());
		archivoAcciones.setNumEcm(archivoBean.getNumEcm());
		archivoAcciones.setNumArc(archivoBean.getNumArc());
		archivoAcciones.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		archivoAcciones.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);

		if (esRegistro) {
			archivoAcciones.setNumArc(t10445ArcAcfDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ARCHIVOS_ACCIONES,
					AccionesControlConstantes.DATASOURCE_DGSICOBF));
			archivoAcciones.setFecCrea(new Date());
			archivoAcciones.setDirIpusucrea(auditoriaBean.getNumIp());
			archivoAcciones.setCodUsuCrea(auditoriaBean.getLogin());
			t10445ArcAcfDAO.save(archivoAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			archivoAcciones.setFecModif(new Date());
			archivoAcciones.setDirIpusumodif(auditoriaBean.getNumIp());
			archivoAcciones.setCodUsuModif(auditoriaBean.getLogin());
			t10445ArcAcfDAO.update(archivoAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
		}

		// Validar
		ArchivoDataAcciones t10446 = t10446ArcDataAcfDAO.obtenerArcDataNoBytes(archivoBean.getNumArc());

		ArchivoDataAcciones archivoDataAcciones = MaestrosUtilidades.isEmpty(t10446) ? new ArchivoDataAcciones() : t10446;
		archivoDataAcciones.setNumArchAcciones(archivoAcciones.getNumArc());
		if (AccionesControlConstantes.TIPO_ARCHIVO_TMP.equals(archivoBean.getTipo())) {
			archivoDataAcciones.setArchivoContenido(fileManagerService.descargarArchivoTemporal(archivoBean.getUuid()));
		}
		archivoDataAcciones.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		archivoDataAcciones.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		if (!MaestrosUtilidades.isEmpty(t10446)) {
			archivoDataAcciones.setFecModif(new Date());
			archivoDataAcciones.setDirIpusumodif(auditoriaBean.getNumIp());
			archivoDataAcciones.setCodUsuModif(auditoriaBean.getLogin());
			t10446ArcDataAcfDAO.update(archivoDataAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			archivoDataAcciones.setFecCrea(new Date());
			archivoDataAcciones.setDirIpusucrea(auditoriaBean.getNumIp());
			archivoDataAcciones.setCodUsuCrea(auditoriaBean.getLogin());
			t10446ArcDataAcfDAO.save(archivoDataAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		return archivoAcciones.getNumArc();
	}

	@Override
	public ArchivoBean obtenerArchivo(Long numArc) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ComunServiceImpl - obtenerArchivo");
		ArchivoBean archivoBean = null;
		if (MaestrosUtilidades.isEmpty(numArc)) {
			return archivoBean;
		}
		ArchivoAcciones t10445 = t10445ArcAcfDAO.findById(numArc, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10445)) {
			archivoBean = new ArchivoBean();
			archivoBean.setDesMimeType(t10445.getDesMimeType());
			archivoBean.setCategoria(t10445.getCodTipoArchivo());
			archivoBean.setTipo(AccionesControlConstantes.TIPO_ARCHIVO_BD);
			archivoBean.setNumArc(numArc);
			archivoBean.setCntPesArch(t10445.getCntPesoArc());
			archivoBean.setNumEcm(t10445.getNumEcm());
			archivoBean.setNomArchivo(t10445.getNombArchivoAcciones());
		}
		return archivoBean;
	}
	
	@Override
	public String obtenerDescripcionCodCatalogo(String catalogo,String codDataCatalogo) {
		String descripcion="";
		DataCatalogoBean dataCatalogo = dataCatalogoService.obtenerCatalogo(catalogo, codDataCatalogo);
		if(!MaestrosUtilidades.isEmpty(dataCatalogo)) {
			descripcion=dataCatalogo.getDescripcionDataCatalogo();
		}
		return descripcion;
	}
	
	@Override
	public String obtenerDescripcionParametro(String numParam,String argParam) {
		String descripcion="";
		ParametrosBean paramBean= parametrosService.obtenerParametro(numParam,argParam);
		if(!MaestrosUtilidades.isEmpty(paramBean)&&paramBean.getFuncion()!=null) {
			descripcion=paramBean.getFuncion().trim();
		}
		return descripcion;
	}
	
	@Override
	public byte[] obtenerBytesArchivo(Long numArc) {
		ArchivoDataAcciones t10446 = t10446ArcDataAcfDAO.findById(numArc, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		return t10446.getArchivoContenido();
	}

}
