package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class EvaluacionResultadoServiceImpl implements EvaluacionResultadoService {

	@EJB
	private T10415OrdenAccionDAO t10415OrdenAccionDAO;
	
	@Override
	public int actualizarOrden(OrdenAccionBean ordenAccionBean) {
		//int resultado=0;
		OrdenAccion filtros=new OrdenAccion();
		MaestrosUtilidades.copiarValoresBean(ordenAccionBean, filtros);
		if(!MaestrosUtilidades.isEmpty(ordenAccionBean.getAuditoriaBean())) {
		filtros.setCodUsuModif(ordenAccionBean.getAuditoriaBean().getLogin());
		filtros.setDirIpusumodif(ordenAccionBean.getAuditoriaBean().getNumIp());
		}
		return t10415OrdenAccionDAO.actualizarOrdenGeneral(filtros);
	}
}
