package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CabezeraCpeBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenSaldoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenStockEstablecBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CabezeraCpe;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenSaldo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenStockEstablec;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T4241CabCpeDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5284BfCabJroDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5641RStockEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5642RSaldoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.bean.BfRegistroBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ParametrosBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSRegistroRUCBean;
import pe.gob.sunat.iqbf3.registro.maestros.model.BfRegistro;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ParametrosService;
import pe.gob.sunat.iqbf3.registro.maestros.service.RegistroBfService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class DepurarUsuariosProgramacionBatchServiceImpl implements DepurarUsuariosProgramacionBatchService{
//CUS24

	private static final Logger logger = LoggerFactory.getLogger(DepurarUsuariosProgramacionBatchServiceImpl.class);
	
	@EJB
	private CargaUsuarioBatchService cargaUsuarioBatchService;
	
	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;
	
	@EJB
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;
	
	@EJB
	private RegistroBfService registroBfService;
	
	@EJB
	private ServicioWebService servicioWebService;
	
	@EJB
	private ParametrosService parametrosService;
	
	@EJB
	private DataCatalogoService dataCatalogoService;
	
	@EJB
	private T8414MensajeIqbfDAO t8414MensajeIqbfDAO;
	
	@EJB
	private T5284BfCabJroDAO t5284BfCabJroDAO;
	
	@EJB
	private T5641RStockEstabDAO t5641RStockEstabDAO;
	
	@EJB
	private T5642RSaldoDAO t5642RSaldoDAO;

	@EJB
	private T4241CabCpeDAO t4241CabCpeDAO;
	
	@EJB
	T8276CatProgCtrlDAO t8276CatProgCtrlDAO;
	
	public ResponseBean<String> iniciarProcesamiento(Long numProgramacion){
	
		ResponseBean<String> respuesta = new ResponseBean<>();
		ProgramacionBean bProgramacion = new ProgramacionBean();
		Integer cntInconsistencia = 0;
		
		Programacion programacion = t10420ProgramacionDAO.findById(numProgramacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		UsuarioProgramacionBean usrProgrBean = new UsuarioProgramacionBean(); 
	//Obtener los usuarios con acci�n en estado diferente a �No aplica� de la programaci�n �Autorizada�. 
		usrProgrBean.setNumProgramacion(numProgramacion);
		usrProgrBean.setCodTipoAccionSugerida(AccionesControlConstantes.COD_ACCION_SUGERIDA_NOAPLICA);
		//usrProgrBean.setCodSubEstadoProgram(null);// aalanya falta indicar estado por gresia
		List<UsuarioProgramacion> listaUsuariosConAccion = t10428UsuarioProgDAO.listarUsuariosTipaccsuge(usrProgrBean);

	//Actualiza el Sub estado de programaci�n: �En Proceso de depuraci�n de usuarios�.
		bProgramacion.setCodSubEstadoProgram(AccionesControlConstantes.COD_SUBESTADO_ENPROCESO_DEPURACION);
		bProgramacion.setNumProgramacion(numProgramacion);
		
		cargaUsuarioBatchService.actualizarEstadoProgramacion(bProgramacion);
		
	try{
		if (!MaestrosUtilidades.isEmpty(listaUsuariosConAccion)) {
			UsuarioProgramacionBean usrProgrBeanLoop;
			UsuarioProgramacion usrProgrUpd;
			ParametrosBean parametro;
		 for (UsuarioProgramacion usrProgr : listaUsuariosConAccion){
			String codMotivoDepuracion = verificarEstadoRcbfRuc(usrProgr);
			
			if (!MaestrosUtilidades.isEmpty(codMotivoDepuracion)){
				// actualiza datos del usuario de la programacion
				
				usrProgrUpd = t10428UsuarioProgDAO.findById(usrProgr.getNumUsuarioPrograma(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
				
				usrProgrUpd.setCodTipoAccionSugerida(AccionesControlConstantes.COD_ACCION_SUGERIDA_NOAPLICA);
				usrProgrUpd.setCodEstadoUsuario(AccionesControlConstantes.COD_ESTADO_USUARIO_DEPURADO);
				usrProgrUpd.setCodMotivaDepuracion(codMotivoDepuracion);
				usrProgrUpd.setFecModif(new Date());
				usrProgrUpd.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
				usrProgrUpd.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
				
				t10428UsuarioProgDAO.update(usrProgrUpd, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				//t10428usuarioprog. actualizarUsuarioProg (Params)
				
			}else{
				// Se procede se a verificar si el usuario peramenece con la inconsistencia seg�n el programa de control 
				if(AccionesControlConstantes.COD_TIP_PROG_OMISOS_DJ.equals(usrProgr.getCodProgctrl())){
					cntInconsistencia = cntInconsistenciaProgramaControlOmisosDj(usrProgr);
				}
				if(AccionesControlConstantes.COD_TIP_PROG_USU_VIGENTES_STOCK_SALDO_NEGATIVO.equals(usrProgr.getCodProgctrl())){
					cntInconsistencia =  cntInconsistenciaProgramaStockSaldoNegativo(usrProgr);
				}
				if(AccionesControlConstantes.COD_TIP_PROG_USU_BAJA_STOCK.equals(usrProgr.getCodProgctrl())){
					cntInconsistencia =  cntInconsistenciaProgramaControlBajaOmisoStockNegativo(usrProgr);
				}
				if(AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_DESTINATARIO.equals(usrProgr.getCodProgctrl())){
					cntInconsistencia =  cntInconsisProgramaControlGreNoConfirmadasDestinatario(usrProgr);
				}
				if(AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_TRANSPORTISTA.equals(usrProgr.getCodProgctrl())){
					cntInconsistencia =  cntInconsisProgramaControlGreNoConfirmadasTransportista(usrProgr);
				}
				
				if(cntInconsistencia == 0){
					// actualiza el motivo de depuraci�n de usuario 
					usrProgrUpd = t10428UsuarioProgDAO.findById(usrProgr.getNumUsuarioPrograma(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
				
					usrProgrUpd.setCodMotivaDepuracion(AccionesControlConstantes.COD_MOTIVO_DEPURACION_SUBSANO_INCONSISTENCIA);
					usrProgrUpd.setCodEstadoUsuario(AccionesControlConstantes.COD_ESTADO_USUARIO_DEPURADO);
					usrProgrUpd.setFecModif(new Date());
					usrProgrUpd.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					usrProgrUpd.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					
					t10428UsuarioProgDAO.update(usrProgrUpd, AccionesControlConstantes.DATASOURCE_DGSICOBF);

				}
			}
		 }// fin de loop
		 
		 //Enviar un mensaje al correo del programador con la lista de usuarios depurados:
		   //Obtener la lista de usuarios depurados para la programaci�n: 
			 //list<UsuarioProgramacionBean> listaUsuariosDepurados  T10428usuarioprogDAO.listarUsuariosDepurados(Param)
		 	PropertyParams propertyParams = new PropertyParams();
		 	boolean descendente = true;
			propertyParams.addProperty("ind_depuracion", AccionesControlConstantes.COD_IND_DEPURACION_AUTOMATICA);
			propertyParams.addProperty("num_programacion", numProgramacion);
			propertyParams.addPropertyOrder("num_doc_ident", descendente);
			
			List<UsuarioProgramacion>  listaUsuariosDepurados = t10428UsuarioProgDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			
			//Recorrer la lista de usuarios depurados �listaUsuariosDepurados � 
			//para obtener la raz�n social, descripci�n del motivo de depuraci�n 
			if (!MaestrosUtilidades.isEmpty(listaUsuariosDepurados)){
				for(UsuarioProgramacion usrProgrDepurados: listaUsuariosDepurados){
					usrProgrBeanLoop = new UsuarioProgramacionBean();
					
					//Obtener los datos de RUC:
	                    //DatosRucBean =ddpDAO.datosRuc(usuarioProgramacionBean.num_doc_ident)
	                    //listaUsuariosDepurados.nombreRazonSocial =  DatosRucBean.ddpNombre
	                    		
						WSRegistroRUCBean regBeanRuc  = servicioWebService.obtenerRegistroRuc(usrProgrDepurados.getNumDocumentoIdentif());
						usrProgrBeanLoop.setNombreRazonSocial(regBeanRuc.getDdpNombre());
	                   
				   //Obtener estado actual del usuario en el registro:
						BfRegistroBean bFRegistroBean = new BfRegistroBean();
						bFRegistroBean.setNumRuc(usrProgrDepurados.getNumDocumentoIdentif());
						List<BfRegistro> lstBfRegistro = registroBfService.obtenerDatosUsuario(bFRegistroBean);
					
					//obtener la descripci�n del estado del registro
						if (!MaestrosUtilidades.isEmpty(lstBfRegistro)) {
							usrProgrBeanLoop.setCodEstadoRegistro(lstBfRegistro.get(0).getCodEstado());
							parametro = parametrosService.obtenerParametro(MaestrosConstantes.COD_PARAMETRO_ESTADO_REGISTRO, usrProgrBeanLoop.getCodEstadoRegistro());
							
							if (!MaestrosUtilidades.isEmpty(parametro)) {
								usrProgrBeanLoop.setDesEstadoRegistro(MaestrosUtilidades.toBlank(parametro.getFuncion()).trim());
							}
							
						}
					
					//obtener la descripci�n del motivo de depuraci�n
						DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_MOTIVOS_DEPURACION,usrProgrDepurados.getCodMotivaDepuracion());
						if (!MaestrosUtilidades.isEmpty(catalogo)) {
							usrProgrBeanLoop.setDesMotDepuracion(catalogo.getDescripcionDataCatalogo());
						}	
					
					//Arma el correo seg�n la plantilla de mensajes y la lista de listaUsuariosDepurados
					//CorreoReceptor=ServicioWebServiceImpl.obtenerDatosPersonalSunat(programacion.codProgramador)
						
						WSPersonalIqbfBean wSPersonalIqbfBean =  servicioWebService.obtenerPersonalIqbf(programacion.getCodProgramador());
						String correoReceptor = wSPersonalIqbfBean.getDirCorreo();
					
						
						MensajeIqbf mensajeCorreo = t8414MensajeIqbfDAO.findById(AccionesControlConstantes.COD_MENSAJE_CORREO_F14, AccionesControlConstantes.DATASOURCE_DCSICOBF);
						
						mensajeCorreo.getDesCorta();
						mensajeCorreo.getDesCuerpo();
						usrProgrBeanLoop.getNumDocumentoIdentif();
						usrProgrBeanLoop.getNombreRazonSocial();
						usrProgrBeanLoop.getDesEstadoRegistro();
						usrProgrBeanLoop.getDesMotDepuracion();
						
						//aalanya implementar correo:
						/*
						Reemplazar los valores {din�micos} en MensajeCorreo:
						-	MensajeCorreo.asunto.desCorta
						-	MensajeCorreo.mensaje.desCuerpo
						-	ListaUsuariosDepurados
						�	numDocumento
						�	nombreRazonSocial
						�	desEstadoActual
						�	desMotivoDepuracion
						
						Invoca a: 
						-	CorreoUtil.enviarCorreo()
						Params:
						-	ModuloCorreo (Correo: AccionesControl@sunat.gob.pe)
						-	UsuarioReceptor
						-	MensajeCorreo.asunto
						-	MensajeCorreo.mensaje
						*/
						Programacion prg = t10420ProgramacionDAO.findById(usrProgrDepurados.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
						ProgramaControl pControl = t8276CatProgCtrlDAO.findById(prg.getCodProgctrl(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
						
						Map<String, Object> parametros = new HashMap<>();
						parametros.put("nroProgramacion", usrProgrDepurados.getNumProgramacion());
						parametros.put("denominacionPrograma", pControl.getDesDenominacion());
						Map<String, Object> parametrosAsunto = new HashMap<>();
						parametrosAsunto.put("DENOMINACIONPROGRAMA", pControl.getDesDenominacion());
						CorreoBean correoBean = new CorreoBean();
						correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
						correoBean.setAsunto(AccionesControlUtil.generarMensaje(mensajeCorreo.getDesCorta(), parametrosAsunto));
						correoBean.setReceptor(wSPersonalIqbfBean.getDirCorreo().trim());
						correoBean.setMensaje(AccionesControlUtil.generarMensaje(mensajeCorreo.getDesCuerpo(), parametros));
						CorreoUtil.enviarCorreo(correoBean);
				}
			}
			
			
		 //Actualiza el Sub estado de programaci�n: �Pendiente de generaci�n de documentos�.
			bProgramacion.setCodSubEstadoProgram(AccionesControlConstantes.COD_SUBESTADO_PENDIENTE_GENERACION_DOCUMENTOS);
			bProgramacion.setNumProgramacion(numProgramacion);
			
			cargaUsuarioBatchService.actualizarEstadoProgramacion(bProgramacion);			
		}
	 }catch(Exception e){
		 //En caso de error Actualiza el Sub estado de programaci�n: �Error en el proceso de depuraci�n�.
		 bProgramacion.setCodSubEstadoProgram(AccionesControlConstantes.COD_SUBESTADO_ERROR_ENPROCESO_DEPURACION);
		 bProgramacion.setNumProgramacion(numProgramacion);
	
		 cargaUsuarioBatchService.actualizarEstadoProgramacion(bProgramacion);
	 }
		return respuesta;
	}
	
	private Integer cntInconsistenciaProgramaControlOmisosDj(UsuarioProgramacion usuarioProgramacion){
		
		Integer cntInconsistencia = 0;
		List<String> lstEstadoUsuario;
		BfRegistroBean bfRegistroBean;
		//Invocar al metodo para identificar si permanece la inconsistencia		
		bfRegistroBean = new BfRegistroBean();
		bfRegistroBean.setNumRuc(usuarioProgramacion.getNumDocumentoIdentif());
		bfRegistroBean.setCodEstado(AccionesControlConstantes.COD_ESTADO_DJROP_PENDIENTE);
		bfRegistroBean.setNumConfirma(AccionesControlConstantes.NUM_CONFIRMACION_SIN_ENVIO );
		lstEstadoUsuario = new ArrayList<>();
		lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
		lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
		bfRegistroBean.setLstEstadoUsuario(lstEstadoUsuario);
		bfRegistroBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		bfRegistroBean.setIndOmiso(AccionesControlConstantes.COD_ESTADO_DJROP_EXONERADO_DEL_MES);
		
		List<BfRegistro> lstUsrRegistro = registroBfService.cntOmiso(bfRegistroBean);
		cntInconsistencia = lstUsrRegistro.size();
		
		/*
		 * -	 

Param
	#num_ruc# = UsuarioProgramacionBean.numeroDocumento
	#cCodEstadoPendiente#  = Constantes.COD_ESTADO_DJROP_PENDIENTE   
	#num_confirma# = Constantes.NUM_CONFIRMACION_SIN_ENVIO  
	#list_cod_estado_registro# = constantes.COD_ESTADO_REGISTRO_VIGENTE, constantes. COD_ESTADO_REGISTRO_SUSPENDIDO
	Constantes. REGISTRO_NO_ELIMINADO
	#Ind_omiso# = constantes.COD_ESTADO_DJROP_EXONERADO_DEL_MES

cntInconsistencia integer =  T5284bfcabdjroDAO.cntOmiso(Param)

		 */
		
		return cntInconsistencia;
	}
	
	private Integer cntInconsistenciaProgramaStockSaldoNegativo(UsuarioProgramacion usuarioProgramacion){
		
		Integer cntInconsistencia = 0;
		Integer cntStock = 0;
		Integer cntSaldo = 0;
		List<String> lstEstadoRegistros;
		
		/*-	Invocar al metodo para identificar si permanece la inconsistencia 
			//Para verificar si tiene stock y/o saldo negativo 
			// Verificar el stock negativo para el usuario 
			
			Par�metros (Param)
				cIndDelActivo = Constantes.REGISTRO_NO_ELIMINADO
				#cCodEstadoBaja#= constantes.COD_ESTADO_REGISTRO_DEBAJA
				#ind_condicion #= constantes. IND_CONDICION_ITEM_REGISTRO  
				#numDocumento# =UsuarioInconsistencia.numRuc
				#cod_tipbien#= constantes.COD_TIPOBIEN_REGISTRO

				cntStock integer  =  T5641rstockestabDAO.cntStockNegativoVerificacion (Param)
		 */
		
			ResumenStockEstablecBean resumenStockEstablecBean = new ResumenStockEstablecBean();
			resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_ESTADO_REGISTRO_DEBAJA);
			resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
			resumenStockEstablecBean.setNumRuc(Integer.parseInt(usuarioProgramacion.getNumDocumentoIdentif()));
			resumenStockEstablecBean.setCodTipobien(AccionesControlConstantes.COD_TIPOBIEN_REGISTRO);
			List<ResumenStockEstablec> lstStockNegativo =  t5641RStockEstabDAO.cntStockNegativoVerificacion(resumenStockEstablecBean);
			
			
			for(ResumenStockEstablec resumenStockEstablec: lstStockNegativo){
				cntStock = resumenStockEstablec.getCntStockNegativoVerificacion().intValue();
			}
		
		//Verificar el saldo negativo para el usuario
			 /*
			
			
				Par�metros (ParamSaldo)
					ind_del = Constantes.REGISTRO_NO_ELIMINADO
					num_reposicion= Constantes.NUM_ULTIMA_REPOSICION 
					cod_estado_item = Constantes.COD_IND_CONDICION_ITEM_REGISTRO
					List_codestado_registro = constantes. COD_ESTADO_REGISTRO_VIGENTE, constantes. COD_ESTADO_REGISTRO_SUSPENDIDO
					ind_condicion = constantes. IND_CONDICION_ITEM_REGISTRO  
				
				cntSaldo  integer = List< ProgramaIncosistenciaSaldoBean >  SaldoNegativo = JPAT5642rsaldoDAO.cntSaldoNegativo(ParamSaldo)
	        */
			ResumenSaldoBean resumenSaldoBean = new ResumenSaldoBean();
			resumenSaldoBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			resumenSaldoBean.setNumReposicion(AccionesControlConstantes.NUM_ULTIMA_REPOSICION);
			resumenSaldoBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
			lstEstadoRegistros = new ArrayList<>();
			lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
			lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
			resumenSaldoBean.setLstEstadoRegistros(lstEstadoRegistros);
			
			
			List<ResumenSaldo> lstUsrInconsistenciaBean = t5642RSaldoDAO.cntSaldoNegativo(resumenSaldoBean);
			
			for(ResumenSaldo resumenSaldo: lstUsrInconsistenciaBean){
				cntSaldo = resumenSaldo.getCntSaldoNegativo().intValue();
			}

			
			
			/*
			//Setear si tiene inconsistencias 
	
			cntInconsistencia integer  = 0 
	
	           Si (cntStock  == 0 &&  cntSaldo  == 0 ) entonces 
					cntInconsisencia = 0
	           caso contrario  
					cntInconsistencia = 1
	
			Retorna  cntInconsistencia
		 */
		if (cntStock  == 0 &&  cntSaldo  == 0){
			cntInconsistencia = 0;
		}else cntInconsistencia = 1;
			
		return cntInconsistencia;
	}
	
	private Integer cntInconsistenciaProgramaControlBajaOmisoStockNegativo(UsuarioProgramacion usuarioProgramacion){
		
	 Integer cntInconsistencia = 0;
	 Integer cntOmiso = 0;
	 Integer cntStockNegativo = 0;
	 BfRegistroBean bfRegistroBean;
	 List<String> lstEstadoUsuario;
	 /*
	 //Invocar al m�todo para identificar si permanece la inconsistencia 
	 //Para verificar si el usuario sigue de baja
 
	 Param:
	 #cIndDelActivo#= constantes.REGISTRO_NO_ELIMINADO
	 #cCodEstadoBaja# = constantes.COD_ESTADO_REGISTRO_DEBAJA
	 #num_ruc# = numero de ruc del usuario 
		
	 List<UsuarioInconsistenciaBean>  UsuarioInconsistencia  = JPAT5075bfregistroDAO.ListaUsuarioBaja()
	 */
	 bfRegistroBean = new BfRegistroBean();
	 bfRegistroBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
	 bfRegistroBean.setCodEstadoBaja(AccionesControlConstantes.COD_ESTADO_REGISTRO_DEBAJA);
	 bfRegistroBean.setNumRuc(usuarioProgramacion.getNumDocumentoIdentif());
	  
	 List<BfRegistro> lstUsuarioInconsistencia =  registroBfService.listaUsuarioBaja(bfRegistroBean);
	 
	 if(lstUsuarioInconsistencia.size()>0){
		 //Verificar si el usuario se encuentra omiso
		  /*
			Param
			#num_ruc# = UsuarioInconsistenciaBean.numeroDocumento
			cCodEstadoPendiente  = Constantes.COD_ESTADO_DJROP_PENDIENTE   
			num_confirma = Constantes.NUM_CONFIRMACION_SIN_ENVIO  
			Constantes. REGISTRO_NO_ELIMINADO
			Ind_omiso = constantes.COD_ESTADO_DJROP_EXONERADO_DEL_MES
			
			  cntOmiso  integer  =  JPAT5075bfregistroDAO.cntOmiso(Param)		  
		  */
		    bfRegistroBean = new BfRegistroBean();
			bfRegistroBean.setNumRuc(usuarioProgramacion.getNumDocumentoIdentif());
			bfRegistroBean.setCodEstado(AccionesControlConstantes.COD_ESTADO_DJROP_PENDIENTE);
			bfRegistroBean.setNumConfirma(AccionesControlConstantes.NUM_CONFIRMACION_SIN_ENVIO );
			bfRegistroBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			bfRegistroBean.setIndOmiso(AccionesControlConstantes.COD_ESTADO_DJROP_EXONERADO_DEL_MES);
			//lstEstadoUsuario = new ArrayList<>();
			//lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
			//lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
			//bfRegistroBean.setLstEstadoUsuario(lstEstadoUsuario);
			
			List<BfRegistro> lstUsrRegistro = registroBfService.cntOmiso(bfRegistroBean);
			cntOmiso = lstUsrRegistro.size();
			
			//Verificar si el usuario tiene stock negativo
			/*
			Para verificar si tiene stock negativo 
			
			Par�metros (Param)
				cIndDelActivo = Constantes.REGISTRO_NO_ELIMINADO
				#cCodEstadoBaja#= constantes.COD_ESTADO_REGISTRO_DEBAJA
				#ind_condicion #= constantes. IND_CONDICION_ITEM_REGISTRO  
				#numDocumento# =UsuarioInconsistencia.numRuc
				#cod_tipbien#= constantes.COD_TIPOBIEN_REGISTRO
			
			cntStockNegativo integer  =  T5641rstockestabDAO.cntStockNegativoBaja(Param)
			*/
		 
			ResumenStockEstablecBean resumenStockEstablecBean = new ResumenStockEstablecBean();
			resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_ESTADO_REGISTRO_DEBAJA);
			resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
			resumenStockEstablecBean.setNumRuc(Integer.parseInt(usuarioProgramacion.getNumDocumentoIdentif()));
			resumenStockEstablecBean.setCodTipobien(AccionesControlConstantes.COD_TIPOBIEN_REGISTRO);
			List<ResumenStockEstablec> lstStockNegativo =  t5641RStockEstabDAO.cntStockNegativoBaja(resumenStockEstablecBean);
			
			for(ResumenStockEstablec resumenStockEstablec: lstStockNegativo){
				cntStockNegativo = resumenStockEstablec.getCantidadStock().intValue();
			}

			/*
			 //Setear  si el usuario no tiene inconsistencia 
			 Si (cntOmiso  == 0  &&  cntStockNegativo == 0 ) entonces
			  cntInconsistencia integer  = 0 
			 caso contrario 
			  cntInconsistencia = 1 
		    */
			if (cntOmiso  == 0  &&  cntStockNegativo == 0 ){
				cntInconsistencia = 0;
			}else{
				cntInconsistencia = 1;
			}
	 }
	 
	 return cntInconsistencia;
	}
	
	private Integer cntInconsisProgramaControlGreNoConfirmadasDestinatario(UsuarioProgramacion usuarioProgramacion){
		
	 Integer cntInconsistencia = 0;
	 CabezeraCpeBean cabezeraCpeBean;
	 /*
	  -	Invocar al metodo para identificar si permanece la inconsistencia 
	  Param
		-	cCodTipoTransportista =  Constantes.COD_TIP_TRANSPORTISTA
		-	iCodTipoPersonaTransportista= constantes. COD_TIP_PERSONA_TRANSPORTISTA
		-	cCodCPEGuiaRemision= constantes.COD_TIP_GUIA_REMITENTE
		-	iCodTipoTrasladoPublico= constantes. COD_TIP_TRASLADO_PUBLICO
		-	cIndEstActivo = constantes.IND_ESTADO_ACTIVO_GUIA
		-	programacionBean.peridoInicio
		-	programacionBean.PeriodoFin    
		-	UsuarioInconsistencia.NumDcoDestantario

		List<GreNoConfirmadasbean>   listaGreNoConfirmadas = UsuarioInconsistencia T4241cabcpeDAO.listarGreNoConfirmadasPorDestintario (Param)
     */
	 cabezeraCpeBean = new CabezeraCpeBean();
	 cabezeraCpeBean.setCodTipoTransportista(AccionesControlConstantes.COD_TIP_TRANSPORTISTA);//aalanya parametro no esta en query gresia
	 cabezeraCpeBean.setCodTipoPersonaTransportista(AccionesControlConstantes.COD_TIP_PERSONA_TRANSPORTISTA);//aalanya parametro no esta en query gresia
	 cabezeraCpeBean.setCodCPEGuiaRemision(AccionesControlConstantes.COD_TIP_GUIA_REMITENTE);
	 cabezeraCpeBean.setCodTipoTrasladoPublico(AccionesControlConstantes.COD_TIP_TRASLADO_PUBLICO);
	 cabezeraCpeBean.setIndEstado(AccionesControlConstantes.IND_ESTADO_ACTIVO_GUIA);
	 cabezeraCpeBean.setPeriodoInicio(null);//aalanya parametro no esta en query gresia
	 cabezeraCpeBean.setPeriodoFin(null);//aalanya parametro no esta en query gresia
	 cabezeraCpeBean.setNumDocumentoRecepcion(usuarioProgramacion.getNumDocumentoIdentif());
		
	 List<CabezeraCpe>  listaGreNoConfirmadas = t4241CabCpeDAO.listarGreNoConfirmadasPorDestinatario(cabezeraCpeBean);
		
	
	//	Setera  si tiene inconsistencia
	/*
	  Si (ListaGreNoConfirmadas.size() == 0) entonces
			cntInconsistencia integer  = 0
	    caso contrario 
            cntInconsistencia = ListaGreNoConfirmadas.size()
    */
	 
	 if(!listaGreNoConfirmadas.isEmpty()){
		 cntInconsistencia = listaGreNoConfirmadas.size();
	 }else{
		 cntInconsistencia = 0;
	 }
	 
	 return cntInconsistencia;
	}

	private Integer cntInconsisProgramaControlGreNoConfirmadasTransportista(UsuarioProgramacion usuarioProgramacion){
		
	 Integer cntInconsistencia = 0;
	 CabezeraCpeBean cabezeraCpeBean;
	 
	 /*
	 //Invocar al metodo para identificar si permanece la inconsistencia 

		Par�metros (paramGreNoDestinatario)
		-	#cCodTipoDestinatario#= constantes.COD_TIP_DESTNATARIO
		-	#iCodRelacionTransportistaRemitente#= constantes.COD_RELACION_TRANSPORTISTA_REMITENTE
		-	#cCodCPETransportista#= constantes. COD_TIP_GUIA_TRANSPORTISTA 
		-	#cCodCPEGuiaRemision# = constantes.COD_TIP_GUIA_REMITENTE
		-	#cIndEstActivo#= constantes.IND_ESTADO_ACTIVO_GUIA   
		-	#iTipDocRuc# = constantes.COD_TIP_DOCIDENT_RUC
		-	#iCodTipoTrasladoPublico# = constantes.COD_TIP_TRASLADO_PUBLICO
		-	UsuarioInconsistencia.NumDocumento

		List<GreNoConfirmadasbean>   ListaGreNoConfirmadas = ListaGreNoConfirmadas T4241cabcpeDAO.listarGreNoConfirmadasPorTransportista (paramGreNoDestinatario)
	 */
	 cabezeraCpeBean = new CabezeraCpeBean();
	 cabezeraCpeBean.setCodTipoDestinatario(AccionesControlConstantes.COD_TIP_DESTNATARIO);//aalanya parametro no esta en query gresia
	 cabezeraCpeBean.setCodRelacionTransportistaRemitente(AccionesControlConstantes.COD_RELACION_TRANSPORTISTA_REMITENTE);//aalanya no esta en query gresia
	 cabezeraCpeBean.setCodCPETransportista(AccionesControlConstantes.COD_TIP_GUIA_TRANSPORTISTA);//aalanya parametro no esta en query gresia
	 cabezeraCpeBean.setCodCPEGuiaRemision(AccionesControlConstantes.COD_TIP_GUIA_REMITENTE);
	 cabezeraCpeBean.setIndEstado(AccionesControlConstantes.IND_ESTADO_ACTIVO_GUIA);
	 cabezeraCpeBean.setCodTipoDocumento(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC);//aalanya parametro no esta en query gresia
	 cabezeraCpeBean.setCodTipoTrasladoPublico(AccionesControlConstantes.COD_TIP_TRASLADO_PUBLICO);
	 cabezeraCpeBean.setNumDocumentoRecepcion(usuarioProgramacion.getNumDocumentoIdentif());
	 
		
	  List<CabezeraCpe>  lstGreNoConfirmadas = t4241CabCpeDAO.listarGreNoConfirmadasPorTransportista(cabezeraCpeBean);

	  /*
		//Setear  si tiene inconsistencia
        Si (ListaGreNoConfirmadas.size() == 0) entonces
			cntInconsistencia integer  = 0
	    caso contrario 
            cntInconsistencia = ListaGreNoConfirmadas.size()
	  */
	  if(!lstGreNoConfirmadas.isEmpty()){
		  cntInconsistencia = lstGreNoConfirmadas.size();
	  }else{
		  cntInconsistencia = 0;
	  }
	  
	 return cntInconsistencia;
	}
	
	private String verificarEstadoRcbfRuc(UsuarioProgramacion usuarioProgramacionBean){
		if (logger.isWarnEnabled())
			logger.warn("Inicio DepurarUsuariosProgramacionBatchServiceImpl - verificarEstadoRcbfRuc");
	
		String codMotivoDepuracion ="";
		
		//Si (UsuarioProgramacionBean.cod_progctrl<> constantes.COD_PROGRCONTROL_DE_BAJA_DJ)
		if(AccionesControlConstantes.COD_PROGRCONTROL_DE_BAJA_DJ.equals(usuarioProgramacionBean.getCodProgctrl())){
			
			
			BfRegistroBean bFRegistroBean = new BfRegistroBean();
			bFRegistroBean.setNumRuc(usuarioProgramacionBean.getNumDocumentoIdentif());
			//	Verificar estado de usuario en RCBF	  	
			List<BfRegistro> lstBfRegistro = registroBfService.obtenerDatosUsuario(bFRegistroBean);
			
			//Verificar Estado de usuario en RUC
			// Para obtener la dependencia :
			WSRegistroRUCBean regBeanRuc  = servicioWebService.obtenerRegistroRuc(usuarioProgramacionBean.getNumDocumentoIdentif());
	    	//usrProgr.setCodDependencia(regBeanRuc.getDdpNumreg()); // consultar la dependencia
			
			if (!MaestrosUtilidades.isEmpty(lstBfRegistro) &&
				!MaestrosUtilidades.isEmpty(regBeanRuc)
				) {
				
				  BfRegistro usuarioBean = lstBfRegistro.get(0);
				
				if (AccionesControlConstantes.COD_ESTADO_REGISTRO_DEBAJA.equals(usuarioBean.getCodEstado())){
					codMotivoDepuracion = AccionesControlConstantes.COD_MOTIVO_DEPURACION_BAJA_RCBF;
				}
				if(!AccionesControlConstantes.COD_ESTADO_ACTIVO_RUC.equals(regBeanRuc.getDdpEstado())){
					codMotivoDepuracion = AccionesControlConstantes.COD_MOTIVO_DEPURACION_BAJA_RUC;
				}
				if(AccionesControlConstantes.COD_ESTADO_REGISTRO_DEBAJA.equals(usuarioBean.getCodEstado()) &&
				  !AccionesControlConstantes.COD_ESTADO_ACTIVO_RUC.equals(regBeanRuc.getDdpEstado())
				  ){
					codMotivoDepuracion = AccionesControlConstantes.COD_MOTIVO_DEPURACION_BAJA_RUC_RCBF;
				}
			}
		}
			
	   if (logger.isDebugEnabled())
		logger.debug("Fin DepurarUsuariosProgramacionBatchServiceImpl - verificarEstadoRcbfRuc");
	   
		return codMotivoDepuracion;
	}
}
