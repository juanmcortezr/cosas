package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaUsuarioAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PreseleccionAsignacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaUsuarioAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PreseleccionAsignacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10394AsignaUsuAccDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10416PreseleAsigDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.MensajeIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.MensajeIqbfService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class AsignacionMasivaAuditoresBatchServiceImpl implements AsignacionMasivaAuditoresBatchService{
	private static final Logger logger = LoggerFactory.getLogger(VerificarEstadoNotificacionBatchServiceImpl.class);
	
	@EJB
	private T10411InformeSelecDAO t10411InformeSelecDAO;
	@EJB
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;
	@EJB
	private T10416PreseleAsigDAO t10416PreseleAsigDAO;
	@EJB 
	private T10415OrdenAccionDAO t10415OrdenAccionDAO;	
	@EJB
	private T10394AsignaUsuAccDAO t10394asignausuaccDAO;
	@EJB
	private ServicioWebService servicioWebService;
	@EJB
	private MensajeIqbfService mensajeIqbfService;
	@Override
	public ResponseBean<String> iniciarProcesamiento(ProgramacionBean programacionBean) {
		if (logger.isWarnEnabled())
			logger.warn("Inicio AsignacionMasivaAuditoresBatchServiceImpl - iniciarProcesamiento");
		ResponseBean<String> respuesta = new ResponseBean<>();
		try {
//			Date fechaActual = new Date();
			String codEstadoProg="";
			InformeSeleccion informeSeleccion = t10411InformeSelecDAO.findById(Long.valueOf(programacionBean.getNumInforme()),  AccionesControlConstantes.DATASOURCE_DCSICOBF);
			codEstadoProg = AccionesControlConstantes.COD_ESTADO_INFORME_ASIGNANDOAUDIT;
			informeSeleccion.setCodEstadoInforme(codEstadoProg);
			t10411InformeSelecDAO.update(informeSeleccion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			UsuarioProgramacion usuarioProgramacion=new UsuarioProgramacion();
			usuarioProgramacion.setNumProgramacion(programacionBean.getNumProgramacion());
			usuarioProgramacion.setCodEstadoUsuario(AccionesControlConstantes.COD_ESTADO_USUARIO_CARGADO);
			usuarioProgramacion.setIndEst(AccionesControlConstantes.REGISTRO_ACTIVO);
			usuarioProgramacion.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
			List<UsuarioProgramacion> listaUsuariosProg = t10428UsuarioProgDAO.listarUsuarioProg(usuarioProgramacion);
			Map<String,Object> auditorCarga=new HashMap<String, Object>();
			List<Map<String,Object>> listaAuditorCarga= new ArrayList<Map<String,Object>>();
			List<Map<String,Object>> listaAuditorCargaMin= new ArrayList<Map<String,Object>>();
			for (UsuarioProgramacion userProgramacion : listaUsuariosProg) {

				OrdenAccion orden =  new OrdenAccion();
				if(userProgramacion.getCodTipoIntervencion().equals(AccionesControlConstantes.COD_TIPO_INTERVENCION_CONTROL)){
					List<PreseleccionAsignacionBean> listaAuditorPresel = this.listarAuditorPreselAccion(userProgramacion);
					
					List<AsignaUsuarioAccionBean>  cargaAuditoresPrincipales = listaCargaAuditoresPrincipales(String.valueOf(programacionBean.getNumProgramacion()));
					if(cargaAuditoresPrincipales!=null){
						int cantidadCarga=cargaAuditoresPrincipales.size();
						auditorCarga.put("cantidad", cantidadCarga);
						auditorCarga.put("auditor", cargaAuditoresPrincipales.get(0));
						listaAuditorCarga.add(auditorCarga);
						listaAuditorCargaMin =auditorMinCarga(auditorCarga,listaAuditorCarga);
						int auditorMinCarga = listaAuditorCargaMin.size(); // obtener cantidad auditor min carga
						
						if(auditorMinCarga>1){
							//TODO : auditor aleatorio 
							int index = ThreadLocalRandom.current().nextInt(0, auditorMinCarga);
							AsignaUsuarioAccionBean a =(AsignaUsuarioAccionBean) listaAuditorCargaMin.get(index).get("auditor");
							userProgramacion.setNumUsuarioPrograma(a.getNumUsuarioPrograma());
						}
					}
					orden.setCodTipoOrden(AccionesControlConstantes.COD_TIPO_ORDEN_CONTROL );
				}
				else if(userProgramacion.getCodTipoIntervencion().equals(AccionesControlConstantes.COD_TIPO_INTERVENCION_FISCAL)){	
					orden.setCodTipoOrden(AccionesControlConstantes.COD_TIPO_ORDEN_FISCALIZACION );				
				}
				orden.setNumProgramacion(programacionBean.getNumProgramacion());
				orden.setEstados(Arrays.asList(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO, AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA));
				orden.setIndEst(AccionesControlConstantes.REGISTRO_ACTIVO);
				orden.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
				List<OrdenAccion> listOrdenAccion= t10415OrdenAccionDAO.listarOrden(orden);
				for (OrdenAccion ordenAccion : listOrdenAccion) {
					ordenAccion.setFecModif(new Date());
					ordenAccion.setNumUsuarioPrograma(userProgramacion.getNumUsuarioPrograma());
					ordenAccion.setCodEstadoOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_ENPROCESO);
					ordenAccion.setCodUsuModif(programacionBean.getAuditoriaBean().getLogin());
					ordenAccion.setDirIpusumodif(programacionBean.getAuditoriaBean().getNumIp());
					t10415OrdenAccionDAO.update(ordenAccion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				}
				AsignaUsuarioAccion asignacion =this.asignarAuditorPrincipalAccion(userProgramacion);
				this.validaEnvioCorreo(asignacion, userProgramacion,Long.valueOf(programacionBean.getNumInforme()));
			}
			respuesta.setExito(true);
			respuesta.setMensaje("OK");
		} catch (Exception e) {
			respuesta.setExito(false);
			respuesta.setMensaje(e.getMessage());
		}
		return respuesta;
	}
	
	private List<Map<String,Object>> auditorMinCarga(Map<String,Object> auditorCarga,List<Map<String,Object>> lista){
		Map<String,Object> auditor=new HashMap<String, Object>();
		AsignaUsuarioAccionBean asignaUsuario = null;
		AsignaUsuarioAccionBean asignaUsuariodelista = null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		int min=0;
		int minCargadeLista=0;
		for (Map<String, Object> map : lista) {
			if(Integer.parseInt(auditorCarga.get("cantidad").toString())<Integer.parseInt(map.get("cantidad").toString())){
				min=Integer.parseInt(auditorCarga.get("cantidad").toString());
				asignaUsuario = (AsignaUsuarioAccionBean) auditorCarga.get("auditor");
			}else{
				min=Integer.parseInt(map.get("cantidad").toString());
				asignaUsuario=(AsignaUsuarioAccionBean) map.get("auditor");
				asignaUsuariodelista=(AsignaUsuarioAccionBean) map.get("auditor");
				minCargadeLista=Integer.parseInt(map.get("cantidad").toString());
			}
		}
		if(minCargadeLista==Integer.parseInt(auditorCarga.get("cantidad").toString())){
			//auditor.put("cantidadMinCarga", 2);
			auditor.put("cantidad", minCargadeLista);
			auditor.put("auditor", asignaUsuariodelista);
			list.add(auditor);
		}else{
			auditor.put("cantidadMinCarga", 1);
		}
		auditor.put("cantidad", min);
		auditor.put("auditor", asignaUsuario);
		list.add(auditor);
		return list;
	}
	
	private List<PreseleccionAsignacionBean> listarAuditorPreselAccion(UsuarioProgramacion userProgramacion){
			 List<PreseleccionAsignacionBean> lista=new ArrayList<PreseleccionAsignacionBean>();
			 
			PreseleccionAsignacion filtro=new PreseleccionAsignacion();
			filtro.setNumProgramacion(userProgramacion.getNumProgramacion());
			filtro.setIndEst(AccionesControlConstantes.REGISTRO_ACTIVO);
			filtro.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
			//filtro.setNumInfSelecc(filtro.getNumInfSelecc());

			List<PreseleccionAsignacion>  t10416PreseleAsig= t10416PreseleAsigDAO.obtenerAuditorAsignar(filtro);
			if (!MaestrosUtilidades.isEmpty(t10416PreseleAsig)) {
				PreseleccionAsignacionBean preseleccionAsignacionBean2=null;
			for (PreseleccionAsignacion preseleccionAsignacion : t10416PreseleAsig) {
				preseleccionAsignacionBean2=new PreseleccionAsignacionBean();
				preseleccionAsignacionBean2.setCodAuditor(preseleccionAsignacion.getCodAuditor());
				preseleccionAsignacion.setNumAsignacionTemp(preseleccionAsignacion.getNumAsignacionTemp());
				lista.add(preseleccionAsignacionBean2);
			}
			}
			return lista;
		}
	private AsignaUsuarioAccion asignarAuditorPrincipalAccion(UsuarioProgramacion userProgramacion) {
		AsignaUsuarioAccion asignaUsuarioAccion =new AsignaUsuarioAccion();
		asignaUsuarioAccion.setNumUsuarioPrograma(userProgramacion.getNumUsuarioPrograma());
		asignaUsuarioAccion.setIndTipAsignacion(AccionesControlConstantes.COD_TIPO_ASIGNACION_AUTOMATICA);
		asignaUsuarioAccion.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		asignaUsuarioAccion.setCodPers(userProgramacion.getCodPers());
		asignaUsuarioAccion.setFecInicioAsignacion(new Date());
		asignaUsuarioAccion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		asignaUsuarioAccion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10394asignausuaccDAO.save(asignaUsuarioAccion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		return asignaUsuarioAccion;
	}

	private void validaEnvioCorreo(AsignaUsuarioAccion asignacion,UsuarioProgramacion userProgramacion,Long numInformeSeleccion){
		MensajeIqbfBean plantillaMensaje = null;
		String codMensajeCorreo ="";
		ResponseBean<AsignaUsuarioAccion> respuestaAsignacion = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		if (!MaestrosUtilidades.isEmpty(asignacion)) {
			respuestaAsignacion = new ResponseBean<>(true, asignacion);
		}
		InformeSeleccion informeSeleccion = t10411InformeSelecDAO.findById(numInformeSeleccion,  AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		if(respuestaAsignacion.isExito()){
			codMensajeCorreo=AccionesControlConstantes.COD_MENSAJE_CORREO_F11a;
			informeSeleccion.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_PENDIENTECOMPL);			
		}else{
			codMensajeCorreo=AccionesControlConstantes.COD_MENSAJE_CORREO_F12;	
			informeSeleccion.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_ERRORASIGNA);				
		}
		t10411InformeSelecDAO.update(informeSeleccion, AccionesControlConstantes.DATASOURCE_DCSICOBF);		
		ResponseBean<String> respuestaCorreo = null;
		 plantillaMensaje = mensajeIqbfService.obtenerPlantillaMensajeIQBF(codMensajeCorreo, AccionesControlConstantes.COD_TIPO_PROCESO);
		WSPersonalIqbfBean personal= servicioWebService.obtenerPersonalIqbf(userProgramacion.getCodPers());
		if(personal!=null){
			respuestaCorreo = enviaCorreoAutorizacion(personal.getDirCorreo(),userProgramacion,plantillaMensaje);
			if(respuestaCorreo.isExito()) logger.debug("Envio Correo");			
		}
	}
	
	private ResponseBean<String> enviaCorreoAutorizacion(String correoReceptor,UsuarioProgramacion userProgramacion,MensajeIqbfBean mensaje) {
		CorreoBean correoBean = new CorreoBean();
		correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
		correoBean.setAsunto(mensaje.getDesCorta());
		correoBean.setReceptor(correoReceptor);
		
		String cuerpoMensaje = mensaje.getDesCuerpo()
				.replace(AccionesControlConstantes.MENSAJE_IQBF_PARAMETROS_NUMERO_PROGRAMACION, userProgramacion.getNumProgramacion().toString())		
				.replace(AccionesControlConstantes.MENSAJE_IQBF_PARAMETROS_ALCANCE, userProgramacion.getAlcanceProg());					
		correoBean.setMensaje(cuerpoMensaje);
		return CorreoUtil.enviarCorreo(correoBean);
	}
	private List<AsignaUsuarioAccionBean> listaCargaAuditoresPrincipales(String numProgramacion) {
		List<AsignaUsuarioAccionBean> listaAsignacion = new ArrayList<AsignaUsuarioAccionBean>();
		AsignaUsuarioAccion parametros = new AsignaUsuarioAccion();
		PropertyParams propertyParams = new PropertyParams();
		parametros.setNumUsuarioPrograma(Long.valueOf(numProgramacion));
		parametros.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);

		propertyParams.addProperty("codTipIntControl", AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL);
		propertyParams.addProperty("codTipIntFiscalizacion",
				AccionesControlConstantes.COD_TIP_INTERVENCION_FISCALIZACION);

		ArrayList<String> estadoOrden = new ArrayList<String>();
		estadoOrden.add(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		estadoOrden.add(AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA);
		parametros.setEstadoOrden(estadoOrden);

		String codTipIntControl = AccionesControlConstantes.COD_TIP_INTERVENCION_CONTROL;
		String codTipIntFiscalizacion = AccionesControlConstantes.COD_TIP_INTERVENCION_FISCALIZACION;

		List<AsignaUsuarioAccion> t10394asignausuacc = t10394asignausuaccDAO.listarCargaAuditorPrincipal(parametros,
				estadoOrden, numProgramacion, codTipIntControl, codTipIntFiscalizacion);
		if (!MaestrosUtilidades.isEmpty(t10394asignausuacc)) {
			AsignaUsuarioAccionBean asignaUsuarioAccionBean = null;
			for (AsignaUsuarioAccion asignaUsuarioAccion : t10394asignausuacc) {
				asignaUsuarioAccionBean = new AsignaUsuarioAccionBean();
				asignaUsuarioAccionBean.setNomAuditor(String
						.valueOf(servicioWebService.obtenerPersonalIqbf(asignaUsuarioAccion.getCodAuditor())));
				listaAsignacion.add(asignaUsuarioAccionBean);
			}
		}

		return listaAsignacion;
	}
}
