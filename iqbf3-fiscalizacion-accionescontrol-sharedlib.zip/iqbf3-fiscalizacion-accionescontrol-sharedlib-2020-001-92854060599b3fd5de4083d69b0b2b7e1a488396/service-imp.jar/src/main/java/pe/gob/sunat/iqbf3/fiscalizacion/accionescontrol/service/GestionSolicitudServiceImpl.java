package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AlternativaCriterioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienFiscalizadoSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CalificacionUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.EstablecimientoUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.MedioProbatorioUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienFiscal;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienFiscalizadoSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienFiscalizadoUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CalificacionUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CriterioCalificacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DetalleCalificacionUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.EstablecimientoUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MedioProbatorioUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10389AlternatCritDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10396BienFisSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10397BienFiscaUsuDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10400CaliUsuaDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10402CriterioCaliDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10403DetaCaliUsuaDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10409EstabUsuDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10412MedioProbUsuDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10414MovSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10421SolicProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10426TipInconSoliDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10427TipInconUsuDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10429UsuarioSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T7883BienFiscalDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.MensajesExcepciones;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.UbigeoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSUnidadOrgBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.service.UbigeoService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosMensajes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class GestionSolicitudServiceImpl implements GestionSolicitudService {
	
	private static final Logger logger = LoggerFactory.getLogger(GestionSolicitudServiceImpl.class);

	@EJB
	private T7883BienFiscalDAO t7883BienFiscalDAO;

	@EJB
	private T10421SolicProgDAO t10421SolicProgDAO;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private T10426TipInconSoliDAO t10426TipInconSoliDAO;

	@EJB
	private T10396BienFisSolicDAO t10396BienFisSolicDAO;

	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private T10429UsuarioSolicDAO t10429UsuarioSolicDAO;

	@EJB
	private T10412MedioProbUsuDAO t10412MedioProbUsuDAO;

	@EJB
	private T10427TipInconUsuDAO t10427TipInconUsuDAO;

	@EJB
	private T10397BienFiscaUsuDAO t10397BienFiscaUsuDAO;

	@EJB
	private T10414MovSolicDAO t10414MovSolicDAO;

	@EJB
	private T10409EstabUsuDAO t10409EstabUsuDAO;

	@EJB(name="accionescontrol.comunService")
	private ComunService comunService;

	@EJB
	private UbigeoService ubigeoService;

	@EJB
	private T10415OrdenAccionDAO t10415OrdenAccionDAO;

	@EJB
	private T10400CaliUsuaDAO t10400CaliUsuaDAO;

	@EJB
	private T10403DetaCaliUsuaDAO t10403DetaCaliUsuaDAO;

	@EJB
	private T10402CriterioCaliDAO t10402CriterioCaliDAO;
	
	@EJB
	private T10389AlternatCritDAO t10389AlternatCritDAO;


	public GestionSolicitudServiceImpl() {
	}

	@Override
	public List<SolicitudProgramacionBean> listarSolicitudProgramacion(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - listarSolicitudProgramacion");

		SolicitudProgramacion filtroModel = new SolicitudProgramacion();
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoSolicitud())) {
			filtroModel.setEstados(Arrays.asList(filtro.getCodEstadoSolicitud()));
		} else {
			filtroModel.setEstados(Arrays.asList(AccionesControlConstantes.COD_ESTADO_SOLICITUD_REGISTRADO,
									AccionesControlConstantes.COD_ESTADO_SOLICITUD_DEVUELTO));
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoDocUsuario())) {
			filtroModel.setCodTipDocIdent(filtro.getCodTipoDocUsuario());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocUsuario())) {
			filtroModel.setNumDocIdent(filtro.getNumDocUsuario());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoIntervension())) {
			filtroModel.setCodTipInterv(filtro.getCodTipoIntervension());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoAccion())) {
			filtroModel.setCodTipAccion(filtro.getCodTipoAccion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			filtroModel.setNumSolicitudUnion(filtro.getNumSolicitudUnion());
		}

		List<SolicitudProgramacionBean> lista = new ArrayList<>();
		List<SolicitudProgramacion> t10421lista = t10421SolicProgDAO.listarSolicitudProgramacion(filtroModel);
		if (!MaestrosUtilidades.isEmpty(t10421lista)) {
			for (SolicitudProgramacion t10421 : t10421lista) {
				SolicitudProgramacionBean bean = new SolicitudProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10421, bean);
				bean.setNumSolicitudUnion(AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
				bean.setFecGeneracion(MaestrosUtilidades.dateToStringDDMMYYYY(t10421.getFecGeneracion()));
				bean.setDesEstadoSolicitud("");
				bean.setCalificacionDefinitiva(t10421.getCalificacionDefinitiva());
				bean.setCalificacionPreliminar(t10421.getCalificacionPreliminar());
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_SOLICITUD,
						t10421.getCodEstadoSolicitud());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesEstadoSolicitud(catalogo.getDescripcionDataCatalogo().trim());
				}
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	public SolicitudProgramacionBean obtenerDatosSolicitud(Long numSolicProg) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - obtenerDatosSolicitud");
		SolicitudProgramacionBean solicitudBean = new SolicitudProgramacionBean();
		SolicitudProgramacion solicitud = t10421SolicProgDAO.findById(numSolicProg, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		MaestrosUtilidades.copiarValoresBean(solicitud, solicitudBean);
		solicitudBean.setNumSolicitudUnion(AccionesControlUtil.generarNumSoli(solicitud.getNumCorrel(), solicitud.getAnioSolicitud(), solicitud.getCodUnidadOrganica()));
		solicitudBean.setInconsistencias(new ArrayList<>());
		solicitudBean.setBienesFiscalizados(new ArrayList<>());
		solicitudBean.setTipoBienes(new ArrayList<>());
		solicitudBean.setFecGeneracion(MaestrosUtilidades.dateToStringDDMMYYYY(solicitud.getFecGeneracion()));
		solicitudBean.setIndOtroSolicitan(MaestrosConstantes.REGISTRO_NO_ELIMINADO.equals(solicitud.getIndOtroSolicitan()) ? MaestrosConstantes.REGISTRO_NO_ELIMINADO : "");
		solicitudBean.setNomSolicitante("");

		// Archivo Bean
		ArchivoBean archivoBean = comunService.obtenerArchivo(solicitud.getNumArc());
		if (!MaestrosUtilidades.isEmpty(archivoBean)) {
			solicitudBean.setArchivoBean(archivoBean);
		}

		if (!MaestrosUtilidades.isEmpty(solicitud.getCodSolicitante())) {
			WSPersonalIqbfBean personal = servicioWebService.obtenerPersonalIqbf(solicitud.getCodSolicitante());
			if (!MaestrosUtilidades.isEmpty(personal)) {
				solicitudBean.setNomSolicitante(personal.getNomCompleto());
			}
		}

		solicitudBean.setDesUnidadOrganica("");

		if (!MaestrosUtilidades.isEmpty(solicitud.getCodUnidadOrganica())) {
			WSUnidadOrgBean unidadOrg = servicioWebService.obtenerDatosUUOO(solicitud.getCodUnidadOrganica());
			if (!MaestrosUtilidades.isEmpty(unidadOrg)) {
				solicitudBean.setDesUnidadOrganica(unidadOrg.getDesUorga().trim());
			}
		}
		
		// Incosistencias
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numSolicitud", numSolicProg);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<TipoInconsistenciaSolicitud> t10426lista = t10426TipInconSoliDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10426lista)) {
			List<DataCatalogoBean> inconsistencias = t10426lista.stream().map(t10426 -> {
				DataCatalogoBean data = new DataCatalogoBean(t10426.getCodTipoInconsistencia(), t10426.getDesOtraInconsistencia());
				data.setSeleccionado(true);
				data.setDescripcionCorta(t10426.getDesOtraInconsistencia());
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INCONSISTENCIAS,
						t10426.getCodTipoInconsistencia());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					data.setDescripcionDataCatalogo(catalogo.getDescripcionDataCatalogo());
				}
				return data;
			}).collect(Collectors.toList());
			String otraIncosistencia = inconsistencias.stream()
							.filter(check -> AccionesControlConstantes.OPCION_OTROS.equals(check.getCodDataCatalogo()))
							.map(DataCatalogoBean::getDescripcionCorta).findFirst().orElse(null);
			solicitudBean.setDesOtraInconsistencia(otraIncosistencia);
			solicitudBean.setInconsistencias(inconsistencias);
		}

		// Bienes y tipo Bienes
		List<BienFiscalizadoSolicitud> t10396lista = t10396BienFisSolicDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10396lista)) {
			List<BienFiscalizadoSolicitudBean> bienes = t10396lista.stream().filter(t10397 -> {
				return Arrays.asList(AccionesControlConstantes.OPCION_OTROS,
						AccionesControlConstantes.OPCION_TIPO_BIEN_DISOLVENTE,
						AccionesControlConstantes.OPCION_TIPO_BIEN_MEZCLA).indexOf(t10397.getCodTipoBien()) < 0;
			}).map(t10397 -> {
				BienFiscalizadoSolicitudBean bien = new BienFiscalizadoSolicitudBean(t10397.getCodBienFiscalizado(), t10397.getCodTipoBien(), t10397.getDesOtroTipobien());
				bien.setSeleccionado(true);
				PropertyParams params = new PropertyParams();
				params.addProperty("codBien", t10397.getCodBienFiscalizado());
				params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
				List<BienFiscal> t7883lista = t7883BienFiscalDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				if (!MaestrosUtilidades.isEmpty(t7883lista)) {
					bien.setDesBienFisca(t7883lista.get(0).getDesBien());
				}
				return bien;
			}).collect(Collectors.toList());
			Set<String> setTipoBienes = t10396lista.stream().map(BienFiscalizadoSolicitud::getCodTipoBien).collect(Collectors.toSet());
			List<DataCatalogoBean> tipoBienes = setTipoBienes.stream().map(tipoBien -> {
				DataCatalogoBean data = new DataCatalogoBean(tipoBien);
				data.setSeleccionado(true);
				if (!AccionesControlConstantes.OPCION_OTROS.equals(tipoBien)) {
					DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_BIEN,
							tipoBien);
					if (!MaestrosUtilidades.isEmpty(catalogo)) {
						data.setDescripcionDataCatalogo(catalogo.getDescripcionDataCatalogo());
					}	
				} else {
					data.setDescripcionDataCatalogo(AccionesControlConstantes.OPCION_DESCRIPCION_OTROS);
				}
				return data;
			}).collect(Collectors.toList());
			String otroBien = t10396lista.stream()
					.filter(check -> Arrays.asList(AccionesControlConstantes.OPCION_OTROS,
							AccionesControlConstantes.OPCION_TIPO_BIEN_DISOLVENTE,
							AccionesControlConstantes.OPCION_TIPO_BIEN_MEZCLA).indexOf(check.getCodTipoBien()) >= 0)
					.map(BienFiscalizadoSolicitud::getDesOtroTipobien).findFirst().orElse(null);
			solicitudBean.setDesOtraTipoBien(otroBien);
			solicitudBean.setBienesFiscalizados(bienes);
			solicitudBean.setTipoBienes(tipoBienes);
		}

		System.out.println("solicitudBean.getBienesFiscalizados().size() => " + solicitudBean.getBienesFiscalizados().size());
		return solicitudBean;
	}

	@Override
	public List<BienFiscalizadoSolicitudBean> listarBienesFiscalizados(String codTipoBien) {
		PropertyParams params = new PropertyParams();
		params.addProperty("codTipoBien", codTipoBien);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<BienFiscalizadoSolicitudBean> lista = new ArrayList<>();
		List<BienFiscal> t7883lista = t7883BienFiscalDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t7883lista)) {
			for (BienFiscal t7883 : t7883lista) {
				BienFiscalizadoSolicitudBean bean = new BienFiscalizadoSolicitudBean();
				bean.setCodTipoBien(t7883.getCodTipoBien());
				bean.setDesBienFisca(t7883.getDesBien());
				bean.setCodBienFiscalizado(t7883.getCodBien());
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	//@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public SolicitudProgramacionBean guardarSolicitud(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - guardarSolicitud");

		logger.debug(String.format("filtro => %s", filtro.toString()));
		if (MaestrosUtilidades.isEmpty(filtro.getIndOtroSolicitan())) {
			filtro.setIndOtroSolicitan("false");
		}

		Long numSolicitud;
		boolean esRegistro = (filtro.getNumSolicitud() == 0);

		SolicitudProgramacion model = esRegistro ? new SolicitudProgramacion() : t10421SolicProgDAO.findById(filtro.getNumSolicitud(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		// INI Registrar archivo
		Long numArc = null;
		ArchivoBean archivoBean = filtro.getArchivoBean();
		if (!MaestrosUtilidades.isEmpty(archivoBean)) {
			archivoBean.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_SOLICITUD);
			archivoBean.setNumArc(!esRegistro ? model.getNumArc() : null);
			numArc = comunService.guardarArchivo(archivoBean, filtro.getAuditoriaBean());
		}
		// FIN Registrar archivo

		model.setCodEstadoSolicitud(AccionesControlConstantes.COD_ESTADO_SOLICITUD_REGISTRADO);
		model.setDesSusSolicitud(filtro.getDesSusSolicitud());
		model.setAnioSolicitud(Calendar.getInstance().get(Calendar.YEAR));
		model.setCodTipoDocumentoReferencia(filtro.getCodTipoDocumentoReferencia());
		model.setNumDocumentoReferencia(filtro.getNumDocumentoReferencia());
		model.setObsSolicitud(filtro.getObsSolicitud());
		model.setPerFin(filtro.getPerFin());
		model.setNumArc(numArc);
		model.setDesMotivoAsignacion(filtro.getDesMotivoAsignacion());
		model.setPerInicio(filtro.getPerInicio());
		model.setIndOtroSolicitan(MaestrosUtilidades.toBoolean(filtro.getIndOtroSolicitan()) ? MaestrosConstantes.REGISTRO_NO_ELIMINADO : MaestrosConstantes.REGISTRO_ELIMINADO);
		model.setDesOtroSolicitante(filtro.getDesOtroSolicitante());
		model.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		model.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		model.setCodSolicitante(filtro.getAuditoriaBean().getNroRegistro());
		model.setCodUnidadOrganica(filtro.getAuditoriaBean().getCodUO());
		if (esRegistro) {
			numSolicitud = t10421SolicProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_SOLICITUD_PROGRAMACION, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			model.setFecCrea(new Date());
			model.setNumSolicitud(numSolicitud);
			model.setFecGeneracion(new Date());
			model.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
			model.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
			model.setNumCorrel(t10421SolicProgDAO.obtenerCorrelativoSolicitud(model.getAnioSolicitud()));
			t10421SolicProgDAO.save(model, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			// Registrar movimiento solicitud
			MovimientoSolicitud t10414 = new MovimientoSolicitud();
			t10414.setCodPersMov(filtro.getAuditoriaBean().getNroRegistro());
			t10414.setFecMovimiento(new Date());
			t10414.setNumSolicitud(numSolicitud);
			t10414.setNumMovimientoPrograma(t10414MovSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_MOVIMIENTO_SOLICITUD, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10414.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10414.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10414.setFecCrea(new Date());
			t10414.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
			t10414.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
			t10414.setCodCargo(" "); // FIXME
			t10414MovSolicDAO.save(t10414, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			numSolicitud = filtro.getNumSolicitud();
			model.setNumSolicitud(numSolicitud);
			model.setFecModif(new Date());
			model.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
			model.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
			t10421SolicProgDAO.update(model, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		// Incosistencias
		PropertyParams detalleParams;
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numSolicitud", numSolicitud);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		// DAR DE BAJA TODOS ANTES INCONSISTENCIAS
		List<TipoInconsistenciaSolicitud> t10426lista = t10426TipInconSoliDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10426lista)) {
			for (TipoInconsistenciaSolicitud t10426 : t10426lista) {
				t10426.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
				t10426.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10426TipInconSoliDAO.update(t10426, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}
		List<DataCatalogoBean> inconsistencias = filtro.getInconsistencias();
		if (!MaestrosUtilidades.isEmpty(inconsistencias)) {
			for (DataCatalogoBean incosistencia : inconsistencias) {
				TipoInconsistenciaSolicitud t10426 = new TipoInconsistenciaSolicitud();
				t10426.setNumSolicitud(numSolicitud);
				t10426.setCodTipoInconsistencia(incosistencia.getCodDataCatalogo());
				if (AccionesControlConstantes.OPCION_OTROS.equals(incosistencia.getCodDataCatalogo())) {
					t10426.setDesOtraInconsistencia(filtro.getDesOtraInconsistencia());
				}
				t10426.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10426.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				// Validar si esta registrado
				detalleParams = new PropertyParams();
				detalleParams.addProperty("numSolicitud", numSolicitud);
				detalleParams.addProperty("codTipoInconsistencia", incosistencia.getCodDataCatalogo());
				List<TipoInconsistenciaSolicitud> existe = t10426TipInconSoliDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(existe)) {
					TipoInconsistenciaSolicitud bexiste = existe.get(0);
					t10426.setFecModif(new Date());
					t10426.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
					t10426.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
					t10426.setNumInconsistenciaSolicitud(bexiste.getNumInconsistenciaSolicitud());
					t10426.setFecCrea(bexiste.getFecCrea());
					t10426.setDirIpusucrea(bexiste.getDirIpusucrea());
					t10426.setCodUsuCrea(bexiste.getCodUsuCrea());
					t10426TipInconSoliDAO.update(t10426, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					t10426.setFecCrea(new Date());
					t10426.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
					t10426.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
					t10426.setNumInconsistenciaSolicitud(t10426TipInconSoliDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_TIPINCONS_SOLICITUD, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10426TipInconSoliDAO.save(t10426, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
				}
			}
		}
		// DAR DE BAJA TODOS LOS BIENES
		List<BienFiscalizadoSolicitud> t10396lista = t10396BienFisSolicDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10396lista)) {
			for (BienFiscalizadoSolicitud t10396 : t10396lista) {
				t10396.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
				t10396.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10396BienFisSolicDAO.update(t10396, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}
		// tipo bienes
		List<DataCatalogoBean> tipoBienes = filtro.getTipoBienes().stream().filter(t -> Arrays.asList(AccionesControlConstantes.OPCION_OTROS,
				AccionesControlConstantes.OPCION_TIPO_BIEN_DISOLVENTE,
				AccionesControlConstantes.OPCION_TIPO_BIEN_MEZCLA).indexOf(t.getCodDataCatalogo()) >= 0).collect(Collectors.toList());
		if (!MaestrosUtilidades.isEmpty(tipoBienes)) {
			for (DataCatalogoBean tipoBien : tipoBienes) {
				BienFiscalizadoSolicitud t10396 = new BienFiscalizadoSolicitud();
				t10396.setNumSolicitud(numSolicitud);
				t10396.setCodTipoBien(tipoBien.getCodDataCatalogo());
				t10396.setDesOtroTipobien(filtro.getDesOtraTipoBien());
				t10396.setCodBienFiscalizado(AccionesControlConstantes.COD_BIEN_VACIO);
				t10396.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10396.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				detalleParams = new PropertyParams();
				detalleParams.addProperty("numSolicitud", numSolicitud);
				detalleParams.addProperty("codTipoBien", tipoBien.getCodDataCatalogo());
				detalleParams.addProperty("codBienFiscalizado", AccionesControlConstantes.COD_BIEN_VACIO);
				List<BienFiscalizadoSolicitud> existe = t10396BienFisSolicDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(existe)) {
					BienFiscalizadoSolicitud bexiste = existe.get(0);
					t10396.setFecModif(new Date());
					t10396.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
					t10396.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
					t10396.setNumBienFiscaSolicitud(bexiste.getNumBienFiscaSolicitud());
					t10396.setFecCrea(bexiste.getFecCrea());
					t10396.setDirIpusucrea(bexiste.getDirIpusucrea());
					t10396.setCodUsuCrea(bexiste.getCodUsuCrea());
					t10396BienFisSolicDAO.update(t10396, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					t10396.setFecCrea(new Date());
					t10396.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
					t10396.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
					t10396.setNumBienFiscaSolicitud(t10396BienFisSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_BIENES_FISCALIZARSOL, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10396BienFisSolicDAO.save(t10396, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
				}
			}
		}
		// bienes
		List<BienFiscalizadoSolicitudBean> bienes = filtro.getBienesFiscalizados();
		if (!MaestrosUtilidades.isEmpty(bienes)) {
			for (BienFiscalizadoSolicitudBean bien : bienes) {
				BienFiscalizadoSolicitud t10396 = new BienFiscalizadoSolicitud();
				t10396.setNumSolicitud(numSolicitud);
				t10396.setCodTipoBien(bien.getCodTipoBien());
				t10396.setDesOtroTipobien(null);
				t10396.setCodBienFiscalizado(bien.getCodBienFiscalizado());
				t10396.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10396.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				detalleParams = new PropertyParams();
				detalleParams.addProperty("numSolicitud", numSolicitud);
				detalleParams.addProperty("codTipoBien", bien.getCodTipoBien());
				detalleParams.addProperty("codBienFiscalizado", bien.getCodBienFiscalizado());
				List<BienFiscalizadoSolicitud> existe = t10396BienFisSolicDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(existe)) {
					BienFiscalizadoSolicitud bexiste = existe.get(0);
					logger.debug("BienFiscalizadoSolicitud:si existe");
					t10396.setFecModif(new Date());
					t10396.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
					t10396.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
					t10396.setNumBienFiscaSolicitud(bexiste.getNumBienFiscaSolicitud());
					t10396.setFecCrea(bexiste.getFecCrea());
					t10396.setDirIpusucrea(bexiste.getDirIpusucrea());
					t10396.setCodUsuCrea(bexiste.getCodUsuCrea());
					t10396BienFisSolicDAO.update(t10396, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					logger.debug("BienFiscalizadoSolicitud:no existe");
					t10396.setFecCrea(new Date());
					t10396.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
					t10396.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
					t10396.setNumBienFiscaSolicitud(t10396BienFisSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_BIENES_FISCALIZARSOL, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10396BienFisSolicDAO.save(t10396, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
				}
			}
		}
		// ERROR AL REGISTRAR CON TRANSACCIONALIDAD
		filtro.setNumSolicitud(numSolicitud);
		filtro.setNumSolicitudUnion(AccionesControlUtil.generarNumSoli(model.getNumCorrel(), model.getAnioSolicitud(), model.getCodUnidadOrganica()));
		return filtro;
	}
	
	@Override
	public boolean eliminarSolicitudProgramacion(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - eliminarSolicitudProgramacion");
		boolean exito = true;
		try {
			SolicitudProgramacion t10421 = t10421SolicProgDAO.findById(filtro.getNumSolicitud(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
			t10421.setCodEstadoSolicitud(AccionesControlConstantes.COD_ESTADO_SOLICITUD_ANULADO);
			t10421.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
			t10421.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
			t10421SolicProgDAO.update(t10421, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			// Registrar movimiento solicitud
			MovimientoSolicitud t10414 = new MovimientoSolicitud();
			t10414.setCodPersMov(filtro.getAuditoriaBean().getNroRegistro());
			t10414.setFecMovimiento(new Date());
			t10414.setNumSolicitud(filtro.getNumSolicitud());
			t10414.setNumMovimientoPrograma(t10414MovSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_MOVIMIENTO_SOLICITUD, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10414.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10414.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10414.setFecCrea(new Date());
			t10414.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
			t10414.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
			t10414.setCodCargo(" "); // FIXME
			t10414MovSolicDAO.save(t10414, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			exito = false;
		}
		return exito;
	}

	@Override
	public ResponseBean<UsuarioSolicitudBean> guardarUsuario(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - guardarUsuario");
		boolean esRegistro = filtro.getNumUsuarioSolicitud() == 0;
		PropertyParams params = new PropertyParams();
		params.addProperty("numSolicitud", filtro.getNumSolicitud());
		params.addProperty("codTipoDocumentoIdentif", filtro.getCodTipoDocumentoIdentif());
		params.addProperty("numDocumentoIdentif", filtro.getNumDocumentoIdentif());
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<UsuarioSolicitud> t10429existe = t10429UsuarioSolicDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10429existe) && esRegistro) {
			return new ResponseBean<UsuarioSolicitudBean>(false, MensajesExcepciones.CUS01_EXCP_019);
		}

		UsuarioSolicitud model = esRegistro ? new UsuarioSolicitud() : t10429UsuarioSolicDAO.findById(filtro.getNumUsuarioSolicitud(), AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// INI Registrar archivo
		Long numArc = null;
		ArchivoBean archivoBean = filtro.getArchivoBean();
		if (!MaestrosUtilidades.isEmpty(archivoBean)) {
			archivoBean.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_USUARIO);
			archivoBean.setNumArc(!esRegistro ? model.getNumArc() : null);
			numArc = comunService.guardarArchivo(archivoBean, filtro.getAuditoriaBean());
		}
		// FIN Registrar archivo
		Long numUsuarioSolicitud;
		model.setNumSolicitud(filtro.getNumSolicitud());
		model.setCodTipoDocumentoIdentif(filtro.getCodTipoDocumentoIdentif());
		model.setNumDocumentoIdentif(filtro.getNumDocumentoIdentif());
		model.setNomApellidoUsuario(filtro.getNomApellidoUsuario());
		model.setCodTipoDocumentoReferencia(filtro.getCodTipoDocumentoReferencia());
		model.setNumDocumentoReferencia(filtro.getNumDocumentoReferencia());
		model.setCodTipoAccion(filtro.getCodTipoAccion());
		model.setCodTipoIntervencion(filtro.getCodTipoIntervencion());
		model.setFecSugeridaVisita(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFecSugeridaVisita()));
		model.setHorSugeVisit(MaestrosUtilidades.stringToDate(filtro.getHorSugeVisit(), MaestrosConstantes.FORMAT_HORA_HHMMSS));
		model.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		model.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		model.setNumArc(numArc);
		if (esRegistro) {
			numUsuarioSolicitud = t10429UsuarioSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_USUARIO_SOLICITUD, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			model.setNumUsuarioSolicitud(numUsuarioSolicitud);
			model.setFecCrea(new Date());
			model.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
			model.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
			t10429UsuarioSolicDAO.save(model, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			numUsuarioSolicitud = filtro.getNumUsuarioSolicitud();
			model.setNumUsuarioSolicitud(numUsuarioSolicitud);
			model.setFecModif(new Date());
			model.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
			model.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
			t10429UsuarioSolicDAO.update(model, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}

		// Medios Probatorios
		// Dar de baja todos
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioSolicitud", numUsuarioSolicitud);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<MedioProbatorioUsuario> t10412lista = t10412MedioProbUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10412lista)) {
			for (MedioProbatorioUsuario t10412 : t10412lista) {
				t10412.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
				t10412.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10412MedioProbUsuDAO.update(t10412, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}
		
		PropertyParams detalleParams;
		List<MedioProbatorioUsuarioBean> mediosProbatorios = filtro.getMediosProbatorios();
		if (!MaestrosUtilidades.isEmpty(mediosProbatorios)) {
			for (MedioProbatorioUsuarioBean medioProbatorio : mediosProbatorios) {
				MedioProbatorioUsuario t10412 = new MedioProbatorioUsuario();
				t10412.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10412.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				t10412.setNumUsuarioSolicitud(numUsuarioSolicitud);
				t10412.setCodTipoMedioProbatorio(medioProbatorio.getCodTipoMedioProbatorio());
				t10412.setNumMedioProbatorio(medioProbatorio.getNumMedioProbatorio());
				t10412.setNumUsuarioSolicitud(numUsuarioSolicitud);
				detalleParams = new PropertyParams();
				detalleParams.addProperty("numUsuarioSolicitud", numUsuarioSolicitud);
				detalleParams.addProperty("codTipoMedioProbatorio", medioProbatorio.getCodTipoMedioProbatorio());
				List<MedioProbatorioUsuario> existe = t10412MedioProbUsuDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				// INI Registrar archivo
				Long numArcProb = null;
				archivoBean = medioProbatorio.getArchivoBean();
				if (!MaestrosUtilidades.isEmpty(archivoBean)) {
					archivoBean.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_MEDIOPROBATORIO);
					archivoBean.setNumArc(!MaestrosUtilidades.isEmpty(existe) ? existe.get(0).getNumArc() : null);
					numArcProb = comunService.guardarArchivo(archivoBean, filtro.getAuditoriaBean());
				}
				t10412.setNumArc(numArcProb);
				// FIN Registrar archivo
				if (!MaestrosUtilidades.isEmpty(existe)) {
					MedioProbatorioUsuario bexiste = existe.get(0);
					t10412.setFecModif(new Date());
					t10412.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
					t10412.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
					t10412.setNumMedioProbatorioUsuario(bexiste.getNumMedioProbatorioUsuario());
					t10412.setFecCrea(bexiste.getFecCrea());
					t10412.setDirIpusucrea(bexiste.getDirIpusucrea());
					t10412.setCodUsuCrea(bexiste.getCodUsuCrea());
					t10412MedioProbUsuDAO.update(t10412, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					t10412.setFecCrea(new Date());
					t10412.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
					t10412.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
					t10412.setNumMedioProbatorioUsuario(t10412MedioProbUsuDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_MEDIO_PROBATORIO, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10412MedioProbUsuDAO.save(t10412, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
		}

		// Incosistencias
		// DAR DE BAJA TODOS ANTES INCONSISTENCIAS
		List<TipoInconsistenciaUsuario> t10427lista = t10427TipInconUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10427lista)) {
			for (TipoInconsistenciaUsuario t10427 : t10427lista) {
				t10427.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
				t10427.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10427TipInconUsuDAO.update(t10427, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}
		List<DataCatalogoBean> inconsistencias = filtro.getInconsistencias();
		if (!MaestrosUtilidades.isEmpty(inconsistencias)) {
			for (DataCatalogoBean incosistencia : inconsistencias) {
				TipoInconsistenciaUsuario t10427 = new TipoInconsistenciaUsuario();
				t10427.setNumUsuarioSolicitud(numUsuarioSolicitud);
				t10427.setCodTipoInconsistencia(incosistencia.getCodDataCatalogo());
				if (AccionesControlConstantes.OPCION_OTROS.equals(incosistencia.getCodDataCatalogo())) {
					t10427.setDesOtraInconsistencia(filtro.getDesOtraInconsistencia());
				}
				t10427.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10427.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				// Validar si esta registrado
				detalleParams = new PropertyParams();
				detalleParams.addProperty("numUsuarioSolicitud", numUsuarioSolicitud);
				detalleParams.addProperty("codTipoInconsistencia", incosistencia.getCodDataCatalogo());
				List<TipoInconsistenciaUsuario> existe = t10427TipInconUsuDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(existe)) {
					TipoInconsistenciaUsuario bexiste = existe.get(0);
					t10427.setFecModif(new Date());
					t10427.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
					t10427.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
					t10427.setNumInconsistenciaUsuario(bexiste.getNumInconsistenciaUsuario());
					t10427.setFecCrea(bexiste.getFecCrea());
					t10427.setDirIpusucrea(bexiste.getDirIpusucrea());
					t10427.setCodUsuCrea(bexiste.getCodUsuCrea());
					t10427TipInconUsuDAO.update(t10427, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					t10427.setFecCrea(new Date());
					t10427.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
					t10427.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
					t10427.setNumInconsistenciaUsuario(t10427TipInconUsuDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_TIPINCONS_USUARIO, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10427TipInconUsuDAO.save(t10427, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
				}
			}
		}

		// DAR DE BAJA TODOS LOS BIENES
		List<BienFiscalizadoUsuario> t10397lista = t10397BienFiscaUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10397lista)) {
			for (BienFiscalizadoUsuario t10397 : t10397lista) {
				t10397.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
				t10397.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10397BienFiscaUsuDAO.update(t10397, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}
		// tipo bienes
		List<DataCatalogoBean> tipoBienes = filtro.getTipoBienes().stream().filter(t -> Arrays.asList(AccionesControlConstantes.OPCION_OTROS,
				AccionesControlConstantes.OPCION_TIPO_BIEN_DISOLVENTE,
				AccionesControlConstantes.OPCION_TIPO_BIEN_MEZCLA).indexOf(t.getCodDataCatalogo()) >= 0).collect(Collectors.toList());
		if (!MaestrosUtilidades.isEmpty(tipoBienes)) {
			for (DataCatalogoBean tipoBien : tipoBienes) {
				BienFiscalizadoUsuario t10397 = new BienFiscalizadoUsuario();
				t10397.setNumUsuarioSolicitud(numUsuarioSolicitud);
				t10397.setCodTipoBien(tipoBien.getCodDataCatalogo());
				t10397.setDesOtroBien(filtro.getDesOtraTipoBien());
				t10397.setCodBienFiscalizado(AccionesControlConstantes.COD_BIEN_VACIO);
				t10397.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10397.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				detalleParams = new PropertyParams();
				detalleParams.addProperty("numUsuarioSolicitud", numUsuarioSolicitud);
				detalleParams.addProperty("codTipoBien", tipoBien.getCodDataCatalogo());
				detalleParams.addProperty("codBienFiscalizado", AccionesControlConstantes.COD_BIEN_VACIO);
				List<BienFiscalizadoUsuario> existe = t10397BienFiscaUsuDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(existe)) {
					BienFiscalizadoUsuario bexiste = existe.get(0);
					t10397.setFecModif(new Date());
					t10397.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
					t10397.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
					t10397.setNumBienFiscaUsuario(bexiste.getNumBienFiscaUsuario());
					t10397.setFecCrea(bexiste.getFecCrea());
					t10397.setDirIpusucrea(bexiste.getDirIpusucrea());
					t10397.setCodUsuCrea(bexiste.getCodUsuCrea());
					t10397BienFiscaUsuDAO.update(t10397, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					t10397.setFecCrea(new Date());
					t10397.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
					t10397.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
					t10397.setNumBienFiscaUsuario(t10396BienFisSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_BIENES_FISCALIZARUSUARIO, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10397BienFiscaUsuDAO.save(t10397, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
				}
			}
		}
		// bienes
		List<BienFiscalizadoSolicitudBean> bienes = filtro.getBienesFiscalizados();
		if (!MaestrosUtilidades.isEmpty(bienes)) {
			for (BienFiscalizadoSolicitudBean bien : bienes) {
				BienFiscalizadoUsuario t10397 = new BienFiscalizadoUsuario();
				t10397.setNumUsuarioSolicitud(numUsuarioSolicitud);
				t10397.setCodTipoBien(bien.getCodTipoBien());
				t10397.setDesOtroBien(null);
				t10397.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10397.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				t10397.setCodBienFiscalizado(bien.getCodBienFiscalizado());
				detalleParams = new PropertyParams();
				detalleParams.addProperty("numUsuarioSolicitud", numUsuarioSolicitud);
				detalleParams.addProperty("codTipoBien", bien.getCodTipoBien());
				detalleParams.addProperty("codBienFiscalizado", bien.getCodBienFiscalizado());
				List<BienFiscalizadoUsuario> existe = t10397BienFiscaUsuDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(existe)) {
					BienFiscalizadoUsuario bexiste = existe.get(0);
					t10397.setFecModif(new Date());
					t10397.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
					t10397.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
					t10397.setNumBienFiscaUsuario(bexiste.getNumBienFiscaUsuario());
					t10397.setFecCrea(bexiste.getFecCrea());
					t10397.setDirIpusucrea(bexiste.getDirIpusucrea());
					t10397.setCodUsuCrea(bexiste.getCodUsuCrea());
					t10397BienFiscaUsuDAO.update(t10397, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					t10397.setFecCrea(new Date());
					t10397.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
					t10397.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
					t10397.setNumBienFiscaUsuario(t10396BienFisSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_BIENES_FISCALIZARUSUARIO, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10397BienFiscaUsuDAO.save(t10397, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
				}
			}
		}
		return new ResponseBean<UsuarioSolicitudBean>(filtro);
	}
	
	@Override
	public boolean eliminarUsuario(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - eliminarUsuario");

		boolean exito = true;
		try {
			UsuarioSolicitud t10429 = t10429UsuarioSolicDAO.findById(filtro.getNumUsuarioSolicitud(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
			t10429.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
			t10429.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
			t10429UsuarioSolicDAO.update(t10429, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			PropertyParams propertyParams = new PropertyParams();
			propertyParams.addProperty("numUsuarioSolicitud", filtro.getNumUsuarioSolicitud());
			propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<MedioProbatorioUsuario> t10412lista = t10412MedioProbUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10412lista)) {
				for (MedioProbatorioUsuario t10412 : t10412lista) {
					t10412.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
					t10412.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
					t10412MedioProbUsuDAO.update(t10412, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
			// DAR DE BAJA TODOS LOS BIENES
			List<BienFiscalizadoUsuario> t10397lista = t10397BienFiscaUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10397lista)) {
				for (BienFiscalizadoUsuario t10397 : t10397lista) {
					t10397.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
					t10397.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
					t10397BienFiscaUsuDAO.update(t10397, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
			List<TipoInconsistenciaUsuario> t10427lista = t10427TipInconUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10427lista)) {
				for (TipoInconsistenciaUsuario t10427 : t10427lista) {
					t10427.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
					t10427.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
					t10427TipInconUsuDAO.update(t10427, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			exito = false;
		}
		return exito;
	}
	
	@Override
	public boolean eliminarEstablecimientoUsuario(EstablecimientoUsuarioBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - eliminarEstablecimientoUsuario");
		boolean exito = true;
		try {
			EstablecimientoUsuario t10409 = t10409EstabUsuDAO.findById(filtro.getNumEstablecimientoUsuario(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
			t10409.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
			t10409.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
			t10409.setFecModif(new Date());
			t10409.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
			t10409.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
			t10409EstabUsuDAO.update(t10409, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			exito = false;
		}
		return exito;
	}
	
	@Override
	public UsuarioSolicitudBean obtenerDatosUsuario(UsuarioSolicitudBean filtro) {
		UsuarioSolicitudBean bean = new UsuarioSolicitudBean();
		UsuarioSolicitud t10429 = t10429UsuarioSolicDAO.findById(filtro.getNumUsuarioSolicitud(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		MaestrosUtilidades.copiarValoresBean(t10429, bean);
		bean.setMediosProbatorios(new ArrayList<>());
		bean.setInconsistencias(new ArrayList<>());
		bean.setTipoBienes(new ArrayList<>());
		bean.setFecSugeridaVisita(MaestrosUtilidades.dateToStringDDMMYYYY(t10429.getFecSugeridaVisita()));
		bean.setHorSugeVisit(MaestrosUtilidades.dateToString(t10429.getHorSugeVisit(), MaestrosConstantes.FORMAT_HORA_HHMMSS));
		// Archivo Bean
		ArchivoBean archivoBean = comunService.obtenerArchivo(t10429.getNumArc());
		if (!MaestrosUtilidades.isEmpty(archivoBean)) {
			bean.setArchivoBean(archivoBean);
		}
		// medios probatorios
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioSolicitud", filtro.getNumUsuarioSolicitud());
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<MedioProbatorioUsuario> t10412lista = t10412MedioProbUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10412lista)) {
			List<MedioProbatorioUsuarioBean> mediosProbatorios = new ArrayList<>();
			for (MedioProbatorioUsuario t10412 : t10412lista) {
				MedioProbatorioUsuarioBean medioBean = new MedioProbatorioUsuarioBean();
				MaestrosUtilidades.copiarValoresBean(t10412, medioBean);
				// Archivo Bean
				archivoBean = comunService.obtenerArchivo(t10412.getNumArc());
				if (!MaestrosUtilidades.isEmpty(archivoBean)) {
					medioBean.setArchivoBean(archivoBean);
				}
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPODOC_TRANSACCION,
						t10412.getCodTipoMedioProbatorio());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					medioBean.setDesMedioProbatorio(catalogo.getDescripcionDataCatalogo());	
				}
				mediosProbatorios.add(medioBean);
			}
			bean.setMediosProbatorios(mediosProbatorios);
		}
		// inconsistencias
		List<TipoInconsistenciaUsuario> t10427lista = t10427TipInconUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10427lista)) {
			List<DataCatalogoBean> inconsistencias = t10427lista.stream().map(t10427 -> {
				DataCatalogoBean data = new DataCatalogoBean(t10427.getCodTipoInconsistencia(), t10427.getDesOtraInconsistencia());
				data.setSeleccionado(true);
				data.setDescripcionCorta(t10427.getDesOtraInconsistencia());
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INCONSISTENCIAS,
						t10427.getCodTipoInconsistencia());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					data.setDescripcionDataCatalogo(catalogo.getDescripcionDataCatalogo());
				}
				return data;
			}).collect(Collectors.toList());
			String otraIncosistencia = inconsistencias.stream()
							.filter(check -> AccionesControlConstantes.OPCION_OTROS.equals(check.getCodDataCatalogo()))
							.map(DataCatalogoBean::getDescripcionCorta).findFirst().orElse(null);
			bean.setInconsistencias(inconsistencias);
			bean.setDesOtraInconsistencia(otraIncosistencia);
		}

		// Bienes y tipo Bienes
		List<BienFiscalizadoUsuario> t10397lista = t10397BienFiscaUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10397lista)) {
			List<BienFiscalizadoSolicitudBean> bienes = t10397lista.stream().filter(t10397 -> {
				return Arrays.asList(AccionesControlConstantes.OPCION_OTROS,
						AccionesControlConstantes.OPCION_TIPO_BIEN_DISOLVENTE,
						AccionesControlConstantes.OPCION_TIPO_BIEN_MEZCLA).indexOf(t10397.getCodTipoBien()) < 0;
			}).map(t10397 -> {
				BienFiscalizadoSolicitudBean bien = new BienFiscalizadoSolicitudBean(t10397.getCodBienFiscalizado(), t10397.getCodTipoBien(), t10397.getDesOtroBien());
				bien.setSeleccionado(true);
				PropertyParams params = new PropertyParams();
				params.addProperty("codBien", t10397.getCodBienFiscalizado());
				params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
				List<BienFiscal> t7883lista = t7883BienFiscalDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				if (!MaestrosUtilidades.isEmpty(t7883lista)) {
					bien.setDesBienFisca(t7883lista.get(0).getDesBien());
				}
				return bien;
			}).collect(Collectors.toList());
			Set<String> setTipoBienes = t10397lista.stream().map(BienFiscalizadoUsuario::getCodTipoBien).collect(Collectors.toSet());
			List<DataCatalogoBean> tipoBienes = setTipoBienes.stream().map(tipoBien -> {
				DataCatalogoBean data = new DataCatalogoBean(tipoBien);
				data.setSeleccionado(true);
				if (!AccionesControlConstantes.OPCION_OTROS.equals(tipoBien)) {
					DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_BIEN,
							tipoBien);
					if (!MaestrosUtilidades.isEmpty(catalogo)) {
						data.setDescripcionDataCatalogo(catalogo.getDescripcionDataCatalogo());
					}	
				} else {
					data.setDescripcionDataCatalogo(AccionesControlConstantes.OPCION_DESCRIPCION_OTROS);
				}
				return data;
			}).collect(Collectors.toList());
			String otroBien = t10397lista.stream()
					.filter(check -> Arrays.asList(AccionesControlConstantes.OPCION_OTROS,
							AccionesControlConstantes.OPCION_TIPO_BIEN_DISOLVENTE,
							AccionesControlConstantes.OPCION_TIPO_BIEN_MEZCLA).indexOf(check.getCodTipoBien()) >= 0)
					.map(BienFiscalizadoUsuario::getDesOtroBien).findFirst().orElse(null);
			bean.setDesOtraTipoBien(otroBien);
			bean.setBienesFiscalizados(bienes);
			bean.setTipoBienes(tipoBienes);
		}
		return bean;
	}
	
	@Override
	public EstablecimientoUsuarioBean obtenerDatosEstablecimientoUsuario(EstablecimientoUsuarioBean filtro) {
		EstablecimientoUsuario t10409 = t10409EstabUsuDAO.findById(filtro.getNumEstablecimientoUsuario(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		EstablecimientoUsuarioBean bean = new EstablecimientoUsuarioBean();
		MaestrosUtilidades.copiarValoresBean(t10409, bean);
		bean.setDesDepartamento("");
		bean.setDesProvincia("");
		bean.setDesDistrito("");
		UbigeoBean departamento = ubigeoService.obtenerUbigeoDescripcion(t10409.getCodDepartamento());
		if (!MaestrosUtilidades.isEmpty(departamento)) {
			bean.setDesDepartamento(departamento.getDesUbigeo());
		}
		UbigeoBean provincia = ubigeoService.obtenerUbigeoDescripcion(t10409.getCodProvincia());
		if (!MaestrosUtilidades.isEmpty(provincia)) {
			bean.setDesProvincia(provincia.getDesUbigeo());
		}
		UbigeoBean distrito = ubigeoService.obtenerUbigeoDescripcion(t10409.getCodDistrito());
		if (!MaestrosUtilidades.isEmpty(distrito)) {
			bean.setDesDistrito(distrito.getDesUbigeo());
		}
		return bean;
	}

	@Override
	public List<UsuarioSolicitudBean> obtenerDetalleSolicitud(Long numSolicProg) {
		UsuarioSolicitud parametro = new UsuarioSolicitud();
		parametro.setNumSolicitud(numSolicProg);
		parametro.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		parametro.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		DataCatalogoBean catalogo;
		List<UsuarioSolicitudBean> lista = new ArrayList<>();
		List<UsuarioSolicitud> t10429lista = t10429UsuarioSolicDAO.listarUsuariosSolicitud(parametro);
		if (!MaestrosUtilidades.isEmpty(t10429lista)) {
			for (UsuarioSolicitud t10429 : t10429lista) {
				UsuarioSolicitudBean bean = new UsuarioSolicitudBean();
				bean.setInconsistencias(new ArrayList<>());
				bean.setBienesFiscalizados(new ArrayList<>());
				bean.setTipoBienes(new ArrayList<>());
				bean.setMediosProbatorios(new ArrayList<>());
				MaestrosUtilidades.copiarValoresBean(t10429, bean);
				bean.setNumSolicitud(numSolicProg);
				bean.setFecSugeridaVisita(MaestrosUtilidades.dateToStringDDMMYYYY(t10429.getFecSugeridaVisita()));
				bean.setHorSugeVisit(MaestrosUtilidades.dateToString(t10429.getHorSugeVisit(), MaestrosConstantes.FORMAT_HORA_HHMMSS));
				catalogo = dataCatalogoService
						.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_DOCUMENTO_REFERENCIAAC, t10429.getCodTipoDocumentoReferencia());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesTipoDocumentoRef(catalogo.getDescripcionDataCatalogo());
				}
				catalogo = dataCatalogoService
						.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL, t10429.getCodTipoAccion());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesTipoAccionControl(catalogo.getDescripcionDataCatalogo());
				}
				catalogo = dataCatalogoService
						.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INTERVENCION, t10429.getCodTipoIntervencion());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesTipoIntervencion(catalogo.getDescripcionDataCatalogo());
				}
				catalogo = dataCatalogoService
						.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF, t10429.getCodTipoDocumentoIdentif());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesTipoDocumentoIdent(catalogo.getDescripcionDataCatalogo());
				}
				// Archivo Bean
				System.out.println("t10429.getNumArc() => " + t10429.getNumArc());
				ArchivoBean archivoBean = comunService.obtenerArchivo(t10429.getNumArc());
				if (!MaestrosUtilidades.isEmpty(archivoBean)) {
					bean.setArchivoBean(archivoBean);
				}
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	public List<EstablecimientoUsuarioBean> listarEstablecimientosUsuario(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - listarEstablecimientosUsuario");
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioSolicitud", filtro.getNumUsuarioSolicitud());
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<EstablecimientoUsuarioBean> lista = new ArrayList<>();
		List<EstablecimientoUsuario> t10409lista = t10409EstabUsuDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10409lista)) {
			for (EstablecimientoUsuario t10409 : t10409lista) {
				EstablecimientoUsuarioBean bean = new EstablecimientoUsuarioBean();
				MaestrosUtilidades.copiarValoresBean(t10409, bean);
				bean.setNumUsuarioSolicitud(filtro.getNumUsuarioSolicitud());
				bean.setDesDepartamento("");
				bean.setDesProvincia("");
				bean.setDesDistrito("");
				UbigeoBean departamento = ubigeoService.obtenerUbigeoDescripcion(t10409.getCodDepartamento());
				if (!MaestrosUtilidades.isEmpty(departamento)) {
					bean.setDesDepartamento(departamento.getDesUbigeo());
				}
				String codProv = MaestrosUtilidades.toBlank(bean.getCodDepartamento()).concat(MaestrosUtilidades.toBlank(t10409.getCodProvincia()));
				UbigeoBean provincia = ubigeoService.obtenerUbigeoDescripcion(codProv);
				if (!MaestrosUtilidades.isEmpty(provincia)) {
					bean.setDesProvincia(provincia.getDesUbigeo());
				}
				String codDist = codProv.concat(MaestrosUtilidades.toBlank(t10409.getCodDistrito()));
				UbigeoBean distrito = ubigeoService.obtenerUbigeoDescripcion(codDist);
				if (!MaestrosUtilidades.isEmpty(distrito)) {
					bean.setDesDistrito(distrito.getDesUbigeo());
				}
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	public UsuarioSolicitudBean guardarEstablecimiento(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - guardarEstablecimiento");
		for (EstablecimientoUsuarioBean establecimiento : filtro.getEstablecimientos()) {
			boolean esRegistro = establecimiento.getNumEstablecimientoUsuario() == 0;
			EstablecimientoUsuario t10409 = esRegistro ? new EstablecimientoUsuario() : t10409EstabUsuDAO.findById(establecimiento.getNumEstablecimientoUsuario(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
			t10409.setCodDepartamento(establecimiento.getCodDepartamento());
			t10409.setCodDistrito(establecimiento.getCodDistrito());
			t10409.setCodProvincia(establecimiento.getCodProvincia());
			t10409.setDesDireccionEstablecimiento(establecimiento.getDesDireccionEstablecimiento());
			t10409.setNumUsuarioSolicitud(filtro.getNumUsuarioSolicitud());
			t10409.setNumEstablecimiento(establecimiento.getNumEstablecimiento().intValue());
			t10409.setIndOtroEstab(establecimiento.getIndOtroEstab());
			t10409.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10409.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			if (esRegistro) {
				t10409.setFecCrea(new Date());
				t10409.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
				t10409.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
				t10409.setNumEstablecimientoUsuario(t10409EstabUsuDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ESTABLECIMIENTO_USARIO, AccionesControlConstantes.DATASOURCE_DGSICOBF));
				t10409EstabUsuDAO.save(t10409, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			} else {
				t10409.setNumEstablecimientoUsuario(establecimiento.getNumEstablecimientoUsuario());
				t10409.setFecModif(new Date());
				t10409.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
				t10409.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
				t10409EstabUsuDAO.update(t10409, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
			establecimiento.setNumEstablecimientoUsuario(t10409.getNumEstablecimientoUsuario());
		}
		return filtro;
	}

	@Override
	public ResponseBean<String> enviarDetalleSolicitudProgram(UsuarioSolicitudBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - enviarDetalleSolicitudProgram");
		ResponseBean<String> respuesta = new ResponseBean<String>();

		// Verificar usuarios
		PropertyParams prop = new PropertyParams();
		prop.addProperty("numSolicitud", filtro.getNumSolicitud());
		prop.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		prop.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<UsuarioSolicitud> t10429lista = t10429UsuarioSolicDAO.findByProperties(prop, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (MaestrosUtilidades.isEmpty(t10429lista)) {
			respuesta.setExito(false);
			respuesta.setMensaje(MensajesExcepciones.CUS01_EXCP_004);
			return respuesta;
		}

		// Calificacion
		Integer total = t10429UsuarioSolicDAO.obtenerTotalUsuarioCalif(filtro.getNumSolicitud(), AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
		if (!MaestrosUtilidades.isEmpty(t10429lista) && total < t10429lista.size()) {
			respuesta.setExito(false);
			respuesta.setMensaje(MensajesExcepciones.CUS01_EXCP_016);
			return respuesta;
		}

		// Criterios con calificacion
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<CriterioCalificacion> t10402lista = t10402CriterioCaliDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		for (UsuarioSolicitud t10429 : t10429lista) {
			PropertyParams t10400params = new PropertyParams();
			t10400params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10400params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			t10400params.addProperty("numUsuarioSolicitud", t10429.getNumUsuarioSolicitud());
			t10400params.addProperty("indTipCali", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
			List<CalificacionUsuario> t10400lista = t10400CaliUsuaDAO.findByProperties(t10400params, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10400lista)) {
				for (CalificacionUsuario t10400 : t10400lista) {
					PropertyParams property = new PropertyParams();
					property.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					property.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
					property.addProperty("numUsuarioCalifiicacion", t10400.getNumUsuarioCalifiicacion());
					Long t10402count = t10403DetaCaliUsuaDAO.countByProperties(property, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					if (t10402count.intValue() < t10402lista.size()) {
						respuesta.setExito(false);
						respuesta.setMensaje(MensajesExcepciones.CUS01_EXCP_007);
						return respuesta;
					}
				}
			}
		}

		// Establecimientos x fiscalizacion
		List<UsuarioSolicitud> fiscalizaciones = t10429lista.stream()
				.filter(t10429 -> AccionesControlConstantes.COD_TIP_INTERVENCION_FISCALIZACION.equals(t10429.getCodTipoIntervencion()))
				.collect(Collectors.toList());
		UsuarioSolicitud map = new UsuarioSolicitud();
		map.setNumSolicitud(filtro.getNumSolicitud());
		Integer establecimientos = t10429UsuarioSolicDAO.validarTotalEstablecimientoxUsuario(map);
		if (!MaestrosUtilidades.isEmpty(fiscalizaciones) && establecimientos < fiscalizaciones.size()) {
			respuesta.setExito(false);
			respuesta.setMensaje(MensajesExcepciones.CUS01_EXCP_015);
			return respuesta;
		}

		SolicitudProgramacion t10421 = t10421SolicProgDAO.findById(filtro.getNumSolicitud(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		t10421.setCodEstadoSolicitud(AccionesControlConstantes.COD_ESTADO_SOLICITUD_ELABORADO);
		t10421.setFecModif(new Date());
		t10421.setDirIpusumodif(filtro.getAuditoriaBean().getNumIp());
		t10421.setCodUsuModif(filtro.getAuditoriaBean().getLogin());
		t10421SolicProgDAO.update(t10421, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// Registrar movimiento solicitud
		MovimientoSolicitud t10414 = new MovimientoSolicitud();
		t10414.setCodPersMov(filtro.getAuditoriaBean().getNroRegistro());
		t10414.setFecMovimiento(new Date());
		t10414.setNumSolicitud(filtro.getNumSolicitud());
		t10414.setNumMovimientoPrograma(t10414MovSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_MOVIMIENTO_SOLICITUD, AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10414.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10414.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10414.setFecCrea(new Date());
		t10414.setDirIpusucrea(filtro.getAuditoriaBean().getNumIp());
		t10414.setCodUsuCrea(filtro.getAuditoriaBean().getLogin());
		t10414.setCodCargo(" "); // FIXME
		t10414MovSolicDAO.save(t10414, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		respuesta.setExito(true);
		return respuesta;
	}

	@Override
	public ResponseBean<List<String>> vigenciaUsuarioSolicitud(String tipoDocUsuario, String numDocUsuario) {
		ResponseBean<List<String>> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		SolicitudProgramacion filtro = new SolicitudProgramacion();
		filtro.setNumDocIdent(numDocUsuario);
		filtro.setCodTipDocIdent(tipoDocUsuario);
		filtro.setEstados(Arrays.asList(AccionesControlConstantes.COD_ESTADO_SOLICITUD_APROBADO,
				AccionesControlConstantes.COD_ESTADO_SOLICITUD_ARCHIVADO, AccionesControlConstantes.COD_ESTADO_SOLICITUD_ANULADO));
		List<String> mensajes = new ArrayList<>();
		List<SolicitudProgramacion> t10421lista = t10421SolicProgDAO.vigenciaUsuarioSolicitud(filtro);
		if (!MaestrosUtilidades.isEmpty(t10421lista)) {
			for (SolicitudProgramacion t10421 : t10421lista) {
				Integer correl = t10421.getNumCorrel();
				String estado = "";
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_SOLICITUD,
						t10421.getCodEstadoSolicitud());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					estado = catalogo.getDescripcionDataCatalogo();
				}
				String nomSolicitante = "";
				WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(t10421.getCodSolicitante());
				if (!MaestrosUtilidades.isEmpty(solicitante)) {
					nomSolicitante = solicitante.getNomCompleto();
				}
				String fechaGeneracion = MaestrosUtilidades.dateToStringDDMMYYYY(t10421.getFecGeneracion());
				mensajes.add(String.format("%d - %s - %s - %s", correl, estado, nomSolicitante, fechaGeneracion));
			}
			respuesta = new ResponseBean<>(true, mensajes);
		}
		return respuesta;
	}

	@Override
	public ResponseBean<List<String>> vigenciaUsuarioOrden(String tipoDocUsuario, String numDocUsuario) {
		ResponseBean<List<String>> respuesta = new ResponseBean<>(false, MaestrosMensajes.MENSAJE_LISTA_VACIA);
		OrdenAccion filtro = new OrdenAccion();
		filtro.setCodTipDocIdent(tipoDocUsuario);
		filtro.setNumDocIdent(numDocUsuario);
		filtro.setEstados(Arrays.asList(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO, AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA));
		List<String> mensajes = new ArrayList<>();
		List<OrdenAccion> t10415lista = t10415OrdenAccionDAO.vigenciaUsuarioOrden(filtro);
		if(!MaestrosUtilidades.isEmpty(t10415lista)) {
			for (OrdenAccion t10415 : t10415lista) {
				Integer correl = t10415.getNumCorrel();
				String estado = "";
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_ORDEN,
						t10415.getCodEstadoOrden());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					estado = catalogo.getDescripcionDataCatalogo();
				}
				String nomAuditor = "";
				WSPersonalIqbfBean auditor = servicioWebService.obtenerPersonalIqbf(t10415.getCodPers());
				if (!MaestrosUtilidades.isEmpty(auditor)) {
					nomAuditor = auditor.getNomCompleto();
				}
				String fechaGeneracion = MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecOrden());
				mensajes.add(String.format("%d - %s - %s - %s", correl, estado, nomAuditor, fechaGeneracion));
			}
		}
		return respuesta;
	}

	@Override
	public CalificacionUsuarioBean obtenerDatosCaliPre(Long numUsuario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - obtenerDatosCaliPre");
		UsuarioSolicitud filtro = new UsuarioSolicitud();
		filtro.setNumUsuarioSolicitud(numUsuario);
		filtro.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		CalificacionUsuarioBean calificacion = null;
		List<SolicitudProgramacion> t10421lista = t10421SolicProgDAO.obtenerDatosCaliPre(filtro);
		if (!MaestrosUtilidades.isEmpty(t10421lista)) {
			calificacion = new CalificacionUsuarioBean();
			calificacion.setAlternativasCriterios(new ArrayList<>());
			SolicitudProgramacion t10421 = t10421lista.get(0);
			calificacion.setNumSolicitudUnion(AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
			calificacion.setNomSolicitante("");
			WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(t10421.getCodSolicitante());
			if (!MaestrosUtilidades.isEmpty(solicitante)) {
				calificacion.setNomSolicitante(solicitante.getNomCompleto());
			}
			calificacion.setCodTipoIntervension(t10421.getCodTipInterv());
			calificacion.setCodTipoAccion(t10421.getCodTipAccion());
			DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INTERVENCION, t10421.getCodTipInterv());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				calificacion.setDesTipoIntervencion(catalogo.getDescripcionDataCatalogo());
			}
			catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL, t10421.getCodTipAccion());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				calificacion.setDesTipoAccionControl(catalogo.getDescripcionDataCatalogo());
			}
			calificacion.setCodTipoDocumentoIdentif(t10421.getCodTipDocIdent());
			calificacion.setNumDocumentoIdentif(t10421.getNumDocIdent());
			calificacion.setNomApellidoUsuario(t10421.getNomApeUsu());
			catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF, t10421.getCodTipDocIdent());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				calificacion.setDesTipoDocumentoIdent(catalogo.getDescripcionDataCatalogo());
			}
			// Obtener criterios calificacion preliminar
			PropertyParams propertyParams = new PropertyParams();
			propertyParams.addProperty("numUsuarioSolicitud", numUsuario);
			propertyParams.addProperty("indTipCali", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
			propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<CalificacionUsuario> t10400lista = t10400CaliUsuaDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if(!MaestrosUtilidades.isEmpty(t10400lista)) {
				CalificacionUsuario t10400 = t10400lista.get(0);
				calificacion.setValCalificacion(t10400.getValCalificacion());
				calificacion.setDesSusAccsuge(t10400.getDesSusAccsuge());
				calificacion.setNumAccionSugerida(t10400.getNumAccionSugerida());
				calificacion.setNumUsuarioCalifiicacion(t10400.getNumUsuarioCalifiicacion());
				// Obtener el detalle
				PropertyParams params = new PropertyParams();
				params.addProperty("numUsuarioCalifiicacion", calificacion.getNumUsuarioCalifiicacion());
				params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
				List<AlternativaCriterioBean> preliminares = new ArrayList<>();
				List<DetalleCalificacionUsuario> t10403lista = t10403DetaCaliUsuaDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				if(!MaestrosUtilidades.isEmpty(t10403lista)) {
					for (DetalleCalificacionUsuario t10403 : t10403lista) {
						AlternativaCriterioBean preliminar = new AlternativaCriterioBean();
						preliminar.setValAlternativa(t10403.getValPuntaje());
						preliminar.setNumCriterio(t10403.getNumCriterio());
						preliminar.setNumAlternativa(t10403.getNumAlternativa());
						preliminar.setDesAlternativa(t10389AlternatCritDAO.findById(t10403.getNumAlternativa(), AccionesControlConstantes.DATASOURCE_DCSICOBF).getDesAlternativa());
						preliminares.add(preliminar);
					}
				}
				calificacion.setAlternativasCriterios(preliminares);
			}

		}
		return calificacion;
	}

	@Override
	public CalificacionUsuarioBean guardarCalificacionPreliminar(CalificacionUsuarioBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - guardarCalificacionPreliminar");
		boolean esRegistro = formulario.getNumUsuarioCalifiicacion() == 0;
		CalificacionUsuario calificacion = esRegistro ? new CalificacionUsuario() : t10400CaliUsuaDAO.findById(formulario.getNumUsuarioCalifiicacion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		calificacion.setDesSusAccsuge(formulario.getDesSusAccsuge());
		calificacion.setValCalificacion(formulario.getValCalificacion());
		calificacion.setNumAccionSugerida(formulario.getNumAccionSugerida());
		calificacion.setNumUsuarioSolicitud(formulario.getNumUsuarioSolicitud());
		calificacion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		calificacion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		calificacion.setIndTipCali(AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
		Long numUsuarioCalificacion;
		if (esRegistro) {
			numUsuarioCalificacion = t10400CaliUsuaDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_CRITERIOS_CALIFICACION, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			calificacion.setNumUsuarioCalifiicacion(numUsuarioCalificacion);
			calificacion.setFecCrea(new Date());
			calificacion.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			calificacion.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10400CaliUsuaDAO.save(calificacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			numUsuarioCalificacion = formulario.getNumUsuarioCalifiicacion();
			calificacion.setNumUsuarioCalifiicacion(numUsuarioCalificacion);
			calificacion.setFecModif(new Date());
			calificacion.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			calificacion.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			t10400CaliUsuaDAO.update(calificacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		// Dar de Baja
		PropertyParams params = new PropertyParams();
		params.addProperty("numUsuarioCalifiicacion", calificacion.getNumUsuarioCalifiicacion());
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<DetalleCalificacionUsuario> t10403lista = t10403DetaCaliUsuaDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if(!MaestrosUtilidades.isEmpty(t10403lista)) {
			for (DetalleCalificacionUsuario t10403 : t10403lista) {
				t10403.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10403.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10403DetaCaliUsuaDAO.update(t10403, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}

		List<AlternativaCriterioBean> preliminares = formulario.getAlternativasCriterios();
		if (!MaestrosUtilidades.isEmpty(preliminares)) {
			for (AlternativaCriterioBean alternativaCriterio : preliminares) {
				DetalleCalificacionUsuario t10403 = new DetalleCalificacionUsuario();
				t10403.setValPuntaje(alternativaCriterio.getValAlternativa());
				t10403.setNumAlternativa(alternativaCriterio.getNumAlternativa());
				t10403.setNumCriterio(alternativaCriterio.getNumCriterio());
				t10403.setNumUsuarioCalifiicacion(numUsuarioCalificacion);
				t10403.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10403.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				PropertyParams detalleParams = new PropertyParams();
				detalleParams.addProperty("numUsuarioCalifiicacion", numUsuarioCalificacion);
				detalleParams.addProperty("numAlternativa", alternativaCriterio.getNumAlternativa());
				detalleParams.addProperty("numCriterio", alternativaCriterio.getNumCriterio());
				List<DetalleCalificacionUsuario> existe = t10403DetaCaliUsuaDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(existe)) {
					DetalleCalificacionUsuario bexiste = existe.get(0);
					t10403.setFecModif(new Date());
					t10403.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
					t10403.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
					t10403.setNumDetalleCalificacion(bexiste.getNumDetalleCalificacion());
					t10403.setFecCrea(bexiste.getFecCrea());
					t10403.setDirIpusucrea(bexiste.getDirIpusucrea());
					t10403.setCodUsuCrea(bexiste.getCodUsuCrea());
					t10403DetaCaliUsuaDAO.update(t10403, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					t10403.setFecCrea(new Date());
					t10403.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					t10403.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
					t10403.setNumDetalleCalificacion(t10403DetaCaliUsuaDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_DETALLE_CALIFICACION, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10403DetaCaliUsuaDAO.save(t10403, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
		}
		formulario.setNumUsuarioCalifiicacion(numUsuarioCalificacion);
		return formulario;
	}

	@Override
	public List<SolicitudProgramacionBean> listarSolicitudSupervisorSolicitante(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - listarSolicitudSupervisorSolicitante");
		SolicitudProgramacion filtroModel = new SolicitudProgramacion();
		filtroModel.setCodEstadoSolicitud(AccionesControlConstantes.COD_ESTADO_SOLICITUD_ELABORADO);
		filtroModel.setCodTipAccion(filtro.getCodTipoAccion());
		filtroModel.setCodTipInterv(filtro.getCodTipoIntervension());
		filtroModel.setCodTipDocIdent(filtro.getCodTipoDocUsuario());
		filtroModel.setNumDocIdent(filtro.getNumDocUsuario());
		filtroModel.setCodSolicitante(filtro.getCodSolicitante());
		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			filtroModel.setNumSolicitudUnion(filtro.getNumSolicitudUnion());
		}
		List<SolicitudProgramacionBean> lista = new ArrayList<>();
		List<SolicitudProgramacion> t10421lista = t10421SolicProgDAO.listarSolicitudSupervisorSolicitante(filtroModel);
		if (!MaestrosUtilidades.isEmpty(t10421lista)) {
			for (SolicitudProgramacion t10421 : t10421lista) {
				SolicitudProgramacionBean bean = new SolicitudProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10421, bean);
				bean.setNumSolicitudUnion(AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
				bean.setFecGeneracion(MaestrosUtilidades.dateToStringDDMMYYYY(t10421.getFecGeneracion()));
				bean.setDesEstadoSolicitud("");
				bean.setCalificacionDefinitiva(t10421.getCalificacionDefinitiva());
				bean.setCalificacionPreliminar(t10421.getCalificacionPreliminar());
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_SOLICITUD,
						t10421.getCodEstadoSolicitud());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesEstadoSolicitud(catalogo.getDescripcionDataCatalogo().trim());
				}
				WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(t10421.getCodSolicitante());
				if (!MaestrosUtilidades.isEmpty(solicitante)) {
					bean.setNomSolicitante(solicitante.getNomCompleto());
				}
				lista.add(bean);
			}
		}
		return lista;
	}

}
