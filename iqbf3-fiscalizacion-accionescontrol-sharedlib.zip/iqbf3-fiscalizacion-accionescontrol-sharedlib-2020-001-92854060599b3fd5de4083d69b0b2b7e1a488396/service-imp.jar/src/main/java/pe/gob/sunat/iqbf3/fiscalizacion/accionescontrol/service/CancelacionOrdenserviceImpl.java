package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10445ArcAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10446ArcDataAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class CancelacionOrdenserviceImpl implements CancelacionOrdenservce {
	
	@EJB
	T10415OrdenAccionDAO t10415OrdenAccionDAO;
	
	@EJB
	T10445ArcAcfDAO t10445ArcAcfDAO;
	
	@EJB
	T10446ArcDataAcfDAO t10446ArcDataAcfDAO;
	
	@EJB
	T10420ProgramacionDAO t10420ProgramacionDAO;
	
	@EJB
	private DataCatalogoService dataCatalogoService;
	
	@EJB
	private ComunService comunService;
	
	@EJB
	private ServicioWebService servicioWebService;	
	
	@Override
	public List<OrdenAccionBean> listarOrden(OrdenAccionBean filtro) {
		List<OrdenAccionBean> lista=new ArrayList<OrdenAccionBean>();
		filtro.getNumDocIdent();
		filtro.getNomApelAuditor();
		
		OrdenAccion ordenAccionFiltro = new OrdenAccion();
		ordenAccionFiltro.setCodTipoOrden(filtro.getCodTipoOrden());
		ordenAccionFiltro.setNumOrden(MaestrosUtilidades.toLong(filtro.getNumOrden()));
		ordenAccionFiltro.setFecAsigIni(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFecAsigIni()));
		ordenAccionFiltro.setFecAsigFin(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFecAsigFin()));
		ordenAccionFiltro.setCodTipDocIdent(filtro.getCodTipoDocumentoIdent());
		ordenAccionFiltro.setNumDocIdent(filtro.getNumDocIdent());
		ordenAccionFiltro.setNumOrdenUnion(filtro.getNumOrdenUnion());
		ordenAccionFiltro.setNumInformeUnion(filtro.getNumInformeUnion());
		ordenAccionFiltro.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
		ordenAccionFiltro.setIndEst(AccionesControlConstantes.REGISTRO_ACTIVO);
		ordenAccionFiltro.setCodClase(AccionesControlConstantes.COD_CLASE_DOCUMENTO_ACCION);
		ordenAccionFiltro.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		ordenAccionFiltro.setCodOrigen(AccionesControlConstantes.COD_ACCION_SUGERIDA_NOAPLICA); 
		if (MaestrosUtilidades.isEmpty(filtro.getCodEstadoOrden())) {
			ordenAccionFiltro.setEstados(Arrays.asList(AccionesControlConstantes.COD_ESTADO_ORDEN_GENERADA, AccionesControlConstantes.COD_ESTADO_ORDEN_ENPROCESO));
		} else {
			ordenAccionFiltro.setCodEstadoOrden(filtro.getCodEstadoOrden());
		}
		ordenAccionFiltro.setNumProgramacion(filtro.getNumProgramacion());
		
		List<OrdenAccion> t10415OrdenAccion=t10415OrdenAccionDAO.listarOrden(ordenAccionFiltro);
		if (!MaestrosUtilidades.isEmpty(t10415OrdenAccion)) {
			OrdenAccionBean ordenAccionBean=null;
			for (OrdenAccion ordenAccion : t10415OrdenAccion) {
				ordenAccionBean=new OrdenAccionBean();
				MaestrosUtilidades.copiarValoresBean(ordenAccion, ordenAccionBean);
				ordenAccionBean.setFecAsigOrden(MaestrosUtilidades.dateToStringDDMMYYYY(ordenAccion.getFecAsigOrden()));
				WSPersonalIqbfBean auditor = servicioWebService.obtenerPersonalIqbf(ordenAccion.getCodPers());
				if (!MaestrosUtilidades.isEmpty(auditor)) {
					ordenAccionBean.setNomApelAuditor(auditor.getNomCompleto());
				}
	          	DataCatalogoBean catalogo = null;
	        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_ORDENES,ordenAccion.getCodTipoOrden());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					ordenAccionBean.setDesTipOrden(catalogo.getDescripcionDataCatalogo());
				}	
	
	        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_ORDEN,ordenAccion.getCodEstadoOrden());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					ordenAccionBean.setDesEstadoOrden(catalogo.getDescripcionDataCatalogo());
				}
	
	        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF,ordenAccion.getCodTipoDocumentoIdentif());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					ordenAccionBean.setDesTipoDocumentoIdent(catalogo.getDescripcionDataCatalogo());
				}
	
	        	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL, ordenAccion.getCodTipAccion());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					ordenAccionBean.setDesTipAccion(catalogo.getDescripcionDataCatalogo());
				}
	
	        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_RESULTADO_ORDEN, ordenAccion.getCodResulOrden());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					ordenAccionBean.setDesResulOrden(catalogo.getDescripcionDataCatalogo());
				}
				lista.add(ordenAccionBean);
			}
		}
		return lista;
	}
	
	@Override
	public OrdenAccionBean obtenerDatosOrden(Long numOrden){		
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numOrden", numOrden);

		OrdenAccionBean ordenAccionBean=null;
		List<OrdenAccion> t10415OrdenAccion= t10415OrdenAccionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10415OrdenAccion)) {
			OrdenAccion ordenAccion = t10415OrdenAccion.get(0);
			ordenAccionBean=new OrdenAccionBean();
			MaestrosUtilidades.copiarValoresBean(ordenAccion, ordenAccionBean);
			ordenAccionBean.setFecAsigOrden(MaestrosUtilidades.dateToStringDDMMYYYY(ordenAccion.getFecAsigOrden()));
			
          	DataCatalogoBean catalogo = null;
        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_ORDENES,ordenAccion.getCodTipoOrden());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				ordenAccionBean.setDesTipOrden(catalogo.getDescripcionDataCatalogo());
			}	
			
        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL,ordenAccion.getCodTipAccion());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				ordenAccionBean.setDesTipOrden(catalogo.getDescripcionDataCatalogo());
			}
			
        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_ORDEN,ordenAccion.getCodTipoOrden());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				ordenAccionBean.setDesTipOrden(catalogo.getDescripcionDataCatalogo());
			}
			ordenAccion.setDesSusCancela(ordenAccion.getDesSusCancela());
			// Archivo Bean
			ArchivoBean archivoBean = comunService.obtenerArchivo(ordenAccion.getNumArc());
			if (!MaestrosUtilidades.isEmpty(archivoBean)) {
				ordenAccionBean.setArchivoBean(archivoBean);
			}
		}
		return ordenAccionBean;
	}
	
	@Override
	public OrdenAccionBean obtenerArchivo(String numArc){
		OrdenAccionBean lista =new OrdenAccionBean();
		 ArchivoBean archivoBean = comunService.obtenerArchivo(Long.valueOf(numArc));
	        if (!MaestrosUtilidades.isEmpty(archivoBean)) {
	        	lista.setArchivoBean(archivoBean);
	        }
		return lista;
	}
	
	@Override
	public void eliminarDocumento(ArchivoBean archivoBean){
		ArchivoAcciones archivoAcciones=new ArchivoAcciones();
		archivoAcciones.setNumArc(archivoBean.getNumArc());
		archivoAcciones.setIndDel(AccionesControlConstantes.REGISTRO_ELIMINADO);
		// auditoria
		archivoAcciones.setDirIpusumodif(archivoBean.getAuditoriaBean().getNumIp());
		archivoAcciones.setCodUsuModif(archivoBean.getAuditoriaBean().getLogin());
		// auditoria
		t10445ArcAcfDAO.update(archivoAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
	}
	
	@Override
	public OrdenAccion actualizarOrden(OrdenAccionBean filtro){
	
		// INI Registrar archivo
        ArchivoBean archivoBean = filtro.getArchivoBean();
        Long numArc = null;
        if (!MaestrosUtilidades.isEmpty(archivoBean)) {
            archivoBean.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_INFORME_CANCELA_ORDEN);
            archivoBean.setNumArc(null);
            numArc = comunService.guardarArchivo(archivoBean, filtro.getAuditoriaBean());
        }
        // FIN Registrar archivo

		OrdenAccion ordenAccion= t10415OrdenAccionDAO.findById(filtro.getNumOrden(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		ordenAccion.setNumOrden(filtro.getNumOrden());
		ordenAccion.setDesSusCancela(filtro.getDesSusCancela());
		ordenAccion.setCodEstadoOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA);
		ordenAccion.setNumArc(numArc);
		
		t10415OrdenAccionDAO.update(ordenAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		return ordenAccion;
	}

	
}
