package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.io.File;
import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.transaction.Transactional;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperPrint;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoDataAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10406DocumentoAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10445ArcAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10446ArcDataAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSDomicilioRUCBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ClienteServiceRest;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class GenerarDocumentosBatchServiceImpl implements GenerarDocumentosBatchService{

	private static final Logger logger = LoggerFactory.getLogger(GenerarDocumentosBatchServiceImpl.class);
	
	@EJB 
	T10428UsuarioProgDAO t10428UsuarioProgDAO;
	
	@EJB 
	T10445ArcAcfDAO t10445ArcAcfDAO;
	
	@EJB
	T10446ArcDataAcfDAO t10446ArcDataAcfDAO;
	
	@EJB
	T10406DocumentoAccionDAO t10406DocumentoAccionDAO;

	@EJB
	T10420ProgramacionDAO t10420ProgramacionDAO;
	
	@EJB
	T8276CatProgCtrlDAO t8276CatProgCtrlDAO;

	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private ArchivoDigitalizadosService archivoDigitalizadosService;
	
	@Transactional
	@Override
	public ResponseBean<String> generarDocumentos(Long numProgramacion){

		if (logger.isWarnEnabled())
			logger.warn("Inicio GenerarDocumentosBatchServiceImpl - generarDocumentos");

		ResponseBean<String> respuesta = new ResponseBean<>();
		List<JasperPrint> listaJaspers = new ArrayList<JasperPrint>();
		UsuarioProgramacionBean params = new UsuarioProgramacionBean();

		Date fecha = new Date();
		Calendar dateCal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");	
		String rutaJasper = "";
		String numECM = ""; 
		
		Programacion programacion = t10420ProgramacionDAO.findById(numProgramacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		try{

			if(!MaestrosUtilidades.isEmpty(programacion)){
				
				//Getting Decade denomination 
				String nameDecenio = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_DENOMINACION_DECENIO,AccionesControlConstantes.COD_CATALOGO_DENOMINACION_DECENIO).getDescripcionDataCatalogo();

				//Getting year denomination
				String nameYear = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_DENOMINACION_AIO,AccionesControlConstantes.COD_CATALOGO_DENOMINACION_AIO).getDescripcionDataCatalogo();

				//Getting modifiable text per year
				String textoModificable = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_TEXTO_MODIFICABLE,AccionesControlConstantes.COD_CATALOGO_TEXTO_MODIFICABLE).getDescripcionDataCatalogo();

				//Getting annex number
				String anexTelefono = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_ANEXO_TELEFONICO,AccionesControlConstantes.COD_CATALOGO_TEXTO_MODIFICABLE).getDescripcionDataCatalogo();

				//Updating start process
				programacion.setCodEstadoPrograma(AccionesControlConstantes.COD_SUBESTADO_ENPROCESO_GENERACION_DOCUMENTOS);
				t10420ProgramacionDAO.update(programacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);

				//Loop user schedule
				params.setNumProgramacion(numProgramacion);
				params.setCodTipoAccionSugerida(AccionesControlConstantes.COD_ACCION_SUGERIDA_NOAPLICA);
				params.setCodSubEstadoProgram(AccionesControlConstantes.COD_SUBESTADO_PENDIENTE_GENERACION_DOCUMENTOS);
				List<UsuarioProgramacion> listUsers = t10428UsuarioProgDAO.listarUsuariosTipaccsuge(params);

				if(MaestrosUtilidades.isEmpty(listUsers)){
					respuesta.setExito(false);
					respuesta.setMensaje("No se encontraron usuarios relacionados a la programacion");
					logger.warn("Fin GenerarDocumentosBatchServiceImpl - generarDocumentos");
					
					//Updating process with error
					programacion.setCodEstadoPrograma(AccionesControlConstantes.COD_SUBESTADO_ERROR_ENPROCESO_GENERACION_DOCUMENTOS);
					t10420ProgramacionDAO.update(programacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					return respuesta;
				}
				for(UsuarioProgramacion user : listUsers){

					ProgramaControl programaControl = t8276CatProgCtrlDAO.findById(user.getCodProgctrl(), AccionesControlConstantes.DATASOURCE_DCSICOBF);

					//Getting the new sequence
					Long numDocAccion = t10406DocumentoAccionDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_DOCUMENTOS_ACCION, AccionesControlConstantes.DATASOURCE_DGSICOBF);

					//Getting the maximum value
					DocumentoAccionBean filtro = new DocumentoAccionBean();
					filtro.setAnnDoc(dateCal.get(Calendar.YEAR));
					filtro.setCodUnidadOrganica(MaestrosUtilidades.toBlank(programaControl.getCodUnidadOrganica()));
					filtro.setIndOrigen(AccionesControlConstantes.COD_IND_ORIGEN_DOCUMENTOACC_ELETRONICO);
					filtro.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
					int numCorrel = t10406DocumentoAccionDAO.maximoDocumentoEletronico(filtro);

					//Registering
					DocumentoAccion documentoAccion = new DocumentoAccion();
					documentoAccion.setNumDocumentoAccion(numDocAccion);
					documentoAccion.setNumUsuarioPrograma(user.getNumUsuarioPrograma());
					documentoAccion.setCodClase(AccionesControlConstantes.COD_CLASE_DOCUMENTO_ACCION);
					documentoAccion.setNumCorrelDoc(numCorrel);
					documentoAccion.setAnnDoc(dateCal.get(Calendar.YEAR));
					documentoAccion.setCodUuooDoc(MaestrosUtilidades.toBlank(programaControl.getCodUnidadOrganica()));
					documentoAccion.setCodEstadoDocumento(AccionesControlConstantes.COD_ESTADO_DOCACCION_GENERADO);
					documentoAccion.setFecEmision(fecha);
					documentoAccion.setNumArc(0L);
					//Auditory parameters
					documentoAccion.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					documentoAccion.setFecCrea(fecha);
					documentoAccion.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					t10406DocumentoAccionDAO.save(documentoAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					
					//Getting fiscal address
					WSDomicilioRUCBean regBeanDomicilio = servicioWebService.obtenerDomicilioFiscal(user.getNumDocumentoIdentif());

					Map<String, Object> parametros = new HashMap<String, Object>();
					parametros.put("P_IMAGEN", AccionesControlConstantes.RUTA_LOGO_REPORTE);
					parametros.put("P_NOMBRE_DECENIO", AccionesControlUtil.toBlank(nameDecenio));
					parametros.put("P_NOMBRE_ANIO", AccionesControlUtil.toBlank(nameYear));
					parametros.put("P_NUMERO_CARTA", numCorrel);
					parametros.put("P_ANIO_CARTA", dateCal.get(Calendar.YEAR));
					parametros.put("P_NOMBRE_RAZON", user.getNomApellidoUsuario());
					parametros.put("P_RUC", user.getNumDocumentoIdentif());
					parametros.put("P_FECHA", dateFormat.format(user.getFecCrea()));
					parametros.put("P_DOMICILIO", regBeanDomicilio.getDireccion());
					parametros.put("P_DEPARTAMENTO", regBeanDomicilio.getDescDepar());
					parametros.put("P_PROVINCIA", regBeanDomicilio.getDescProvi());
					parametros.put("P_DISTRITO", regBeanDomicilio.getDescDistr());
					
					switch (user.getCodProgctrl()) {

						//Getting phone annex
						case AccionesControlConstantes.COD_TIP_PROG_OMISOS_DJ:
							parametros.put("P_RESOLAPRANIO", AccionesControlUtil.toBlank(textoModificable));
							parametros.put("P_PERMINOMISO",AccionesControlUtil.toBlank(user.getNumPeridoomisomin()));
							parametros.put("P_PERMAXOMISO",AccionesControlUtil.toBlank(user.getNumPeridoomisomax()));
							parametros.put("P_ANEXO",AccionesControlUtil.toBlank(anexTelefono));
							rutaJasper = AccionesControlConstantes.COD_REPORTE_JASPER_PLANTILLA000926;
							break;
		
						case AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_DESTINATARIO:
						case AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_TRANSPORTISTA:
							parametros.put("P_PERIODOINI", dateFormat.format(programacion.getPerInicio()));
							parametros.put("P_PERIODOFIN", dateFormat.format(programacion.getPerFin()));

							String diasHabiles = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_DIAS_HABILES,AccionesControlConstantes.COD_CATALOGO_TEXTO_MODIFICABLE).getDescripcionDataCatalogo();
							parametros.put("P_DIASHABILES", AccionesControlUtil.toBlank(diasHabiles));

							String link = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_REPORTE_SEMAFORO,AccionesControlConstantes.COD_CATALOGO_TEXTO_MODIFICABLE).getDescripcionDataCatalogo();
							parametros.put("P_LINK", AccionesControlUtil.toBlank(link));

							if(user.getCodProgctrl().equals(AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_DESTINATARIO)){
								rutaJasper = AccionesControlConstantes.COD_REPORTE_JASPER_PLANTILLA000927;
							}else{
								rutaJasper = AccionesControlConstantes.COD_REPORTE_JASPER_PLANTILLA000928;
							}
							break;
		
						case AccionesControlConstantes.COD_TIP_PROG_USU_VIGENTES_STOCK_SALDO_NEGATIVO:
							String operacion = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_REPORTE_REGISTRO_CONTROL_BIEN,AccionesControlConstantes.COD_CATALOGO_TEXTO_MODIFICABLE).getDescripcionDataCatalogo();
							parametros.put("P_OPERACION", AccionesControlUtil.toBlank(operacion));
							
							String saldo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_REPORTE_SALDO_DISPONIBLE,AccionesControlConstantes.COD_CATALOGO_TEXTO_MODIFICABLE).getDescripcionDataCatalogo();
							parametros.put("P_SALDO", AccionesControlUtil.toBlank(saldo));
							
							String stock = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_REPORTE_STOCK_MENSUAL,AccionesControlConstantes.COD_CATALOGO_TEXTO_MODIFICABLE).getDescripcionDataCatalogo();
							parametros.put("P_STOCK", AccionesControlUtil.toBlank(stock));
							rutaJasper = AccionesControlConstantes.COD_REPORTE_JASPER_PLANTILLA000929;
							break;
						
						case AccionesControlConstantes.COD_TIP_PROG_USU_BAJA_STOCK:
							parametros.put("P_FECHABAJA", dateFormat.format(user.getFecFinVigencia()));
							parametros.put("P_PERIODMINOMISO",AccionesControlUtil.toBlank(user.getNumPeridoomisomin()));
							parametros.put("P_PERIODMAXOMISO",AccionesControlUtil.toBlank(user.getNumPeridoomisomax()));
							parametros.put("P_ANEXO",AccionesControlUtil.toBlank(anexTelefono));
							rutaJasper = AccionesControlConstantes.COD_REPORTE_JASPER_PLANTILLA000930;
							break;
					}
					//Generating holographic sign
					File firma = archivoDigitalizadosService.obtenerFirmaConNombrePorPersona(user.getCodPers());
					if(firma!=null) {
						parametros.put("FIRMA",firma.getAbsolutePath());
					}else{
						parametros.put("FIRMA","");
					}

					JasperPrint jasperPrint = archivoDigitalizadosService.generarBytePlantillaJasper(parametros, rutaJasper, new JREmptyDataSource());
					listaJaspers.add(jasperPrint);
					byte[] byteReporte = archivoDigitalizadosService.convertirJasperPrintByte(listaJaspers);

					//Registering the file pdf
					Long secNumArc = t10445ArcAcfDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ARCHIVOS_ACCIONES, AccionesControlConstantes.DATASOURCE_DGSICOBF);

					String nombreArchivo = String.format("%6d", numCorrel) + 
										   MaestrosUtilidades.toStr(dateCal.get(Calendar.YEAR) + "-SUNAT/" + 
										   programaControl.getCodUnidadOrganica());

					////
					Map<String, Object> mapParam = new HashMap<String, Object>();
					mapParam.put("codTipoDoc", "02");
					mapParam.put("fechaDocumento",fecha);
					mapParam.put("numRuc",user.getNumDocumentoIdentif());
					mapParam.put("codTipoProc","codTipoProc");
					mapParam.put("numDocumentoSine",nombreArchivo);
					mapParam.put("UsuarioBean",new AuditoriaBean());
					mapParam.put("numArcCali",MaestrosUtilidades.toLong(numCorrel));
					mapParam.put("nomArchivo", nombreArchivo.concat("pdf"));
					mapParam.put("byteArchivo", byteReporte);
					
					logger.warn("mapParam GenerarDocumentosBatchServiceImpl - ClienteServiceRest.enviarPeticionPOST: " + mapParam);
					ResponseBean<String> rpta = ClienteServiceRest.enviarPeticionPOST("http://localhost:7003/ol-iq-ianotificacion-calificacion-ws/documentoECM/generarDocumentos", mapParam);
					logger.warn("rpta GenerarDocumentosBatchServiceImpl - ClienteServiceRest.enviarPeticionPOST: " + rpta);
					
					if (rpta.isExito()) {
						Map<String, Object> map = MaestrosUtilidades.jsonToObject(rpta.getData(), Map.class);
						numECM = map.get("numIdEcm").toString();
					}
					
					ArchivoAcciones archivoAcciones = new ArchivoAcciones();
					archivoAcciones.setNumArc(secNumArc);
					archivoAcciones.setCodTipoArchivo(AccionesControlConstantes.COD_TIPO_ARCHIVO_DOCUMENTOS_ACCION_PRINCIPAL);
					archivoAcciones.setNombArchivoAcciones(nombreArchivo.concat(".pdf"));
					archivoAcciones.setDesMimeType(AccionesControlConstantes.DESCRIPCION_MIME_TYPE_PDF);
					archivoAcciones.setCntPesoArc(MaestrosUtilidades.toDouble(byteReporte.length));
					archivoAcciones.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					archivoAcciones.setFecCrea(fecha);
					archivoAcciones.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					archivoAcciones.setNumEcm(numECM);
					archivoAcciones.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
					archivoAcciones.setIndEst(AccionesControlConstantes.REGISTRO_ACTIVO);
					t10445ArcAcfDAO.save(archivoAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					
					//Registering the file detail
					ArchivoDataAcciones archivoDataAcciones = new ArchivoDataAcciones();
					archivoDataAcciones.setNumArchAcciones(secNumArc);
					archivoDataAcciones.setArchivoContenido(byteReporte);
					archivoDataAcciones.setDirIpusucrea(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					archivoDataAcciones.setFecCrea(fecha);
					archivoDataAcciones.setCodUsuCrea(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
					t10446ArcDataAcfDAO.save(archivoDataAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);

				}
				//Updating process without error
				programacion.setCodEstadoPrograma(AccionesControlConstantes.COD_SUBESTADO_PENDIENTE_PROCESO_NOTIFICACION);
				t10420ProgramacionDAO.update(programacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				
				respuesta.setExito(true);
				respuesta.setMensaje("OK");
				logger.warn("Fin GenerarDocumentosBatchServiceImpl - generarDocumentos");
			}else {
				respuesta.setExito(false);
				respuesta.setMensaje("El n�mero de programaci�n no existe");
				logger.warn("GenerarDocumentosBatchServiceImpl - generarDocumentos: El n�mero de programaci�n no existe");
			}
			
		}catch(Exception e){
			//Updating process with error
			programacion.setCodEstadoPrograma(AccionesControlConstantes.COD_SUBESTADO_ERROR_ENPROCESO_GENERACION_DOCUMENTOS);
			t10420ProgramacionDAO.update(programacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			respuesta.setExito(false);
			respuesta.setMensaje("Error en el proceso: " + e.getMessage());
			logger.warn("GenerarDocumentosBatchServiceImpl - generarDocumentos: " + e.getMessage());
		}
		return respuesta;
	}
}
