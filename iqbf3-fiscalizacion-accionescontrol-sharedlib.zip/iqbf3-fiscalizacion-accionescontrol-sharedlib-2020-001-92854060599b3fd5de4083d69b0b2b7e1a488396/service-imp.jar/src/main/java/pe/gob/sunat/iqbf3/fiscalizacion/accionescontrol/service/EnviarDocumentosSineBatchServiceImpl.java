package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10406DocumentoAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSUnidadOrgBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class EnviarDocumentosSineBatchServiceImpl implements EnviarDocumentosSineBatchService{
	//CUS26
	
	private static final Logger logger = LoggerFactory.getLogger(EnviarDocumentosSineBatchServiceImpl.class);
	
	@EJB
	private T10406DocumentoAccionDAO t10406DocumentoAccionDAO; 
	
	@EJB
	private ServicioWebService servicioWebService;
	
	public ResponseBean<String> enviarDocumentoSine(){
		if (logger.isWarnEnabled())
			logger.warn("Inicio EnviarDocumentosSineBatchServiceImpl - enviarDocumentoSine");
		ResponseBean<String> respuesta = new ResponseBean<>();
		
		PropertyParams propertyParams = new PropertyParams();
		
		propertyParams.addProperty("codEstadoDocumento", AccionesControlConstantes.COD_ESTADO_DOCACCION_GENERADO);
		propertyParams.addProperty("indOrigen", AccionesControlConstantes.COD_IND_ORIGEN_DOCUMENTOACC_ELETRONICO);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);

		List<DocumentoAccion> lstDocumAccion = t10406DocumentoAccionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		if (!MaestrosUtilidades.isEmpty(lstDocumAccion)){
			for (DocumentoAccion docuAccion: lstDocumAccion){
       		  if (!MaestrosUtilidades.isEmpty(docuAccion.getCodUuooDoc())) {
					
				WSUnidadOrgBean unidOrga = servicioWebService.obtenerDatosUUOO(docuAccion.getCodUuooDoc());
				
				//listDocumento.CodTipoDoc
				docuAccion.getCodTipoDocumento();
				
				//listDocumento.fecEmision
				docuAccion.getFecEmision();
				
				//listDocumento.numDocIdent
				docuAccion.getNumDocumento();
				
				//listDocumento.desUUOO 
				String descUo = ""; 
				if (!MaestrosUtilidades.isEmpty(unidOrga)) {
					descUo = unidOrga.getDesUorga();		
				}
						
				//listDocumento.nroRegistro = constantes.COD_CATALOGO_GERENTE_IQBF
				String nroRegistro = MaestrosConstantes.COD_CATALOGO_GERENTE_IQBF;
				
				//listDocumento.codUUOO
				docuAccion.getCodUuooDoc();
				
				//listDocumento.numArc
				docuAccion.getNumArc();
				
				//numIdDoc
				docuAccion.getNumIdDoc();
				
				
				/** Notificar a servicio registrar ECM */
				//El n�mero de pedido a la acci�n.
				//El estado de la acci�n se actualiza a �Pendiente de notificaci�n�
				Map<String, Object>  param = new HashMap<String, Object>();
				
				param.put("nroRegistro", nroRegistro);
				param.put("codUuooDoc", docuAccion.getCodUuooDoc());
				param.put("nomCompleto", "");
				param.put("numIdDoc", docuAccion.getNumIdDoc());
				
				Map<String, Object> result= servicioWebService.registrarPedidoNotificacionSINE(param);
				
				
				if (!MaestrosUtilidades.isEmpty(result)) {
					String numPedido = (String) result.get("numPedido"); // invocar al servicio de Notificar ECM
					logger.warn("numPedido => " + numPedido);
					docuAccion.setNumPedido(numPedido);// Adicionar numero de pedido de service
					docuAccion.setCodEstadoDocumento(AccionesControlConstantes.COD_ESTADO_DOCACCION_PENDIENTENOTIF);
					docuAccion.setFecModif(new Date());
					docuAccion.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
					docuAccion.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
	
					t10406DocumentoAccionDAO.update(docuAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			 }
			}
		}

		
		if (logger.isDebugEnabled())
			logger.debug("Fin EnviarDocumentosSineBatchServiceImpl - enviarDocumentoSine");
		
		return respuesta;
	}
}
