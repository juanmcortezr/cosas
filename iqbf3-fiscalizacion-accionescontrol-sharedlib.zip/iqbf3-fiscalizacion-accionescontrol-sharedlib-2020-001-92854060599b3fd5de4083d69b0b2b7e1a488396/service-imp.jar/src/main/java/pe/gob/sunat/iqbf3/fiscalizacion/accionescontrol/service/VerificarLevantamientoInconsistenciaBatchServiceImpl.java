package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ConfirmacionGreBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DeclaracionesJuradasBfBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenSaldoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenStockEstablecBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ConfirmacionGre;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DeclaracionesJuradasBf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaGreNC;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaSaldo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaStock;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenSaldo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenStockEstablec;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10417ProIncoGreNCDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10418ProIncoSaldoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10419ProIncoStockDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5257ConfirDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5284BfCabJroDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5641RStockEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5642RSaldoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.service.RegistroBfService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class VerificarLevantamientoInconsistenciaBatchServiceImpl implements VerificarLevantamientoInconsistenciaBatchService{
	//CUS28, cus32
	
	private static final Logger logger = LoggerFactory.getLogger(VerificarLevantamientoInconsistenciaBatchServiceImpl.class);
	
	@EJB
	private T10415OrdenAccionDAO t10415OrdenAccionDAO;
	
	@EJB
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;
	
	@EJB
	private T5284BfCabJroDAO t5284BfCabJroDAO;
	
	@EJB
	private RegistroBfService registroBfService;
	
	@EJB
	private T10419ProIncoStockDAO t10419ProIncoStockDAO;
	
	@EJB
	private T10418ProIncoSaldoDAO t10418ProIncoSaldoDao; 
	
	@EJB
	private T5641RStockEstabDAO t5641RStockEstabDAO;
	
	@EJB
	private T5642RSaldoDAO t5642RSaldoDAO;
	
	@EJB
	private T10417ProIncoGreNCDAO t10417ProIncoGreNCDAO;
	
	@EJB
	private T5257ConfirDAO t5257ConfirDAO;
	
	public ResponseBean<String> iniciarProcesamiento(Long numProgramacion){
		if (logger.isWarnEnabled())
			logger.warn("Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - iniciarProcesamiento");
		
	 ResponseBean<String> respuesta = new ResponseBean<>();

	 Date fechaActual = new Date();
	 
	 OrdenAccion ordenAccionFiltro=new OrdenAccion();
	 ordenAccionFiltro.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_GENERADA);
	 ordenAccionFiltro.setCodProgCtrl(AccionesControlConstantes.COD_TIP_PROG_OTROS);
	 ordenAccionFiltro.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
	 ordenAccionFiltro.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		
	 List<OrdenAccion> listOrdenGenerada = t10415OrdenAccionDAO.listarOrdenGenerada(ordenAccionFiltro);
	 
	 logger.warn("listOrdenGenerada: tamanio ==>" + listOrdenGenerada.size());
	 
	 //Calcular la fecha de vencimiento y Realizar la verificaci�n de inconsistencia del usuario seg�n el programa de control al que corresponde la orden.

	 //Verifica la fecha de fin de subsanaci�n para identificar si ha vencido el plazo de la subsanaci�n  
	 
	   if (!MaestrosUtilidades.isEmpty(listOrdenGenerada)){
		 for(OrdenAccion ordenGenerada: listOrdenGenerada){
			 if (MaestrosUtilidades.fechaMenor(ordenGenerada.getFecFinSubsanacion(), fechaActual)){
				 //Procede a realizar la verificaci�n de la inconsistencia para el usuario asociado al documento de acci�n.
				 
				 logger.warn("ordenGenerada.getCodProgctrl() ==>" + ordenGenerada.getCodProgctrl());
				 
	    		if(AccionesControlConstantes.COD_TIP_PROG_OMISOS_DJ.equals(ordenGenerada.getCodProgctrl())){
					verificarInconsistenciaProgramaControlOmisosDj(ordenGenerada);
				}
				if(AccionesControlConstantes.COD_TIP_PROG_USU_VIGENTES_STOCK_SALDO_NEGATIVO.equals(ordenGenerada.getCodProgctrl())){
					verificarInconsistenciaProgramaStockSaldoNegativo(ordenGenerada);
				}
				if(AccionesControlConstantes.COD_TIP_PROG_USU_BAJA_STOCK.equals(ordenGenerada.getCodProgctrl())){
					verificarInconsistenciaProgramaControlBajaOmisoStockNegativo(ordenGenerada);
				}
				if(AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_DESTINATARIO.equals(ordenGenerada.getCodProgctrl())){
					verificarInconsisProgramaControlGreNoConfirmadasDestinatario(ordenGenerada);
				}
				if(AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_TRANSPORTISTA.equals(ordenGenerada.getCodProgctrl())){
					verificarInconsisProgramaControlGreNoConfirmadasTransportista(ordenGenerada);
				}
		     }
	     }
	   }
	 respuesta.setExito(true);
	 
	 if (logger.isDebugEnabled())
		logger.debug("Fin VerificarLevantamientoInconsistenciaBatchServiceImpl - iniciarProcesamiento");
	 
	 return respuesta;
	}
	
	private int verificarGreConfirmada (ProgramaIncosistenciaGreNC programaIncosistenciaGreNC,
										OrdenAccion ordenGenerada,
										String codTipo){
		if (logger.isWarnEnabled())
			logger.warn("Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarGreConfirmada");
		
		int cntGRE = 0;
		
		ConfirmacionGreBean confirmacionGreBean  = new ConfirmacionGreBean();
		confirmacionGreBean.setNumRuc(Integer.parseInt(programaIncosistenciaGreNC.getNumRuc()));
		confirmacionGreBean.setCodCpe(Integer.parseInt(programaIncosistenciaGreNC.getCodCpe()));
		confirmacionGreBean.setNumSerieCpe(Integer.parseInt(programaIncosistenciaGreNC.getNumSerieCpe()));
		confirmacionGreBean.setNumCpe(programaIncosistenciaGreNC.getNumCpe());
		confirmacionGreBean.setNumRucConfirmacion(ordenGenerada.getNumDocumentoIdentif());
		confirmacionGreBean.setCodTipo(codTipo);
		
		List<ConfirmacionGre>  lstConfirmacionGre =  t5257ConfirDAO.verificarGreConfirmada(confirmacionGreBean);
		 
		if(!lstConfirmacionGre.isEmpty()){
			cntGRE = lstConfirmacionGre.get(0).getCantidad().intValue();
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarGreConfirmada");
		
    	return cntGRE;
	}
	
	
	public boolean actualizarResultadoOrden(OrdenAccion ordenGenerada){
	  if (logger.isWarnEnabled())
		logger.warn("Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - actualizarResultadoOrden");
	  
	  boolean vExito = false;
	  
	  try{
	  
		  OrdenAccion ordAccionUpd = t10415OrdenAccionDAO.findById(ordenGenerada.getNumOrden(), AccionesControlConstantes.DATASOURCE_DCSICOBF);

		  //Si (tipoVerificacionIncons = constantes.COD_TIPO_EJECUCION_VERIFICACION_MANUAL)
		  if (!MaestrosUtilidades.isEmpty(ordAccionUpd.getCodResultadoInconsistenciaDef())){
			  ordAccionUpd.setCodResultadoInconsistenciaDef(ordAccionUpd.getCodResultadoInconsistenciaDef());
		  }else{
			  ordAccionUpd.setCodResultadoInconsistenciaPre(ordenGenerada.getCodResultadoInconsistenciaPre());
			  ordAccionUpd.setCodResulOrden(ordenGenerada.getCodResulOrden());
			  ordAccionUpd.setCodEstadoOrden(ordenGenerada.getCodEstadoOrden());
		  }
		  ordAccionUpd.setFecModif(new Date());
		  ordAccionUpd.setDirIpusumodif(AccionesControlConstantes.CONS_IP_USR_CREACION_MODIFICACION_BATCH);
		  ordAccionUpd.setCodUsuModif(AccionesControlConstantes.CONS_USR_CREACION_MODIFICACION_BATCH);
		  
		  t10415OrdenAccionDAO.update(ordAccionUpd, AccionesControlConstantes.DATASOURCE_DGSICOBF);
	  
	    vExito = true;
	  
	  }catch(Exception e){
		  vExito = false;
	  }
	  
	  if (logger.isDebugEnabled())
		logger.debug("Fin VerificarLevantamientoInconsistenciaBatchServiceImpl - actualizarResultadoOrden");
	  
	  return vExito;
	}
	
	public void verificarInconsistenciaProgramaControlOmisosDj(OrdenAccion ordenGenerada){
		if (logger.isWarnEnabled())
			logger.warn(
					"Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsistenciaProgramaControlOmisosDj");
		
		
		UsuarioProgramacion usuarioProgramacionBean;
		OrdenAccion ordnAccUpd = new OrdenAccion();
		ordnAccUpd.setNumOrden(ordenGenerada.getNumOrden());
		
		usuarioProgramacionBean = t10428UsuarioProgDAO.findById(ordenGenerada.getNumUsuarioPrograma(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		//Obtener los periodos actuales omisos del usuario:
		DeclaracionesJuradasBfBean declaracionesJuradasBfBean = new DeclaracionesJuradasBfBean();
		
		declaracionesJuradasBfBean.setCodEstado(AccionesControlConstantes.COD_ESTADO_DJROP_PENDIENTE);
		declaracionesJuradasBfBean.setNumConfirma(AccionesControlConstantes.NUM_CONFIRMACION_SIN_ENVIO);
		List<String> lstCodEstadoUsuario = new ArrayList<>();
		lstCodEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);
		lstCodEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);
		declaracionesJuradasBfBean.setLstEstadoBfRegistro(lstCodEstadoUsuario);
		declaracionesJuradasBfBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		declaracionesJuradasBfBean.setIndOmiso(AccionesControlConstantes.COD_ESTADO_DJROP_EXONERADO_DEL_MES);
		declaracionesJuradasBfBean.setNumVersionRegistro(usuarioProgramacionBean.getNumVersionRegistro());
		declaracionesJuradasBfBean.setNumRuc(Integer.parseInt(usuarioProgramacionBean.getNumDocumentoIdentif()));
		
		List<DeclaracionesJuradasBf>  lstUsuarioOmisoBean = t5284BfCabJroDAO.periodosOmisosPorUsuario(declaracionesJuradasBfBean);
		
		DeclaracionesJuradasBf usuarioOmisoBean = new DeclaracionesJuradasBf();
		
		if (!MaestrosUtilidades.isEmpty(lstUsuarioOmisoBean)){
			usuarioOmisoBean = lstUsuarioOmisoBean.get(0);
		}
	
	//Verificar si los periodos del usuarioProgramacionBean  en encuentra en usuarioOmisoBean
		List<String> lstPeriodosDesagredadosUsrProgr = desagregarPeriodo(usuarioProgramacionBean.getNumPeridoomisomin(), usuarioProgramacionBean.getNumPeridoomisomax());
		List<String> lstPeriodosDesagredadosUsrOmiso = desagregarPeriodo(usuarioOmisoBean.getMinPeriodo(), usuarioOmisoBean.getMaxPeriodo());
	//-	Verificar periodo por periodo del usuario para determinar el tipo de resultado de inconsistencia:
		Integer cantPeriUsrProg = lstPeriodosDesagredadosUsrProgr.size();

		boolean bExitePeriodo;
		int periEncontradosEnOmiso = 0;
		if (!MaestrosUtilidades.isEmpty(lstPeriodosDesagredadosUsrProgr) &&
			!MaestrosUtilidades.isEmpty(lstPeriodosDesagredadosUsrOmiso)
		   ){
			for(String perUsrProgr : lstPeriodosDesagredadosUsrProgr){
				bExitePeriodo = false;
				for(String perUsrOmiso : lstPeriodosDesagredadosUsrOmiso){
					if (perUsrOmiso.equals(perUsrProgr)){
						bExitePeriodo = true;
					}
				}
				
				if(bExitePeriodo){
					periEncontradosEnOmiso++;
				}
			}
		}
		
	//	Si todos los periodos del usuario existe en el rango del periodo usuarioOmisoBean:
		if(cantPeriUsrProg == periEncontradosEnOmiso ){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_NO_SUBSANO);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}

	//	Si al menos un periodo del usuario se encuentra en el rango de periodos usuarioOmisoBean
		if(periEncontradosEnOmiso>0){
		ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
		ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
		ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}

    //	Si ning�n periodo del usuario se encuentra usuario se encuentra en el rango de periodos   usuarioOmisoBean.
		if(periEncontradosEnOmiso==0){
		ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANO);
		ordnAccUpd.setCodResultadoInconsistenciaDef(AccionesControlConstantes.COD_INCON_SUBSANO);// aalanya solo esta en esta condicion
		ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_CONFORME);
		ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		}
		
		actualizarResultadoOrden(ordnAccUpd);
		
		
		if (logger.isDebugEnabled())
			logger.debug(
					"Fin VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsistenciaProgramaControlOmisosDj");
		
	}
	
	
	public void verificarInconsistenciaProgramaStockSaldoNegativo(OrdenAccion ordenGenerada){
		if (logger.isWarnEnabled())
			logger.warn(
					"Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsistenciaProgramaStockSaldoNegativo");
		
		PropertyParams propertyParams;
		ResumenStockEstablecBean resumenStockEstablecBean;
		List<String> lstEstadoUsuario;
		List<String> lstEstadoRegistros;
		ResumenSaldoBean resumenSaldoBean;
		
		Integer cntInconsistenciasSaldo = 0;
		Integer cntStockNegativo = 0;
		Integer cntInconsistenciaStockNoSubsanada = 0;
		Integer cntInconsistenciasStock = 0;
		Integer cntInconsistenciaStockSubsanada = 0;
		Integer cntInconsistenciaStock = 0;
		Integer cntInconsistencaSaldo = 0;
		Integer cntSaldoNegativo = 0;
		Integer cntInconsistenciaSaldoSubsanada = 0;
		Integer cntInconsistenciaSaldoNoSubsanada = 0;
		
		OrdenAccion ordnAccUpd = new OrdenAccion();
		ordnAccUpd.setNumOrden(ordenGenerada.getNumOrden());
		/*
		-	Par�metro de entrada:
		
			numeroDocumentoIdentidad = listordenGenerada.numeroDocumentoIdentidad
			tipoDocumentoIdentidad  = listordenGenerada.tipoDocumentoIdentidad 
			numUsuProgram  = listordenGenerada.numUsuProgram
		
		   //Obtener las inconsistencias determinadas (registradas en el m�dulo de acciones de control) 
		   //de stock y saldo negativo de un usuario y almacenarlo en una lista 
		   //�listaInconsistenciaStock�  y �listaInconsistenciaSaldo�
			T10419proincostockDAO.listarInconsistenciaStock(numUsuProgram)
			T10418proincosaldoDAO.listarInconsistenciaSaldo(numUsuProgram)
		*/
		propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioPrograma", ordenGenerada.getNumUsuarioPrograma());
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		List<ProgramaIncosistenciaStock>  listaInconsistenciaStock = t10419ProIncoStockDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);

		List<ProgramaIncosistenciaSaldo>  listaInconsistenciaSaldo = t10418ProIncoSaldoDao.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		cntInconsistenciaStock = listaInconsistenciaStock.size();
		cntInconsistencaSaldo =  listaInconsistenciaSaldo.size();

		
		if (!MaestrosUtilidades.isEmpty(listaInconsistenciaStock)){
			for(ProgramaIncosistenciaStock blistarInconsistenciaStock : listaInconsistenciaStock){
		
			//Recorre la lista  listaInconsistenciaStock y verificar si se mantiene o no la inconsistencia:
			
			// Para stock Negativo
			
			resumenStockEstablecBean = new ResumenStockEstablecBean();
			resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_IND_CONDICION_ITEM_REGISTRO);//COD_ESTADO_ITEM_REGISTRO
			lstEstadoUsuario = new ArrayList<>();
			lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
			lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
			resumenStockEstablecBean.setLstEstadoUsuarios(lstEstadoUsuario);
			resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
			resumenStockEstablecBean.setNumRuc(Integer.parseInt(ordenGenerada.getNumDocumentoIdentif()));
			resumenStockEstablecBean.setNumEstablecimiento(String.valueOf(blistarInconsistenciaStock.getNumEstablecimiento()));
			resumenStockEstablecBean.setNumPresentacion(blistarInconsistenciaStock.getNumPresentacion());
			
			List<ResumenStockEstablec> listInconsistenciasActualStock = t5641RStockEstabDAO.cntStockNegativoVerificacion(resumenStockEstablecBean);
			//listarStockNegativo  estaba antes
			//cntStockNegativoVerificacion		
	
			if (!MaestrosUtilidades.isEmpty(listInconsistenciasActualStock)){
				cntStockNegativo = listInconsistenciasActualStock.get(0).getCntStockNegativoVerificacion().intValue();
			}
			
			//Crear las variables cntInconsistenciasStock , cntInconsistenciaStockSubsanada, cntInconsistenciaStockNoSubsanada de tipo integer 
			if (cntStockNegativo  == 0){
				cntInconsistenciaStockSubsanada++;
			}else{
				cntInconsistenciaStockNoSubsanada++;
			}
		  }
		}

		//Determinar el tipo de subsanaci�n para el stock negativo 
        // no ha subanado ninguna 
        if (cntStockNegativo == cntInconsistenciaStockNoSubsanada){
        	cntInconsistenciasStock  = 1; 
        }
        
        // permanece al menos una inconsistencia
        if( cntStockNegativo < cntInconsistenciaStockSubsanada){
              cntInconsistenciasStock  = 2;
        }
        
        //ha subsanado todas las inconsistencia
   		if(cntStockNegativo == cntInconsistenciaStockSubsanada){
              cntInconsistenciasStock  = 0;
   		}
		
		
		if (!MaestrosUtilidades.isEmpty(listaInconsistenciaSaldo)){
			for(ProgramaIncosistenciaSaldo blistaInconsistenciaSaldo : listaInconsistenciaSaldo)
			{
			/*
			// Para saldo Negativo
		
				Par�metros (ParamSaldo)
				ind_del = Constantes.REGISTRO_NO_ELIMINADO
				num_reposicion= Constantes.NUM_ULTIMA_REPOSICION 
				cod_estado_item = Constantes.COD_IND_CONDICION_ITEM_REGISTRO
				List_codestado_registro = constantes. COD_ESTADO_REGISTRO_VIGENTE, constantes. COD_ESTADO_REGISTRO_SUSPENDIDO
				ind_condicion = constantes. IND_CONDICION_ITEM_REGISTRO  
				numRuc = numeroDocumentoIdentidad  
				num_inscab = listaInconsistenciaSaldo.numInscab  
			*/
				resumenSaldoBean = new ResumenSaldoBean();
				resumenSaldoBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				resumenSaldoBean.setNumReposicion(AccionesControlConstantes.NUM_ULTIMA_REPOSICION);
				resumenSaldoBean.setCodEstadoItem(AccionesControlConstantes.COD_IND_CONDICION_ITEM_REGISTRO);
				lstEstadoRegistros = new ArrayList<>();
				lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
				lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
				resumenSaldoBean.setLstEstadoRegistros(lstEstadoRegistros);
				resumenSaldoBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
				resumenSaldoBean.setNumRuc(Integer.parseInt(ordenGenerada.getNumDocumentoIdentif()));
				resumenSaldoBean.setNumInsumoCabecera(blistaInconsistenciaSaldo.getNumInsumoCabecera());
				
				List<ResumenSaldo>  listaInconsistenciaActualSaldo = t5642RSaldoDAO.cntSaldoNegativo(resumenSaldoBean);
				//listarSaldoNegativo
				if (!MaestrosUtilidades.isEmpty(listaInconsistenciaActualSaldo)){
					cntSaldoNegativo = listaInconsistenciaActualSaldo.get(0).getCntSaldoNegativo().intValue();
				}
				
				if(cntSaldoNegativo == 0){
					cntInconsistenciaSaldoSubsanada++;
				}else{
					cntInconsistenciaSaldoNoSubsanada++;
				}
			}
		}
		//Determinar el tipo de subsanaci�n para el saldo negativo 
		// no ha subanado ninguna
		if (cntSaldoNegativo == cntInconsistenciaSaldoNoSubsanada){
			cntInconsistenciasSaldo = 1; 
        }
		 // permanece al menos una inconsistencia
		if(cntSaldoNegativo < cntInconsistenciaSaldoSubsanada){
              cntInconsistenciasSaldo  = 2;
		}
		//ha subsanado todas las inconsistencia
		if(cntSaldoNegativo == cntInconsistenciaSaldoSubsanada){
              cntInconsistenciasSaldo = 0;
		}
		
		//Determinar si el tipo de resultado de inconsistencias seg�n la cantidad de inconsistencias 
		if(cntInconsistenciasStock == 0 &&  cntInconsistenciasSaldo == 0){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANO);
			ordnAccUpd.setCodResultadoInconsistenciaDef(AccionesControlConstantes.COD_INCON_SUBSANO);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		}
		
		//-	Si (cntInconsistenciasStock  = 0 &&  cntInconsistenciasSaldo   > 0) 
		if(cntInconsistenciasStock  == 0 &&  cntInconsistenciasSaldo   > 0){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}
	
		//-	Si (cntInconsistenciasStock  > 0 && cntInconsistenciasSaldo= 0)
		if(cntInconsistenciasStock  > 0 && cntInconsistenciasSaldo == 0){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}
	    
		//-	Si (cntInconsistenciasStock  > 0 && cntInconsistenciasSaldo> 0)
		if(cntInconsistenciasStock  > 0 && cntInconsistenciasSaldo == 0){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}
	
		//-	Si (cntInconsistenciasStock =  1 && cntInconsistenciasSaldo = 1)
		if(cntInconsistenciasStock  ==1 && cntInconsistenciasSaldo == 1){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_NO_SUBSANO);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}
	
 	 actualizarResultadoOrden(ordnAccUpd);
 	 
 	 if (logger.isDebugEnabled())
		logger.debug(
				"Fin VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsistenciaProgramaStockSaldoNegativo");
	}
	
	
	public void verificarInconsistenciaProgramaControlBajaOmisoStockNegativo(OrdenAccion ordenGenerada){
		if (logger.isWarnEnabled())
			logger.warn(
					"Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsistenciaProgramaControlBajaOmisoStockNegativo");
	 Integer cntStockNegativoBaja = 0;
	 Integer cntStockNegativoNoSubsanado = 0;
	 Integer cntStockNegativoSubsanado = 0;
	 Integer cntInconsistenciasBajaStock = 0;
	 Integer cntInconsistenciasBajaOmiso = 0;
	 Integer cntPeriodosOmisos = 0;
	 Integer cntPeriodosNoOmisos = 0;
	 Integer cntStock = 0;
	 PropertyParams propertyParams;
	 List<String> lstEstadoUsuario;
	 String numPeriodoOmisoMin = "";//numPeridoomisomin
	 String numPeriodoOmisoMax = ""; //numPperidoomisomax
	 
	 OrdenAccion ordnAccUpd = new OrdenAccion();
	 ordnAccUpd.setNumOrden(ordenGenerada.getNumOrden());
	 
	//4. 1  Obtener la lista inconsistencias de stock negativo y lo almacenamos en la lista listaStockNegativoEnBaja:

	//listaStockNegativoEnBaja  =  T10419proincostockDAO.listarInconsistenciaStock(NumUsuarioProgramacion.numUsuarioProgramacion)
	if (AccionesControlConstantes.COD_TIPO_INCON_BAJA_STOCK_OMISO.equals(ordenGenerada.getCodTipInconsis()) ||
		AccionesControlConstantes.COD_TIPO_INCON_BAJA_STOCK.equals(ordenGenerada.getCodTipInconsis())
	    )
	{
	 	propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioPrograma", ordenGenerada.getNumUsuarioPrograma());
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		List<ProgramaIncosistenciaStock>  listaStockNegativoEnBaja = t10419ProIncoStockDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
	
		cntStockNegativoBaja = listaStockNegativoEnBaja.size();
		
	    //Recorre la lista  listaStockNegativoEnBaja  y verificar si la presentaci�n en el 
	    //establecimiento se mantiene con stock negativo:
	    for(ProgramaIncosistenciaStock prgrIncosStock: listaStockNegativoEnBaja){
	    	
		    ResumenStockEstablecBean resumenStockEstablecBean = new ResumenStockEstablecBean();
			resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_ESTADO_REGISTRO_DEBAJA);
			resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
			resumenStockEstablecBean.setNumRuc(Integer.parseInt(ordenGenerada.getNumDocumentoIdentif()));
			resumenStockEstablecBean.setNumVersionRegistro(ordenGenerada.getNumVersionRegistro());
			resumenStockEstablecBean.setCodTipobien(AccionesControlConstantes.COD_TIPOBIEN_REGISTRO);
			resumenStockEstablecBean.setNumPresentacion(prgrIncosStock.getNumPresentacion());
			resumenStockEstablecBean.setNumEstablecimiento(String.valueOf(prgrIncosStock.getNumEstablecimiento()));
			
			List<ResumenStockEstablec> lstStockNegativo =  t5641RStockEstabDAO.verificarSctokNegativoBaja(resumenStockEstablecBean);
		
			for(ResumenStockEstablec resumenStockEstablec: lstStockNegativo){
				cntStock = resumenStockEstablec.getCantidadStock().intValue();
			}
			
			if(cntStock ==   0){
				cntStockNegativoSubsanado++;
			}else{
				cntStockNegativoNoSubsanado++;
			}

	    }
		//Fin del recorrido de la lista listaStockNegativoEnBaja  
		
		//-	Determinar el tipo de subsanaci�n para el stock negativo 
		    //No ha subanado ninguna 
		 if(cntStockNegativoBaja == cntStockNegativoNoSubsanado ){
			 cntInconsistenciasBajaStock = 1;
		 }
		    //permanece al menos una inconsistencia
		 if(cntStockNegativoBaja < cntStockNegativoSubsanado  ){
			 cntInconsistenciasBajaStock = 2;
		 }
		     //Ha subsanado todas las inconsistencia
		 if(cntStockNegativoBaja == cntStockNegativoSubsanado ){
			 cntInconsistenciasBajaStock = 0;
		 }
	}

	
	//4.2 Obtener los periodos omisos actuales del usuario y almacenarlo en la el bean usuarioOmisoBean
	DeclaracionesJuradasBfBean declaracionesJuradasBfBean = new DeclaracionesJuradasBfBean();
	
	declaracionesJuradasBfBean.setCodEstado(AccionesControlConstantes.COD_ESTADO_DJROP_PENDIENTE);
	declaracionesJuradasBfBean.setNumConfirma(AccionesControlConstantes.NUM_CONFIRMACION_SIN_ENVIO);
	lstEstadoUsuario = new ArrayList<>();
	lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
	lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
	declaracionesJuradasBfBean.setLstEstadoBfRegistro(lstEstadoUsuario);
	declaracionesJuradasBfBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
	declaracionesJuradasBfBean.setIndOmiso(AccionesControlConstantes.COD_ESTADO_DJROP_EXONERADO_DEL_MES);
	declaracionesJuradasBfBean.setNumVersionRegistro(ordenGenerada.getNumVersionRegistro());
	declaracionesJuradasBfBean.setNumRuc(Integer.valueOf(ordenGenerada.getNumDocumentoIdentif()));
	
	List<DeclaracionesJuradasBf>  lstUsuarioOmisoBean = t5284BfCabJroDAO.periodosOmisosPorUsuario(declaracionesJuradasBfBean);
	//
	DeclaracionesJuradasBf bDeclaJurBfOmision = new DeclaracionesJuradasBf();
	if (!MaestrosUtilidades.isEmpty(lstUsuarioOmisoBean)) {
		bDeclaJurBfOmision = lstUsuarioOmisoBean.get(0);
		numPeriodoOmisoMin = bDeclaJurBfOmision.getMinPeriodo();
		numPeriodoOmisoMax = bDeclaJurBfOmision.getMaxPeriodo(); 
	}
	/*
	//Verificar si los periodos del usuario NumUsuarioProgramacion  se mantiene en  el  
	//usuarioOmisoBean y para ello desagregar los periodos  NumUsuarioProgramacion  
		NumUsuarioProgramacion.numPeridoomisomin
		NumUsuarioProgramacion.numPeridoomisomax
	    Y almacenarlo en la la lista listaPeriodosDesagregados

		Ejemplo:
		201901 � 201905
		�	 201901
		�	201902
		�	201903
		�	��

	-	Crear la variable  cntPeriodosDesagrados    y setear la cantidad de periodos desagregados.

		cntPeriodosDesagrados     = listaPeriodosDesagregados.size()
	 */
	List<String> listaPeriodosDesagregados = desagregarPeriodo(ordenGenerada.getNumPeridoOmisoMin(), ordenGenerada.getNumPeridoOmisoMax());
	Integer cntPeriodosDesagrados = 0;
	cntPeriodosDesagrados     = listaPeriodosDesagregados.size();

	 for (String peridoUsuarioProgramacion : listaPeriodosDesagregados){
		 if (peridoUsuarioProgramacion.equals(numPeriodoOmisoMin) ||
			 Integer.parseInt(peridoUsuarioProgramacion)<= Integer.parseInt(numPeriodoOmisoMax)
		    ){
			 cntPeriodosOmisos++;
		 }else{
			 cntPeriodosNoOmisos++;
		 }
	 }
	

    //Determinar el resultado para omisos
    // no ha subanado ninguna 
    if(cntPeriodosDesagrados  == cntPeriodosOmisos){
 		cntInconsistenciasBajaOmiso = 1;
    }
    // permanece al menos una inconsistencia
    if(cntPeriodosDesagrados  == cntPeriodosOmisos){
    	cntInconsistenciasBajaOmiso = 2;
    }
    
	// ha subsanado todas las inconsistencias
    if(cntStockNegativoBaja == cntPeriodosNoOmisos){
        cntInconsistenciasBajaOmiso = 0;
    }
        
        
	//Luego de determinar el resultado del stock y de omisos se debe determinar el tipo de resultado de inconsistencias para la orden seg�n la cantidad de inconsistencias del stock y omiso 
	  if(cntInconsistenciasBajaStock == 0 &&  cntInconsistenciasBajaOmiso == 0){
		  ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANO);
		  ordnAccUpd.setCodResultadoInconsistenciaDef(AccionesControlConstantes.COD_INCON_SUBSANO);
		  ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_CONFORME);
		  ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
	  }

	  if(cntInconsistenciasBajaStock == 0 &&  cntInconsistenciasBajaOmiso > 0){
		  ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
		  ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
		  ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
	  }

	  if(cntInconsistenciasBajaStock > 0 && cntInconsistenciasBajaOmiso == 0){
		  ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
		  ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
		  ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
	  }
	  
	  if(cntInconsistenciasBajaStock > 0 && cntInconsistenciasBajaOmiso > 0){
		  ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
		  ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
		  ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
	  }
		
	  if(cntInconsistenciasBajaStock ==  1 && cntInconsistenciasBajaOmiso == 1){
		  ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_NO_SUBSANO);
		  ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
		  ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
	  }

	//Actualizar los datos de la orden, invocar al m�todo 
	 actualizarResultadoOrden (ordenGenerada);
	 
	 if (logger.isDebugEnabled())
		logger.debug(
				"Fin VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsistenciaProgramaControlBajaOmisoStockNegativo");
	 

	}
	
	public void verificarInconsisProgramaControlGreNoConfirmadasDestinatario(OrdenAccion ordenGenerada){
		if (logger.isWarnEnabled())
			logger.warn(
					"Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsisProgramaControlGreNoConfirmadasDestinatario");
		
		PropertyParams propertyParams;
		Integer cntInconsistenciasGreNoConfirmadas = 0;
		Integer cntNoConfirmadas = 0;
		Integer cntGreConfirmadas = 0;
		Integer cntGRE = 0;
		OrdenAccion ordnAccUpd = new OrdenAccion();
		ordnAccUpd.setNumOrden(ordenGenerada.getNumOrden());

		//Obtener las inconsistencias determinadas (registradas en el m�dulo de acciones de control) 
		//de GRE no confirmadas por el destinatario y almacenarlo en una lista �listaGreNoConfirmadasDestinatario�

		propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioPrograma", ordenGenerada.getNumUsuarioPrograma());
		propertyParams.addProperty("numRuc", ordenGenerada.getNumDocumentoIdentif());
		
		List<ProgramaIncosistenciaGreNC>  listaGreNoConfirmadasDestinatario = t10417ProIncoGreNCDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);

		//	Recorre la lista de listaGreNoConfirmadasDestinatario  y verificar si cada GRE ya se encuentra confirmada:

		cntInconsistenciasGreNoConfirmadas = listaGreNoConfirmadasDestinatario.size();
		
		for (ProgramaIncosistenciaGreNC programaIncosistenciaGreNC:  listaGreNoConfirmadasDestinatario){

			cntGRE = verificarGreConfirmada(programaIncosistenciaGreNC, ordenGenerada, AccionesControlConstantes.COD_TIP_DESTNATARIO);
			
			if (cntGRE > 0){
				cntGreConfirmadas++;
			}else{
				cntNoConfirmadas++;
			}
		
		}

		
		//Determinar el resultado de la orden seg�n la cantidad de GRE confirmadas y no confirmadas
		
		if(cntInconsistenciasGreNoConfirmadas == cntGreConfirmadas){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANO);
			ordnAccUpd.setCodResultadoInconsistenciaDef(AccionesControlConstantes.COD_INCON_SUBSANO);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		}
		
		if(cntInconsistenciasGreNoConfirmadas == cntNoConfirmadas){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_NO_SUBSANO);
			
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}
		
		if(cntInconsistenciasGreNoConfirmadas <  cntGreConfirmadas){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
			
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}

		actualizarResultadoOrden(ordnAccUpd);
		
		if (logger.isDebugEnabled())
			logger.debug(
					"Fin VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsisProgramaControlGreNoConfirmadasDestinatario");	
	}
	
	public void verificarInconsisProgramaControlGreNoConfirmadasTransportista(OrdenAccion ordenGenerada){
	if (logger.isWarnEnabled())
		logger.warn(
				"Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsisProgramaControlGreNoConfirmadasTransportista");
		PropertyParams propertyParams;
		Integer cntInconsistenciasGreNoConfirmadas = 0;
		Integer cntNoConfirmadas = 0;
		Integer cntGreConfirmadas = 0;
		
		Integer cntGRE = 0;
		OrdenAccion ordnAccUpd = new OrdenAccion();
		ordnAccUpd.setNumOrden(ordenGenerada.getNumOrden());

		//Obtener las inconsistencias determinadas (registradas en el m�dulo de acciones de control) 
		//de GRE no confirmadas por el transportista y almacenarlo en una lista �listaGreNoConfirmadasTransportista�
	
		propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioPrograma", ordenGenerada.getNumUsuarioPrograma());
		propertyParams.addProperty("numRuc", ordenGenerada.getNumDocumentoIdentif());
		
		List<ProgramaIncosistenciaGreNC>  listaGreNoConfirmadasTransportista = t10417ProIncoGreNCDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		cntInconsistenciasGreNoConfirmadas = listaGreNoConfirmadasTransportista.size();
		
		
		//Verificar si la GRE de la inconsistencia sigue sin confirmar:
		for (ProgramaIncosistenciaGreNC programaIncosistenciaGreNC:  listaGreNoConfirmadasTransportista){
		
			cntGRE = verificarGreConfirmada(programaIncosistenciaGreNC, ordenGenerada, AccionesControlConstantes.COD_TIP_TRANSPORTISTA );
			if (cntGRE > 0){
				cntGreConfirmadas++;
			}else{
				cntNoConfirmadas++;
			}
		
		}
		
		//Determinar el resultado y estado de la orden seg�n la cantidad de GRE confirmadas y no confirmadas
		if(cntInconsistenciasGreNoConfirmadas == cntGreConfirmadas){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANO);
			ordnAccUpd.setCodResultadoInconsistenciaDef(AccionesControlConstantes.COD_INCON_SUBSANO);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		}
		
		if(cntInconsistenciasGreNoConfirmadas == cntNoConfirmadas){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_NO_SUBSANO);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}

		if(cntInconsistenciasGreNoConfirmadas < cntGreConfirmadas){
			ordnAccUpd.setCodResultadoInconsistenciaPre(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
			ordnAccUpd.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
			ordnAccUpd.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
		}

		actualizarResultadoOrden(ordnAccUpd);
		
		if (logger.isDebugEnabled())
			logger.debug(
					"Fin VerificarLevantamientoInconsistenciaBatchServiceImpl - verificarInconsisProgramaControlGreNoConfirmadasTransportista");
		
	}
	
	private List<String> desagregarPeriodo(String pInicio, String pFin){
		if (logger.isWarnEnabled())
			logger.warn("Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - desagregarPeriodo");
		
		//201912   202002
		List<String> lstPeriodo = new ArrayList<>();
		String periodo = "";
		int mesInicial = Integer.parseInt(pInicio.substring(4,6));
		int anioInicial = Integer.parseInt(pInicio.substring(0,4));
		String mes = "";
		String anio="";
		int cont = 0;
		
		if (Integer.parseInt(pInicio) <= Integer.parseInt(pFin)){
	        while (true) { //Condici�n trivial: siempre cierta
	        	cont++;
	        	mes = agregarCeros(String.valueOf(mesInicial), 2);
	        	anio = String.valueOf(anioInicial);
	        	periodo = anio + mes;
	        	
	        	lstPeriodo.add(periodo);
	        	
	            if (pFin.equals(periodo)){
	            	break;
	            }else{
	            	mesInicial++;
	            	if(mesInicial>12){
	            		anioInicial++;
	            		mesInicial = 1;
	            	}
	            }
	            if(cont == 240){
	            	lstPeriodo = new ArrayList<>();
	            	break;
	            }
	        }     
		}
		
		if (logger.isDebugEnabled())
			logger.debug("Fin VerificarLevantamientoInconsistenciaBatchServiceImpl - desagregarPeriodo");
		
        return lstPeriodo;
	}
	
	
	private static String agregarCeros(String string, int largo)
	{
		if (logger.isWarnEnabled())
			logger.warn("Inicio VerificarLevantamientoInconsistenciaBatchServiceImpl - agregarCeros");
		
		StringBuilder ceros = new StringBuilder();
		int cantidad = largo - string.length();
		if (cantidad >= 1)
		{
			for(int i=0;i<cantidad;i++)
			{
				ceros.append("0");
			}
			return (ceros.append(string).toString());
		}
		else{
			return string;}
		
		
	}
	
}
