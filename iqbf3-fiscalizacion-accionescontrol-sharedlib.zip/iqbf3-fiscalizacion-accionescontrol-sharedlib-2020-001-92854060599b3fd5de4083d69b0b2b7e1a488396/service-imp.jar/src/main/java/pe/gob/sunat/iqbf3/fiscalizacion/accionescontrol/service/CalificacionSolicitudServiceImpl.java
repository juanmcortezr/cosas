package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AlternativaCriterioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CalificacionUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AccionSugeridaCalif;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AlternativaCriterio;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CalificacionUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CriterioCalificacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DetalleCalificacionUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10389AlternatCritDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10393AsignaSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10400CaliUsuaDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10402CriterioCaliDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10403DetaCaliUsuaDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10414MovSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10421SolicProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10429UsuarioSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10444AccSugeCalifDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.MensajesExcepciones;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class CalificacionSolicitudServiceImpl implements CalificacionSolicitudService {

	private static final Logger logger = LoggerFactory.getLogger(CalificacionSolicitudServiceImpl.class);

	@EJB
	private T10421SolicProgDAO t10421SolicProgDAO;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private GestionSolicitudService gestionSolicitudService;

	@EJB
	private T10400CaliUsuaDAO t10400CaliUsuaDAO;

	@EJB
	private T10403DetaCaliUsuaDAO t10403DetaCaliUsuaDAO;

	@EJB
	private T10389AlternatCritDAO t10389AlternatCritDAO;

	@EJB
	private T10429UsuarioSolicDAO t10429UsuarioSolicDAO;

	@EJB
	private T10414MovSolicDAO t10414MovSolicDAO;

	@EJB
	private T8414MensajeIqbfDAO t8414MensajeIqbfDAO;

	@EJB
	private T10402CriterioCaliDAO t10402CriterioCaliDAO;
	
	@EJB
	private T10444AccSugeCalifDAO t10444AccSugeCalifDAO;

	@EJB
	private T8303DistriGrupoDAO t8303DistriGrupoDAO;

	@EJB
	private T10393AsignaSolicDAO t10393AsignaSolicDAO;

	public CalificacionSolicitudServiceImpl() {
	}

	@Override
	public List<SolicitudProgramacionBean> listarSolicitudesporCalificar(SolicitudProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudServiceImpl - listarSolicitudesporCalificar");
		SolicitudProgramacion filtroModel = new SolicitudProgramacion();
		filtroModel.setEstados(Arrays.asList(AccionesControlConstantes.COD_ESTADO_SOLICITUD_ASIGNADO));
		filtroModel.setCodTipAccion(filtro.getCodTipoAccion());
		filtroModel.setCodTipInterv(filtro.getCodTipoIntervension());
		filtroModel.setCodTipDocIdent(filtro.getCodTipoDocUsuario());
		filtroModel.setNumDocIdent(filtro.getNumDocUsuario());
		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			filtroModel.setNumSolicitudUnion(filtro.getNumSolicitudUnion());
		}
		filtroModel.setCodSolicitante(filtro.getCodSolicitante()); // verificar debe ser programador.
		List<SolicitudProgramacionBean> lista = new ArrayList<>();
		List<SolicitudProgramacion> t10421lista = t10421SolicProgDAO.listarSolicitudesporAsignarCalificar(filtroModel);
		if (!MaestrosUtilidades.isEmpty(t10421lista)) {
			for (SolicitudProgramacion t10421 : t10421lista) {
				SolicitudProgramacionBean bean = new SolicitudProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10421, bean);
				bean.setNumSolicitudUnion(AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
				bean.setFecGeneracion(MaestrosUtilidades.dateToStringDDMMYYYY(t10421.getFecGeneracion()));
				bean.setDesEstadoSolicitud("");
				bean.setCalificacionDefinitiva(t10421.getCalificacionDefinitiva());
				bean.setCalificacionPreliminar(t10421.getCalificacionPreliminar());
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_SOLICITUD,
						t10421.getCodEstadoSolicitud());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesEstadoSolicitud(catalogo.getDescripcionDataCatalogo().trim());
				}
				WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(t10421.getCodSolicitante());
				if (!MaestrosUtilidades.isEmpty(solicitante)) {
					bean.setNomSolicitante(solicitante.getNomCompleto());
				}
				WSPersonalIqbfBean supervisor = servicioWebService.obtenerPersonalIqbf(t10421.getCodSupervisor());
				if (!MaestrosUtilidades.isEmpty(supervisor)) {
					bean.setNomSupervisor(supervisor.getNomCompleto());
				}
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	public List<UsuarioSolicitudBean> listarUsuarioSolicitud(Long numSolicProg) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudServiceImpl - listarUsuarioSolicitud");
		return gestionSolicitudService.obtenerDetalleSolicitud(numSolicProg);
	}

	@Override
	public List<CalificacionUsuarioBean> listarCalificacionUsuario(Long numUsuSolic) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudServiceImpl - listarCalificacionUsuario");
		// Obtener criterios calificacion preliminar
		List<CalificacionUsuarioBean> lista = new ArrayList<>();
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioSolicitud", numUsuSolic);
		//propertyParams.addProperty("indTipCali", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<CalificacionUsuario> t10400lista = t10400CaliUsuaDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if(!MaestrosUtilidades.isEmpty(t10400lista)) {
			for (CalificacionUsuario t10400 : t10400lista) {
				CalificacionUsuarioBean calificacion = new CalificacionUsuarioBean();
				calificacion.setIndTipCali(t10400.getIndTipCali());
				calificacion.setValCalificacion(t10400.getValCalificacion());
				calificacion.setDesSusAccsuge(t10400.getDesSusAccsuge());
				calificacion.setNumAccionSugerida(t10400.getNumAccionSugerida());
				calificacion.setDescAccionSugerida("");
				if (!MaestrosUtilidades.isEmpty(t10400.getNumAccionSugerida())) {
					AccionSugeridaCalif t10444 = t10444AccSugeCalifDAO.findById(t10400.getNumAccionSugerida(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
					if (!MaestrosUtilidades.isEmpty(t10444)) {
						calificacion.setDescAccionSugerida(t10444.getDesAccionSugerida());	
					}
				}
				calificacion.setNumUsuarioCalifiicacion(t10400.getNumUsuarioCalifiicacion());
				// Obtener el detalle
				PropertyParams params = new PropertyParams();
				params.addProperty("numUsuarioCalifiicacion", calificacion.getNumUsuarioCalifiicacion());
				params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
				List<AlternativaCriterioBean> preliminares = new ArrayList<>();
				List<DetalleCalificacionUsuario> t10403lista = t10403DetaCaliUsuaDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				if(!MaestrosUtilidades.isEmpty(t10403lista)) {
					for (DetalleCalificacionUsuario t10403 : t10403lista) {
						AlternativaCriterioBean preliminar = new AlternativaCriterioBean();
						preliminar.setValAlternativa(t10403.getValPuntaje());
						preliminar.setNumCriterio(t10403.getNumCriterio());
						preliminar.setNumAlternativa(t10403.getNumAlternativa());
						CriterioCalificacion t10402 = t10402CriterioCaliDAO.findById(t10403.getNumCriterio(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
						if (!MaestrosUtilidades.isEmpty(t10402)) {
							preliminar.setPesoCriterio(t10402.getPorPeso());
							preliminar.setDesCriterio(t10402.getDesCriterio());	
						}
						AlternativaCriterio t10389 = t10389AlternatCritDAO.findById(t10403.getNumAlternativa(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
						if (!MaestrosUtilidades.isEmpty(t10389)) {
							preliminar.setDesAlternativa(t10389.getDesAlternativa());
						}
						preliminares.add(preliminar);
					}
				}
				calificacion.setAlternativasCriterios(preliminares);
				lista.add(calificacion);
			}
		}
		return lista;
	}

	@Override
	public ResponseBean<CalificacionUsuarioBean> guardarCalificacionDefinitiva(CalificacionUsuarioBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudServiceImpl - guardarCalificacionDefinitiva");
		ResponseBean<CalificacionUsuarioBean> respuesta = new ResponseBean<>();
		Long totalPreliminar = 0l;
		PropertyParams t10400params = new PropertyParams();
		t10400params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10400params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		t10400params.addProperty("numUsuarioSolicitud", formulario.getNumUsuarioSolicitud());
		t10400params.addProperty("indTipCali", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
		List<CalificacionUsuario> t10400lista = t10400CaliUsuaDAO.findByProperties(t10400params, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10400lista)) {
			for (CalificacionUsuario t10400 : t10400lista) {
				PropertyParams property = new PropertyParams();
				property.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				property.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
				property.addProperty("numUsuarioCalifiicacion", t10400.getNumUsuarioCalifiicacion());
				totalPreliminar += t10403DetaCaliUsuaDAO.countByProperties(property, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}

		if (formulario.getAlternativasCriterios().size() < totalPreliminar.intValue()) {
			respuesta.setExito(false);
			respuesta.setMensaje(MensajesExcepciones.CUS04_EXCP_006);
			return respuesta;
		}
		boolean esRegistro = formulario.getNumUsuarioCalifiicacion() == 0;
		CalificacionUsuario calificacion = new CalificacionUsuario();
		if (!esRegistro) {
			CalificacionUsuario t10400 = t10400CaliUsuaDAO.findById(formulario.getNumUsuarioCalifiicacion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
			MaestrosUtilidades.copiarValoresBean(t10400, calificacion);
		}
		calificacion.setDesSusAccsuge(formulario.getDesSusAccsuge());
		calificacion.setValCalificacion(formulario.getValCalificacion());
		calificacion.setNumAccionSugerida(formulario.getNumAccionSugerida());
		calificacion.setNumUsuarioSolicitud(formulario.getNumUsuarioSolicitud());
		calificacion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		calificacion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		calificacion.setIndTipCali(AccionesControlConstantes.COD_TIP_CALI_DEFINITIVA);
		Long numUsuarioCalificacion;
		if (esRegistro) {
			numUsuarioCalificacion = t10400CaliUsuaDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_CRITERIOS_CALIFICACION, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			calificacion.setNumUsuarioCalifiicacion(numUsuarioCalificacion);
			calificacion.setFecCrea(new Date());
			calificacion.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			calificacion.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10400CaliUsuaDAO.save(calificacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			numUsuarioCalificacion = formulario.getNumUsuarioCalifiicacion();
			calificacion.setNumUsuarioCalifiicacion(numUsuarioCalificacion);
			calificacion.setFecModif(new Date());
			calificacion.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			calificacion.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			t10400CaliUsuaDAO.update(calificacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		// Dar de Baja
		PropertyParams params = new PropertyParams();
		params.addProperty("numUsuarioCalifiicacion", calificacion.getNumUsuarioCalifiicacion());
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<DetalleCalificacionUsuario> t10403lista = t10403DetaCaliUsuaDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if(!MaestrosUtilidades.isEmpty(t10403lista)) {
			for (DetalleCalificacionUsuario t10403 : t10403lista) {
				t10403.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10403.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10403DetaCaliUsuaDAO.update(t10403, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}

		List<AlternativaCriterioBean> preliminares = formulario.getAlternativasCriterios();
		if (!MaestrosUtilidades.isEmpty(preliminares)) {
			for (AlternativaCriterioBean alternativaCriterio : preliminares) {
				DetalleCalificacionUsuario t10403 = new DetalleCalificacionUsuario();
				PropertyParams detalleParams = new PropertyParams();
				t10403.setValPuntaje(alternativaCriterio.getValAlternativa());
				t10403.setNumAlternativa(alternativaCriterio.getNumAlternativa());
				t10403.setNumCriterio(alternativaCriterio.getNumCriterio());
				t10403.setNumUsuarioCalifiicacion(numUsuarioCalificacion);
				t10403.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10403.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				detalleParams.addProperty("numUsuarioCalifiicacion", numUsuarioCalificacion);
				detalleParams.addProperty("numAlternativa", alternativaCriterio.getNumAlternativa());
				detalleParams.addProperty("numCriterio", alternativaCriterio.getNumCriterio());
				List<DetalleCalificacionUsuario> existe = t10403DetaCaliUsuaDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(existe)) {
					t10403.setFecModif(new Date());
					t10403.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
					t10403.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
					t10403.setNumDetalleCalificacion(existe.get(0).getNumDetalleCalificacion());
					t10403.setFecCrea(existe.get(0).getFecCrea());
					t10403.setDirIpusucrea(existe.get(0).getDirIpusucrea());
					t10403.setCodUsuCrea(existe.get(0).getCodUsuCrea());
					t10403DetaCaliUsuaDAO.update(t10403, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					t10403.setFecCrea(new Date());
					t10403.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					t10403.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
					t10403.setNumDetalleCalificacion(t10403DetaCaliUsuaDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_DETALLE_CALIFICACION, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10403DetaCaliUsuaDAO.save(t10403, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
		}
		formulario.setNumUsuarioCalifiicacion(numUsuarioCalificacion);
		respuesta.setExito(true);
		respuesta.setData(formulario);
		return respuesta;
	}

	@Override
	public ResponseBean<SolicitudProgramacionBean> enviarCalificacion(SolicitudProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CalificacionSolicitudServiceImpl - enviarCalificacion");
		ResponseBean<SolicitudProgramacionBean> respuesta = new ResponseBean<>();
		PropertyParams params = new PropertyParams();
		params.addProperty("numSolicitud", formulario.getNumSolicitud());
		Long usuarios = t10429UsuarioSolicDAO.countByProperties(params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		Integer totalUsuarios = t10429UsuarioSolicDAO.obtenerTotalUsuarioCalif(formulario.getNumSolicitud(),
				AccionesControlConstantes.COD_TIP_CALI_DEFINITIVA);
		if (totalUsuarios != usuarios.intValue()) {
			return new ResponseBean<>(false, MensajesExcepciones.CUS04_EXCP_003);
		}
		SolicitudProgramacion t10421 = t10421SolicProgDAO.findById(formulario.getNumSolicitud(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		t10421.setCodEstadoSolicitud(AccionesControlConstantes.COD_ESTADO_SOLICITUD_CALIFICADO);
		t10421.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
		t10421.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
		t10421SolicProgDAO.update(t10421, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// Parseo
		SolicitudProgramacionBean bean = new SolicitudProgramacionBean();
		MaestrosUtilidades.copiarValoresBean(t10421, bean);

		// Registrar movimiento solicitud
		MovimientoSolicitud t10414 = new MovimientoSolicitud();
		t10414.setCodPersMov(formulario.getAuditoriaBean().getNroRegistro());
		t10414.setFecMovimiento(new Date());
		t10414.setNumSolicitud(formulario.getNumSolicitud());
		t10414.setNumMovimientoPrograma(t10414MovSolicDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_MOVIMIENTO_SOLICITUD, AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10414.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10414.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10414.setFecCrea(new Date());
		t10414.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10414.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10414.setCodCargo(AccionesControlConstantes.COD_CARGO_PROGRAMADOR);
		t10414MovSolicDAO.save(t10414, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		try {
			String codSolicitante = t10421.getCodSolicitante();
			String codSupervisor = t8303DistriGrupoDAO.obtenerSupervisorPersonal(codSolicitante);
			WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(codSolicitante);
			String dirReceptor = "";
			String dirCopia = "";
			if (!MaestrosUtilidades.isEmpty(solicitante)) {
				dirReceptor = solicitante.getDirCorreo().trim();
			}
			WSPersonalIqbfBean supervisor = servicioWebService.obtenerPersonalIqbf(codSupervisor);
			if (!MaestrosUtilidades.isEmpty(supervisor)) {
				dirCopia = supervisor.getDirCorreo().trim();
			}
			// Obtener programador:
			PropertyParams propertyParams = new PropertyParams();
			propertyParams.addProperty("numSolicitud", formulario.getNumSolicitud());
			propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			String nombreProgramador = "-";
			List<AsignaSolicitud> t10393lista = t10393AsignaSolicDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10393lista)) {
				WSPersonalIqbfBean programador = servicioWebService.obtenerPersonalIqbf(t10393lista.get(0).getCodProgramador().trim());
				if (!MaestrosUtilidades.isEmpty(programador)) {
					nombreProgramador = programador.getNomCompleto();
				}
			}
			MensajeIqbf t8414 = t8414MensajeIqbfDAO.findById(AccionesControlConstantes.COD_MENSAJE_CORREO_F04, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t8414) && !MaestrosUtilidades.isEmpty(dirReceptor)) {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("numeroSolicitudProgramacion", AccionesControlUtil.generarNumSoli(t10421.getNumCorrel(), t10421.getAnioSolicitud(), t10421.getCodUnidadOrganica()));
				parametros.put("nombreProgramador", nombreProgramador);
				CorreoBean correoBean = new CorreoBean();
				correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
				correoBean.setAsunto(t8414.getDesCorta());
				correoBean.setReceptor(dirReceptor);
				//correoBean.setCopia(dirCopia);
				correoBean.setMensaje(AccionesControlUtil.generarMensaje(t8414.getDesCuerpo(), parametros));
				CorreoUtil.enviarCorreo(correoBean);
			}
		} catch(Exception e) {
			logger.error(String.format("errorEnviarCorreo %s", e.getMessage()), e);
		}
		respuesta.setExito(true);
		respuesta.setData(formulario);
		return respuesta;
	}
}
