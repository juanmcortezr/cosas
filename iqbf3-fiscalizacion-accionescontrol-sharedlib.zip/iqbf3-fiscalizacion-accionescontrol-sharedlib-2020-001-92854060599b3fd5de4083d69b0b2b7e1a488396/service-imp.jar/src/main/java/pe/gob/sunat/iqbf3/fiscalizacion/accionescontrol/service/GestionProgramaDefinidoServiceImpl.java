package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoDataAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoInformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.HistorialEstadosPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10390ArcInformeDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10410HistEstadoProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10425TipInconProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10445ArcAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10446ArcDataAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.MensajesExcepciones;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSDomicilioRUCBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSRegistroRUCBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class GestionProgramaDefinidoServiceImpl implements GestionProgramaDefinidoService {
	private static final Logger logger = LoggerFactory.getLogger(GestionProgramaOtrosServiceImpl.class);

	@EJB
	private T8276CatProgCtrlDAO t8276CatProgCtrlDAO;
	
	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;
	
	@EJB
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;
	
	@EJB
	private T10411InformeSelecDAO t10411InformeSelecDAO;
	
	@EJB
	private T10390ArcInformeDAO t10390ArcInformeDAO;
	
	@EJB
	private DataCatalogoService dataCatalogoService;
	
	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private T10410HistEstadoProgDAO t10410HistEstadoProgDAO;

	@EJB
	private T10425TipInconProgDAO t10425TipInconProgDAO;
	
	@EJB
	private T10445ArcAcfDAO t10445ArcAcfDAO;

	@EJB
	private DeterminarSeleccionUsuariosBatchService determinarSeleccionUsuariosBatchService;
	
	@EJB
	private T10446ArcDataAcfDAO t10446ArcDataAcfDAO;
	
	@EJB
	private ComunService comunService;
	
	@EJB
	private T8414MensajeIqbfDAO t8414MensajeIqbfDAO;
	
	@EJB
	private T8303DistriGrupoDAO t8303DistriGrupoDAO;
	
	public ProgramaControlBean obtenerProgramaControl(String codProgramaControl) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoServiceImpl - obtenerProgramaControl");

		ProgramaControlBean programaControlBean = null;
		ProgramaControl t8276 = t8276CatProgCtrlDAO.findById(codProgramaControl, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(t8276)) {
			programaControlBean = new ProgramaControlBean();
			MaestrosUtilidades.copiarValoresBean(t8276, programaControlBean);
		}
		return programaControlBean;
	}
	
	public List<ProgramacionBean> listarProgramaDefinido(ProgramacionBean filtro){
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoServiceImpl - listarProgramaDefinido");
		
		List<ProgramacionBean> lista =new ArrayList<ProgramacionBean>();
		
		Programacion program=new Programacion();
		/*
		program.setNumProgramaCorrel(filtro.getNumProgramaCorrel());
		program.setCodProgctrl(filtro.getCodProgramaControl());
		program.setCodEstadoPrograma(filtro.getCodEstadoPrograma());
		program.setFechaDesde(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
		program.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
		program.setNumInforme(filtro.getNumInforme());
		*/
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramaCorrel())){
			program.setNumProgramaCorrel(filtro.getNumProgramaCorrel());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodProgramaControl())){
			program.setCodProgctrl(filtro.getCodProgramaControl());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())){
			program.setCodEstadoPrograma(filtro.getCodEstadoPrograma());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getFechaDesde())){
			program.setFechaDesde(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getFechaHasta())){
			program.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumInforme())){
			program.setNumInforme(filtro.getNumInforme());
		}
		
		List<Programacion> t10420Programacion = t10420ProgramacionDAO.listarProgramaDefinido(program);
		if (!MaestrosUtilidades.isEmpty(t10420Programacion)) {
			ProgramacionBean programacionBean=null;
			for (Programacion programacion : t10420Programacion) {
				programacionBean = new ProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(programacion, programacionBean);
				programacionBean.setFechaIniAsignacion(MaestrosUtilidades.dateToStringDDMMYYYY(programacion.getFechaIniAsignacion()));
				programacionBean.setCodProgramaControl(programacion.getCodProgctrl());
				programacionBean.setDesProgramaControl(programacion.getDesProgctrl());
				programacionBean.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(programacion.getFecProgramacion()));
				programacionBean.setDesEstadoProgram("");
				programacionBean.setNumInforme(programacion.getNumInforme());
	          	DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,programacion.getCodEstadoPrograma());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesEstadoProgram(catalogo.getDescripcionDataCatalogo());
				}	
				lista.add(programacionBean);
			}
		}
		return lista;
	}

	@Override
	public ProgramacionBean obtenerDatosProgramacionDefinido(Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoServiceImpl - obtenerDatosProgramacionDefinido");

		ProgramacionBean programacionBean = new ProgramacionBean();
		Programacion programacion = t10420ProgramacionDAO.findById(numProgramacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		if(!MaestrosUtilidades.isEmpty(programacion)){
			MaestrosUtilidades.copiarValoresBean(programacion, programacionBean);
			programacionBean.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(programacion.getFecProgramacion()));
			programacionBean.setCodProgramaControl(programacion.getCodProgctrl());

			ProgramaControl t8276 = t8276CatProgCtrlDAO.findById(programacion.getCodProgctrl(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t8276)) {
				programacionBean.setDesProgramaControl(t8276.getDesDenominacion());
			}

			WSPersonalIqbfBean servicioWebServ = servicioWebService.obtenerPersonalIqbf(programacionBean.getCodProgramador());
            if (!MaestrosUtilidades.isEmpty(servicioWebServ)) {
                programacionBean.setDesProgramador(servicioWebServ.getNomCompleto());
                programacionBean.setNomProgramador(servicioWebServ.getNomCompleto());
            } else {
                programacionBean.setDesProgramador("");
                programacionBean.setNomProgramador("");
            }
		}
		
		// Obtener datos de informe
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", numProgramacion);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		propertyParams.addPropertyOrder("numInformeSeleccion", true);
		List<InformeSeleccion> t10411lista = t10411InformeSelecDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);

		if (!MaestrosUtilidades.isEmpty(t10411lista)) {

			InformeSeleccion t10411 = t10411lista.get(0);

			InformeSeleccionBean infoBean = new InformeSeleccionBean();
			MaestrosUtilidades.copiarValoresBean(t10411, infoBean);

			propertyParams = new PropertyParams();
			propertyParams.addProperty("numInformeSeleccion", t10411.getNumInformeSeleccion());
			propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<ArchivoInformeSeleccion> t10390lista = t10390ArcInformeDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);

			if (!MaestrosUtilidades.isEmpty(t10390lista)) {
				for (ArchivoInformeSeleccion archivoInformeSeleccion : t10390lista) {
					ArchivoAcciones t10445 = t10445ArcAcfDAO.findById(archivoInformeSeleccion.getNumArchivo(), AccionesControlConstantes.DATASOURCE_DCSICOBF);

					if (!MaestrosUtilidades.isEmpty(t10445)) {
						ArchivoBean archivoBean = new ArchivoBean();
						archivoBean.setCategoria(t10445.getCodTipoArchivo());
						archivoBean.setDesMimeType(t10445.getDesMimeType());
						archivoBean.setCntPesArch(t10445.getCntPesoArc());
						archivoBean.setNumArc(archivoInformeSeleccion.getNumArchivo());
						archivoBean.setTipo(AccionesControlConstantes.TIPO_ARCHIVO_BD);
						if (AccionesControlConstantes.COD_TIPO_ARCHIVO_INFORME.equals(t10445.getCodTipoArchivo())) {
							infoBean.setArchivoInforme(archivoBean);
						}
					}
				}
			}
			programacionBean.setInformeSeleccion(infoBean);
		}
		
		//Getting inconsistencia data
		propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", numProgramacion);
		propertyParams.addProperty("codTipoInconsistencia", AccionesControlConstantes.COD_TIPO_INCON_STOCK_SALDO_NEGATIVO);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<TipoInconsistenciaPrograma> listaTipoIncons = t10425TipInconProgDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if(!MaestrosUtilidades.isEmpty(listaTipoIncons)){
			DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_TIPO_INCON_STOCK_SALDO_NEGATIVO,programacion.getCodEstadoPrograma());
			programacionBean.setDesInconsistencia(catalogo.getDescripcionCorta());
		}else{
			programacionBean.setDesInconsistencia("-");
		}
		return programacionBean; 
	}
	
	@Transactional
	@Override
	public ResponseBean<ProgramacionBean> actualizarUsuario(List<UsuarioProgramacionBean> filtro){
		
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoServiceImpl - actualizarUsuario");

		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<>();
		try{
			String usuarioSOL = filtro.get(0).getAuditoriaBean().getUsuarioSOL();
			String numIp = filtro.get(0).getAuditoriaBean().getNumIp();
			
			for(UsuarioProgramacionBean bean :filtro){
				
				UsuarioProgramacion usuarioProgramacion = new UsuarioProgramacion();
				usuarioProgramacion.setNumUsuarioPrograma(bean.getNumUsuarioPrograma());
				usuarioProgramacion.setCodMotivaDepuracion(bean.getCodMotivaDepuracion());
				usuarioProgramacion.setDesSusMotivo(bean.getDesSusMotivo());
				usuarioProgramacion.setIndEst(AccionesControlConstantes.REGISTRO_INACTIVO);
				usuarioProgramacion.setIndDepuracion(AccionesControlConstantes.COD_IND_DEPURACION_MANUAL);
				usuarioProgramacion.setCodUsuModif(usuarioSOL);
				usuarioProgramacion.setFecModif(new Date());
				usuarioProgramacion.setDirIpusumodif(numIp);
				t10428UsuarioProgDAO.update(usuarioProgramacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
			respuesta.setExito(true);
			respuesta.setMensaje("OK");
		}catch(Exception e){
			respuesta.setExito(false);
			respuesta.setMensaje(e.getMessage());
		}
		return respuesta;
	}
	
	public void actualizarProgramacionDefinido(ProgramacionBean filtro1,InformeSeleccionBean filtro2){
		
		Programacion programacion=new Programacion();
		programacion.setNumProgramacion(filtro1.getNumProgramacion());
		programacion.setNumPlazoVerificacion(filtro1.getNumPlazoVerificacion());
		programacion.setObsProgramacion(filtro1.getObsProgramacion());
		
		t10420ProgramacionDAO.update(programacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
		if(filtro1.getNumInforme().equals("0")){
			
			//LLAMAR METODO GENERICO DE CARGA DE ARCHIVO
			
			Long numeroInforme =t10411InformeSelecDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_INFORMES_SELECCION, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			InformeSeleccion informeSeleccion=new InformeSeleccion();
			informeSeleccion.setNumInformeSeleccion(numeroInforme);
			informeSeleccion.setNumProgramacion(filtro2.getNumProgramacion());
			informeSeleccion.setNumCorrel(filtro2.getNumCorrel());
			informeSeleccion.setAnioInforme(filtro2.getAnioInforme());
			informeSeleccion.setCodUnidadOrganica(filtro2.getCodUnidadOrganica());
			informeSeleccion.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_GENERADO);
			t10411InformeSelecDAO.save(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			
			Long NumeroArchivoDoc  =t10411InformeSelecDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ARCHIVO_INFORME, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			ArchivoInformeSeleccion archivoInformeSeleccion=new ArchivoInformeSeleccion();
			archivoInformeSeleccion.setNumArchivoDoc(NumeroArchivoDoc);
			/*FALTA ESPECIFICAR EN EL DISE�O DE DONDE SE OBTENDRA ESTOS VALORES
			-	NumInfo 
			-	Numarc
			*/
			t10390ArcInformeDAO.save(archivoInformeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			
		}else{
			
			//LLAMAR METODO GENERICO DE CARGA DE ARCHIVO
			
			
		}
	}

	@Override
	public ResponseBean<ProgramacionBean> guardarProgramacionDefinido(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoServiceImpl - guardarProgramacionDefinido");
		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<>();
		PropertyParams params = new PropertyParams();
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		params.addProperty("codProgctrl", formulario.getCodProgramaControl());
		params.addProperty("codEstadoPrograma", AccionesControlConstantes.COD_EST_PROGRAM_EN_PROCESO_SELECCION);
		List<Programacion> t10420lista = t10420ProgramacionDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10420lista)) {
			respuesta.setExito(false);
			respuesta.setMensaje(MensajesExcepciones.CUS22_EXCP_014);
			return respuesta;
		}
		Programacion t10420 = new Programacion();
		t10420.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_GENERADA);
		t10420.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10420.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10420.setDesAlcance(formulario.getDesAlcance());
		t10420.setDesProgramacion(formulario.getDesProgramacion());
		t10420.setCodProgctrl(formulario.getCodProgramaControl());
		t10420.setPerFin(formulario.getPerFin());
		t10420.setPerInicio(formulario.getPerInicio());
		t10420.setFecCrea(new Date());
		t10420.setFecProgramacion(new Date());
		t10420.setAnioProgramacion(Calendar.getInstance().get(Calendar.YEAR));
		t10420.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10420.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10420.setNumProgramaCorrel(t10420ProgramacionDAO.obtenerCorrelativoProgramacion(t10420.getAnioProgramacion()));
		t10420.setNumProgramacion(t10420ProgramacionDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_SOLICITUD_PROGRAMACION, AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10420ProgramacionDAO.save(t10420, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// Historial
		HistorialEstadosPrograma t10410 = new HistorialEstadosPrograma();
		t10410.setNumProgramacion(t10420.getNumProgramacion());
		t10410.setFecEstadoProgram(new Date());
		t10410.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_GENERADA);
		t10410.setFecCrea(new Date());
		t10410.setNumHistoriaProgram(t10410HistEstadoProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_HISTORIAL_ESTADOPROG, AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10410.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10410.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10410.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10410.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10410HistEstadoProgDAO.save(t10410, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		if (AccionesControlConstantes.COD_TIP_PROG_USU_VIGENTES_STOCK_SALDO_NEGATIVO.equals(formulario.getCodProgramaControl())) {
			TipoInconsistenciaPrograma t10425 = new TipoInconsistenciaPrograma();
			t10425.setNumProgramacion(t10420.getNumProgramacion());
			t10425.setCodTipoInconsistencia(AccionesControlConstantes.COD_TIPO_INCON_STOCK_SALDO_NEGATIVO);
			t10425.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10425.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10425.setFecCrea(new Date());
			t10425.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10425.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10425.setNumInconsistenciaProgram(t10425TipInconProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_TIPINCONS_PROGRAMA, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10425TipInconProgDAO.save(t10425, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		System.out.println("GestionProgramaDefinidoServiceImpl - inicio call determinarSeleccionUsuariosBatchService.iniciarProcesamiento");
		logger.debug("GestionProgramaDefinidoServiceImpl - inicio call determinarSeleccionUsuariosBatchService.iniciarProcesamiento");
		determinarSeleccionUsuariosBatchService.iniciarProcesamiento(t10420.getNumProgramacion());
		System.out.println("t10420.getNumProgramacion(): " + t10420.getNumProgramacion());
		logger.debug("GestionProgramaDefinidoServiceImpl - fin call determinarSeleccionUsuariosBatchService.iniciarProcesamiento");
		System.out.println("GestionProgramaDefinidoServiceImpl - fin call determinarSeleccionUsuariosBatchService.iniciarProcesamiento");
		
		respuesta.setExito(true);
		respuesta.setMensaje(String.format("Se ha generado con \u00e9xito la programaci�n Nro. %d", t10420.getNumProgramaCorrel()));
		return respuesta;
	}
	
	@Override
	public List<UsuarioProgramacionBean> listarUsuariosDefinidos(UsuarioProgramacionBean filtro){

		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoServiceImpl - listarUsuariosDefinidos");

		List<UsuarioProgramacionBean> listaUsuarioProgr = new ArrayList<UsuarioProgramacionBean>();
		PropertyParams param = new PropertyParams();

		if(!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())){
			param.addProperty("numProgramacion", filtro.getNumProgramacion());
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getCodNivelRiesgo())){
			param.addProperty("codNivelRiesgo", filtro.getCodNivelRiesgo());
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getCodDependencia())){
			param.addProperty("codDependencia", filtro.getCodDependencia());
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getCodEstadoUsuario())){
			param.addProperty("codEstadoUsuario", filtro.getCodEstadoUsuario());
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getNumPeridoomisomax())){
			param.addProperty("numPeridoomisomax", filtro.getNumPeridoomisomax());
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getOtrasAcciones())){
			param.addProperty("codTipoAccion", filtro.getOtrasAcciones());
		}
		param.addProperty("indDel", AccionesControlConstantes.REGISTRO_NOELIMINADO);
		param.addProperty("indEst", AccionesControlConstantes.REGISTRO_ACTIVO);
		List<UsuarioProgramacion> lista = t10428UsuarioProgDAO.findByProperties(param, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if(!MaestrosUtilidades.isEmpty(lista)){
			
			WSRegistroRUCBean wsRUCBean = new WSRegistroRUCBean();
			WSDomicilioRUCBean wsDomicilioBean = new WSDomicilioRUCBean();
			DataCatalogoBean catalogo = new DataCatalogoBean();
			for(UsuarioProgramacion userProg : lista){
				
				UsuarioProgramacionBean bean = new UsuarioProgramacionBean();

				bean.setNumDocumentoIdentif(MaestrosUtilidades.toBlank(userProg.getNumDocumentoIdentif()));
				bean.setNomApellidoUsuario(MaestrosUtilidades.toBlank(userProg.getNomApellidoUsuario()));
				bean.setFecInicioCaso(MaestrosUtilidades.toBlank(MaestrosUtilidades.dateToStringDDMMYYYY(userProg.getFecInicioCaso())));
				bean.setFecFinVigencia(MaestrosUtilidades.toBlank(MaestrosUtilidades.dateToStringDDMMYYYY(userProg.getFecFinVigencia())));

				bean.setCodEstadoUsuario(MaestrosUtilidades.toBlank(userProg.getCodEstadoUsuario()));
				wsRUCBean = servicioWebService.obtenerRegistroRuc(userProg.getNumDocumentoIdentif());
				if(!MaestrosUtilidades.isEmpty(wsRUCBean)){
					bean.setDesEstadoUsuario(MaestrosUtilidades.toBlank(wsRUCBean.getDescEstado()));
				}

				wsDomicilioBean = servicioWebService.obtenerDomicilioFiscal(userProg.getNumDocumentoIdentif());
				if(!MaestrosUtilidades.isEmpty(wsDomicilioBean)){
					bean.setDesUbigeoDomicilioFiscal(MaestrosUtilidades.toBlank(wsDomicilioBean.getDireccion()));
				}

				bean.setCodDependencia(MaestrosUtilidades.toBlank(MaestrosUtilidades.toBlank(userProg.getCodDependencia())));
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_DEPENDENCIAS,userProg.getCodDependencia());
				if(!MaestrosUtilidades.isEmpty(catalogo)){
					bean.setDesDependencia(MaestrosUtilidades.toBlank(MaestrosUtilidades.toBlank(catalogo.getDescripcionDataCatalogo())));
				}
				
				bean.setCodNivelRiesgo(MaestrosUtilidades.toBlank(userProg.getCodNivelRiesgo()));
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_NIVEL_DERIESGO,userProg.getCodNivelRiesgo());
				if(!MaestrosUtilidades.isEmpty(catalogo)){
					bean.setDesNivelRiesgo(MaestrosUtilidades.toBlank(catalogo.getDescripcionDataCatalogo()));
				}

				bean.setCodTipoAccion(userProg.getCodTipAccion());
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_TIPO_ACCIONCONTROL,userProg.getCodTipAccion());
				if(!MaestrosUtilidades.isEmpty(catalogo)){
					bean.setDesTipoAccion(MaestrosUtilidades.toBlank(catalogo.getDescripcionDataCatalogo()));
				}

				bean.setNumPeridoomisomin(MaestrosUtilidades.toBlank(userProg.getNumPeridoomisomin()));
				bean.setNumPeridoomisomax(MaestrosUtilidades.toBlank(userProg.getNumPeridoomisomax()));

				param = new PropertyParams();
				param.addProperty("numDocumentoIdentif", userProg.getNumDocumentoIdentif());
				param.addProperty("indDel", AccionesControlConstantes.REGISTRO_NOELIMINADO);
				param.addProperty("indEst", AccionesControlConstantes.REGISTRO_ACTIVO);
				List<UsuarioProgramacion> listTot = t10428UsuarioProgDAO.findByProperties(param, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				if(!MaestrosUtilidades.isEmpty(listTot) && listTot.size() > 0){
					bean.setOtrasAcciones("SI");
				}
				if(filtro.getOtrasAcciones().equalsIgnoreCase("NO") && bean.getOtrasAcciones().equals("SI")){
					break;
				}

				bean.setCodMotivaDepuracion(MaestrosUtilidades.toBlank(userProg.getCodMotivaDepuracion()));
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_MOTIVOS_DEPURACION,userProg.getCodMotivaDepuracion());
				if(!MaestrosUtilidades.isEmpty(catalogo)){
					bean.setDesMotDepuracion(MaestrosUtilidades.toBlank(catalogo.getDescripcionDataCatalogo()));
				}
				bean.setDesSusMotivo(userProg.getDesSusMotivo());
				
				listaUsuarioProgr.add(bean);
			}
		}
		return listaUsuarioProgr;
	}
	
	@Override
	public List<DataCatalogoBean> listarMotivoActualizar(){
		
		List<DataCatalogoBean> lista = new ArrayList<DataCatalogoBean>();
		lista = dataCatalogoService.listarCatalogos(AccionesControlConstantes.COD_CATALOGO_MOTIVOS_DEPURACION);
		if(!MaestrosUtilidades.isEmpty(lista)){
			for(DataCatalogoBean bean : lista){
				if (bean.getCodDataCatalogo().equals(AccionesControlConstantes.COD_MOTIVO_DEPURACION_SUBSANO_INCONSISTENCIA)) {
					lista.remove(bean);
					break;
				}
			}
		}
		return lista;
	}

	@Transactional
	@Override
	public ResponseBean<ProgramacionBean> actualizarProgramacionDefinido(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoServiceImpl - actualizarProgramacionDefinido");
		
		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<>();
		PropertyParams propertyParams = new PropertyParams();
		try{

			//Finding the programation
			Programacion t10420 = t10420ProgramacionDAO.findById(formulario.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if(!MaestrosUtilidades.isEmpty(t10420)){
				t10420.setNumPlazoVerificacion(MaestrosUtilidades.toBlank(formulario.getNumPlazoVerificacion()).trim());
				t10420.setObsProgramacion(MaestrosUtilidades.toBlank(formulario.getObsProgramacion()).trim());
				t10420.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
				t10420.setFecModif(new Date());
				t10420.setCodUsuModif(formulario.getAuditoriaBean().getUsuarioSOL());
				t10420ProgramacionDAO.update(t10420, AccionesControlConstantes.DATASOURCE_DGSICOBF);

				//Finding the informe file
				propertyParams = new PropertyParams();
				propertyParams.addProperty("numProgramacion", t10420.getNumProgramacion());
				propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
				propertyParams.addPropertyOrder("numInformeSeleccion", true);
				List<InformeSeleccion> listaInforme = t10411InformeSelecDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				
				ArchivoBean archivoBean = formulario.getArchivoBean();

				if(!MaestrosUtilidades.isEmpty(listaInforme)){
					
					//Saving acciones
					ArchivoAcciones archivoAcciones = new ArchivoAcciones();
					Long numArc = t10445ArcAcfDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ARCHIVOS_ACCIONES, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					archivoAcciones.setNumArc(numArc);
					archivoAcciones.setCodTipoArchivo(AccionesControlConstantes.COD_TIPO_ARCHIVO_INFORME);
					archivoAcciones.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					archivoAcciones.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					archivoAcciones.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					archivoAcciones.setFecCrea(new Date());
					archivoAcciones.setCodUsuCrea(formulario.getAuditoriaBean().getUsuarioSOL());
					
					if(!MaestrosUtilidades.isEmpty(archivoBean)){
						archivoAcciones.setNombArchivoAcciones(archivoBean.getNomArchivo());
						archivoAcciones.setCntPesoArc(archivoBean.getCntPesArch());
						archivoAcciones.setDesMimeType(archivoBean.getDesMimeType());
					}

					t10445ArcAcfDAO.save(archivoAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					
					//Saving data acciones
					ArchivoDataAcciones archivoDataAcciones = new ArchivoDataAcciones();
					archivoDataAcciones.setNumArchAcciones(numArc);
					
					if(!MaestrosUtilidades.isEmpty(archivoBean)){
						archivoDataAcciones.setArchivoContenido(archivoBean.getBlob());
					}

					archivoDataAcciones.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					archivoDataAcciones.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					archivoDataAcciones.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					archivoDataAcciones.setFecCrea(new Date());
					archivoDataAcciones.setCodUsuCrea(formulario.getAuditoriaBean().getUsuarioSOL());
					t10446ArcDataAcfDAO.save(archivoDataAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);

					//Saving informe seleccion
					InformeSeleccion informeSeleccion = new InformeSeleccion();
					Long numeroInforme = t10411InformeSelecDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_INFORMES_SELECCION, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					informeSeleccion.setNumInformeSeleccion(numeroInforme);
					informeSeleccion.setNumProgramacion(t10420.getNumProgramacion());
					informeSeleccion.setNumCorrel(MaestrosUtilidades.toLong(formulario.getNumInforme()));
					informeSeleccion.setAnioInforme(formulario.getAnioProgramacion());
					informeSeleccion.setCodUnidadOrganica(formulario.getCodigoUnidadOrganica());
					informeSeleccion.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_GENERADO);
					informeSeleccion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					informeSeleccion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					informeSeleccion.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					informeSeleccion.setFecCrea(new Date());
					informeSeleccion.setCodUsuCrea(formulario.getAuditoriaBean().getUsuarioSOL());
					t10411InformeSelecDAO.save(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					
					//Saving archivo informe
					ArchivoInformeSeleccion archivoInformeSeleccion = new ArchivoInformeSeleccion();
					Long numeroArchivoDoc = t10390ArcInformeDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ARCHIVO_INFORME, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					archivoInformeSeleccion.setNumArchivoDoc(numeroArchivoDoc);
					archivoInformeSeleccion.setNumInformeSeleccion(numeroArchivoDoc);
					archivoInformeSeleccion.setNumArchivo(numArc);
					archivoInformeSeleccion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					archivoInformeSeleccion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					archivoInformeSeleccion.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					archivoInformeSeleccion.setFecCrea(new Date());
					archivoInformeSeleccion.setCodUsuCrea(formulario.getAuditoriaBean().getUsuarioSOL());
					t10390ArcInformeDAO.save(archivoInformeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}else{
					
					InformeSeleccion informeSeleccion = listaInforme.get(0);
					propertyParams = new PropertyParams();
					propertyParams.addProperty("numInformeSeleccion", informeSeleccion.getNumInformeSeleccion());
					propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
					propertyParams.addPropertyOrder("numArchivo", true);
					List<ArchivoInformeSeleccion> listaArchivoInformeSeleccion = t10390ArcInformeDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
					
					ArchivoAcciones archivoAcciones = t10445ArcAcfDAO.findById(listaArchivoInformeSeleccion.get(0).getNumArchivo(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
					archivoAcciones.setCodTipoArchivo(AccionesControlConstantes.COD_TIPO_ARCHIVO_INFORME);
					
					if(!MaestrosUtilidades.isEmpty(archivoBean)){
						archivoAcciones.setNombArchivoAcciones(archivoBean.getNomArchivo());
						archivoAcciones.setDesMimeType(archivoBean.getDesMimeType());
						archivoAcciones.setCntPesoArc(archivoBean.getCntPesArch());
					}

					archivoAcciones.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					archivoAcciones.setFecCrea(new Date());
					archivoAcciones.setCodUsuCrea(formulario.getAuditoriaBean().getUsuarioSOL());
					t10445ArcAcfDAO.update(archivoAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					
					ArchivoDataAcciones ArchivoDataAcciones = t10446ArcDataAcfDAO.findById(archivoAcciones.getNumArc(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
					
					if(!MaestrosUtilidades.isEmpty(archivoBean)){
						ArchivoDataAcciones.setArchivoContenido(archivoBean.getBlob());
					}
					ArchivoDataAcciones.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					ArchivoDataAcciones.setFecCrea(new Date());
					ArchivoDataAcciones.setCodUsuCrea(formulario.getAuditoriaBean().getUsuarioSOL());
					t10446ArcDataAcfDAO.save(ArchivoDataAcciones, AccionesControlConstantes.DATASOURCE_DGSICOBF);

					informeSeleccion.setNumCorrel(MaestrosUtilidades.toLong(formulario.getNumInforme()));
					informeSeleccion.setAnioInforme(formulario.getAnioProgramacion());
					informeSeleccion.setCodUnidadOrganica(formulario.getCodigoUnidadOrganica());
					informeSeleccion.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					informeSeleccion.setFecCrea(new Date());
					informeSeleccion.setCodUsuCrea(formulario.getAuditoriaBean().getUsuarioSOL());
					
					respuesta.setExito(true);
					respuesta.setMensaje(String.format("Se ha generado con \u00e9xito la programaci�n Nro. %d", t10420.getNumProgramaCorrel()));
				}
			}else{
				respuesta.setExito(false);
				respuesta.setMensaje("El n�mero de programacion no es valido");
			}
		}catch(Exception ex){
			respuesta.setExito(false);
			respuesta.setMensaje(ex.getMessage());
		}
		return respuesta;
	}
	
	@Transactional
	@Override
	public ResponseBean<ProgramacionBean> enviarPrograma(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaDefinidoServiceImpl - enviarPrograma");
		
		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<>();
		PropertyParams propertyParams = new PropertyParams();
		try{

			//Finding the programation
			Programacion t10420 = t10420ProgramacionDAO.findById(formulario.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
			t10420.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_PROGRAMADO);
			t10420.setCodUsuModif(formulario.getAuditoriaBean().getUsuarioSOL());
			t10420.setFecModif(new Date());
			t10420.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			t10420ProgramacionDAO.update(t10420, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			//Finding the informe file
			propertyParams = new PropertyParams();
			propertyParams.addProperty("numProgramacion", t10420.getNumProgramacion());
			propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			propertyParams.addPropertyOrder("numInformeSeleccion", true);
			List<InformeSeleccion> listaInforme = t10411InformeSelecDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);

			if(!MaestrosUtilidades.isEmpty(listaInforme)){
				InformeSeleccion informeSeleccion = listaInforme.get(0);
				informeSeleccion.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_PENDIENTE);
				informeSeleccion.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
				informeSeleccion.setFecCrea(new Date());
				informeSeleccion.setCodUsuCrea(formulario.getAuditoriaBean().getUsuarioSOL());
				t10411InformeSelecDAO.update(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}

			// Historial
			HistorialEstadosPrograma t10410 = new HistorialEstadosPrograma();
			t10410.setNumProgramacion(t10420.getNumProgramacion());
			t10410.setFecEstadoProgram(new Date());
			t10410.setCodEstadoPrograma(AccionesControlConstantes.COD_ESTADO_INFORME_PENDIENTE);
			t10410.setFecCrea(new Date());
			t10410.setNumHistoriaProgram(t10410HistEstadoProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_HISTORIAL_ESTADOPROG, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10410.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10410.setCodUsuCrea(formulario.getAuditoriaBean().getUsuarioSOL());
			t10410.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10410.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10410HistEstadoProgDAO.save(t10410, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			//Sending e-mail
			String codMensaje = AccionesControlConstantes.COD_MENSAJE_CORREO_F13;
			ProgramaControl t8276 = t8276CatProgCtrlDAO.findById(t10420.getCodProgctrl(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
			MensajeIqbf t8414 = t8414MensajeIqbfDAO.findById(codMensaje, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("nroProgramacion", t10420.getNumProgramaCorrel().toString());
			parametros.put("desAlcance", t8276.getDesDenominacion());
			
			String codSupervisor = t8303DistriGrupoDAO.obtenerSupervisorPersonal(t10420.getCodProgramador());
			WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(codSupervisor);
			
			CorreoBean correoBean = new CorreoBean();
			correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
			correoBean.setAsunto(t8414.getDesCorta());
			correoBean.setReceptor(solicitante.getDirCorreo().trim());
			correoBean.setMensaje(AccionesControlUtil.generarMensaje(t8414.getDesCuerpo(), parametros));
			CorreoUtil.enviarCorreo(correoBean);

			respuesta.setExito(true);
			respuesta.setMensaje("OK");
		}catch(Exception ex){
			respuesta.setExito(false);
			respuesta.setMensaje(ex.getMessage());
		}
		return respuesta;
	}
}
