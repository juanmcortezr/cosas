package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActaBienOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActaEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActividadEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActividadOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ContactoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DetalleResultadoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOperacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.EstablecimientoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaIncosistenciaGreNCBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaIncosistenciaSaldoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaIncosistenciaStockBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SuspensionOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.TareoAuditorBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActaBienOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActaEstablecimiento;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActividadEstablecimiento;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActividadOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Actividades;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienEstablecimiento;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ContactoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.TipoInconsistenciaOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DetalleResultadoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoOperacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.EstablecimientoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaGreNC;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaSaldo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaStock;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SuspensionOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TareoAuditor;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10384ActBienOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10385ActaEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10386ActividEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10387ActividOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10395BienEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10401ContactOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10404DetaResOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10405DocOperOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10407DocumenOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10408EstabOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10417ProIncoGreNCDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10418ProIncoSaldoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10419ProIncoStockDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10422SuspensOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10423TareoAuditorDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10424TipIncoOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T7882ActividadDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.MensajesExcepciones;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ParametrosBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ParametrosService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class RegistroResultadoServiceImpl implements RegistroResultadoService {
	
	private static final Logger logger = LoggerFactory.getLogger(RegistroResultadoServiceImpl.class);
	
	@EJB
	private T10395BienEstabDAO t10395BienEstabDAO;
	@EJB
	private T10385ActaEstabDAO t10385ActaEstabDAO;
	@EJB
	private T10386ActividEstabDAO t10386ActividEstabDAO;
	@EJB
	private T7882ActividadDAO t7882ActividadDAO;
	@EJB
	private T10408EstabOrdenDAO t10408EstabOrdenDAO;
	@EJB 
	private T10405DocOperOrdenDAO t10405DocOperOrdenDAO;
	@EJB
	private T10401ContactOrdenDAO t10401ContactOrdenDAO;
	@EJB
	private T10384ActBienOrdenDAO t10384ActBienOrdenDAO;
	@EJB
	private T10387ActividOrdenDAO t10387ActividOrdenDAO;
	
	
	@EJB
	private T10415OrdenAccionDAO t10415OrdenAccionDAO;
	
	@EJB
	private T8276CatProgCtrlDAO t8276CatProgCtrlDAO; 
	
	@EJB
	private DataCatalogoService dataCatalogoService;
	
	@EJB
	private ParametrosService parametrosService;
	
	@EJB
	private T10419ProIncoStockDAO t10419ProIncoStockDAO;
	
	@EJB
	private T10418ProIncoSaldoDAO t10418ProIncoSaldoDAO;
	
	@EJB
	private T10417ProIncoGreNCDAO t10417ProIncoGreNCDAO;
	
	@EJB
	private T10401ContactOrdenDAO t10401ContactoOrdenDAO;
	
	@EJB
	private T10407DocumenOrdenDAO t10407DocumenOrdenDAO;
	
	@EJB
	private T10423TareoAuditorDAO t10423TareoAuditorDAO;
	
	@EJB
	private T10424TipIncoOrdenDAO t10424TipIncoOrdenDAO;
	
	@EJB
	private T10404DetaResOrdenDAO t10404DetaResOrdenDAO;
	
	@EJB(name="accionescontrol.comunService")
	private ComunService comunService;
	@EJB
	private T10422SuspensOrdenDAO t10422SuspensOrdenDAO;
	
	public RegistroResultadoServiceImpl() {
		
	}
	
	@Override
	public List<OrdenAccionBean> listarOrdenAccion(OrdenAccionBean filtro) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio RegistroResultadoServiceImpl - listarOrdenAccion");
		}
		OrdenAccion filtroModel = new OrdenAccion();
		//campo tipo orden
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoOrden())) {
			filtroModel.setCodTipoOrden(filtro.getCodTipoOrden());
		}
		//campo nro orden
		if (!MaestrosUtilidades.isEmpty(filtro.getNumOrden())) {
			filtroModel.setNumOrden(filtro.getNumOrden());
		}
		//campo fecha asignacion inicio
		if (!MaestrosUtilidades.isEmpty(filtro.getFecAsigIni())) {
			filtroModel.setFecAsigIni(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFecAsigIni()));
		}
		//campo fecha asignacion fin
		if (!MaestrosUtilidades.isEmpty(filtro.getFecAsigFin())) {
			filtroModel.setFecAsigFin(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFecAsigFin()));
		}
		//campo tipo documento usuario
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent())) {
			filtroModel.setCodTipDocIdent(filtro.getCodTipDocIdent());
		}
		//campo nro documento del usuario
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			filtroModel.setNumDocIdent(filtro.getNumDocIdent());
		}
		//campo nro informe de seleccion
		if (!MaestrosUtilidades.isEmpty(filtro.getNumCorrel())) {
			filtroModel.setNumCorrel(filtro.getNumCorrel());
		}
		//campo estado de la orden
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoOrden())) {
			filtroModel.setCodEstadoOrden(filtro.getCodEstadoOrden());
		}
		//campo nro documento de la accion
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocAccion())) {
			filtroModel.setNumDocAccion(filtro.getNumDocAccion());
		}
		//campo del programa de control
		if (!MaestrosUtilidades.isEmpty(filtro.getCodProgCtrl())) {
			filtroModel.setCodProgCtrl(filtro.getCodProgCtrl());
		}
		
		if(!MaestrosUtilidades.isEmpty(filtro.getNumInfoResul())) {
			filtroModel.setNumInforResul(filtro.getNumInfoResul());
		}
		
		if(!MaestrosUtilidades.isEmpty(filtro.getCodOrigen())) {
			filtroModel.setCodOrigen(filtro.getCodOrigen());
		}
		
		List<OrdenAccionBean> lista = new ArrayList<>();
		List<OrdenAccion> t10415Lista = t10415OrdenAccionDAO.listarOrden(filtroModel);
		if (!MaestrosUtilidades.isEmpty(t10415Lista)) {
			for (OrdenAccion t10415 : t10415Lista) {
				OrdenAccionBean ordenAccionBean = new OrdenAccionBean();
				MaestrosUtilidades.copiarValoresBean(t10415, ordenAccionBean);
				DataCatalogoBean dataCatalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_ORDENES, t10415.getCodTipoOrden());
				if (!MaestrosUtilidades.isEmpty(dataCatalogo)) {
					ordenAccionBean.setDesTipOrden(dataCatalogo.getDescripcionDataCatalogo().trim());
					ordenAccionBean.setDesAcronimo(MaestrosUtilidades.toBlank(dataCatalogo.getDescripcionAcronimo().trim()));
				}
				if (ordenAccionBean.getCodTipoOrden().equals(AccionesControlConstantes.COD_TIPO_ORDEN_CONTROL)) {
					String numOrdenAccion= ordenAccionBean.getDesAcronimo() + "-" + 
											ordenAccionBean.getNumCorrel() + "-" + 
											ordenAccionBean.getAnioOrden() + "-" + 
											ordenAccionBean.getCodUnidadOrganica();
					ordenAccionBean.setNumOrdenAccion(numOrdenAccion);
				}
				if (ordenAccionBean.getCodTipoOrden().equals(AccionesControlConstantes.COD_TIPO_ORDEN_FISCALIZACION)) {
					String numOrdenAccion = ordenAccionBean.getDesAcronimo() + "-" + 
											ordenAccionBean.getNumOrden() + "-" +
											ordenAccionBean.getAnioOrden() + "-" +
											ordenAccionBean.getCodUnidadOrganica();
					ordenAccionBean.setNumOrdenAccion(numOrdenAccion);
				}
				ProgramaControl programaControl = t8276CatProgCtrlDAO.findById(ordenAccionBean.getCodProgCtrl(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
				if (!MaestrosUtilidades.isEmpty(programaControl)) {
					ordenAccionBean.setDesProgControl(programaControl.getDesDenominacion());
				}
				String informeSeleccion = "IS-" + ordenAccionBean.getNumCorrel() + "-" +
											ordenAccionBean.getAnioInforme() + "-" +
											ordenAccionBean.getCodUnidadOrganicaInforme();
				ordenAccionBean.setDesInformeSelecc(informeSeleccion);
				DataCatalogoBean dataCatalogoTipoAccion = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL, t10415.getCodTipoAccion());
				if (!MaestrosUtilidades.isEmpty(dataCatalogoTipoAccion)) {
					ordenAccionBean.setDesTipoAccion(dataCatalogoTipoAccion.getDescripcionDataCatalogo().trim());
				}
				DataCatalogoBean dataCatalogoEstadoOrden = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_ORDEN, t10415.getCodEstadoOrden());
				if (!MaestrosUtilidades.isEmpty(dataCatalogoEstadoOrden)) {
					ordenAccionBean.setDesEstadoOrden(dataCatalogoEstadoOrden.getDescripcionDataCatalogo().trim());
				}
				DataCatalogoBean dataCatalogoResultadoOrden = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_RESULTADO_ORDEN, t10415.getCodResulOrden());
				if (!MaestrosUtilidades.isEmpty(dataCatalogoResultadoOrden)) {
					ordenAccionBean.setDesResulOrden(dataCatalogoResultadoOrden.getDescripcionDataCatalogo().trim());
				}
				
				DataCatalogoBean dataCatalogoTipoDocumento = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF, t10415.getCodTipoDocumentoIdentif());
				if(!MaestrosUtilidades.isEmpty(dataCatalogoTipoDocumento)) {
					ordenAccionBean.setDesTipoDocumentoIdentif(dataCatalogoTipoDocumento.getDescripcionDataCatalogo().trim());
				}
				
				lista.add(ordenAccionBean);
			}
		}
		return lista;
	}
	
	@Override
	public ProgramaControlBean obtenerTipoProgramaControl(Long numOrden) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio RegistroResultadoServiceImpl - obtenerTipoProgramaControl");
		}
		
		ProgramaControl filtroModel = new ProgramaControl();
		
		//campo numOrden
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			filtroModel.setNumOrden(numOrden);
		}
		ProgramaControlBean programaControlBean = new ProgramaControlBean();
		ProgramaControl programaControl = t8276CatProgCtrlDAO.obtenerTipoProgCtrl(filtroModel);
		MaestrosUtilidades.copiarValoresBean(programaControl, programaControlBean);
		return programaControlBean;
	}
	
	
	@Override
	public OrdenAccionBean obtenerDatosOrden(Long numOrden) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio RegistroResultadoServiceImpl - obtenerDatosOrden");
		}
		
		OrdenAccion t10415 = new OrdenAccion();
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			t10415 = t10415OrdenAccionDAO.obtenerDatosOrden(numOrden, null);
		}
		OrdenAccionBean ordenAccionBean = new OrdenAccionBean();
		
		if (!MaestrosUtilidades.isEmpty(t10415)) {
			MaestrosUtilidades.copiarValoresBean(t10415, ordenAccionBean);
			ordenAccionBean.setFecAsigOrden(MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecAsigOrden()));
			ordenAccionBean.setFecCancelacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecCancelacion()));
			ordenAccionBean.setFecDerivacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecDerivacion()));
			ordenAccionBean.setFecInicioCaso(MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecInicioCaso()));
			ordenAccionBean.setFecInicioCasoNuevo(MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecInicioCasoNuevo()));
			ordenAccionBean.setFecOrden(MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecOrden()));
			ordenAccionBean.setFecPrimeraVisit(MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecPrimeraVisita()));
			ordenAccionBean.setFecSegundaVisit(MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecSegundaVisit()));
			ordenAccionBean.setFecSolicProrroga(MaestrosUtilidades.dateToStringDDMMYYYY(t10415.getFecSolicProrroga()));
			if (ordenAccionBean.getCodTipoOrden().equals(AccionesControlConstantes.COD_TIPO_ORDEN_CONTROL)) {
				ordenAccionBean.setDesTipSigOrden("OC");
			}
			if (ordenAccionBean.getCodTipoOrden().equals(AccionesControlConstantes.COD_TIPO_ORDEN_FISCALIZACION)) {
				ordenAccionBean.setDesTipSigOrden("OF");
			}
			if (ordenAccionBean.getCodTipoOrden().equals(AccionesControlConstantes.COD_TIPO_ORDEN_CONTROL)) {
				String numOrdenAccion= ordenAccionBean.getDesTipSigOrden() + "-" + 
										ordenAccionBean.getNumCorrel() + "-" + 
										ordenAccionBean.getAnioOrden() + "-" + 
										ordenAccionBean.getCodUnidadOrganica();
				ordenAccionBean.setNumOrdenAccion(numOrdenAccion);
			}
			if (ordenAccionBean.getCodTipoOrden().equals(AccionesControlConstantes.COD_TIPO_ORDEN_FISCALIZACION)) {
				String numOrdenAccion = ordenAccionBean.getDesTipSigOrden() + "-" + 
										ordenAccionBean.getNumOrden() + "-" +
										ordenAccionBean.getAnioOrden() + "-" +
										ordenAccionBean.getCodUnidadOrganica();
				ordenAccionBean.setNumOrdenAccion(numOrdenAccion);
			}
			ProgramaControl programaControl = t8276CatProgCtrlDAO.findById(ordenAccionBean.getCodProgCtrl(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(programaControl)) {
				ordenAccionBean.setDesProgControl(programaControl.getDesDenominacion());
			}
			DataCatalogoBean dataCatalogoTipoAccion = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL, t10415.getCodTipoAccion());
			if (!MaestrosUtilidades.isEmpty(dataCatalogoTipoAccion)) {
				ordenAccionBean.setDesTipoAccion(dataCatalogoTipoAccion.getDescripcionDataCatalogo().trim());
			}
			DataCatalogoBean dataCatalogoTipoOrden = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_ORDENES, t10415.getCodTipoOrden());
			if (!MaestrosUtilidades.isEmpty(dataCatalogoTipoOrden)) {
				ordenAccionBean.setDesTipOrden(dataCatalogoTipoOrden.getDescripcionDataCatalogo().trim());
			}
			DataCatalogoBean dataCatalogoTipoDocumento = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF, t10415.getCodTipoDocumentoIdentif());
			if (!MaestrosUtilidades.isEmpty(dataCatalogoTipoDocumento)) {
				ordenAccionBean.setDesTipoDocumentoIdent(dataCatalogoTipoDocumento.getDescripcionCorta().trim());
			}
			ParametrosBean parametroEstadoRegistro = parametrosService.obtenerParametro(MaestrosConstantes.COD_PARAMETRO_ESTADO_REGISTRO, t10415.getCodEstadoRegistro());
			if (!MaestrosUtilidades.isEmpty(parametroEstadoRegistro)) {
				ordenAccionBean.setDesEstadoRegistro(parametroEstadoRegistro.getFuncion().trim());
			}
			DataCatalogoBean dataCatalogoResultadoIncosistencia = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_RESULTADO_INCONSISTENCIA, t10415.getCodResultadoInconsistenciaPre());
			if (!MaestrosUtilidades.isEmpty(dataCatalogoResultadoIncosistencia)) {
				ordenAccionBean.setDesResultadoInconsistencia(dataCatalogoResultadoIncosistencia.getDescripcionDataCatalogo().trim());
			}
			DataCatalogoBean dataCatalogoEstadoOrden = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_ORDEN, t10415.getCodEstadoOrden());
			if (!MaestrosUtilidades.isEmpty(dataCatalogoEstadoOrden)) {
				ordenAccionBean.setDesEstadoOrden(dataCatalogoEstadoOrden.getDescripcionDataCatalogo().trim());
			}
			List<ContactoOrdenBean> listaContactoOrdenBean = this.listarContacto(numOrden);
			if (!MaestrosUtilidades.isEmpty(listaContactoOrdenBean)) {
				ordenAccionBean.setListaContactoOrden(listaContactoOrdenBean);
			}
				
			TipoInconsistenciaOrden filtros=new TipoInconsistenciaOrden();
			filtros.setNumOrden(t10415.getNumOrden());
			filtros.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			filtros.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			List<TipoInconsistenciaOrdenBean> lstInconsistencia=t10424TipIncoOrdenDAO.listarInconsistenciaBean(filtros);
				if(!MaestrosUtilidades.isEmpty(lstInconsistencia)&&lstInconsistencia.size()>0) {
					for(TipoInconsistenciaOrdenBean inconTemp:lstInconsistencia) {
						inconTemp.setDesTipoInconsistencia(comunService.obtenerDescripcionCodCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_INCONSISTENCIAS,inconTemp.getCodTipoInconsistencia()));
						inconTemp.setDesResulInconsis(comunService.obtenerDescripcionCodCatalogo(AccionesControlConstantes.COD_CATALOGO_RESULTADO_INCONSISTENCIA,inconTemp.getCodResultadoInconsistencia()));
						inconTemp.setDesOrigen(comunService.obtenerDescripcionCodCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_ORIGEN_INCONSISTENCIA,inconTemp.getCodOrigen()));
					}
				}
			ordenAccionBean.setLstInconsistencia(lstInconsistencia);
				
				
			//DOCUMENTOS ORDEN
			DetalleResultadoOrden filtrosDetResul=new DetalleResultadoOrden();
			filtrosDetResul.setNumOrden(t10415.getNumOrden());
			filtrosDetResul.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			//filtrosDetResul.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			List<DetalleResultadoOrden>  lstDetalleResult=t10404DetaResOrdenDAO.listarDetaResultado(filtrosDetResul);
			List<DataCatalogoBean> lstCatDetaResul=dataCatalogoService.listarCatalogos(AccionesControlConstantes.COD_CATALOGO_RESULTADOACCION);
			List<DetalleResultadoOrdenBean>  lstDetalleResultFinal=new ArrayList<>();
			if(!MaestrosUtilidades.isEmpty(lstCatDetaResul)) {
				for(DataCatalogoBean catTemp:lstCatDetaResul ) {
					boolean existe=false;
					if(!MaestrosUtilidades.isEmpty(lstDetalleResult)) {
						for(DetalleResultadoOrden detResulTemp:lstDetalleResult) {
							if(detResulTemp.getCodResulOrden().trim().equals(catTemp.getCodDataCatalogo().trim())) {
								DetalleResultadoOrdenBean detalleFinal=new DetalleResultadoOrdenBean();
								detalleFinal.setNumDetalleResultadoOrden(MaestrosUtilidades.toInteger(detResulTemp.getNumDetalleResultadoOrden()));
								detalleFinal.setCodResulOrden(detResulTemp.getCodResulOrden());
								detalleFinal.setDesResulOrden(catTemp.getDescripcionDataCatalogo());
								detalleFinal.setDesOtroResultado(detResulTemp.getDesOtroResultado());
								detalleFinal.setIndSeleccionado(detResulTemp.getIndEst());
								lstDetalleResultFinal.add(detalleFinal);
								existe=true;
							}
						}
					}
					if(!existe){
						DetalleResultadoOrdenBean detalleFinal=new DetalleResultadoOrdenBean();
						detalleFinal.setCodResulOrden(catTemp.getCodDataCatalogo());
						detalleFinal.setDesResulOrden(catTemp.getDescripcionDataCatalogo());
						detalleFinal.setDesOtroResultado(AccionesControlConstantes.SINVALOR);
						detalleFinal.setIndSeleccionado(MaestrosConstantes.REGISTRO_INACTIVO);
						lstDetalleResultFinal.add(detalleFinal);
					}
				}
			}
			ordenAccionBean.setLstDetalleResultOrden(lstDetalleResultFinal);
		
			DocumentoOrden filtrosDocumento=new DocumentoOrden();
			filtrosDocumento.setNumOrden(t10415.getNumOrden());
			filtrosDocumento.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			filtrosDocumento.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			List<DocumentoOrdenBean> lstDocumentos= t10407DocumenOrdenDAO.listarOtroDocumentoBean(filtrosDocumento);
			
			ordenAccionBean.setLstDocumentosOrden(lstDocumentos);
				//TAREAAUDITOR
				
				List<TareoAuditorBean> lstTareoAuditor= this.listarTareo(t10415.getNumOrden());
				ordenAccionBean.setLstTareoAuditor(lstTareoAuditor);
				
				//suspension
				SuspensionOrden filtroSuspension=new SuspensionOrden();
				filtroSuspension.setNumOrden(t10415.getNumOrden());
				filtroSuspension.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				//filtroSuspension.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				List<SuspensionOrden> lstSuspenOrden=t10422SuspensOrdenDAO.listarSuspension(filtroSuspension);//samy
				List<DataCatalogoBean> lstCatSuspen=dataCatalogoService.listarCatalogos(AccionesControlConstantes.COD_CATALOGO_SUSTENTO_SUSPENSION_REGISTRO_RCBF);
				List<SuspensionOrdenBean> lstSuspenOrdenFinal=new ArrayList<SuspensionOrdenBean>();
				if(!MaestrosUtilidades.isEmpty(lstCatSuspen)&&lstCatSuspen.size()>0) {
					for(DataCatalogoBean catSuspTemp: lstCatSuspen) {
						boolean existe=false;
						if(!MaestrosUtilidades.isEmpty(lstSuspenOrden)&&lstSuspenOrden.size()>0) {
							for(SuspensionOrden suspenTemp: lstSuspenOrden) {
								if(suspenTemp.getCodSustentoSuspencion().trim().equals(catSuspTemp.getCodDataCatalogo().trim())) {
									SuspensionOrdenBean suspensionOrdenBean=new SuspensionOrdenBean();
									suspensionOrdenBean.setNumSusSuporden(MaestrosUtilidades.toInteger(suspenTemp.getNumSusSuporden()));
									suspensionOrdenBean.setDesSusSusp(catSuspTemp.getDescripcionDataCatalogo());
									suspensionOrdenBean.setCodSustentoSuspencion(suspenTemp.getCodSustentoSuspencion());
									suspensionOrdenBean.setIndSeleccionado(suspenTemp.getIndEst());
									lstSuspenOrdenFinal.add(suspensionOrdenBean);
									existe=true;
								}
							}
						}
						if(!existe) {
							SuspensionOrdenBean suspensionOrdenBean=new SuspensionOrdenBean();
							suspensionOrdenBean.setDesSusSusp(catSuspTemp.getDescripcionDataCatalogo());
							suspensionOrdenBean.setCodSustentoSuspencion(catSuspTemp.getCodDataCatalogo());
							suspensionOrdenBean.setIndSeleccionado(MaestrosConstantes.REGISTRO_INACTIVO);
							lstSuspenOrdenFinal.add(suspensionOrdenBean);
						}
					}
				}
				
				ordenAccionBean.setLstSuspenOrden(lstSuspenOrdenFinal);
				// LISTAR OTROS DOCUMENTOS
				List<DocumentoOrdenBean> listaOtrosDocumentosBean = this.listarOtroDocumento(t10415.getNumOrden());
				if (!MaestrosUtilidades.isEmpty(listaOtrosDocumentosBean)) {
					ordenAccionBean.setListaOtrosDocumentos(listaOtrosDocumentosBean);
				}
		}
		return ordenAccionBean;
	}
	
	@Override
	public List<ProgramaIncosistenciaStockBean> listarDetalleStockNegativo(Long numUsuarioPrograma) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio RegistroResultadoServiceImpl - listarDetalleStockNegativo");
		}
		List<ProgramaIncosistenciaStockBean> listIncoStock = new ArrayList<>();
		List<ProgramaIncosistenciaStock>  t10419Lista = new ArrayList<>();
		if (!MaestrosUtilidades.isEmpty(numUsuarioPrograma)) {
			t10419Lista  = t10419ProIncoStockDAO.listarDetalleStockNegativo(numUsuarioPrograma); 
		}
		if (!MaestrosUtilidades.isEmpty(t10419Lista)) {
			for (ProgramaIncosistenciaStock t10419 : t10419Lista) {
				ProgramaIncosistenciaStockBean programaInconsistenciaStockBean = new ProgramaIncosistenciaStockBean();
				MaestrosUtilidades.copiarValoresBean(t10419, programaInconsistenciaStockBean);
				ParametrosBean parametroUnidadFisica = parametrosService.obtenerParametro(MaestrosConstantes.COD_PARAMETRO_UNIDAD_FISICA, t10419.getCodUnidadFiscal());
				if (!MaestrosUtilidades.isEmpty(parametroUnidadFisica)) {
					programaInconsistenciaStockBean.setDesUnidadFisica(parametroUnidadFisica.getFuncion().trim());
				}
				DataCatalogoBean dataCatalogoUnidadComercial = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_UNIDAD_COMERCIAL, t10419.getCodUnidadComercial());
				if (!MaestrosUtilidades.isEmpty(dataCatalogoUnidadComercial)) {
					programaInconsistenciaStockBean.setDesUnidadComercial(dataCatalogoUnidadComercial.getDescripcionDataCatalogo().trim());
				}
				listIncoStock.add(programaInconsistenciaStockBean);
			}
		}
		return listIncoStock;
	}
	
	@Override
	public List<ProgramaIncosistenciaSaldoBean> listarDetalleSaldoNegativo(Long numUsuarioPrograma) {
		if (logger.isDebugEnabled()) {
			logger.debug("Inicio RegistroResultadoServiceImpl - listarDetalleSaldoNegativo");
		}
		List<ProgramaIncosistenciaSaldoBean> listIncoSaldo = new ArrayList<>();
		List<ProgramaIncosistenciaSaldo> t10418Lista = new ArrayList<>();
		if (!MaestrosUtilidades.isEmpty(numUsuarioPrograma)) {
			t10418Lista = t10418ProIncoSaldoDAO.listarInconsistenciaSaldo(numUsuarioPrograma);
		}
		if (!MaestrosUtilidades.isEmpty(t10418Lista)) {
			for (ProgramaIncosistenciaSaldo t10418 : t10418Lista) {
				ProgramaIncosistenciaSaldoBean proIncoSaldoBean = new ProgramaIncosistenciaSaldoBean();
				MaestrosUtilidades.copiarValoresBean(t10418, proIncoSaldoBean);
				listIncoSaldo.add(proIncoSaldoBean);
			}
		}
		return listIncoSaldo;
	}
	
	@Override
	public List<ProgramaIncosistenciaGreNCBean> listarDetalleGreNoConfirmada(Long numUsuarioPrograma) {
		if (logger.isDebugEnabled()) {
			logger.debug("Inicio RegistroResultadoServiceImpl - listarDetalleGreNoConfirmada");
		}
		List<ProgramaIncosistenciaGreNCBean> listProIncoGreNC = new ArrayList<>();
		List<ProgramaIncosistenciaGreNC> t10417Lista = new ArrayList<>();
		if (!MaestrosUtilidades.isEmpty(numUsuarioPrograma)) {
			t10417Lista = t10417ProIncoGreNCDAO.listarInconsistenciaGre(numUsuarioPrograma);
		}
		if (!MaestrosUtilidades.isEmpty(t10417Lista)) {
			for (ProgramaIncosistenciaGreNC t10417 : t10417Lista) {
				ProgramaIncosistenciaGreNCBean proIncoGreNC = new ProgramaIncosistenciaGreNCBean();
				MaestrosUtilidades.copiarValoresBean(t10417, proIncoGreNC);
				listProIncoGreNC.add(proIncoGreNC);
			}
		}
		return listProIncoGreNC;
	}
	
	@Override
	public OrdenAccionBean obtenerDetalleInconsistencia(Long numUsuarioPrograma) {
		if (logger.isDebugEnabled()) {
			logger.debug("Inicio RegistroResultadoServiceImpl - obtenerDetalleInconsistencia");
		}
		OrdenAccion ordenAccion = new OrdenAccion();
		if (!MaestrosUtilidades.isEmpty(numUsuarioPrograma)) {
			ordenAccion = t10415OrdenAccionDAO.obtenerDetalleInconsistencia(numUsuarioPrograma);
		}
		OrdenAccionBean ordenAccionBean = new OrdenAccionBean();
		MaestrosUtilidades.copiarValoresBean(ordenAccion, ordenAccionBean);
		return ordenAccionBean;
	}
	
	@Override
	public List<ContactoOrdenBean> listarContacto(Long numOrden) {
		if (logger.isDebugEnabled()) {
			logger.debug("Inicio RegistroResultadoServiceImpl - listarContacto");
		}
		List<ContactoOrdenBean> listaContactoOrden = new ArrayList<>();
		List<ContactoOrden> t10401Lista = new ArrayList<>();
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			t10401Lista = t10401ContactoOrdenDAO.listarContacto(numOrden);
		}
		if (!MaestrosUtilidades.isEmpty(t10401Lista)) {
			for (ContactoOrden t10401 : t10401Lista) {
				ContactoOrdenBean contactoOrdenBean = new ContactoOrdenBean();
				MaestrosUtilidades.copiarValoresBean(t10401, contactoOrdenBean);
				DataCatalogoBean dataCatalogoTipoDocumento = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF, t10401.getCodTipoDocumentoIdentif());
				if (!MaestrosUtilidades.isEmpty(dataCatalogoTipoDocumento)) {
					contactoOrdenBean.setDesTipoDocumentoIdent(dataCatalogoTipoDocumento.getDescripcionCorta().trim());
				}
				listaContactoOrden.add(contactoOrdenBean);
			}
		}
		return listaContactoOrden;
	}
	
	@Override
	public List<DocumentoOrdenBean> listarOtroDocumento(Long numOrden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - listarOtroDocumento");
		List<DocumentoOrdenBean> listaDocumentoOrdenBean = new ArrayList<>();
		
		DocumentoOrden filtroBean = new DocumentoOrden();
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			filtroBean.setNumOrden(numOrden);
		}
 		filtroBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
 		filtroBean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		filtroBean.setCodOrigen("01");
	
		List<DocumentoOrden> t10407Lista = t10407DocumenOrdenDAO.listarOtroDocumento(filtroBean);
		if (!MaestrosUtilidades.isEmpty(t10407Lista)) {
			for (DocumentoOrden t10407 : t10407Lista) {
				DocumentoOrdenBean documenOrdenBean = new DocumentoOrdenBean();
				MaestrosUtilidades.copiarValoresBean(t10407, documenOrdenBean);
				DataCatalogoBean dataCatalogoTipDocumenResultado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_DOCUMENTOTRABAJO, t10407.getCodTipoDocumento());
				if (!MaestrosUtilidades.isEmpty(dataCatalogoTipDocumenResultado)) {
					documenOrdenBean.setDesTipoDocumento(dataCatalogoTipDocumenResultado.getDescripcionDataCatalogo().trim());
				}
				documenOrdenBean.setFecEmision(MaestrosUtilidades.dateToStringDDMMYYYY(t10407.getFecEmision()));
				documenOrdenBean.setFecEntrega(MaestrosUtilidades.dateToStringDDMMYYYY(t10407.getFecEntrega()));
				documenOrdenBean.setFecNotificacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10407.getFecNotificacion()));
				documenOrdenBean.setFecProrroga(MaestrosUtilidades.dateToStringDDMMYYYY(t10407.getFecProrroga()));
				documenOrdenBean.setFecPresentaVisita(MaestrosUtilidades.dateToStringDDMMYYYY(t10407.getFecPresentaVisita()));
				documenOrdenBean.setIndDel(filtroBean.getIndDel());
				documenOrdenBean.setIndEst(filtroBean.getIndEst());
				ArchivoBean archivoBean = comunService.obtenerArchivo(t10407.getNumArc());
				if (!MaestrosUtilidades.isEmpty(archivoBean)) {
					documenOrdenBean.setArchivoBean(archivoBean);
				}
				listaDocumentoOrdenBean.add(documenOrdenBean);
			}
		}
		return listaDocumentoOrdenBean;
	}
	
	@Override
	public List<TareoAuditorBean> listarTareo(Long numOrden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - listarTareo");
		
		List<TareoAuditorBean> listaTareo = new ArrayList<>();
		
		TareoAuditor filtroBean = new TareoAuditor();
		
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			filtroBean.setNumOrden(numOrden);
		}
		filtroBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
 		filtroBean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		
		List<TareoAuditor> t10423Lista = t10423TareoAuditorDAO.listarTareoAuditor(filtroBean);
		if (!MaestrosUtilidades.isEmpty(t10423Lista)) {
			for (TareoAuditor t10423 : t10423Lista) {
				TareoAuditorBean tareoAuditorBean = new TareoAuditorBean();
				MaestrosUtilidades.copiarValoresBean(t10423, tareoAuditorBean);
				tareoAuditorBean.setFecActividad(MaestrosUtilidades.dateToStringDDMMYYYY(t10423.getFecActividad()));
				tareoAuditorBean.setHorEmpleada(MaestrosUtilidades.dateToStringHHMM(t10423.getHorEmpleada()));
				tareoAuditorBean.setNumOrden(t10423.getNumOrden().intValue());
				tareoAuditorBean.setNumTareo(t10423.getNumTareo().intValue());
				tareoAuditorBean.setIndDel(filtroBean.getIndDel());
				tareoAuditorBean.setIndEst(filtroBean.getIndEst());
				listaTareo.add(tareoAuditorBean);
			}
		}
		return listaTareo;
	}
	
	@Override
	public int guardarResultadoOrden(OrdenAccionBean ordenAccionBean) {
		int resultado=0;
		OrdenAccion filtros=new OrdenAccion();
		MaestrosUtilidades.copiarValoresBean(ordenAccionBean, filtros);
		if(!MaestrosUtilidades.isEmpty(ordenAccionBean.getAuditoriaBean())) {
		filtros.setCodUsuModif(ordenAccionBean.getAuditoriaBean().getLogin());
		filtros.setDirIpusumodif(ordenAccionBean.getAuditoriaBean().getNumIp());
		}
		resultado = t10415OrdenAccionDAO.actualizarOrdenGeneral(filtros);
		//SUSPENSION
		
		SuspensionOrdenBean filSupenElim=new SuspensionOrdenBean();
		filSupenElim.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
		filSupenElim.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
		filSupenElim.setNumOrden(MaestrosUtilidades.toInteger(ordenAccionBean.getNumOrden()));
		filSupenElim.setAuditoriaBean(ordenAccionBean.getAuditoriaBean());
		actualizarSuspencionOrden(filSupenElim);
		
		if(!MaestrosUtilidades.isEmpty(ordenAccionBean.getLstSuspenOrden()!=null)&&ordenAccionBean.getLstSuspenOrden().size()>0) {
			for(SuspensionOrdenBean beanSuspen:ordenAccionBean.getLstSuspenOrden()) {
				if(MaestrosConstantes.REGISTRO_ACTIVO.equals(beanSuspen.getIndSeleccionado())) {
					if(!MaestrosUtilidades.isEmpty(beanSuspen.getNumSusSuporden())&&beanSuspen.getNumSusSuporden()>0) {
						// actualiza
						beanSuspen.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						beanSuspen.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
						beanSuspen.setAuditoriaBean(ordenAccionBean.getAuditoriaBean());
						actualizarSuspencionOrden(beanSuspen);
						
					}else {
						SuspensionOrden modelSuspension=new SuspensionOrden();
						MaestrosUtilidades.copiarValoresBean(beanSuspen, modelSuspension);
						modelSuspension.setNumSusSuporden(t10422SuspensOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_SUSTENTO_SUSPENSIONORDEN, AccionesControlConstantes.DATASOURCE_DCSICOBF));
						modelSuspension.setNumOrden(ordenAccionBean.getNumOrden());
						modelSuspension.setCodUsuCrea(ordenAccionBean.getAuditoriaBean().getLogin());
						modelSuspension.setCodUsuModif(ordenAccionBean.getAuditoriaBean().getLogin());
						modelSuspension.setDirIpusucrea(ordenAccionBean.getAuditoriaBean().getNumIp());
						modelSuspension.setDirIpusumodif(ordenAccionBean.getAuditoriaBean().getNumIp());
						modelSuspension.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						modelSuspension.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
						modelSuspension.setFecCrea(new Date());
						modelSuspension.setFecModif(new Date());
						t10422SuspensOrdenDAO.save(modelSuspension, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					}
				}
			}
		}

		//INCONSISTENCIA
		
		TipoInconsistenciaOrdenBean filTipInconElim=new TipoInconsistenciaOrdenBean();
		filTipInconElim.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
		filTipInconElim.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
		filTipInconElim.setNumOrden(MaestrosUtilidades.toInteger(ordenAccionBean.getNumOrden()));
		filTipInconElim.setAuditoriaBean(ordenAccionBean.getAuditoriaBean());
		actualizarInconsistenciaOrden(filTipInconElim);
		
		if(!MaestrosUtilidades.isEmpty(ordenAccionBean.getLstInconsistencia()!=null)&&ordenAccionBean.getLstInconsistencia().size()>0) {
			for(TipoInconsistenciaOrdenBean inconsisBean:ordenAccionBean.getLstInconsistencia()) {
				
					if(!MaestrosUtilidades.isEmpty(inconsisBean.getNumInconsistenciaOrden())&&inconsisBean.getNumInconsistenciaOrden()>0) {
						// actualiza
						
						inconsisBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						inconsisBean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
						inconsisBean.setAuditoriaBean(ordenAccionBean.getAuditoriaBean());
						actualizarInconsistenciaOrden(inconsisBean);
						
					}else {
						TipoInconsistenciaOrden modelInconsis=new TipoInconsistenciaOrden();
						MaestrosUtilidades.copiarValoresBean(inconsisBean, modelInconsis);
						modelInconsis.setNumInconsistenciaOrden(t10424TipIncoOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_TIPINCONS_ORDEN, AccionesControlConstantes.DATASOURCE_DCSICOBF));
						modelInconsis.setNumOrden(ordenAccionBean.getNumOrden());
						modelInconsis.setCodUsuCrea(ordenAccionBean.getAuditoriaBean().getLogin());
						modelInconsis.setCodUsuModif(ordenAccionBean.getAuditoriaBean().getLogin());
						modelInconsis.setDirIpusucrea(ordenAccionBean.getAuditoriaBean().getNumIp());
						modelInconsis.setDirIpusumodif(ordenAccionBean.getAuditoriaBean().getNumIp());
						modelInconsis.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						modelInconsis.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
						modelInconsis.setFecCrea(new Date());
						modelInconsis.setFecModif(new Date());
						t10424TipIncoOrdenDAO.save(modelInconsis, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					}
				
			}
		}
		
		//DATOS DE ACCION
		DetalleResultadoOrdenBean filDetaResuElim=new DetalleResultadoOrdenBean();
		filDetaResuElim.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
		filDetaResuElim.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
		filDetaResuElim.setNumOrden(MaestrosUtilidades.toInteger(ordenAccionBean.getNumOrden()));
		filDetaResuElim.setAuditoriaBean(ordenAccionBean.getAuditoriaBean());
		actualizarDetalleResultadoOrden(filDetaResuElim);
		
		if(!MaestrosUtilidades.isEmpty(ordenAccionBean.getLstDetalleResultOrden()!=null)&&ordenAccionBean.getLstDetalleResultOrden().size()>0) {
			for(DetalleResultadoOrdenBean detalleResulBean:ordenAccionBean.getLstDetalleResultOrden()) {
				if(MaestrosConstantes.REGISTRO_ACTIVO.equals(detalleResulBean.getIndSeleccionado())) {
					if(!MaestrosUtilidades.isEmpty(detalleResulBean.getNumDetalleResultadoOrden())&&detalleResulBean.getNumDetalleResultadoOrden()>0) {
						// actualiza
						detalleResulBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						detalleResulBean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
						detalleResulBean.setAuditoriaBean(ordenAccionBean.getAuditoriaBean());
						actualizarDetalleResultadoOrden(detalleResulBean);
						
					}else {
						DetalleResultadoOrden modelDetalleOrden=new DetalleResultadoOrden();
						MaestrosUtilidades.copiarValoresBean(detalleResulBean, modelDetalleOrden);
						modelDetalleOrden.setNumDetalleResultadoOrden(t10404DetaResOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_RESULTADO_ORDEN, AccionesControlConstantes.DATASOURCE_DCSICOBF));
						modelDetalleOrden.setNumOrden(ordenAccionBean.getNumOrden());
						modelDetalleOrden.setCodUsuCrea(ordenAccionBean.getAuditoriaBean().getLogin());
						modelDetalleOrden.setCodUsuModif(ordenAccionBean.getAuditoriaBean().getLogin());
						modelDetalleOrden.setDirIpusucrea(ordenAccionBean.getAuditoriaBean().getNumIp());
						modelDetalleOrden.setDirIpusumodif(ordenAccionBean.getAuditoriaBean().getNumIp());
						modelDetalleOrden.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						modelDetalleOrden.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
						modelDetalleOrden.setFecCrea(new Date());
						modelDetalleOrden.setFecModif(new Date());
						t10404DetaResOrdenDAO.save(modelDetalleOrden, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					}
				}
			}
		}
		
		//HALLAZGO ACTIVIDADES
		ActividadOrdenBean filActiOrdenElim=new ActividadOrdenBean();
		filActiOrdenElim.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
		filActiOrdenElim.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
		filActiOrdenElim.setNumOrden(MaestrosUtilidades.toInteger(ordenAccionBean.getNumOrden()));
		filActiOrdenElim.setAuditoriaBean(ordenAccionBean.getAuditoriaBean());
		actualizarActividadOrden(filActiOrdenElim);
		
		if(!MaestrosUtilidades.isEmpty(ordenAccionBean.getLstActividadOrden()!=null)&&ordenAccionBean.getLstActividadOrden().size()>0) {
			for(ActividadOrdenBean actiOrdenTemp:ordenAccionBean.getLstActividadOrden()) {
				if(MaestrosConstantes.REGISTRO_ACTIVO.equals(actiOrdenTemp.getIndSeleccionado())) {
					if(!MaestrosUtilidades.isEmpty(actiOrdenTemp.getNumActividadResultado())&&actiOrdenTemp.getNumActividadResultado()>0) {
						// actualiza
						actiOrdenTemp.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						actiOrdenTemp.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
						actiOrdenTemp.setAuditoriaBean(ordenAccionBean.getAuditoriaBean());
						actualizarActividadOrden(actiOrdenTemp);
						
					}else {
						ActividadOrden modelActiOrden=new ActividadOrden();
						MaestrosUtilidades.copiarValoresBean(actiOrdenTemp, modelActiOrden);
						modelActiOrden.setNumActividadResultado(t10387ActividOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ACTIVIDADES_RESULORDEN, AccionesControlConstantes.DATASOURCE_DCSICOBF));
						modelActiOrden.setNumOrden(MaestrosUtilidades.toInteger(ordenAccionBean.getNumOrden()));
						modelActiOrden.setCodUsuCrea(ordenAccionBean.getAuditoriaBean().getLogin());
						modelActiOrden.setCodUsuModif(ordenAccionBean.getAuditoriaBean().getLogin());
						modelActiOrden.setDirIpusucrea(ordenAccionBean.getAuditoriaBean().getNumIp());
						modelActiOrden.setDirIpusumodif(ordenAccionBean.getAuditoriaBean().getNumIp());
						modelActiOrden.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						modelActiOrden.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
						modelActiOrden.setFecCrea(new Date());
						modelActiOrden.setFecModif(new Date());
						t10387ActividOrdenDAO.save(modelActiOrden, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					}
				}
			}
		}
		
		
		
		return resultado;
	}
	
	@Override
	public List<DocumentoAccionBean> listarDocumentoAccion(Long numOrden) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - listarDocumentoAccion");
		List<DocumentoAccionBean> listaDocumentoAccion = new ArrayList<>();
		List<DocumentoAccion> t10406Lista = new ArrayList<>();
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			t10406Lista = t10415OrdenAccionDAO.listarDocuAccion(numOrden);
		}
		if (!MaestrosUtilidades.isEmpty(t10406Lista)) {
			for (DocumentoAccion t10406 : t10406Lista) {
				DocumentoAccionBean documentoAccionBean = new DocumentoAccionBean();
				MaestrosUtilidades.copiarValoresBean(t10406, documentoAccionBean);
				documentoAccionBean.setFecEmision(MaestrosUtilidades.dateToStringDDMMYYYY(t10406.getFecEmision()));
				documentoAccionBean.setFecNotificacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10406.getFecNotificacion()));
				DataCatalogoBean dataCatalogoEstadoDocumento = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_DOCUMENTO_ACCION, t10406.getCodEstadoDocumento());
				if (!MaestrosUtilidades.isEmpty(dataCatalogoEstadoDocumento)) {
					documentoAccionBean.setDesEstadoDocumento(dataCatalogoEstadoDocumento.getDescripcionDataCatalogo().trim());
				}
				DataCatalogoBean dataCatalogoTipDocumentAdicAccion = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOOGO_DOCUMENTO_ADICIONALACCION, t10406.getCodTipoDocumento());
				if (!MaestrosUtilidades.isEmpty(dataCatalogoTipDocumentAdicAccion)) {
					documentoAccionBean.setDesTipoDocumento(dataCatalogoTipDocumentAdicAccion.getDescripcionDataCatalogo().trim());
				}
				DataCatalogoBean dataCatalogoClaseDocumento = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CLASE_DOCUMENTO, t10406.getCodClase());
				if (!MaestrosUtilidades.isEmpty(dataCatalogoClaseDocumento)) {
					documentoAccionBean.setDesClase(dataCatalogoClaseDocumento.getDescripcionDataCatalogo().trim());
				}
				ArchivoBean archivoBean = comunService.obtenerArchivo(t10406.getNumArc());
				if (!MaestrosUtilidades.isEmpty(archivoBean)) {
					documentoAccionBean.setArchivoBean(archivoBean);
				}
				listaDocumentoAccion.add(documentoAccionBean);
			}
		}
		return listaDocumentoAccion;
	}

	@Override
	public ResponseBean<ContactoOrdenBean> guardarContacto(ContactoOrdenBean formulario) {
		
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - guardarContacto");
		
		ContactoOrden t10401 = new ContactoOrden();
		
		if (MaestrosUtilidades.isEmpty(formulario.getCodTipoDocumentoIdentif()) && MaestrosUtilidades.isEmpty(formulario.getNumDocumentoIdentif())) {
			return new ResponseBean<>(false, MensajesExcepciones.CUS18_EXCP_030);
		}
		
		if (!MaestrosUtilidades.isEmpty(formulario.getNumOrden())) {
			t10401.setNumOrden(formulario.getNumOrden());
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getCodTipoDocumentoIdentif())) {
			t10401.setCodTipoDocumentoIdentif(formulario.getCodTipoDocumentoIdentif());
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getNumDocumentoIdentif())) {
			t10401.setNumDocumentoIdentif(formulario.getNumDocumentoIdentif());
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getNomApellidoContacto())) {
			t10401.setNomApellidoContacto(formulario.getNomApellidoContacto());
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getNumTelefono())) {
			t10401.setNumTelefono(formulario.getNumTelefono());
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getDesCargo())) {
			t10401.setDesCargo(formulario.getDesCargo());
		}
		
		List<ContactoOrdenBean> listaContacto = this.listarContacto(formulario.getNumOrden());
		
		if (!MaestrosUtilidades.isEmpty(listaContacto)) {
			for (ContactoOrdenBean c : listaContacto) {
				if (c.getCodTipoDocumentoIdentif().equals(formulario.getCodTipoDocumentoIdentif())
						&& c.getNumDocumentoIdentif().equals(formulario.getNumDocumentoIdentif())) {
					return new ResponseBean<>(false, MensajesExcepciones.CUS18_EXCP_034);
				}
			}
		}
		t10401.setFecCrea(new Date());
		t10401.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10401.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10401.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10401.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		formulario.setIndDel(t10401.getIndDel());
		formulario.setIndEst(t10401.getIndEst());
		t10401.setNumContacto(t10401ContactoOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_CONTACTO_ORDEN, AccionesControlConstantes.DATASOURCE_DCSICOBF));
		formulario.setNumContacto(t10401.getNumContacto());
		t10401ContactoOrdenDAO.save(t10401, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		return new ResponseBean<ContactoOrdenBean>(formulario);
	}

	@Override
	public boolean eliminarContacto(ContactoOrdenBean contactoBean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - eliminarContacto");
		boolean exito = false;
		try {
			ContactoOrden t10401 = new ContactoOrden();
			if (!MaestrosUtilidades.isEmpty(contactoBean)) {
				t10401 = t10401ContactoOrdenDAO.findById(contactoBean.getNumContacto(),AccionesControlConstantes.DATASOURCE_DCSICOBF);
			}
			if (!MaestrosUtilidades.isEmpty(t10401)) {
				t10401.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
				t10401.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10401.setFecModif(new Date());
				t10401.setDirIpusumodif(contactoBean.getAuditoriaBean().getNumIp());
				t10401.setCodUsuModif(contactoBean.getAuditoriaBean().getLogin());
				t10401ContactoOrdenDAO.update(t10401, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				exito = true;
			}
		} catch(Exception e) {
			logger.error(e.getMessage(), e);
			exito = false;
		}
		return exito;
	}

	@Override
	public ResponseBean<DocumentoOrdenBean> guardarOtroDocumento(DocumentoOrdenBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - guardarOtroDocumento");
		boolean esRegistro = formulario.getNumDocumentoOrden() == 0;
		
		
		DocumentoOrden t10407 = esRegistro ? new DocumentoOrden() : t10407DocumenOrdenDAO
															.findById(formulario.getNumDocumentoOrden(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
		if (MaestrosUtilidades.isEmpty(formulario.getCodTipoDocumento()) && MaestrosUtilidades.isEmpty(formulario.getNumDocumento())) {
			return new ResponseBean<>(false, MensajesExcepciones.CUS18_EXCP_031);
		}
		
		if (!MaestrosUtilidades.isEmpty(formulario.getNumOrden())) {
			t10407.setNumOrden(formulario.getNumOrden());
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getCodTipoDocumento())) {
			t10407.setCodTipoDocumento(formulario.getCodTipoDocumento());
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getNumDocumento())) {
			t10407.setNumDocumento(formulario.getNumDocumento());
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getDesDocumento())) {
			t10407.setDesDocumento(formulario.getDesDocumento());
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getFecEmision())) {
			t10407.setFecEmision(MaestrosUtilidades.stringToDateDDMMYYYY(formulario.getFecEmision()));
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getFecNotificacion())) {
			t10407.setFecNotificacion(MaestrosUtilidades.stringToDateDDMMYYYY(formulario.getFecNotificacion()));
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getFecPresentaVisita())) {
			t10407.setFecPresentaVisita(MaestrosUtilidades.stringToDateDDMMYYYY(formulario.getFecPresentaVisita()));
		}
		if (!MaestrosUtilidades.isEmpty(formulario.getFecProrroga())) {
			t10407.setFecProrroga(MaestrosUtilidades.stringToDateDDMMYYYY(formulario.getFecProrroga()));
		}
		
		Long numArc = null;
		ArchivoBean archivoBean = formulario.getArchivoBean();
		if (!MaestrosUtilidades.isEmpty(archivoBean)) {
			archivoBean.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_DOCUMENTO_OTROS);
			archivoBean.setNumArc(!esRegistro ? t10407.getNumArc() : null);
			numArc = comunService.guardarArchivo(archivoBean, formulario.getAuditoriaBean());
		}
		
		List<DocumentoOrdenBean> listaOtrosDocumentos = this.listarOtroDocumento(formulario.getNumOrden());
		
		if (!MaestrosUtilidades.isEmpty(listaOtrosDocumentos)) {
			if (esRegistro) {
				for (DocumentoOrdenBean d : listaOtrosDocumentos) {
					if (d.getNumDocumento().equals(formulario.getNumDocumento())) {
						return new ResponseBean<>(false, MensajesExcepciones.CUS18_EXCP_034);
					}
				}
			} else {
				List<DocumentoOrdenBean> lista = new ArrayList<>();
				for (DocumentoOrdenBean d: listaOtrosDocumentos) {
					if (!d.getNumDocumentoOrden().equals(formulario.getNumDocumentoOrden())) {
						lista.add(d);
					}
				}
				for (DocumentoOrdenBean d: lista) {
					if (d.getNumDocumento().equals(formulario.getNumDocumento())) {
						return new ResponseBean<>(false, MensajesExcepciones.CUS18_EXCP_034);
					}
				}
			}
			
		}
		Long numDocumentoOrden;
		t10407.setNumArc(numArc);
		t10407.setCodOrigen("01");
		t10407.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10407.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		if (esRegistro) {
			numDocumentoOrden = t10407DocumenOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_DOCRESULTADO_ORDEN, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			t10407.setNumDocumentoOrden(numDocumentoOrden);
			t10407.setFecCrea(new Date());
			t10407.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10407.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10407DocumenOrdenDAO.save(t10407, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			numDocumentoOrden = formulario.getNumDocumentoOrden();
			t10407.setNumDocumentoOrden(numDocumentoOrden);
			t10407.setFecModif(new Date());
			t10407.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			t10407.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			t10407DocumenOrdenDAO.update(t10407, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		formulario.setIndDel(t10407.getIndDel());
		formulario.setIndEst(t10407.getIndEst());
		formulario.setCodOrigen(t10407.getCodOrigen());
		formulario.setNumDocumentoOrden(t10407.getNumDocumentoOrden());
		return new ResponseBean<DocumentoOrdenBean>(formulario);
	}
	
	
	@Override
	public List<BienEstablecimientoBean> listarBien(BienEstablecimientoBean bean){
		List<BienEstablecimientoBean> lstBean=new ArrayList<BienEstablecimientoBean>();
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - listarBien");
		
			BienEstablecimiento params=new BienEstablecimiento();
			params.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			params.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			params.setNumEstablecimientoOrden(MaestrosUtilidades.toLong(bean.getNumEstablecimientoOrden()));
			lstBean= t10395BienEstabDAO.listarBienEstablecimientoBean(params);
			
			if(!MaestrosUtilidades.isEmpty(lstBean)&&lstBean.size()>0) {
				for(BienEstablecimientoBean beanTemp:lstBean){
					if(!MaestrosUtilidades.isEmpty(beanTemp.getCodTipoBien()))beanTemp.setDesTipoBien(comunService.obtenerDescripcionCodCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_BIEN, beanTemp.getCodTipoBien().trim()));
					if(!MaestrosUtilidades.isEmpty(beanTemp.getCodUnidadMedida()))beanTemp.setDesUnidadMedida(comunService.obtenerDescripcionParametro(AccionesControlConstantes.PARAMETRO_UNIDAD_MEDIDA_BIEN,beanTemp.getCodUnidadMedida()));
					 
					 PropertyParams paramsActaBien=new PropertyParams();
					 paramsActaBien.addProperty("numBienEstablecimiento", beanTemp.getNumBienEstablecimiento());
					 paramsActaBien.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					 paramsActaBien.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
					 List<ActaBienOrden> lstActaBienModel=t10384ActBienOrdenDAO.findByProperties(paramsActaBien, AccionesControlConstantes.DATASOURCE_DCSICOBF);
					 List<ActaBienOrdenBean> lstActaBienFinal;
					 if(!MaestrosUtilidades.isEmpty(lstActaBienModel)&&lstActaBienModel.size()>0) {
						 lstActaBienFinal=new ArrayList<>();
						 for(ActaBienOrden modelTemp :lstActaBienModel) {
							 ActaBienOrdenBean beanActaTemp=new ActaBienOrdenBean();
							 MaestrosUtilidades.copiarValoresBean(modelTemp, beanActaTemp);
							 lstActaBienFinal.add(beanActaTemp);
						 }
						 beanTemp.setLstActaBienEstablecimiento(lstActaBienFinal);
					 }
				}
			}
			
		return lstBean;
	}
	
	
	@Override
	public List<ActaEstablecimientoBean> listarActa(ActaEstablecimientoBean bean){
		List<ActaEstablecimientoBean> lstBean=new ArrayList<ActaEstablecimientoBean>();
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - listarActa");
		
		PropertyParams params=new PropertyParams();
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		params.addProperty("numEstablecimientoOrden", MaestrosUtilidades.toLong(bean.getNumEstablecimientoOrden()));
		
		List<ActaEstablecimiento> lstModel=t10385ActaEstabDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if(!MaestrosUtilidades.isEmpty(lstModel)&&lstModel.size()>0) {
			for(ActaEstablecimiento modelTemp:lstModel ) {
				ActaEstablecimientoBean beanTemp=new ActaEstablecimientoBean();
				MaestrosUtilidades.copiarValoresBean(modelTemp, beanTemp);
				lstBean.add(beanTemp);
			}
		}
		return lstBean;
	}
	
	@Override
	public List<ActividadEstablecimientoBean> listarActividadEstab(ActividadEstablecimientoBean bean){
		List<ActividadEstablecimientoBean> lstBean=new ArrayList<ActividadEstablecimientoBean>();
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - listarActividadEstablecimiento");
		
		PropertyParams paramsActividad=new PropertyParams();
		paramsActividad.addProperty("indServicio", MaestrosConstantes.REGISTRO_INACTIVO);
		paramsActividad.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		paramsActividad.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<Actividades> lstActividades=t7882ActividadDAO.findByProperties(paramsActividad, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		PropertyParams paramsActiEstab=new PropertyParams();
		paramsActiEstab.addProperty("numEstablecimientoOrden", MaestrosUtilidades.toLong(bean.getNumActividadEstablecimiento()));
//		paramsActiEstab.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		paramsActiEstab.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		List<ActividadEstablecimiento> lstActiEstab=t10386ActividEstabDAO.findByProperties(paramsActiEstab, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if(!MaestrosUtilidades.isEmpty(lstActividades)&&lstActividades.size()>0) {
			for(Actividades actiTemp:lstActividades) {
				boolean existe=false;
				ActividadEstablecimientoBean beanTemp=new ActividadEstablecimientoBean();
				if(!MaestrosUtilidades.isEmpty(lstActiEstab)&&lstActiEstab.size()>0) {
					for(ActividadEstablecimiento actiEstabTemp:lstActiEstab) {
						if(actiEstabTemp.getCodActividad().trim().equals(actiTemp.getCodActividad().trim())) {
							beanTemp.setCodActividad(actiEstabTemp.getCodActividad());
							beanTemp.setDesActividad(actiTemp.getNomActividad());
							beanTemp.setNumEstablecimientoOrden(MaestrosUtilidades.toInteger(actiEstabTemp.getNumEstablecimientoOrden()));
							beanTemp.setNumActividadEstablecimiento(MaestrosUtilidades.toInteger(actiEstabTemp.getNumActividadEstablecimiento()));
							beanTemp.setIndSeleccionado(actiEstabTemp.getIndEst());
							lstBean.add(beanTemp);
							existe=true;
							break;
						}
					}
				}
				if(!existe) {
					beanTemp.setCodActividad(actiTemp.getCodActividad());
					beanTemp.setDesActividad(actiTemp.getNomActividad());
					beanTemp.setIndSeleccionado(MaestrosConstantes.REGISTRO_INACTIVO);
					beanTemp.setNumEstablecimientoOrden(bean.getNumEstablecimientoOrden());
					lstBean.add(beanTemp);
				}
			}
		}
		return lstBean;
	}
	
	
	@Override
	public List<EstablecimientoOrdenBean> listarEstablecimiento(EstablecimientoOrdenBean bean){
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - listarEstablecimiento");
		
		List<EstablecimientoOrdenBean> lstModel=new ArrayList<>();
		EstablecimientoOrden model=new EstablecimientoOrden();
		MaestrosUtilidades.copiarValoresBean(bean, model);
		model.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
		model.setIndEst(AccionesControlConstantes.REGISTRO_ACTIVO);
		lstModel=t10408EstabOrdenDAO.listarEstablecimientoOrdenBean(model);
		for(EstablecimientoOrdenBean estaTemp:lstModel) {
			if(!MaestrosUtilidades.isEmpty(estaTemp.getCodOrigen()))estaTemp.setDesOrigen(comunService.obtenerDescripcionCodCatalogo(AccionesControlConstantes.COD_CATALOGO_ORIGEN_ESTAB_HALLAZGOS, estaTemp.getCodOrigen()));
			if(!MaestrosUtilidades.isEmpty(estaTemp.getCodDepartamento()))estaTemp.setDesDepartamento(comunService.obtenerDescripcionParametro(AccionesControlConstantes.PARAMETRO_DEPARTAMENTO, estaTemp.getCodDepartamento()));
			if(!MaestrosUtilidades.isEmpty(estaTemp.getCodDistrito()))estaTemp.setDesDistrito(comunService.obtenerDescripcionParametro(AccionesControlConstantes.PARAMETRO_DISTRITO, estaTemp.getCodDistrito()));
			if(!MaestrosUtilidades.isEmpty(estaTemp.getCodProvincia()))estaTemp.setDesProvincia(comunService.obtenerDescripcionParametro(AccionesControlConstantes.PARAMETRO_PROVINCIA, estaTemp.getCodProvincia()));
			estaTemp.setDesOrigen(estaTemp.getDesDepartamento()+"-"+estaTemp.getDesProvincia()+"-"+estaTemp.getDesDistrito());
		}
		return lstModel;
	}
	
	@Override
	public DocumentoOperacionBean guardarOperacion(DocumentoOperacionBean bean) {
		
		if (logger.isDebugEnabled()){
			logger.debug("Inicio RegistroResultadoServiceImpl - guardarDocumentoOperacion");
		}
		
		

		if(!MaestrosUtilidades.isEmpty(bean.getNumDocumentoOperacion())&&bean.getNumDocumentoOperacion()>0) {
			actualizarDocumentoOperacion(bean);
		}else {
			DocumentoOperacion model=new DocumentoOperacion();
			model.setNumDocumentoOperacion(t10405DocOperOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_DOCOPERACION_ORDEN,  AccionesControlConstantes.DATASOURCE_DCSICOBF));
			model.setCodTipoDocumentoOperacion(bean.getCodTipoDocumentoOperacion());
			model.setNumDocumentoComercial(bean.getNumDocumentoComercial());
			model.setNumOrden(MaestrosUtilidades.toLong(bean.getNumOrden()));
			
			model.setCodUsuCrea(bean.getAuditoriaBean().getLogin());
			model.setDirIpusucrea(bean.getAuditoriaBean().getNumIp());
			model.setFecCrea(new Date());
			model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
			model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
			model.setFecModif(new Date());
			model.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			model.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10405DocOperOrdenDAO.save(model, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		
		return bean;
	}
	
	@Override
	public DocumentoOperacionBean actualizarDocumentoOperacion(DocumentoOperacionBean bean) {
		
		if (logger.isDebugEnabled()){
			logger.debug("Inicio RegistroResultadoServiceImpl - actualizarDocumentoOperacion");
		}
		DocumentoOperacion model=new DocumentoOperacion();
		
		if(!MaestrosUtilidades.isEmpty(bean.getCodTipoDocumentoOperacion()))model.setCodTipoDocumentoOperacion(bean.getCodTipoDocumentoOperacion());
		if(!MaestrosUtilidades.isEmpty(bean.getNumDocumentoComercial()))model.setNumDocumentoComercial(bean.getNumDocumentoComercial());
		if(!MaestrosUtilidades.isEmpty(bean.getNumOrden())&&bean.getNumOrden()>0)model.setNumOrden(MaestrosUtilidades.toLong(bean.getNumOrden()));
		if(!MaestrosUtilidades.isEmpty(bean.getNumDocumentoOperacion())&&bean.getNumDocumentoOperacion()>0)model.setNumDocumentoOperacion(MaestrosUtilidades.toLong(bean.getNumDocumentoOperacion()));
		if(!MaestrosUtilidades.isEmpty(bean.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(bean.getAuditoriaBean().getLogin()))model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(bean.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(bean.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
		if(!MaestrosUtilidades.isEmpty(bean.getIndDel())&&
			MaestrosConstantes.REGISTRO_ELIMINADO.equals(bean.getIndDel())&&
		   !MaestrosUtilidades.isEmpty(bean.getIndEst())&&
		   MaestrosConstantes.REGISTRO_INACTIVO.equals(bean.getIndEst())) {
			model.setIndEliminar(true);
		}
		t10405DocOperOrdenDAO.actualizarDocumentoOperacion(model);
		
		
		return bean;
	}
	
	
	
	@Override
	public List<DocumentoOperacionBean> listarOperacion(DocumentoOperacionBean bean){
		if (logger.isDebugEnabled()){
			logger.debug("Inicio RegistroResultadoServiceImpl - listarOperacion");
		}
		
		List<DocumentoOperacionBean> lstDocumentoOperacion=new ArrayList<>();
		
		DocumentoOperacion model=new DocumentoOperacion();
		if(!MaestrosUtilidades.isEmpty(bean.getNumDocumentoOperacion())&&bean.getNumDocumentoOperacion()>0)model.setNumDocumentoOperacion(MaestrosUtilidades.toLong(bean.getNumDocumentoOperacion()));
		if(!MaestrosUtilidades.isEmpty(bean.getNumOrden())&&bean.getNumOrden()>0)model.setNumOrden(MaestrosUtilidades.toLong(bean.getNumOrden()));
		if(!MaestrosUtilidades.isEmpty(bean.getCodTipoDocumentoOperacion()))model.setCodTipoDocumentoOperacion(bean.getCodTipoDocumentoOperacion());
		if(!MaestrosUtilidades.isEmpty(bean.getNumDocumentoComercial()))model.setNumDocumentoComercial(bean.getNumDocumentoComercial());
		model.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		model.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		lstDocumentoOperacion=t10405DocOperOrdenDAO.listarDocumentoOperacionBean(model);
		if(!MaestrosUtilidades.isEmpty(lstDocumentoOperacion)&&lstDocumentoOperacion.size()>0) {
			for(DocumentoOperacionBean beanTemp:lstDocumentoOperacion) {
				if(!MaestrosUtilidades.isEmpty(beanTemp.getCodTipoDocumentoOperacion()))beanTemp.setDesTipoDocumentoOperacion(comunService.obtenerDescripcionCodCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_DOCUMENTO_ACCION, beanTemp.getCodTipoDocumentoOperacion()));
			}
		}
		return lstDocumentoOperacion;
	}
	
	
	@Override
	public TareoAuditorBean guardarTareo(TareoAuditorBean bean) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio RegistroResultadoServiceImpl - guardarTareo");
		}
		
		if(!MaestrosUtilidades.isEmpty(bean.getNumTareo())&&bean.getNumTareo()>0) {
			actualizarTareo(bean);
		}else {
			TareoAuditor model=new TareoAuditor();
			model.setNumTareo(t10423TareoAuditorDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_TIEMPO_ATENCIONAUDITOR,  AccionesControlConstantes.DATASOURCE_DCSICOBF));
			model.setDesActividad(bean.getDesActividad());
			model.setFecActividad(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecActividad()));
			model.setHorEmpleada(MaestrosUtilidades.stringToDate(bean.getHorEmpleada(), MaestrosConstantes.FORMAT_HORA_HHMMSS));
			model.setNumOrden(MaestrosUtilidades.toLong(bean.getNumOrden()));
			
			model.setCodUsuCrea(bean.getAuditoriaBean().getLogin());
			model.setDirIpusucrea(bean.getAuditoriaBean().getNumIp());
			model.setFecCrea(new Date());
			model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
			model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
			model.setFecModif(new Date());
			model.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			model.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10423TareoAuditorDAO.save(model, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		
		return bean;
	}
	
	
	@Override
	public TareoAuditorBean actualizarTareo(TareoAuditorBean bean) {
		if (logger.isDebugEnabled()){
			logger.debug("Inicio RegistroResultadoServiceImpl - actualizarTareo");
		}
		TareoAuditor model=new TareoAuditor();
		
		if(!MaestrosUtilidades.isEmpty(bean.getDesActividad()))model.setDesActividad(bean.getDesActividad());
		if(!MaestrosUtilidades.isEmpty(bean.getFecActividad()))model.setFecActividad(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecActividad()));
		if(!MaestrosUtilidades.isEmpty(bean.getHorEmpleada()))model.setHorEmpleada(MaestrosUtilidades.stringToDate(bean.getHorEmpleada(), MaestrosConstantes.FORMAT_HORA_HHMMSS));
		if(!MaestrosUtilidades.isEmpty(bean.getNumOrden())&&bean.getNumOrden()>0)model.setNumOrden(MaestrosUtilidades.toLong(bean.getNumOrden()));
		if(!MaestrosUtilidades.isEmpty(bean.getNumTareo())&&bean.getNumTareo()>0)model.setNumTareo(MaestrosUtilidades.toLong(bean.getNumTareo()));
		if(!MaestrosUtilidades.isEmpty(bean.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(bean.getAuditoriaBean().getLogin()))model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(bean.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(bean.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
		if(!MaestrosUtilidades.isEmpty(bean.getIndDel())&&
			MaestrosConstantes.REGISTRO_ELIMINADO.equals(bean.getIndDel())&&
		   !MaestrosUtilidades.isEmpty(bean.getIndEst())&&
		   MaestrosConstantes.REGISTRO_INACTIVO.equals(bean.getIndEst())) {
			model.setIndEliminar(true);
		}
		t10423TareoAuditorDAO.actualizarTareoAuditor(model);
		
		
		return bean;
	}
	
	@Override
	public ContactoOrdenBean guardarContactoOrden(ContactoOrdenBean bean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - guardarContactoOrden");
		
			if(!MaestrosUtilidades.isEmpty(bean.getNumContacto())&&bean.getNumContacto()>0) {
				ContactoOrden model=new ContactoOrden();
				MaestrosUtilidades.copiarValoresBean(bean, model);
				model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
				model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
				t10401ContactOrdenDAO.actualizarContactoOrden(model);
			}else {
				
				ContactoOrden model=new ContactoOrden();
				MaestrosUtilidades.copiarValoresBean(bean, model);
				model.setNumContacto(t10401ContactOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_CONTACTO_ORDEN,AccionesControlConstantes.DATASOURCE_DCSICOBF));
				model.setCodUsuCrea(bean.getAuditoriaBean().getLogin());
				model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
				model.setDirIpusucrea(bean.getAuditoriaBean().getNumIp());
				model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
				model.setFecCrea(new Date());
				model.setFecModif(new Date());
				model.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				model.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				t10401ContactOrdenDAO.save(model, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
			
		return bean;
	}
	
	@Override
	public ContactoOrdenBean actualizarContactoOrden(ContactoOrdenBean bean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - actualizarContactoOrden");
				//modificar si se necesita actualizar
				ContactoOrden model=new ContactoOrden();
				MaestrosUtilidades.copiarValoresBean(bean, model);
				model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
				model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
				if(!MaestrosUtilidades.isEmpty(bean.getIndDel())&&MaestrosConstantes.REGISTRO_ELIMINADO.equals(bean.getIndDel())&&
				  !MaestrosUtilidades.isEmpty(bean.getIndEst())&&MaestrosConstantes.REGISTRO_INACTIVO.equals(bean.getIndEst())) {
					model.setIndEliminar(true);
				}
				t10401ContactOrdenDAO.actualizarContactoOrden(model);
			
		return bean;
	}
	
	@Override
	public DocumentoOrdenBean guardarDocumentoOrden(DocumentoOrdenBean bean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - guardarDocumentoOrden");
		boolean esRegistro=true;
		if(!MaestrosUtilidades.isEmpty(bean.getNumDocumentoOrden())&&bean.getNumDocumentoOrden()>0)esRegistro=false;
		Long numArc = null;
		ArchivoBean archivoBean = bean.getArchivoBean();
		if (!MaestrosUtilidades.isEmpty(archivoBean)) {
			archivoBean.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_DOCUMENTO_ADICIONAL);
			archivoBean.setNumArc(!esRegistro ? MaestrosUtilidades.toLong(bean.getNumArc()) : null);
			numArc = comunService.guardarArchivo(archivoBean, bean.getAuditoriaBean());
		}
		
		
		DocumentoOrden model=new DocumentoOrden();
		if(!MaestrosUtilidades.isEmpty(bean.getCodOrigen()))model.setCodOrigen(bean.getCodOrigen());
		if(!MaestrosUtilidades.isEmpty(bean.getCodTipoDocumento()))model.setCodTipoDocumento(bean.getCodTipoDocumento());
		if(!MaestrosUtilidades.isEmpty(bean.getDesDocumento()))model.setDesDocumento(bean.getDesDocumento());
		if(!MaestrosUtilidades.isEmpty(bean.getFecEmision()))model.setFecEmision(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecEmision()));
		if(!MaestrosUtilidades.isEmpty(bean.getFecNotificacion()))model.setFecNotificacion(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecNotificacion()));
		if(!MaestrosUtilidades.isEmpty(bean.getFecEntrega()))model.setFecEntrega(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecEntrega()));
		if(!MaestrosUtilidades.isEmpty(bean.getFecPresentaVisita()))model.setFecPresentaVisita(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecPresentaVisita()));
		if(!MaestrosUtilidades.isEmpty(bean.getFecProrroga()))model.setFecProrroga(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecProrroga()));
		if(!MaestrosUtilidades.isEmpty(bean.getNumDocumento()))model.setNumDocumento(bean.getNumDocumento());
		if(!MaestrosUtilidades.isEmpty(bean.getNumOrden()))model.setNumOrden(MaestrosUtilidades.toLong(bean.getNumOrden()));
		
		if(esRegistro) {
			
			
			
			model.setNumDocumentoOrden(t10407DocumenOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_DOCRESULTADO_ORDEN,AccionesControlConstantes.DATASOURCE_DCSICOBF));
			model.setNumArc(numArc);
			model.setCodUsuCrea(bean.getAuditoriaBean().getLogin());
			model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
			model.setDirIpusucrea(bean.getAuditoriaBean().getNumIp());
			model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
			model.setFecCrea(new Date());
			model.setFecModif(new Date());
			model.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			model.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10407DocumenOrdenDAO.save(model, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			
		}else {
			model.setNumDocumentoOrden(MaestrosUtilidades.toLong(bean.getNumDocumentoOrden()));
			model.setNumArc(numArc);
			model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
			model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
			model.setFecModif(new Date());
			t10407DocumenOrdenDAO.actualizarDocumentoOrden(model);
		}
		
		
		return bean;
	}
	
	
	
	@Override
	public DocumentoOrdenBean actualizarDocumentoOrden(DocumentoOrdenBean bean) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio RegistroResultadoServiceImpl - actualizarDocumentoOrden");
				//modificar si se necesita actualizar
				DocumentoOrden model=new DocumentoOrden();
				//MaestrosUtilidades.copiarValoresBean(bean, model);
				if(!MaestrosUtilidades.isEmpty(bean.getCodOrigen()))model.setCodOrigen(bean.getCodOrigen());
				if(!MaestrosUtilidades.isEmpty(bean.getCodTipoDocumento()))model.setCodTipoDocumento(bean.getCodTipoDocumento());
				if(!MaestrosUtilidades.isEmpty(bean.getDesDocumento()))model.setDesDocumento(bean.getDesDocumento());
				if(!MaestrosUtilidades.isEmpty(bean.getFecEmision()))model.setFecEmision(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecEmision()));
				if(!MaestrosUtilidades.isEmpty(bean.getFecNotificacion()))model.setFecNotificacion(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecNotificacion()));
				if(!MaestrosUtilidades.isEmpty(bean.getFecEntrega()))model.setFecEntrega(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecEntrega()));
				if(!MaestrosUtilidades.isEmpty(bean.getFecPresentaVisita()))model.setFecPresentaVisita(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecPresentaVisita()));
				if(!MaestrosUtilidades.isEmpty(bean.getFecProrroga()))model.setFecProrroga(MaestrosUtilidades.stringToDateDDMMYYYY(bean.getFecProrroga()));
				if(!MaestrosUtilidades.isEmpty(bean.getNumDocumento()))model.setNumDocumento(bean.getNumDocumento());
				if(!MaestrosUtilidades.isEmpty(bean.getNumOrden())&&bean.getNumOrden()>0)model.setNumOrden(MaestrosUtilidades.toLong(bean.getNumOrden()));
				if(!MaestrosUtilidades.isEmpty(bean.getNumDocumentoOrden())&&bean.getNumDocumentoOrden()>0)model.setNumDocumentoOrden(MaestrosUtilidades.toLong(bean.getNumDocumentoOrden()));
				if(!MaestrosUtilidades.isEmpty(bean.getNumArc())&&bean.getNumArc()>0)model.setNumArc(MaestrosUtilidades.toLong(bean.getNumArc()));
				
				model.setCodUsuModif(bean.getAuditoriaBean().getLogin());
				model.setDirIpusumodif(bean.getAuditoriaBean().getNumIp());
				model.setFecModif(new Date());
				if(!MaestrosUtilidades.isEmpty(bean.getIndDel())&&MaestrosConstantes.REGISTRO_ELIMINADO.equals(bean.getIndDel())&&
				  !MaestrosUtilidades.isEmpty(bean.getIndEst())&&MaestrosConstantes.REGISTRO_INACTIVO.equals(bean.getIndEst())) {
					model.setIndEliminar(true);
				}
				t10407DocumenOrdenDAO.actualizarDocumentoOrden(model);
			
		return bean;
	}
	
	
	@Override
	public int guardarEstablecimiento(EstablecimientoOrdenBean beanEstab) {
		int resultado=0;
		if(!MaestrosUtilidades.isEmpty(beanEstab.getNumEstablecimientoOrden())&&beanEstab.getNumEstablecimientoOrden()>0) {
			//actualiza
			resultado=actualizarEstablecimientoOrden(beanEstab);
		}else {
			//registra
			EstablecimientoOrden model=new EstablecimientoOrden();
			MaestrosUtilidades.copiarValoresBean(beanEstab, model);
			model.setNumEstablecimientoOrden(t10408EstabOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ESTABLHALLAZGO_ORDEN, AccionesControlConstantes.DATASOURCE_DCSICOBF));
			beanEstab.setNumEstablecimientoOrden(MaestrosUtilidades.toInteger(model.getNumEstablecimientoOrden()));
			model.setCodUsuCrea(beanEstab.getAuditoriaBean().getLogin());
			model.setCodUsuModif(beanEstab.getAuditoriaBean().getLogin());
			model.setDirIpusucrea(beanEstab.getAuditoriaBean().getNumIp());
			model.setDirIpusumodif(beanEstab.getAuditoriaBean().getNumIp());
			model.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			model.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			model.setFecCrea(new Date());
			model.setFecModif(new Date());
			t10408EstabOrdenDAO.save(model, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			resultado++;
		}
		//ACTA
		//dar de baja a todos los registrados
		ActaEstablecimientoBean filtrosEliminar=new ActaEstablecimientoBean();
		filtrosEliminar.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
		filtrosEliminar.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
		filtrosEliminar.setNumEstablecimientoOrden(beanEstab.getNumEstablecimientoOrden());
		filtrosEliminar.setAuditoriaBean(beanEstab.getAuditoriaBean());
		actualizarActaEstab(filtrosEliminar);
		
		if(beanEstab.getLstActaEstablecimiento()!=null&&beanEstab.getLstActaEstablecimiento().size()>0) {
			
			for(ActaEstablecimientoBean actaTemp: beanEstab.getLstActaEstablecimiento()) {
				if(!MaestrosUtilidades.isEmpty(actaTemp.getNumActaEstablecimiento())&&actaTemp.getNumActaEstablecimiento()>0) {
					actaTemp.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					actaTemp.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					actaTemp.setAuditoriaBean(beanEstab.getAuditoriaBean());
					actualizarActaEstab(actaTemp);
				}else {
					ActaEstablecimiento modelActa=new ActaEstablecimiento();
					MaestrosUtilidades.copiarValoresBean(actaTemp, modelActa);
					modelActa.setNumActaEstablecimiento(t10408EstabOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ACTA_ESTABLECIMIENTO, AccionesControlConstantes.DATASOURCE_DCSICOBF));
					modelActa.setNumEstablecimientoOrden(beanEstab.getNumEstablecimientoOrden());
					modelActa.setCodUsuCrea(beanEstab.getAuditoriaBean().getLogin());
					modelActa.setCodUsuModif(beanEstab.getAuditoriaBean().getLogin());
					modelActa.setDirIpusucrea(beanEstab.getAuditoriaBean().getNumIp());
					modelActa.setDirIpusumodif(beanEstab.getAuditoriaBean().getNumIp());
					modelActa.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					modelActa.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					modelActa.setFecCrea(new Date());
					modelActa.setFecModif(new Date());
					t10385ActaEstabDAO.save(modelActa, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
		}
		//ACTIVIDAD
		//dar de baja a todos los registrados
		ActividadEstablecimientoBean filElimActiv=new ActividadEstablecimientoBean();
		filElimActiv.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
		filElimActiv.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
		filElimActiv.setNumEstablecimientoOrden(beanEstab.getNumEstablecimientoOrden());
		filElimActiv.setAuditoriaBean(beanEstab.getAuditoriaBean());
		actualizarActividadEstablecimiento(filElimActiv);
		
		if(beanEstab.getLstActividadEstablecimiento()!=null && beanEstab.getLstActividadEstablecimiento().size()>0) {
			for(ActividadEstablecimientoBean actBeanTemp:beanEstab.getLstActividadEstablecimiento()) {
				if(MaestrosConstantes.REGISTRO_ACTIVO.equals(actBeanTemp.getIndSeleccionado())) {
					if(!MaestrosUtilidades.isEmpty(actBeanTemp.getNumActividadEstablecimiento())&&actBeanTemp.getNumActividadEstablecimiento()>0) {
												
							ActividadEstablecimientoBean actaBeanActu=new ActividadEstablecimientoBean();
							actaBeanActu.setNumActividadEstablecimiento(actBeanTemp.getNumActividadEstablecimiento());
							actaBeanActu.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
							actaBeanActu.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
							actaBeanActu.setAuditoriaBean(beanEstab.getAuditoriaBean());
							actualizarActividadEstablecimiento(actaBeanActu);
						
					}else {
						
						ActividadEstablecimiento modelActiv=new ActividadEstablecimiento();
						MaestrosUtilidades.copiarValoresBean(actBeanTemp, modelActiv);
						modelActiv.setNumActividadEstablecimiento(t10386ActividEstabDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ACTA_ESTABLECIMIENTO, AccionesControlConstantes.DATASOURCE_DCSICOBF));
						modelActiv.setNumEstablecimientoOrden(beanEstab.getNumEstablecimientoOrden());
						modelActiv.setCodUsuCrea(beanEstab.getAuditoriaBean().getLogin());
						modelActiv.setCodUsuModif(beanEstab.getAuditoriaBean().getLogin());
						modelActiv.setDirIpusucrea(beanEstab.getAuditoriaBean().getNumIp());
						modelActiv.setDirIpusumodif(beanEstab.getAuditoriaBean().getNumIp());
						modelActiv.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
						modelActiv.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
						modelActiv.setFecCrea(new Date());
						modelActiv.setFecModif(new Date());
						t10386ActividEstabDAO.save(modelActiv,  AccionesControlConstantes.DATASOURCE_DGSICOBF);
					}
				}
			}
		}
		//BIEN
		//desactivar todos
		BienEstablecimientoBean filElimBien=new BienEstablecimientoBean();
		filElimBien.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
		filElimBien.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
		filElimBien.setNumEstablecimientoOrden(beanEstab.getNumEstablecimientoOrden());
		filElimBien.setAuditoriaBean(beanEstab.getAuditoriaBean());
		actualizarBienEstabOrden(filElimBien);
		
		if(beanEstab.getLstBienEstablecimiento()!=null && beanEstab.getLstBienEstablecimiento().size()>0) {
			for( BienEstablecimientoBean bienBeanTemp: beanEstab.getLstBienEstablecimiento() ) {
				if(!MaestrosUtilidades.isEmpty(bienBeanTemp.getNumBienEstablecimiento())&&bienBeanTemp.getNumBienEstablecimiento()>0) {
					//actualizar
					bienBeanTemp.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					bienBeanTemp.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					bienBeanTemp.setAuditoriaBean(beanEstab.getAuditoriaBean());
					actualizarBienEstabOrden(bienBeanTemp);
				}else {
					BienEstablecimiento modelBien=new BienEstablecimiento();
					//MaestrosUtilidades.copiarValoresBean(bienBeanTemp, modelBien);
					if(bienBeanTemp.getCodTipoBien()!=null)modelBien.setCodTipoBien(bienBeanTemp.getCodTipoBien());
				    if(bienBeanTemp.getCodBienFiscalizado()!=null)modelBien.setCodBienFiscalizado(bienBeanTemp.getCodBienFiscalizado());
				    if(bienBeanTemp.getDesBien()!=null)modelBien.setDesBien(bienBeanTemp.getDesBien());
				    if(bienBeanTemp.getFecStockFisico()!=null)modelBien.setFecStockFisico(MaestrosUtilidades.stringToDateDDMMYYYY(bienBeanTemp.getFecStockFisico()));
				    if(bienBeanTemp.getHorStockFisico()!=null)modelBien.setHorStockFisico(MaestrosUtilidades.stringToDate(bienBeanTemp.getHorStockFisico(), MaestrosConstantes.FORMAT_HORA_HHMMSS));
				    if(!MaestrosUtilidades.isEmpty(bienBeanTemp.getCantidadStockFisico())&&bienBeanTemp.getCantidadStockFisico()>0)modelBien.setCantidadStockFisico(bienBeanTemp.getCantidadStockFisico());
				    if(bienBeanTemp.getCodUnidadMedida()!=null)modelBien.setCodUnidadMedida(bienBeanTemp.getCodUnidadMedida());
				    				
					modelBien.setNumBienEstablecimiento(t10395BienEstabDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_BIEN_ESTABLECIMIENTO, AccionesControlConstantes.DATASOURCE_DCSICOBF));
					bienBeanTemp.setNumBienEstablecimiento(MaestrosUtilidades.toInteger(modelBien.getNumBienEstablecimiento()));
					modelBien.setNumEstablecimientoOrden(MaestrosUtilidades.toLong(beanEstab.getNumEstablecimientoOrden()));
					modelBien.setCodUsuCrea(beanEstab.getAuditoriaBean().getLogin());
					modelBien.setCodUsuModif(beanEstab.getAuditoriaBean().getLogin());
					modelBien.setDirIpusucrea(beanEstab.getAuditoriaBean().getNumIp());
					modelBien.setDirIpusumodif(beanEstab.getAuditoriaBean().getNumIp());
					modelBien.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					modelBien.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					modelBien.setFecCrea(new Date());
					modelBien.setFecModif(new Date());
					t10395BienEstabDAO.save(modelBien, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
				
				
				// ACTA BIEN
				//desactivar todos
				ActaBienOrdenBean filActaBienElim=new ActaBienOrdenBean();
				filActaBienElim.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
				filActaBienElim.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				filActaBienElim.setNumBienEstablecimiento(bienBeanTemp.getNumBienEstablecimiento());
				filActaBienElim.setAuditoriaBean(beanEstab.getAuditoriaBean());
				actualizarActaBien(filActaBienElim);
				
				if(bienBeanTemp.getLstActaBienEstablecimiento()!=null&&bienBeanTemp.getLstActaBienEstablecimiento().size()>0) {
					for( ActaBienOrdenBean actaBienBeanTemp:bienBeanTemp.getLstActaBienEstablecimiento()) {
						if(!MaestrosUtilidades.isEmpty(actaBienBeanTemp.getNumActaBienOrden())&&actaBienBeanTemp.getNumActaBienOrden()>0) {
							//actualizar
							actaBienBeanTemp.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
							actaBienBeanTemp.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
							actaBienBeanTemp.setAuditoriaBean(beanEstab.getAuditoriaBean());
							actualizarActaBien(actaBienBeanTemp);
						}else {
							ActaBienOrden modelActaBien=new ActaBienOrden();
							MaestrosUtilidades.copiarValoresBean(actaBienBeanTemp, modelActaBien);
							modelActaBien.setNumActaBienOrden(t10384ActBienOrdenDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ACTA_RESULTADOBIENES, AccionesControlConstantes.DATASOURCE_DCSICOBF));
							modelActaBien.setNumBienEstablecimiento(bienBeanTemp.getNumBienEstablecimiento());
							modelActaBien.setCodUsuCrea(beanEstab.getAuditoriaBean().getLogin());
							modelActaBien.setCodUsuModif(beanEstab.getAuditoriaBean().getLogin());
							modelActaBien.setDirIpusucrea(beanEstab.getAuditoriaBean().getNumIp());
							modelActaBien.setDirIpusumodif(beanEstab.getAuditoriaBean().getNumIp());
							modelActaBien.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
							modelActaBien.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
							modelActaBien.setFecCrea(new Date());
							modelActaBien.setFecModif(new Date());
							t10384ActBienOrdenDAO.save(modelActaBien, AccionesControlConstantes.DATASOURCE_DGSICOBF);
						}
					}
				}
			}
		}
		
		
		return resultado;
	}
	
	@Override
	public int actualizarEstablecimientoOrden(EstablecimientoOrdenBean beanEstab) {
		EstablecimientoOrden model=new EstablecimientoOrden();
		MaestrosUtilidades.copiarValoresBean(beanEstab, model);
		
		if(!MaestrosUtilidades.isEmpty(beanEstab.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanEstab.getAuditoriaBean().getLogin()))model.setCodUsuModif(beanEstab.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(beanEstab.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanEstab.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(beanEstab.getAuditoriaBean().getNumIp());
		if(!MaestrosUtilidades.isEmpty(beanEstab.getIndDel())&&
		   MaestrosConstantes.REGISTRO_ELIMINADO.equals(beanEstab.getIndDel())&&
		   !MaestrosUtilidades.isEmpty(beanEstab.getIndEst())&&
		   MaestrosConstantes.REGISTRO_INACTIVO.equals(beanEstab.getIndEst())) {
			model.setIndEliminar(true);
		}
		return t10408EstabOrdenDAO.actualizarEstablecimiento(model);
	}
	
	@Override
	public int actualizarActaEstab(ActaEstablecimientoBean beanActa) {
		ActaEstablecimiento model=new ActaEstablecimiento();
		MaestrosUtilidades.copiarValoresBean(beanActa, model);
		
		if(!MaestrosUtilidades.isEmpty(beanActa.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanActa.getAuditoriaBean().getLogin()))model.setCodUsuModif(beanActa.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(beanActa.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanActa.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(beanActa.getAuditoriaBean().getNumIp());
		if(!MaestrosUtilidades.isEmpty(beanActa.getIndDel())&&
		   MaestrosConstantes.REGISTRO_ELIMINADO.equals(beanActa.getIndDel())&&
		   !MaestrosUtilidades.isEmpty(beanActa.getIndEst())&&
		   MaestrosConstantes.REGISTRO_INACTIVO.equals(beanActa.getIndEst())) {
			model.setIndEliminar(true);
		}
		return t10385ActaEstabDAO.actualizarActaEstab(model);
	}
	
	
	@Override
	public int actualizarActividadEstablecimiento(ActividadEstablecimientoBean beanActividad) {
		ActividadEstablecimiento model=new ActividadEstablecimiento();
		MaestrosUtilidades.copiarValoresBean(beanActividad, model);
		if(!MaestrosUtilidades.isEmpty(beanActividad.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanActividad.getAuditoriaBean().getLogin()))model.setCodUsuModif(beanActividad.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(beanActividad.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanActividad.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(beanActividad.getAuditoriaBean().getNumIp());
		
		return t10386ActividEstabDAO.actualizarActividadOrden(model);
	}
	
	@Override
	public int actualizarBienEstabOrden(BienEstablecimientoBean beanBien) {
		
		BienEstablecimiento model=new BienEstablecimiento(); 
		//MaestrosUtilidades.copiarValoresBean(beanBien, model);
		if(!MaestrosUtilidades.isEmpty(beanBien.getNumBienEstablecimiento())&&beanBien.getNumBienEstablecimiento()>0)model.setNumBienEstablecimiento(MaestrosUtilidades.toLong(beanBien.getNumBienEstablecimiento()));
		if(!MaestrosUtilidades.isEmpty(beanBien.getNumEstablecimientoOrden())&&beanBien.getNumEstablecimientoOrden()>0)model.setNumEstablecimientoOrden(MaestrosUtilidades.toLong(beanBien.getNumEstablecimientoOrden()));	
	    if(beanBien.getCodTipoBien()!=null)model.setCodTipoBien(beanBien.getCodTipoBien());
	    if(beanBien.getCodBienFiscalizado()!=null)model.setCodBienFiscalizado(beanBien.getCodBienFiscalizado());
	    if(beanBien.getDesBien()!=null)model.setDesBien(beanBien.getDesBien());
	    if(beanBien.getFecStockFisico()!=null)model.setFecStockFisico(MaestrosUtilidades.stringToDateDDMMYYYY(beanBien.getFecStockFisico()));
	    if(beanBien.getHorStockFisico()!=null)model.setHorStockFisico(MaestrosUtilidades.stringToDate(beanBien.getHorStockFisico(), MaestrosConstantes.FORMAT_HORA_HHMMSS));
	    if(!MaestrosUtilidades.isEmpty(beanBien.getCantidadStockFisico())&&beanBien.getCantidadStockFisico()>0)model.setCantidadStockFisico(beanBien.getCantidadStockFisico());
	    if(beanBien.getCodUnidadMedida()!=null)model.setCodUnidadMedida(beanBien.getCodUnidadMedida());
	    
	    if(beanBien.getIndDel()!=null)model.setIndDel(beanBien.getIndDel());
	    if(beanBien.getIndEst()!=null)model.setIndEst(beanBien.getIndEst());

		if(!MaestrosUtilidades.isEmpty(beanBien.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanBien.getAuditoriaBean().getLogin()))model.setCodUsuModif(beanBien.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(beanBien.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanBien.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(beanBien.getAuditoriaBean().getNumIp());
		
		return t10395BienEstabDAO.actualizarBienEstab(model);
	}
	
	@Override
	public int actualizarActaBien(ActaBienOrdenBean beanActaBien) {
		ActaBienOrden model=new ActaBienOrden();
		MaestrosUtilidades.copiarValoresBean(beanActaBien, model);
		if(!MaestrosUtilidades.isEmpty(beanActaBien.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanActaBien.getAuditoriaBean().getLogin()))model.setCodUsuModif(beanActaBien.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(beanActaBien.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanActaBien.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(beanActaBien.getAuditoriaBean().getNumIp());
		
		return t10384ActBienOrdenDAO.actualizarActaBien(model);
	}
	
	
	@Override
	public int actualizarSuspencionOrden(SuspensionOrdenBean beanSuspension) {
		SuspensionOrden model=new SuspensionOrden();
		MaestrosUtilidades.copiarValoresBean(beanSuspension, model);
		if(!MaestrosUtilidades.isEmpty(beanSuspension.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanSuspension.getAuditoriaBean().getLogin()))model.setCodUsuModif(beanSuspension.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(beanSuspension.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanSuspension.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(beanSuspension.getAuditoriaBean().getNumIp());
		
		return t10422SuspensOrdenDAO.actualizarSuspension(model);
	}
	
	
	@Override
	public int actualizarInconsistenciaOrden(TipoInconsistenciaOrdenBean beanTipIncon) {
		TipoInconsistenciaOrden model=new TipoInconsistenciaOrden();
		MaestrosUtilidades.copiarValoresBean(beanTipIncon, model);
		if(!MaestrosUtilidades.isEmpty(beanTipIncon.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanTipIncon.getAuditoriaBean().getLogin()))model.setCodUsuModif(beanTipIncon.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(beanTipIncon.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanTipIncon.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(beanTipIncon.getAuditoriaBean().getNumIp());
		
		return t10424TipIncoOrdenDAO.actualizarInconsistenciaOtro(model);
	}
	
	@Override
	public int actualizarDetalleResultadoOrden(DetalleResultadoOrdenBean beanDetaResu) {
		DetalleResultadoOrden model=new DetalleResultadoOrden();
		MaestrosUtilidades.copiarValoresBean(beanDetaResu, model);
		if(!MaestrosUtilidades.isEmpty(beanDetaResu.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanDetaResu.getAuditoriaBean().getLogin()))model.setCodUsuModif(beanDetaResu.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(beanDetaResu.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanDetaResu.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(beanDetaResu.getAuditoriaBean().getNumIp());
		
		return t10404DetaResOrdenDAO.actualizarDetaResultado(model);
	}
	
	@Override
	public int actualizarActividadOrden(ActividadOrdenBean beanActividadOrden) {
		ActividadOrden model=new ActividadOrden();
		MaestrosUtilidades.copiarValoresBean(beanActividadOrden, model);
		if(!MaestrosUtilidades.isEmpty(beanActividadOrden.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanActividadOrden.getAuditoriaBean().getLogin()))model.setCodUsuModif(beanActividadOrden.getAuditoriaBean().getLogin());
		if(!MaestrosUtilidades.isEmpty(beanActividadOrden.getAuditoriaBean())&&!MaestrosUtilidades.isEmpty(beanActividadOrden.getAuditoriaBean().getNumIp()))model.setDirIpusumodif(beanActividadOrden.getAuditoriaBean().getNumIp());
		
		return t10387ActividOrdenDAO.actualizarActividadOrden(model);
	}
	
}

