package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;


@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class MantenimientoProgramaServiceImpl implements MantenimientoProgramaService {
	

@EJB
private T8276CatProgCtrlDAO t8276CatProgCtrlDAO;
	 
	 public MantenimientoProgramaServiceImpl() {
		}

	 @Override
	 public  List<ProgramaControlBean> listarProgramaControl(String nombrePrograma,String estadoPrograma) {
		 
		 	List<ProgramaControlBean> listaPrograma = new ArrayList<ProgramaControlBean>();
		 
		    PropertyParams propertyParams = new PropertyParams();
		    if (!MaestrosUtilidades.isEmpty(nombrePrograma)) {
				propertyParams.addPropertyOperador("desDenominacion", "%" + nombrePrograma + "%", "LIKE");	
		    }
			if (!MaestrosUtilidades.isEmpty(estadoPrograma)) {
				propertyParams.addProperty("indEst", estadoPrograma);	
			}
			propertyParams.addProperty("indDel", AccionesControlConstantes.REGISTRO_NOELIMINADO);
			List<ProgramaControl> t8276CatProgCtrl= t8276CatProgCtrlDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		 
		 if (!MaestrosUtilidades.isEmpty(t8276CatProgCtrl)) {
			 ProgramaControlBean programaControlBean = null;
				for (ProgramaControl valores : t8276CatProgCtrl) {
					programaControlBean = new ProgramaControlBean();
					MaestrosUtilidades.copiarValoresBean(valores, programaControlBean);
					programaControlBean.setIndEstado(valores.getIndEst());//
					if(valores.getIndEst().equals("1")){
						programaControlBean.setDesEstado(AccionesControlConstantes.COD_DESCRIP_INDICADOR_ACTIVO);
					}else{
						programaControlBean.setDesEstado(AccionesControlConstantes.COD_DESCRIP_INDICADOR_INACTIVO);
					}
					listaPrograma.add(programaControlBean);
				}
			}
		 
			return listaPrograma;
	 }
	 
	 
	 @Override
	 public ProgramaControlBean guardarEstadoPrograma(ProgramaControlBean programaControlBean) {
		 ProgramaControl actualizar = t8276CatProgCtrlDAO.findById(programaControlBean.getCodProgctrl(), AccionesControlConstantes.DATASOURCE_DGSICOBF);

			actualizar.setCodProgctrl(programaControlBean.getCodProgctrl());
			actualizar.setIndEst(programaControlBean.getIndEstado());	

			// auditoria
			actualizar.setDirIpusumodif(programaControlBean.getAuditoriaBean().getNumIp());
			actualizar.setCodUsuModif(programaControlBean.getAuditoriaBean().getLogin());
			// auditoria
			t8276CatProgCtrlDAO.update(actualizar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			
			ProgramaControlBean resultado=new ProgramaControlBean();
			resultado.setCodProgctrl(programaControlBean.getCodProgctrl());
			resultado.setIndEstado(programaControlBean.getIndEstado());
		    return resultado;
	 }

	 @Override
		public List<ProgramaControlBean> cargarDatosPrograma(String codProgctrl) {

		 List<ProgramaControlBean> listaPrograma = new ArrayList<ProgramaControlBean>();
		 
		 PropertyParams propertyParams = new PropertyParams();
			propertyParams.addProperty("codProgctrl", codProgctrl);
			List<ProgramaControl> t8276CatProgCtrl= t8276CatProgCtrlDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		 
			 if (!MaestrosUtilidades.isEmpty(t8276CatProgCtrl)) {
				 ProgramaControlBean programaControlBean = null;
					for (ProgramaControl valores : t8276CatProgCtrl) {
						programaControlBean = new ProgramaControlBean();
						MaestrosUtilidades.copiarValoresBean(valores, programaControlBean);
						listaPrograma.add(programaControlBean);
					}
				}
			return listaPrograma;
	 	}
	 

	 @Override	
	 public ProgramaControlBean guardarDatosPrograma(ProgramaControlBean programaControlBean){
		 
		 ProgramaControl actualizar =  t8276CatProgCtrlDAO.findById(programaControlBean.getCodProgctrl(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		 
		 actualizar.setCodProgctrl(programaControlBean.getCodProgctrl());
		 actualizar.setDesAlcance(programaControlBean.getDesAlcance());
		 actualizar.setDesDenominacion(programaControlBean.getDesDenominacion());
		 actualizar.setNumPlazo(programaControlBean.getNumPlazo());
		 actualizar.setCodUnidadOrganica(programaControlBean.getCodUnidadOrganica());
		 actualizar.setIndInformeSelec(programaControlBean.getIndInformeSelec());
		 actualizar.setIndCierre(programaControlBean.getIndCierre());
		// auditoria
		actualizar.setDirIpusumodif(programaControlBean.getAuditoriaBean().getNumIp());
		actualizar.setCodUsuModif(programaControlBean.getAuditoriaBean().getLogin());
		// auditoria
		 t8276CatProgCtrlDAO.update(actualizar, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		return programaControlBean;
	 }
	 
	 
}
