package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;
/*import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;*/
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.T9494ArcDigit;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.T9495DocDigit;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T9494ArchivoDigitalDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T9495DocumentoDigitalDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ArchivoDigitalizadosServiceImpl implements ArchivoDigitalizadosService{

	private static final Logger logger = LoggerFactory.getLogger(ArchivoDigitalizadosServiceImpl.class);
	
	@EJB
	T9495DocumentoDigitalDAO t9495DocDigitDAO;
	
	@EJB
	T9494ArchivoDigitalDAO t9494ArcDigitDAO;
	
	
	@Override
	public File obtenerFirmaConNombrePorPersona(String codRegPersona) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio ArchivoDigitalizadosServiceImpl - obtenerFirmaPorPersona");
		
		File firma = null;
		
		PropertyParams params = new PropertyParams();
		
		params.addProperty("codRegPersona", codRegPersona);
		params.addProperty("codTipo", AccionesControlConstantes.COD_TIPO_FIRMA_DIGITALIZADAS);
		params.addProperty("codSubTipo", AccionesControlConstantes.COD_SUBTIPO_FIRMA_CON_NOMBRE);
		params.addProperty("indActivo", AccionesControlConstantes.IND_ACTIVO_REGISTRO);
		List<T9495DocDigit> lista = t9495DocDigitDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSPAC);

		if(!MaestrosUtilidades.isEmpty(lista)){
			T9495DocDigit docDigit = lista.get(0);
			logger.info("docDigit => " + docDigit);
			
			params = new PropertyParams();
			params.addProperty("numArcDigit", docDigit.getNumArcDigit());

			List<T9494ArcDigit> listaArc = t9494ArcDigitDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSPAC);
			if(!MaestrosUtilidades.isEmpty(listaArc)){
				T9494ArcDigit arcDigit = listaArc.get(0);
				logger.info("arcDigit => " + arcDigit);
				
				firma = new File(AccionesControlConstantes.RUTA_TEMPORAL_FIRMA.concat(arcDigit.getNombreArchivo()));
				FileOutputStream fos = null;
				try
				{
					fos = new FileOutputStream(firma);
					fos.write(arcDigit.getArcDigit());
				} catch (Exception e) {
					logger.error("e => " + e.getMessage(), e);
				} finally {
					AccionesControlUtil.cerrarStream(fos);
				}
				logger.info("firma.getAbsolutePath() => " + firma.getAbsolutePath());
			}
		}
		if (logger.isDebugEnabled())
			logger.debug("Fin ArchivoDigitalizadosServiceImpl - obtenerFirmaPorPersona");

		return firma;
	}
	@Override
	public JasperPrint generarBytePlantillaJasper(Map<String, Object> parameters, String rutaJasper ,JRDataSource dataSource){
		
		if (logger.isDebugEnabled())
			logger.debug("Inicio ArchivoDigitalizadosServiceImpl - generarBytePlantillaJasper");
		
		JasperPrint jasperPrint=null;
		try {		
			jasperPrint = JasperFillManager.fillReport(rutaJasper, parameters, dataSource);
		
		} catch (JRException excepcion) {
			logger.debug("Excepci�n - generarBytePlantillaJasper : ", excepcion);
		}

		if (logger.isDebugEnabled())
			logger.debug("Fin ArchivoDigitalizadosServiceImpl - generarBytePlantillaJasper");
		
		return jasperPrint;
	}

	@Override
	public byte[] convertirJasperPrintByte(List<JasperPrint> lstJasperPrints){

		byte[] bytesReporte=new byte[1024];
	    JRPdfExporter jrPdfExporter = new JRPdfExporter();

	    if (logger.isDebugEnabled())
			logger.debug("Inicio ArchivoDigitalizadosServiceImpl - convertirJasperPrintByte");

	    try 
	    {
	    	ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	    	jrPdfExporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, lstJasperPrints);
	    	jrPdfExporter.setParameter(JRExporterParameter.OUTPUT_STREAM, byteArrayOutputStream);
			jrPdfExporter.exportReport();
			bytesReporte = byteArrayOutputStream.toByteArray();
		} catch (JRException excepcion) {
			logger.debug("Excepci�n - convertirJasperPrintByte : ", excepcion);
		}

	    if (logger.isDebugEnabled())
			logger.debug("Fin ArchivoDigitalizadosServiceImpl - convertirJasperPrintByte");
	    return bytesReporte;
	}
}
