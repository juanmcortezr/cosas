package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.accessibility.internal.resources.accessibility;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ArchivoInformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaUsuarioAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoDataAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoInformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaUsuarioAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10390ArcInformeDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10394AsignaUsuAccDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10406DocumentoAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10445ArcAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10446ArcDataAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class CompletarInformeServiceImpl implements CompletarInformeService {

	private static final Logger logger = LoggerFactory.getLogger(CompletarInformeServiceImpl.class);

	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;
	
	@EJB
	private T10445ArcAcfDAO t10445ArcAcfDAO;
	
	@EJB
	private T10446ArcDataAcfDAO t10446ArcDataAcfDAO;
	
	@EJB
	private T10406DocumentoAccionDAO t10406DocumentoAccionDAO;

	@EJB
	private DataCatalogoService dataCatalogoService;
	
	@EJB
	private T10394AsignaUsuAccDAO t10394AsignaUsuAccDAO;
	
	@EJB
	private T10411InformeSelecDAO t10411InformeSelecDAO;
	
	@EJB
	private T10390ArcInformeDAO t10390ArcInformeDAO;
	
	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private GestionProgramaAsignadoService gestionProgramaAsignadoService;
	
	@EJB 
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;
	
	@EJB(name="accionescontrol.comunService")
	private ComunService comunService;
	
	@Override
	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro) {
		
		List<ProgramacionBean> listaPrograma=new ArrayList<ProgramacionBean>();

		Programacion parametros=new Programacion();
		parametros.setNumProgramacion(filtro.getNumProgramacion());
		parametros.setDesAlcance(filtro.getDesAlcance());
		parametros.setNumInforme(filtro.getNumInforme());
		parametros.setNroInformeUnion(filtro.getNroInformeUnion());
		parametros.setFechaDesde(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
		parametros.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
		parametros.setCodProgramador(filtro.getCodProgramador());
	
        List<Programacion> t10420Programacion= t10420ProgramacionDAO.listarProgramacion(parametros);
        if (!MaestrosUtilidades.isEmpty(t10420Programacion)) {
        	ProgramacionBean programacionBean=null;
	        for (Programacion programacion : t10420Programacion) {
	        	programacionBean = new ProgramacionBean();
	        	MaestrosUtilidades.copiarValoresBean(programacion, programacionBean);
	        	programacionBean.setCodEstadoInforme(programacion.getCodEstadoInforme());
				programacionBean.setNumInforme(programacion.getNumInforme());
				programacionBean.setNroInformeUnion(programacion.getNroInformeUnion());
				programacionBean.setCodProgramaControl(programacion.getCodProgctrl());
				programacionBean.setDesProgramaControl(programacion.getDesProgctrl());
				programacionBean.setNumProgramacion(programacion.getNumProgramacion());
				programacionBean.setCodProgramador(programacion.getCodProgramador());
				programacionBean.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(programacion.getFecProgramacion()));	        	
	        	obtenerDatosCatalogo(programacionBean, programacion);
	        	listaPrograma.add(programacionBean);
			}
			if (!MaestrosUtilidades.isEmpty(filtro.getDesProgramador())) {
				listaPrograma = AccionesControlUtil.listByDesProgramador(listaPrograma, filtro);
			}
        }        

		return listaPrograma;
	}	
	private void obtenerDatosCatalogo(ProgramacionBean programacionBean,Programacion programacion){
		WSPersonalIqbfBean programador = servicioWebService.obtenerPersonalIqbf(programacion.getCodProgramador());
    	programacionBean.setNomProgramador("");
    	if (!MaestrosUtilidades.isEmpty(programador)) {
    		programacionBean.setNomProgramador(programador.getNomCompleto());
    		programacionBean.setDesProgramador(programador.getNomCompleto());
    	}
    	DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_FUENTES_PROGRAMAS, programacion.getCodFuente());
    	programacionBean.setDesFuente("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesFuente(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_PROGRAMACION, programacion.getCodTipoProgram());
    	programacionBean.setDesTipoProgram("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesTipoProgram(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS, programacion.getCodEstadoPrograma());
    	programacionBean.setDesEstadoProgram("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesEstadoProgram(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_SUBESTADOS_PROGRAMACION, programacion.getCodSubEstadoProgram());
    	programacionBean.setDesSubEstprogram("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesSubEstprogram(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_PROCESOS_PROGRAMACION, programacion.getCodProceso());
    	programacionBean.setDesProceso("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesProceso(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_INFORMESELECCION, programacion.getCodEstadoInforme());
    	programacionBean.setDesEstadoInforme("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesEstadoInforme(catalogo.getDescripcionDataCatalogo().trim());
    	}    	
	}
	@Override
	public ProgramacionBean obtenerDatosProgramacion(Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeServiceImpl - obtenerDatosProgramacion");
		return gestionProgramaAsignadoService.obtenerDatosProgramacion(numProgramacion);
	}

	@Override
	public UsuarioProgramacionBean obtenerDatosAccion(Long numUsuarioProgram) {	
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioPrograma", numUsuarioProgram);
		propertyParams.addProperty("codCargo", AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		propertyParams.addProperty("indEst", AccionesControlConstantes.REGISTRO_ACTIVO);
		propertyParams.addProperty("indDel", AccionesControlConstantes.REGISTRO_NOELIMINADO);
        List<AsignaUsuarioAccion> t10394AsignaUsuAcc=  t10394AsignaUsuAccDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
    	AsignaUsuarioAccionBean asignaUsuarioAccionBean=null;
    	UsuarioProgramacionBean usuarioProgramacionBean =  null;
        if (!MaestrosUtilidades.isEmpty(t10394AsignaUsuAcc)) {
		AsignaUsuarioAccion asignaUsuarioAccion= t10394AsignaUsuAcc.get(0);
		UsuarioProgramacion usuarioProgramacion =  t10428UsuarioProgDAO.findById(asignaUsuarioAccion.getNumUsuarioPrograma(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
			asignaUsuarioAccionBean= new AsignaUsuarioAccionBean();
			usuarioProgramacionBean = new UsuarioProgramacionBean();
			MaestrosUtilidades.copiarValoresBean(asignaUsuarioAccion, asignaUsuarioAccionBean);
          	DataCatalogoBean catalogo = null;
        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL,asignaUsuarioAccion.getCodCargo());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				asignaUsuarioAccionBean.setDesCargo(catalogo.getDescripcionDataCatalogo());
			}	
			catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF,usuarioProgramacion.getCodTipoDocumentoIdentif());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				usuarioProgramacionBean.setDesTipoDocumentoIdent(catalogo.getDescripcionDataCatalogo());
			}
			catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL,usuarioProgramacion.getCodTipoAccion());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				usuarioProgramacionBean.setDesTipoAccion(catalogo.getDescripcionDataCatalogo());
			}
			catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INTERVENCION,usuarioProgramacion.getCodTipoIntervencion());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				usuarioProgramacionBean.setDesTipoIntervencion(catalogo.getDescripcionDataCatalogo());
			}
			
        	if (!MaestrosUtilidades.isEmpty(asignaUsuarioAccion.getCodAuditor())) {
    			WSPersonalIqbfBean data = servicioWebService.obtenerPersonalIqbf(asignaUsuarioAccion.getCodAuditor());
    			if (!MaestrosUtilidades.isEmpty(data)) {
    	        	usuarioProgramacionBean.setNomAuditor(data.getNomCompleto());
    			}else{
    				usuarioProgramacionBean.setNomAuditor("");
    			}
    		}
        	usuarioProgramacionBean.setNumDocumentoIdentif(usuarioProgramacion.getNumDocumentoIdentif());
        	usuarioProgramacionBean.setNomApellidoUsuario(usuarioProgramacion.getNomApellidoUsuario());
        	usuarioProgramacionBean.setCantidadDiasAtencion(usuarioProgramacion.getCantidadDiasAtencion());
        	usuarioProgramacionBean.setHorIniCaso(usuarioProgramacion.getHorIniCaso());
        	usuarioProgramacionBean.setFecInicioCaso(MaestrosUtilidades.dateToStringDDMMYYYY(usuarioProgramacion.getFecInicioCaso()));
        	asignaUsuarioAccionBean.setFecInicioAsignacion(MaestrosUtilidades.dateToStringDDMMYYYY(asignaUsuarioAccion.getFecInicioAsignacion()));
        	asignaUsuarioAccionBean.setFecFinAsignacion(MaestrosUtilidades.dateToStringDDMMYYYY(asignaUsuarioAccion.getFecFinAsignacion()));
		}
     
       
		return usuarioProgramacionBean;
	}
	
	@Override
	public List<DocumentoAccionBean> obtenerDatosDocAccion(Long numDocAccion){
		List<DocumentoAccionBean> lista =new ArrayList<DocumentoAccionBean>();
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numDocumentoAccion", numDocAccion);
		List<DocumentoAccion> t10406DocumentoAccion=t10406DocumentoAccionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10406DocumentoAccion)) {
			DocumentoAccionBean documentoAccionBean=null;
		for (DocumentoAccion documentoAccion : t10406DocumentoAccion) {
			documentoAccionBean=new DocumentoAccionBean();
			
          	DataCatalogoBean catalogo = null;
        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_DOCUMENTO_ADICIONALACCION,documentoAccion.getCodTipoDocumento());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				documentoAccionBean.setDesTipoDocumento(catalogo.getDescripcionDataCatalogo());
			}
			
			lista.add(documentoAccionBean);
		}
		}
		return lista;
	}
	
	@Override
	public List<DocumentoAccionBean> listarDocumentoAccion(Long numUsuarioProgramacion) {
		List<DocumentoAccionBean> lista =new ArrayList<DocumentoAccionBean>();
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numUsuarioPrograma", numUsuarioProgramacion);
		propertyParams.addProperty("indDel", AccionesControlConstantes.REGISTRO_NOELIMINADO);
		propertyParams.addProperty("indEst", AccionesControlConstantes.REGISTRO_ACTIVO);
		List<DocumentoAccion> t10406DocumentoAccion=t10406DocumentoAccionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10406DocumentoAccion)) {
			DocumentoAccionBean documentoAccionBean=null;
		for (DocumentoAccion documentoAccion : t10406DocumentoAccion) {
			documentoAccionBean =new DocumentoAccionBean();
			MaestrosUtilidades.copiarValoresBean(documentoAccion, documentoAccionBean);
          	DataCatalogoBean catalogo = null;
        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CLASE_DOCUMENTO,documentoAccion.getCodClase());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				documentoAccionBean.setDesClase(catalogo.getDescripcionDataCatalogo());
			}
			
        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL,documentoAccion.getCodTipoDocumento());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				documentoAccionBean.setDesTipoDocumento(catalogo.getDescripcionDataCatalogo());
			}
			
        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_DOCUMENTO_ACCION,documentoAccion.getCodEstadoDocumento());
			if (!MaestrosUtilidades.isEmpty(catalogo)) {
				documentoAccionBean.setDesEstadoDocumento(catalogo.getDescripcionDataCatalogo());
			}
			documentoAccionBean.setFecEmision(MaestrosUtilidades.dateToStringDDMMYYYY(documentoAccion.getFecEmision()));
			documentoAccionBean.setFecNotificacion(MaestrosUtilidades.dateToStringDDMMYYYY(documentoAccion.getFecNotificacion()));
			// Archivo Bean
			ArchivoBean archivoBean = comunService.obtenerArchivo(documentoAccion.getNumArc());
			if (!MaestrosUtilidades.isEmpty(archivoBean)) {
				documentoAccionBean.setArchivoBean(archivoBean);
			}
			lista.add(documentoAccionBean);	
		}
		}
		return lista;
	}
	
	@Override
	public InformeSeleccionBean guardarInformeSeleccion(InformeSeleccionBean informeSeleccionBean){
		
		
		boolean esRegistro = (informeSeleccionBean.getNumInformeSeleccion() == 0);
		InformeSeleccion informeSeleccion= esRegistro? new InformeSeleccion(): t10411InformeSelecDAO.findById(informeSeleccionBean.getNumInformeSeleccion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
		informeSeleccion.setNumInformeSeleccion(informeSeleccionBean.getNumInformeSeleccion());
		informeSeleccion.setNumProgramacion(informeSeleccionBean.getNumProgramacion());
		informeSeleccion.setNumCorrel(informeSeleccionBean.getNumCorrel());
		informeSeleccion.setAnioInforme(informeSeleccionBean.getAnioInforme());
		informeSeleccion.setCodUnidadOrganica(informeSeleccionBean.getCodUnidadOrganica());
		informeSeleccion.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_CONCLUIDO);

		if(esRegistro){
			// auditoria
			informeSeleccion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			informeSeleccion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			informeSeleccion.setFecCrea(new Date());
			informeSeleccion.setDirIpusucrea(informeSeleccionBean.getAuditoriaBean().getNumIp());
			informeSeleccion.setCodUsuCrea(informeSeleccionBean.getAuditoriaBean().getLogin());
			// auditoria
			t10411InformeSelecDAO.save(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}else{
			// auditoria
			informeSeleccion.setFecModif(new Date());
			informeSeleccion.setDirIpusumodif(informeSeleccionBean.getAuditoriaBean().getNumIp());
			informeSeleccion.setCodUsuModif(informeSeleccionBean.getAuditoriaBean().getLogin());
			// auditoria
			t10411InformeSelecDAO.update(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		return informeSeleccionBean; 
	}
	
	//PENDIENTE 
	@Override
	public UsuarioProgramacion guardarDocumentoInforme(UsuarioProgramacionBean usuarioProgramacionBean){
		
		boolean esRegistro = (usuarioProgramacionBean.getNumProgramacion() == 0);
		UsuarioProgramacion usuarioProgramacion = esRegistro? new UsuarioProgramacion(): t10428UsuarioProgDAO.findById(usuarioProgramacionBean.getNumUsuarioPrograma(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
	
		if(esRegistro){
			usuarioProgramacion.setNumUsuarioPrograma(usuarioProgramacionBean.getNumUsuarioPrograma());
			usuarioProgramacion.setCantidadDiasAtencion(usuarioProgramacionBean.getCantidadDiasAtencion());
			usuarioProgramacion.setNumProgramacion(usuarioProgramacionBean.getNumProgramacion());
			usuarioProgramacion.setFecCrea(new Date());
			usuarioProgramacion.setFecInicioCaso(MaestrosUtilidades.stringToDateDDMMYYYY(usuarioProgramacionBean.getFecInicioCaso()));
			usuarioProgramacion.setHorIniCaso(usuarioProgramacionBean.getHorIniCaso());
			usuarioProgramacion.setIndDel(AccionesControlConstantes.REGISTRO_NOELIMINADO);
			usuarioProgramacion.setIndEst(AccionesControlConstantes.REGISTRO_ACTIVO);
			
			t10428UsuarioProgDAO.save(usuarioProgramacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}else{
			usuarioProgramacion.setCantidadDiasAtencion(usuarioProgramacionBean.getCantidadDiasAtencion());
			usuarioProgramacion.setNumProgramacion(usuarioProgramacionBean.getNumProgramacion());
			usuarioProgramacion.setFecInicioCaso(MaestrosUtilidades.stringToDateDDMMYYYY(usuarioProgramacionBean.getFecInicioCaso()));
			usuarioProgramacion.setHorIniCaso(usuarioProgramacionBean.getHorIniCaso());
			usuarioProgramacion.setDirIpusumodif(usuarioProgramacionBean.getAuditoriaBean().getNumIp());
			usuarioProgramacion.setCodUsuModif(usuarioProgramacionBean.getAuditoriaBean().getLogin());
			usuarioProgramacion.setFecModif(new Date());
			t10428UsuarioProgDAO.update(usuarioProgramacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		// INI Registrar archivo
//		Long numArc = null;
//		boolean esRegistro = (archivoInformeSeleccionBean.getNumArchivoDoc() == null);
//		ArchivoBean archivoBean = archivoInformeSeleccionBean.getArchivoBean();
//		ArchivoInformeSeleccion archivoInformeSeleccion = esRegistro ? new ArchivoInformeSeleccion()
//				: t10390ArcInformeDAO.findById(archivoInformeSeleccionBean.getNumInformeSeleccion(),
//						AccionesControlConstantes.DATASOURCE_DCSICOBF);
//		if (!MaestrosUtilidades.isEmpty(archivoBean)) {
//			archivoBean.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_SOLICITUD);
//			archivoBean.setNumArc(!esRegistro ? archivoInformeSeleccion.getNumArchivo() : null);
//			numArc = comunService.guardarArchivo(archivoBean, archivoInformeSeleccionBean.getAuditoriaBean());
//		}
//		if(esRegistro){
//			archivoInformeSeleccion.setNumArchivoDoc(t10390ArcInformeDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ARCHIVO_INFORME, AccionesControlConstantes.DATASOURCE_DCSICOBF));
//			archivoInformeSeleccion.setNumInformeSeleccion(archivoInformeSeleccionBean.getNumInformeSeleccion());
//			archivoInformeSeleccion.setNumArchivo(numArc);
//			// auditoria
//			archivoInformeSeleccion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
//			archivoInformeSeleccion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
//			archivoInformeSeleccion.setFecCrea(new Date());
//			archivoInformeSeleccion.setDirIpusucrea(archivoInformeSeleccionBean.getAuditoriaBean().getNumIp());
//			archivoInformeSeleccion.setCodUsuCrea(archivoInformeSeleccionBean.getAuditoriaBean().getLogin());		
//			// auditoria
//			t10390ArcInformeDAO.save(archivoInformeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
//			
//		}else{
//			archivoInformeSeleccion.setNumArchivoDoc(archivoInformeSeleccionBean.getNumArchivoDoc());
//			archivoInformeSeleccion.setNumInformeSeleccion(archivoInformeSeleccionBean.getNumInformeSeleccion());
//			archivoInformeSeleccion.setNumArchivo(numArc);
//			archivoInformeSeleccion.setFecModif(new Date());
//			archivoInformeSeleccion.setDirIpusumodif(archivoInformeSeleccionBean.getAuditoriaBean().getNumIp());
//			archivoInformeSeleccion.setCodUsuModif(archivoInformeSeleccionBean.getAuditoriaBean().getLogin());
//			t10390ArcInformeDAO.update(archivoInformeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
//		}
		
		
		return usuarioProgramacion;
	}

	@Override
	public DocumentoAccionBean guardarDocumentoAccion(DocumentoAccionBean documentoAccionBean){
		
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("codTipoDocumento", documentoAccionBean.getCodTipoDocumento());
		propertyParams.addProperty("numDocumento", documentoAccionBean.getNumDocumento());
		propertyParams.addProperty("codClase", AccionesControlConstantes.COD_CLASE_DOCUMENTO_VINCULADO);
		
		List<DocumentoAccion> t10406DocumentoAccion= t10406DocumentoAccionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		Long numDocAccion=documentoAccionBean.getNumDocumentoAccion();
		if (!MaestrosUtilidades.isEmpty(t10406DocumentoAccion)) {
			numDocAccion=t10406DocumentoAccion.get(0).getNumDocumentoAccion();	
		}
		// INI Registrar archivo
		Long numArc = null;
		boolean esRegistro = (numDocAccion==0);
		ArchivoBean archivoBean = documentoAccionBean.getArchivoBean();
		DocumentoAccion documentoAccion = esRegistro ? new DocumentoAccion() : t10406DocumentoAccionDAO.findById(numDocAccion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		if (!MaestrosUtilidades.isEmpty(archivoBean)) {
			logger.debug("Archivo : "+archivoBean.getNumArc() );
			archivoBean.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_SOLICITUD);
			archivoBean.setNumArc(!esRegistro ? documentoAccion.getNumArc() : null);
			numArc = comunService.guardarArchivo(archivoBean, documentoAccionBean.getAuditoriaBean());
		}
		if(esRegistro){
			documentoAccion.setNumDocumentoAccion(t10406DocumentoAccionDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_TIPINCONS_PROGRAMA, AccionesControlConstantes.DATASOURCE_DCSICOBF));
			documentoAccion.setNumUsuarioPrograma(Long.valueOf(documentoAccionBean.getNumUsuarioPrograma()));
			documentoAccion.setCodClase(documentoAccionBean.getCodClase());	
			documentoAccion.setIndOrigen(AccionesControlConstantes.COD_ORIGEN_MANUAL);
			documentoAccion.setCodTipoDocumento(documentoAccionBean.getCodTipoDocumento());
			documentoAccion.setNumDocumento(documentoAccionBean.getNumDocumento());
			documentoAccion.setCodEstadoDocumento(AccionesControlConstantes.COD_ESTADO_DOCUMENTOACCION);
			documentoAccion.setFecEmision(MaestrosUtilidades.stringToDateDDMMYYYY(documentoAccionBean.getFecEmision()));
			documentoAccion.setFecNotificacion(MaestrosUtilidades.stringToDateDDMMYYYY(documentoAccionBean.getFecNotificacion()));
			documentoAccion.setNumArc(numArc);
			// auditoria
			documentoAccion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			documentoAccion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			documentoAccion.setFecCrea(new Date());
			documentoAccion.setDirIpusucrea(documentoAccionBean.getAuditoriaBean().getNumIp());
			documentoAccion.setCodUsuCrea(documentoAccionBean.getAuditoriaBean().getLogin());
			// auditoria
			t10406DocumentoAccionDAO.save(documentoAccion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		}else{
			documentoAccion.setNumDocumentoAccion(documentoAccionBean.getNumDocumentoAccion());
			documentoAccion.setNumUsuarioPrograma(Long.valueOf(documentoAccionBean.getNumUsuarioPrograma()));
			documentoAccion.setFecEmision(MaestrosUtilidades.stringToDateDDMMYYYY(documentoAccionBean.getFecEmision()));
			documentoAccion.setFecNotificacion(MaestrosUtilidades.stringToDateDDMMYYYY(documentoAccionBean.getFecNotificacion()));			
			documentoAccion.setNumArc(numArc);
			documentoAccion.setCodClase(AccionesControlConstantes.COD_CLASE_DOCUMENTO_ACCION);	
			documentoAccion.setIndOrigen(AccionesControlConstantes.COD_ORIGEN_MANUAL);
			documentoAccion.setCodTipoDocumento(documentoAccionBean.getCodTipoDocumento());
			documentoAccion.setNumDocumento(documentoAccionBean.getNumDocumento());
			documentoAccion.setCodEstadoDocumento(AccionesControlConstantes.COD_ESTADO_DOCUMENTOACCION);

			// auditoria
			documentoAccion.setDirIpusumodif(documentoAccionBean.getAuditoriaBean().getNumIp());
			documentoAccion.setCodUsuModif(documentoAccionBean.getAuditoriaBean().getLogin());
			// auditoria
			t10406DocumentoAccionDAO.update(documentoAccion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			
		}
		
		
		return documentoAccionBean;
	}
	
	@Override
	public List<UsuarioProgramacionBean> listarUsuarioProgramacion(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio CompletarInformeServiceImpl - listarUsuarioProgramacion");
		List<UsuarioProgramacionBean> lista= gestionProgramaAsignadoService.listarUsuarioProgramacion(filtro);
		return lista;
	}
	@Override
	public DocumentoAccionBean eliminarDocumentoAccion(Long numDocAccion) {
		DocumentoAccion documentoAccion= t10406DocumentoAccionDAO.findById(numDocAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		documentoAccion.setIndDel(AccionesControlConstantes.REGISTRO_ELIMINADO);
		DocumentoAccion documentoAccionEliminado =t10406DocumentoAccionDAO.update(documentoAccion,  AccionesControlConstantes.DATASOURCE_DGSICOBF);
		DocumentoAccionBean documentoAccionBean = new DocumentoAccionBean();		
		MaestrosUtilidades.copiarValoresBean(documentoAccionEliminado, documentoAccionBean);
		return documentoAccionBean;
	}
	
}
