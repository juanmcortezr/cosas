package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.transaction.Transactional;
import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoDataAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoInformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.HistorialEstadosPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MedioProbatorioUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10390ArcInformeDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10391ArcProgramDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10406DocumentoAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10410HistEstadoProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10412MedioProbUsuDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10445ArcAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10446ArcDataAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.MensajesExcepciones;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.FullUbigeoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.JmsBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.MensajeIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ParametrosBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSUnidadOrgBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.MensajeIqbfService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ParametrosService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.service.UbigeoService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class GestionProgramaAsignadoServiceImpl implements GestionProgramaAsignadoService {

	private static final Logger logger = LoggerFactory.getLogger(GestionProgramaAsignadoServiceImpl.class);

	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private ParametrosService parametrosService;

	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;

	@EJB
	private T8276CatProgCtrlDAO t8276CatProgCtrlDAO;

	@EJB(name="accionescontrol.comunService")
	private ComunService comunService;

	@EJB
	private pe.gob.sunat.iqbf3.registro.maestros.service.ComunService comunServiceMaestros;

	@EJB
	private T10391ArcProgramDAO archivoProgramacionDAO;

	@EJB
	private T10390ArcInformeDAO t10390ArcInformeDAO;

	@EJB
	private T10410HistEstadoProgDAO t10410HistEstadoProgDAO;

	@EJB
	private T10445ArcAcfDAO archivoAccionesDAO;

	@EJB
	private T10446ArcDataAcfDAO archivoDataAccionesDAO;

	@EJB
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;

	@EJB
	private UbigeoService ubigeoService;

	@EJB
	private GestionProgramaOtrosService gestionProgramaOtrosService;
	
	@EJB
	private T10411InformeSelecDAO t10411InformeSelecDAO;
	
	@EJB
	private T10445ArcAcfDAO t10445ArcAcfDAO;
	
	@EJB
	private T10406DocumentoAccionDAO t10406DocumentoAccionDAO;

	@EJB
	private MensajeIqbfService mensajeIqbfService;
	
	@EJB
	private T8414MensajeIqbfDAO t8414MensajeIqbfDAO;
	
	@Override
	public List<ProgramacionBean> listarPrograma(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - listarPrograma");

		logger.debug("Antes => this.comunServiceMaestros.sendMessageWL");
		Programacion filtroModel = new Programacion();
		filtroModel.setDesAlcance(filtro.getDesAlcance());
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
			filtroModel.setCodEstadoPrograma(filtro.getCodEstadoPrograma());	
		} else {
			filtroModel.setEstadosPrograma(Arrays.asList(AccionesControlConstantes.COD_EST_PROGRAM_EN_PROCESO_CARGA,
					AccionesControlConstantes.COD_EST_PROGRAM_ASIGNADO,
					AccionesControlConstantes.COD_EST_PROGRAM_ERROR_CARGA,
					AccionesControlConstantes.COD_EST_PROGRAM_EJECUTADO));
		}
		filtroModel.setFechaDesde(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
		filtroModel.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
		filtroModel.setNumInforme(filtro.getNumInforme());
		filtroModel.setCodEstadoInforme(filtro.getCodEstadoInforme());
		filtroModel.setCodProgctrl(AccionesControlConstantes.COD_OTROS_PROGRAMAS);
		List<ProgramacionBean> lista = new ArrayList<ProgramacionBean>();
		List<Programacion> t10420lista = t10420ProgramacionDAO.listarProgramacion(filtroModel);
		logger.debug(String.format("t10420lista => %s", t10420lista));
		if(!MaestrosUtilidades.isEmpty(t10420lista)) {
			for (Programacion t10420 : t10420lista) {
				ProgramacionBean bean = new ProgramacionBean();
				bean.setDesAlcance(t10420.getDesAlcance());
				bean.setDesProgramacion(t10420.getDesProgramacion());
				bean.setNumProgramacion(t10420.getNumProgramacion());
				bean.setNumProgramaCorrel(t10420.getNumProgramaCorrel());
				bean.setCodProgramaControl(t10420.getCodProgctrl());
				bean.setDesProgramaControl(t10420.getDesProgctrl());
				bean.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10420.getFecProgramacion()));
				bean.setPerFin(t10420.getPerFin());
				bean.setPerInicio(t10420.getPerInicio());
				bean.setDesProgramador("");
				WSPersonalIqbfBean personal = servicioWebService.obtenerPersonalIqbf(t10420.getCodProgramador());
				if (!MaestrosUtilidades.isEmpty(personal)) {
					bean.setDesProgramador(personal.getNomCompleto());
				}
				bean.setFechaIniAsignacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10420.getFechaIniAsignacion()));
				bean.setCodEstadoPrograma(t10420.getCodEstadoPrograma());
				DataCatalogoBean estado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,
						bean.getCodEstadoPrograma());
				bean.setDesEstadoProgram("");
				if (!MaestrosUtilidades.isEmpty(estado)) {
					bean.setDesEstadoProgram(estado.getDescripcionDataCatalogo());
				}
				bean.setNumInforme(t10420.getNumInforme());
				bean.setDesEstadoInforme("");
				estado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_ESTADOS_INFORME_SELECCION,
						bean.getCodEstadoInforme());
				if (!MaestrosUtilidades.isEmpty(estado)) {
					bean.setDesEstadoInforme(estado.getDescripcionDataCatalogo());
				}
				bean.setDesProceso("");
				estado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_PROCESOS_PROGRAMACION,
						bean.getCodProceso());
				if (!MaestrosUtilidades.isEmpty(estado)) {
					bean.setDesProceso(estado.getDescripcionDataCatalogo());
				}
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	public ProgramacionBean obtenerCargarFiscalizable(Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - obtenerCargarFiscalizable");
		ProgramacionBean bean = null;
		Programacion t10420 = t10420ProgramacionDAO.findById(numProgramacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10420)) {
			bean = new ProgramacionBean();
			MaestrosUtilidades.copiarValoresBean(t10420, bean);
			DataCatalogoBean estado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,
					bean.getCodEstadoPrograma());
			bean.setDesEstadoProgram("");
			if (!MaestrosUtilidades.isEmpty(estado)) {
				bean.setDesEstadoProgram(estado.getDescripcionDataCatalogo());
			}
			bean.setDesProgramaControl("");
			ProgramaControl t8276 = t8276CatProgCtrlDAO.findById(t10420.getCodProgctrl(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t8276)) {
				bean.setDesProgramaControl(t8276.getDesDenominacion());
			}
		}
		return bean;
	}

	@Override
	public ArchivoBean descargarPlantilla() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - descargarPlantilla");
		byte[] bytes = null;
		try {
			String rutaArchivo = AccionesControlConstantes.RUTA_PLANTILLA_EXCEL_OTROS;
			File file = new File(rutaArchivo);
			bytes = Files.readAllBytes(file.toPath());
		} catch (Exception e) {
			logger.error("descargarArchivoTemporal:".concat(e.getMessage()), e);
			bytes = null;
		}
		ArchivoBean archivoBean = new ArchivoBean();
		archivoBean.setNomArchivo("ArchivoCargaUsuarios.xlsx");
		archivoBean.setDesMimeType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		archivoBean.setBlobBase64(DatatypeConverter.printBase64Binary(bytes));
		return archivoBean;
	}

	@Override
	public ResponseBean<ProgramacionBean> guardarUniversoFiscalizable(ProgramacionBean programacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - guardarUniversoFiscalizable");
		programacion.getArchivoBean().setCategoria(AccionesControlConstantes.COD_TIP_ARC_CARGA_USUARIO);
		Long numArc = comunService.guardarArchivo(programacion.getArchivoBean(), programacion.getAuditoriaBean());
		
		ArchivoProgramacion t10391 = new ArchivoProgramacion();
		t10391.setNumProgramacion(programacion.getNumProgramacion());
		t10391.setFecCrea(new Date());
		t10391.setCodUsuCrea(programacion.getAuditoriaBean().getLogin());
		t10391.setDirIpusucrea(programacion.getAuditoriaBean().getNumIp());
		t10391.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10391.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10391.setNumArchivo(numArc);
		t10391.setNumArchivoProgram(archivoProgramacionDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ARCHIVOS_PROGRAMACION, AccionesControlConstantes.DATASOURCE_DCSICOBF));
		archivoProgramacionDAO.save(t10391, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		Programacion t10420 = t10420ProgramacionDAO.findById(programacion.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		t10420.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_EN_PROCESO_CARGA);
		t10420.setFecModif(new Date());
		t10420.setCodUsuModif(programacion.getAuditoriaBean().getLogin());
		t10420.setDirIpusumodif(programacion.getAuditoriaBean().getNumIp());
		t10420ProgramacionDAO.update(t10420, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// Historial
		HistorialEstadosPrograma t10410 = new HistorialEstadosPrograma();
		t10410.setNumProgramacion(programacion.getNumProgramacion());
		t10410.setFecEstadoProgram(new Date());
		t10410.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_EN_PROCESO_CARGA);
		t10410.setFecCrea(new Date());
		t10410.setNumHistoriaProgram(t10410HistEstadoProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_HISTORIAL_ESTADOPROG, AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10410.setDirIpusucrea(programacion.getAuditoriaBean().getNumIp());
		t10410.setCodUsuCrea(programacion.getAuditoriaBean().getLogin());
		t10410.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10410.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10410HistEstadoProgDAO.save(t10410, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// Llamar JMS
		this.comunServiceMaestros.sendMessageWL(new JmsBean(AccionesControlConstantes.JMS_CARGAUSUARIO,
				MaestrosUtilidades.toStr(programacion.getNumProgramacion())));

		return new ResponseBean<ProgramacionBean>(true, "Carga exitosa");
	}

	@Override
	public ArchivoBean obtenerDetalleError(Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - obtenerDetalleError");
		ArchivoBean archivoBean = null;
		List<ArchivoAcciones> lstArchivoAcciones = archivoProgramacionDAO.listarArchivosProgramacion(numProgramacion,
				AccionesControlConstantes.COD_TIP_ARC_ERROR_CARGA_USUARIO);
		if (!MaestrosUtilidades.isEmpty(lstArchivoAcciones)) {
			ArchivoAcciones archivoAcciones = lstArchivoAcciones.get(0);
			ArchivoDataAcciones bT10446ArcDataAcf = archivoDataAccionesDAO.findById(archivoAcciones.getNumArc(), AccionesControlConstantes.DATASOURCE_DCSICOBF);

			archivoBean = new ArchivoBean();
			archivoBean.setNomArchivo(archivoAcciones.getNombArchivoAcciones());
			archivoBean.setDesMimeType(archivoAcciones.getDesMimeType());
			archivoBean.setBlobBase64(DatatypeConverter.printBase64Binary(bT10446ArcDataAcf.getArchivoContenido()));
		}
		return archivoBean;
	}

	@Override
	public List<UsuarioProgramacionBean> listarUsuarioProgramacion(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - listarUsuarioProgramacion");
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", filtro.getNumProgramacion());
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		if(!MaestrosUtilidades.isEmpty(filtro.getCodDependencia())) {
			propertyParams.addProperty("codDependencia", filtro.getCodDependencia());	
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getCodNivelRiesgo())) {
			propertyParams.addProperty("codNivelRiesgo", filtro.getCodNivelRiesgo());	
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getCodTipoAccion())) {
			propertyParams.addProperty("codTipoAccion", filtro.getCodTipoAccion());	
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getCodTipoDocumentoIdentif())) {
			propertyParams.addProperty("codTipoDocumentoIdentif", filtro.getCodTipoDocumentoIdentif());	
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getNumDocumentoIdentif())) {
			propertyParams.addProperty("numDocumentoIdentif", filtro.getNumDocumentoIdentif());	
		}
		List<UsuarioProgramacionBean> lista = new ArrayList<>();
		List<UsuarioProgramacion> t10428lista = t10428UsuarioProgDAO.findByProperties(propertyParams,
				AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10428lista)) {
			for (UsuarioProgramacion t10428 : t10428lista) {
				UsuarioProgramacionBean bean = new UsuarioProgramacionBean();
				MaestrosUtilidades.copiarValoresBean(t10428, bean);
				DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF,
						bean.getCodTipoDocumentoIdentif());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesTipoDocumentoIdent(catalogo.getDescripcionDataCatalogo().trim());
				}
				ParametrosBean parametro = parametrosService.obtenerParametro(MaestrosConstantes.COD_PARAMETRO_ESTADO_REGISTRO, bean.getCodEstadoRegistro());
				if (!MaestrosUtilidades.isEmpty(parametro)) {
					bean.setDesEstadoRegistro(parametro.getFuncion().trim());
				}
				FullUbigeoBean ubigeo = ubigeoService.obtenerFullUbigeoDescripcion(bean.getCodUbigeoDomicilioFiscal());
				if (!MaestrosUtilidades.isEmpty(ubigeo)) {
					bean.setDesUbigeoDomicilioFiscal(ubigeo.obtenerFullDescripcion());
				}
//				parametro = parametrosService.obtenerParametro(MaestrosConstantes.COD_CATALOGO_NIVEL_DERIESGO, bean.getCodNivelRiesgo());
//				if (!MaestrosUtilidades.isEmpty(parametro)) {
//					bean.setDesNivelRiesgo(parametro.getFuncion().trim());
//				}
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_NIVEL_DERIESGO,
						bean.getCodNivelRiesgo());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesNivelRiesgo(catalogo.getDescripcionDataCatalogo().trim());
				}			
				
				parametro = parametrosService.obtenerParametro(MaestrosConstantes.COD_PARAMETRO_DEPENDENCIA, bean.getCodDependencia());
				if (!MaestrosUtilidades.isEmpty(parametro)) {
					bean.setDesDependencia(parametro.getFuncion().trim());
				}
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL,
						bean.getCodTipoAccion());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesTipoAccion(catalogo.getDescripcionDataCatalogo().trim());
				}
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL,
						bean.getCodTipoAccionSugerida());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesTipoAccionSugerida(catalogo.getDescripcionDataCatalogo().trim());
				}
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INTERVENCION,
						bean.getCodTipoIntervencion());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesTipoIntervencion(catalogo.getDescripcionDataCatalogo().trim());
				}
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INTERVENCION,
						bean.getCodTipoIntervencionSugerida());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesTipoIntervencionSugerida(catalogo.getDescripcionDataCatalogo().trim());
				}			    
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_MOTIVOS_DEPURACION,
						bean.getCodMotivaDepuracion());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesMotDepuracion(catalogo.getDescripcionDataCatalogo().trim());
				}
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_USUARIOACCION,
						bean.getCodEstadoUsuario());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					bean.setDesEstadoUsuario(catalogo.getDescripcionDataCatalogo().trim());
				}
				bean.setFecFinVigencia(MaestrosUtilidades.dateToStringDDMMYYYY(t10428.getFecFinVigencia()));
				lista.add(bean);
			}
		}
		for (int i=0;i<lista.size();i++){
			lista.get(i).setProgramacionBean(this.listarOtraAccion(lista.get(i)));
		}			
		return lista;
	}

	@Override
	public ProgramacionBean obtenerDatosProgramacion(Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - obtenerDatosProgramacion");
		ProgramacionBean bean = gestionProgramaOtrosService.obtenerDatosProgramacion(numProgramacion);

		// Obtener datos de informe
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", numProgramacion);
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<InformeSeleccion> t10411lista = t10411InformeSelecDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10411lista)) {
			InformeSeleccionBean infoBean = new InformeSeleccionBean();
			InformeSeleccion t10411 = t10411lista.get(0);
			MaestrosUtilidades.copiarValoresBean(t10411, infoBean);
			propertyParams = new PropertyParams();
			propertyParams.addProperty("numInformeSeleccion", t10411.getNumInformeSeleccion());
			propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<ArchivoInformeSeleccion> t10390lista = t10390ArcInformeDAO.findByProperties(propertyParams,
					AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10390lista)) {
				for (ArchivoInformeSeleccion archivoInformeSeleccion : t10390lista) {
					ArchivoAcciones t10445 = t10445ArcAcfDAO.findById(archivoInformeSeleccion.getNumArchivo(),
							AccionesControlConstantes.DATASOURCE_DCSICOBF);
					if (!MaestrosUtilidades.isEmpty(t10445)) {
						ArchivoBean archivoBean = new ArchivoBean();
						archivoBean.setCategoria(t10445.getCodTipoArchivo());
						archivoBean.setDesMimeType(t10445.getDesMimeType());
						archivoBean.setCntPesArch(t10445.getCntPesoArc());
						archivoBean.setNumArc(archivoInformeSeleccion.getNumArchivo());
						archivoBean.setTipo(AccionesControlConstantes.TIPO_ARCHIVO_BD);
						archivoBean.setNomArchivo(t10445.getNombArchivoAcciones());
						if (AccionesControlConstantes.COD_TIPO_ARCHIVO_INFORME.equals(t10445.getCodTipoArchivo())) {
							infoBean.setArchivoInforme(archivoBean);
						} else if (AccionesControlConstantes.COD_TIPO_ARCHIVO_REPORTE_INCOSISTENCIA.equals(t10445.getCodTipoArchivo())) {
							infoBean.setArchivoReporte(archivoBean);
						}
					}
				}
			}
			bean.setInformeSeleccion(infoBean);
		}
		return bean;
	}

	@Override
	public List<ProgramacionBean> listarOtraAccion(UsuarioProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - listarOtraAccion");
		UsuarioProgramacion mapFiltro = new UsuarioProgramacion();
		List<ProgramacionBean> lista = new ArrayList<>();
		if(!MaestrosUtilidades.isEmpty(filtro.getNumDocumentoIdentif())) {
			mapFiltro.setNumDocumentoIdentif(filtro.getNumDocumentoIdentif());
		}	
		if(!MaestrosUtilidades.isEmpty(filtro.getCodTipoDocumentoIdentif())) {
			mapFiltro.setCodTipoDocumentoIdentif(filtro.getCodTipoDocumentoIdentif());
		}	
		if(!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
			mapFiltro.setNumProgramacion( filtro.getNumProgramacion());
		}	
		mapFiltro.setCodEstPrograma(AccionesControlConstantes.COD_EST_PROGRAM_CERRADA);			
		List<Programacion> t10428lista = t10428UsuarioProgDAO.listarOtraAccion(mapFiltro);
		if (!MaestrosUtilidades.isEmpty(t10428lista)) {		
				for (Programacion t10420 : t10428lista) {
					ProgramacionBean bean = new ProgramacionBean();		
					//NUM PROGRAMA
					bean.setNumProgramacion(t10420.getNumProgramacion());					
					bean.setNumProgramaCorrel(t10420.getNumProgramaCorrel());
					//Programa Control
					bean.setCodProgramaControl(t10420.getCodProgctrl());
					bean.setDesProgramaControl(t10420.getDesProgctrl());					
					//PERIODO INICIO
					bean.setPerInicio(t10420.getPerInicio());
					//PERIODO Fin
					bean.setPerFin(t10420.getPerFin());
					//Tipo Intervencion
					bean.setCodTipInterv(t10420.getCodTipInterv());					
					DataCatalogoBean estado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INTERVENCION,
							bean.getCodTipInterv());					
					if (!MaestrosUtilidades.isEmpty(estado)) {
						bean.setDesTipInterv(estado.getDescripcionDataCatalogo());
					}
					//Tipo Accion Control
					bean.setCodTipoAccion(t10420.getCodTipoAccion());
					estado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL,
							bean.getCodTipoAccion());					
					if (!MaestrosUtilidades.isEmpty(estado)) {
						bean.setDesTipoAccion(estado.getDescripcionDataCatalogo());
					}				
					//Tipo Docu
					bean.setCodTipoDocumentoIdent((t10420.getCodTipoDocumentoIdent()));
					DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF,
							bean.getCodTipoDocumentoIdent());
					if (!MaestrosUtilidades.isEmpty(catalogo)) {
						bean.setDesTipoDocumentoIdent(catalogo.getDescripcionDataCatalogo().trim());
					}					
					//Num Doc
					bean.setNumDocumentoIdent(t10420.getNumDocumentoIdent());
					//Num Orden
					bean.setNumOrden(t10420.getNumOrden());					
					WSPersonalIqbfBean personal = servicioWebService.obtenerPersonalIqbf(t10420.getCodProgramador());
					if (!MaestrosUtilidades.isEmpty(personal)) {
						bean.setDesProgramador(personal.getNomCompleto());
					}										
					//ESTADO DE ORDEN
					bean.setCodEstOrden(t10420.getCodEstOrden());
					estado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_ORDEN,
							bean.getCodEstOrden());					
					if (!MaestrosUtilidades.isEmpty(estado)) {
						bean.setDesEstOrden(estado.getDescripcionDataCatalogo());
					}					
					lista.add(bean);
				}	
			}			

		return lista;				
	}


	@Override
	public ResponseBean<UsuarioProgramacionBean> guardarUsuario(UsuarioProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - guardarUsuario");
		PropertyParams properties = new PropertyParams();
		properties.addProperty("numProgramacion", formulario.getNumProgramacion());
		properties.addPropertyOperador("numUsuarioPrograma", formulario.getUsuariosBean().stream()
				.map(UsuarioProgramacionBean::getNumUsuarioPrograma).collect(Collectors.toList()), "IN");
		List<UsuarioProgramacion> t10428lista = t10428UsuarioProgDAO.findByProperties(properties, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10428lista)) {
			for (UsuarioProgramacion t10428 : t10428lista) {
				t10428.setIndDepuracion(AccionesControlConstantes.COD_IND_DEPURACION_MANUAL);
				t10428.setFecModif(new Date());
				t10428.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
				t10428.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
				if (!MaestrosUtilidades.isEmpty(formulario.getCodMotivaDepuracion())) {
					t10428.setCodMotivaDepuracion(formulario.getCodMotivaDepuracion());
					//VALIDAR QUE NO PUEDA PONER COD DEPURACION SIN VALOR, SIN ESCOGER OTROS
					if(formulario.getCodMotivaDepuracion().equals(AccionesControlConstantes.OPCION_OTROS)){
						if (!MaestrosUtilidades.isEmpty(formulario.getDesSusMotivo())) {
							t10428.setDesSusMotivo(formulario.getDesSusMotivo());	
						}
					}else{
						t10428.setDesSusMotivo(AccionesControlConstantes.SINVALOR);
					}
				}

				if (!MaestrosUtilidades.isEmpty(formulario.getCodTipoAccion())) {
					t10428.setCodTipoAccion(formulario.getCodTipoAccion());	
				}
				if (!MaestrosUtilidades.isEmpty(formulario.getIndNeutralizacion())) {
					t10428.setIndNeutralizacion(formulario.getIndNeutralizacion());	
				}
				t10428UsuarioProgDAO.update(t10428, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}
		return new ResponseBean<UsuarioProgramacionBean>(formulario);
	}
	public WSUnidadOrgBean validarCodigoUUOO(String codUnidadOrganica){
		WSUnidadOrgBean unidadOrg= new WSUnidadOrgBean();
		if (!MaestrosUtilidades.isEmpty(codUnidadOrganica)) {
			unidadOrg = servicioWebService.obtenerDatosUUOO(codUnidadOrganica);
		}	
		return unidadOrg;
	}	
	
	@Override
	@Transactional
	public ResponseBean<InformeSeleccionBean> guardarInformeSeleccion(InformeSeleccionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - guardarInformeSeleccion");
		boolean esRegistro = MaestrosUtilidades.isEmpty(formulario.getNumInformeSeleccion()) || (formulario.getNumInformeSeleccion() == 0);

		if (esRegistro) {
			PropertyParams params = new PropertyParams();
			params.addProperty("numCorrel", formulario.getNumCorrel());
			params.addProperty("codUnidadOrganica", formulario.getCodUnidadOrganica());
			params.addProperty("anioInforme", formulario.getAnioInforme());
			params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<InformeSeleccion> t10411lista = t10411InformeSelecDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10411lista)) {
				return new ResponseBean<>(false, MensajesExcepciones.CUS09_EXCP_004);
			}
		}

		if (!MaestrosUtilidades.isEmpty(formulario.getCodUnidadOrganica())) {
			WSUnidadOrgBean unidadOrg = servicioWebService.obtenerDatosUUOO(formulario.getCodUnidadOrganica());
			if (MaestrosUtilidades.isEmpty(unidadOrg)) {
				return new ResponseBean<>(false, MensajesExcepciones.CUS09_EXCP_011);
			}
		}	

		InformeSeleccion t10411 = esRegistro ? new InformeSeleccion() : t10411InformeSelecDAO.findById(formulario.getNumInformeSeleccion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		t10411.setAnioInforme(formulario.getAnioInforme());
		t10411.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_GENERADO);
		t10411.setCodUnidadOrganica(formulario.getCodUnidadOrganica());
		t10411.setNumCorrel(formulario.getNumCorrel());
		t10411.setNumProgramacion(formulario.getNumProgramacion());
		if (esRegistro) {
			t10411.setNumInformeSeleccion(t10411InformeSelecDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_INFORMES_SELECCION, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10411.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10411.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10411.setFecCrea(new Date());
			t10411.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10411.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			// auditoria
			formulario.setNumInformeSeleccion(t10411.getNumInformeSeleccion());
			t10411InformeSelecDAO.save(t10411, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			// auditoria
			t10411.setFecModif(new Date());
			t10411.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			t10411.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			// auditoria
			t10411InformeSelecDAO.update(t10411, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}

		// Guardar archivos

		// Archivo informe
		ArchivoInformeSeleccion informe = null;
		ArchivoInformeSeleccion reporte = null;
		PropertyParams params = new PropertyParams();
		params.addProperty("numInformeSeleccion", formulario.getNumInformeSeleccion());
		List<ArchivoInformeSeleccion> listaArcInforme = t10390ArcInformeDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(listaArcInforme)) {
			for (ArchivoInformeSeleccion archivoInformeSeleccion : listaArcInforme) {
				ArchivoAcciones t10445 = t10445ArcAcfDAO.findById(archivoInformeSeleccion.getNumArchivo(),
						AccionesControlConstantes.DATASOURCE_DCSICOBF);
				if (!MaestrosUtilidades.isEmpty(t10445)) {
					if (AccionesControlConstantes.COD_TIPO_ARCHIVO_INFORME.equals(t10445.getCodTipoArchivo())) {
						informe = archivoInformeSeleccion;
					} else if (AccionesControlConstantes.COD_TIPO_ARCHIVO_REPORTE_INCOSISTENCIA.equals(t10445.getCodTipoArchivo())) {
						reporte = archivoInformeSeleccion;
					}	
				}
			}
		}

		boolean existeInforme = !MaestrosUtilidades.isEmpty(informe);
		ArchivoBean archivoInforme = formulario.getArchivoInforme();
		archivoInforme.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_INFORME);
		archivoInforme.setNumArc(existeInforme ? informe.getNumArchivo() : null);
		Long numArcInfo = comunService.guardarArchivo(archivoInforme, formulario.getAuditoriaBean());

		ArchivoInformeSeleccion t10390 = existeInforme ? informe : new ArchivoInformeSeleccion();
		t10390.setNumInformeSeleccion(formulario.getNumInformeSeleccion());
		t10390.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10390.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10390.setNumArchivo(numArcInfo);
		if (existeInforme) {
			t10390.setFecModif(new Date());
			t10390.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			t10390.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			// auditoria
			t10390ArcInformeDAO.update(t10390, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			t10390.setFecCrea(new Date());
			t10390.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10390.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10390.setNumArchivoDoc(t10390ArcInformeDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_INFORME_SELECCION, AccionesControlConstantes.DATASOURCE_DCSICOBF));
			t10390ArcInformeDAO.save(t10390, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
		}

		// Archivo reporte
		boolean existeReporte = !MaestrosUtilidades.isEmpty(reporte);
		ArchivoBean archivoReporte = formulario.getArchivoReporte();
		archivoReporte.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_REPORTE_INCOSISTENCIA);
		archivoReporte.setNumArc(!MaestrosUtilidades.isEmpty(reporte) ? reporte.getNumArchivo() : null);
		Long numArcRepo = comunService.guardarArchivo(archivoReporte, formulario.getAuditoriaBean());

		t10390 = existeReporte ? reporte : new ArchivoInformeSeleccion();
		t10390.setNumInformeSeleccion(formulario.getNumInformeSeleccion());
		t10390.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10390.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10390.setNumArchivo(numArcRepo);
		if (existeReporte) {
			t10390.setFecModif(new Date());
			t10390.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			t10390.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			// auditoria
			t10390ArcInformeDAO.update(t10390, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			t10390.setFecCrea(new Date());
			t10390.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10390.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10390.setNumArchivoDoc(t10390ArcInformeDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_INFORME_SELECCION, AccionesControlConstantes.DATASOURCE_DCSICOBF));
			t10390ArcInformeDAO.save(t10390, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
		}
		return new ResponseBean<InformeSeleccionBean>(formulario);
	}
	@Override
	public ResponseBean<InformeSeleccionBean> enviarInformeSeleccion(InformeSeleccionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaAsignadoServiceImpl - guardarInformeSeleccion");
		boolean esRegistro = MaestrosUtilidades.isEmpty(formulario.getNumInformeSeleccion()) || (formulario.getNumInformeSeleccion() == 0);
		if(esRegistro){
			return new ResponseBean<>(false, "Ocurrio un error");
		}
		if (esRegistro) {
			PropertyParams params = new PropertyParams();
			params.addProperty("numCorrel", formulario.getNumCorrel());
			params.addProperty("codUnidadOrganica", formulario.getCodUnidadOrganica());
			params.addProperty("anioInforme", formulario.getAnioInforme());
			params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<InformeSeleccion> t10411lista = t10411InformeSelecDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10411lista)) {
				return new ResponseBean<>(false, MensajesExcepciones.CUS09_EXCP_004);
			}
		}

		if (!MaestrosUtilidades.isEmpty(formulario.getCodUnidadOrganica())) {
			WSUnidadOrgBean unidadOrg = servicioWebService.obtenerDatosUUOO(formulario.getCodUnidadOrganica());
			if (MaestrosUtilidades.isEmpty(unidadOrg)) {
				return new ResponseBean<>(false, MensajesExcepciones.CUS09_EXCP_011);
			}
		}	
		//ValidarUsuarioProg
		UsuarioProgramacion filtroValidarUsuarioProg = new UsuarioProgramacion();		
		filtroValidarUsuarioProg.setNumProgramacion(formulario.getNumProgramacion());
		filtroValidarUsuarioProg.setCodTipAccion(AccionesControlConstantes.COD_TIPO_ACCION_CONTROL_NINGUNO);
		filtroValidarUsuarioProg.setCodMotivaDepuracion(AccionesControlConstantes.COD_TIPO_MOTIVODEPURA_NINGUNO);		
		List<UsuarioProgramacion> usuarioProgramacion=  t10428UsuarioProgDAO.validarUsuarioProg(filtroValidarUsuarioProg);
		if (!MaestrosUtilidades.isEmpty(usuarioProgramacion)) {			
			return new ResponseBean<>(false, MensajesExcepciones.CUS09_EXCP_007);			
		}
		//ListarCantUsuario
		UsuarioProgramacion filtroListarCantUsuario= new UsuarioProgramacion();
		filtroListarCantUsuario.setCodTipAccion(AccionesControlConstantes.COD_TIPO_ACCION_CONTROL_NINGUNO+","+AccionesControlConstantes.COD_TIPO_ACCION_CONTROL_NOAPLICA);		
		filtroListarCantUsuario.setNumProgramacion(formulario.getNumProgramacion());	
		List<UsuarioProgramacion> usuarioProgramacion2=  t10428UsuarioProgDAO.listarCantUsuario(filtroListarCantUsuario);
		if (MaestrosUtilidades.isEmpty(usuarioProgramacion2)) {			
			return new ResponseBean<>(false, MensajesExcepciones.CUS09_EXCP_008);			
		}
		//ActualizarProgramacion 
		Programacion programacion=  t10420ProgramacionDAO.findById(formulario.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		programacion.setFecModif(new Date());
		programacion.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
		programacion.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
		programacion.setCodEstadoPrograma(AccionesControlConstantes.COD_ESTADO_PROG_PROGRAMADO);
		t10420ProgramacionDAO.update(programacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);

		//InsertarHistoriaProg 
		HistorialEstadosPrograma t10410 = new HistorialEstadosPrograma();
		t10410.setNumProgramacion(programacion.getNumProgramacion());
		t10410.setFecEstadoProgram(new Date());
		t10410.setCodEstadoPrograma(AccionesControlConstantes.COD_ESTADO_PROG_PROGRAMADO);
		t10410.setFecCrea(new Date());
		t10410.setNumHistoriaProgram(t10410HistEstadoProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_HISTORIAL_ESTADOPROG, AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10410.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10410.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10410.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10410.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10410HistEstadoProgDAO.save(t10410, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		//ActualizarInformeSeleccion  
		InformeSeleccion t10411 =  t10411InformeSelecDAO.findById(formulario.getNumInformeSeleccion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		t10411.setFecModif(new Date());
		t10411.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
		t10411.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
		t10411.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_PENDIENTE);		
		t10411InformeSelecDAO.update(t10411, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		
		
		
		//ENVIAR CORREO
		// Enviar correo (TODO: Copiar a supervisor)
		try {
			// CONSEGUIR USUARIO
			String codSolicitante=(formulario.getAuditoriaBean().getLogin());
			WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(codSolicitante);
			MensajeIqbf t8414 = t8414MensajeIqbfDAO.findById(AccionesControlConstantes.COD_MENSAJE_CORREO_F08, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t8414) && !MaestrosUtilidades.isEmpty(solicitante)) {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("nroInformeSeleccion", formulario.getNumInformeSeleccion());
				CorreoBean correoBean = new CorreoBean();
				correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
				correoBean.setAsunto(t8414.getDesCorta());
				correoBean.setReceptor(solicitante.getDirCorreo().trim());
				correoBean.setMensaje(AccionesControlUtil.generarMensaje(t8414.getDesCuerpo(), parametros));
				CorreoUtil.enviarCorreo(correoBean);
			}
		} catch(Exception e) {
			logger.error(String.format("errorEnviarCorreo %s", e.getMessage()), e);
		}
		
		return new ResponseBean<InformeSeleccionBean>(formulario);
	}
	
	
	
	
	@Override
	public ResponseBean<UsuarioProgramacionBean> guardarDocumentoVinculado(UsuarioProgramacionBean formulario) {
		PropertyParams propertyParams = new PropertyParams();
		DocumentoAccion  t10406 = new DocumentoAccion ();
						//numDocumentoAccion
		if(!MaestrosUtilidades.isEmpty(formulario.getNumDocumentoAccion())) {
			t10406.setNumDocumentoAccion(Long.parseLong(formulario.getNumDocumentoAccion()));
			propertyParams.addProperty("numDocumentoAccion", t10406.getNumDocumentoAccion());//Validar Existencia
		}
							//numDocumento
		if(!MaestrosUtilidades.isEmpty(formulario.getNumeroDocumentoVinculado())) {
			t10406.setNumDocumento(formulario.getNumeroDocumentoVinculado());
		}	
							//codTipoDocumento
		if(!MaestrosUtilidades.isEmpty(formulario.getTipoDocumentoVinculado())) {
			t10406.setCodTipoDocumento(formulario.getTipoDocumentoVinculado());
		}
							//NumUsuarioPrograma
		if(!MaestrosUtilidades.isEmpty(formulario.getNumUsuarioPrograma())) {
			t10406.setNumUsuarioPrograma(formulario.getNumUsuarioPrograma());
			propertyParams.addProperty("numUsuarioPrograma", t10406.getNumUsuarioPrograma());//Validar Existencia
		}
	    t10406.setIndDel(AccionesControlConstantes.COD_ESTADO_DOCACCION_GENERADO);
		t10406.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10406.setCodEstadoDocumento(AccionesControlConstantes.COD_ESTADO_DOCACCION_GENERADO);

        							//indDel       
        //propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
        
							//COD_CLASE_DOCUMENTO_VINCULADO
		t10406.setCodClase(AccionesControlConstantes.COD_CLASE_DOCUMENTO_VINCULADO);//Validar Existencia
		propertyParams.addProperty("codClase", t10406.getCodClase());// PIDEN ESTE PARAMETRO PARA VALIDAR	
        List<DocumentoAccion> existe = t10406DocumentoAccionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
    	//PROCESO PARA CREAR NUM ARC
        Long numArchivo= null;	
        ArchivoBean archivoBean = formulario.getArchivoVinculado();
        archivoBean = formulario.getArchivoVinculado();
        if (!MaestrosUtilidades.isEmpty(archivoBean)) {
            archivoBean.setCategoria(AccionesControlConstantes.COD_TIPO_ARCHIVO_MEDIOPROBATORIO);
            archivoBean.setNumArc(!MaestrosUtilidades.isEmpty(existe) ? existe.get(0).getNumArc() : null);
            numArchivo = comunService.guardarArchivo(archivoBean, formulario.getAuditoriaBean());
        }
        t10406.setNumArc(numArchivo);
        // FIN Registrar archivo
        if (!MaestrosUtilidades.isEmpty(existe)) {
        	DocumentoAccion bexiste = existe.get(0);	    
        	t10406.setFecModif(new Date());
        	t10406.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
        	t10406.setCodUsuModif(formulario.getAuditoriaBean().getLogin());        	
        	t10406.setNumUsuarioPrograma(bexiste.getNumUsuarioPrograma());
        	t10406.setNumDocumentoAccion(bexiste.getNumDocumentoAccion());
        	t10406.setFecCrea(bexiste.getFecCrea());
        	t10406.setDirIpusucrea(bexiste.getDirIpusucrea());
        	t10406.setCodUsuCrea(bexiste.getCodUsuCrea());
        	t10406DocumentoAccionDAO.update(t10406, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			t10406.setFecEmision(new Date());
			t10406.setFecCrea(new Date());
			t10406.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10406.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10406.setNumDocumentoAccion(t10406DocumentoAccionDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_MEDIO_PROBATORIO, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10406DocumentoAccionDAO.save(t10406, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
        formulario.setNumDocumentoAccion(t10406.getNumDocumentoAccion().toString());
		return new ResponseBean<UsuarioProgramacionBean>(formulario);
	}
	
	
	@Override
	public List<UsuarioProgramacionBean> obtenerDatosDocVin(UsuarioProgramacionBean formulario) {
		PropertyParams propertyParams = new PropertyParams();
		List<UsuarioProgramacionBean> lista = new ArrayList<>();
		UsuarioProgramacionBean bean= new UsuarioProgramacionBean();
		//Parametros de Consulta
		if(!MaestrosUtilidades.isEmpty(formulario.getNumUsuarioPrograma())) {
			propertyParams.addProperty("numUsuarioPrograma", formulario.getNumUsuarioPrograma());//Validar Existencia
			propertyParams.addProperty("codClase", AccionesControlConstantes.COD_CLASE_DOCUMENTO_VINCULADO);// PIDEN ESTE PARAMETRO PARA VALIDAR
		}			
	    List<DocumentoAccion> existe = t10406DocumentoAccionDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
        if (!MaestrosUtilidades.isEmpty(existe)) {  
        	//Parametros de retorno
        	DocumentoAccion bexiste = existe.get(0);        	
        	bean.setNumDocumentoAccion(bexiste.getNumDocumentoAccion().toString());
        	bean.setNumUsuarioPrograma(bexiste.getNumUsuarioPrograma());        	      	
        	bean.setTipoDocumentoVinculado(bexiste.getCodTipoDocumento());
        	bean.setNumeroDocumentoVinculado(bexiste.getNumDocumento());  
        	bean.setIndDel(AccionesControlConstantes.COD_ESTADO_DOCACCION_GENERADO);
        	bean.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
        	bean.setCodEstadoPrograma(AccionesControlConstantes.COD_ESTADO_DOCACCION_GENERADO);   	
        	bean.setNumUsuarioPrograma(bexiste.getNumUsuarioPrograma());        	
        	bean.setArchivoVinculado(comunService.obtenerArchivo(bexiste.getNumArc()) );
        	lista.add(bean);
        }        
		return (lista);
	}
	

}
