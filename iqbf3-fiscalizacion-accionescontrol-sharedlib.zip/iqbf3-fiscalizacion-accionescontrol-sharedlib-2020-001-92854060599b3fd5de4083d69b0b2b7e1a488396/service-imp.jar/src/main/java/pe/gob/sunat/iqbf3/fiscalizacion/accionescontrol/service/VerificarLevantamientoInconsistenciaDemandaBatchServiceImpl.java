package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import javax.ejb.EJB;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public class VerificarLevantamientoInconsistenciaDemandaBatchServiceImpl implements VerificarLevantamientoInconsistenciaDemandaBatchService{

	
	private static final Logger logger = LoggerFactory.getLogger(VerificarLevantamientoInconsistenciaDemandaBatchServiceImpl.class);

	@EJB
	private T10415OrdenAccionDAO t10415OrdenAccionDAO;
	
	@EJB
	private T10428UsuarioProgDAO t10428UsuarioProgDAO;
	
	@EJB
	private VerificarLevantamientoInconsistenciaBatchService serviceBatch;
	
	
	public ResponseBean<String> iniciarProcesamiento(Long numOrden){
		if (logger.isWarnEnabled())
			logger.warn("Inicio VerificarLevantamientoInconsistenciaDemandaBatchServiceImpl - iniciarProcesamiento");
		
		 ResponseBean<String> respuesta = new ResponseBean<>();

		 OrdenAccion ordenAcccionBean = t10415OrdenAccionDAO.findById(numOrden, AccionesControlConstantes.DATASOURCE_DCSICOBF);

		 UsuarioProgramacion usuarioProgramacionBean;
			
		 usuarioProgramacionBean = t10428UsuarioProgDAO.findById(ordenAcccionBean.getNumUsuarioPrograma(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		 
		 //Procede a realizar la verificaci�n de la inconsistencia para el usuario asociado al documento de acci�n.

		if(AccionesControlConstantes.COD_TIP_PROG_OMISOS_DJ.equals(ordenAcccionBean.getCodProgctrl())){
			serviceBatch.verificarInconsistenciaProgramaControlOmisosDj(ordenAcccionBean);
		}
		if(AccionesControlConstantes.COD_TIP_PROG_USU_VIGENTES_STOCK_SALDO_NEGATIVO.equals(ordenAcccionBean.getCodProgctrl())){
			serviceBatch.verificarInconsistenciaProgramaStockSaldoNegativo(ordenAcccionBean);
		}
		if(AccionesControlConstantes.COD_TIP_PROG_USU_BAJA_STOCK.equals(ordenAcccionBean.getCodProgctrl())){
			serviceBatch.verificarInconsistenciaProgramaControlBajaOmisoStockNegativo(ordenAcccionBean);
		}
		if(AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_DESTINATARIO.equals(ordenAcccionBean.getCodProgctrl())){
			serviceBatch.verificarInconsisProgramaControlGreNoConfirmadasDestinatario(ordenAcccionBean);
		}
		if(AccionesControlConstantes.COD_TIP_PROG_GRE_NOCONFIMADAS_TRANSPORTISTA.equals(ordenAcccionBean.getCodProgctrl())){
			serviceBatch.verificarInconsisProgramaControlGreNoConfirmadasTransportista(ordenAcccionBean);
		}
	     
		     
		 respuesta.setExito(true);
		 if (logger.isDebugEnabled())
			logger.debug("Fin VerificarLevantamientoInconsistenciaDemandaBatchServiceImpl - iniciarProcesamiento");
		 
		 return respuesta;
	}

}
