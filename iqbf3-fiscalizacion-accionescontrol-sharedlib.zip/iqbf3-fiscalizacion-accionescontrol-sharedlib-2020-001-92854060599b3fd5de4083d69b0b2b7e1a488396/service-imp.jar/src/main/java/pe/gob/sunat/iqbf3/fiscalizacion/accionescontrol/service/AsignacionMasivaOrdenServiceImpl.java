package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AgentePuestosCtrlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaUsuarioAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.GrupoProcesoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PreseleccionAsignacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AgentePuestosCtrl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DistribucionGrupo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.GrupoProceso;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PreseleccionAsignacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10297AgenteCtrolDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10394AsignaUsuAccDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10416PreseleAsigDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8311GrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class AsignacionMasivaOrdenServiceImpl implements AsignacionMasivaOrdenService {
	
	private static final Logger logger = LoggerFactory.getLogger(GestionSolicitudServiceImpl.class);
	
	@EJB
	T10420ProgramacionDAO t10420ProgramacionDAO;
	
	@EJB
	T10428UsuarioProgDAO t10428UsuarioProgDAO;
	
	@EJB
	T10416PreseleAsigDAO t10416PreseleAsigDAO;
	
	@EJB
	T8311GrupoDAO t8311GrupoDAO;
	
	@EJB
	T8303DistriGrupoDAO t8303DistriGrupoDAO;
	
	@EJB
	T10297AgenteCtrolDAO t10297AgenteCtrolDAO;
	
	@EJB
	T10394AsignaUsuAccDAO t10394AsignaUsuAccDAO;
	
	@EJB
	private ServicioWebService servicioWebServiceImpl;
	
	@EJB
	private DataCatalogoService dataCatalogoService;
	
	@EJB
	private AsignacionMasivaAuditoresBatchService asignacionMasivaAuditoresBatchService;
	
	@Override
	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro){
		
		List<ProgramacionBean> listaProgramacionBean = new ArrayList<ProgramacionBean>();

		Programacion parametros=new Programacion();
		parametros.setNumProgramacion(filtro.getNumProgramacion());
		parametros.setDesAlcance(filtro.getDesAlcance());
		parametros.setCodEstadoPrograma(filtro.getCodEstadoPrograma());
		parametros.setFechaDesde(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
		parametros.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
		parametros.setNumInforme(filtro.getNumInforme());
		parametros.setCodEstadoInforme(filtro.getCodEstInforme());
		parametros.setCodProgramador(filtro.getCodProgramador());
		//parametros.setCodPers(filtro.getCodPers()); fixme
		
		ArrayList<String> estadosPrograma=new ArrayList<String>();
		estadosPrograma.add(AccionesControlConstantes.COD_EST_PROGRAM_APROBADO);
		estadosPrograma.add(AccionesControlConstantes.COD_EST_PROGRAM_AUTORIZADO);
		parametros.setEstadosPrograma(estadosPrograma);

        List<Programacion> t10420Programacion= t10420ProgramacionDAO.listarProgramacion(parametros);
        
        if (!MaestrosUtilidades.isEmpty(t10420Programacion)) {
        	ProgramacionBean programacionBean=null;
	        for (Programacion programacion : t10420Programacion) {
	        	programacionBean =  new ProgramacionBean();
	        	programacionBean.setNumProgramacion(programacion.getNumProgramacion()==null?-1L:programacion.getNumProgramacion());
	        	programacionBean.setCodProgramaControl(programacion.getCodProgctrl()==null?"":programacion.getCodProgctrl());
	        	programacionBean.setCodProgramador(
	        			programacion.getCodProgramador()==null?AccionesControlConstantes.SINVALOR:programacion.getCodProgramador());
	        	programacionBean.setFecProgramacion(programacion.getFecProgramacion()==null?AccionesControlConstantes.SINVALOR:
	        		MaestrosUtilidades.dateToStringDDMMYYYY(programacion.getFecProgramacion()));
	        	programacionBean.setPerInicio(
	        			programacion.getPerInicio()==null?AccionesControlConstantes.SINVALOR:programacion.getPerInicio());
	        	programacionBean.setPerFin(
	        			programacion.getPerFin()==null?AccionesControlConstantes.SINVALOR:programacion.getPerFin());
	        	programacionBean.setNumInforme(programacion.getNumInforme());
	        	programacionBean.setNroInformeUnion(programacion.getNroInformeUnion());
	        	
	        	programacionBean.setCodEstadoInforme(programacion.getCodEstadoInforme());
	        	
	        	programacionBean.setDesProgctrl(programacion.getDesProgctrl());
	        	programacionBean.setDesProgramaControl(programacion.getDesProgctrl());
	        	
	        	if (!MaestrosUtilidades.isEmpty(programacion.getCodProgramador())) {
	    			WSPersonalIqbfBean codProgramador = servicioWebServiceImpl.obtenerPersonalIqbf(programacion.getCodProgramador());
	    			if (!MaestrosUtilidades.isEmpty(codProgramador)) {
	    				programacionBean.setNomProgramador(codProgramador.getNomCompleto());
	    			}else{
	    				programacionBean.setNomProgramador(AccionesControlConstantes.SINVALOR);
	    			}
	    		}else{
					programacionBean.setNomProgramador(AccionesControlConstantes.SINVALOR);
				}
	        	
	        	DataCatalogoBean catalogo = null;
	        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_FUENTES_PROGRAMAS,programacion.getCodFuente());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesFuente(catalogo.getDescripcionDataCatalogo());
				}
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_PROGRAMACION,programacion.getCodTipoProgram());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesTipoProgram(catalogo.getDescripcionDataCatalogo());
				}
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,programacion.getCodEstadoPrograma());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesEstadoProgram(catalogo.getDescripcionDataCatalogo());
				}
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_SUBESTADOS_PROGRAMACION,programacion.getCodSubEstadoProgram());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesSubEstprogram(catalogo.getDescripcionDataCatalogo());
				}	
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_PROCESOS_PROGRAMACION,programacion.getCodProceso());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesProceso(catalogo.getDescripcionDataCatalogo());
				}	
				catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_INFORMESELECCION,programacion.getCodEstadoInforme());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					programacionBean.setDesEstadoInforme(catalogo.getDescripcionDataCatalogo());
				}
	           	if (!MaestrosUtilidades.isEmpty(programacion.getCodProgramadorAdmin())) {
        			WSPersonalIqbfBean codProgramadorAdmin = servicioWebServiceImpl.obtenerPersonalIqbf(programacion.getCodProgramadorAdmin());
        			if (!MaestrosUtilidades.isEmpty(codProgramadorAdmin)) {
        				programacionBean.setNomProgramadorAdmin(codProgramadorAdmin.getNomCompleto());
        			}else{
        				programacionBean.setNomProgramadorAdmin(AccionesControlConstantes.SINVALOR);
        			}
        		}else{
    				programacionBean.setNomProgramadorAdmin(AccionesControlConstantes.SINVALOR);
    			}
	
	        	listaProgramacionBean .add(programacionBean);
			}
        }
        
		return listaProgramacionBean ;
	}
	
	@Override
	public ProgramacionBean obtenerDatosProgramacion(String numProgramacion){
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionSolicitudServiceImpl - obtenerDatosSolicitud");
		ProgramacionBean programacionBean=null;
		
		//Programacion programacion = t10420ProgramacionDAO.findById(Long.valueOf(numProgramacion), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		Programacion parametros=new Programacion();
		parametros.setNumProgramacion(Long.valueOf(numProgramacion));
		List<Programacion> t10420Programacion= t10420ProgramacionDAO.listarProgramacion(parametros);
		
		   if (!MaestrosUtilidades.isEmpty(t10420Programacion)) {		
		        for (Programacion programacion : t10420Programacion) {
		        	programacionBean=new ProgramacionBean();
		        	
		        	programacionBean.setNumProgramacion(programacion.getNumProgramacion());
		        	programacionBean.setCodProgctrl(programacion.getCodProgctrl());
		        	programacionBean.setCodProgramaControl(programacion.getCodProgctrl());
		        	programacionBean.setAnioProgramacion(programacion.getAnioProgramacion());
		        	programacionBean.setNumProgramaCorrel(programacion.getNumProgramaCorrel());
		        	programacionBean.setDesAlcance(programacion.getDesAlcance());
		        	programacionBean.setDesProgramacion(programacion.getDesProgramacion());
		        	programacionBean.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(programacion.getFecProgramacion()));
		        	programacionBean.setCodProgramador(programacion.getCodProgramador());
		        	programacionBean.setPerInicio(programacion.getPerInicio());
		        	programacionBean.setPerFin(programacion.getPerFin());
		        	programacionBean.setCodFuente(programacion.getCodFuente());
		        	programacionBean.setDesOtraFuente(programacion.getDesOtraFuente());
		        	programacionBean.setCodTipoProgram(programacion.getCodTipoProgram());
		        	programacionBean.setObsProgramacion(programacion.getObsProgramacion());
		        	programacionBean.setNumInformeCancelacion(programacion.getNumInformeCancelacion());
		        	programacionBean.setNumPlazoVerificacion(programacion.getNumPlazoVerificacion());
		        	programacionBean.setIndCierre(programacion.getIndCierre());
		        	programacionBean.setCodEstadoPrograma(programacion.getCodEstadoPrograma());
		        	programacionBean.setCodSubEstadoProgram(programacion.getCodSubEstadoProgram());
		        	programacionBean.setCodProceso(programacion.getCodProceso());
		        	programacionBean.setDesSusCancela(programacion.getDesSusCancela());
		        	programacionBean.setNumInforme(programacion.getNumInforme());
		        	programacionBean.setNroInformeUnion(programacion.getNroInformeUnion());
		        	
		        	programacionBean.setDesProgramaControl(programacion.getDesProgctrl());
		        	programacionBean.setDesProgctrl(programacion.getDesProgctrl());
		        	
//		        	if (!MaestrosUtilidades.isEmpty(programacion.getCodProgctrl())) {
//		        		programacionBean.getc = programaControlBean.
//		    			WSPersonalIqbfBean servicioWebService = servicioWebServiceImpl.obtenerPersonalIqbf();
//		    			if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
//		    				programacionBean.setDesProgramaControl(servicioWebService.getNomCompleto());
//		    			}else{
//		    				programacionBean.setDesProgramaControl(AccionesControlConstantes.SINVALOR);
//		    			}
//		    		}else{
//	    				programacionBean.setDesProgramaControl(AccionesControlConstantes.SINVALOR);
//	    			}	        	
		        	
		        	if (!MaestrosUtilidades.isEmpty(programacion.getCodProgramador())) {
		    			WSPersonalIqbfBean servicioWebService = servicioWebServiceImpl.obtenerPersonalIqbf(programacion.getCodProgramador());
		    			if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
		    				programacionBean.setNomProgramador(servicioWebService.getNomCompleto());
		    			}else{
		    				programacionBean.setNomProgramador(AccionesControlConstantes.SINVALOR);
		    			}
		    		}else{
	    				programacionBean.setNomProgramador(AccionesControlConstantes.SINVALOR);
	    			}
		        	
		        	DataCatalogoBean catalogo = null;
		        	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_FUENTES_PROGRAMAS,programacion.getCodFuente());
					if (!MaestrosUtilidades.isEmpty(catalogo)) {
						programacionBean.setDesFuente(catalogo.getDescripcionDataCatalogo());
					}	
		        	
					catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_PROGRAMACION,programacion.getCodTipoProgram());
					if (!MaestrosUtilidades.isEmpty(catalogo)) {
						programacionBean.setDesTipoProgram(catalogo.getDescripcionDataCatalogo());
					}
		        	
					catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,programacion.getCodEstadoPrograma());
					if (!MaestrosUtilidades.isEmpty(catalogo)) {
						programacionBean.setDesEstadoProgram(catalogo.getDescripcionDataCatalogo());
					}
		        	
					catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_SUBESTADOS_PROGRAMACION,programacion.getCodSubEstadoProgram());
					if (!MaestrosUtilidades.isEmpty(catalogo)) {
						programacionBean.setDesSubEstprogram(catalogo.getDescripcionDataCatalogo());
					}
		        	
					catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_PROCESOS_PROGRAMACION,programacion.getCodProceso());
					if (!MaestrosUtilidades.isEmpty(catalogo)) {
						programacionBean.setDesProceso(catalogo.getDescripcionDataCatalogo());
					}
		        }
		   }
		
		return programacionBean;
	}
	
	@Override
	public List<UsuarioProgramacionBean> listarResumenAccion(String numProgramacion){
		List<UsuarioProgramacionBean> listaUsuarioProgramacionBean =new ArrayList<UsuarioProgramacionBean>();
		
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", Long.valueOf(numProgramacion));
		
		List<UsuarioProgramacion> t10428UsuarioProg=t10428UsuarioProgDAO.listarResumenAccion(numProgramacion);
		
		if (!MaestrosUtilidades.isEmpty(t10428UsuarioProg)) {
			UsuarioProgramacionBean usuarioProgramacionBean=null;
			for (UsuarioProgramacion usuarioProgramacion : t10428UsuarioProg) {
				usuarioProgramacionBean=new UsuarioProgramacionBean();
				
//				usuarioProgramacionBean.setCantidadDiasAtencion(usuarioProgramacion.getCantidadDiasAtencion());
//				usuarioProgramacionBean.setCodDependencia(usuarioProgramacion.getCodDependencia());
//				usuarioProgramacionBean.setCodEstadoRegistro(usuarioProgramacion.getCodEstadoRegistro());
//				usuarioProgramacionBean.setCodEstadoUsuario(usuarioProgramacion.getCodEstadoUsuario());
//				usuarioProgramacionBean.setCodMotivaDepuracion(usuarioProgramacion.getCodMotivaDepuracion());
//				usuarioProgramacionBean.setCodNivelRiesgo(usuarioProgramacion.getCodNivelRiesgo());
//				usuarioProgramacionBean.setCodTipoAccion(usuarioProgramacion.getCodTipoAccion());
//				usuarioProgramacionBean.setCodTipoAccionSugerida(usuarioProgramacion.getCodTipoAccionSugerida());
//				usuarioProgramacionBean.setCodTipoDocumentoIdentif(usuarioProgramacion.getCodTipoDocumentoIdentif());
//				usuarioProgramacionBean.setCodTipoIntervencion(usuarioProgramacion.getCodTipoIntervencion());
//				usuarioProgramacionBean.setCodTipoIntervencionSugerida(usuarioProgramacion.getCodTipoIntervencionSugerida());
//				usuarioProgramacionBean.setCodUbigeoDomicilioFiscal(usuarioProgramacion.getCodUbigeoDomicilioFiscal());
//				usuarioProgramacionBean.setDesSusMotivo(usuarioProgramacion.getDesSusMotivo());
//				usuarioProgramacionBean.setFecFinVigencia(MaestrosUtilidades.dateToStringDDMMYYYY(usuarioProgramacion.getFecFinVigencia()));
//				usuarioProgramacionBean.setFecInicioCaso(MaestrosUtilidades.dateToStringDDMMYYYY(usuarioProgramacion.getFecInicioCaso()));
//				usuarioProgramacionBean.setFecProcesamiento(MaestrosUtilidades.dateToStringDDMMYYYY(usuarioProgramacion.getFecProcesamiento()));
//				usuarioProgramacionBean.setHorIniCaso(usuarioProgramacion.getHorIniCaso());
//				usuarioProgramacionBean.setIndNeutralizacion(usuarioProgramacion.getIndNeutralizacion()==null?"":usuarioProgramacion.getIndNeutralizacion());
//				usuarioProgramacionBean.setNomApellidoUsuario(usuarioProgramacion.getNomApellidoUsuario());
//				usuarioProgramacionBean.setNumDocumentoIdentif(usuarioProgramacion.getNumDocumentoIdentif());
//				usuarioProgramacionBean.setNumPeridoomisomax(usuarioProgramacion.getNumPeridoomisomax());
//				usuarioProgramacionBean.setNumPeridoomisomin(usuarioProgramacion.getNumPeridoomisomin());
//				usuarioProgramacionBean.setNumUsuarioPrograma(usuarioProgramacion.getNumUsuarioPrograma());
//				usuarioProgramacionBean.setNumVersionRegistro(usuarioProgramacion.getNumVersionRegistro());
//				usuarioProgramacionBean.setAlcanceProg(usuarioProgramacion.getAlcanceProg());
//				usuarioProgramacionBean.setIndDel(usuarioProgramacion.getIndDel());
//				usuarioProgramacionBean.setIndEst(usuarioProgramacion.getIndEst());
//				usuarioProgramacionBean.setNumInformeSelecci(usuarioProgramacion.getNumInformeSelecci());
//				usuarioProgramacionBean.setCodPers(usuarioProgramacion.getCodPers());
//				usuarioProgramacionBean.setCodProgctrl(usuarioProgramacion.getCodProgctrl());
//				usuarioProgramacionBean.setCodAuditor(usuarioProgramacion.getCodAuditor());
//				usuarioProgramacionBean.setNomAuditor(usuarioProgramacion.getNomAuditor());
//				usuarioProgramacionBean.setNomRazonSocial(usuarioProgramacion.getNomRazonSocial());
//				usuarioProgramacionBean.setFecModif(MaestrosUtilidades.dateToStringDDMMYYYY(usuarioProgramacion.getFecModif()));
//				usuarioProgramacionBean.setDirIpusumodif(usuarioProgramacion.getDirIpusumodif());
//				usuarioProgramacionBean.setCodUsuModif(usuarioProgramacion.getCodUsuModif());
//				usuarioProgramacionBean.setCodEstadoPrograma(usuarioProgramacion.getCodEstadoPrograma());
//				usuarioProgramacionBean.setNumProgCorrel(usuarioProgramacion.getNumProgCorrel());
//				usuarioProgramacionBean.setNumOrden(usuarioProgramacion.getNumOrden());
//				usuarioProgramacionBean.setDesAlcance(usuarioProgramacion.getDesAlcance());
//				usuarioProgramacionBean.setNroInformeUnion(usuarioProgramacion.getNroInformeUnion());
//				
				usuarioProgramacionBean.setCodTipoAccion(usuarioProgramacion.getCodTipoAccion());
				usuarioProgramacionBean.setCantTiposAccion(usuarioProgramacion.getCantTiposAccion());
				
				
				DataCatalogoBean catalogo = null;
				catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_ACCIONCONTROL,usuarioProgramacion.getCodTipoAccion());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					usuarioProgramacionBean.setDesTipoAccion(catalogo.getDescripcionDataCatalogo());
				}else {
					usuarioProgramacionBean.setDesTipoAccion(AccionesControlConstantes.SINVALOR);
				}
				listaUsuarioProgramacionBean.add(usuarioProgramacionBean);
			}
		}
		return listaUsuarioProgramacionBean;
	}
	
	@Override
	public List<PreseleccionAsignacionBean> listarAuditorPresel(String numProgramacion, String codTipoAccion){
		
		List<PreseleccionAsignacionBean> listaPreseleccionAsignacionBean =new ArrayList<PreseleccionAsignacionBean>();
		
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", Long.valueOf(numProgramacion));
		propertyParams.addProperty("codTipoAccion", codTipoAccion);
		
		List<PreseleccionAsignacion> t10416PreseleAsig=	t10416PreseleAsigDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		if (!MaestrosUtilidades.isEmpty(t10416PreseleAsig)) {
			PreseleccionAsignacionBean preseleccionAsignacionBean=null;
			for (PreseleccionAsignacion preseleccionAsignacion : t10416PreseleAsig) {
				preseleccionAsignacionBean=new PreseleccionAsignacionBean();
				
				DataCatalogoBean catalogo = null;
				catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_TIPO_ACCIONCONTROL,preseleccionAsignacion.getCodTipoAccion());
				if (!MaestrosUtilidades.isEmpty(catalogo)) {
					preseleccionAsignacionBean.setCodTipoAccion(catalogo.getDescripcionDataCatalogo());
				}else {
					preseleccionAsignacionBean.setCodTipoAccion(AccionesControlConstantes.SINVALOR);
				}
				
				if (!MaestrosUtilidades.isEmpty(preseleccionAsignacion.getCodAuditor())) {
	    			WSPersonalIqbfBean servicioWebService = servicioWebServiceImpl.obtenerPersonalIqbf(preseleccionAsignacion.getCodAuditor());
	    			if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
	    				preseleccionAsignacionBean.setNomAuditor(servicioWebService.getNomCompleto());
	    			}else{
	    				preseleccionAsignacionBean.setNomAuditor(AccionesControlConstantes.SINVALOR);
	    			}
	    		}else {
	    			preseleccionAsignacionBean.setNomAuditor(AccionesControlConstantes.SINVALOR);
	    		}
				
				listaPreseleccionAsignacionBean.add(preseleccionAsignacionBean);
			}
		}
		return listaPreseleccionAsignacionBean;
	}
	
	@Override
	public void guardarAuditorPresel(PreseleccionAsignacionBean preseleccionAsignacionBean){
		PreseleccionAsignacion preseleccionAsignacion=new PreseleccionAsignacion();
		
		preseleccionAsignacion.setNumAsignacionTemp(Long.valueOf(preseleccionAsignacionBean.getNumAsignacionTemp()));
		preseleccionAsignacion.setNumProgramacion(Long.valueOf(preseleccionAsignacionBean.getNumProgramacion()));
		preseleccionAsignacion.setCodTipoAccion(preseleccionAsignacionBean.getCodTipoAccion());
		preseleccionAsignacion.setCodAuditor(preseleccionAsignacionBean.getCodAuditor());
		// auditoria
		preseleccionAsignacion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		preseleccionAsignacion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		preseleccionAsignacion.setFecCrea(new Date());
		preseleccionAsignacion.setDirIpusucrea(preseleccionAsignacionBean.getAuditoriaBean().getNumIp());
		preseleccionAsignacion.setCodUsuCrea(preseleccionAsignacionBean.getAuditoriaBean().getLogin());
		// auditoria
		t10416PreseleAsigDAO.save(preseleccionAsignacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
	}

	@Override
	public void eliminarAuditorPresel(PreseleccionAsignacionBean preseleccionAsignacionBean) {
		
		PreseleccionAsignacion preseleccionAsignacion= t10416PreseleAsigDAO.findById(Long.valueOf(preseleccionAsignacionBean.getNumAsignacionTemp()), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		preseleccionAsignacion.setNumAsignacionTemp(Long.valueOf(preseleccionAsignacionBean.getNumAsignacionTemp()));
		preseleccionAsignacion.setIndDel(AccionesControlConstantes.REGISTRO_ELIMINADO);
		// auditoria
		preseleccionAsignacion.setDirIpusumodif(preseleccionAsignacionBean.getAuditoriaBean().getNumIp());
		preseleccionAsignacion.setCodUsuModif(preseleccionAsignacionBean.getAuditoriaBean().getLogin());
		// auditoria
		t10416PreseleAsigDAO.update(preseleccionAsignacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
	}
	
	@Override
	public List<GrupoProcesoBean> listarSupervisionAuditor(){
		List<GrupoProcesoBean> lista =new ArrayList<GrupoProcesoBean>();
		
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("codTipoProceso", AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);
		List<GrupoProceso>  t8311Grupo =t8311GrupoDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t8311Grupo)) {
			GrupoProcesoBean grupoProcesoBean=null;
		for (GrupoProceso grupoProceso : t8311Grupo) {
			grupoProcesoBean=new GrupoProcesoBean();
			grupoProcesoBean.setCodTipoProceso(grupoProceso.getCodTipoProceso());
			grupoProcesoBean.setNumGrupo(grupoProceso.getNumGrupo());
			grupoProcesoBean.setNomGrupo(grupoProceso.getNomGrupo());
			lista.add(grupoProcesoBean);
		}
		}
		return lista;
	}
	
	@Override
	public List<DistribucionGrupoBean> listarAuditoresAuditores(String numGrupo){
		List<DistribucionGrupoBean> lista=new ArrayList<DistribucionGrupoBean>();
		
		String codTipoProceso=AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD;
		String codCargo=AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL;
		String indEst=AccionesControlConstantes.REGISTRO_ACTIVO;
		ArrayList<String> codEstOrden=new ArrayList<String>();
		codEstOrden.add(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO);
		codEstOrden.add(AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA);
		
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("codTipoProceso", AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD);
		
		List<DistribucionGrupo> t8303DistriGrupo= t8303DistriGrupoDAO.listarAuditor(codEstOrden,codTipoProceso, numGrupo, codCargo,indEst);
		if (!MaestrosUtilidades.isEmpty(t8303DistriGrupo)) {
			
			DistribucionGrupoBean objDistribucionGrupoBean=null;
		for (DistribucionGrupo distribucionGrupo : t8303DistriGrupo) {
			objDistribucionGrupoBean=new DistribucionGrupoBean();
			
			objDistribucionGrupoBean.setNumRegistro(distribucionGrupo.getNumUsuarioPrograma()==null?"":distribucionGrupo.getNumUsuarioPrograma().toString());
			objDistribucionGrupoBean.setCodPers(distribucionGrupo.getCodPersonal());
			objDistribucionGrupoBean.setCantCarga(distribucionGrupo.getCantCarga());
			
			
			if (!MaestrosUtilidades.isEmpty(distribucionGrupo.getCodPersonal())) {
    			WSPersonalIqbfBean servicioWebService = servicioWebServiceImpl.obtenerPersonalIqbf(distribucionGrupo.getCodPersonal());
    			if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
    				objDistribucionGrupoBean.setNomProgramador(servicioWebService.getNomCompleto());
    			}else{
    				objDistribucionGrupoBean.setNomProgramador(AccionesControlConstantes.SINVALOR);
    			}
    		}
			lista.add(objDistribucionGrupoBean);
		}	
		}
		return lista;
	}
	
	@Override
	public List<AgentePuestosCtrlBean> listarAgentePuesto(String codPuesto){

		List<AgentePuestosCtrlBean> lista=new ArrayList<AgentePuestosCtrlBean>();
		
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("codPuesto", codPuesto);
		
       List<AgentePuestosCtrl>	t10297AgenteCtrol=	t10297AgenteCtrolDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
       if (!MaestrosUtilidades.isEmpty(t10297AgenteCtrol)) {
    	   AgentePuestosCtrlBean agentePuestosCtrlBean=null;
	       for (AgentePuestosCtrl agentePuestosCtrl : t10297AgenteCtrol) {
	    	   agentePuestosCtrlBean=new AgentePuestosCtrlBean();
	    	   agentePuestosCtrlBean.setNumRegistroPersonal(agentePuestosCtrl.getNumRegistroPersonal());
	    	   agentePuestosCtrlBean.setCodDep(agentePuestosCtrl.getCodDep());
	    	   agentePuestosCtrlBean.setCodPuesto(agentePuestosCtrl.getCodPuesto());
	    	   agentePuestosCtrlBean.setCodUnidadOrganica(agentePuestosCtrl.getCodUnidadOrganica());
	    	   agentePuestosCtrlBean.setCodRol(agentePuestosCtrl.getCodRol());
	    	   agentePuestosCtrlBean.setCodEstado(agentePuestosCtrl.getCodEstado());
	    	   agentePuestosCtrlBean.setDesSustento(agentePuestosCtrl.getDesSustento());
	    	   agentePuestosCtrlBean.setFecRegistro(agentePuestosCtrl.getDesSustento());
	    	   
	    	   if (!MaestrosUtilidades.isEmpty(agentePuestosCtrl.getNumRegistroPersonal())) {
	    			WSPersonalIqbfBean servicioWebService = servicioWebServiceImpl.obtenerPersonalIqbf(agentePuestosCtrl.getNumRegistroPersonal());
	    			if (!MaestrosUtilidades.isEmpty(servicioWebService)) {
	    				agentePuestosCtrlBean.setNomAuditor(servicioWebService.getNomCompleto());
	    			}else{
	    				agentePuestosCtrlBean.setNomAuditor(AccionesControlConstantes.SINVALOR);
	    			}
	    		}
	    	   
	    	   lista.add(agentePuestosCtrlBean);
	       }
       }
		return lista;
	}
	
	@Override
	public void guardarAsignarAuditor(ProgramacionBean filtro){    
		//SE INVOCARA UN PROCESO BATCH
		asignacionMasivaAuditoresBatchService.iniciarProcesamiento(filtro);
	}

}
