package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActividadesBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CheckElementBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PersonaBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActividadPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Actividades;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoInformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienFiscal;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DistribucionGrupo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.HistorialEstadosPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10384ActBienOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10388ActividProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10390ArcInformeDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10392AsignProgramDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10398BienProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10410HistEstadoProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10425TipInconProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T7882ActividadDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T7883BienFiscalDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlMensajes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.MensajesExcepciones;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.CorreoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.CorreoUtil;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class GestionProgramaOtrosServiceImpl implements GestionProgramaOtrosService {

	private static final Logger logger = LoggerFactory.getLogger(GestionProgramaOtrosServiceImpl.class);

	@EJB
	private T10425TipInconProgDAO t10425TipInconProgDAO;

	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;

	@EJB
	private T10388ActividProgDAO t10388ActividProgDAO;

	@EJB
	private T10398BienProgDAO t10398BienProgDAO;

	@EJB
	private T7882ActividadDAO t7882ActividadDAO;

	@EJB
	private T8303DistriGrupoDAO t8303DistriGrupoDAO;

	@EJB
	private ServicioWebService servicioWebService;

	@EJB
	private DataCatalogoService dataCatalogoService;

	@EJB
	private T10384ActBienOrdenDAO t10384ActBienOrdenDAO;

	@EJB
	private T10410HistEstadoProgDAO t10410HistEstadoProgDAO;

	@EJB
	private T8414MensajeIqbfDAO t8414MensajeIqbfDAO;
	
	@EJB
	private T7883BienFiscalDAO t7883BienFiscalDAO;

	@EJB
	private T10392AsignProgramDAO t10392AsignProgramDAO;

	@EJB
	private T10411InformeSelecDAO t10411InformeSelecDAO;
	
	@EJB
	private T8276CatProgCtrlDAO t8276CatProgCtrlDAO;
	
	@EJB 
	private T10390ArcInformeDAO t10390ArcInformeDAO;
	
	@EJB(name="accionescontrol.comunService")
	private ComunService comunService;
	
	@Override
	public List<ProgramacionBean> listarPrograma(ProgramacionBean filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosServiceImpl - listarPrograma");

		Programacion filtroModel = new Programacion();
		filtroModel.setDesAlcance(filtro.getDesAlcance());
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
			filtroModel.setCodEstadoPrograma(filtro.getCodEstadoPrograma());	
		} else {
			filtroModel.setEstadosPrograma(Arrays.asList(AccionesControlConstantes.COD_EST_PROGRAM_PLANIFICADO,
					AccionesControlConstantes.COD_EST_PROGRAM_ASIGNADO,
					AccionesControlConstantes.COD_EST_PROGRAM_AUTORIZADO));
		}
		filtroModel.setFechaDesde(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
		filtroModel.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
		filtroModel.setNumInforme(filtro.getNumInforme());
		filtroModel.setCodEstadoInforme(filtro.getCodEstadoInforme());
		filtroModel.setCodProgctrl(AccionesControlConstantes.COD_OTROS_PROGRAMAS);
		List<ProgramacionBean> lista = new ArrayList<ProgramacionBean>();
		List<Programacion> t10420lista = t10420ProgramacionDAO.listarProgramacion(filtroModel);
		logger.debug(String.format("t10420lista => %s", t10420lista));
		if(!MaestrosUtilidades.isEmpty(t10420lista)) {
			for (Programacion t10420 : t10420lista) {
				ProgramacionBean bean = new ProgramacionBean();
				bean.setDesAlcance(t10420.getDesAlcance());
				bean.setDesProgramacion(t10420.getDesProgramacion());
				bean.setNumProgramacion(t10420.getNumProgramacion());
				bean.setNumProgramaCorrel(t10420.getNumProgramaCorrel());
				bean.setCodProgramaControl(t10420.getCodProgctrl());
				bean.setDesProgramaControl(t10420.getDesProgctrl());
				bean.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10420.getFecProgramacion()));
				bean.setPerFin(t10420.getPerFin());
				bean.setPerInicio(t10420.getPerInicio());
				bean.setDesProgramador("");
				WSPersonalIqbfBean personal = servicioWebService.obtenerPersonalIqbf(t10420.getCodProgramador());
				if (!MaestrosUtilidades.isEmpty(personal)) {
					bean.setDesProgramador(personal.getNomCompleto());
				}
				bean.setFechaIniAsignacion(MaestrosUtilidades.dateToStringDDMMYYYY(t10420.getFechaIniAsignacion()));
				bean.setCodEstadoPrograma(t10420.getCodEstadoPrograma());
				DataCatalogoBean estado = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,
						bean.getCodEstadoPrograma());
				bean.setDesEstadoProgram("");
				if (!MaestrosUtilidades.isEmpty(estado)) {
					bean.setDesEstadoProgram(estado.getDescripcionDataCatalogo());
				}
				bean.setNumInforme(t10420.getNumInforme());
				bean.setDesEstadoInforme("");
				lista.add(bean);
			}
		}
		return lista;
	}

	@Override
	//@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public ResponseBean<ProgramacionBean> guardarPrograma(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosServiceImpl - guardarPrograma");
		logger.debug(String.format("formulario => %s", formulario.toString()));
		Calendar today = Calendar.getInstance();
		ResponseBean<ProgramacionBean> respuesta = new ResponseBean<>();

		boolean esRegistro = (MaestrosUtilidades.isEmpty(formulario.getNumProgramacion()) || formulario.getNumProgramacion() == 0);

		Programacion programacion = esRegistro ? new Programacion() : t10420ProgramacionDAO.findById(formulario.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		programacion.setDesAlcance(formulario.getDesAlcance());
		programacion.setDesProgramacion(formulario.getDesProgramacion());
		programacion.setFecProgramacion(new Date());
		programacion.setCodProgramador(formulario.getCodProgramador());
		programacion.setPerInicio(formulario.getPerInicio());
		programacion.setPerFin(formulario.getPerFin());
		programacion.setCodFuente(formulario.getCodFuente());
		programacion.setDesOtraFuente(formulario.getDesOtraFuente());
		programacion.setCodTipoProgram(formulario.getCodTipoProgram());
		programacion.setObsProgramacion(formulario.getObsProgramacion());
		programacion.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		programacion.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		programacion.setCodProgctrl(AccionesControlConstantes.COD_OTROS_PROGRAMAS);
		programacion.setAnioProgramacion(today.get(Calendar.YEAR));
		
		if (esRegistro) {
			programacion.setFecCrea(new Date());
			programacion.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			programacion.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			programacion.setCodEstadoPrograma(formulario.getCodEstadoPrograma());
			programacion.setNumProgramaCorrel(t10420ProgramacionDAO.obtenerCorrelativoProgramacion(programacion.getAnioProgramacion()));
			programacion.setNumProgramacion(t10420ProgramacionDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_SOLICITUD_PROGRAMACION, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10420ProgramacionDAO.save(programacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);

			// Historial
			HistorialEstadosPrograma t10410 = new HistorialEstadosPrograma();
			t10410.setNumProgramacion(formulario.getNumProgramacion());
			t10410.setFecEstadoProgram(new Date());
			t10410.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_ASIGNADO);
			t10410.setFecCrea(new Date());
			t10410.setNumHistoriaProgram(t10410HistEstadoProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_HISTORIAL_ESTADOPROG, AccionesControlConstantes.DATASOURCE_DGSICOBF));
			t10410.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
			t10410.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
			t10410.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			t10410.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
			t10410HistEstadoProgDAO.save(t10410, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		} else {
			programacion.setNumProgramacion(formulario.getNumProgramacion());
			programacion.setFecModif(new Date());
			programacion.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
			programacion.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
			t10420ProgramacionDAO.update(programacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		}
		logger.debug(String.format("programacion.getNumProgramacion() => %d", programacion.getNumProgramacion()));

		// Inconsistencias
		PropertyParams detalleParams;
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", formulario.getNumProgramacion());
		propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		// DAR DE BAJA TODOS ANTES INCONSISTENCIAS
		List<TipoInconsistenciaPrograma> t10425lista = t10425TipInconProgDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10425lista)) {
			for (TipoInconsistenciaPrograma t10425 : t10425lista) {
				t10425.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
				t10425.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
				t10425TipInconProgDAO.update(t10425, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		} 
		List<CheckElementBean> inconsistencias = formulario.getInconsistencias();
		if (!MaestrosUtilidades.isEmpty(inconsistencias)) {
			for (CheckElementBean incosistencia : inconsistencias) {
				TipoInconsistenciaPrograma t10425 = new TipoInconsistenciaPrograma();
				t10425.setNumProgramacion(programacion.getNumProgramacion());
				t10425.setCodTipoInconsistencia(incosistencia.getCodigo());
				if (AccionesControlConstantes.OPCION_OTROS.equals(incosistencia.getCodigo())) {
					t10425.setDesOtraInconsistencia(formulario.getDesOtroIncosistencia());
				}
				t10425.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
				t10425.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
				// Validar si esta registrado
				detalleParams = new PropertyParams();
				detalleParams.addProperty("numProgramacion", formulario.getNumProgramacion());
				detalleParams.addProperty("codTipoInconsistencia", incosistencia.getCodigo());
				List<TipoInconsistenciaPrograma> existe = t10425TipInconProgDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				if (!MaestrosUtilidades.isEmpty(existe)) {
					TipoInconsistenciaPrograma bexiste = existe.get(0);
					t10425.setFecModif(new Date());
					t10425.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
					t10425.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
					t10425.setNumInconsistenciaProgram(bexiste.getNumInconsistenciaProgram());
					t10425.setFecCrea(bexiste.getFecCrea());
					t10425.setDirIpusucrea(bexiste.getDirIpusucrea());
					t10425.setCodUsuCrea(bexiste.getCodUsuCrea());
					t10425TipInconProgDAO.update(t10425, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				} else {
					t10425.setFecCrea(new Date());
					t10425.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
					t10425.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
					t10425.setNumInconsistenciaProgram(t10425TipInconProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_TIPINCONS_PROGRAMA, AccionesControlConstantes.DATASOURCE_DGSICOBF));
					t10425TipInconProgDAO.save(t10425, AccionesControlConstantes.DATASOURCE_DGSICOBF);	
				}
			}
		}
		// Tipo BIEN
		if (AccionesControlConstantes.COD_TIP_PROG_BIEN.equals(programacion.getCodTipoProgram())) {
			// DAR DE BAJA TODOS LOS BIENES
			List<BienProgramacion> t10398lista = t10398BienProgDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10398lista)) {
				for (BienProgramacion t10398 : t10398lista) {
					t10398.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
					t10398.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
					t10398BienProgDAO.update(t10398, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
			// tipo bienes
			List<CheckElementBean> tipoBienes = formulario.getTipoBienes().stream().filter(t -> Arrays.asList(AccionesControlConstantes.OPCION_OTROS,
					AccionesControlConstantes.OPCION_TIPO_BIEN_DISOLVENTE,
					AccionesControlConstantes.OPCION_TIPO_BIEN_MEZCLA).indexOf(t.getCodigo()) >= 0).collect(Collectors.toList());
			if (!MaestrosUtilidades.isEmpty(tipoBienes)) {
				for (CheckElementBean tipoBien : tipoBienes) {
					BienProgramacion t10398 = new BienProgramacion();
					t10398.setNumProgramacion(programacion.getNumProgramacion());
					t10398.setCodTipoBien(tipoBien.getCodigo());
					t10398.setDesBien(formulario.getDesOtroBien());
					t10398.setCodBien(AccionesControlConstantes.COD_BIEN_VACIO);
					t10398.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					t10398.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					detalleParams = new PropertyParams();
					detalleParams.addProperty("numProgramacion", formulario.getNumProgramacion());
					detalleParams.addProperty("codTipoBien", tipoBien.getCodigo());
					detalleParams.addProperty("codBien", AccionesControlConstantes.COD_BIEN_VACIO);
					List<BienProgramacion> existe = t10398BienProgDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					if (!MaestrosUtilidades.isEmpty(existe)) {
						BienProgramacion bexiste = existe.get(0);
						t10398.setFecModif(new Date());
						t10398.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
						t10398.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
						t10398.setNumBienPrograma(bexiste.getNumBienPrograma());
						t10398.setFecCrea(bexiste.getFecCrea());
						t10398.setDirIpusucrea(bexiste.getDirIpusucrea());
						t10398.setCodUsuCrea(bexiste.getCodUsuCrea());
						t10398BienProgDAO.update(t10398, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					} else {
						t10398.setFecCrea(new Date());
						t10398.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
						t10398.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
						t10398.setNumBienPrograma(t10398BienProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_BIENES_PROGRAMACION, AccionesControlConstantes.DATASOURCE_DGSICOBF));
						t10398BienProgDAO.save(t10398, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					}
				}
			}
			// bienes
			List<CheckElementBean> bienes = formulario.getBienesFiscalizados();
			if (!MaestrosUtilidades.isEmpty(bienes)) {
				for (CheckElementBean bien : bienes) {
					BienProgramacion t10398 = new BienProgramacion();
					t10398.setNumProgramacion(programacion.getNumProgramacion());
					t10398.setCodTipoBien(bien.getTipo());
					t10398.setCodBien(bien.getCodigo());
					t10398.setDesBien(null);
					t10398.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					t10398.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					detalleParams = new PropertyParams();
					detalleParams.addProperty("numProgramacion", formulario.getNumProgramacion());
					detalleParams.addProperty("codTipoBien", bien.getTipo());
					detalleParams.addProperty("codBien", bien.getCodigo());
					List<BienProgramacion> existe = t10398BienProgDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					if (!MaestrosUtilidades.isEmpty(existe)) {
						BienProgramacion bexiste = existe.get(0);
						t10398.setFecModif(new Date());
						t10398.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
						t10398.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
						t10398.setNumBienPrograma(bexiste.getNumBienPrograma());
						t10398.setFecCrea(bexiste.getFecCrea());
						t10398.setDirIpusucrea(bexiste.getDirIpusucrea());
						t10398.setCodUsuCrea(bexiste.getCodUsuCrea());
						t10398BienProgDAO.update(t10398, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					} else {
						t10398.setFecCrea(new Date());
						t10398.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
						t10398.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
						t10398.setNumBienPrograma(t10398BienProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_BIENES_PROGRAMACION, AccionesControlConstantes.DATASOURCE_DGSICOBF));
						t10398BienProgDAO.save(t10398, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					}
				}
			}
		}
		// Tipo Servicio
		else if (AccionesControlConstantes.COD_TIP_PROG_SERVICIO.equals(programacion.getCodTipoProgram())) {
			// DAR DE BAJA TODOS LOS Actividades
			List<ActividadPrograma> t10388lista = t10388ActividProgDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10388lista)) {
				for (ActividadPrograma t10388 : t10388lista) {
					t10388.setIndDel(MaestrosConstantes.REGISTRO_ELIMINADO);
					t10388.setIndEst(MaestrosConstantes.REGISTRO_INACTIVO);
					t10388ActividProgDAO.update(t10388, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
			}
			// actividades
			List<CheckElementBean> actividades = formulario.getActividades();
			if (!MaestrosUtilidades.isEmpty(actividades)) {
				for (CheckElementBean actividad : actividades) {
					ActividadPrograma t10388 = new ActividadPrograma();
					t10388.setCodActividad(actividad.getCodigo());
					t10388.setNumProgramacion(programacion.getNumProgramacion());
					t10388.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
					t10388.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
					detalleParams = new PropertyParams();
					detalleParams.addProperty("numProgramacion", formulario.getNumProgramacion());
					detalleParams.addProperty("codActividad", actividad.getCodigo());
					List<ActividadPrograma> existe = t10388ActividProgDAO.findByProperties(detalleParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					if (!MaestrosUtilidades.isEmpty(existe)) {
						ActividadPrograma bexiste = existe.get(0);
						t10388.setFecModif(new Date());
						t10388.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
						t10388.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
						t10388.setNumActividadPrograma(bexiste.getNumActividadPrograma());
						t10388.setFecCrea(bexiste.getFecCrea());
						t10388.setDirIpusucrea(bexiste.getDirIpusucrea());
						t10388.setCodUsuCrea(bexiste.getCodUsuCrea());
						t10388ActividProgDAO.update(t10388, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					} else {
						t10388.setNumActividadPrograma(t10388ActividProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_ACTIVIDADES_PROGRAMADAS, AccionesControlConstantes.DATASOURCE_DGSICOBF));
						t10388.setFecCrea(new Date());
						t10388.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
						t10388.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
						t10388ActividProgDAO.save(t10388, AccionesControlConstantes.DATASOURCE_DGSICOBF);
					}
				}
			}
		}

		formulario.setNumProgramacion(programacion.getNumProgramacion());
		respuesta.setExito(true);
		respuesta.setData(formulario);
		respuesta.setMensaje(String.format(AccionesControlMensajes.CUS06_REGISTRO_EXITO, MaestrosUtilidades.toBlank(programacion.getNumProgramaCorrel())));
		return respuesta;
	}
	
	
	@Override
	public List<ActividadesBean> listarBienFiscalizado(String codTipoBien){
		if(logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosServiceImpl - listarBienFiscalizado");
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("codTipoBien", codTipoBien);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		List<BienFiscal> t7883lista = t7883BienFiscalDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		List<ActividadesBean> bienes = new ArrayList<>();
		if(!MaestrosUtilidades.isEmpty(t7883lista)){
			for (BienFiscal t7883 : t7883lista){
				bienes.add(new ActividadesBean(t7883.getCodBien(), t7883.getDesBien()));
			}
		}
		return bienes;
	}
	
	
	@Override
	public List<ActividadesBean> listarActividadFiscalizada() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosServiceImpl - listarActividadFiscalizada");
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("indServicio", AccionesControlConstantes.COD_IND_SERVICIO);
		propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<Actividades> t7882lista = t7882ActividadDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		List<ActividadesBean> actividades = new ArrayList<>();
		if (!MaestrosUtilidades.isEmpty(t7882lista)) {
			for (Actividades t7882 : t7882lista) {
				actividades.add(new ActividadesBean(t7882.getCodActividad(), t7882.getNomActividad(), null));
			}
		}
		return actividades;
	}

	@Override
	public List<PersonaBean> listarProgramador() {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosServiceImpl - listarProgramador");
		List<DistribucionGrupo> t8303lista = t8303DistriGrupoDAO.listarProgramador(AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD,
				AccionesControlConstantes.COD_CARGO_PROGRAMADOR, MaestrosConstantes.REGISTRO_ACTIVO);
		List<PersonaBean> programadores = new ArrayList<>();
		if (!MaestrosUtilidades.isEmpty(t8303lista)) {
			for (DistribucionGrupo t8303 : t8303lista) {
				WSPersonalIqbfBean personal = servicioWebService.obtenerPersonalIqbf(t8303.getCodPersonal());
				if (!MaestrosUtilidades.isEmpty(personal)) {
					PersonaBean personaBean = new PersonaBean();
					personaBean.setCodPers(t8303.getCodPersonal());
					personaBean.setNombreCompleto(personal.getNomCompleto());
					programadores.add(personaBean);	
				}
			}
		}
		return programadores;
	}

	@Override
	public ProgramacionBean obtenerDatosProgramacion(Long numProgramacion) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosServiceImpl - obtenerDatosProgramacion");
		ProgramacionBean programacionBean = null;
		Programacion programacion = t10420ProgramacionDAO.findById(numProgramacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(programacion)) {
			programacionBean = new ProgramacionBean();
			MaestrosUtilidades.copiarValoresBean(programacion, programacionBean);
			programacionBean.setInconsistencias(new ArrayList<>());
			programacionBean.setActividades(new ArrayList<>());
			programacionBean.setBienesFiscalizados(new ArrayList<>());
			programacionBean.setTipoBienes(new ArrayList<>());
			programacionBean.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(programacion.getFecProgramacion()));
			// Incosistencias
			PropertyParams propertyParams = new PropertyParams();
			propertyParams.addProperty("numProgramacion", numProgramacion);
			propertyParams.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			propertyParams.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
			List<TipoInconsistenciaPrograma> t10425lista = t10425TipInconProgDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
			if (!MaestrosUtilidades.isEmpty(t10425lista)) {
				List<CheckElementBean> inconsistencias = t10425lista.stream().map(t10425 -> {
					CheckElementBean check = new CheckElementBean(t10425.getCodTipoInconsistencia(), t10425.getDesOtraInconsistencia(), true);
					check.setOtros(t10425.getDesOtraInconsistencia());
					DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_INCONSISTENCIAS,
							t10425.getCodTipoInconsistencia());
					if (!MaestrosUtilidades.isEmpty(catalogo)) {
						check.setDescripcion(catalogo.getDescripcionDataCatalogo());
					}
					return check;
				}).collect(Collectors.toList());
				String otraIncosistencia = inconsistencias.stream()
								.filter(check -> AccionesControlConstantes.OPCION_OTROS.equals(check.getCodigo()))
								.map(CheckElementBean::getOtros).findFirst().orElse(null);
				programacionBean.setDesOtroIncosistencia(otraIncosistencia);
				programacionBean.setInconsistencias(inconsistencias);
			}
			// Tipo Bien
			if (AccionesControlConstantes.COD_TIP_PROG_BIEN.equals(programacion.getCodTipoProgram())) {
				List<BienProgramacion> t10398lista = t10398BienProgDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				if (!MaestrosUtilidades.isEmpty(t10398lista)) {
					List<CheckElementBean> bienes = t10398lista.stream().filter(t10398 -> {
						return Arrays.asList(AccionesControlConstantes.OPCION_OTROS,
								AccionesControlConstantes.OPCION_TIPO_BIEN_DISOLVENTE,
								AccionesControlConstantes.OPCION_TIPO_BIEN_MEZCLA).indexOf(t10398.getCodTipoBien()) < 0;
					}).map(t10398 -> {
						CheckElementBean check = new CheckElementBean(t10398.getCodBien(), t10398.getDesBien(), true, t10398.getCodTipoBien());
						PropertyParams params = new PropertyParams();
						params.addProperty("codBien", t10398.getCodBien());
						params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
						List<BienFiscal> t7883lista = t7883BienFiscalDAO.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
						if (!MaestrosUtilidades.isEmpty(t7883lista)) {
							check.setDescripcion(t7883lista.get(0).getDesBien());
						}
						return check;
						}).collect(Collectors.toList());
					Set<String> setTipoBienes = t10398lista.stream().map(BienProgramacion::getCodTipoBien).collect(Collectors.toSet());
					List<CheckElementBean> tipoBienes = setTipoBienes.stream().map(tipoBien -> {
						CheckElementBean check = new CheckElementBean(tipoBien, true);
						if (!AccionesControlConstantes.OPCION_OTROS.equals(tipoBien)) {
							DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_BIEN,
									tipoBien);
							if (!MaestrosUtilidades.isEmpty(catalogo)) {
								check.setDescripcion(catalogo.getDescripcionDataCatalogo());
							}	
						} else {
							check.setDescripcion(AccionesControlConstantes.OPCION_DESCRIPCION_OTROS);
						}
						return check;
					}).collect(Collectors.toList());
					String otroBien = t10398lista.stream()
							.filter(check -> Arrays.asList(AccionesControlConstantes.OPCION_OTROS,
									AccionesControlConstantes.OPCION_TIPO_BIEN_DISOLVENTE,
									AccionesControlConstantes.OPCION_TIPO_BIEN_MEZCLA).indexOf(check.getCodTipoBien()) >= 0)
							.map(BienProgramacion::getDesBien).findFirst().orElse(null);
					programacionBean.setDesOtroBien(otroBien);
					programacionBean.setBienesFiscalizados(bienes);
					programacionBean.setTipoBienes(tipoBienes);
				}
			}
			// Tipo Servicio
			else if (AccionesControlConstantes.COD_TIP_PROG_SERVICIO.equals(programacion.getCodTipoProgram())) {
				List<ActividadPrograma> t10388lista = t10388ActividProgDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
				if (!MaestrosUtilidades.isEmpty(t10388lista)) {
					List<CheckElementBean> actividades = t10388lista.stream().map(t10388 -> {
						CheckElementBean  check = new CheckElementBean(t10388.getCodActividad(), true);
						Actividades t7882 = t7882ActividadDAO.findById(t10388.getCodActividad(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
						if (!MaestrosUtilidades.isEmpty(t7882)) {
							check.setDescripcion(t7882.getDesActividad());
						}
						return check;
					}).collect(Collectors.toList());
					programacionBean.setActividades(actividades);
				}
			}
			programacionBean.setCodEstadoInforme(programacion.getCodEstadoInforme());
			ProgramaControl pControl = t8276CatProgCtrlDAO.findById(programacion.getCodProgctrl(), AccionesControlConstantes.DATASOURCE_DCSICOBF);	
			if(!MaestrosUtilidades.isEmpty(pControl)){
				programacionBean.setDesProgramaControl(pControl.getDesDenominacion());
			}
			obtenerDatosCatalogo(programacionBean,programacion);
		}
		return programacionBean;
	}
	@Override
	public InformeSeleccionBean obtenerInformeSelecccion(Long numInforme){
		InformeSeleccion informeSeleccion = t10411InformeSelecDAO.obtenerInformeSelecccion(numInforme);
		InformeSeleccionBean informeSeleccionBean = new InformeSeleccionBean();
		informeSeleccionBean.setNumInformeSeleccion(informeSeleccion.getNumInformeSeleccion());
		informeSeleccionBean.setAnioInforme(informeSeleccion.getAnioInforme());
		informeSeleccionBean.setCodEstadoInforme(informeSeleccion.getCodEstadoInforme());
		informeSeleccionBean.setCodUnidadOrganica(informeSeleccion.getCodUnidadOrganica());
		DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_INFORMESELECCION,
				informeSeleccion.getCodEstadoInforme());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			informeSeleccionBean.setDesEstadoInforme(catalogo.getDescripcionDataCatalogo());
		}
		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numInformeSeleccion", informeSeleccion.getNumInformeSeleccion());		
		List<ArchivoInformeSeleccion> listArchivoSelecion= t10390ArcInformeDAO.findByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		
		if(!MaestrosUtilidades.isEmpty(listArchivoSelecion)){
			ArchivoBean archivoInforme = comunService.obtenerArchivo(listArchivoSelecion.get(0).getNumArchivo());
			if (!MaestrosUtilidades.isEmpty(archivoInforme)) {
				informeSeleccionBean.setArchivoInforme(archivoInforme);
			}
			if(listArchivoSelecion.size()>1){
				ArchivoBean archivoReporte = comunService.obtenerArchivo(listArchivoSelecion.get(1).getNumArchivo());
				
				if (!MaestrosUtilidades.isEmpty(archivoReporte)) {
					informeSeleccionBean.setArchivoReporte(archivoReporte);
				}
			}
		}
		informeSeleccionBean.setNumInformeUnion(informeSeleccion.getNumInformeUnion());
		return informeSeleccionBean;
	}
	
	private void obtenerDatosCatalogo(ProgramacionBean programacionBean,Programacion valores){
		DataCatalogoBean catalogo = null;
		if (!MaestrosUtilidades.isEmpty(valores.getCodProgramador())) {
			WSPersonalIqbfBean servicioWebServ = servicioWebService.obtenerPersonalIqbf(valores.getCodProgramador());
			if (!MaestrosUtilidades.isEmpty(servicioWebServ)) {
				programacionBean.setDesProgramador(servicioWebServ.getNomCompleto()); 
				programacionBean.setNomProgramador(servicioWebServ.getNomCompleto());
			} else {
				programacionBean.setDesProgramador("");
				programacionBean.setNomProgramador("");
			}
		}
		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_FUENTES_PROGRAMAS,
				valores.getCodFuente());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesFuente(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_PROGRAMACION,
				valores.getCodTipoProgram());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesTipoProgram(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS,
				valores.getCodEstadoPrograma());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesEstadoProgram(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_SUBESTADOS_PROGRAMACION,
				valores.getCodSubEstadoProgram());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesSubEstprogram(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_PROCESOS_PROGRAMACION,
				valores.getCodProceso());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesProceso(catalogo.getDescripcionDataCatalogo());
		}

		catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_INFORMESELECCION,
				valores.getCodEstadoInforme());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			programacionBean.setDesEstadoInforme(catalogo.getDescripcionDataCatalogo());
		}
		if (!MaestrosUtilidades.isEmpty(valores.getCodProgramadorAdmin())) {
			WSPersonalIqbfBean servicioWebServ = servicioWebService
					.obtenerPersonalIqbf(valores.getCodProgramadorAdmin());
			if (!MaestrosUtilidades.isEmpty(servicioWebServ)) {
				programacionBean.setNomProgramadorAdmin(servicioWebServ.getNomCompleto());
			} else {
				programacionBean.setNomProgramadorAdmin("");
			}
		}
	}
	
	@Override
	public ResponseBean<ProgramacionBean> enviarProgramacion(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosServiceImpl - enviarProgramacion");
		AsignaProgramacion t10392 = new AsignaProgramacion();
		t10392.setNumProgramacion(formulario.getNumProgramacion());
		t10392.setIndTipAsignacion(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR_ADMIN); // FIX
		t10392.setCodProgramador(formulario.getCodProgramador());
		t10392.setFecInicioAsignacion(new Date());
		t10392.setFecFinAsignacion(MaestrosUtilidades.stringToDate(AccionesControlConstantes.FECHA_ESTANDAR, MaestrosConstantes.FORMAT_FECHAHORA_YYYYMMDDHHMMSS));
		t10392.setFecCrea(new Date());
		t10392.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10392.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10392.setNumAsignacion(t10392AsignProgramDAO.obtenerSequencia("completar", AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10392AsignProgramDAO.save(t10392, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		Programacion t10420 = t10420ProgramacionDAO.findById(formulario.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		t10420.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_ASIGNADO);
		t10420.setFecModif(new Date());
		t10420.setCodProgramador(formulario.getCodProgramador());
		t10420.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
		t10420.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
		t10420ProgramacionDAO.update(t10420, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// Historial
		HistorialEstadosPrograma t10410 = new HistorialEstadosPrograma();
		t10410.setNumProgramacion(formulario.getNumProgramacion());
		t10410.setFecEstadoProgram(new Date());
		t10410.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_ASIGNADO);
		t10410.setFecCrea(new Date());
		t10410.setNumHistoriaProgram(t10410HistEstadoProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_HISTORIAL_ESTADOPROG, AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10410.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10410.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10410.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10410.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10410HistEstadoProgDAO.save(t10410, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// Enviar correo (TODO: Copiar a supervisor)
		try {
			String codSupervisor = t8303DistriGrupoDAO.obtenerSupervisorPersonal(formulario.getAuditoriaBean().getNroRegistro());
			WSPersonalIqbfBean solicitante = servicioWebService.obtenerPersonalIqbf(codSupervisor);
			MensajeIqbf t8414 = t8414MensajeIqbfDAO.findById(AccionesControlConstantes.COD_MENSAJE_CORREO_F10, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t8414) && !MaestrosUtilidades.isEmpty(solicitante)) {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("nroProgramacion", "");
				parametros.put("nroInformeSeleccion", "XXXX");
				parametros.put("estadoProgramacion", "XXXX");
				CorreoBean correoBean = new CorreoBean();
				correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
				correoBean.setAsunto(t8414.getDesCorta());
				correoBean.setReceptor(solicitante.getDirCorreo().trim());
				correoBean.setMensaje(AccionesControlUtil.generarMensaje(t8414.getDesCuerpo(), parametros));
				CorreoUtil.enviarCorreo(correoBean);
			}
		} catch(Exception e) {
			logger.error(String.format("errorEnviarCorreo %s", e.getMessage()), e);
		}
		return new ResponseBean<ProgramacionBean>(formulario);
	}

	@Override
	public ResponseBean<ProgramacionBean> cancelarProgramacion(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosServiceImpl - cancelarProgramacion");
		Programacion t10420 = t10420ProgramacionDAO.findById(formulario.getNumProgramacion(), AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (AccionesControlConstantes.COD_EST_PROGRAM_EN_PROCESO_CARGA.equals(t10420.getCodEstadoPrograma())) {
			return new ResponseBean<ProgramacionBean>(false, MensajesExcepciones.CUS06_EXCP_009);
		}
		t10420.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_CANCELADA);
		t10420.setFecModif(new Date());
		t10420.setDesSusCancela(formulario.getDesSusCancela());
		t10420.setNumInformeCancelacion(formulario.getNumInformeCancelacion());
		t10420.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
		t10420.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
		t10420ProgramacionDAO.update(t10420, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		// Historial
		HistorialEstadosPrograma t10410 = new HistorialEstadosPrograma();
		t10410.setNumProgramacion(formulario.getNumProgramacion());
		t10410.setCodEstadoPrograma(AccionesControlConstantes.COD_EST_PROGRAM_CANCELADA);
		t10410.setFecEstadoProgram(new Date());
		t10410.setFecCrea(new Date());
		t10410.setNumHistoriaProgram(t10410HistEstadoProgDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_HISTORIAL_ESTADOPROG, AccionesControlConstantes.DATASOURCE_DGSICOBF));
		t10410.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10410.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10410.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		t10410.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
		t10410HistEstadoProgDAO.save(t10410, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		return new ResponseBean<ProgramacionBean>(formulario);
	}

	@Override
	public ResponseBean<ProgramacionBean> guardarAsignacionProgramacion(ProgramacionBean formulario) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio GestionProgramaOtrosServiceImpl - guardarAsignacionProgramacion");
		AsignaProgramacion t10392 = new AsignaProgramacion();
		t10392.setNumProgramacion(formulario.getNumProgramacion());
		t10392.setIndTipAsignacion(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR_ADMIN);
		t10392.setCodProgramador(formulario.getCodProgramador());
		t10392.setFecInicioAsignacion(new Date());
		t10392.setFecFinAsignacion(MaestrosUtilidades.stringToDate(AccionesControlConstantes.FECHA_ESTANDAR, MaestrosConstantes.FORMAT_FECHAHORA_YYYYMMDDHHMMSS));
		t10392.setFecCrea(new Date());
		t10392.setCodUsuCrea(formulario.getAuditoriaBean().getLogin());
		t10392.setDirIpusucrea(formulario.getAuditoriaBean().getNumIp());
		t10392AsignProgramDAO.save(t10392, AccionesControlConstantes.DATASOURCE_DGSICOBF);

		PropertyParams property = new PropertyParams();
		property.addProperty("numProgramacion", formulario.getNumProgramacion());
		property.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		property.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		List<InformeSeleccion> t10411lista = t10411InformeSelecDAO.findByProperties(property, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10411lista)) {
			for (InformeSeleccion informeSeleccion : t10411lista) {
				informeSeleccion.setCodEstadoInforme(AccionesControlConstantes.COD_ESTADO_INFORME_PENDIENTEASIG);
				informeSeleccion.setFecModif(new Date());
				informeSeleccion.setCodUsuModif(formulario.getAuditoriaBean().getLogin());
				informeSeleccion.setDirIpusumodif(formulario.getAuditoriaBean().getNumIp());
				t10411InformeSelecDAO.update(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			}
		}

		// Enviar correo (TODO: Copiar a supervisor)
		try {
			WSPersonalIqbfBean programador = servicioWebService.obtenerPersonalIqbf(formulario.getCodProgramador());
			MensajeIqbf t8414 = t8414MensajeIqbfDAO.findById(AccionesControlConstantes.COD_MENSAJE_CORREO_F15, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if (!MaestrosUtilidades.isEmpty(t8414) && !MaestrosUtilidades.isEmpty(programador)) {
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("numeroProgramacion", "");
				parametros.put("nombreProgramaControl", "XXXX");
				CorreoBean correoBean = new CorreoBean();
				correoBean.setEmisor(MaestrosConstantes.CORREO_EMISOR);
				correoBean.setAsunto(t8414.getDesCorta());
				correoBean.setReceptor(programador.getDirCorreo().trim());
				correoBean.setMensaje(AccionesControlUtil.generarMensaje(t8414.getDesCuerpo(), parametros));
				CorreoUtil.enviarCorreo(correoBean);
			}
		} catch(Exception e) {
			logger.error(String.format("errorEnviarCorreo %s", e.getMessage()), e);
		}
		return new ResponseBean<ProgramacionBean>(formulario);
	}

}
