package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.GrupoProcesoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PreseleccionAsignacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DistribucionGrupo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.GrupoProceso;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PreseleccionAsignacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10416PreseleAsigDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8311GrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.MensajesExcepciones;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class AsignacionMasivaAuditorServiceImpl implements AsignacionMasivaAuditorService {
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@EJB
	private T8276CatProgCtrlDAO t8276CatProgCtrlDAO;
	
	@EJB
	private T10415OrdenAccionDAO t10415OrdenAccionDAO;
	
	@EJB
	private T10416PreseleAsigDAO t10416PreseleAsigDAO;
	
	@EJB
	private T8311GrupoDAO t8311GrupoDAO;
	
	@EJB
	private T8303DistriGrupoDAO t8303DistriGrupoDAO;
	
	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;

	@EJB
	private ServicioWebService servicioWebServiceImpl;
	
	@Override
	public List<OrdenAccionBean> obtenerResumenOrdPend(ProgramacionBean programacionBean) {
		
		List<OrdenAccionBean> listaOrdenAccionBean=new ArrayList<OrdenAccionBean>();
		Programacion filtro = new Programacion();
		filtro.setNumProgramacion(programacionBean.getNumProgramacion());
		filtro.setNumInforme(programacionBean.getNumInforme());
		
		Programacion listProgramacionBean = t10420ProgramacionDAO.obtenerResuProgramacion(filtro);
		
		if (!MaestrosUtilidades.isEmpty(listProgramacionBean)) {
			logger.debug(MensajesExcepciones.CUS29_EXCP_002);
			return listaOrdenAccionBean;
		}
	/*	if (listProgramacionBean.getCodProgctrl().equals(MaestrosConstantes.COD_TIP_PROG_OTROS)) {
			logger.debug(MensajesExcepciones.CUS29_EXCP_003);
			return listaOrdenAccionBean;
		}*/
		
		UsuarioBean usuarioBean = new UsuarioBean();
		//FIXME COMPARAR NUMGRUPO
//		if(!listProgramacionBean.getNumGrupo().equals(usuarioBean.get));
		
		if(!MaestrosUtilidades.isEmpty(listaOrdenAccionBean)) {
			logger.debug(MensajesExcepciones.CUS29_EXCP_005);
			return listaOrdenAccionBean;
		}
		
		OrdenAccion objOrdenAccion = new OrdenAccion();
		objOrdenAccion.setNumProgramacion(programacionBean.getNumProgramacion());
		objOrdenAccion.setNumProgramacion(programacionBean.getNumProgramacion());
		
//		listaOrdenAccionBean = t10415OrdenAccionDAO.obtenerResumenOrdPend(objOrdenAccion);
//		ProgramaControl filtro=new ProgramaControl();
//		filtro.setNumProgramacion(programacionBean.getNumProgramaCorrel());
//		filtro.setNumInforme(programacionBean.getNumInforme());
		
//		List<ProgramaControl> t8276CatProgCtrl= t8276CatProgCtrlDAO.obtenerProgCtrlDefinido(filtro);
		
		boolean pendientesAsignar=true;
//		if (!MaestrosUtilidades.isEmpty(t8276CatProgCtrl)) {
//			for (ProgramaControl programaControl : t8276CatProgCtrl) {
//				if(AccionesControlConstantes.COD_TIP_PROG_OTROS.equals(programaControl.getCodProgctrl())) {
//					pendientesAsignar=false;
//					break;
//				}
//			}
//		}
		return listaOrdenAccionBean;
		
//		if(pendientesAsignar) {
//			OrdenAccion filtroAccion=new OrdenAccion();
//			filtroAccion.setNumProgramacion(programacionBean.getNumProgramacion());
//			filtroAccion.setNumInfSelecc(programacionBean.getNumInforme());
//			filtroAccion.setNoSubSano(AccionesControlConstantes.COD_INCON_NO_SUBSANO);
//			filtroAccion.setParcialmente(AccionesControlConstantes.COD_INCON_SUBSANADO_PARCIAL);
//			filtroAccion.setCodEstOrden(AccionesControlConstantes.COD_ESTADO_ORDEN_PENDIENTE);
//			filtroAccion.setCodResulOrden(AccionesControlConstantes.COD_RESULTADO_ORDEN_NO_CONFORME);
//	
//			List<OrdenAccion> t10415OrdenAccion=t10415OrdenAccionDAO.obtenerResumenOrdPend(filtroAccion);
//			if (!MaestrosUtilidades.isEmpty(t10415OrdenAccion)) {
//				OrdenAccionBean ordenAccionBean=null;
//				for (OrdenAccion ordenAccion : t10415OrdenAccion) {
//					ordenAccionBean=new OrdenAccionBean();
//					ordenAccionBean.setCodResultadoInconsistenciaPre(ordenAccion.getCodResultadoInconsistenciaPre());
//					lista.add(ordenAccionBean);
//				}
//			}
//		}
//		return lista;
	}
	
	@Override
	public List<PreseleccionAsignacionBean> listarAuditoresPreSeleccionados (PreseleccionAsignacionBean preseleccionAsignacionBean){
	//public List<PreseleccionAsignacionBean> obtenerAuditorAsignar (PreseleccionAsignacionBean preseleccionAsignacionBean){
		
		 List<PreseleccionAsignacionBean> lista=new ArrayList<PreseleccionAsignacionBean>();
		 
		PreseleccionAsignacion filtro=new PreseleccionAsignacion();
		filtro.setNumProgramacion(filtro.getNumProgramacion());
		//filtro.setNumInfSelecc(filtro.getNumInfSelecc());

		List<PreseleccionAsignacion>  t10416PreseleAsig= t10416PreseleAsigDAO.obtenerAuditorAsignar(filtro);
		if (!MaestrosUtilidades.isEmpty(t10416PreseleAsig)) {
			PreseleccionAsignacionBean preseleccionAsignacionBean2=null;
		for (PreseleccionAsignacion preseleccionAsignacion : t10416PreseleAsig) {
			preseleccionAsignacionBean2=new PreseleccionAsignacionBean();
			preseleccionAsignacionBean2.setCodAuditor(preseleccionAsignacion.getCodAuditor());
			lista.add(preseleccionAsignacionBean2);
		}
		}
		return lista;
	}
	
	@Override
	
	public void eliminarAuditorPreseleccionado(PreseleccionAsignacionBean preseleccionAsignacionBean){
	//public void eliminarAuditor(PreseleccionAsignacionBean preseleccionAsignacionBean){
		
		PreseleccionAsignacion preseleccionAsignacion=new PreseleccionAsignacion();
		
		preseleccionAsignacion.setNumAsignacionTemp(preseleccionAsignacionBean.getNumAsignacionTemp());
		preseleccionAsignacion.setIndDel( AccionesControlConstantes.REGISTRO_ELIMINADO);
	
		t10416PreseleAsigDAO.update(preseleccionAsignacion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
	}
	
	@Override
	public void guardarAsignacion(ProgramacionBean filtro) {

		PropertyParams propertyParams = new PropertyParams();
		propertyParams.addProperty("numProgramacion", filtro.getNumProgramacion());
		propertyParams.addProperty("codProgctrl", filtro.getCodProgramaControl());

		List<Programacion> t10420Programacion = t10420ProgramacionDAO.findByProperties(propertyParams,
				AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t10420Programacion)) {
			for (Programacion programacion : t10420Programacion) {
				if (!programacion.getIndAsigMasOrdenNoConf()
						.equals(AccionesControlConstantes.COD_PROGRAMA_EN_PROCESO_ASIG)) {
					programacion.setIndAsigMasOrdenNoConf(AccionesControlConstantes.COD_PROGRAMA_EN_PROCESO_ASIG);
					t10420ProgramacionDAO.update(programacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);
					// Invocar a proceso PENDIENTE!!!
					// asignarOrdenesNoConformeBatchServiceImpl
				}
			}
		}

	}
	
	@Override
	public List<GrupoProcesoBean> listarSupervisionAuditor (GrupoProcesoBean filtro){
	
		List<GrupoProcesoBean> lista=new ArrayList<GrupoProcesoBean>();
		PropertyParams propertyParams=new PropertyParams();
		propertyParams.addProperty("codTipoProceso", filtro.getCodTipoProceso()); 
		List<GrupoProceso> t8311Grupo=	t8311GrupoDAO.findByProperties(propertyParams,  AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(t8311Grupo)) {
			GrupoProcesoBean grupoProcesoBean=null;
		for (GrupoProceso grupoProceso : t8311Grupo) {
			grupoProcesoBean=new GrupoProcesoBean();
			grupoProcesoBean.setNumGrupo(grupoProceso.getNumGrupo());
			grupoProcesoBean.setNomGrupo(grupoProceso.getNomGrupo());
			lista.add(grupoProcesoBean);
		}
		}
		return lista;
	}
	
	@Override
	public List<DistribucionGrupoBean> listarAuditoresVigentes (DistribucionGrupoBean filtro){
		
		List<DistribucionGrupoBean> lista =new ArrayList<DistribucionGrupoBean>();
		String numGrupo=String.valueOf(filtro.getNumGrupo());
		String codTipoProceso=AccionesControlConstantes.COD_TIPO_PROCESO_TRAZABILIDAD;
		String codCargo=AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL;
		String indEst=AccionesControlConstantes.REGISTRO_ACTIVO;

		List<DistribucionGrupo> t8303DistriGrupo=t8303DistriGrupoDAO.listarAuditor(new ArrayList<String>(), codTipoProceso, numGrupo, codCargo, indEst);
		if (!MaestrosUtilidades.isEmpty(t8303DistriGrupo)) {
			DistribucionGrupoBean distribucionGrupoBean=null;
		for (DistribucionGrupo distribucionGrupo : t8303DistriGrupo) {
			distribucionGrupoBean=new DistribucionGrupoBean();
			distribucionGrupoBean.setCodPersonal(distribucionGrupo.getCodPersonal());
			lista.add(distribucionGrupoBean);
		}
		}
		return lista;
	}
	
	@Override
	public void guardarAuditorPreselec (PreseleccionAsignacionBean preseleccionAsignacionBean){
		Long numAsigtTemp=t10416PreseleAsigDAO.obtenerSequencia(AccionesControlConstantes.SECUENCIA_PRESELECCION_ASIGNACION, AccionesControlConstantes.DATASOURCE_DGSICOBF);
		String codTipoAccion=AccionesControlConstantes.COD_TIP_ACCION_NOCONFORME;
		
		PreseleccionAsignacion preseleccionAsignacion=new PreseleccionAsignacion();	
		preseleccionAsignacion.setNumAsignacionTemp(numAsigtTemp);
		preseleccionAsignacion.setNumProgramacion(preseleccionAsignacionBean.getNumProgramacion());
		preseleccionAsignacion.setCodTipoAccion(codTipoAccion);
		preseleccionAsignacion.setCodAuditor(preseleccionAsignacionBean.getCodAuditor());

		t10416PreseleAsigDAO.save(preseleccionAsignacion, AccionesControlConstantes.DATASOURCE_DCSICOBF);		
	}
	


}
