package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlUtil;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSPersonalIqbfBean;
import pe.gob.sunat.iqbf3.registro.maestros.service.DataCatalogoService;
import pe.gob.sunat.iqbf3.registro.maestros.service.ServicioWebService;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class DerivacionOrdenServiceImpl implements DerivacionOrdenService {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	@EJB
	private ServicioWebService servicioWebService;	
	@EJB
	private T10420ProgramacionDAO t10420ProgramacionDAO;
	@EJB
	private DataCatalogoService dataCatalogoService;
	@EJB
	T10415OrdenAccionDAO t10415OrdenAccionDAO;
	@EJB 
	T10411InformeSelecDAO t10411InformeSelecDAO;
	@EJB
	private ComunService comunService;
	@Override
	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro) {
		
		List<ProgramacionBean> listaPrograma=new ArrayList<ProgramacionBean>();

		Programacion parametros=new Programacion();
		parametros.setNumProgramacion(filtro.getNumProgramacion());
		parametros.setDesAlcance(filtro.getDesAlcance());
		parametros.setNumInforme(filtro.getNumInforme());
		parametros.setFechaDesde(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
		parametros.setFechaHasta(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
		parametros.setCodProgramador(filtro.getCodProgramador());
	
        List<Programacion> t10420Programacion= t10420ProgramacionDAO.listarProgramacion(parametros);
        if (!MaestrosUtilidades.isEmpty(t10420Programacion)) {
        	ProgramacionBean programacionBean=null;
	        for (Programacion programacion : t10420Programacion) {
	        	programacionBean = new ProgramacionBean();
	        	MaestrosUtilidades.copiarValoresBean(programacion, programacionBean);
	        	programacionBean.setDesProgramaControl(programacion.getDesProgctrl());
				programacionBean.setNumProgramacion(programacion.getNumProgramacion());
	        	programacionBean.setCodProgramador(programacion.getCodProgramador());
	        	programacionBean.setNumInforme(programacion.getNumInforme());
	        	programacionBean.setNroInformeUnion(programacion.getNroInformeUnion());
	        	programacionBean.setPerInicio(programacion.getPerInicio());
	        	programacionBean.setPerFin(programacion.getPerFin());
	        	programacionBean.setFecProgramacion(MaestrosUtilidades.dateToStringDDMMYYYY(programacion.getFecProgramacion()));	        		        	
	        	obtenerDatosCatalogo(programacionBean,programacion);
	        	listaPrograma.add(programacionBean);
			}
			if (!MaestrosUtilidades.isEmpty(filtro.getDesProgramador())) {
				listaPrograma = AccionesControlUtil.listByDesProgramador(listaPrograma, filtro);
			}
        }
		return listaPrograma;
	}
	private void obtenerDatosCatalogo(ProgramacionBean programacionBean,Programacion programacion){
		WSPersonalIqbfBean programador = servicioWebService.obtenerPersonalIqbf(programacion.getCodProgramador());
    	programacionBean.setNomProgramador("");
    	if (!MaestrosUtilidades.isEmpty(programador)) {
    		programacionBean.setNomProgramador(programador.getNomCompleto());
    		programacionBean.setDesProgramador(programador.getNomCompleto());
    	}
    	DataCatalogoBean catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_FUENTES_PROGRAMAS, programacion.getCodFuente());
    	programacionBean.setDesFuente("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesFuente(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_PROGRAMACION, programacion.getCodTipoProgram());
    	programacionBean.setDesTipoProgram("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesTipoProgram(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADOS_PROGRAMAS, programacion.getCodEstadoPrograma());
    	programacionBean.setDesEstadoProgram("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesEstadoProgram(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_SUBESTADOS_PROGRAMACION, programacion.getCodSubEstadoProgram());
    	programacionBean.setDesSubEstprogram("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesSubEstprogram(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_PROCESOS_PROGRAMACION, programacion.getCodProceso());
    	programacionBean.setDesProceso("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesProceso(catalogo.getDescripcionDataCatalogo().trim());
    	}
    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_INFORMESELECCION, programacion.getCodEstadoInforme());
    	programacionBean.setDesEstadoInforme("");
    	if (!MaestrosUtilidades.isEmpty(catalogo)) {
    		programacionBean.setDesEstadoInforme(catalogo.getDescripcionDataCatalogo().trim());
    	}    	
	}
	@Override
	public List<OrdenAccionBean> listarOrden(OrdenAccionBean filtro) {
		List<OrdenAccionBean> lista=new ArrayList<OrdenAccionBean>();
		
		OrdenAccion ordenAccionFiltro = new OrdenAccion();
		ordenAccionFiltro.setCodTipoOrden(filtro.getCodTipoOrden());
		//ordenAccionFiltro.setNumOrden(MaestrosUtilidades.toLong(filtro.getNumOrden()));
		ordenAccionFiltro.setNumOrdenUnion(filtro.getNumOrdenUnion());
//		ordenAccionFiltro.setFecAsigIni(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaDesde()));
//		ordenAccionFiltro.setFecAsigFin(MaestrosUtilidades.stringToDateDDMMYYYY(filtro.getFechaHasta()));
//		ordenAccionFiltro.setCodTipDocIdent(filtro.getCodTipoDocumentoIdent());
		ordenAccionFiltro.setNumDocIdent(filtro.getNumDocumentoUsuario());
		ordenAccionFiltro.setCodCargo(AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		ordenAccionFiltro.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		ordenAccionFiltro.setIndEst(MaestrosConstantes.REGISTRO_ACTIVO);
//		ordenAccionFiltro.setNumInforSelec(filtro.getNumInforSelec());
//		if (MaestrosUtilidades.isEmpty(filtro.getCodEstadoOrden())) {
//			ordenAccionFiltro.setEstados(Arrays.asList(AccionesControlConstantes.COD_ESTADO_PROG_GENERADA, AccionesControlConstantes.COD_ESTADO_PROG_ENPROCESO));
//		} else {
//			ordenAccionFiltro.setCodEstadoOrden(filtro.getCodEstadoOrden());
//		}
//		ordenAccionFiltro.setNumProgramacion(filtro.getNumProgramacion());
		
		List<OrdenAccion> t10415OrdenAccion=t10415OrdenAccionDAO.listarOrdenDerivacion(ordenAccionFiltro);
		if (!MaestrosUtilidades.isEmpty(t10415OrdenAccion)) {
			OrdenAccionBean ordenAccionBean=null;
			for (OrdenAccion ordenAccion : t10415OrdenAccion) {
				ordenAccionBean=new OrdenAccionBean();
				MaestrosUtilidades.copiarValoresBean(ordenAccion, ordenAccionBean);
				ordenAccionBean.setFecAsigOrden(MaestrosUtilidades.dateToStringDDMMYYYY(ordenAccion.getFecAsigOrden()));
				ordenAccionBean.setCodTipoOrden(ordenAccion.getCodTipoOrden());
				ordenAccionBean.setNumDocIdent(ordenAccion.getNumDocIdent());
	          	obtenerDatosCatalagoOrden(ordenAccion,ordenAccionBean);
	          	 if (!existeOrdenDuplicada(ordenAccion.getNumOrdenUnion(), lista)) {
	          	//TODO: mejorar query
	 	        	lista.add(ordenAccionBean);
	 			}	
			}
			if(!MaestrosUtilidades.isEmpty(filtro.getNomApeUsuario())){
				lista = listByNomAuditor(lista, filtro);
			}
		}
		
		return lista;
	}
	private List<OrdenAccionBean> listByNomAuditor(List<OrdenAccionBean> lista,OrdenAccionBean filtro){
		List<OrdenAccionBean> lista2= new ArrayList<OrdenAccionBean>();
		for (OrdenAccionBean bean : lista) {
			if(bean.getNomApelAuditor()!=null && bean.getNomApelAuditor().toLowerCase().contains(filtro.getNomApeUsuario().toLowerCase())){
				lista2.add(bean);
			}
		}
		return lista2;
	}
	private boolean existeOrdenDuplicada(String numOrden, List<OrdenAccionBean> listaDuplicada) {

		boolean indicadorExiste = false;

		for (OrdenAccionBean item : listaDuplicada) {
			if (item.getNumOrdenUnion().equals(numOrden)) {
				indicadorExiste = true;
				break;
			}

		}
		return indicadorExiste;

	}
	@Override
	public List<OrdenAccionBean> obtenerDatosOrden(Long numProgramacion){		
		List<OrdenAccionBean> lista=null;
		OrdenAccionBean filtro = new OrdenAccionBean();
		filtro.setNumProgramacion(numProgramacion);
		lista =listarOrden(filtro);
		return lista;
	}
	
	private void obtenerDatosCatalagoOrden(OrdenAccion ordenAccion, OrdenAccionBean ordenAccionBean) {
		DataCatalogoBean catalogo = null;

		WSPersonalIqbfBean auditor = servicioWebService.obtenerPersonalIqbf(ordenAccion.getCodPers());
		if (!MaestrosUtilidades.isEmpty(auditor)) {
			ordenAccionBean.setNomApelAuditor(auditor.getNomCompleto());
		}
		
    	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPO_ORDENES,ordenAccion.getCodTipoOrden());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			ordenAccionBean.setDesTipOrden(catalogo.getDescripcionDataCatalogo());
		}	

    	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_ESTADO_ORDEN,ordenAccion.getCodEstadoOrden());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			ordenAccionBean.setDesEstadoOrden(catalogo.getDescripcionDataCatalogo());
		}

    	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_TIPDOCIDENTIF,ordenAccion.getCodTipoDocumentoIdentif());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			ordenAccionBean.setDesTipoDocumentoIdent(catalogo.getDescripcionDataCatalogo());
		}

    	catalogo = dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL, ordenAccion.getCodTipAccion());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			ordenAccionBean.setDesTipAccion(catalogo.getDescripcionDataCatalogo());
		}

    	catalogo=dataCatalogoService.obtenerCatalogo(AccionesControlConstantes.COD_CATALOGO_RESULTADO_ORDEN, ordenAccion.getCodResulOrden());
		if (!MaestrosUtilidades.isEmpty(catalogo)) {
			ordenAccionBean.setDesResulOrden(catalogo.getDescripcionDataCatalogo());
		}		
	}
	@Override
	public OrdenAccionBean derivarOrdenes(OrdenAccionBean filtro) {
		OrdenAccionBean ordenAccionBean = null;
		PropertyParams propertyParams = new PropertyParams();
		String codEstadoOrden = AccionesControlConstantes.COD_ESTADO_ORDEN_ENPROCESO;
		for (OrdenAccionBean element : filtro.getListOrden()) {
			ordenAccionBean = new OrdenAccionBean();
			ordenAccionBean.setCodEstadoOrden(codEstadoOrden);
			ordenAccionBean.setFecAsigOrden(element.getFecAsigOrden());
			ordenAccionBean.setNumOrden(element.getNumOrden());
			OrdenAccion ordenAccion = t10415OrdenAccionDAO.findById(element.getNumOrden(), AccionesControlConstantes.DATASOURCE_DCSICOBF);
			ordenAccion.setCodEstadoOrden(codEstadoOrden);
			ordenAccion.setFecAsigOrden(MaestrosUtilidades.stringToDateDDMMYYYY(element.getFecAsigOrden()));
			//MaestrosUtilidades.copiarValoresBean(ordenAccionBean, ordenAccion);			
			t10415OrdenAccionDAO.update(ordenAccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			propertyParams.addProperty("codEstadoOrden",AccionesControlConstantes.COD_ESTADO_ORDEN_ENPROCESO);
			propertyParams.addProperty("numOrden",element.getNumOrden());
			Long countOrdenAccion =t10415OrdenAccionDAO.countByProperties(propertyParams, AccionesControlConstantes.DATASOURCE_DGSICOBF);
			if(!("").equals(element.getNumInforSelec()) && element.getNumInforSelec()!=null){
				InformeSeleccion informeSeleccion =t10411InformeSelecDAO.findById(Long.valueOf(element.getNumInforSelec()), AccionesControlConstantes.DATASOURCE_DCSICOBF);
				String codEstadoInforme =AccionesControlConstantes.COD_ESTADO_INFORME_DERIVACIONCOMPL;
				informeSeleccion.setNumInformeSeleccion(Long.valueOf(element.getNumInforSelec()));
				informeSeleccion.setCodEstadoInforme(codEstadoInforme);
				if(countOrdenAccion.equals(0)){
					t10411InformeSelecDAO.update(informeSeleccion, AccionesControlConstantes.DATASOURCE_DGSICOBF);
				}
				
			}
			
		}
		
		return ordenAccionBean;
	}
	@Override
	public ArchivoBean obtenerArchivo(Long numArc) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio DerivacionOrdenServiceImpl - obtenerArchivo");
		 ArchivoBean archivoBean = comunService.obtenerArchivo(Long.valueOf(numArc));
		return archivoBean;
	}
}
