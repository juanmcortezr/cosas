package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.io.File;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperPrint;

public interface ArchivoDigitalizadosService {

	public File obtenerFirmaConNombrePorPersona(String codRegPersona);
	public JasperPrint generarBytePlantillaJasper(Map<String, Object> parameters, String rutaJasper ,JRDataSource dataSource);
	public byte[] convertirJasperPrintByte(List<JasperPrint> lstJasperPrints);
}
