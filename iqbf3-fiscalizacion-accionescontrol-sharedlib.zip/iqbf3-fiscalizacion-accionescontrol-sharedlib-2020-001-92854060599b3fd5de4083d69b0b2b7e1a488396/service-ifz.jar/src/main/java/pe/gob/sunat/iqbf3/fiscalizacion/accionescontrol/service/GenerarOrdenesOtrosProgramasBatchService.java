package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface GenerarOrdenesOtrosProgramasBatchService {

	public ResponseBean<String> generarOrdenesOtrosProgramas(Long numInformeSeleccion);
	
	public int ingresarOrdenOtroPrograma(OrdenAccionBean ordnAcc);
}
