package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AgentePuestosCtrlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaUsuarioAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.GrupoProcesoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface AsignaReasignaAuditorService {
	
	
	List<AsignaUsuarioAccionBean> listaCargaAuditoresPrincipales(String numProgramacion);
	
	public List<DistribucionGrupoBean> listarAuditorApoyoAsignado(Long numUsuarioProgram);

	public AsignaUsuarioAccionBean guardarAuditorApoyo(AsignaUsuarioAccionBean formulario);

	public AsignaUsuarioAccionBean guardarAuditorPrincipal(AsignaUsuarioAccionBean formulario);

	public List<UsuarioProgramacionBean> listarUsuarioProgramacion(UsuarioProgramacionBean filtro);
	
	//CUS 13
	List<AsignaUsuarioAccionBean> listarAuditorPrincipal(String numGrupo);	
	public List<AsignaUsuarioAccionBean> listarAuditoresAgentes (AsignaUsuarioAccionBean filtro);

	public List<GrupoProcesoBean> listarSupervisionAuditor();

	//List<AgentePuestosCtrlBean> listarAgentePuesto(String codPuesto);

	public List<AgentePuestosCtrlBean> listarAgentePuesto(String codPuesto, String codRol);

	public List<AsignaUsuarioAccionBean> obtenerAsigUsuarioAccion(AsignaUsuarioAccionBean filtro);
	
	public boolean eliminarAuditorApoyo (AsignaUsuarioAccionBean filtro);
	
	public List<DistribucionGrupoBean> listarAuditorApoyo (DistribucionGrupoBean bean);
		
}
