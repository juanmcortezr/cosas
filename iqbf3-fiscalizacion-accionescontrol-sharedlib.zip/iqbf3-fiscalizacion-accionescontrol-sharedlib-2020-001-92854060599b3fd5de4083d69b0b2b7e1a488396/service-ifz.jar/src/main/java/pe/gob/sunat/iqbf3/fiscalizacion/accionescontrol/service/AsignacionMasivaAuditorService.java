package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.GrupoProcesoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PreseleccionAsignacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;

public interface AsignacionMasivaAuditorService {

	public List<OrdenAccionBean> obtenerResumenOrdPend (ProgramacionBean programaControlBean);
	
	public List<PreseleccionAsignacionBean> listarAuditoresPreSeleccionados (PreseleccionAsignacionBean preseleccionAsignacionBean);
	//public List<PreseleccionAsignacionBean> obtenerAuditorAsignar (PreseleccionAsignacionBean preseleccionAsignacionBean);
	
	public void eliminarAuditorPreseleccionado(PreseleccionAsignacionBean preseleccionAsignacionBean);
	//public void eliminarAuditor(PreseleccionAsignacionBean preseleccionAsignacionBean);
	
	public List<GrupoProcesoBean> listarSupervisionAuditor (GrupoProcesoBean filtro);
	
	public List<DistribucionGrupoBean> listarAuditoresVigentes (DistribucionGrupoBean filtro);
	//public List<DistribucionGrupoBean> listarAuditor(DistribucionGrupoBean filtro);
	
	public void guardarAuditorPreselec (PreseleccionAsignacionBean preseleccionAsignacionBean);
	
	public void guardarAsignacion(ProgramacionBean filtro);
}
