package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import pe.gob.sunat.iqbf3.registro.maestros.model.Entidad;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public abstract class AbstractDAOImpl<T extends Entidad, ID> extends pe.gob.sunat.iqbf3.registro.maestros.utils.AbstractDAOImpl<T, ID> implements GenericInterface<T, ID> {

	public AbstractDAOImpl(Class<T> entityClass) {
		super(entityClass);
	}

	// INI Entity Manager
	@PersistenceContext(unitName = "dcsicobfAC")
	private EntityManager dcsicobfAC;
	@PersistenceContext(unitName = "dgsicobfAC")
	private EntityManager dgsicobfAC;
	@PersistenceContext(unitName = "dcspAC")
	private EntityManager dcspAC;
	
	public EntityManager getdcsicobfAC()   { return this.dcsicobfAC; }
	public EntityManager getdgsicobfAC()   { return this.dgsicobfAC; }
	public EntityManager getdcspAC()   	   { return this.dcspAC; }
	// FIN Entity Manager

}
