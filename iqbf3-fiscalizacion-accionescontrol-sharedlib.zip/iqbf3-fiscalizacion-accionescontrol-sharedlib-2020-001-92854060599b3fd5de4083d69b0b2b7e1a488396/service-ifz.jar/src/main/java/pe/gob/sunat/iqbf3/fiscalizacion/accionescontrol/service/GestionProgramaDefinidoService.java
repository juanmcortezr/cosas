package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;


public interface GestionProgramaDefinidoService {

	public List<ProgramacionBean> listarProgramaDefinido(ProgramacionBean filtro);
	public ProgramaControlBean obtenerProgramaControl(String codProgramaControl);
	public ResponseBean<ProgramacionBean> guardarProgramacionDefinido(ProgramacionBean formulario);
	public ProgramacionBean obtenerDatosProgramacionDefinido(Long numProgramacion);
	public List<UsuarioProgramacionBean> listarUsuariosDefinidos(UsuarioProgramacionBean filtro);
	public List<DataCatalogoBean> listarMotivoActualizar();
	public ResponseBean<ProgramacionBean> actualizarProgramacionDefinido(ProgramacionBean formulario);
	public ResponseBean<ProgramacionBean> actualizarUsuario(List<UsuarioProgramacionBean> filtro);
	public ResponseBean<ProgramacionBean> enviarPrograma(ProgramacionBean formulario);
}
