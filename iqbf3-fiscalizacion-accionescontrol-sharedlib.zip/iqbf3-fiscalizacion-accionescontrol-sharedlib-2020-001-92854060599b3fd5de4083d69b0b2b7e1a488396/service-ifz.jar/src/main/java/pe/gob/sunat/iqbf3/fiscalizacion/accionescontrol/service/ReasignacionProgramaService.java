package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.HistorialEstadosProgramaBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.HistorialEstadosPrograma;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface ReasignacionProgramaService {

	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro);
	
	public List<AsignaProgramacionBean> listarAsignadoProgramacion(String numProgramacion);
		
	public ResponseBean<ProgramacionBean> guardarAsignacionProgramacion(ProgramacionBean formulario);
	
	List<AsignaProgramacionBean> listarHistorialAsignaciones(Long numProgramacion, String indTipAsignacion);

	List<DistribucionGrupoBean> listarProgramador(String indTipAsignacion);
		
}
