package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;

public interface CompletarInformeService {
	
	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro);
	
	public ProgramacionBean obtenerDatosProgramacion(Long numProgramacion);
	
	public UsuarioProgramacionBean obtenerDatosAccion(Long numUsuarioProgram);
	
	public List<DocumentoAccionBean> obtenerDatosDocAccion(Long numDocAccion);
	
	public List<DocumentoAccionBean> listarDocumentoAccion(Long numUsuarioProgramacion);
	
	public InformeSeleccionBean guardarInformeSeleccion(InformeSeleccionBean informeSeleccionBean);
	
	public UsuarioProgramacion guardarDocumentoInforme(UsuarioProgramacionBean usuarioProgramacionBean);
	
	public DocumentoAccionBean guardarDocumentoAccion(DocumentoAccionBean documentoAccionBean);
	
	public List<UsuarioProgramacionBean> listarUsuarioProgramacion(UsuarioProgramacionBean filtro);
	
	public DocumentoAccionBean eliminarDocumentoAccion(Long numDocAccion);

}
