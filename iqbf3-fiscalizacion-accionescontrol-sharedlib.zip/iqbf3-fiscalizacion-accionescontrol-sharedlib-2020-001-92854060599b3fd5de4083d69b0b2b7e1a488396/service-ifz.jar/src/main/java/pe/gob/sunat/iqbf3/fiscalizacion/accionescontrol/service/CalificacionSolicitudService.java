package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CalificacionUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface CalificacionSolicitudService {

	public List<SolicitudProgramacionBean> listarSolicitudesporCalificar(SolicitudProgramacionBean filtro);

	public List<UsuarioSolicitudBean> listarUsuarioSolicitud(Long numSolic);

	public List<CalificacionUsuarioBean> listarCalificacionUsuario(Long numUsuSolic);

	public ResponseBean<CalificacionUsuarioBean> guardarCalificacionDefinitiva(CalificacionUsuarioBean formulario);

	public ResponseBean<SolicitudProgramacionBean> enviarCalificacion(SolicitudProgramacionBean formulario);

}
