package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;

public interface AsignacionSolicitudService {

	public List<SolicitudProgramacionBean> listarSolicitudesporAsignar(SolicitudProgramacionBean filtro);

	public List<AsignaProgramacionBean> listarHistoriaAsignaciones(Long numSolic);

	public AsignaProgramacionBean guardarAsignacionSolicitud(AsignaProgramacionBean formulario);

}
