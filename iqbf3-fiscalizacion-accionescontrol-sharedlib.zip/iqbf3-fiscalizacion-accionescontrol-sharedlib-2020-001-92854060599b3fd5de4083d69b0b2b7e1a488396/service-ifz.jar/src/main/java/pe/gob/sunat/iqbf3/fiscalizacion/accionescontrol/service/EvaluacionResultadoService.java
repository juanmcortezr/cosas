package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;

public interface EvaluacionResultadoService {
	public int actualizarOrden(OrdenAccionBean ordenAccionBean);
}
