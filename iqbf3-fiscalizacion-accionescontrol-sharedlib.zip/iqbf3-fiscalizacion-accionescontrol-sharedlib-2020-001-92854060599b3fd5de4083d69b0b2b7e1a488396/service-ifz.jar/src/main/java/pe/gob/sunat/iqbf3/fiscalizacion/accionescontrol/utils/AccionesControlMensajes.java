package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils;

public class AccionesControlMensajes {

	// Utilizar String.format(texto, parametros...);
	public static final String CUS06_REGISTRO_EXITO = "Se ha creado con \u00c9xito la programaci\u00f3n Nro. %s";
	public static final String CUS13_REGISTRO_EXITO = "Se ha creado con \u00c9xito la programaci\u00f3n Nro. %s";

}
