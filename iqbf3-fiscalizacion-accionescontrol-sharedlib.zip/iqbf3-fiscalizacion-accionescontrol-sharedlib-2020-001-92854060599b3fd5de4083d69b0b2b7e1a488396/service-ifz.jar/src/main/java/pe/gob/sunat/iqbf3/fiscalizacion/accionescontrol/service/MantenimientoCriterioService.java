package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AccionSugeridaCalifBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AlternativaCriterioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CriterioCalificacionBean;

public interface MantenimientoCriterioService {
	
	public List<CriterioCalificacionBean> listarCriterioCalificacion(Integer numCriterio);

	public CriterioCalificacionBean guardarCriterio(CriterioCalificacionBean filtro);
	
	public CriterioCalificacionBean actualizarCriterio(CriterioCalificacionBean criterioCalificacionBean);
	
	public CriterioCalificacionBean eliminarCriterio(CriterioCalificacionBean criterioCalificacionBean);
	
	public List<AlternativaCriterioBean> listarAlternativaCriterio(Long numCriterio, String indEst, String indDel);
	
	public List<AlternativaCriterioBean> guardarAlternativa(AlternativaCriterioBean alternativaCriterioBean);
	
	public AlternativaCriterioBean actualizarAlternativa(AlternativaCriterioBean alternativaCriterioBean);
	
	public AlternativaCriterioBean eliminarAlternativa (AlternativaCriterioBean alternativaCriterioBean);
	
	public  List<AccionSugeridaCalifBean> listarAccionesSugeridas(String indEstado);
	
	public AccionSugeridaCalifBean guardarAccionSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean);

	public AccionSugeridaCalifBean actualizarAccSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean);
	
	public AccionSugeridaCalifBean eliminarAccSugerida(AccionSugeridaCalifBean accionSugeridaCalifBean);

	public List<CriterioCalificacionBean> listarCriterioCalificacion();

}
