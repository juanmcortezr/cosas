package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;

public interface EvaluacionProgramaService {
	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro);
	public List<ProgramaControlBean> obtenerTipoProgramaControl(Integer numProgramacion);
	public List<DataCatalogoBean> obtenerEstadosProgramacion();
	public List<DataCatalogoBean> obtenerEstadosInformeSeleccion();
	public List<UsuarioProgramacionBean> listarUsuarioProgramacion(UsuarioProgramacionBean filtro);
	public ArchivoBean obtenerArchivo(Long numArc);
	public Programacion guardarProgramacion(ProgramacionBean filtro);
	public UsuarioProgramacionBean obtenerDocumentoVinculado(UsuarioProgramacionBean formulario);
	public MovimientoProgramacion obtenerEvaluarPrograma(ProgramacionBean filtro);

}

	