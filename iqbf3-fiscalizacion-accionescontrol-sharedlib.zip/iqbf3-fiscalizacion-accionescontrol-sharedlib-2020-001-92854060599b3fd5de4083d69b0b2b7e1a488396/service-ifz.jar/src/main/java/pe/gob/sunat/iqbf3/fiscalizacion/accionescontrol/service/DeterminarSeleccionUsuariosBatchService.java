package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface DeterminarSeleccionUsuariosBatchService {

	public ResponseBean<String> iniciarProcesamiento(Long numProgramacion);
}
