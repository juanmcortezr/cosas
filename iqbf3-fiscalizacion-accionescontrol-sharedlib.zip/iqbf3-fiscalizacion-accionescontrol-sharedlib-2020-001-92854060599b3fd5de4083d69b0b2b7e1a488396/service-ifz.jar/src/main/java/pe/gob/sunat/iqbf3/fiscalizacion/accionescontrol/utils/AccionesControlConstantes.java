package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils;

public class AccionesControlConstantes {
	
	//Estado indicador
	public static final String COD_ESTADO_INDICADOR_ACTIVO = "1";
	public static final String COD_ESTADO_INDICADOR_INACTIVO = "0";
	
	public static final String COD_DESCRIP_INDICADOR_ACTIVO ="Si";
	public static final String COD_DESCRIP_INDICADOR_INACTIVO ="No";
	
	public static final String COD_ESTADO_PROG_GENERADA="12";
	public static final String COD_ESTADO_PROG_ENPROCESO="00"; //por definir 
	
	public static final String COD_ESTADOS_INFORME_SELECCION="";//por definir
	
	public static final String REGISTRO_ACTIVO="1";
	public static final String REGISTRO_INACTIVO="0"; 
	
	public static final String COD_ESTADO_PROG_ASIGNADO ="02";
	
	public static final String COD_TIPO_ARCHIVO_INFORME ="06";
	
	public static final String REGISTRO_NOELIMINADO ="0";
	public static final String REGISTRO_ELIMINADO="1";
	
	public static final String COD_CARGO_AUDITOR_PRINCIPAL = "01";
	public static final String COD_CARGO_AUDITOR_APOYO ="04";
	public static final String COD_CARGO_GERENTE ="06";
	public static final String COD_CARGO_SUPERVISOR= "03";
	public static final String COD_CARGO_SUPERVISOR_PROG= "08";	
	
	public static final String COD_PUESTO_CONTROL_ROL_SUPERVISOR = "1";
	public static final String COD_PUESTO_CONTROL_ROL_GERENCIA = "2";
	public static final String COD_PUESTO_CONTROL_ROL_AGENTE_DE_CONTROL = "3";	
	
	public static final String COD_CATALOOGO_DOCUMENTO_ADICIONALACCION ="BCW";
	public static final String COD_CATALOGO_NIVEL_DERIESGO  = "BCO";
	public static final String COD_ESTADO_DOCUMENTO ="";//por definir
	
	public static final String COD_CLASE_DOCUMENTO_ACCION ="02";
	public static final String COD_ORIGEN_MANUAL="0";//por definir
	public static final String COD_ESTADO_DOCUMENTOACCION="0";//por definir
	
	public static final String COD_TIPO_ACCIONCONTROL="0";//por definir
	
	public static final String COD_CATALOGO_TIPO_ACCIONCONTROL = "BCA";
	
	public static final String COD_TIPO_ORDENES="";//por definir
	public static final String COD_ESTADO_ORDEN="";//por definir
	
	public static final String COD_TIPO_ARCHIVO_INFORME_CANCELA_ORDEN="13";//por definir
	
	public static final String COD_TIP_PROG_OTROS ="999";
	
	public static final String COD_INCON_NO_SUBSANO ="02";
	public static final String COD_INCON_SUBSANO = "01";
	public static final String COD_INCON_SUBSANADO_PARCIAL="03";
	
	public static final String COD_RESULTADO_ORDEN_NO_CONFORME="02";
	
	public static final String COD_TIP_ACCION_NOCONFORME="00";   
	
	public static final String COD_PROGRAMA_EN_PROCESO_ASIG="1";
	
	public static final String COD_ESTADO_PROG_PROGRAMADO="05";
	
	public static final String COD_CATALOGO_TIPO_INCONSISTENCIAS ="BCD";
	
	public static final String COD_IND_DEPURACION_MANUAL="1";
	
	public static final String COD_ESTADO_INFORME_GENERADO="01";
	
	//public static final String COD_ESTADO_INFORME_CONCLUIDO="";
	
	public static final String COD_ESTADO_INFORME_PENDIENTE="02";
	public static final String COD_ESTADO_INFORME_APROBADO ="03";
	public static final String COD_ESTADO_INFORME_DEVUELTOSUP ="04";
	public static final String COD_ESTADO_INFORME_AUTORIZADO ="05";
	public static final String COD_ESTADO_INFORME_DEVUELTOGER="06";
	public static final String COD_ESTADO_INFORME_PENDIENTEASIG ="07";
	public static final String COD_ESTADO_INFORME_ASIGNANDOAUDIT ="08";
	public static final String COD_ESTADO_INFORME_ERRORASIGNA ="09";
	public static final String COD_ESTADO_INFORME_PENDIENTECOMPL ="10";
	public static final String COD_ESTADO_INFORME_CONCLUIDO="11";
	public static final String COD_ESTADO_INFORME_DERIVACIONCOMPL="12";
	
	public static final String COD_CLASE_DOCUMENTO_VINCULADO ="01";

	// Catalogos Solicitud de programacion
	public static final String COD_CATALOGO_CATALOGO_TIPO_ACCIONCONTROL = "BCA";
	public static final String COD_CATALOGO_CATALOGO_ORIGEN_INCONSISTENCIA="BCB";
	public static final String COD_CATALOGO_CATALOGO_TIPO_INTERVENCION = "BCC";
	public static final String COD_CATALOGO_CATALOGO_TIPO_INCONSISTENCIAS = "BCD";
	public static final String COD_CATALOGO_RECOMENDACIONESRESULTADO = "BCF";
	public static final String COD_CATALOGO_TIPO_DOCUMENTO_REFERENCIAAC="BCG";
	public static final String COD_CATALOGO_RESULTADOACCION = "BCH";
	public static final String COD_CATALOGO_SUSTENTO_SUSPENSION_REGISTRO_RCBF = "BCJ";
	public static final String COD_CATALOGO_ESTADO_SOLICITUD = "BCK";
	public static final String COD_CATALOGO_TIPDOCIDENTIF = "BCI";
	public static final String COD_CATALOGO_TIPODOC_TRANSACCION = "B83";
	public static final String COD_CATALOGO_TIPO_BIEN = "B76";

	// Catalogos programas de control
	public static final String COD_CATALOGO_FUENTES_PROGRAMAS = "BCL";
	public static final String COD_CATALOGO_MOTIVOS_DEPURACION = "BCM";
	public static final String COD_CATALOGO_ESTADOS_PROGRAMAS = "BCN";
	public static final String COD_CATALOGO_SUBESTADOS_PROGRAMACION = "BCP";
	public static final String COD_CATALOGO_PROCESOS_PROGRAMACION = "BCQ";
	public static final String COD_CATALOGO_ESTADO_INFORMESELECCION = "BCR";
	public static final String COD_CATALOGO_TIPO_ORDENES = "BCS";
	public static final String COD_CATALOGO_ESTADO_ORDEN = "BCT";
	public static final String COD_CATALOGO_TIEMPO_ESTIMADO_ACCION="BCU";
	public static final String COD_CATALOGO_CLASE_DOCUMENTO = "BCV";
	public static final String COD_CATALOGO_DOCUMENTO_ADICIONALACCION = "BCW";
	public static final String COD_CATALOGO_RESULTADO_ORDEN = "BCX";
	public static final String COD_CATALOGO_RESULTADO_INCONSISTENCIA = "BCY";
	public static final String COD_CATALOGO_TIPO_DOCUMENTOTRABAJO = "BCZ";
	public static final String COD_CATALOGO_ORIGEN_ESTAB_HALLAZGOS="BDC";
	public static final String COD_CATALOGO_TIPOSACTA="BDD";
	public static final String COD_CATALOGO_DOCUMENTOS_TIPOACTA = "BDE";
	public static final String COD_CATALOGO_TIPO_INFORME = "BDF";
	public static final String COD_CATALOGO_TIPO_PROGRAMACION = "BDG";
	public static final String COD_CATALOGO_TIPO_ARCHIVO = "BDH";
	public static final String COD_CATALOGO_ESTADO_USUARIOACCION = "BDI";
	public static final String COD_CATALOGO_DOCUMENTO_VINCULADO = "BDK";
	
	// ENVIO DE CORREO NOTIFICACION PREVIA
	public static final String  COD_CATALOGO_CORREO_AUTORIZACION = "BEH";
	public static final String  COD_CATALOGO_CORREO_AUTORIZACION_RECEPTOR = "03";

	// CONSTANTES PARA LAS SECUENCIAS DE LAS TABLAS
    public static final String SECUENCIA_ACTA_RESULTADOBIENES = "seactbienorden";
    public static final String SECUENCIA_ACTA_ESTABLECIMIENTO = "seactaestab";
    public static final String SECUENCIA_ACTA_RESULESTABLEC = "seactividestab";
    public static final String SECUENCIA_ACTIVIDADES_RESULORDEN = "seactividorden";
    public static final String SECUENCIA_ACTIVIDADES_PROGRAMADAS = "seactividprog";
    public static final String SECUENCIA_ALTERNATIVAS_CRITERIOS = "sealternatcrit";
    public static final String SECUENCIA_INFORME_SELECCION = "searcinforme";
    public static final String SECUENCIA_ARCHIVOS_PROGRAMACION = "searcprogram";
    public static final String SECUENCIA_ARCHIVOS_ACCIONES = "searcacf";
    public static final String SECUENCIA_ARCHIVOS_DATA_ACCIONES = "searcdataacf";
    public static final String SECUENCIA_ASIGNACION_PROGRAMAS = "seasignprogram";
    public static final String SECUENCIA_ASIGNACION_USUARIOS = "seasignausuacc";
    public static final String SECUENCIA_BIEN_ESTABLECIMIENTO = "sebienestab";
    public static final String SECUENCIA_BIENES_FISCALIZARSOL = "sebienfiscasoli";
    public static final String SECUENCIA_BIENES_FISCALIZARUSUARIO = "sebienfiscausu";
    public static final String SECUENCIA_BIENES_PROGRAMACION = "sebienprog";
    public static final String SECUENCIA_PERIODOS_ABLOQUEAR = "sebloqdjro";
    public static final String SECUENCIA_CALIFICACION_USUARIO = "secaliusua";
    public static final String SECUENCIA_CONTACTO_ORDEN = "secontactorden";
    public static final String SECUENCIA_CRITERIOS_CALIFICACION = "secriteriocali";
    public static final String SECUENCIA_DETALLE_CALIFICACION = "sedetacaliusua";
    public static final String SECUENCIA_RESULTADO_ORDEN = "sedetaresorden";
    public static final String SECUENCIA_DOCOPERACION_ORDEN = "sedocoperorden";
    public static final String SECUENCIA_DOCUMENTOS_ACCION = "sedocumeaccion";
    public static final String SECUENCIA_DOCRESULTADO_ORDEN = "sedocumenorden";
    public static final String SECUENCIA_ESTABLHALLAZGO_ORDEN = "seestaborden";
    public static final String SECUENCIA_ESTABLECIMIENTO_USARIO = "seestabusu";
    public static final String SECUENCIA_HISTORIAL_ESTADOPROG = "sehistestaprog";
    public static final String SECUENCIA_INFORMES_SELECCION = "seinformeselec";
    public static final String SECUENCIA_MEDIO_PROBATORIO = "semedioprobusu";
    public static final String SECUENCIA_MOVIMIENTO_PROGRAMA = "semovprogram";
    public static final String SECUENCIA_MOVIMIENTO_SOLICITUD = "semovsolic";
    public static final String SECUENCIA_ORDENES_ACCION = "seordenaccion";
    public static final String SECUENCIA_PRESELECCION_ASIGNACION = "sepreselecasig";
    public static final String SECUENCIA_PROGRAM_INCONSISGRE = "seproincogrenc";
    public static final String SECUENCIA_PROGRAM_INCONSISSALDO="seproincosaldo";
    public static final String SECUENCIA_PROGRAM_INCONSISTOCK="seproincostock ";
    public static final String SECUENCIA_PROGRAM_PROGRAMAS="seprogramacionacc";
    public static final String SECUENCIA_SOLICITUD_PROGRAMACION="sesolicprog";
    public static final String SECUENCIA_SUSTENTO_SUSPENSIONORDEN="sesuspensorden";
    public static final String SECUENCIA_TIEMPO_ATENCIONAUDITOR="setareoauditor";
    public static final String SECUENCIA_TIPINCONS_ORDEN="setipincoorden";
    public static final String SECUENCIA_TIPINCONS_PROGRAMA="setipinconprog";
    public static final String SECUENCIA_TIPINCONS_SOLICITUD="setipinconsoli";
    public static final String SECUENCIA_TIPINCONS_USUARIO="setipinconusu";
    public static final String SECUENCIA_USUARIO_FISCALIZABLE="seusuarioprog";
    public static final String SECUENCIA_USUARIO_SOLICITUD="seusuariosolic";
    public static final String SECUENCIA_ASIGNACION_SOLICITUD="seasignasolic";
    public static final String SECUENCIA_ACCION_SUGERIDA="seaccionsug";
    public static final String SECUENCIA_ARCHIVO_INFORME="searcinforme";


	// CONSTANTES PARA LA SOLICITUD Y PROGRAMACION
	public static final String COD_ESTADO_SOLICITUD_REGISTRADO = "01";
	public static final String COD_ESTADO_SOLICITUD_ELABORADO = "02";
	public static final String COD_ESTADO_SOLICITUD_DEVUELTO = "03";
	public static final String COD_ESTADO_SOLICITUD_AUTORIZADO = "04";
	public static final String COD_ESTADO_SOLICITUD_ASIGNADO = "05";
	public static final String COD_ESTADO_SOLICITUD_CALIFICADO = "06";
	public static final String COD_ESTADO_SOLICITUD_APROBADO = "07";
	public static final String COD_ESTADO_SOLICITUD_ARCHIVADO = "08";
	public static final String COD_ESTADO_SOLICITUD_ANULADO = "09";
	public static final String COD_TIPO_ARCHIVO_SOLICITUD = "01";
	public static final String COD_TIPO_ARCHIVO_USUARIO = "02";
	public static final String COD_TIPO_ARCHIVO_MEDIOPROBATORIO = "03";
	public static final String COD_TIP_CALI_PRELIMINAR = "0";
	public static final String COD_TIP_CALI_DEFINITIVA = "1";
	
	/** TIPO DE INTERVENCION */
	public static final String COD_TIP_INTERVENCION_CONTROL = "01";
	public static final String COD_TIP_INTERVENCION_FISCALIZACION = "02";
	
	public static final String COD_TIP_INDICADOR_CONTROL_OC = "OC";
	public static final String COD_TIP_INDICADOR_FISCALIZACION_OF = "OF";
	
	
	public static final String COD_IND_OTRO_ESTABLECIMIENTO = "1";
	public static final String COD_CARGO_PROGRAMADOR = "05";
	public static final String COD_CARGO_PROGRAMADOR_ADMIN = "09";
	public static final String COD_TIPO_PROCESO = "02";
	public static final String ANEXO_TELEFONICO = "51881";
	public static final String COD_TIPO_PROCESO_TRAZABILIDAD = "02";

	public static final String COD_EST_PROGRAM_PLANIFICADO = "01";
	public static final String COD_EST_PROGRAM_ASIGNADO = "02";
	public static final String COD_EST_PROGRAM_EN_PROCESO_CARGA = "03";
	public static final String COD_EST_PROGRAM_EJECUTADO = "04";
	public static final String COD_EST_PROGRAM_PROGRAMADO = "05";
	public static final String COD_EST_PROGRAM_APROBADO = "06";
	public static final String COD_EST_PROGRAM_AUTORIZADO = "07";
	public static final String COD_EST_PROGRAM_CONCLUIDO = "08";
	public static final String COD_EST_PROGRAM_GENERADO_OC_OF = "09";
	public static final String COD_EST_PROGRAM_CERRADA = "10";
	public static final String COD_EST_PROGRAM_CANCELADA = "11";
	public static final String COD_EST_PROGRAM_GENERADA = "12";
	public static final String COD_EST_PROGRAM_EN_PROCESO_SELECCION = "13";
	public static final String COD_EST_PROGRAM_SIN_USUR_SELECCIONADOS = "14";
	public static final String COD_EST_PROGRAM_SELECCION_PROCESADA = "15";
	public static final String COD_EST_PROGRAM_DEVUELTO_SUPERVISOR = "16";
	public static final String COD_EST_PROGRAM_DEVUELTO_GERENCIA = "17";
	public static final String COD_EST_PROGRAM_ERROR_CARGA = "18";
	public static final String COD_EST_PROGRAM_NOTIFICADA = "19";
	public static final String COD_EST_PROGRAM_ERRORSELECCION = "20";
	public static final String COD_ESTADO_PROG_ERRORSELECCION = "20";
	
	/** TIPO DE ACCION SUGERIDA t10428usuarioprog.cod_tip_accion*/
	public static final String COD_TIP_ACCION_CARTA = "01";
	public static final String COD_TIP_ACCION_ESQUELA = "02";
	public static final String COD_TIP_ACCION_VISITA_PROGRAMADA = "03";
	public static final String COD_TIP_ACCION_VISITA_NO_PROGRAMADA = "04";
		
	/** TIPO ESTADO INFORME : t10411informeselec.cod_est_informe*/
	public static final String COD_EST_INFOR_SELEC_GENERADO = "01";
	public static final String COD_EST_INFOR_SELEC_PENDIENTE = "02";
	public static final String COD_EST_INFOR_SELEC_APROBADO = "03";
	public static final String COD_EST_INFOR_SELEC_DEVUELTO_X_SUPERVISOR = "04";
	public static final String COD_EST_INFOR_SELEC_AUTORIZADO = "05";
	public static final String COD_EST_INFOR_SELEC_DEVUELTO_X_GERENCIA = "06";
	public static final String COD_EST_INFOR_SELEC_PENDIENTE_ASIGNACION = "07";
	public static final String COD_EST_INFOR_SELEC_ASIGNANDO_AUDITORES = "08";
	public static final String COD_EST_INFOR_SELEC_ERROR_ASIGNACION = "09";
	public static final String COD_EST_INFOR_SELEC_PENDIENTE_COMPLETAR = "10";
	public static final String COD_EST_INFOR_SELEC_CONCLUIDO = "11";
	public static final String COD_EST_INFOR_SELEC_DERIVACION_COMPLETA = "12";
	public static final String COD_EST_INFOR_SELEC_ERROR_GENERA_ORDENES = "13";
	public static final String COD_EST_INFOR_SELEC_GENERANDO_ORDENES = "14"; 
	
	/** TIPO ESTADO ORDEN : t10415ordenaccion.cod_est_orden*/
	public static final String COD_EST_ORDEN_GENERADA = "01"; 
	public static final String COD_EST_ORDEN_PENDIENTE = "02";
	public static final String COD_EST_ORDEN_EN_PROCESO = "03";
	public static final String COD_EST_ORDEN_EN_EVALUACION = "04";
	public static final String COD_EST_ORDEN_DEVUELTO = "05";
	public static final String COD_EST_ORDEN_TERMINADO = "06";
	public static final String COD_EST_ORDEN_CANCELADA = "07";

	public static final String COD_ESTADO_ORDEN_GENERADA     = "01";
	public static final String COD_ESTADO_ORDEN_PENDIENTE    = "02";
	public static final String COD_ESTADO_ORDEN_ENPROCESO    = "03";
	public static final String COD_ESTADO_ORDEN_ENEVALUACION = "04";
	public static final String COD_ESTADO_ORDEN_DEVUELTO     = "05";
	public static final String COD_ESTADO_ORDEN_TERMINADO    = "06";
	public static final String COD_ESTADO_ORDEN_CANCELADA    = "07";	
	
	public static final String COD_RESULTADO_ORDEN_CONFORME  = "01";
	
	/**ERROR_CARGA_DDMMYYYY_HHMMSS.txt*/
	public static final String NOM_ARCHIVO_ERROR = "ERROR_CARGA_{1}.txt";

	/** TIPO DE ARCHIVOS  TABLA : t10445arcacf | cod_tip_arc */
	public static final String COD_TIP_ARC_CARGA_USUARIO = "04";
	public static final String COD_TIP_ARC_ERROR_CARGA_USUARIO = "05";

	/** CODIGOS UBIGEO DEPARTAMENTO */
	public static final String COD_UBIG_DEPA_LIMA = "15";
	
	public static final String DATASOURCE_DCSICOBF = "dcsicobfAC";
	public static final String DATASOURCE_DGSICOBF = "dgsicobfAC";
	public static final String DATASOURCE_DCCPE = "dccpe1";
	
	public static final int CONS_CANT_CEROS_ORDEN = 4;
	
	/** MENSAJES DE NOTIFICACION */
	public static final String COD_MENSAJE_EXITO_GENR_ORDEN = "0027";
	public static final String COD_MENSAJE_FALLO_GENR_ORDEN = "0028";
	
	/** CONSTANTE CREACION DE REGISTRO BATCH*/
	public static final String CONS_USR_CREACION_MODIFICACION_BATCH = "batch";
	public static final String CONS_IP_USR_CREACION_MODIFICACION_BATCH = "0.0.0.0";

	public static final String COD_IND_SERVICIO = "1";

	public static final String OPCION_TIPO_BIEN_INSUMO = "1";
    public static final String OPCION_TIPO_BIEN_COMBUSTIBLE = "2"; //5
    public static final String OPCION_TIPO_BIEN_DISOLVENTE = "4";
    public static final String OPCION_TIPO_BIEN_MEZCLA = "5";
	public static final String OPCION_OTROS = "99";
	public static final String OPCION_DESCRIPCION_OTROS = "OTROS";
	public static final String SINVALOR = "";


	public static final String COD_TIP_PROG_BIEN 	 = "01";
	public static final String COD_TIP_PROG_SERVICIO = "02";
	public static final String COD_BIEN_VACIO = "000";

	// Constantes Mensajes
	public static final String COD_MENSAJE_CORREO_F01 = "0017";
	public static final String COD_MENSAJE_CORREO_F02 = "0018";
	public static final String COD_MENSAJE_CORREO_F03 = "0019";
	public static final String COD_MENSAJE_CORREO_F04 = "0020";
	public static final String COD_MENSAJE_CORREO_F05 = "0021";
	public static final String COD_MENSAJE_CORREO_F06 = "0022";
	public static final String COD_MENSAJE_CORREO_F07 = "0023";
	public static final String COD_MENSAJE_CORREO_F08 = "0024";
	public static final String COD_MENSAJE_CORREO_F09 = "0025";
	public static final String COD_MENSAJE_CORREO_F10 = "0026";
	
	public static final String COD_MENSAJE_CORREO_F11 = "0026";
	
	public static final String COD_MENSAJE_CORREO_F11a = "0027";
	public static final String COD_MENSAJE_CORREO_F11b = "0028";
	public static final String COD_MENSAJE_CORREO_F12 = "0029";
	public static final String COD_MENSAJE_CORREO_F13 = "0030";
	public static final String COD_MENSAJE_CORREO_F14 = "0033";
	public static final String COD_MENSAJE_CORREO_F15 = "0032";
	public static final String COD_MENSAJE_CORREO_F16 = "0033";
	public static final String COD_MENSAJE_CORREO_F17 = "0034";
	public static final String COD_MENSAJE_CORREO_F18 = "0035";
	public static final String COD_MENSAJE_CORREO_F19 = "0036";
	public static final String COD_MENSAJE_CORREO_F20 = "0037";
	public static final String COD_MENSAJE_CORREO_F21 = "0038";
	public static final String COD_MENSAJE_CORREO_F11_2 = "0028";
	public static final String COD_MENSAJE_CORREO_F11_4 = "0030";
	
	/** Estado Documento Accion : t10406documeaccion.cod_est_doc  */
	public static final String COD_ESTADO_DOCACCION_GENERADO = "01";
	public static final String COD_ESTADO_DOCACCION_PENDIENTENOTIF = "02";
	public static final String COD_ESTADO_DOCACCION_NOTIFICADO = "03";	
	
	/** t10406documeaccion.ind_origen*/
	public static final String COD_IND_ORIGEN_DOCUMENTOACC_ELETRONICO = "1";

	/** FECHA ESTANDAR*/
	public static final String FECHA_ESTANDAR = "0001-01-01 00:00:00";

	public static final String COD_OTROS_PROGRAMAS = "999";
	
	/** t5284bfcabdjro.cod_estado*/
	public static final String COD_ESTADO_DJROP_EN_PLAZO  	 = "01";
	public static final String COD_ESTADO_DJROP_PENDIENTE  	 = "02";
	public static final String COD_ESTADO_DJROP_PRESENTADO   = "03";
	public static final String COD_ESTADO_DJROP_SUSTITUIDO   = "04";
	public static final String COD_ESTADO_DJROP_REGULARIZADO = "05";
	public static final String COD_ESTADO_DJROP_RECTIFICADO  = "06";
	 
	/** t5284bfcabdjro.num_confirma */
	public static final int    NUM_CONFIRMACION_SIN_ENVIO  = 0;
	
	/** t5284bfcabdjro.ind_omiso */
	public static final String COD_ESTADO_DJROP_DECLARADO  = "0";
	public static final String COD_ESTADO_DJROP_NO_DECLARADO  = "1";
	public static final String COD_ESTADO_DJROP_EXONERADO_DEL_MES  = "2";
	
	/** t5075bfregistro.cod_estado*/
	public static final String COD_ESTADO_REGISTRO_VIGENTE = "01";
	public static final String COD_ESTADO_REGISTRO_SUSPENDIDO = "02";
	public static final String COD_ESTADO_REGISTRO_BAJA = "03";

	/** t5074bfpresenta.ind_condicion */
	public static final String COD_IND_CONDICION_ITEM_REGISTRO = "1";
	
	/**CUS23*/
	public static final int NUM_ULTIMA_REPOSICION = 0;

	public static final String IND_ESTADO_ACTIVO_GUIA = "0";
	public static final String COD_TIP_DESTNATARIO = "02";
	public static final String COD_RELACION_TRANSPORTISTA_REMITENTE = "14";
	public static final String COD_TIP_GUIA_TRANSPORTISTA = "62";
	
	/** t10420programacion.cod_progctrl*/
	public static final String COD_TIP_PROG_OMISOS_DJ = "007";
	public static final String COD_TIP_PROG_USU_VIGENTES_STOCK_SALDO_NEGATIVO = "008";
	public static final String COD_TIP_PROG_USU_BAJA_STOCK = "009";
	public static final String COD_TIP_PROG_GRE_NOCONFIMADAS_TRANSPORTISTA = "011";
	public static final String COD_TIP_PROG_GRE_NOCONFIMADAS_DESTINATARIO = "010";

	/** t10420programacion.cod_sub_estprogram*/
	public static final String COD_SUBESTADO_ENPROCESO_DEPURACION = "01";
	public static final String COD_SUBESTADO_ERROR_ENPROCESO_DEPURACION = "02";
	public static final String COD_SUBESTADO_PENDIENTE_GENERACION_DOCUMENTOS = "03";
	public static final String COD_SUBESTADO_ENPROCESO_GENERACION_DOCUMENTOS = "04";
	public static final String COD_SUBESTADO_ERROR_ENPROCESO_GENERACION_DOCUMENTOS = "05";
	public static final String COD_SUBESTADO_PENDIENTE_PROCESO_NOTIFICACION = "06";
	public static final String COD_SUBESTADO_EN_PROCESO_NOTIFICACION = "07";
	public static final String COD_SUBESTADO_ERROR_PROCESO_NOTIFICACION = "08";
	public static final String COD_SUBESTADO_ENVIADOS_SINE = "09";
	
	public static final String COD_PROGRCONTROL_DE_BAJA_DJ = "03";
	
	public static final String COD_TIPO_INCON_STOCK_SALDO_NEGATIVO ="13";
	public static final String COD_TIPO_INCON_STOCK_NEGATIVO = "11";
	public static final String COD_TIPO_INCON_SALDO_NEGATIVO = "12";
	

	public static final String COD_TIP_TRANSPORTISTA ="01";
	public static final Integer COD_TIP_PERSONA_TRANSPORTISTA = 1;
	public static final String COD_TIP_GUIA_REMITENTE ="60";
	public static final Integer COD_TIP_TRASLADO_PUBLICO = 1;
	
	public static final String COD_TIP_DOCUMENTO_IDENT_RUC = "6";
	
	/** t10428usuarioprog.cod_est_usu*/
	public static final String COD_ESTADO_USUARIO_CARGADO = "01";
	public static final String COD_ESTADO_USUARIO_DEPURADO = "02";

	public static final String TIPO_ARCHIVO_TMP = "TMP";
	public static final String TIPO_ARCHIVO_BD  = "BD";
	/** */
	public static final String IND_CONDICION_ITEM_REGISTRO = "1";
	public static final String COD_ESTADO_ITEM_REGISTRO  ="01";
	
	public static final String COD_ESTADO_ACTIVO_RUC = "00";
	
	public static final String COD_ESTADO_REGISTRO_DEBAJA = "03";
	
	public static final String COD_TIPOBIEN_REGISTRO = "01";
	
	public static final String COD_TIPO_INCON_BAJA_STOCK_OMISO ="15";
	public static final String COD_TIPO_INCON_BAJA_OMISO ="16";
	public static final String COD_TIPO_INCON_BAJA_STOCK = "14";
	public static final String COD_TIPO_ASIGNA_PROGRAMADOR_ADMIN = "1";
	public static final String COD_TIPO_ASIGNA_PROGRAMADOR = "0";
	public static final String COD_TIPO_ASIGNA_PROGRAMADOR_MANUAL = "1";

	public static final String RUTA_PLANTILLA_EXCEL_OTROS = "/data0/plantillas/excel/ArchivoCargaUsuarios.xlsx";
	
	public static final String COD_ACCION_SUGERIDA_NOAPLICA ="00";
	public static final String COD_TIPO_ARCHIVO_DOCUMENTOS_ACCION_PRINCIPAL = "09";

	public static final String COD_MOTIVO_DEPURACION_BAJA_RUC ="01";
	public static final String COD_MOTIVO_DEPURACION_BAJA_RCBF ="02";
	public static final String COD_MOTIVO_DEPURACION_BAJA_RUC_RCBF ="03";
	
	public static final String COD_MOTIVO_DEPURACION_SUBSANO_INCONSISTENCIA = "05";
	
	public static final String COD_IND_DEPURACION_AUTOMATICA = "2";
	public static final String COD_TIPO_ARCHIVO_REPORTE_INCOSISTENCIA = "";
	
	//JTA
	public static final String DESCRIPCION_MIME_TYPE_PDF = "Application/pdf";
	public static final String COD_DENOMINACION_DECENIO = "01";
	public static final String COD_CATALOGO_DENOMINACION_DECENIO = "BD9";
	public static final String COD_CATALOGO_TEXTO_MODIFICABLE = "BDI";
	public static final String COD_CATALOGO_DENOMINACION_AIO = "B66";
	public static final String COD_DENOMINACION_AIO = "01";
	public static final String COD_TEXTO_MODIFICABLE = "02";
	public static final String COD_ANEXO_TELEFONICO = "01";
	public static final String COD_DIAS_HABILES = "03";
	public static final String COD_REPORTE_SEMAFORO = "04";
	public static final String COD_REPORTE_REGISTRO_CONTROL_BIEN = "05";
	public static final String COD_REPORTE_SALDO_DISPONIBLE = "06";
	public static final String COD_REPORTE_STOCK_MENSUAL = "07";
	public static final String COD_REPORTE_JASPER_PLANTILLA000926 = "PLANTILLA000926.jasper";
	public static final String COD_REPORTE_JASPER_PLANTILLA000927 = "PLANTILLA000927.jasper";
	public static final String COD_REPORTE_JASPER_PLANTILLA000928 = "PLANTILLA000928.jasper";
	public static final String COD_REPORTE_JASPER_PLANTILLA000929 = "PLANTILLA000929.jasper";
	public static final String COD_REPORTE_JASPER_PLANTILLA000930 = "PLANTILLA000930.jasper";
	public static final String COD_REPORTE_JASPER_RUTA = "/data0/generador/jasper/plantillas/rptReporteUsuariosBaja.jrxml";
	public static final String RUTA_LOGO_REPORTE = "/data0/generador/jasper/plantillas/imagenes/logo.png";
	public static final String RUTA_TEMPORAL_FIRMA = "/data0/tempo/";
	public static final String COD_TIPO_FIRMA_DIGITALIZADAS = "001";
    public static final String COD_SUBTIPO_FIRMA_CON_NOMBRE = "001004";
    public static final String IND_ACTIVO_REGISTRO = "S";
    public static final String DATASOURCE_DCSPAC = "dcspAC";
	//JTA
	
	public static final String MENSAJE_IQBF_PARAMETROS_NUMERO_SOLICITUD = "{numeroSolicitudProgramacion}";
	public static final String MENSAJE_IQBF_PARAMETROS_NUMERO_PROGRAMACION = "{nroProgramacion}";
	public static final String MENSAJE_IQBF_PARAMETROS_NRO_INFORME_SELECCION = "{nroInformeSeleccion}";
	public static final String MENSAJE_IQBF_PARAMETROS_ESTADO_PROGRAMACION = "{estadoProgramacion}";
	public static final String MENSAJE_IQBF_PARAMETROS_ALCANCE = "{Alcance}";

	// SELECTOR JMS
	public static final String JMS_CARGAUSUARIO = "SELECTOR.CARGARUSUARIOOTROSPROGRAMAS";
	
	
	//CONSTANTES REGISTRO ACTIVIDADES Y RESULTADOS
	public static final String COD_TIPO_ORDEN_CONTROL = "01";
	public static final String COD_TIPO_ORDEN_FISCALIZACION  = "02";
	public static final String COD_CATALOGO_UNIDAD_COMERCIAL = "B45";
	

	public static final String COD_TIPO_INTERVENCION_CONTROL = "01";
	public static final String COD_TIPO_INTERVENCION_FISCAL  = "02";
	public static final String COD_ESTADO_CONDICION_ACTIVO   = "01";
	public static final String COD_ESTADO_ESTABLECIMIENTO_VIGENTE = "01";
	public static final String COD_ESTADO_ESTABLECIMIENTO_SUSPENDIDO  = "02";
	public static final String COD_ESTADO_ESTABLECIMIENTO_BAJA  = "03";
	public static final String COD_TIPO_ASIGNACION_AUTOMATICA  = "0";
	
	// CONSTANTES DOCUMENTO ACCION
	public static final String COD_CATALOGO_ESTADO_DOCUMENTO_ACCION = "BCE";
	
	/**CUS09*/
	public static final String COD_TIPO_ACCION_CONTROL_NINGUNO  = "99";
	public static final String COD_TIPO_ACCION_CONTROL_NOAPLICA   = "00";
	public static final String COD_TIPO_MOTIVODEPURA_NINGUNO  = "00";
	public static final String COD_TIPO_MOTIVODEPURA_NOAPLICA  = "99";
	
	//tipo Documento
	
	public static final String COD_TIPO_ARCHIVO_DOCUMENTO_ADICIONAL="10";
	public static final String COD_TIPO_ARCHIVO_DOCUMENTO_OTROS = "01";
	
	public static final String COD_CATALOGO_DEPENDENCIAS = "003";
	
	public static final String PARAMETRO_UNIDAD_MEDIDA_BIEN="483";
	public static final String PARAMETRO_DEPARTAMENTO = "030";
	public static final String PARAMETRO_PROVINCIA = "031";
	public static final String PARAMETRO_DISTRITO = "001";
}
