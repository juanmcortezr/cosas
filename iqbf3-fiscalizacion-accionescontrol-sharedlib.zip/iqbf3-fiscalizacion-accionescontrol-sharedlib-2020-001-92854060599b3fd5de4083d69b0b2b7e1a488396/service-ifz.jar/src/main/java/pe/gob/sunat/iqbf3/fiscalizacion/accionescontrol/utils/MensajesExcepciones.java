package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils;

public class MensajesExcepciones {

	// CUS01
	public static final String CUS01_EXCP_004 = "Debe ingresar al menos un usuario";
	public static final String CUS01_EXCP_007 = "Debe completar las respuestas de los criterios de calificaci\u00f3n";
	public static final String CUS01_EXCP_015 = "Existen usuarios con tipo de intervenci\u00f3n 'Fiscalizaci\u00f3n' sin establecimiento registrado";
	public static final String CUS01_EXCP_016 = "Debe Calificar todos los usuarios ingresados en la solicitud";
	public static final String CUS01_EXCP_019 = "El usuario ya existe en la solicitud";

	// CUS04
	public static final String CUS04_EXCP_005 = "Existen criterios de calificaci\u00f3n que no est\u00e1n activos";
	public static final String CUS04_EXCP_003 = "Debe calificar a todos los usuarios para enviar";
	public static final String CUS04_EXCP_006 = "No ha respondido todos los criterios para la calificaci\u00f3n del usuario";

	// CUS06
	public static final String CUS06_EXCP_009 = "No se puede cancelar la programaci\u00f3n cuando el programador ya efectu\u00f3 la carga de usuarios";

	// CUS07
	public static final String CUS07_EXCP_005 = "Existe una carga en curso para la programaci\u00f3n";
	public static final String CUS07_EXCP_008 = "El archivo a adjuntar debe tener la estructura correcta";

	// CUS08
	// Donde n: numero de fila donde ocurrio el error.
	public static final String CUS08_EXCP_001 = "Fila n: Tipo de documento est\u00e1 vac\u00edo";
	public static final String CUS08_EXCP_002 = "Fila n: N\u00famero de documento est\u00e1 vac\u00edo";
	public static final String CUS08_EXCP_003 = "Fila n: N\u00famero de documento solo debe ser n\u00fameros";
	public static final String CUS08_EXCP_004 = "Fila n: N\u00famero de documento no es v\u00e1lido";
	public static final String CUS08_EXCP_005 = "Fila n: N\u00famero de documento no existe";
	public static final String CUS08_EXCP_006 = "Fila n: Nombre est\u00e1 vac\u00edo";
	public static final String CUS08_EXCP_007 = "Fila n: El nombre y apellido debe tener una longitud m\u00ednima de 5";

	// CUS09
	public static final String CUS09_EXCP_004 = "El Nro. de informe de selecci\u00f3n ya fue utilizado en otra programaci\u00f3n";
	public static final String CUS09_EXCP_006 = "El n\u00famero de documento ingresado no est\u00e1 registrado";
	public static final String CUS09_EXCP_007 = "Todos los usuarios deben tener una acci\u00f3n de control o un motivo de depuraci\u00f3n";
	public static final String CUS09_EXCP_008 = "El informe debe tener al menos un usuario con acci\u00f3n de control";
	public static final String CUS09_EXCP_011 = "El c\u00f3digo de Unidad Org\u00e1nica ingresado no existe";

	// CUS11
	public static final String CUS11_EXCP_007 = "Falta agregar auditores o agentes de puesto de control al tipo de acci\u00f3n <Nombre del tipo de acci\u00f3n>";

	// CUS22
	public static final String CUS22_EXCP_012 = "No se puede cancelar el programa de control, este ya fue utilizado para generar un Informe de selecci\u00f3n";
	public static final String CUS22_EXCP_013 = "La programaci\u00f3n no cuenta con usuario. Debe proceder a cancelar la programaci\u00f3n o verificar el motivo de depuraci\u00f3n";
	public static final String CUS22_EXCP_014 = "Existe una determinaci\u00f3n de usuarios en curso para el mismo programa de control. Debe esperar que culmine para generar una nueva programaci\u00f3n";

	// CUS29
	public static final String CUS29_EXCP_002 = "El Nro. de programaci\u00f3n o informe de selecci\u00f3n no existe";
	public static final String CUS29_EXCP_003 = "El Nro. de programaci\u00f3n o informe de selecci\u00f3n no corresponde a un programa definido";
	public static final String CUS29_EXCP_004 = "La programaci\u00f3n o informe de selecci\u00f3n no corresponde a un programador de su supervisi\u00f3n";
	public static final String CUS29_EXCP_005 = "No existen ordenes en estado 'Pendiente'";
	public static final String CUS29_EXCP_007 = "Existe un proceso de asignaci\u00f3n en curso para la programaci\u00f3n";

	// CUS30
	public static final String CUS30_EXCP_003 = "Los puntajes ingresados se encuentran en el rango de una de acci\u00f3n sugerida registrada";
	public static final String CUS30_EXCP_004 = "La descripci\u00f3n de la acci\u00f3n sugerida ya existe";
	public static final String CUS30_EXCP_005 = "El puntaje de la alternativa ya existe";
	
	// CUS18
	public static final String CUS18_EXCP_030 = "Debe ingresar el tipo y numero de documento de identificaci\u00f3n";
	public static final String CUS18_EXCP_031 = "Debe Ingresar el tipo y n\u00famero del documento";
	public static final String CUS18_EXCP_034 = "El n\u00famero de documento ya se encuentra en la lista";

}
