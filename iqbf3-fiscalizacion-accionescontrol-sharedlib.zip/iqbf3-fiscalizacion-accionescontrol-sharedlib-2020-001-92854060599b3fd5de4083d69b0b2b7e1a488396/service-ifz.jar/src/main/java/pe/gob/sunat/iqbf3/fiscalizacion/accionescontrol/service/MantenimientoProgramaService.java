package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;


public interface MantenimientoProgramaService {

    public  List<ProgramaControlBean> listarProgramaControl(String nombrePrograma,String estadoPrograma);
	
    public ProgramaControlBean guardarEstadoPrograma(ProgramaControlBean programaControlBean);

	public List<ProgramaControlBean> cargarDatosPrograma(String codProgctrl);
	
	public ProgramaControlBean guardarDatosPrograma(ProgramaControlBean programaControlBean);
}
