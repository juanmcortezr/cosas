package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

public class AccionesControlUtil {

	private static final Logger logger = LoggerFactory.getLogger(AccionesControlUtil.class);
	
	public static String generarMensaje(String mensaje, Map<String, Object> parametros) {
		StringBuffer buffer = MaestrosUtilidades.iniciarMensajeCorreo();
		buffer.append(AccionesControlUtil.formatearString(mensaje, parametros));
		return MaestrosUtilidades.cerrarMensajeCorreo(buffer).toString();
	}
	
	public static String formatearString(String mensaje, Map<String, Object> parametros) {
		String tmpMensaje = mensaje;
		for (Map.Entry<String, Object> param : parametros.entrySet()) {
			tmpMensaje = tmpMensaje.replaceAll("\\{" + param.getKey() + "\\}", (param.getValue() != null ? param.getValue().toString() : "-"));
		}
		return tmpMensaje;
	}

	public static String generarNumSoli(Integer numCorrel, Integer anioSolicitud, String codUUOO) {
		return String.format("SP-%04d-%d-%s", numCorrel, anioSolicitud, MaestrosUtilidades.toBlank(codUUOO));
	}

	public static String toBlank(String value){
		if(value.isEmpty()){
			return "";
		}else{
			return value.trim();
		}
	}
	public static void cerrarStream(Closeable closable) {
		if (null != closable) {
			try {
				closable.close();
			} catch (IOException e) {
				logger.error("Ocurrio un error.cerrarStream: ", e);
			}
		}
	}
	
	public static List<ProgramacionBean> listByDesProgramador(List<ProgramacionBean> listaPrograma,ProgramacionBean filtro){
		List<ProgramacionBean> lista2= new ArrayList<ProgramacionBean>();
		for (ProgramacionBean bean : listaPrograma) {
			if(bean.getDesProgramador()!=null && bean.getDesProgramador().toLowerCase().contains(filtro.getDesProgramador().toLowerCase())){
				lista2.add(bean);
			}
		}
		return lista2;
	}
}
