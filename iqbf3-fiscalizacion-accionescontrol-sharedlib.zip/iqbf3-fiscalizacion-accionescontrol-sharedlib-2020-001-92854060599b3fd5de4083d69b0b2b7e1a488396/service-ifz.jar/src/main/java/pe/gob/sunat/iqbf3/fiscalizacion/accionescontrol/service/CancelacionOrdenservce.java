package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;

public interface CancelacionOrdenservce {
	
	List<OrdenAccionBean> listarOrden(OrdenAccionBean filtro);
	
	public OrdenAccionBean obtenerDatosOrden(Long numOrden);

	public OrdenAccionBean obtenerArchivo(String numArc);

	public void eliminarDocumento(ArchivoBean archivoBean);
	
	public OrdenAccion actualizarOrden(OrdenAccionBean filtro);
	
	

}
