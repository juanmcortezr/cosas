package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.WSUnidadOrgBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface GestionProgramaAsignadoService {

	public List<ProgramacionBean> listarPrograma(ProgramacionBean filtro);

	public ProgramacionBean obtenerCargarFiscalizable(Long numProgramacion);

	public ArchivoBean descargarPlantilla();

	public ArchivoBean obtenerDetalleError(Long numProgramacion);

	public ResponseBean<ProgramacionBean> guardarUniversoFiscalizable(ProgramacionBean programacion);

	public List<UsuarioProgramacionBean> listarUsuarioProgramacion(UsuarioProgramacionBean filtro);

	public ProgramacionBean obtenerDatosProgramacion(Long numProgramacion);

	public List< ProgramacionBean> listarOtraAccion(UsuarioProgramacionBean filtro);

	public ResponseBean<UsuarioProgramacionBean> guardarUsuario(UsuarioProgramacionBean formulario);

	public ResponseBean<InformeSeleccionBean> guardarInformeSeleccion(InformeSeleccionBean formulario);
	public ResponseBean<InformeSeleccionBean> enviarInformeSeleccion (InformeSeleccionBean formulario);
	public ResponseBean<UsuarioProgramacionBean> guardarDocumentoVinculado(UsuarioProgramacionBean formulario);
	public List<UsuarioProgramacionBean> obtenerDatosDocVin(UsuarioProgramacionBean formulario);
	public WSUnidadOrgBean validarCodigoUUOO(String codUnidadOrganica);
	

}
