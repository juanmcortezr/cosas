package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import javax.ws.rs.core.Response;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActaBienOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActaEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActividadEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActividadOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ContactoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DetalleResultadoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOperacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.EstablecimientoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaControlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaIncosistenciaGreNCBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaIncosistenciaSaldoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramaIncosistenciaStockBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SuspensionOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.TareoAuditorBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.TipoInconsistenciaOrdenBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface RegistroResultadoService {

	List<OrdenAccionBean> listarOrdenAccion(OrdenAccionBean filtro);
	
	ProgramaControlBean obtenerTipoProgramaControl(Long numOrden);
	
	public OrdenAccionBean obtenerDatosOrden(Long numOrden);
	
	List<ProgramaIncosistenciaStockBean> listarDetalleStockNegativo(Long numUsuarioPrograma);
	
	List<ProgramaIncosistenciaSaldoBean> listarDetalleSaldoNegativo(Long numUsuarioPrograma);
	
	List<ProgramaIncosistenciaGreNCBean> listarDetalleGreNoConfirmada(Long numUsuarioPrograma);
	
	OrdenAccionBean obtenerDetalleInconsistencia(Long numUsuarioPrograma);
	
	List<ContactoOrdenBean> listarContacto(Long numOrden);
	
	List<DocumentoOrdenBean> listarOtroDocumento(Long numOrden);
	
	List<TareoAuditorBean> listarTareo(Long numOrden);
	
	int guardarResultadoOrden(OrdenAccionBean ordenAccionBean);

	List<DocumentoAccionBean> listarDocumentoAccion(Long numOrden);
	
	ResponseBean<ContactoOrdenBean> guardarContacto(ContactoOrdenBean formulario);
	
	public boolean eliminarContacto(ContactoOrdenBean contactoBean);
	
	ResponseBean<DocumentoOrdenBean> guardarOtroDocumento(DocumentoOrdenBean formulario);
	
	List<BienEstablecimientoBean> listarBien(BienEstablecimientoBean bean);
	List<ActaEstablecimientoBean> listarActa(ActaEstablecimientoBean bean);
	List<ActividadEstablecimientoBean> listarActividadEstab(ActividadEstablecimientoBean bean);
	List<EstablecimientoOrdenBean> listarEstablecimiento(EstablecimientoOrdenBean bean);
	List<DocumentoOperacionBean> listarOperacion(DocumentoOperacionBean bean);
	DocumentoOperacionBean guardarOperacion(DocumentoOperacionBean bean);
	DocumentoOperacionBean actualizarDocumentoOperacion(DocumentoOperacionBean bean);
	TareoAuditorBean guardarTareo(TareoAuditorBean bean);
	TareoAuditorBean actualizarTareo(TareoAuditorBean bean);
	ContactoOrdenBean actualizarContactoOrden(ContactoOrdenBean bean);
	ContactoOrdenBean guardarContactoOrden(ContactoOrdenBean bean);
	DocumentoOrdenBean guardarDocumentoOrden(DocumentoOrdenBean bean);
	DocumentoOrdenBean actualizarDocumentoOrden(DocumentoOrdenBean bean);
	int guardarEstablecimiento(EstablecimientoOrdenBean beanEstab);
	int actualizarEstablecimientoOrden(EstablecimientoOrdenBean beanEstab);
	int actualizarActaEstab(ActaEstablecimientoBean beanActa);
	int actualizarActividadEstablecimiento(ActividadEstablecimientoBean bean);
	int actualizarBienEstabOrden(BienEstablecimientoBean beanBien);
	int actualizarActaBien(ActaBienOrdenBean beanActaBien);
	int actualizarSuspencionOrden(SuspensionOrdenBean beanSuspension);
	int actualizarInconsistenciaOrden(TipoInconsistenciaOrdenBean beanTipIncon);
	int actualizarDetalleResultadoOrden(DetalleResultadoOrdenBean beanDetaResu) ;
	int actualizarActividadOrden(ActividadOrdenBean beanActividadOrden);
	
	
}