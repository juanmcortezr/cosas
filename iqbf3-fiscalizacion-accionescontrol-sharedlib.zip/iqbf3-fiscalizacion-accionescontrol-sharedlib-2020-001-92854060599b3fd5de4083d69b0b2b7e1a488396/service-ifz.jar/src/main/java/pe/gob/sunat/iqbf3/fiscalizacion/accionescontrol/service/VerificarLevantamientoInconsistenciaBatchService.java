package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface VerificarLevantamientoInconsistenciaBatchService {

	public ResponseBean<String> iniciarProcesamiento(Long numProgramacion);
	
	public void verificarInconsistenciaProgramaControlOmisosDj(OrdenAccion ordenGenerada);
	
	public void verificarInconsistenciaProgramaStockSaldoNegativo(OrdenAccion ordenGenerada);
	
	public void verificarInconsistenciaProgramaControlBajaOmisoStockNegativo(OrdenAccion ordenGenerada);
	
	public void verificarInconsisProgramaControlGreNoConfirmadasDestinatario(OrdenAccion ordenGenerada);
	
	public void verificarInconsisProgramaControlGreNoConfirmadasTransportista(OrdenAccion ordenGenerada);
}
