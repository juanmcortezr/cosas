package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.AuditoriaBean;

public interface ComunService {

	public Long guardarArchivo(ArchivoBean archivoBean, AuditoriaBean auditoriaBean);

	public ArchivoBean obtenerArchivo(Long numArc);

	public byte[] obtenerBytesArchivo(Long numArc);
	
	public String obtenerDescripcionCodCatalogo(String catalogo,String codDataCatalogo);
	public String obtenerDescripcionParametro(String numParam,String argParam);
}
