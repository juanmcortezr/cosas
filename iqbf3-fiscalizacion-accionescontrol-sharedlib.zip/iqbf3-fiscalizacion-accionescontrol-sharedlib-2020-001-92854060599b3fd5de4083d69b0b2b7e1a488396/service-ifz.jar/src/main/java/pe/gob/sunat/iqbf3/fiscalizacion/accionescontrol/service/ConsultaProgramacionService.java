package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;

public interface ConsultaProgramacionService {
	
	public List<ProgramacionBean> listarConsultaProgramacion (ProgramacionBean filtro);

	
}
