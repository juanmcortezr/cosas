package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;

public interface EvaluacionSolicitudService {

	public List<SolicitudProgramacionBean> listarSolicitudSupervisorProgramador(SolicitudProgramacionBean filtro);

	public SolicitudProgramacionBean obtenerDatosSolicitud(Long numSolicProg);

	public UsuarioSolicitudBean obtenerUsuarioSeleccionado(Long numUsuarioSolicitud);

	public SolicitudProgramacionBean guardarEvaluacion(SolicitudProgramacionBean formulario);

}
