package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AgentePuestosCtrlBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaUsuarioAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignacionMasivaAuditoresBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DistribucionGrupoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.GrupoProcesoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PreseleccionAsignacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PreseleccionAsignacion;

public interface AsignacionMasivaOrdenService {

	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro);
	
	public ProgramacionBean obtenerDatosProgramacion(String numProgramacion);
	
	public List<UsuarioProgramacionBean> listarResumenAccion(String numProgramacion);
	
	public List<PreseleccionAsignacionBean> listarAuditorPresel(String numProgramacion, String codTipoAccion);
	
	public void guardarAuditorPresel(PreseleccionAsignacionBean preseleccionAsignacionBean);
	
	public void eliminarAuditorPresel(PreseleccionAsignacionBean preseleccionAsignacionBean);
	
	public List<GrupoProcesoBean> listarSupervisionAuditor();
	
	public List<DistribucionGrupoBean> listarAuditoresAuditores(String numGrupo);
	
	public List<AgentePuestosCtrlBean> listarAgentePuesto(String codPuesto);
	
	public void guardarAsignarAuditor(ProgramacionBean filtro);
	
}
