package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ActividadesBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.InformeSeleccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PersonaBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface GestionProgramaOtrosService {

	public List<ProgramacionBean> listarPrograma(ProgramacionBean filtro);
	public List<PersonaBean> listarProgramador();
	public List<ActividadesBean> listarActividadFiscalizada();
	public ResponseBean<ProgramacionBean> guardarPrograma(ProgramacionBean formulario);
	public ProgramacionBean obtenerDatosProgramacion(Long numProgramacion);
	public List<ActividadesBean> listarBienFiscalizado(String codTipoBien);
	public ResponseBean<ProgramacionBean> enviarProgramacion(ProgramacionBean formulario);
	public ResponseBean<ProgramacionBean> cancelarProgramacion(ProgramacionBean formulario);
	public ResponseBean<ProgramacionBean> guardarAsignacionProgramacion(ProgramacionBean formulario);
	public InformeSeleccionBean obtenerInformeSelecccion(Long numInforme);
}
