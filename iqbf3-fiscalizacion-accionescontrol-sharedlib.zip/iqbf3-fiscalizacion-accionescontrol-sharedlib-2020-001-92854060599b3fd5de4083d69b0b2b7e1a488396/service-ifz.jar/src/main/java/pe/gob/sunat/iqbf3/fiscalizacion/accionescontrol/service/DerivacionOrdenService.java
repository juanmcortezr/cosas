package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.OrdenAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.registro.maestros.bean.ArchivoBean;

public interface DerivacionOrdenService {

	public List<ProgramacionBean> listarProgramacion(ProgramacionBean filtro);
	public List<OrdenAccionBean> listarOrden(OrdenAccionBean filtro);
	public List<OrdenAccionBean> obtenerDatosOrden(Long numProgramacion);
	public OrdenAccionBean derivarOrdenes(OrdenAccionBean filtro);
	public ArchivoBean obtenerArchivo(Long numArc);
}
