package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ProgramacionBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface CargaUsuarioBatchService {

	public ResponseBean<String> validarArchivoCarga(Long	numProgramacion);
	
	public int actualizarEstadoProgramacion(ProgramacionBean bProgramacion);

}
