package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienFiscalizadoSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CalificacionUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.EstablecimientoUsuarioBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioSolicitudBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.ResponseBean;

public interface GestionSolicitudService {
	
	public SolicitudProgramacionBean guardarSolicitud(SolicitudProgramacionBean filtro);
	public ResponseBean<UsuarioSolicitudBean> guardarUsuario(UsuarioSolicitudBean filtro);
	public boolean eliminarSolicitudProgramacion(UsuarioSolicitudBean filtro);
	public boolean eliminarUsuario(UsuarioSolicitudBean filtro);
	public boolean eliminarEstablecimientoUsuario(EstablecimientoUsuarioBean filtro);
	public List<SolicitudProgramacionBean> listarSolicitudProgramacion(SolicitudProgramacionBean filtro);
	public UsuarioSolicitudBean obtenerDatosUsuario(UsuarioSolicitudBean filtro);
	public EstablecimientoUsuarioBean obtenerDatosEstablecimientoUsuario(EstablecimientoUsuarioBean filtro);
	
	public List<BienFiscalizadoSolicitudBean> listarBienesFiscalizados(String codTipoBien);
	public List<UsuarioSolicitudBean> obtenerDetalleSolicitud(Long numSolicProg);
	public List<EstablecimientoUsuarioBean> listarEstablecimientosUsuario(UsuarioSolicitudBean filtro);
	public SolicitudProgramacionBean obtenerDatosSolicitud(Long numSolicProg);

	public UsuarioSolicitudBean guardarEstablecimiento(UsuarioSolicitudBean filtro);

	public ResponseBean<String> enviarDetalleSolicitudProgram(UsuarioSolicitudBean filtro);
	public ResponseBean<List<String>> vigenciaUsuarioSolicitud(String tipoDocUsuario, String numDocUsuario);
	public ResponseBean<List<String>> vigenciaUsuarioOrden(String tipoDocUsuario, String numDocUsuario);

	public CalificacionUsuarioBean obtenerDatosCaliPre(Long numUsuario);

	public CalificacionUsuarioBean guardarCalificacionPreliminar(CalificacionUsuarioBean formulario);
	public List<SolicitudProgramacionBean> listarSolicitudSupervisorSolicitante(SolicitudProgramacionBean filtro);

}
