package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.service;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.SolicitudProgramacionBean;

public interface ConsultaSolicitudService {

	public List<SolicitudProgramacionBean> listarConsultaSolicitudProgramacion(SolicitudProgramacionBean filtro);
	

}
