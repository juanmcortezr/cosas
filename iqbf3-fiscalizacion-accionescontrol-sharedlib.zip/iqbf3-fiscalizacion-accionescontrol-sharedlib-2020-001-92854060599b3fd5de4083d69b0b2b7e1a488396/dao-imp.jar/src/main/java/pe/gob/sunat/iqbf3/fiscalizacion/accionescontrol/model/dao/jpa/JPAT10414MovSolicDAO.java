package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10414MovSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10414MovSolicDAO extends AbstractDAOImpl<MovimientoSolicitud, Long> implements T10414MovSolicDAO{

	public JPAT10414MovSolicDAO() {
		super(MovimientoSolicitud.class);
	}

}
