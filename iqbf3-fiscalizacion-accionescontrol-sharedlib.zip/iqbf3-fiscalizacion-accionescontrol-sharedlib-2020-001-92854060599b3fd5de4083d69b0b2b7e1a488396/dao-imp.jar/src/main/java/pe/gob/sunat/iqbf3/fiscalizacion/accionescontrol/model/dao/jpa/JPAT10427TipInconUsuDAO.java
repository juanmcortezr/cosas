package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10427TipInconUsuDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10427TipInconUsuDAO extends AbstractDAOImpl<TipoInconsistenciaUsuario, Long> implements T10427TipInconUsuDAO{

	public JPAT10427TipInconUsuDAO() {
		super(TipoInconsistenciaUsuario.class);
	}

}
