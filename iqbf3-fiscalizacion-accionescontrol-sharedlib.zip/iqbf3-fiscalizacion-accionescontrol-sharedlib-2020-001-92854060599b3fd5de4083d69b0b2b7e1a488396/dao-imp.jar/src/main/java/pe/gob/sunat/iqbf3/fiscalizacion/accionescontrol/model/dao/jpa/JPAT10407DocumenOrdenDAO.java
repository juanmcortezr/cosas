package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ContactoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10407DocumenOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10407DocumenOrdenDAO extends AbstractDAOImpl<DocumentoOrden, Long> implements T10407DocumenOrdenDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(JPAT10407DocumenOrdenDAO.class);

	public JPAT10407DocumenOrdenDAO() {
		super(DocumentoOrden.class);
	}

	@Override
	public List<DocumentoOrden> listarOtroDocumento(Long numOrden) {
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT10407DocumenOrdenDAO - listarOtroDocumento");
		
		builder.append("SELECT ")
		.append(" num_doc_orden as numDocumentoOrden, ")
		.append(" num_orden as numOrden, ")
		.append(" cod_origen as codOrigen, ")
		.append(" cod_tip_doc as codTipoDocumento, ")
		.append(" num_doc as numDocumento, ")
		.append(" des_doc as desDocumento, ")
		.append(" fec_emision as fecEmision, ")
		.append(" fec_entrega as fecEntrega, ")
		.append(" fec_notificacion as fecNotificacion, ")
		.append(" fec_prorroga as fecProrroga, ")
		.append(" fec_pres_visita as fecPresentaVisita, ")
		.append(" num_arc as numArc ")
		.append(" FROM t10407documenorden ");
		
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			builder.append(" WHERE num_orden = ?numOrden "); //numOrden
			params.addProperty("numOrden", numOrden);
		}
		
		logger.debug(String.format("JPAT10407DocumenOrdenDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DocumentoOrden.class);
	}
	
	@Override
	public List<DocumentoOrden> listarOtroDocumento (DocumentoOrden param) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10407DocumenOrdenDAO - listarOtroDocumento");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ");
		builder.append("d.num_doc_orden as numDocumentoOrden,");
		builder.append("d.num_orden as numOrden,");
		builder.append("d.cod_origen as codOrigen,");
		builder.append("d.cod_tip_doc as codTipoDocumento,");
		builder.append("d.num_doc as numDocumento,");
		builder.append("d.des_doc as desDocumento,");
		builder.append("d.fec_emision as fecEmision,");
		builder.append("d.fec_entrega as fecEntrega,");
		builder.append("d.fec_notificacion as fecNotificacion,");
		builder.append("d.fec_prorroga as fecProrroga,");
		builder.append("d.fec_pres_visita as fecPresentaVisita,");
		builder.append("d.num_arc as numArc, ");
		builder.append("a.nom_arc as nomArc ");
		builder.append("FROM t10407documenorden d ");
		builder.append("INNER JOIN t10445arcacf a ");
		builder.append("ON a.num_arc=d.num_arc ");
		builder.append("WHERE 1=1 ");
		
		
		if (!MaestrosUtilidades.isEmpty(param.getNumOrden())) {
			builder.append("AND d.num_orden = ?numOrden ");
			params.addProperty("numOrden", param.getNumOrden());
		}
		if (!MaestrosUtilidades.isEmpty(param.getIndDel())) {
			builder.append("AND d.ind_del = ?indDel ");
			builder.append("AND a.ind_del = ?indDel ");
			params.addProperty("indDel", param.getIndDel());
		}
		if (!MaestrosUtilidades.isEmpty(param.getIndEst())) {
			builder.append("AND d.ind_est = ?indEst ");
			builder.append("AND a.ind_est = ?indEst ");
			params.addProperty("indEst", param.getIndEst());
		}
		if (!MaestrosUtilidades.isEmpty(param.getNumDocumentoOrden())) {
			builder.append("AND d.num_doc_orden = ?numDocumentoOrden ");
			params.addProperty("numDocumentoOrden", param.getNumDocumentoOrden());
		}
		if (!MaestrosUtilidades.isEmpty(param.getCodOrigen())) {
			builder.append("AND d.cod_origen = ?codOrigen ");
			params.addProperty("codOrigen", param.getCodOrigen());
		}
		logger.debug(String.format("JPAT10407DocumenOrdenDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DocumentoOrden.class);
	}
	
	
	@Override
	public List<DocumentoOrdenBean> listarOtroDocumentoBean (DocumentoOrden param) {
		List<DocumentoOrdenBean> resultado=new ArrayList<DocumentoOrdenBean>();
		 
		List<DocumentoOrden> lstDocumTemp= listarOtroDocumento(param);
		if(!MaestrosUtilidades.isEmpty(lstDocumTemp)) {
			for(DocumentoOrden docuTemp:lstDocumTemp) {
				DocumentoOrdenBean beanTemp=new DocumentoOrdenBean();
				MaestrosUtilidades.copiarValoresBean(docuTemp,beanTemp);
				resultado.add(beanTemp);
			}
		}
		
		return resultado;
	}
	
	
	@Override
	public int actualizarDocumentoOrden(DocumentoOrden documentoOrden) {
		int resultado=0;
		
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
				
		builder.append("UPDATE t10407documenorden d SET ");
		builder.append(" d.fec_modif=SYSDATE ");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getCodOrigen()))builder.append(" ,d.COD_ORIGEN = ?2");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getCodTipoDocumento()))builder.append(" ,d.COD_TIP_DOC = ?3");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getDesDocumento()))builder.append(" ,d.DES_DOC = ?4");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getFecEmision()))builder.append(" ,d.FEC_EMISION = ?5");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getFecEntrega()))builder.append(" ,d.FEC_ENTREGA = ?6");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getFecNotificacion()))builder.append(" ,d.FEC_NOTIFICACION = ?7");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getFecPresentaVisita()))builder.append(" ,d.FEC_PRES_VISITA = ?8");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getFecProrroga()))builder.append(" ,d.FEC_PRORROGA = ?9");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getNumDocumento()))builder.append(" ,d.NUM_DOC = ?10");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getNumArc())&&documentoOrden.getNumArc()>0)builder.append(" ,d.num_arc = ?11");
		if(documentoOrden.isIndEliminar()) {
		builder.append(" ,d.IND_DEL = ?12");
		builder.append(" ,d.IND_EST = ?13");
		}
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getCodUsuModif()))builder.append(" ,d.COD_USUMODIF = ?14");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getDirIpusumodif()))builder.append(" ,d.DIR_IPUSUMODIF = ?15");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getNumOrden())&&documentoOrden.getNumOrden()>0)builder.append(" ,d.num_orden = ?16");
		builder.append(" WHERE 1=1 ");
		if(!MaestrosUtilidades.isEmpty(documentoOrden.getNumDocumentoOrden())&&documentoOrden.getNumDocumentoOrden()>0)builder.append(" AND d.NUM_DOC_ORDEN = ?1 ");
		
		Query query = entityManager.createNativeQuery(builder.toString());
		
		query.setParameter(1 , documentoOrden.getNumDocumentoOrden());
		query.setParameter(2 , documentoOrden.getCodOrigen());
		query.setParameter(3 , documentoOrden.getCodTipoDocumento());
		query.setParameter(4 , documentoOrden.getDesDocumento());
		query.setParameter(5 , documentoOrden.getFecEmision());
		query.setParameter(6 , documentoOrden.getFecEntrega());
		query.setParameter(7 , documentoOrden.getFecNotificacion());
		query.setParameter(8 , documentoOrden.getFecPresentaVisita());
		query.setParameter(9 , documentoOrden.getFecProrroga());
		query.setParameter(10 , documentoOrden.getNumDocumento());
		query.setParameter(11, documentoOrden.getNumArc());
		if(documentoOrden.isIndEliminar()) {
		query.setParameter(12 , MaestrosConstantes.REGISTRO_ELIMINADO);
		query.setParameter(13 , MaestrosConstantes.REGISTRO_INACTIVO);
		}
		query.setParameter(14, documentoOrden.getCodUsuModif());
		query.setParameter(15 , documentoOrden.getDirIpusumodif());
		query.setParameter(16 , documentoOrden.getNumOrden());
			
		logger.debug(String.format("JPAT10407DocumenOrdenDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10407DocumenOrdenDAO: query => %s", builder.toString()));
		
		resultado =	query.executeUpdate();
		
		return resultado;
	}
	
}
