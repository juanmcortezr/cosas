package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienFiscalizadoUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10397BienFiscaUsuDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10397BienFiscaUsuDAO extends AbstractDAOImpl<BienFiscalizadoUsuario, Long> implements T10397BienFiscaUsuDAO  {

	public JPAT10397BienFiscaUsuDAO(){
		super(BienFiscalizadoUsuario.class);
	}
}
