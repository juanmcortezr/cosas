package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10393AsignaSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10393AsignaSolicDAO extends AbstractDAOImpl<AsignaSolicitud, Long> implements T10393AsignaSolicDAO  {
	
	public JPAT10393AsignaSolicDAO(){
		super(AsignaSolicitud.class);
	}
}
