package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DeclaracionesJuradasBfBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DeclaracionesJuradasBf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5284BfCabJroDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT5284BfCabJroDAO extends AbstractDAOImpl<DeclaracionesJuradasBf, Long> implements T5284BfCabJroDAO  {

	private static final Logger logger = LoggerFactory.getLogger(JPAT5284BfCabJroDAO.class);
	
	public JPAT5284BfCabJroDAO(){
		super(DeclaracionesJuradasBf.class);
	}

	@Override
	public List<DeclaracionesJuradasBf> listarUsuariosOmisosDjRop(DeclaracionesJuradasBfBean declaracionesJuradasBfBean)
	{
		if (logger.isWarnEnabled())
			logger.warn("Inicio JPAT5284BfCabJroDAO - listarUsuariosOmisosDjRop");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
	 builder.append("SELECT ")
			//.append("a.num_ruc as declaracionesJuradasBfPk_numRuc, ")
			//.append("a.num_verreg as declaracionesJuradasBfPk_numVersionRegistro, ")
	 		.append("a.num_ruc as numRuc, ")
	 		.append("a.num_verreg as numVersionRegistro, ")
			.append("MIN(a.num_periodo) as minPeriodo, ")
			.append("MAX(a.num_periodo) as maxPeriodo, ")
			.append("r.fec_finvigencia as fecFinvigencia, ")
			.append("r.cod_estado as codEstado, ")
			//.append("r.cod_tipbien as declaracionesJuradasBfPk_codTipobien ")
			.append("r.cod_tipbien as codTipobien ")
			.append("FROM t5284bfcabdjro a, t5075bfregistro r ")
			.append("WHERE a.num_verreg=r.num_verreg ")
			.append("AND a.num_ruc=r.num_ruc ")
			.append("AND a.cod_tipbien= r.cod_tipbien ");
	 
			 if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getLstEstadoBfRegistro())) {
			 		builder.append("AND a.num_verreg = (SELECT MAX(rg.num_verreg) FROM t5075bfregistro rg WHERE rg.cod_estado  "); 
			 		String estadoBf="";
			 		int cont = 1;
			 		for(String codEstadoBfRegistro : declaracionesJuradasBfBean.getLstEstadoBfRegistro()){
			 			logger.debug(String.format("cont: " + cont));
			 			
			 			if(cont == 1 ){
			 				estadoBf = "'" + codEstadoBfRegistro + "'";
			 				cont++;
			 			}else{
			 				estadoBf = estadoBf + ",'" + codEstadoBfRegistro + "'";
			 			}
			 			logger.debug(String.format("estadoBf: " + estadoBf));
			 		}
			 		builder.append(" IN ("+estadoBf+") ");
			 		//params.addProperty("estadoBf", estadoBf);
			 		
			 		builder.append("AND rg.num_ruc = a.num_ruc GROUP BY rg.num_ruc) "); //ultima version 
			 }
			
			if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getIndDel())) {
		 		builder.append("AND a.ind_del = ?indDel ");//     --dj activa
		 		params.addProperty("indDel", declaracionesJuradasBfBean.getIndDel());
			}
			
			if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getCodEstado())) {
				builder.append("AND a.cod_estado = ?codEstado ");// --pendiente
		 		params.addProperty("codEstado", declaracionesJuradasBfBean.getCodEstado());
			}
			
			if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getNumConfirma())) {
		 		builder.append("AND a.num_confirma = ?numConfirma ");//  -- no tienen envios
		 		params.addProperty("numConfirma", declaracionesJuradasBfBean.getNumConfirma());
			}
	 		
			if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getIndOmiso())) {
		 		builder.append("AND a.ind_omiso  <> ?indOmiso ");
		 		params.addProperty("indOmiso", declaracionesJuradasBfBean.getIndOmiso());
			}
			 
	 		builder.append("GROUP BY a.num_ruc , a.num_verreg, r.fec_finvigencia, r.cod_estado, r.cod_tipbien ");

	 		logger.debug(String.format("JPAT5284BfCabJroDAO: query => %s", builder.toString()));
	 	logger.debug(String.format("getIndDel: query => %s", declaracionesJuradasBfBean.getIndDel().toString()));
	 	logger.debug(String.format("getCodEstado: query => %s", declaracionesJuradasBfBean.getCodEstado().toString()));
	 	logger.debug(String.format("getNumConfirma: query => %s", declaracionesJuradasBfBean.getNumConfirma()));
	 	logger.debug(String.format("getIndOmiso: query => %s", declaracionesJuradasBfBean.getIndOmiso().toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DeclaracionesJuradasBf.class);
	}
	
	@Override
	public List<DeclaracionesJuradasBf> periodosOmisosPorUsuario(DeclaracionesJuradasBfBean declaracionesJuradasBfBean)
	{
		if (logger.isWarnEnabled())
			logger.warn("Inicio JPAT5284BfCabJroDAO - periodosOmisosPorUsuario");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		/*
		 * declaracionesJuradasBfBean.getNumVersionRegistro()
		 * declaracionesJuradasBfBean.getIndDel()
		 * declaracionesJuradasBfBean.getCodEstado()
		 * declaracionesJuradasBfBean.getNumConfirma()
		 * declaracionesJuradasBfBean.getNumRuc()
		 */
		
		
		builder.append("SELECT ")
		.append("a.num_ruc as numRuc, ")
		.append("a.num_verreg as numVersionRegistro, ")
		.append("MIN(a.num_periodo) as MinPeriodo, ")
		.append("MAX(a.num_periodo) as MaxPeriodo, ")
		.append("r.fec_finvigencia as fecFinvigencia, ")
		.append("r.cod_estado as codEstado")
		.append("FROM t5284bfcabdjro a, t5075bfregistro r ")
		.append("WHERE a.num_verreg = r.num_verreg ")
		.append("AND a.num_ruc = r.num_ruc ")
		.append("AND a.cod_tipbien= r.cod_tipbien ");
		
		if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getNumVersionRegistro())) {
			builder.append("AND a.num_verreg = #num_verreg# ");
	 		params.addProperty("cIndDelActivo", declaracionesJuradasBfBean.getNumVersionRegistro());
		}
		
		if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getIndDel())) {
			builder.append("AND a.ind_del = ?cIndDelActivo ");
	 		params.addProperty("cIndDelActivo", declaracionesJuradasBfBean.getIndDel());
		}
		
		if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getCodEstado())) {
			builder.append("AND a.cod_estado = ?cCodEstadoPendiente ");
	 		params.addProperty("cCodEstadoPendiente", declaracionesJuradasBfBean.getCodEstado());
		}
		
		if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getNumConfirma())) {
			builder.append("AND a.num_confirma = ?numConfirma  "); //-- 0  no tienen envios
	 		params.addProperty("numConfirma", declaracionesJuradasBfBean.getNumConfirma());
		}
		
		builder.append("AND a.ind_omiso <> 2  "); //-- no declarado
		
		
		if (!MaestrosUtilidades.isEmpty(declaracionesJuradasBfBean.getNumRuc())) {
			builder.append("AND a.num_ruc = ?numeroDocumento  ");
	 		params.addProperty("numeroDocumento", declaracionesJuradasBfBean.getNumRuc());
		}
		
		builder.append("GROUP BY a.num_ruc, a.num_verreg, r.fec_finvigencia, r.cod_estado ");

	 	logger.debug(String.format("JPAT5284BfCabJroDAO: query => %s", builder.toString()));
		
	 	
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DeclaracionesJuradasBf.class);
	}
}
