package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SuspensionOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10422SuspensOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;
import sun.applet.AppletPanel;

@Stateless
public class JPAT10422SuspensOrdenDAO extends AbstractDAOImpl<SuspensionOrden, Long> implements T10422SuspensOrdenDAO{
	
	private static final Logger logger = LoggerFactory.getLogger(JPAT10422SuspensOrdenDAO.class);
	
	public JPAT10422SuspensOrdenDAO() {
		super(SuspensionOrden.class);
	}

	
	@Override
	public List<SuspensionOrden> listarSuspension(SuspensionOrden suspensionOrden) {
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT10422SuspensOrdenDAO - listarOtroDocumento");
		
		builder.append("SELECT ")
		.append(" num_sus_suporden as numSusSuporden, ")
		.append(" cod_sus_susp as codSustentoSuspencion, ")
		.append(" ind_est as indEst ")
		.append(" FROM t10422suspensorden ")
		.append(" WHERE 1=1");
		
		if (!MaestrosUtilidades.isEmpty(suspensionOrden.getNumOrden())) {
			builder.append(" AND num_orden = ?numOrden "); //numOrden
			params.addProperty("numOrden", suspensionOrden.getNumOrden());
		}
		if (!MaestrosUtilidades.isEmpty(suspensionOrden.getIndDel())) {
			builder.append(" AND ind_del = ?indDel ");
			params.addProperty("indDel", suspensionOrden.getIndDel());
		}
		if (!MaestrosUtilidades.isEmpty(suspensionOrden.getIndEst())) {
			builder.append(" AND ind_est = ?indEst ");
			params.addProperty("indEst", suspensionOrden.getIndEst());
		}
		
		logger.debug(String.format("JPAT10422SuspensOrdenDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, SuspensionOrden.class);
	}
	
	@Override
	public int actualizarSuspension(SuspensionOrden model) {
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT10422SuspensOrdenDAO - actualizarSuspension");
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
			builder.append(" UPDATE t10422suspensorden s SET ");
			builder.append(" s.fec_modif = SYSDATE ");
			
		  if(model.getNumOrden()!=null&&model.getNumOrden()>0)builder.append(" ,s.num_orden =?2 ");
		  if(model.getCodSustentoSuspencion()!=null)builder.append(" ,s.cod_sus_susp = ?3 ");
		  if(!MaestrosUtilidades.isEmpty(model.getIndDel()))builder.append(" ,s.ind_del = ?4 ");  
		  if(!MaestrosUtilidades.isEmpty(model.getIndEst()))builder.append(" ,s.ind_est = ?5 ");       
		  if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,s.cod_usumodif = ?6 ");
		  if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,s.dir_ipusumodif = ?7 "); 
		  	
		  builder.append(" WHERE 1=1 ");
		  
		  if(model.getNumSusSuporden()!=null&&model.getNumSusSuporden()>0)builder.append(" AND s.num_sus_suporden = ?1 ");
		  if(model.getNumOrden()!=null&&model.getNumOrden()>0)builder.append(" AND s.num_orden = ?2 ");
		  
		Query query = entityManager.createNativeQuery(builder.toString());
		query.setParameter(1, model.getNumSusSuporden());
		query.setParameter(2, model.getNumOrden());
		query.setParameter(3, model.getCodSustentoSuspencion());
		query.setParameter(4, model.getIndDel());
		query.setParameter(5, model.getIndEst());
		query.setParameter(6, model.getCodUsuModif());
		query.setParameter(7, model.getDirIpusumodif());
		
		logger.debug(String.format("JPAT10422SuspensOrdenDAO: query => %s", builder.toString()));
		return query.executeUpdate();
	}
	
}
