package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.EstablecimientoUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10409EstabUsuDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;


@Stateless
public class JPAT10409EstabUsuDAO extends AbstractDAOImpl<EstablecimientoUsuario, Long> implements T10409EstabUsuDAO  {
	public JPAT10409EstabUsuDAO(){
		super(EstablecimientoUsuario.class);
	}
}
