package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaUsuarioAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DistribucionGrupo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8303DistriGrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT8303DistriGrupoDAO extends AbstractDAOImpl<DistribucionGrupo, Integer> implements T8303DistriGrupoDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT8303DistriGrupoDAO.class);

	public JPAT8303DistriGrupoDAO() {
		super(DistribucionGrupo.class);
	}

	@Override
	public List<DistribucionGrupo> listarProgramador(final String codCargo,
									final String codTipProc, final String indEst)
	{
		String query = "SELECT num_dist_grupo, cod_pers, cod_cargo FROM t8303distrigrupo d " + 
					   " INNER JOIN t8311grupo g  ON d.num_grupo = g.num_grupo " + 
					   " WHERE d.cod_cargo = ?1" + 
					   " AND g.cod_tipo_proceso = ?2" + 
					   " AND g.ind_est = ?3";
		return this.findQueryNative(query, Arrays.asList(codCargo, codTipProc, indEst), AccionesControlConstantes.DATASOURCE_DCSICOBF, DistribucionGrupo.class);
	}


	
	/*@Override
	public List<DistribucionGrupo> listarAuditor(final ArrayList<String> codEstOrden,final String codTipoProceso,final String numGrupo,final String codCargo,final String indEst){

		PropertyParams params=new PropertyParams();
		StringBuilder builder = new StringBuilder();
		   builder.append(" SELECT a.num_usu_program as numUsuarioPrograma,d.cod_pers as codPersonal,  ")
				.append(" (SELECT COUNT(*) as cantCarga")
				.append(" FROM t10394asignausuacc a  ")
				.append(" LEFT JOIN t10415ordenaccion o  ")
				.append(" ON o.num_usu_program = a.num_usu_program  ")
				.append(" WHERE a.cod_pers=d.cod_pers ");

		   		if (!MaestrosUtilidades.isEmpty(codEstOrden)) {
		   			builder.append(" AND o.cod_est_orden not in ?codEstOrden ");
		   			params.addProperty("codEstOrden", codEstOrden);
		   			}
	
		        builder.append(" ) as cantCarga ")
		   		.append(" FROM t8303distrigrupo d ")
		   		.append(" INNER JOIN t8311grupo g ")
		   		.append(" ON d.num_grupo = g.num_grupo ")
		   		.append(" LEFT JOIN t10394asignausuacc a on a.cod_pers=d.cod_pers ")
		   		.append(" WHERE 1=1 ");

		        builder.append(" AND d.ind_est = ?indEst ");
				params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		        
		        if (!MaestrosUtilidades.isEmpty(codTipoProceso)) {
		        	builder.append(" AND g.cod_tipo_proceso = ?codTipoProceso ");
		        	params.addProperty("codTipoProceso", codTipoProceso);
		        }
		   		
		        if (!MaestrosUtilidades.isEmpty(numGrupo)) {
		        builder.append(" AND d.num_grupo = ?numGrupo ");
		        params.addProperty("numGrupo", numGrupo);
		        }
		        
		        if (!MaestrosUtilidades.isEmpty(codCargo)) {
		        builder.append(" AND d.cod_cargo = ?codCargo ");
		        params.addProperty("codCargo", codCargo);
		        }

		        List<DistribucionGrupo> grupos = new ArrayList<DistribucionGrupo>();
		List<Object[]> object = (List<Object[]>) this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		for (Object[] objects : object) {
			Long numUsuarioPrograma = MaestrosUtilidades.toLong(objects[0]);
			String codPersonal = MaestrosUtilidades.toBlank(objects[1]);
			Long cantCarga = MaestrosUtilidades.toLong(objects[2]);
			System.out.println(Arrays.toString(objects));
			DistribucionGrupo grupo = new DistribucionGrupo();
			grupo.setCodPersonal(codPersonal);
			grupo.setCantCarga(cantCarga);
			grupo.setNumUsuarioPrograma(numUsuarioPrograma);
			grupos.add(grupo);
		}
		logger.debug(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		return grupos;
		//return this.findQueryNative(Arrays.toString(objects), Arrays.asList(codEstOrden, codTipoProceso, numGrupo,codCargo,indEst), AccionesControlConstantes.DATASOURCE_DCSICOBF, DistribucionGrupo.class);
		///return this.findQueryNative(builder.toString(), Arrays.asList(codEstOrden, codTipoProceso, numGrupo,codCargo,indEst), AccionesControlConstantes.DATASOURCE_DCSICOBF, DistribucionGrupo.class);
		logger.debug(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		System.out.print(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DistribucionGrupo.class);

	}*/

	@Override
	@SuppressWarnings("unchecked")
	public String obtenerSupervisorPersonal(String codPersPersonal) {
		if (logger.isDebugEnabled())	
			logger.debug("Inicio JPAT8303DistriGrupoDAO - obtenerSupervisorPersonal");
		String query = "SELECT MAX(cod_pers) FROM t8303distrigrupo WHERE cod_cargo = ?1 AND num_grupo IN (SELECT num_grupo " + 
					  "FROM t8303distrigrupo  WHERE cod_pers = ?2)";
		List<String> data = (List<String>) this.findQueryNative(query, Arrays.asList(AccionesControlConstantes.COD_CARGO_SUPERVISOR, codPersPersonal), AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(data)) {
			return data.get(0);
		}
		return null;
	}

	@Override
	public List<DistribucionGrupo> listarAuditorApoyo(DistribucionGrupo filtro) {

		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT8303DistriGrupoDAO - listarAuditorApoyo");

		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT a.num_usu_program as numUsuarioPrograma , d.cod_pers as codPersonal, d.num_grupo as numGrupo, d.cod_cargo as codCargo, g.cod_tipo_proceso as codTipoProceso FROM t8303distrigrupo d INNER JOIN t8311grupo g ON d.num_grupo = g.num_grupo ");
		builder.append(" LEFT JOIN t10394asignausuacc a on a.cod_pers=d.cod_pers WHERE 1=1");
		builder.append(" AND d.cod_cargo = ?codCargo ");
		params.addProperty("codCargo", filtro.getCodCargo());
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoProceso())) {
			builder.append(" AND g.cod_tipo_proceso = ?codTipoProceso ");
			params.addProperty("codTipoProceso", filtro.getCodTipoProceso());
		}
		builder.append(" AND d.ind_est = ?indEst ");
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		builder.append(" AND d.ind_del = ?indDel ");
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		if(!MaestrosUtilidades.isEmpty(filtro.getCodPersonal())){
			builder.append(" AND d.cod_pers = ?codPersonal ");
			params.addProperty("codPersonal", filtro.getCodPersonal());
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getNumGrupo())){
			builder.append(" AND d.num_grupo = ?numGrupo ");
			params.addProperty("numGrupo", filtro.getNumGrupo());
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getNumUsuarioPrograma())){
			builder.append(" AND a.num_usu_program = ?numUsuProgram ");
			params.addProperty("numUsuProgram", filtro.getNumUsuarioPrograma());
		}
		logger.debug(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DistribucionGrupo.class);
	
	}


	@Override
	public List<DistribucionGrupo> listarAuditorApoyoAccion(String numUsuarioProgram, String codCargo, String indEst) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DistribucionGrupo> listarAsignaProg(DistribucionGrupo filtro) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DistribucionGrupo> listarProgramador(DistribucionGrupo filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT8303DistriGrupoDAO - listarProgramador");

		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		//d.cod_pers as codPersonal
		builder.append("SELECT d.cod_pers as codPersonal, d.num_grupo as numGrupo, d.cod_cargo as codCargo, g.cod_tipo_proceso as codTipoProceso FROM t8303distrigrupo d INNER JOIN t8311grupo g ON d.num_grupo = g.num_grupo WHERE 1=1 ");
		builder.append(" AND d.cod_cargo = ?codCargo ");
		params.addProperty("codCargo", filtro.getCodCargo());
		builder.append(" AND g.cod_tipo_proceso = ?codTipoProceso ");
		params.addProperty("codTipoProceso", filtro.getCodTipoProceso());
		builder.append("AND d.ind_est = ?indEst");
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		logger.debug(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DistribucionGrupo.class);
	
	}

	@Override
	public List<AsignaUsuarioAccion> listarAuditor(AsignaUsuarioAccion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT8303DistriGrupoDAO - listarAuditor");

		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		//d.cod_pers as codPersonal
		builder.append("SELECT d.cod_pers as codAuditor, d.cod_cargo as codCargo, fec_inicio as fecInicioAsignacion, fec_fin as fecFinAsignacion,")
			   .append("(SELECT COUNT(*) FROM t10394asignausuacc a LEFT JOIN t10415ordenaccion o ON o.num_usu_program = a.num_usu_program ")
			   .append("WHERE a.cod_pers=d.cod_pers AND o.cod_est_orden <> ")
			   .append(AccionesControlConstantes.COD_ESTADO_ORDEN_TERMINADO)
			   .append(" AND o.cod_est_orden <> ")
			   .append(AccionesControlConstantes.COD_ESTADO_ORDEN_CANCELADA)
			   .append(" ) as cntCarga ")
			   .append("FROM t8303distrigrupo d INNER JOIN t8311grupo g ON d.num_grupo = g.num_grupo WHERE 1=1 ");

		builder.append(" AND g.cod_tipo_proceso = ?codTipoProceso ");
		params.addProperty("codTipoProceso", filtro.getCodTipoProceso());
		builder.append(" AND d.num_grupo = ?numGrupo ");
		params.addProperty("numGrupo", filtro.getNumGrupo());
		builder.append(" AND d.cod_cargo = ?codCargo ");
		params.addProperty("codTipoProceso", filtro.getCodCargo());
		builder.append("AND d.ind_est = ?indEst");
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		logger.debug(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, AsignaUsuarioAccion.class);
	
	}

	@Override
	public List<DistribucionGrupo> listarAuditor(ArrayList<String> codEstOrden, String codTipoProceso, String numGrupo,
			String codCargo, String indEst) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
