package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10413MovProgramDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10413MovProgramDAO extends AbstractDAOImpl<MovimientoProgramacion, Long> implements T10413MovProgramDAO{

	public JPAT10413MovProgramDAO() {
		super(MovimientoProgramacion.class);
		// TODO Auto-generated constructor stub
	}

}
