package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DeclaracionesJuradasBfBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PerfilRiesgosBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DeclaracionesJuradasBf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PerfilRiesgos;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8048PerRieDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT8048PerRieDAO extends AbstractDAOImpl<PerfilRiesgos, Long> implements T8048PerRieDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT8048PerRieDAO.class);
	
	public JPAT8048PerRieDAO() {
		super(PerfilRiesgos.class);
	}

	@Override
	public List<PerfilRiesgos> obtenerNivelRiesgo(PerfilRiesgosBean perfilRiesgosBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT First 1 ind_nivrie FROM t8048perrie ") 
				.append("WHERE cod_tipidenti = "+ perfilRiesgosBean.getCodTipoDocumentoIdent() + " ") //6 
				.append("AND   num_docidenti =  " + perfilRiesgosBean.getNumDocumentoIdentif() + " ")//'10407329347'
				.append("ORDER BY cod_pervagg desc ");
			
	 	logger.debug(String.format("JPAT5284BfCabJroDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, PerfilRiesgos.class);
	}
}
