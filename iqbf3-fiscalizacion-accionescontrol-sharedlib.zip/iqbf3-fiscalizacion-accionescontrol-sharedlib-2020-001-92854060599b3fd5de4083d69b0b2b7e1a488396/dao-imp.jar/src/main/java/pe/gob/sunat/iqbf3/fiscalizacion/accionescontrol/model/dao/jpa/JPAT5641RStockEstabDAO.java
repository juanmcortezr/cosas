package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenStockEstablecBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenStockEstablec;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5641RStockEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT5641RStockEstabDAO extends AbstractDAOImpl<ResumenStockEstablec, Long> implements T5641RStockEstabDAO{

	private static final Logger logger = LoggerFactory.getLogger(JPAT5641RStockEstabDAO.class);
	
	public JPAT5641RStockEstabDAO() {
		super(ResumenStockEstablec.class);
	}

	
	@Override
	public List<ResumenStockEstablec> listarUsuarioStockNegativo(ResumenStockEstablecBean resumenStockEstablecBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		String estadoBf = null;
		
		/*
		 * resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_ESTADO_ITEM_REGISTRO);
			lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
			lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
			resumenStockEstablecBean.setLstEstadoUsuarios(lstEstadoUsuario);
			resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
		 */
		
		builder.append("SELECT  ")
			.append("st.num_ruc, ")
			.append("reg.fec_finvigencia, ")
			.append("reg.cod_estado, ")
			.append("st.cod_tipbien, ")
			.append("st.num_verreg  ")
			.append("FROM t5641rstockestab st, t5070bfestab c, T5074BFPRESENTA  a, t5066bfcabinsumo b, t5075bfregistro reg ")
			.append("WHERE st.num_ruc= c.num_ruc AND st.num_verreg= c.num_verreg  ")
			.append("AND st.num_estab= c.num_estab ");
		
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
				builder.append("AND c.ind_condicion = ?ind_condicion  ");//--establecimiento
		 		params.addProperty("ind_condicion", resumenStockEstablecBean.getIndCondicion());
			}
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
				builder.append("AND c.cod_estado = ?cod_estado_item ");//---'01' -- Vigente
		 		params.addProperty("cod_estado_item", resumenStockEstablecBean.getCodEstadoItem());
			}
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
				builder.append("AND c.ind_del = ?ind_del  ");//--_cIndDelActivo
		 		params.addProperty("ind_del", resumenStockEstablecBean.getIndDel());
			}
			
			builder.append("AND st.num_ruc = a.num_ruc AND  ")
			.append("st.cod_tipbien = a.cod_tipbien  ")
			.append("AND st.num_verreg = a.num_verreg  ")
			.append("AND st.num_present= a.num_present  ");
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
				builder.append("AND a.ind_condicion = ?ind_condicionx  ");//---presentacion
		 		params.addProperty("ind_condicionx", resumenStockEstablecBean.getIndCondicion());
			}
			
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
				builder.append("AND a.cod_estado =  ?cod_estado_itemx  ");//--'01' -- Vigente
		 		params.addProperty("cod_estado_itemx", resumenStockEstablecBean.getCodEstadoItem());
			}
			
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
				builder.append("AND a.ind_del = ?ind_delx ");//--_cIndDelActivo
		 		params.addProperty("ind_delx", resumenStockEstablecBean.getIndDel());
			}
			
			builder.append("AND b.num_ruc = a.num_ruc  ")
			.append("AND b.cod_tipbien = a.cod_tipbien  ")
			.append("AND b.num_verreg = a.num_verreg  ")
			.append("AND b.num_inscab = a.num_inscab  ");
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
				builder.append("AND b.ind_condicion = ?ind_condicionv ");
		 		params.addProperty("ind_condicionv", resumenStockEstablecBean.getIndCondicion());
			}
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
				builder.append("AND b.cod_estado = ?cod_estado_itemv ");//--- '01'
		 		params.addProperty("cod_estado_itemv", resumenStockEstablecBean.getCodEstadoItem());
			}
			
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
				builder.append("AND b.ind_del = ?ind_dely  ");
		 		params.addProperty("ind_dely", resumenStockEstablecBean.getIndDel());
			}
			
			builder.append("AND reg.num_ruc= st.num_ruc  ")
			.append("AND reg.num_verreg = st.num_verreg  ")
			.append("AND reg.cod_tipbien = st.cod_tipbien ");
			
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
				builder.append("AND reg.ind_del = ?ind_delz  ");//--_cIndDelActivo
		 		params.addProperty("ind_delz", resumenStockEstablecBean.getIndDel());
			}
			
			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getLstEstadoUsuarios())) {
				builder.append("AND reg.cod_estado ");//--- vigente y suspendido
		 		int cont = 1;
		 		for(String codEstadoBfRegistro : resumenStockEstablecBean.getLstEstadoUsuarios()) {
		 			if(cont == 1 ){
		 				estadoBf = "'" + codEstadoBfRegistro + "'";
		 				cont++;
		 			}else{
		 				estadoBf = estadoBf + ",'" + codEstadoBfRegistro + "'";
		 			}
		 		}
		 		builder.append(" IN ("+estadoBf+") ");
		   }
			
			builder.append("AND st.num_periodo = (SELECT MIN(p.num_periodo) FROM t5641rstockestab p  ")
			                                .append("WHERE  p.num_ruc = st.num_ruc ")
			                                .append("AND p.num_verreg = st.num_verreg ")
			                                .append("AND p.cod_tipbien = st.cod_tipbien ")
			                                .append("AND p.num_present = st.num_present ")
			                                .append("AND p.num_estab = st.num_estab ")
			                                .append("AND p.cnt_stock_actual < 0  ");
			                                
			                    			if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			                    				builder.append("AND p.ind_del = ?ind_dela ");
			                    		 		params.addProperty("ind_dela", resumenStockEstablecBean.getIndDel());
			                    			}
			                                builder.append("AND p.num_verreg = (SELECT MAX(num_verreg) FROM t5075bfregistro rr ")
			                                .append("WHERE 1=1 ");
			                                
											if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getLstEstadoUsuarios())) {
												builder.append(" and rr.cod_estado IN ("+estadoBf+") ");
										   }
											
			                                builder.append("AND rr.num_ruc = p.num_ruc ");
			                                
			                                if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			                                	builder.append("AND rr.ind_del = ?ind_delb ");
			                    		 		params.addProperty("ind_delb", resumenStockEstablecBean.getIndDel());
			                    			}
			                                builder.append("GROUP BY rr.num_ruc))   ")             
			                                .append("AND st.num_reposicion = (SELECT num_reposicion FROM t5636bfreposicion r ")
			                                .append("WHERE r.num_ruc=st.num_ruc  ")
			                                .append("AND r.cod_tipbien = st.cod_tipbien ")
			                                .append("AND r.num_verreg = st.num_verreg ")
			                                .append("AND r.num_reposicion= st.num_reposicion  ");
			                                
			                                if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			                                	builder.append("AND r.ind_del = ?ind_delc ");
			                    		 		params.addProperty("ind_delc", resumenStockEstablecBean.getIndDel());
			                    			}
			                                builder.append("AND r.fec_ini_peranual = ( SELECT MIN(fec_ini_peranual) FROM t5636bfreposicion rm ")
			                                                                                        .append("WHERE rm.num_ruc=r.num_ruc ")
			                                                                .append("AND rm.num_verreg = r.num_verreg  ")
			                                                                .append("AND rm.cod_tipbien= r.cod_tipbien  ");
			                                                                if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			                                                                	builder.append("AND rm.ind_del = ?ind_deld ");
			                    			                    		 		params.addProperty("ind_deld", resumenStockEstablecBean.getIndDel());
			                    			                    			}
			                                                                builder.append(")) ");
		
		
		
		
	 	logger.debug(String.format("JPAT5641RStockEstabDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ResumenStockEstablec.class);
	}
	
	@Override
	public List<ResumenStockEstablec> listarStockNegativo(ResumenStockEstablecBean resumenStockEstablecBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		String estadoBf="";
		
		/*
		 * resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_ESTADO_ITEM_REGISTRO);
			lstEstadoUsuario = new ArrayList<>();
			lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
			lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
			resumenStockEstablecBean.setLstEstadoUsuarios(lstEstadoUsuario);
			resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
			resumenStockEstablecBean.setNumRuc(1);
		 */
		
		
		builder.append("SELECT  ")
			//.append("st.num_ruc as resumenStockEstablecPk_numRuc, ")
			.append("st.num_ruc as numRuc, ")
			.append("reg.fec_finvigencia as fecFinvigencia, ")
			.append("reg.cod_estado as codEstado, ")
			//.append("st.cod_tipbien as resumenStockEstablecPk_codTipobien, ")
			//.append("st.num_verreg as resumenStockEstablecPk_numVersionRegistro,  ")
			//.append("st.num_estab as resumenStockEstablecPk_numEstablecimiento, ")
			.append("st.cod_tipbien as codTipobien, ")
			.append("st.num_verreg as numVersionRegistro,  ")
			.append("st.num_estab as numEstablecimiento, ")
			.append("c.num_version as numVersionEstab, ")
			.append("a.num_present as numPresentacion, ") //bfEstablecimientoPK
			.append("a.cod_presen as codPresen, ") // registroPresentacionBfPk
			.append("a.num_version as numVersionPressentacion, ") //
			.append("b.num_inscab as numInscab, ") //codPresen	bfCabInsumoPK
			.append("b.num_version as numVersionCabInsumo, ")
			.append("b.cod_insumo as codInsumo, ")
			.append("b.num_orden as numOrden, ")
			.append("b.cod_tipprod as codTipProd,   ")
			.append("b.cod_um as codUm, ")
			//.append("st.num_periodo as resumenStockEstablecPk_numPeriodo, ")
			.append("st.num_periodo as numPeriodo, ")
			.append("st.cnt_stock_actual as cantidadStockActual, ")
			//.append("st.num_reposicion as resumenStockEstablecPk_numReposicion, ")
			.append("st.num_reposicion as numReposicion, ")
			.append("c.cod_ubigeo as codUbigeo, ")
			.append("b.des_nomprod as desNomProd, ")
			.append("b.des_nomcomprod as desNomComProd,  ")
			.append("a.cod_uni_com as codUnidadComercial, ")
			.append("a.cnt_unifisica as cantidadUnidadFisica, ")
			.append("a.cod_uni_fis as codUnidadFiscal, ")
			.append("b.cod_bienfisca as codBienFisca,  ")
			.append("b.num_version as numVersion, ")
			.append("NVL(a.cnt_net_prod,0) AS cntNetProd, ")
			.append("NVL(st.cnt_ing_est,0) AS cntIngEst, ")
			.append("(NVL(a.cnt_net_prod,0) * NVL(st.cnt_stock_actual,0)) as cntNeteada, ")
			.append("NVL(b.por_max_ins,0) as porMax, ")
			.append("NVL(b.por_min_ins,0) as porMin, ")
			.append("st.num_stock as numStock, ")
			.append("st.num_confirma as numConfirma, ")
			.append("st.cnt_sal_est as cantidadSalidaEstablec, ")
			.append("a.num_verreg as numVersionRegistroBfPresenta ")
		.append("FROM t5641rstockestab st, t5070bfestab c, T5074BFPRESENTA  a, t5066bfcabinsumo b, t5075bfregistro reg ")
		.append("WHERE st.num_ruc= c.num_ruc AND st.num_verreg= c.num_verreg  ")
		.append("AND st.num_estab= c.num_estab ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND c.ind_condicion = ?ind_condiciona  ");//--establecimiento
	 		params.addProperty("ind_condiciona", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND c.cod_estado = ?cod_estado_itema  ");//#cod_estado_item# -- Vigente
	 		params.addProperty("cod_estado_itema", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND c.ind_del = ?ind_dela  ");//--_cIndDelActivo
	 		params.addProperty("ind_dela", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND st.num_ruc = a.num_ruc AND  ")
		.append("st.cod_tipbien = a.cod_tipbien  ")
		.append("AND st.num_verreg = a.num_verreg  ")
		.append("AND st.num_present= a.num_present  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
	 		builder.append("AND a.ind_condicion = ?ind_condicionb  "); //---presentacion
	 		params.addProperty("ind_condicionb", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND a.cod_estado = ?cod_estado_itemb  "); //#cod_estado_item# -- Vigente
	 		params.addProperty("cod_estado_itemb", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND a.ind_del = ?ind_delb "); //--_cIndDelActivo
	 		params.addProperty("ind_delb", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND b.num_ruc = a.num_ruc  ")
		.append("AND b.cod_tipbien = a.cod_tipbien  ")
		.append("AND b.num_verreg = a.num_verreg  ")
		.append("AND b.num_inscab = a.num_inscab  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND b.ind_condicion = ?ind_condicionc ");
	 		params.addProperty("ind_condicionc", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND b.cod_estado = ?cod_estado_itemc  ");//#cod_estado_item#
	 		params.addProperty("cod_estado_itemc", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND b.ind_del = ?ind_delc  ");
	 		params.addProperty("ind_delc", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND reg.num_ruc= st.num_ruc  ")
		.append("AND reg.num_verreg = st.num_verreg  ")
		.append("AND reg.cod_tipbien = st.cod_tipbien ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND reg.ind_del = ?ind_deld  ");//--_cIndDelActivo
	 		params.addProperty("ind_deld", resumenStockEstablecBean.getIndDel());
		}
		
		 if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getLstEstadoUsuarios())) {
		 		builder.append("AND reg.cod_estado ");//--- vigente y suspendido
		 		int cont = 1;
		 		for(String codEstadoBfRegistro : resumenStockEstablecBean.getLstEstadoUsuarios()){
		 			if(cont == 1 ){
		 				estadoBf = "'" + codEstadoBfRegistro + "'";
		 				cont++;
		 			}else{
		 				estadoBf = estadoBf + ",'" + codEstadoBfRegistro + "'";
		 			}
		 		}
		 		builder.append(" IN ("+estadoBf+") ");
		 }
		 builder.append("AND st.num_periodo = (SELECT MIN(p.num_periodo) FROM t5641rstockestab p  ")
								.append("WHERE  p.num_ruc = st.num_ruc ")
								.append("AND p.num_verreg = st.num_verreg ")
								.append("AND p.cod_tipbien = st.cod_tipbien ")
								.append("AND p.num_present = st.num_present ")
								.append("AND p.num_estab = st.num_estab ")
								.append("AND p.cnt_stock_actual < 0  ")
								.append("AND p.ind_del = "+resumenStockEstablecBean.getIndDel()+" ")
								.append("AND p.num_verreg = (SELECT MAX(num_verreg) FROM t5075bfregistro rr ")
								.append("WHERE 1=1 ");
		 						if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getLstEstadoUsuarios())) {
		 							builder.append("and rr.cod_estado IN ("+estadoBf+") ");
		 						}
		 						builder.append("AND rr.num_ruc = p.num_ruc ");
		 						
		 						if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
		 							builder.append("AND rr.ind_del = ?ind_dele ");
		 					 		params.addProperty("ind_dele", resumenStockEstablecBean.getIndDel());
		 						}
		 						
		 						builder.append("GROUP BY rr.num_ruc)) ");            
		 						builder.append("AND st.num_reposicion = (SELECT num_reposicion FROM t5636bfreposicion r ")
								.append("WHERE r.num_ruc=st.num_ruc  ")
								.append("AND r.cod_tipbien = st.cod_tipbien ")
								.append("AND r.num_verreg = st.num_verreg ")
								.append("AND r.num_reposicion= st.num_reposicion  ");
		 						
		 						if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
		 							builder.append("AND r.ind_del = ?ind_delf ");
		 					 		params.addProperty("ind_delf", resumenStockEstablecBean.getIndDel());
		 						}
		 						
		 						builder.append("AND r.fec_ini_peranual = ( SELECT MIN(fec_ini_peranual) FROM t5636bfreposicion rm ")
																								.append("WHERE rm.num_ruc=r.num_ruc ")
																		.append("AND rm.num_verreg = r.num_verreg  ")
																		.append("AND rm.cod_tipbien= r.cod_tipbien  ");
																		
																		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
																			builder.append("AND rm.ind_del = ?ind_delg ");
												 					 		params.addProperty("ind_delg", resumenStockEstablecBean.getIndDel());
												 						}
																		builder.append(")) ");
	
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumRuc())) {
			builder.append("AND st.num_ruc = ?num_ruc ");
			params.addProperty("num_ruc", resumenStockEstablecBean.getNumRuc());
		}
		 						
	 	logger.debug(String.format("JPAT5641RStockEstabDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ResumenStockEstablec.class);
	}
	
	@Override
	public List<ResumenStockEstablec> cntStockNegativoVerificacion(ResumenStockEstablecBean resumenStockEstablecBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		String estadoBf="";
		
		/*
		 * resumenStockEstablecBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
			resumenStockEstablecBean.setCodEstadoItem(AccionesControlConstantes.COD_ESTADO_ITEM_REGISTRO);
			lstEstadoUsuario = new ArrayList<>();
			lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
			lstEstadoUsuario.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
			resumenStockEstablecBean.setLstEstadoUsuarios(lstEstadoUsuario);
			resumenStockEstablecBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);
			resumenStockEstablecBean.setNumRuc(1);
		 */
		
		
		builder.append("SELECT count (*) as cntStockNegativoVerificacion ")
		.append("FROM t5641rstockestab st, t5070bfestab c, T5074BFPRESENTA  a, t5066bfcabinsumo b, t5075bfregistro reg ")
		.append("WHERE st.num_ruc= c.num_ruc AND st.num_verreg= c.num_verreg  ")
		.append("AND st.num_estab= c.num_estab ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND c.ind_condicion = ?ind_condiciona  ");//--establecimiento
	 		params.addProperty("ind_condiciona", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND c.cod_estado = ?cod_estado_itema  ");//#cod_estado_item# -- Vigente
	 		params.addProperty("cod_estado_itema", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND c.ind_del = ?ind_dela  ");//--_cIndDelActivo
	 		params.addProperty("ind_dela", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND st.num_ruc = a.num_ruc AND  ")
		.append("st.cod_tipbien = a.cod_tipbien  ")
		.append("AND st.num_verreg = a.num_verreg  ")
		.append("AND st.num_present= a.num_present  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
	 		builder.append("AND a.ind_condicion = ?ind_condicionb  "); //---presentacion
	 		params.addProperty("ind_condicionb", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND a.cod_estado = ?cod_estado_itemb  "); //#cod_estado_item# -- Vigente
	 		params.addProperty("cod_estado_itemb", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND a.ind_del = ?ind_delb "); //--_cIndDelActivo
	 		params.addProperty("ind_delb", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND b.num_ruc = a.num_ruc  ")
		.append("AND b.cod_tipbien = a.cod_tipbien  ")
		.append("AND b.num_verreg = a.num_verreg  ")
		.append("AND b.num_inscab = a.num_inscab  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND b.ind_condicion = ?ind_condicionc ");
	 		params.addProperty("ind_condicionc", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND b.cod_estado = ?cod_estado_itemc  ");//#cod_estado_item#
	 		params.addProperty("cod_estado_itemc", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND b.ind_del = ?ind_delc  ");
	 		params.addProperty("ind_delc", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND reg.num_ruc= st.num_ruc  ")
		.append("AND reg.num_verreg = st.num_verreg  ")
		.append("AND reg.cod_tipbien = st.cod_tipbien ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND reg.ind_del = ?ind_deld  ");//--_cIndDelActivo
	 		params.addProperty("ind_deld", resumenStockEstablecBean.getIndDel());
		}
		
		 if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getLstEstadoUsuarios())) {
		 		builder.append("AND reg.cod_estado ");//--- vigente y suspendido
		 		int cont = 1;
		 		for(String codEstadoBfRegistro : resumenStockEstablecBean.getLstEstadoUsuarios()){
		 			if(cont == 1 ){
		 				estadoBf = "'" + codEstadoBfRegistro + "'";
		 				cont++;
		 			}else{
		 				estadoBf = estadoBf + ",'" + codEstadoBfRegistro + "'";
		 			}
		 		}
		 		builder.append(" IN ("+estadoBf+") ");
		 }
		 builder.append("AND st.num_periodo = (SELECT MIN(p.num_periodo) FROM t5641rstockestab p  ")
								.append("WHERE  p.num_ruc = st.num_ruc ")
								.append("AND p.num_verreg = st.num_verreg ")
								.append("AND p.cod_tipbien = st.cod_tipbien ")
								.append("AND p.num_present = st.num_present ")
								.append("AND p.num_estab = st.num_estab ")
								.append("AND p.cnt_stock_actual < 0  ")
								.append("AND p.ind_del = "+resumenStockEstablecBean.getIndDel()+" ")
								.append("AND p.num_verreg = (SELECT MAX(num_verreg) FROM t5075bfregistro rr ")
								.append("WHERE 1=1 ");
		 						if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getLstEstadoUsuarios())) {
		 							builder.append("and rr.cod_estado IN ("+estadoBf+") ");
		 						}
		 						builder.append("AND rr.num_ruc = p.num_ruc ");
		 						
		 						if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
		 							builder.append("AND rr.ind_del = ?ind_dele ");
		 					 		params.addProperty("ind_dele", resumenStockEstablecBean.getIndDel());
		 						}
		 						
		 						builder.append("GROUP BY rr.num_ruc)) ");            
		 						builder.append("AND st.num_reposicion = (SELECT num_reposicion FROM t5636bfreposicion r ")
								.append("WHERE r.num_ruc=st.num_ruc  ")
								.append("AND r.cod_tipbien = st.cod_tipbien ")
								.append("AND r.num_verreg = st.num_verreg ")
								.append("AND r.num_reposicion= st.num_reposicion  ");
		 						
		 						if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
		 							builder.append("AND r.ind_del = ?ind_delf ");
		 					 		params.addProperty("ind_delf", resumenStockEstablecBean.getIndDel());
		 						}
		 						
		 						builder.append("AND r.fec_ini_peranual = ( SELECT MIN(fec_ini_peranual) FROM t5636bfreposicion rm ")
																								.append("WHERE rm.num_ruc=r.num_ruc ")
																		.append("AND rm.num_verreg = r.num_verreg  ")
																		.append("AND rm.cod_tipbien= r.cod_tipbien  ");
																		
																		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
																			builder.append("AND rm.ind_del = ?ind_delg ");
												 					 		params.addProperty("ind_delg", resumenStockEstablecBean.getIndDel());
												 						}
																		builder.append(")) ");
	
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumRuc())) {
			builder.append("AND st.num_ruc = ?num_ruc ");
			params.addProperty("num_ruc", resumenStockEstablecBean.getNumRuc());
		}
		
		//--Filtros din�micos solo usados en la verificaci�n----
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumPresentacion())) {
			builder.append("AND st.num_present = ?num_present ");
			params.addProperty("num_present", resumenStockEstablecBean.getNumPresentacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumEstablecimiento())) {
			builder.append("AND st.num_estab = ?num_estab ");
			params.addProperty("num_estab", resumenStockEstablecBean.getNumEstablecimiento());
		}

		 						
	 	logger.debug(String.format("JPAT5641RStockEstabDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ResumenStockEstablec.class);
	}
	
	
	@Override
	public List<ResumenStockEstablec> cntStockNegativoBaja(ResumenStockEstablecBean resumenStockEstablecBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		String estadoBf="";
		
		/*
		 * -	#cCodEstadoBaja#= c�digo del estado del usuario 03 -Baja)
-	#ind_condicion #= condici�n de los presentaciones y establecimientos.
-	#numDocumento# = n�mero de RUC del usuario
-	#cod_tipbien# = c�digo del tipo de bien �01�
-	#num_verreg#= n�mero de versi�n del usuario 
-	ind_condicion= indicador de condici�n del �tem 
-	#cIndDelActivo#= indicador de registro no eliminado

		 */
		
		builder.append("SELECT count(1) as cantidadStock")
		.append("FROM t5641rstockestab st, t5070bfestab c, t5074bfpresenta a, t5066bfcabinsumo b  ")
		.append("WHERE st.num_ruc= c.num_ruc  ")
		.append("AND st.num_verreg= c.num_verreg  ")
		.append("AND st.num_estab= c.num_estab  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND c.ind_condicion = ?ind_condicionc ");//1--establecimiento
	 		params.addProperty("ind_condicionc", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND c.cod_estado = ?cCodEstadoBajaa ");
	 		params.addProperty("cCodEstadoBajaa", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND c.ind_del = ?cIndDelActivoa ");
	 		params.addProperty("cIndDelActivoa", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND st.num_ruc = a.num_ruc ")
		.append("AND st.cod_tipbien = a.cod_tipbien ")
		.append("AND st.num_verreg = a.num_verreg  ")
		.append("AND st.num_present= a.num_present  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND a.ind_condicion = ?ind_condiciona  ");// 1 --presentacion
	 		params.addProperty("ind_condiciona", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND a.cod_estado = ?cCodEstadoBajab ");
	 		params.addProperty("cCodEstadoBajab", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND a.ind_del = ?cIndDelActivob  ");
	 		params.addProperty("cIndDelActivob", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND b.num_ruc = a.num_ruc ")
		.append("AND b.cod_tipbien = a.cod_tipbien ")
		.append("AND b.num_verreg = a.num_verreg  ")
		.append("AND b.num_inscab = a.num_inscab ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND b.ind_condicion = ?ind_condicionb  ");//1 --producto
	 		params.addProperty("ind_condicionb", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND b.cod_estado = ?cCodEstadoBajac ");
	 		params.addProperty("cCodEstadoBajac", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND b.ind_del = ?cIndDelActivoc ");
	 		params.addProperty("cIndDelActivoc", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND st.cnt_stock_actual < 0  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND st.ind_del = ?cIndDelActivod ");
	 		params.addProperty("cIndDelActivod", resumenStockEstablecBean.getIndDel());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumRuc())) {
			builder.append("AND st.num_ruc = ?numDocumento  ");
	 		params.addProperty("numDocumento", resumenStockEstablecBean.getNumRuc());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumVersionRegistro())) {
			builder.append("AND st.num_verreg = ?num_verreg  ");
	 		params.addProperty("num_verreg", resumenStockEstablecBean.getNumVersionRegistro());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodTipobien())) {
			builder.append("AND st.cod_tipbien = ?cod_tipbien ");
	 		params.addProperty("cod_tipbien", resumenStockEstablecBean.getCodTipobien());
		}
		 						
	 	logger.debug(String.format("JPAT5641RStockEstabDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ResumenStockEstablec.class);
	}
	
	@Override
	public List<ResumenStockEstablec> listarStockNegativoBaja(ResumenStockEstablecBean resumenStockEstablecBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		String estadoBf="";
		
		/*
		 * -	#cCodEstadoBaja#= c�digo del estado del usuario 03 -Baja)
-	#ind_condicion #= condici�n de los presentaciones y establecimientos.
-	#numDocumento# = n�mero de RUC del usuario
-	#cod_tipbien# = c�digo del tipo de bien �01�
-	#num_verreg#= n�mero de versi�n del usuario 
-	ind_condicion= indicador de condici�n del �tem 
-	#cIndDelActivo#= indicador de registro no eliminado

		 */
		
		builder.append("SELECT ")
		.append("st.num_estab as numEstablecimiento, ")
		.append("c.num_version AS numVersionEstab, ")
		.append("a.num_present as numPresentacion, ")
		.append("a.cod_presen as codPresen, ")
		.append("b.num_inscab as numInscab, ")
		.append("b.num_version AS numVersionCabInsumo")//num_version_ins
		.append("b.cod_insumo as codInsumo, ")
		.append("b.num_orden as numOrden, ")
		.append("b.cod_tipprod as codTipProd, ")
		.append("b.cod_um as codUm, ")
		.append("st.num_periodo as numPeriodo, ")
		.append("st.cnt_stock_actual as cantidadStockActual, ")
		.append("st.num_reposicion as numReposicion, ")
		.append("c.cod_ubigeo as codUbigeo, ") // codUbigeoEstablecimiento
		.append("b.des_nomprod as desNomProd, ") // desNombreProducto
		.append("b.des_nomcomprod as desNomComProd,  ")// desNombreComercial
		.append("a.cod_uni_com as codUnidadComercial, ")//cod_und_com_prest
		.append("a.cnt_unifisica as cantidadUnidadFisica, ")
		.append("a.cod_uni_fis as codUnidadFiscal, ")
		.append("b.cod_bienfisca as codBienFisca, ")
		.append("b.num_version as numVersion, ")
		.append("NVL(a.cnt_net_prod,0) AS cntNetProd") // cntnetaPresentacion
		.append("NVL(st.cnt_ing_est,0) AS cntIngEst")//cnt_ingres_preset_estable
		.append("(NVL(a.cnt_net_prod,0) * NVL(st.cnt_stock_actual,0)) AS cntNeteada, ")
		.append("NVL(b.por_max_ins,0) AS porMax")//por_max_ins, ")
		.append("NVL(b.por_min_ins,0) AS porMin")//por_min_ins, ")
		.append("st.num_stock as numStock, ")
		.append("st.num_confirma as numConfirma, ")
		.append("st.cnt_sal_est as cantidadSalidaEstablec")
		.append("a.num_verreg as numVersionRegistroBfPresenta ")
		.append("FROM t5641rstockestab st, t5070bfestab c, t5074bfpresenta a, t5066bfcabinsumo b  ")
		.append("WHERE st.num_ruc= c.num_ruc  ")
		.append("AND st.num_verreg= c.num_verreg  ")
		.append("AND st.num_estab= c.num_estab  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND c.ind_condicion = ?ind_condicionc ");//1--establecimiento
	 		params.addProperty("ind_condicionc", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND c.cod_estado = ?cCodEstadoBajaa ");
	 		params.addProperty("cCodEstadoBajaa", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND c.ind_del = ?cIndDelActivoa ");
	 		params.addProperty("cIndDelActivoa", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND st.num_ruc = a.num_ruc ")
		.append("AND st.cod_tipbien = a.cod_tipbien ")
		.append("AND st.num_verreg = a.num_verreg  ")
		.append("AND st.num_present= a.num_present  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND a.ind_condicion = ?ind_condiciona  ");// 1 --presentacion
	 		params.addProperty("ind_condiciona", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND a.cod_estado = ?cCodEstadoBajab ");
	 		params.addProperty("cCodEstadoBajab", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND a.ind_del = ?cIndDelActivob  ");
	 		params.addProperty("cIndDelActivob", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND b.num_ruc = a.num_ruc ")
		.append("AND b.cod_tipbien = a.cod_tipbien ")
		.append("AND b.num_verreg = a.num_verreg  ")
		.append("AND b.num_inscab = a.num_inscab ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND b.ind_condicion = ?ind_condicionb  ");//1 --producto
	 		params.addProperty("ind_condicionb", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND b.cod_estado = ?cCodEstadoBajac ");
	 		params.addProperty("cCodEstadoBajac", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND b.ind_del = ?cIndDelActivoc ");
	 		params.addProperty("cIndDelActivoc", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND st.cnt_stock_actual < 0  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND st.ind_del = ?cIndDelActivod ");
	 		params.addProperty("cIndDelActivod", resumenStockEstablecBean.getIndDel());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumRuc())) {
			builder.append("AND st.num_ruc = ?numDocumento  ");
	 		params.addProperty("numDocumento", resumenStockEstablecBean.getNumRuc());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumVersionRegistro())) {
			builder.append("AND st.num_verreg = ?num_verreg  ");
	 		params.addProperty("num_verreg", resumenStockEstablecBean.getNumVersionRegistro());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodTipobien())) {
			builder.append("AND st.cod_tipbien = ?cod_tipbien ");
	 		params.addProperty("cod_tipbien", resumenStockEstablecBean.getCodTipobien());
		}
		 						
	 	logger.debug(String.format("JPAT5641RStockEstabDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ResumenStockEstablec.class);
	}
	
	@Override
	public List<ResumenStockEstablec> verificarSctokNegativoBaja(ResumenStockEstablecBean resumenStockEstablecBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		String estadoBf="";
		
		/*
		 * -	#cCodEstadoBaja#= c�digo del estado del usuario 03 -Baja)
			-	#ind_condicion #= condici�n de los presentaciones y establecimientos.
			-	#numDocumento# = n�mero de RUC del usuario
			-	#cod_tipbien# = c�digo del tipo de bien �01�
			-	#num_verreg#= n�mero de versi�n del usuario 
			-	ind_condicion= indicador de condici�n del �tem 
			-	#cIndDelActivo#= indicador de registro no eliminado
		 */
		
		builder.append("SELECT count(1) as cantidadStock")
		.append("FROM t5641rstockestab st, t5070bfestab c, t5074bfpresenta a, t5066bfcabinsumo b  ")
		.append("WHERE st.num_ruc= c.num_ruc  ")
		.append("AND st.num_verreg= c.num_verreg  ")
		.append("AND st.num_estab= c.num_estab  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND c.ind_condicion = ?ind_condicionc ");//1--establecimiento
	 		params.addProperty("ind_condicionc", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND c.cod_estado = ?cCodEstadoBajaa ");
	 		params.addProperty("cCodEstadoBajaa", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND c.ind_del = ?cIndDelActivoa ");
	 		params.addProperty("cIndDelActivoa", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND st.num_ruc = a.num_ruc ")
		.append("AND st.cod_tipbien = a.cod_tipbien ")
		.append("AND st.num_verreg = a.num_verreg  ")
		.append("AND st.num_present= a.num_present  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND a.ind_condicion = ?ind_condiciona  ");// 1 --presentacion
	 		params.addProperty("ind_condiciona", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND a.cod_estado = ?cCodEstadoBajab ");
	 		params.addProperty("cCodEstadoBajab", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND a.ind_del = ?cIndDelActivob  ");
	 		params.addProperty("cIndDelActivob", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND b.num_ruc = a.num_ruc ")
		.append("AND b.cod_tipbien = a.cod_tipbien ")
		.append("AND b.num_verreg = a.num_verreg  ")
		.append("AND b.num_inscab = a.num_inscab ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndCondicion())) {
			builder.append("AND b.ind_condicion = ?ind_condicionb  ");//1 --producto
	 		params.addProperty("ind_condicionb", resumenStockEstablecBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodEstadoItem())) {
			builder.append("AND b.cod_estado = ?cCodEstadoBajac ");
	 		params.addProperty("cCodEstadoBajac", resumenStockEstablecBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND b.ind_del = ?cIndDelActivoc ");
	 		params.addProperty("cIndDelActivoc", resumenStockEstablecBean.getIndDel());
		}
		
		builder.append("AND st.cnt_stock_actual < 0  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getIndDel())) {
			builder.append("AND st.ind_del = ?cIndDelActivod ");
	 		params.addProperty("cIndDelActivod", resumenStockEstablecBean.getIndDel());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumRuc())) {
			builder.append("AND st.num_ruc = ?numDocumento  ");
	 		params.addProperty("numDocumento", resumenStockEstablecBean.getNumRuc());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumVersionRegistro())) {
			builder.append("AND st.num_verreg = ?num_verreg  ");
	 		params.addProperty("num_verreg", resumenStockEstablecBean.getNumVersionRegistro());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getCodTipobien())) {
			builder.append("AND st.cod_tipbien = ?cod_tipbien ");
	 		params.addProperty("cod_tipbien", resumenStockEstablecBean.getCodTipobien());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumPresentacion())) {
			builder.append("and st.num_present = ?num_present ");
	 		params.addProperty("num_present", resumenStockEstablecBean.getNumPresentacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenStockEstablecBean.getNumEstablecimiento() )) {
			builder.append("and st.num_estab  = ?num_estab ");
	 		params.addProperty("num_estab", resumenStockEstablecBean.getNumEstablecimiento());
		}
		
		
	 	logger.debug(String.format("JPAT5641RStockEstabDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ResumenStockEstablec.class);
	}
}
