package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10425TipInconProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10425TipInconProgDAO extends AbstractDAOImpl<TipoInconsistenciaPrograma, Integer> implements T10425TipInconProgDAO {

	public JPAT10425TipInconProgDAO() {
		super(TipoInconsistenciaPrograma.class);
	}

}
