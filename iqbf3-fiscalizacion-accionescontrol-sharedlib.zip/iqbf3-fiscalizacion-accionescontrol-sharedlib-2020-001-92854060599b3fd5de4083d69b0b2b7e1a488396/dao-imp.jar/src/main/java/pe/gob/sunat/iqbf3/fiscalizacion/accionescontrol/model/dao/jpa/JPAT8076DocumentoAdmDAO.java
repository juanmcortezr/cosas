package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAdm;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8076DocumentoAdmDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT8076DocumentoAdmDAO extends AbstractDAOImpl<DocumentoAdm, Long> implements T8076DocumentoAdmDAO {

	public JPAT8076DocumentoAdmDAO() {
		super(DocumentoAdm.class);
	}

}
