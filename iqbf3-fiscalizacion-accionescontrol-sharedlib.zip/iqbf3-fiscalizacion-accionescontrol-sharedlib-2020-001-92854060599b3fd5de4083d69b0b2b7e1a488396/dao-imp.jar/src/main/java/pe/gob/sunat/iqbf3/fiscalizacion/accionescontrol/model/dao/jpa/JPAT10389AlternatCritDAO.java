package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AlternativaCriterio;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10389AlternatCritDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10389AlternatCritDAO extends AbstractDAOImpl<AlternativaCriterio, Long> implements T10389AlternatCritDAO {

	public JPAT10389AlternatCritDAO(){
		super(AlternativaCriterio.class);
	}
	
}
