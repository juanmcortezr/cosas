package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.Arrays;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AgentePuestosCtrl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10297AgenteCtrolDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10297AgenteCtrolDAO extends AbstractDAOImpl<AgentePuestosCtrl, Long> implements T10297AgenteCtrolDAO  {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10420ProgramacionDAO.class);

	public JPAT10297AgenteCtrolDAO() {
		super(AgentePuestosCtrl.class);
	}

	@Override
	public List<AgentePuestosCtrl> listarAgentePuesto(String codPuesto, String codRol) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10297AgenteCtrolDAO - listarAgentePuesto");

		String query = "SELECT num_regpers as numRegistroPersonal, cod_dep as codDep, cod_puesto as codPuesto, cod_uuoo as codUnidadOrganica, " + 
				"cod_rol as codRol, cod_estado as codEstado, des_sustento as desSustento, fec_reg as fecRegistro" +
					  "FROM t10297agentectrol WHERE cod_puesto = ?codPuesto and cod_rol = ?codRol";
		PropertyParams params = new PropertyParams();
		params.addProperty("codPuesto", codPuesto);
		params.addProperty("codRol", codRol);
		
		return this.findQueryNative(query, Arrays.asList(codPuesto), AccionesControlConstantes.DATASOURCE_DCSICOBF, AgentePuestosCtrl.class);
		
	}
	
	
	
}
