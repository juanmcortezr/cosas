package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.AsignaUsuarioAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaUsuarioAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10394AsignaUsuAccDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10394AsignaUsuAccDAO extends AbstractDAOImpl<AsignaUsuarioAccion, Long> implements T10394AsignaUsuAccDAO  {
	
	private static final Logger logger = LoggerFactory.getLogger(JPAT10421SolicProgDAO.class);

	public JPAT10394AsignaUsuAccDAO(){
		super(AsignaUsuarioAccion.class);
	}

	@Override
	public List<AsignaUsuarioAccion> listarCargaAuditorPrincipal(AsignaUsuarioAccion filtro) {
		
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT A.cod_pers as codPers, count(*) as cntCarga ")
			   .append("FROM t10394asignausuacc A LEFT JOIN t10428usuarioprog U ON A.num_usu_program = U.num_usu_program ")
			   .append("LEFT JOIN t10415ordenaccion O ON A.num_usu_program = O.num_usu_program WHERE 1=1 ");
		if(!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())){
			builder.append(" AND U.num_programacion = ?numProgramacion ");
			params.addProperty("numProgramacion", filtro.getNumProgramacion());
			
		}
		
		builder.append(" AND A.cod_cargo = ?codCargo ");
		params.addProperty("codCargo", AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		if(!MaestrosUtilidades.isEmpty(filtro.getCodTipIntControl())){
			builder.append(" AND U.cod_tip_interv = ?codTipIntControl ");
			params.addProperty("codTipIntControl", filtro.getCodTipIntControl());			
		}

		if(!MaestrosUtilidades.isEmpty(filtro.getIndDel())){
			builder.append(" AND A.ind_del = ?indDel AND U.ind_del = ?indDel ");
			params.addProperty("indDel", filtro.getIndDel());				
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getIndEst())){
			builder.append(" AND A.ind_est = ?indEst AND U.ind_est = ?indEst ");
			params.addProperty("indEst", filtro.getIndEst());				
		}

		builder.append(" AND U.cod_tip_interv = ?codTipIntControl ");
		params.addProperty("codTipIntControl", filtro.getCodTipIntControl());
		
		//builder.append(" AND O.cod_est_orden = ?estadoOrden ");
		//params.addProperty("estadoOrden", filtro.getEstadoOrden());

		if(!MaestrosUtilidades.isEmpty(filtro.getEstadoOrden())){
			builder.append(" AND O.cod_est_orden IN ?estadoOrden  GROUP BY 1 ");
			params.addPropertyOperador("estadoOrden", filtro.getEstadoOrden(), "IN");
			//params.addProperty("estadoOrden", filtro.getEstadoOrden());
		}

	
		if (!MaestrosUtilidades.isEmpty(filtro.getCodAuditor())) {
			builder.append(" AND A.cod_pers = ?codAuditor  GROUP BY A.cod_pers");
			params.addProperty("codAuditor", filtro.getCodAuditor());
		}
		//builder.append("  GROUP BY 1");
		
		System.out.println(String.format("JPAT10394AsignaUsuAccDAO: query => %s", builder.toString()));
		logger.debug(String.format("JPAT10394AsignaUsuAccDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, AsignaUsuarioAccion.class);
	
	}

	@Override
	public List<AsignaUsuarioAccion> obtenerAsigUsuarioAccion(AsignaUsuarioAccion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10394AsignaUsuAccDAO - obtenerAsigUsuarioAccion");
				
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT num_asig_accion as numAsignacionAccion, num_usu_program as numUsuarioPrograma, ind_tip_asignacion as indTipAsignacion, ")
			   .append("cod_cargo as codCargo, cod_pers as codPers, fec_ini_asignacion as fecInicioAsignacion, fec_fin_asignacion as fecFinAsignacion ")
			   .append("FROM t10394asignausuacc ")
			   .append("WHERE num_usu_program = ?numUsuarioPrograma AND cod_cargo = ?codCargo ");
			
		params.addProperty("numUsuarioPrograma", filtro.getNumUsuarioPrograma());
		params.addProperty("codCargo", AccionesControlConstantes.COD_CARGO_AUDITOR_PRINCIPAL);
		
		builder.append("AND ind_del = ?indDel");
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);


		
		logger.debug(String.format("JPAT10394AsignaUsuAccDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, AsignaUsuarioAccion.class);
	}
	
	@Override
	public List<AsignaUsuarioAccion> insertarAsigUsuarioAccion(AsignaUsuarioAccion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10394AsignaUsuAccDAO - insertarAsigUsuarioAccion");
		
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("INSERT INTO t10394asignausuacc (num_asig_accion as numAsignacionAccion, num_usu_program as numUsuarioPrograma, ind_tip_asignacion as indTipAsignacion, ")     
			   .append( "cod_cargo as codCargo, cod_pers as codAuditor, fec_ini_asignacion as fecInicioAsignacion, fec_fin_asignacion as fecFinAsignacion, ")
			   .append( "cod_usucrea as codUsuCrea, dir_ipusucrea as dirIpUsuCrea, ind_del as indDel, ind_est as indEst ) ")
			   .append(" VALUES ( ?numAsignacionAccion, ?numUsuarioPrograma, ?indTipAsignacion, ?codCargo, ?codAuditor, ?fecInicioAsignacion, ?fecFinAsignacion, ")
			   .append("  ?codUsuCrea, ?dirIpUsuCrea, ?indDel, ?indEst");
		params.addProperty("numAsignacionAccion", filtro.getNumAsignacionAccion());
		params.addProperty("numUsuarioPrograma", filtro.getNumUsuarioPrograma());
		params.addProperty("indTipAsignacion", filtro.getIndTipAsignacion());
		params.addProperty("codCargo", filtro.getCodCargo());
		params.addProperty("codAuditor", filtro.getCodAuditor());
		params.addProperty("fecInicioAsignacion", filtro.getFecInicioAsignacion());
		params.addProperty("fecFinAsignacion", filtro.getFecFinAsignacion());
		params.addProperty("codUsuCrea", filtro.getCodUsuCrea());
		params.addProperty("dirIpusucrea", filtro.getDirIpusucrea());
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		logger.debug(String.format("JPAT10394AsignaUsuAccDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10394AsignaUsuAccDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				AsignaUsuarioAccion.class);
	}

	@Override
	public List<AsignaUsuarioAccion> listarCargaAuditorPrincipal(AsignaUsuarioAccion parametros,
			ArrayList<String> estadoOrden, String numProgramacion, String codTipIntControl,
			String codTipIntFiscalizacion) {
		// TODO Auto-generated method stub
		return null;
	}



}
