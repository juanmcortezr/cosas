package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActividadPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10388ActividProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10388ActividProgDAO extends AbstractDAOImpl<ActividadPrograma, Integer> implements T10388ActividProgDAO {

	public JPAT10388ActividProgDAO() {
		super(ActividadPrograma.class);
	}

}
