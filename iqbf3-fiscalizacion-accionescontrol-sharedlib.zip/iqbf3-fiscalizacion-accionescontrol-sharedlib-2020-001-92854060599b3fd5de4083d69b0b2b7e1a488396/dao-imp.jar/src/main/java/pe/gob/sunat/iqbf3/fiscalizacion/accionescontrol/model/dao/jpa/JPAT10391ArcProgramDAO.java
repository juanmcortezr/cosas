package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.Arrays;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10391ArcProgramDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;

@Stateless
public class JPAT10391ArcProgramDAO extends AbstractDAOImpl<ArchivoProgramacion, Integer> implements T10391ArcProgramDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10391ArcProgramDAO.class);

	public JPAT10391ArcProgramDAO() {
		super(ArchivoProgramacion.class);
	}

	@Override
	public List<ArchivoAcciones> listarArchivosProgramacion(Long numSolicitud, String tipo) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10391ArcProgramDAO - listarArchivosProgramacion");
		StringBuilder query = new StringBuilder("SELECT ARC.NUM_ARC, ARC.NOM_ARC, ARC.COD_TIP_ARC, ARC.DES_MIME_TYPE FROM T10391ARCPROGRAM PROG ")
				.append("INNER JOIN T10445ARCACF ARC ON PROG.NUM_ARC=ARC.NUM_ARC WHERE PROG.NUM_PROGRAMACION=?1 AND ARC.COD_TIP_ARC=?2 ")
				.append("AND ARC.IND_DEL='0' AND PROG.IND_DEL='0' AND PROG.IND_EST='1' AND ARC.IND_EST='1'");
		return this.findQueryNative(query.toString(), Arrays.asList(numSolicitud, tipo), AccionesControlConstantes.DATASOURCE_DCSICOBF, ArchivoAcciones.class);
	}

}
