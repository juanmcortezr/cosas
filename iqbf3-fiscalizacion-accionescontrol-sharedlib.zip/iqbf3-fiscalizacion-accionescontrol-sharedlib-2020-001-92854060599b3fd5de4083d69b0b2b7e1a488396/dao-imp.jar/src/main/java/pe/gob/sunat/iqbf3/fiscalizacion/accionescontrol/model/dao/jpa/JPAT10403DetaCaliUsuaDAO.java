package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DetalleCalificacionUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10403DetaCaliUsuaDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10403DetaCaliUsuaDAO extends AbstractDAOImpl<DetalleCalificacionUsuario, Long> implements T10403DetaCaliUsuaDAO  {

	public JPAT10403DetaCaliUsuaDAO(){
		super(DetalleCalificacionUsuario.class);
	}
	
}
