package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MedioProbatorioUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10412MedioProbUsuDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10412MedioProbUsuDAO extends AbstractDAOImpl<MedioProbatorioUsuario, Long> implements T10412MedioProbUsuDAO{

	public JPAT10412MedioProbUsuDAO() {
		super(MedioProbatorioUsuario.class);
	}

}
