package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ConfirmacionGreBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CabezeraCpe;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ConfirmacionGre;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5257ConfirDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT5257ConfirDAO extends AbstractDAOImpl<ConfirmacionGre, Long> implements T5257ConfirDAO  {
	
	private static final Logger logger = LoggerFactory.getLogger(JPAT5257ConfirDAO.class);
	
	public JPAT5257ConfirDAO(){
		super(ConfirmacionGre.class);
	}
	
	
	@Override
	public List<ConfirmacionGre> verificarGreConfirmada(ConfirmacionGreBean confirmacionGreBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("select count(*) as cantidad ")
		.append("from T5257confir b  ")
		.append("where 1=1 ");
		
		if (!MaestrosUtilidades.isEmpty(confirmacionGreBean.getNumRuc())) {
			builder.append("and b.num_ruc = ?num_ruc_remitente ");
			params.addProperty("num_ruc_remitente", confirmacionGreBean.getNumRuc());
		}		
		
		if (!MaestrosUtilidades.isEmpty(confirmacionGreBean.getCodCpe())) {
			builder.append("AND b.cod_cpe = ?cod_cpe ");
			params.addProperty("cod_cpe", confirmacionGreBean.getCodCpe());
		}
		
		if (!MaestrosUtilidades.isEmpty(confirmacionGreBean.getNumSerieCpe())) {
			builder.append("AND b.num_serie_cpe = ?num_serie_cpe ");
			params.addProperty("num_serie_cpe", confirmacionGreBean.getNumSerieCpe());
		}
		
		if (!MaestrosUtilidades.isEmpty(confirmacionGreBean.getNumCpe())) {
			builder.append("AND b.num_cpe  = ?num_cpe ");
			params.addProperty("num_cpe", confirmacionGreBean.getNumCpe());
		}
		
		if (!MaestrosUtilidades.isEmpty(confirmacionGreBean.getNumRucConfirmacion())) {
			builder.append("AND b.num_ruc_confir = ?numeroDocumentoIdent ");
			params.addProperty("numeroDocumentoIdent", confirmacionGreBean.getNumRucConfirmacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(confirmacionGreBean.getCodTipo())) {
			builder.append("AND b.cod_tipo= ?cod_tipo_confirmacion "); //--02   --destinatario , 01 � Transportista 
			params.addProperty("cod_tipo_confirmacion", confirmacionGreBean.getCodTipo());
		}
		
	 	logger.debug(String.format("JPAT5257ConfirDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ConfirmacionGre.class);
	}
}
