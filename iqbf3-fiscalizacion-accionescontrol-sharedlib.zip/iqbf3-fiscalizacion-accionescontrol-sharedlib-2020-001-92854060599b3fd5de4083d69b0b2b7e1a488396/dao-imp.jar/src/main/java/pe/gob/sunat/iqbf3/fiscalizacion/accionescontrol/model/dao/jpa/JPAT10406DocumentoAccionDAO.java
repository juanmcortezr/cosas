package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10406DocumentoAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10406DocumentoAccionDAO  extends AbstractDAOImpl<DocumentoAccion, Long> implements T10406DocumentoAccionDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10406DocumentoAccionDAO.class);
	
	public JPAT10406DocumentoAccionDAO() {
		super(DocumentoAccion.class);
	}
	
	@Override
	public List<DocumentoAccion> listarDocumentoPendienteNotificacion(DocumentoAccionBean filtro){
																		 
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
				
		builder.append("SELECT ")
		.append("A.num_doc_accion as numDocumentoAccion, ")
		.append("A.num_usu_program as numUsuarioPrograma, ")
		.append("A.cod_clase as codClase, ")
		.append("A.ind_origen as indOrigen, ")
		.append("A.cod_tip_doc as codTipoDocumento, ")
		.append("A.num_doc_accion as numDocumentoAccion, ")
		.append("A.ann_doc as annDoc, ")
		.append("A.num_correl_doc as numCorrelDoc, ")
		.append("A.cod_uuoo_doc as codUuooDoc, ")
		.append("A.num_documento as numDocumento, ")
		.append("A.cod_est_doc as codEstadoDocumento, ")
		.append("A.fec_emision as fecEmision, ")
		.append("A.fec_notificacion as fecNotificacion, ")
		.append("A.num_pedido as numPedido, ")
		.append("A.num_arc  as numArc, ")
		.append("B.num_programacion as numProgramacion, ")
		.append("C.num_plazo_verif as numPlazoVerif, ")
		.append("A.num_id_doc as numIdDoc ")
		.append("from t10406documeaccion A INNER JOIN t10428usuarioprog B ")
		.append("ON A.num_usu_program= B.num_usu_program ") 
		.append("INNER JOIN t10420programacion C ")
		.append("ON B.num_programacion = C.num_programacion ");
		
		builder.append("where 1=1 ");
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoDocumento())) {
			builder.append("and A.cod_est_doc = ?cod_est_doc  ");// '02' --- Pendiente de notificaci�n
			params.addProperty("cod_est_doc", filtro.getCodEstadoDocumento());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getIndOrigen())) {
			builder.append("and A.ind_origen = ?ind_origen "); // 1 --- eletronico
			params.addProperty("ind_origen", filtro.getIndOrigen());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getIndDel())) {
			builder.append("and A.ind_del= ?ind_del "); // 0 
			params.addProperty("ind_del", filtro.getIndDel());
		}
	
		logger.debug(String.format("JPAT10406DocumentoAccionDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DocumentoAccion.class);
					   
	}

	public int maximoDocumentoEletronico(DocumentoAccionBean filtro){

		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();

		builder.append("SELECT max(d.num_correl) + 1 ")
		.append("FROM t10406documeaccion d ")
		.append("where 1=1 ")
		.append("WHERE d.cod_uuoo = ?cod_uuoo ")
		.append("and d.ann_doc = ?ann_doc ")
		.append("and d.ind_origen = ?ind_origen")
		.append("and d.ind_del = ?ind_del");
		
		params.addProperty("cod_uuoo", filtro.getCodUnidadOrganica());
		params.addProperty("ann_doc", filtro.getAnnDoc());
		params.addProperty("ind_origen", filtro.getIndOrigen());
		params.addProperty("ind_del", filtro.getIndDel());

		logger.debug(String.format("JPAT10406DocumentoAccionDAO: query => %s", builder.toString()));

		List<DocumentoAccion> listaDocumentoAccion = this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DocumentoAccion.class);
		
		if(!listaDocumentoAccion.isEmpty()){
			return listaDocumentoAccion.get(0).getNumCorrelDoc();
		}else{
			return 0;
		}
	}	
}
