package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaUsuarioAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DistribucionGrupo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10392AsignProgramDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10392AsignProgramDAO extends AbstractDAOImpl<AsignaProgramacion, Long> implements T10392AsignProgramDAO  {
	
	private static final Logger logger = LoggerFactory.getLogger(JPAT10421SolicProgDAO.class);

	public JPAT10392AsignProgramDAO(){
		super(AsignaProgramacion.class);
	}

	@Override
	public List<AsignaProgramacion> listarAsignaProg(AsignaProgramacion filtro) {
		
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT num_asignacion as numAsignacion, num_programacion as numProgramacion, ind_tip_asignacion as indTipAsignacion, ")
			   .append("cod_pers as codProgramador, fec_ini_asignacion as fecInicioAsignacion, fec_fin_asignacion as fecFinAsignacion, ")
			   .append("des_reasignacion as desReasignacion FROM t10392asignprogram WHERE 1=1 ");
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
		builder.append(" AND num_programacion = ?numProgramacion ");
		params.addProperty("numProgramacion", filtro.getNumProgramacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getIndTipAsignacion())) {
			builder.append(" AND ind_tip_asignacion = ?indTipAsignacion ");
			params.addProperty("indTipAsignacion", filtro.getIndTipAsignacion());
		}
		

		System.out.println(String.format("JPAT10392AsignProgramDAO: query => %s", builder.toString()));
		logger.debug(String.format("JPAT10392AsignProgramDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, AsignaProgramacion.class);
	
		
		
	}

	@Override
	public List<AsignaProgramacion> actualizarAsignaProg(AsignaProgramacion formulario) {
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("UPDATE t10392asignprogram SET ")
			   .append("num_programacion = ?numProgramacion, ind_tip_asignacion = ?indTipAsignacion, cod_pers = ?codProgramador, ")
			   .append("fec_ini_asignacion = ?fecInicioAsignacion, fec_fin_asignacion = ?fecFinAsignacion, des_reasignacion = ?desReasignacion, ")
			   .append("cod_usumodif = ?codUsuModif, dir_ipusumodif = ?dirIpusumodif, fec_modif = ?fecModif WHERE 1=1 ");
		
		if (!MaestrosUtilidades.isEmpty(formulario.getNumProgramacion())) {
		builder.append(" AND num_asignacion = ?numAsignacion ");
		params.addProperty("numAsignacion", formulario.getNumAsignacion());
		}
		
		params.addProperty("numProgramacion", formulario.getNumProgramacion());

		
		logger.debug(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT8303DistriGrupoDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, AsignaProgramacion.class);
	
	}

	@Override
	public AsignaProgramacion ultimoAsignaProg(AsignaProgramacion filtro) {
		PropertyParams params = new PropertyParams();
		params.addProperty("numProgramacion", filtro.getNumProgramacion());
		params.addProperty("indTipAsignacion", filtro.getIndTipAsignacion());
		params.addPropertyOperador("fecInicioAsignacion", "(SELECT MAX(reg.fecInicioAsignacion)" + 
				"FROM AsignaProgramacion reg " + 
				"WHERE reg.numProgramacion = a.numProgramacion " + 
				"AND reg.indTipAsignacion = a.indTipAsignacion " + 
				"AND reg.indDel = a.indDel) ", "=", false);
		
		List<AsignaProgramacion> lista = this.findByProperties(params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			return lista.get(0);
		}
		return null;
	}

	/*@Override
	public List<AsignaProgramacion> insertarAsignaProg(AsignaProgramacion formulario) {
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("INSERT INTO t10392asignprogram ( ")
		.append(" num_asignacion, ")
		.append(" num_programacion, ")
		.append(" ind_tip_asignacion, ")
		.append(" cod_pers, ")
		.append(" fec_ini_asignacion, ")
		.append(" fec_fin_asignacion, ")
		.append(" cod_usucrea, ")
		.append(" dir_ipusucrea ) ")
		.append(" VALUES ( ")
		.append(" ?numAsignacion, ")
		.append(" ?numProgramacion, ")
		.append(" ?indTipAsignacion, ")
		.append(" ?codProgramador, ")
		.append(" ?fecInicioAsignacion, ")
		.append(" ?fecFinAsignacion, ")
		.append(" ?codUsuCrea, ")
		.append(" ?dirIpusucrea ) ");
		
		if (!MaestrosUtilidades.isEmpty(formulario.getNumAsignacion())) {
			params.addProperty("numAsignacion", formulario.getNumAsignacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(formulario.getNumProgramacion())) {
			params.addProperty("numProgramacion", formulario.getNumProgramacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(formulario.getIndTipAsignacion())) {
			params.addProperty("indTipAsignacion", formulario.getIndTipAsignacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(formulario.getCodProgramador())) {
			params.addProperty("codProgramador", formulario.getIndTipAsignacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(formulario.getFecInicioAsignacion())) {
			params.addProperty("fecInicioAsignacion", formulario.getFecInicioAsignacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(formulario.getFecFinAsignacion())) {
			params.addProperty("fecFinAsignacion", formulario.getFecFinAsignacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(formulario.getCodUsuCrea())) {
			params.addProperty("codUsuCrea", formulario.getCodUsuCrea());
		}
		
		if (!MaestrosUtilidades.isEmpty(formulario.getDirIpusucrea())) {
			params.addProperty("dirIpusucrea", formulario.getDirIpusucrea());
		}
		
		logger.debug(String.format("JPAT10415OrdenAccionDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DocumentoAccion.class);
	
		
	}*/

}

