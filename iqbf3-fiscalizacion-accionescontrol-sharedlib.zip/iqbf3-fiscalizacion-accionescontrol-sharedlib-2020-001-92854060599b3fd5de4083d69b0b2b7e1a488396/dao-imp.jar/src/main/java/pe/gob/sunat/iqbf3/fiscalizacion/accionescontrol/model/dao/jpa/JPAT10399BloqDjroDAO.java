package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BloqueoDjro;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10399BloqDjroDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10399BloqDjroDAO extends AbstractDAOImpl<BloqueoDjro, Long> implements T10399BloqDjroDAO  {

	public JPAT10399BloqDjroDAO(){
		super(BloqueoDjro.class);
	}
	
}
