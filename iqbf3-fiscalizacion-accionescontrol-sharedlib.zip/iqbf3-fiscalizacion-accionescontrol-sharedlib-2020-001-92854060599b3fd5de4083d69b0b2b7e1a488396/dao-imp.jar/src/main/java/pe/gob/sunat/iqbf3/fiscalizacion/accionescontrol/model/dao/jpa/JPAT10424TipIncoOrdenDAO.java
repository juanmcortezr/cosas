package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.TipoInconsistenciaOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SuspensionOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10424TipIncoOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10424TipIncoOrdenDAO extends AbstractDAOImpl<TipoInconsistenciaOrden, Long> implements T10424TipIncoOrdenDAO{
	private static final Logger logger = LoggerFactory.getLogger(JPAT10424TipIncoOrdenDAO.class);

	public JPAT10424TipIncoOrdenDAO() {
		super(TipoInconsistenciaOrden.class);
	}

	
	
	@Override
	public List<TipoInconsistenciaOrden> listarInconsistencia(TipoInconsistenciaOrden param) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10424TipIncoOrdenDAO - listarInconsistencia");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ");
		builder.append("i.num_incon_orden as numInconsistenciaOrden,");
		builder.append("i.cod_origen as codOrigen,");
		builder.append("i.cod_tip_inconsis as codTipoInconsistencia,");
		builder.append("i.cod_resul_inconsis as codResultadoInconsistencia,");
		builder.append("i.des_sus_inconsis as desSusInconsis,");
		builder.append("i.des_otra_inconsis as desOtraInconsistencia ");
		builder.append("FROM t10424tipincoorden i ");
		builder.append("WHERE 1=1 ");
		
		
		if (!MaestrosUtilidades.isEmpty(param.getNumOrden())) {
			builder.append("AND i.num_orden = ?numOrden ");
			params.addProperty("numOrden", param.getNumOrden());
		}
		if (!MaestrosUtilidades.isEmpty(param.getIndDel())) {
			builder.append("AND i.ind_del = ?indDel ");
			params.addProperty("indDel", param.getIndDel());
		}
		if (!MaestrosUtilidades.isEmpty(param.getIndEst())) {
			builder.append("AND i.ind_est = ?indEst ");
			params.addProperty("indEst", param.getIndEst());
		}
		
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, TipoInconsistenciaOrden.class);
	}
	
	@Override
	public int actualizarInconsistenciaOtro(TipoInconsistenciaOrden model) {
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT10424TipIncoOrdenDAO - actualizarSuspension");
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
			builder.append(" UPDATE t10424tipincoorden t SET ");
			builder.append(" t.fec_modif = SYSDATE ");
			
			  
			  if(model.getNumOrden()!=null&&model.getNumOrden()>0)builder.append(" ,t.num_orden = ?2 "); 
			  if(model.getCodOrigen()!=null)builder.append(" ,t.cod_origen = ?3 ");       
			  if(model.getCodTipoInconsistencia()!=null)builder.append(" ,t.cod_tip_inconsis = ?4 ");
			  if(model.getCodResultadoInconsistencia()!=null)builder.append(" ,t.cod_resul_inconsis = ?5 ");
			  if(model.getDesSusInconsis()!=null)builder.append(" ,t.des_sus_inconsis = ?6 ");
			  if(model.getDesOtraInconsistencia()!=null)builder.append(" ,t.des_otra_inconsis = ?7 ");
			  if(!MaestrosUtilidades.isEmpty(model.getIndDel()))builder.append(" ,t.ind_del = ?8 ");
			  if(!MaestrosUtilidades.isEmpty(model.getIndEst()))builder.append(" ,t.ind_est = ?9 ");        
			  if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,t.cod_usumodif = ?10 ");
			  if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,t.dir_ipusumodif = ?11 ");
		  	
		  builder.append(" WHERE 1=1 ");
		  
		  if(model.getNumInconsistenciaOrden()!=null&&model.getNumInconsistenciaOrden()>0)builder.append(" AND t.num_incon_orden = ?1 ");
		  if(model.getNumOrden()!=null&&model.getNumOrden()>0)builder.append(" AND t.num_orden = ?2 "); 
		  
		Query query = entityManager.createNativeQuery(builder.toString());
		
				query.setParameter(1, model.getNumInconsistenciaOrden());
				query.setParameter(2, model.getNumOrden());
				query.setParameter(3, model.getCodOrigen());
				query.setParameter(4, model.getCodTipoInconsistencia());
				query.setParameter(5, model.getCodResultadoInconsistencia());
				query.setParameter(6, model.getDesSusInconsis());
				query.setParameter(7, model.getDesOtraInconsistencia());
				query.setParameter(8, model.getIndDel());
				query.setParameter(9, model.getIndEst());
				query.setParameter(10, model.getCodUsuModif());
				query.setParameter(11, model.getDirIpusumodif());
		
		
		logger.debug(String.format("JPAT10424TipIncoOrdenDAO: query => %s", builder.toString()));
		return query.executeUpdate();
	}
	
	
	@Override
	public List<TipoInconsistenciaOrdenBean> listarInconsistenciaBean(TipoInconsistenciaOrden param) {
		
	List<TipoInconsistenciaOrdenBean> result=new ArrayList<TipoInconsistenciaOrdenBean>();
	
	List<TipoInconsistenciaOrden> lstInconsistencia=listarInconsistencia(param);
	if(!MaestrosUtilidades.isEmpty(lstInconsistencia)) {
		for(TipoInconsistenciaOrden modelTemp :lstInconsistencia) {
			TipoInconsistenciaOrdenBean beanTemp=new TipoInconsistenciaOrdenBean();
			MaestrosUtilidades.copiarValoresBean(modelTemp,beanTemp);
			result.add(beanTemp);
		}
	}
	return result;
	}
	
}
