package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaGreNC;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10417ProIncoGreNCDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10417ProIncoGreNCDAO extends AbstractDAOImpl<ProgramaIncosistenciaGreNC, Long> implements T10417ProIncoGreNCDAO{

	private static final Logger logger = LoggerFactory.getLogger(JPAT10417ProIncoGreNCDAO.class);
	
	public JPAT10417ProIncoGreNCDAO() {
		super(ProgramaIncosistenciaGreNC.class);
	}

	@Override
	public List<ProgramaIncosistenciaGreNC> listarInconsistenciaGre(Long numUsuarioPrograma) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10417ProIncoGreNCDAO - listarInconsistenciaGre");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ")
		.append(" num_inco_gre as numIncoGre, ")
		.append(" num_usu_program as numUsuarioPrograma, ")
		.append(" num_ruc as numRuc, ")
		.append(" cod_cpe as codCpe, ")
		.append(" num_serie_cpe as numSerieCpe, ")
		.append(" num_cpe as numCpe, ")
		.append(" fec_emision as fecEmision ")
		.append(" FROM t10417proincogrenc ");
		
		if (!MaestrosUtilidades.isEmpty(numUsuarioPrograma)) {
			builder.append(" WHERE num_usu_program = ?numUsuarioPrograma ");
			params.addProperty("numUsuarioPrograma", numUsuarioPrograma);
		}
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ProgramaIncosistenciaGreNC.class);
	}
}
