package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienEstablecimiento;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10395BienEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10395BienEstabDAO extends AbstractDAOImpl<BienEstablecimiento, Long> implements T10395BienEstabDAO  {
	private static final Logger logger = LoggerFactory.getLogger(JPAT10395BienEstabDAO.class);
	public JPAT10395BienEstabDAO(){
		super(BienEstablecimiento.class);
	}
	
	
	@Override
	public List<BienEstablecimiento> listarBienEstablecimiento(BienEstablecimiento model){
		
		PropertyParams parmas=new PropertyParams();
		StringBuilder  builder=new StringBuilder();
		
		   builder.append(" SELECT ");
	       builder.append(" be.num_bien_estab as numBienEstablecimiento, ");
	       builder.append(" be.num_estab_orden as numEstablecimientoOrden, ");
	       builder.append(" be.cod_tip_bien as codTipoBien, ");
	       builder.append(" bf.des_bien as desBienFiscalizado , ");
	       builder.append(" be.cod_bien_fisca as codBienFiscalizado, ");
	       builder.append(" be.des_bien as desBien, ");
	       builder.append(" be.fec_stock_fisico as fecStockFisico, ");
	       builder.append(" be.hor_stock_fisico as horStockFisico, ");
	       builder.append(" be.cnt_stock_fisico as cantidadStockFisico, ");
	       builder.append(" be.cod_und_medida as codUnidadMedida ");
		   builder.append(" FROM t10395bienestab be ");
	       builder.append(" INNER JOIN t7883bienfiscal bf on bf.cod_bien=be.cod_bien_fisca ");
	       builder.append(" WHERE 1=1 ");
		
		
		if(!MaestrosUtilidades.isEmpty(model.getIndDel())) {
			builder.append(" AND be.ind_del = ?indDel ");
			parmas.addProperty("indDel", model.getIndDel());
		}
		if(!MaestrosUtilidades.isEmpty(model.getIndEst())) {
			builder.append(" AND be.ind_est = ?indEst");
			parmas.addProperty("indEst", model.getIndEst());
		}
		if(!MaestrosUtilidades.isEmpty(model.getNumEstablecimientoOrden())&&model.getNumEstablecimientoOrden()>0) {
			builder.append(" AND be.num_estab_orden = ?numEstablecimientoOrden");
			parmas.addProperty("numEstablecimientoOrden",model.getNumEstablecimientoOrden());
		}
		
		return this.findQueryNative(builder.toString(), parmas, AccionesControlConstantes.DATASOURCE_DCSICOBF,BienEstablecimiento.class);
	}
	
	@Override
	public int actualizarBienEstab(BienEstablecimiento model) {
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
		builder.append(" UPDATE t10395bienestab b SET ");
		builder.append(" b.fec_modif = SYSDATE ");
		  if(model.getNumEstablecimientoOrden()!=null&&model.getNumEstablecimientoOrden()>0)builder.append(" ,b.num_estab_orden = ?2 ");
		  if(model.getCodTipoBien()!=null)builder.append(" ,b.cod_tip_bien = ?3 ");
		  if(model.getCodBienFiscalizado()!=null)builder.append(" ,b.cod_bien_fisca = ?4 "); 
		  if(model.getDesBien()!=null)builder.append(" ,b.des_bien = ?5 ");
		  if(!MaestrosUtilidades.isEmpty(model.getFecStockFisico()))builder.append(" ,b.fec_stock_fisico = ?6 ");
		  if(!MaestrosUtilidades.isEmpty(model.getHorStockFisico()))builder.append(" ,b.hor_stock_fisico = ?7 ");
		  if(model.getCantidadStockFisico()!=null&&model.getCantidadStockFisico()>0)builder.append(" ,b.cnt_stock_fisico = ?8 ");
		  if(model.getCodUnidadMedida()!=null)builder.append(" ,b.cod_und_medida = ?9 ");
		  if(!MaestrosUtilidades.isEmpty(model.getIndDel()))builder.append(" ,b.ind_del = ?10 ");
		  if(!MaestrosUtilidades.isEmpty(model.getIndEst()))builder.append(" ,b.ind_est = ?11 ");        
		  if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,b.cod_usumodif = ?12 ");
		  if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,b.dir_ipusumodif = ?13 ");
		
		builder.append(" WHERE 1=1 ");

		if(model.getNumBienEstablecimiento()!=null&&model.getNumBienEstablecimiento()>0)builder.append(" AND b.num_bien_estab = ?1 ");
		if(model.getNumEstablecimientoOrden()!=null&&model.getNumEstablecimientoOrden()>0)builder.append(" AND b.num_estab_orden = ?2 ");
		
		Query query = entityManager.createNativeQuery(builder.toString());
		
		query.setParameter(1, model.getNumBienEstablecimiento());
		query.setParameter(2, model.getNumEstablecimientoOrden());
		query.setParameter(3, model.getCodTipoBien());
		query.setParameter(4, model.getCodBienFiscalizado());
		query.setParameter(5, model.getDesBien());
		query.setParameter(6, model.getFecStockFisico());
		query.setParameter(7, model.getHorStockFisico());
		query.setParameter(8, model.getCantidadStockFisico());
		query.setParameter(9, model.getCodUnidadMedida());
		query.setParameter(10, model.getIndDel());
		query.setParameter(11, model.getIndEst());
		query.setParameter(12, model.getCodUsuModif());
		query.setParameter(13, model.getDirIpusumodif());
		
		
		
		logger.debug(String.format("JPAT10395BienEstabDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10395BienEstabDAO: query => %s", builder.toString()));
		
		return query.executeUpdate(); 
	}
	
	
	
	@Override
	public List<BienEstablecimientoBean> listarBienEstablecimientoBean(BienEstablecimiento model){
		List<BienEstablecimientoBean> lstBean=new ArrayList<>();
		List<BienEstablecimiento> lstModel=listarBienEstablecimiento(model);
		if(!MaestrosUtilidades.isEmpty(lstModel)&&lstModel.size()>0) {
			for(BienEstablecimiento modelTemp:lstModel) {
				BienEstablecimientoBean beanTemp=new BienEstablecimientoBean();
				if(!MaestrosUtilidades.isEmpty(modelTemp.getNumBienEstablecimiento())&&modelTemp.getNumBienEstablecimiento()>0)beanTemp.setNumBienEstablecimiento(MaestrosUtilidades.toInteger(modelTemp.getNumBienEstablecimiento()));
				if(!MaestrosUtilidades.isEmpty(modelTemp.getNumEstablecimientoOrden())&&modelTemp.getNumEstablecimientoOrden()>0)beanTemp.setNumEstablecimientoOrden(MaestrosUtilidades.toInteger(modelTemp.getNumEstablecimientoOrden()));
				if(!MaestrosUtilidades.isEmpty(modelTemp.getCodTipoBien()))beanTemp.setCodTipoBien(modelTemp.getCodTipoBien());
				if(!MaestrosUtilidades.isEmpty(modelTemp.getDesBienFiscalizado()))beanTemp.setDesBienFisca(modelTemp.getDesBienFiscalizado());
				if(!MaestrosUtilidades.isEmpty(modelTemp.getCodBienFiscalizado()))beanTemp.setCodBienFiscalizado(modelTemp.getCodBienFiscalizado());
				if(!MaestrosUtilidades.isEmpty(modelTemp.getDesBien()))beanTemp.setDesBien(modelTemp.getDesBien());
				if(!MaestrosUtilidades.isEmpty(modelTemp.getFecStockFisico()))beanTemp.setFecStockFisico(MaestrosUtilidades.dateToStringDDMMYYYY(modelTemp.getFecStockFisico()));
				if(!MaestrosUtilidades.isEmpty(modelTemp.getHorStockFisico()))beanTemp.setHorStockFisico(MaestrosUtilidades.dateToStringHHMM(modelTemp.getHorStockFisico()));
				if(!MaestrosUtilidades.isEmpty(modelTemp.getCantidadStockFisico()))beanTemp.setCantidadStockFisico(modelTemp.getCantidadStockFisico());
				if(!MaestrosUtilidades.isEmpty(modelTemp.getCodUnidadMedida()))beanTemp.setCodUnidadMedida(modelTemp.getCodUnidadMedida());
				lstBean.add(beanTemp);
			}
		}
		return lstBean;
	}
	
	
	
	
}
