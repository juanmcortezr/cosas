package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.EstablecimientoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.EstablecimientoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10408EstabOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10408EstabOrdenDAO extends AbstractDAOImpl<EstablecimientoOrden, Long> implements T10408EstabOrdenDAO  {
	private static final Logger logger = LoggerFactory.getLogger(JPAT10408EstabOrdenDAO.class);

	public JPAT10408EstabOrdenDAO(){
		super(EstablecimientoOrden.class);
	}
	
	@Override
	public List<EstablecimientoOrden> listarEstablecimientoOrden(EstablecimientoOrden model){
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder=new StringBuilder();
		 builder.append("SELECT ");
		  builder.append("e.num_estab_orden as numEstablecimientoOrden, ");
		  builder.append("e.num_orden as numOrden, ");
		  builder.append("e.cod_origen as codOrigen, ");
		  builder.append("e.num_otro_ruc as numOtroRuc, ");
		  builder.append("e.num_estab  as numEstablecimiento, ");
		  builder.append("e.cod_departamento as codDepartamento, ");
		  builder.append("e.cod_provincia as codProvincia, ");
		  builder.append("e.cod_distrito as  codDistrito, ");
		  builder.append("e.des_direccion as  desDireccion, ");
		  builder.append("e.num_zona as  numZona, ");
		  builder.append("e.num_xutm as  numXutm, ");
		  builder.append("e.num_yutm as  numYutm, ");
		  builder.append("e.cod_tip_docneut as codTipoDocumentoIdentif, ");
		  builder.append("e.num_sol_neu as numSolicitudNuetralizacion ");
		  builder.append(" FROM t10408estaborden e ");
		  builder.append(" WHERE 1=1 ");
		
	if(!MaestrosUtilidades.isEmpty(model.getIndDel()))
	{
		builder.append(" AND e.IND_DEL = ?indDel ");
		params.addProperty("indDel", model.getIndDel());
	}
	if(!MaestrosUtilidades.isEmpty(model.getIndEst())) {
		builder.append(" AND e.IND_EST = ?indEst ");
		params.addProperty("indEst", model.getIndEst());
	}
	if(!MaestrosUtilidades.isEmpty(model.getNumOrden())&&model.getNumOrden()>0) {
		builder.append(" AND e.NUM_ORDEN = ?numOrden ");
		params.addProperty("numOrden", model.getNumOrden());
	}
	if(!MaestrosUtilidades.isEmpty(model.getNumEstablecimientoOrden())&&model.getNumEstablecimientoOrden()>0) {
		builder.append(" AND e.num_estab_orden = ?numEstablecimientoOrden ");
		params.addProperty("numEstablecimientoOrden", model.getNumEstablecimientoOrden());
	}
				
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,EstablecimientoOrden.class);
	}
	
	@Override
	public int actualizarEstablecimiento(EstablecimientoOrden model) {
		int resultado=0;
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
		
		  builder.append(" UPDATE t10408estaborden e SET ");
		  builder.append(" e.fec_modif = SYSDATE ");
		  if(model.getNumOrden()!=null&&model.getNumOrden()>0)builder.append(" ,e.num_orden =?2 ");    
		  if(model.getCodOrigen()!=null)builder.append(" ,e.cod_origen =?3 "); 
		  if(model.getNumOtroRuc()!=null)builder.append(" ,e.num_otro_ruc =?4 "); 
		  if(model.getNumEstablecimiento()!=null &&model.getNumEstablecimiento()>0)builder.append(" ,e.num_estab =?5 ");
		  if(model.getCodDepartamento()!=null)builder.append(" ,e.cod_departamento =?6 ");
		  if(model.getCodProvincia()!=null)builder.append(" ,e.cod_provincia =?7 ");
		  if(model.getCodDistrito()!=null)builder.append(" ,e.cod_distrito =?8 ");
		  if(model.getDesDireccion()!=null)builder.append(" ,e.des_direccion =?9 ");
		  if(model.getNumZona()!=null&&model.getNumZona()>0)builder.append(" ,e.num_zona =?10 ");
		  if(model.getNumXutm()!=null&&model.getNumZona()>0)builder.append(" ,e.num_xutm =?11 "); 
		  if(model.getNumYutm()!=null&&model.getNumZona()>0)builder.append(" ,e.num_yutm =?12 "); 
		  if(model.getCodTipoDocumentoIdentif()!=null)builder.append(" ,e.cod_tip_docneut =?13 ");
		  if(model.getNumSolicitudNuetralizacion()!=null)builder.append(" ,e.num_sol_neu =?14 ");
		  if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,e.cod_usumodif = ?15");
		  if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,e.dir_ipusumodif = ?16");
		  if(model.isIndEliminar()) {
		  builder.append(" ,e.ind_del =?15 ");
		  builder.append(" ,e.ind_est =?16 ");
		  }
		  builder.append(" WHERE 1=1 ");
		  if(model.getNumEstablecimientoOrden()!=null&&model.getNumEstablecimientoOrden()>0) builder.append(" AND e.num_estab_orden = ?1 ");
		Query query = entityManager.createNativeQuery(builder.toString());
				
		query.setParameter(1, model.getNumEstablecimientoOrden());
		query.setParameter(2, model.getNumOrden());
		query.setParameter(3, model.getCodOrigen());
		query.setParameter(4, model.getNumOtroRuc());
		query.setParameter(5, model.getNumEstablecimiento());
		query.setParameter(6, model.getCodDepartamento());
		query.setParameter(7, model.getCodProvincia());
		query.setParameter(8, model.getCodDistrito());
		query.setParameter(9, model.getDesDireccion());
		query.setParameter(10, model.getNumZona());
		query.setParameter(11, model.getNumXutm());
		query.setParameter(12, model.getNumYutm());
		query.setParameter(13, model.getCodTipoDocumentoIdentif());
		query.setParameter(14, model.getNumSolicitudNuetralizacion());
		query.setParameter(15, model.getCodUsuModif());
		query.setParameter(16, model.getDirIpusumodif());
		 if(model.isIndEliminar()) {
		query.setParameter(15, MaestrosConstantes.REGISTRO_ELIMINADO);
		query.setParameter(16, MaestrosConstantes.REGISTRO_INACTIVO);
		 }
		
		logger.debug(String.format("JPAT10408EstabOrdenDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10408EstabOrdenDAO: query => %s", builder.toString()));
		
		resultado =	query.executeUpdate();
		return resultado;
	}
	
	
	@Override
	public List<EstablecimientoOrdenBean> listarEstablecimientoOrdenBean(EstablecimientoOrden model){
		List<EstablecimientoOrdenBean> resultado=new ArrayList<>();
		List<EstablecimientoOrden> lstModel=listarEstablecimientoOrden(model);
		if(!MaestrosUtilidades.isEmpty(lstModel)&&lstModel.size()>0) {
			for(EstablecimientoOrden modelTemp:lstModel) {
				EstablecimientoOrdenBean bean=new EstablecimientoOrdenBean();
				MaestrosUtilidades.copiarValoresBean(modelTemp, bean);
				resultado.add(bean);
			}
		}
		return resultado;
	}
	
	
	
}
