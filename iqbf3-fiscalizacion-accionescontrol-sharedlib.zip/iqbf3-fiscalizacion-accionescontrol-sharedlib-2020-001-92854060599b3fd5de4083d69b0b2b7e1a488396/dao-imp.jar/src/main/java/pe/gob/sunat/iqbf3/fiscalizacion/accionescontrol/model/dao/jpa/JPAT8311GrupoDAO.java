package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.Arrays;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.GrupoProceso;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8311GrupoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT8311GrupoDAO extends AbstractDAOImpl<GrupoProceso, Long> implements T8311GrupoDAO  {
	
	private static final Logger logger = LoggerFactory.getLogger(JPAT8311GrupoDAO.class);
	
	public JPAT8311GrupoDAO(){
		super(GrupoProceso.class);
	}

	@Override
	public List<GrupoProceso> listarSupervisionAuditor(String codTipoProceso) {
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT8311GrupoDAO - listarSupervisionAuditor");

		String query = "SELECT num_grupo, nom_grupo FROM t8311grupo WHERE cod_tipo_proceso = ?codTipoProceso";
		PropertyParams params = new PropertyParams();
		params.addProperty("codTipoProceso", codTipoProceso);
		
		return this.findQueryNative(query, Arrays.asList(codTipoProceso), AccionesControlConstantes.DATASOURCE_DCSICOBF, GrupoProceso.class);
	}
}
