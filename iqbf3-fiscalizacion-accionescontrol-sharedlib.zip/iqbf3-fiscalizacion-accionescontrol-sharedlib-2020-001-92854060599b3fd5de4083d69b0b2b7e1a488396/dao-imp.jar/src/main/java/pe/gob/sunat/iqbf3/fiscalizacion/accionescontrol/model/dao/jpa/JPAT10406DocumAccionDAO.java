package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10406DocumAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10406DocumAccionDAO extends AbstractDAOImpl<DocumentoAccion, Long> implements T10406DocumAccionDAO  {
	
	public JPAT10406DocumAccionDAO(){
		super(DocumentoAccion.class);
	}

}
