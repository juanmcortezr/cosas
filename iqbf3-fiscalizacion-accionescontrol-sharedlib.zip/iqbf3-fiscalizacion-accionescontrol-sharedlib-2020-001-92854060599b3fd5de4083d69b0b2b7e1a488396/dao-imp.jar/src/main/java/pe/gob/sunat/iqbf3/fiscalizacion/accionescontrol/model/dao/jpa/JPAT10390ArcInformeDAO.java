package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoInformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10390ArcInformeDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10390ArcInformeDAO extends AbstractDAOImpl<ArchivoInformeSeleccion, Long> implements T10390ArcInformeDAO  {
	
	public JPAT10390ArcInformeDAO(){
		super(ArchivoInformeSeleccion.class);
	}

}
