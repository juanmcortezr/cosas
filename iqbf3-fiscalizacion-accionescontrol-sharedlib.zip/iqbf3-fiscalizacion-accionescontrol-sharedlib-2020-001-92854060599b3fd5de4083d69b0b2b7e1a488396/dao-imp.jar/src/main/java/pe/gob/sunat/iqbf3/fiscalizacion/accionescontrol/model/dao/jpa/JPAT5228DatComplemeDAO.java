package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DataComplementGre;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5228DatComplemeDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT5228DatComplemeDAO extends AbstractDAOImpl<DataComplementGre, Long> implements T5228DatComplemeDAO  {

	public JPAT5228DatComplemeDAO(){
		super(DataComplementGre.class);
	}
	
}
