package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10428UsuarioProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10428UsuarioProgDAO extends AbstractDAOImpl<UsuarioProgramacion, Long> implements T10428UsuarioProgDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10428UsuarioProgDAO.class);
	
	public JPAT10428UsuarioProgDAO() {
		super(UsuarioProgramacion.class);
	}

	@Override
	public List<UsuarioProgramacion> verificarUsuario(UsuarioProgramacionBean usuarioProgramacionBean)
	{
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		/**
		 * #num_programacion# = n�mero de la programacion
			#cod_tip_docident# = tipo de documento del usuario
			#num_doc_ident# = n�mero de documento del usuario
			#ind_del# = indicador de eliminado
			#ind_est# = indicador de estado 
		 */

		builder.append("select num_usu_program as numUsuarioPrograma from t10428usuarioprog ")
		.append("where 1=1 ");
		
		if (!MaestrosUtilidades.isEmpty(usuarioProgramacionBean.getNumProgramacion() )) {
			builder.append("and num_programacion= ?num_programacion ");
	 		params.addProperty("num_programacion", usuarioProgramacionBean.getNumProgramacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(usuarioProgramacionBean.getCodTipoDocumentoIdentif() )) {
			builder.append("and cod_tip_docident = ?cod_tip_docident ");
	 		params.addProperty("cod_tip_docident", usuarioProgramacionBean.getCodTipoDocumentoIdentif());
		}
		
		if (!MaestrosUtilidades.isEmpty(usuarioProgramacionBean.getNumDocumentoIdentif() )) {
			builder.append("and num_doc_ident = ?num_doc_ident ");
	 		params.addProperty("num_doc_ident", usuarioProgramacionBean.getNumDocumentoIdentif());
		}
		
		if (!MaestrosUtilidades.isEmpty(usuarioProgramacionBean.getIndDel() )) {
			builder.append("and ind_del= ?ind_del ");
	 		params.addProperty("ind_del", usuarioProgramacionBean.getIndDel());
		}
		
		if (!MaestrosUtilidades.isEmpty(usuarioProgramacionBean.getIndEst() )) {
			builder.append("and ind_est= ?ind_est ");
	 		params.addProperty("ind_est", usuarioProgramacionBean.getIndEst());
		}
			
	 	logger.debug(String.format("JPAT10428UsuarioProgDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, UsuarioProgramacion.class);
	}
	
	@Override
	public List<UsuarioProgramacion> listarUsuariosTipaccsuge(UsuarioProgramacionBean filtro) {
		if (logger.isWarnEnabled())
			logger.warn("Inicio JPAT10420ProgramacionDAO - listarUsuariosTipaccsuge");

		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ")
				.append("A.num_programacion as numProgramacion, ")
				.append("A.num_usu_program as numUsuarioPrograma, ")
				.append("B.cod_progctrl as codProgctrl,")
				.append("a.cod_tip_docident as codTipoDocumentoIdentif,")
				.append("a.num_doc_ident as numDocumentoIdentif ")
			.append("FROM t10428usuarioprog A, ")
			.append("t10420programacion B ")
			.append("WHERE 1=1 ");
    
	if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoAccionSugerida())) {
		builder.append("and A.cod_tip_accsuge <> ?cod_tip_accsuge "); //No aplica
	  params.addProperty("cod_tip_accsuge", filtro.getCodTipoAccionSugerida());
	}
    
	if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
		builder.append("AND A.num_programacion = ?num_programacion "); //programacion autorizada
		params.addProperty("num_programacion", filtro.getNumProgramacion());
	}
	
	if (!MaestrosUtilidades.isEmpty(filtro.getCodSubEstadoProgram())) {
		builder.append("AND A.cod_sub_estprogram = ?cod_sub_estprogram ");
		params.addProperty("cod_sub_estprogram", filtro.getCodSubEstadoProgram());
	}
	
	builder.append("AND A.num_programacion = B.num_programacion ");
	

		logger.debug(String.format("JPAT10420ProgramacionDAO: query => %s", builder.toString()));
		
		if (logger.isDebugEnabled())
			logger.debug("Fin JPAT10420ProgramacionDAO - listarUsuariosTipaccsuge");
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, Programacion.class);

	}

	@Override
	public List<UsuarioProgramacion> listarUsuarioProg(UsuarioProgramacion filtro) {
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT10428UsuarioProgDAO - listarUsuarioProg");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
//		builder.append("SELECT u.cod_tip_docident  u.num_doc_ident as codTipoDocumentoIdentif, p.num_prog_correl as numProgCorrel, ")
//			   .append("p.cod_progctrl as codProgctrl, ")
//			   .append("u.cod_tip_interv as codTipoIntervencion, u.cod_tip_accion as codTipoAccion, a.cod_pers as codPers, d.num_documento as numDocumentoIdentif ")
//			   .append("FROM t10420programacion p ")
//			   .append("LEFT JOIN t10411informeselec i ON p.num_programacion = i.num_programacion INNER JOIN t10428usuarioprog u ON p.num_programacion = u.num_programacion ")
//			   .append("INNER JOIN t10394asignausuacc a ON u.num_usu_program = a.num_usu_program LEFT JOIN t10406documeaccion d ON u.num_usu_program = d.num_usu_program ")
//			   .append("LEFT JOIN t10415ordenaccion o ON u.num_usu_program = o.num_usu_program where 1=1");
		
		builder.append("SELECT u.num_usu_program as numUsuarioPrograma, u.cod_tip_docident  as codTipoDocumentoIdentif, u.num_doc_ident as numDocumentoIdentif ,  u.nom_ape_usu as nomApellidoUsuario, ")
		   .append("u.num_programacion as numProgramacion, p.cod_progctrl  as codProgctrl, p.des_alcance     as desProgctrl, i.num_inf_selecc as numInformeSelecci,  p.num_prog_correl as numProgCorrel, ")
		   .append("u.cod_tip_interv as codTipoIntervencion, u.cod_tip_accion as codTipoAccion, a.cod_pers as codPers, d.num_documento as  numDocumentoAccion,o.num_orden as numOrden, ")
		   .append("('IS'||'-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) as nroInformeUnion, ")
		   .append("(o.cod_tip_orden||'-'||o.num_correl_orden||'-'||o.ann_orden||'-SUNAT/'||o.cod_uuoo_orden) as numOrdenUnion ")
		   .append("FROM t10420programacion p ")
		   .append("LEFT JOIN t10411informeselec i ON p.num_programacion = i.num_programacion INNER JOIN t10428usuarioprog u ON p.num_programacion = u.num_programacion ")
		   .append("INNER JOIN t10394asignausuacc a ON u.num_usu_program = a.num_usu_program LEFT JOIN t10406documeaccion d ON u.num_usu_program = d.num_usu_program ")
		   .append("LEFT JOIN t10415ordenaccion o ON u.num_usu_program = o.num_usu_program where 1=1");
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNroInformeUnion())) {
			builder.append(" AND ('IS'||'-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) LIKE ?nroInformeUnion ");
			params.addProperty("nroInformeUnion", "%" + filtro.getNroInformeUnion() + "%");
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumOrdenUnion())) {
			builder.append(" AND (o.cod_tip_orden||'-'||o.num_correl_orden||'-'||o.ann_orden||'-SUNAT/'||o.cod_uuoo_orden) LIKE ?numOrdenUnion ");
			params.addProperty("numOrdenUnion", "%" + filtro.getNumOrdenUnion() + "%");
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgCorrel())) {
			builder.append(" AND p.num_prog_correl = ? numProgCorrel ");
			params.addProperty("numProgCorrel", filtro.getNumProgCorrel());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getDesAlcance())) {
			builder.append(" AND p.des_alcance = ?desAlcance ");
			params.addProperty("desAlcance", filtro.getDesAlcance());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumInformeSelecci())) {
			builder.append(" AND i.num_inf_selecc = ?numInformeSelecci ");
			params.addProperty("numInformeSelecci", filtro.getNumInformeSelecci());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoDocumentoIdentif())) {
			builder.append(" AND u.cod_tip_docident = ?codTipoDocumentoIdentif ");
			params.addProperty("codTipoDocumentoIdentif", filtro.getCodTipoDocumentoIdentif());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocumentoIdentif())) {
			builder.append(" AND u.num_doc_ident = ?numDocumentoIdentif ");
			params.addProperty("numDocumentoIdentif", filtro.getNumDocumentoIdentif());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodCargo())) {
			builder.append(" AND a.cod_cargo = ?codCargo ");
			params.addProperty("codCargo", filtro.getCodCargo());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
			builder.append(" AND p.num_programacion = ?numProgramacion ");
			params.addProperty("numProgramacion", filtro.getNumProgramacion());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getIndDel())) {
			builder.append(" AND p.ind_del = ?inDel AND i.ind_del = ?inDel");
			params.addProperty("inDel", filtro.getIndDel());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getIndEst())) {
			builder.append(" AND p.ind_est = ?indEst AND i.ind_est = ?indEst ");
			params.addProperty("indEst", filtro.getIndEst());
		}
		
		
		logger.debug(String.format("JPAT10428UsuarioProgDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				UsuarioProgramacion.class);
		}
	
	@Override
	public List<UsuarioProgramacion> validarUsuarioProg(UsuarioProgramacion filtro) {
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT10428UsuarioProgDAO - validarUsuarioProg");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT ")
		.append("p.num_programacion as numProgramacion, ")
		.append("p.num_usu_program as numUsuarioPrograma, ")
		.append("p.cod_tip_docident as codTipoDocumentoIdentif,")
		.append("p.num_doc_ident as numDocumentoIdentif ")
//		builder.append("SELECT p.NUM_USU_PROGRAM as numUsuarioPrograma")
		   .append(" FROM t10428usuarioprog p where 1=1 ");			
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {	
			builder.append(" AND p.num_programacion = ?numProgramacion ");
			params.addProperty("numProgramacion",  filtro.getNumProgramacion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipAccion())) {
			builder.append(" AND (p.cod_tip_accion = ?codTipAccion OR cod_tip_accion IS NULL) ");
			params.addProperty("codTipAccion", filtro.getCodTipAccion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodMotivaDepuracion())) {
			builder.append(" AND (p.cod_mot_depuracion = ?codMotivaDepuracion OR cod_mot_depuracion IS NULL) ");
			params.addProperty("codMotivaDepuracion", filtro.getCodMotivaDepuracion());
		}	
//		
		logger.debug(String.format("JPAT10428UsuarioProgDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				UsuarioProgramacion.class);
		}

	@Override
	public List<UsuarioProgramacion> listarCantUsuario(UsuarioProgramacion filtro) {
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT10428UsuarioProgDAO - listarUsuarioProg");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT ")
		.append("p.num_programacion as numProgramacion, ")
		.append("p.num_usu_program as numUsuarioPrograma, ")
		.append("p.cod_tip_docident as codTipoDocumentoIdentif,")
		.append("p.num_doc_ident as numDocumentoIdentif ")
        .append(" FROM t10428usuarioprog p where 1=1 ");	
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {	
			builder.append(" AND p.num_programacion = ?numProgramacion ");
			params.addProperty("numProgramacion",filtro.getNumProgramacion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipAccion())) {
			//builder.append(" AND (p.cod_tip_accion NOT IN (99,00) AND cod_tip_accion IS NOT NULL) ");
			builder.append(" AND (p.cod_tip_accion NOT IN ?tipAccion AND cod_tip_accion IS NOT NULL) ");
			List<String> valor = new ArrayList<String>();
			valor.add("99");
			valor.add("00");
			params.addPropertyOperador("tipAccion", valor, "IN");
		}
		
		logger.debug(String.format("JPAT10428UsuarioProgDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				UsuarioProgramacion.class);
		}
	
	public List<Programacion> listarOtraAccion(UsuarioProgramacion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10428UsuarioProgDAO - listarOtraAccion");
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();

		builder.append("SELECT A.num_programacion as numProgramacion, A.cod_progctrl as codProgctrl,(SELECT des_denominacion FROM t8276catprogctrl ")
			   .append("WHERE cod_progctrl= A.cod_progctrl) as desProgctrl, A.per_inicio as perFin, A.per_fin as perInicio, ")
			   .append("E.cod_tip_interv as codTipInterv, E.cod_tip_accion as codTipoAccion, D.cod_tip_doc as codTipoDocumentoIdent, D.num_documento as numDocumentoIdent, ") 
			   .append("C.num_orden as numOrden, C.cod_est_orden as codEstOrden FROM t10420programacion A ")
			   .append("LEFT JOIN (SELECT num_doc_ident, num_usu_program, num_programacion, cod_tip_interv, ")
			   .append("cod_tip_accion FROM t10428usuarioprog WHERE num_doc_ident = ?numDocIdent ")
			   .append("AND cod_tip_docident = ?codTipDocIdent AND num_programacion <> ?numProgramacion) E ")
			   .append("ON E.num_programacion = A.num_programacion LEFT JOIN t10415ordenaccion C ")
			   .append("ON E.num_usu_program = C.num_usu_program LEFT JOIN t10406documeaccion D ON E.num_usu_program = D. num_usu_program ") 
			   .append(" WHERE A.cod_est_program <> ?codEstPrograma ");
		params.addProperty("numDocIdent", filtro.getNumDocumentoIdentif());
		params.addProperty("codTipDocIdent", filtro.getCodTipoDocumentoIdentif());
		params.addProperty("numProgramacion", filtro.getNumProgramacion());
		params.addProperty("codEstPrograma", filtro.getCodEstPrograma());
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, Programacion.class);
	}

	@Override
	public List<UsuarioProgramacion> listarResumenAccion(String filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10428UsuarioProgDAO - listarResumenAccion");
		
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		
		builder.append(" SELECT ")
				.append(" a.cod_tip_accion as codTipoAccion, count (*) as cantTiposAccion ")
				.append(" FROM t10428usuarioprog a ")
				.append(" WHERE   a.num_programacion = ?numProgramacion ")
				.append(" GROUP BY   1 ");
		
		params.addProperty("numProgramacion", filtro);
		
		System.out.println(String.format("JPAT10428UsuarioProgDAO: query => %s", builder.toString()));
		logger.debug(String.format("JPAT10428UsuarioProgDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, UsuarioProgramacion.class);
	}

}
