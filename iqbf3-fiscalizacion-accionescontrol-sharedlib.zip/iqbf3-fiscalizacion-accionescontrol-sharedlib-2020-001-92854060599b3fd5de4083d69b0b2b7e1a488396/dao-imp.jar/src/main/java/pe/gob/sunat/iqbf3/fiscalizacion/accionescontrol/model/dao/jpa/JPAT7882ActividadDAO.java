package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Actividades;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T7882ActividadDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT7882ActividadDAO  extends AbstractDAOImpl<Actividades, String> implements T7882ActividadDAO {

	public JPAT7882ActividadDAO() {
		super(Actividades.class);
	}

}
