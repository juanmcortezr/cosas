package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.Arrays;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10421SolicProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10421SolicProgDAO extends AbstractDAOImpl<SolicitudProgramacion, Long> implements T10421SolicProgDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10421SolicProgDAO.class);

	public JPAT10421SolicProgDAO() {
		super(SolicitudProgramacion.class);
	}

	@Override
	public List<SolicitudProgramacion> listarConsultaSolicitudProgramacion(SolicitudProgramacion filtro) {
		
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10421SolicProgDAO - listarConsultaSolicitudProgramacion");

		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();

		builder.append(" select A.num_solic_prog as numSolicitud, B.nom_ape_usu as nomApeUsu, A.num_correl as numCorrel, ")
				.append(" A.ann_solicitud as anioSolicitud, A.num_correl as numCorrel, A.cod_uuoo as codUnidadOrganica, B.nom_ape_usu as nomApeUsu, B.cod_tip_interv as codTipInterv, ")
				.append(" A.fec_generacion as fecGeneracion, A.per_inicio as perInicio, A.per_fin as perFin, A.cod_tip_docrefer as codTipoDocumentoReferencia, ")
				.append(" B.cod_tip_docident as codTipDocIdent, B.num_doc_ident as numDocIdent, A.cod_solicitante as codSolicitante, A.cod_est_solicitud as codEstadoSolicitud, ")
				.append(" X.fec_movimiento as fechaEstadoActual, A.des_sus_solicitud as desSusSolicitud, B.cod_tip_accion as codTipAccion,  ")
				.append(" (Select COUNT(*) FROM t10412medioprobusu E where E.num_usu_solic=B.num_usu_solic) as medioProbatorio, ")
				.append(" (Select max(cod_pers) FROM t10393asignasolic D  where D.num_solic_prog=A.num_solic_prog ) as programadorAsignado, ")
				.append(" (Select max(val_calificacion) from t10400caliusua C where  B.num_usu_solic=C.num_usu_solic AND C.ind_tip_cali= ?califPreliminar AND C.ind_del = ?indDel) as calificacionPreliminar, ")
				.append(" (Select max(val_calificacion) from t10400caliusua C where  B.num_usu_solic=C.num_usu_solic AND C.ind_tip_cali= ?califDefinitiva AND C.ind_del = ?indDel) as calificacionDefinitiva, ")
				.append(" A.num_arc as numArc")
				.append(" FROM t10421solicprog A INNER JOIN  t10429usuariosolic B ON  A.num_solic_prog=B.num_solic_prog LEFT JOIN (SELECT LIMIT 1 A.fec_movimiento, A.num_solic_prog ")
				.append(" FROM t10414movsolic A, t10421solicprog B WHERE A.num_solic_prog=B.num_solic_prog ")
				.append(" ORDER BY A.fec_movimiento DESC)X ON X.num_solic_prog=A.num_solic_prog WHERE 1=1 ");
				
				params.addProperty("califPreliminar", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
				params.addProperty("califDefinitiva", AccionesControlConstantes.COD_TIP_CALI_DEFINITIVA);
				
				builder.append(" AND A.ind_del = ?indDel ");
				params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);	
				
				//System.out.println("filtro.getNumSolicitudUnion() => " + filtro.getNumSolicitudUnion());
				if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
					builder.append(" AND ('SP' || '-' ||  CASE when LENGTH(TO_CHAR(A.num_correl)) > 4 THEN TO_CHAR(A.num_correl) WHEN LENGTH(TO_CHAR(A.num_correl)) <= 4 THEN TO_CHAR(A.num_correl, '&&&&') end|| '-' || A.ann_solicitud || '-' || A.cod_uuoo) LIKE ?numSolicitudUnion");
					params.addProperty("numSolicitudUnion", "%" + filtro.getNumSolicitudUnion() + "%");
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoSolicitud())) {	
					builder.append(" AND A.cod_est_solicitud=?codEstSolicitud ");
					params.addProperty("codEstSolicitud", filtro.getCodEstadoSolicitud());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getCodTipAccion())) {
					builder.append(" AND B.cod_tip_accion= ?codTipAccion  ");
					params.addProperty("codTipAccion", filtro.getCodTipAccion());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getCodTipInterv())) {
					builder.append(" AND B.cod_tip_interv=?codTipInterv ");
					params.addProperty("codTipInterv", filtro.getCodTipInterv());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent())) {
					builder.append(" AND B.cod_tip_docident= ?codTipDocIdent ");
					params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getCodSolicitante())) {
					builder.append(" AND exists (B.cod_solicitante=?codSolicitante) ");
					params.addProperty("codSolicitante", filtro.getCodSolicitante());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getNumDocumentoReferencia())) {
					builder.append(" AND B.num_doc_refer=?numDocRefer) ");
					params.addProperty("numDocRefer", filtro.getNumDocumentoReferencia());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getCodProgramador())) {
					builder.append(" AND exists ( Select  num_solic_prog from t10393asignasolic D  WHERE  D.num_solic_prog = A.num_solic_prog AND cod_pers=?programadorAsignado) ");
					params.addProperty("programadorAsignado", filtro.getCodProgramador());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getInconsistencias())) {
					builder.append(" AND exists (  Select num_usu_solic from t10427tipinconusu WHERE cod_tip_inconsis in ?codTipInconsis) ");
					params.addProperty("codTipInconsis", filtro.getInconsistencias());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getTipoBienes())) {
					builder.append(" AND  exists(  select  num_usu_solic from  t10397bienfiscausu WHERE  cod_tip_bien in ?ListaCodTipBien) ");
					params.addProperty("ListaCodTipBien", filtro.getTipoBienes());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getBienesFiscalizados())) {
					builder.append(" AND exists ( select   num_usu_solic from  t10397bienfiscausu  WHERE cod_bien_fisca in ?bienesFiscalizados) ");
					params.addProperty("bienesFiscalizados", filtro.getBienesFiscalizados());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getFechaDesde())
						&& !MaestrosUtilidades.isEmpty(filtro.getFechaHasta())) {
					builder.append(" AND  A.fec_generacion BETWEEN  ?fechaDesde AND ?fechaHasta ");
					params.addProperty("fechaDesde", filtro.getFechaDesde());
					params.addProperty("fechaHasta", filtro.getFechaHasta());
				}
				else if (!MaestrosUtilidades.isEmpty(filtro.getFechaDesde())
						&& !MaestrosUtilidades.isEmpty(filtro.getFechaHasta())) {
					builder.append(" AND  A.fec_generacion >= ?fechaDesde ");
					params.addProperty("fechaDesde", filtro.getFechaDesde());
				}
				
				if (!MaestrosUtilidades.isEmpty(filtro.getCalificacionDesde())
						&& !MaestrosUtilidades.isEmpty(filtro.getCalificacionHasta())) {
					builder.append(" AND exists (Select C.num_usu_solic  FROM t10400caliusua C WHERE C.num_usu_solic= B.num_usu_solic  AND (valCalificacion>=?calificacionDesde AND valCalificacion<=?calificacionHasta) ");
					params.addProperty("calificacionDesde", filtro.getCalificacionDesde());
					params.addProperty("calificacionHasta", filtro.getCalificacionHasta());
				}
				else if (!MaestrosUtilidades.isEmpty(filtro.getCalificacionDesde())
						&& !MaestrosUtilidades.isEmpty(filtro.getCalificacionHasta())) {
					builder.append(" AND exists (Select C.num_usu_solic  FROM t10400caliusua C WHERE C.num_usu_solic= B.num_usu_solic  AND (valCalificacion>=?calificacionDesde) ");
					params.addProperty("calificacionDesde", filtro.getCalificacionDesde());
				}

			//System.out.println(String.format("JPAT10421SolicProgDAO: query => %s", builder.toString()));
			logger.debug(String.format("JPAT10421SolicProgDAO: query => %s", builder.toString()));
			return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
					SolicitudProgramacion.class);
	}

	@Override
	public List<SolicitudProgramacion> listarSolicitudProgramacion(SolicitudProgramacion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10421SolicProgDAO - listarSolicitudProgramacion");
		boolean soloTipoDoc = !MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent());
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT A.num_solic_prog  as numSolicitud, A.num_correl as numCorrel, A.ann_solicitud as anioSolicitud, ") 
				.append("A.cod_uuoo as codUnidadOrganica, A.des_sus_solicitud as desSusSolicitud, ")
				.append("A.fec_generacion as fecGeneracion, A.obs_solicitud as obsSolicitud,  ")
				.append("A.cod_est_solicitud as codEstadoSolicitud, ");
		if (soloTipoDoc) {
			builder.append("(Select max(val_calificacion) from t10429usuariosolic C INNER JOIN t10400caliusua B ON A.num_solic_prog= C.num_solic_prog where B.num_usu_solic=C.num_usu_solic and ind_tip_cali= ?calificacionPreliminar) as calificacionPreliminar, ")
				.append("(Select max(val_calificacion) from t10429usuariosolic C INNER JOIN t10400caliusua B ON A.num_solic_prog= C.num_solic_prog where B.num_usu_solic=C.num_usu_solic and ind_tip_cali= ?calificacionDefinitiva) as calificacionDefinitiva ");
			params.addProperty("calificacionPreliminar", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
			params.addProperty("calificacionDefinitiva", AccionesControlConstantes.COD_TIP_CALI_DEFINITIVA);
		} else {
			builder.append("0 as calificacionPreliminar, 0 as calificacionDefinitiva ");
		}
		builder.append("FROM t10421solicprog A WHERE 1=1 ");

		builder.append(" AND A.ind_del = ?indDel ");
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		builder.append(" AND A.ind_est = ?indEst ");
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);

		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			builder.append(" AND ('SP' || '-' ||  CASE when LENGTH(TO_CHAR(A.num_correl)) > 4 THEN TO_CHAR(A.num_correl) WHEN LENGTH(TO_CHAR(A.num_correl)) <= 4 THEN TO_CHAR(A.num_correl, '&&&&') end|| '-' || A.ann_solicitud || '-' || A.cod_uuoo) LIKE ?numSolicitudUnion");
			params.addProperty("numSolicitudUnion", "%" + filtro.getNumSolicitudUnion() + "%");
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getEstados())) {
			builder.append(" AND A.cod_est_solicitud IN ?estados ");
			params.addProperty("estados", filtro.getEstados());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipAccion())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_accion= ?codTipAccion) ");
			params.addProperty("codTipAccion", filtro.getCodTipAccion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipInterv())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_interv= ?codTipInterv) ");
			params.addProperty("codTipInterv", filtro.getCodTipInterv());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_docident= ?codTipDocIdent AND C.num_doc_ident=?numDocIdent) ");
			params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}
		else if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_docident= ?codTipDocIdent) ");
			params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
		}
		else if (MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.num_doc_ident= ?numDocIdent) ");
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}

		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, SolicitudProgramacion.class);
	}

	@Override
	public Integer obtenerCorrelativoSolicitud(Integer anio) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10421SolicProgDAO - obtenerCorrelativoSolicitud");
		String query = "SELECT MAX(a.numCorrel) FROM SolicitudProgramacion a WHERE a.anioSolicitud=:anioSolicitud";
		PropertyParams params = new PropertyParams();
		params.addProperty("anioSolicitud", anio);
		logger.debug("anio =>" + anio);
		List<Integer> correls = this.findByJPQL(query, params, AccionesControlConstantes.DATASOURCE_DCSICOBF, Integer.class);
		Integer correlativo = 0;
		logger.debug(String.format("correls => %s", Arrays.toString(correls.toArray())));
		if (!MaestrosUtilidades.isEmpty(correls)) {
			if (!MaestrosUtilidades.isEmpty(correls.get(0))) {
				correlativo = correls.get(0);	
			}
		}
		return correlativo + 1;
	}

	@Override
	public List<SolicitudProgramacion> listarSolicitudSupervisorSolicitante(SolicitudProgramacion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10421SolicProgDAO - listarSolicitudSupervisorSolicitante");
		boolean soloTipoDoc = !MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent());
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT A.num_solic_prog  as numSolicitud, A.num_correl as numCorrel, A.ann_solicitud as anioSolicitud, ") 
				.append("A.cod_uuoo as codUnidadOrganica, A.des_sus_solicitud as desSusSolicitud,  A.cod_solicitante as codSolicitante, ")
				.append("A.fec_generacion as fecGeneracion, A.obs_solicitud as obsSolicitud,  ")
				.append("A.cod_est_solicitud as codEstadoSolicitud, ");

		if (soloTipoDoc) {
			builder.append("(Select max(val_calificacion) from t10429usuariosolic C INNER JOIN t10400caliusua B ON A.num_solic_prog= C.num_solic_prog ")
				   .append("where B.num_usu_solic=C.num_usu_solic and B.ind_tip_cali= ?calificacionPreliminar  AND C.cod_tip_docident= ?codTipDocIdent AND C.num_doc_ident=?numDocIdent) as calificacionPreliminar, ");
		} else {
			builder.append("0 as calificacionPreliminar, ");
		}
		builder.append("A.num_doc_refer as numDocumentoReferencia, A.num_arc as numArc ")
				.append("FROM t10421solicprog A WHERE 1=1 ");

		params.addProperty("calificacionPreliminar", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
		builder.append(" AND A.ind_del = ?indDel ");
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		builder.append(" AND A.ind_est = ?indEst ");
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);

		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			builder.append(" AND ('SP' || '-' ||  CASE when LENGTH(TO_CHAR(A.num_correl)) > 4 THEN TO_CHAR(A.num_correl) WHEN LENGTH(TO_CHAR(A.num_correl)) <= 4 THEN TO_CHAR(A.num_correl, '&&&&') end|| '-' || A.ann_solicitud || '-' || A.cod_uuoo) LIKE ?numSolicitudUnion");
			params.addProperty("numSolicitudUnion", "%" + filtro.getNumSolicitudUnion() + "%");
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoSolicitud())) {
			builder.append(" AND A.cod_est_solicitud = ?estado ");
			params.addProperty("estado", filtro.getCodEstadoSolicitud());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipAccion())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_accion= ?codTipAccion) ");
			params.addProperty("codTipAccion", filtro.getCodTipAccion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipInterv())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_interv= ?codTipInterv) ");
			params.addProperty("codTipInterv", filtro.getCodTipInterv());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_docident= ?codTipDocIdent AND C.num_doc_ident=?numDocIdent) ");
			params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}
		else if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_docident= ?codTipDocIdent) ");
			params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
		}
		else if (MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.num_doc_ident= ?numDocIdent) ");
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodSolicitante())) {
			builder.append(" AND A.cod_solicitante = ?codSolicitante ");
			params.addProperty("codSolicitante", filtro.getCodSolicitante());
		}
		logger.debug(String.format("query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, SolicitudProgramacion.class);
	}

	@Override
	public List<SolicitudProgramacion> listarSolicitudSupervisorProgramador(SolicitudProgramacion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10421SolicProgDAO - listarSolicitudSupervisorProgramador");
		boolean soloTipoDoc = !MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent());
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT A.num_solic_prog as numSolicitud, A.num_correl as numCorrel, A.ann_solicitud as anioSolicitud, ") 
				.append("A.cod_uuoo as codUnidadOrganica, A.des_sus_solicitud as desSusSolicitud,  A.cod_solicitante as codSolicitante, ")
				.append("(Select cod_pers FROM t10393asignasolic D WHERE D.num_solic_prog=A.num_solic_prog AND D.ind_del = ?indDel AND D.ind_est = ?indEst) as codProgramador, X.cod_pers_mov as codSupervisor, ")
				.append("A.des_sus_solicitud as desSusSolicitud, A.fec_generacion as fecGeneracion, A.obs_solicitud as obsSolicitud,  ")
				.append("A.cod_est_solicitud as codEstadoSolicitud, ");
		if (soloTipoDoc) {
			builder
			.append("(Select max(val_calificacion) from t10429usuariosolic C INNER JOIN t10400caliusua B ON A.num_solic_prog= C.num_solic_prog where B.num_usu_solic=C.num_usu_solic and ind_tip_cali= ?calificacionPreliminar) as calificacionPreliminar, ")
			.append("(Select max(val_calificacion) from t10429usuariosolic C INNER JOIN t10400caliusua B ON A.num_solic_prog= C.num_solic_prog where B.num_usu_solic=C.num_usu_solic and ind_tip_cali= ?calificacionDefinitiva) as calificacionDefinitiva, ");
			params.addProperty("calificacionPreliminar", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
			params.addProperty("calificacionDefinitiva", AccionesControlConstantes.COD_TIP_CALI_DEFINITIVA);
		} else {
			builder.append("0 as calificacionPreliminar, 0 as calificacionDefinitiva, ");
		}
		builder.append("A.num_doc_refer as numDocumentoReferencia, A.num_arc as numArc ")
				.append("FROM t10421solicprog A LEFT JOIN (SELECT LIMIT 1 cod_pers_mov,A.num_solic_prog ") 
				.append("FROM t10414movsolic A, t10421solicprog B WHERE A.num_solic_prog=B.num_solic_prog ") 
				.append(" ORDER BY A.fec_movimiento DESC) X ON X.num_solic_prog=A.num_solic_prog WHERE 1=1 ");

		builder.append(" AND A.ind_del = ?indDel ");
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		builder.append(" AND A.ind_est = ?indEst ");
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);

		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			builder.append(" AND ('SP' || '-' ||  CASE when LENGTH(TO_CHAR(A.num_correl)) > 4 THEN TO_CHAR(A.num_correl) WHEN LENGTH(TO_CHAR(A.num_correl)) <= 4 THEN TO_CHAR(A.num_correl, '&&&&') end|| '-' || A.ann_solicitud || '-' || A.cod_uuoo) LIKE ?numSolicitudUnion");
			params.addProperty("numSolicitudUnion", "%" + filtro.getNumSolicitudUnion() + "%");
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoSolicitud())) {
			builder.append(" AND A.cod_est_solicitud = ?estado ");
			params.addProperty("estado", filtro.getCodEstadoSolicitud());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipAccion())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_accion= ?codTipAccion) ");
			params.addProperty("codTipAccion", filtro.getCodTipAccion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipInterv())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_interv= ?codTipInterv) ");
			params.addProperty("codTipInterv", filtro.getCodTipInterv());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_docident= ?codTipDocIdent AND C.num_doc_ident=?numDocIdent) ");
			params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}
		else if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_docident= ?codTipDocIdent) ");
			params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
		}
		else if (MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.num_doc_ident= ?numDocIdent) ");
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodSolicitante())) {
			builder.append(" AND A.cod_solicitante = ?codSolicitante ");
			params.addProperty("codSolicitante", filtro.getCodSolicitante());
		}
		logger.debug(String.format("query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, SolicitudProgramacion.class);
	}

	@Override
	public List<SolicitudProgramacion> vigenciaUsuarioSolicitud(SolicitudProgramacion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10421SolicProgDAO - vigenciaUsuarioSolicitud");
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT  A.num_solic_prog as numSolicitud, B.num_correl as numCorrel, B.cod_est_solicitud as codEstadoSolicitud, C.cod_pers as codSolicitante, B.fec_generacion as fecGeneracion ")
			   .append("FROM t10429usuariosolic A INNER JOIN  t10421solicprog B ") 
			   .append("ON A.num_solic_prog=B.num_solic_prog INNER JOIN t10393asignasolic C ") 
			   .append("ON B.num_solic_prog=C.num_solic_prog WHERE A. cod_tip_docident=?codTipDocIdent ") 
			   .append("AND A.num_doc_ident=?numDocIdent AND B.cod_est_solicitud not in ?estados ");
		params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
		params.addProperty("numDocIdent", filtro.getNumDocIdent());
		params.addProperty("estados", filtro.getEstados());
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, SolicitudProgramacion.class);
	}

	@Override
	public List<SolicitudProgramacion> listarSolicitudesporAsignarCalificar(SolicitudProgramacion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10421SolicProgDAO - listarSolicitudesporAsignarCalificar");
		boolean soloTipoDoc = !MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent());
		
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT A.num_solic_prog as numSolicitud, A.num_correl as numCorrel, A.ann_solicitud as anioSolicitud, ") 
			   .append("A.cod_uuoo as codUnidadOrganica, A.cod_solicitante as codSolicitante, X.cod_pers_mov as codSupervisor, ") 
			   .append("A.des_sus_solicitud as desSusSolicitud, A.fec_generacion as fecGeneracion, A.obs_solicitud as obsSolicitud, ")
			   .append(" A.cod_est_solicitud as codEstadoSolicitud, (select max(cod_pers) FROM t10393asignasolic D where D.num_solic_prog=A.num_solic_prog ")
			   .append("AND D.ind_del = ?indDel AND D.ind_est = ?indEst) as codProgramador, ");
		if (soloTipoDoc) {
			builder.append("(Select max(val_calificacion) from t10429usuariosolic C INNER JOIN t10400caliusua B ON A.num_solic_prog= C.num_solic_prog AND A.ind_del = ?indDel ")
				   .append("where B.num_usu_solic=C.num_usu_solic and B.ind_tip_cali= ?calificacionPreliminar AND C.cod_tip_docident= ?codTipDocIdent AND C.num_doc_ident=?numDocIdent) as calificacionPreliminar, ");
		} else {
			builder.append("0 as calificacionPreliminar, ");
		}
		builder.append("A.num_doc_refer as numDocumentoReferencia, A.num_arc as numArc FROM t10421solicprog A LEFT JOIN  (SELECT LIMIT 1 cod_pers_mov,A.num_solic_prog FROM ") 
			   .append("t10414movsolic A, t10421solicprog B  WHERE A.num_solic_prog=B.num_solic_prog ORDER BY A.fec_movimiento DESC) X ")
			   .append("ON X.num_solic_prog=A.num_solic_prog WHERE 1=1 ");

		params.addProperty("calificacionPreliminar", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
		builder.append(" AND A.ind_del = ?indDel ");
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		builder.append(" AND A.ind_est = ?indEst ");
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);

		if (!MaestrosUtilidades.isEmpty(filtro.getNumSolicitudUnion())) {
			builder.append(" AND ('SP' || '-' ||  CASE when LENGTH(TO_CHAR(A.num_correl)) > 4 THEN TO_CHAR(A.num_correl) WHEN LENGTH(TO_CHAR(A.num_correl)) <= 4 THEN TO_CHAR(A.num_correl, '&&&&') end|| '-' || A.ann_solicitud || '-' || A.cod_uuoo) LIKE ?numSolicitudUnion");
			params.addProperty("numSolicitudUnion", "%" + filtro.getNumSolicitudUnion() + "%");
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getEstados())) {
			builder.append(" AND A.cod_est_solicitud in ?estados ");
			params.addProperty("estados", filtro.getEstados());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipAccion())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_accion= ?codTipAccion) ");
			params.addProperty("codTipAccion", filtro.getCodTipAccion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipInterv())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_interv= ?codTipInterv) ");
			params.addProperty("codTipInterv", filtro.getCodTipInterv());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_docident= ?codTipDocIdent AND C.num_doc_ident=?numDocIdent) ");
			params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}
		else if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.cod_tip_docident= ?codTipDocIdent) ");
			params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
		}
		else if (MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent()) && !MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND EXISTS (select C.num_solic_prog from t10429usuariosolic C WHERE A.num_solic_prog= C.num_solic_prog AND C.num_doc_ident= ?numDocIdent) ");
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodSolicitante())) {
			builder.append(" AND A.cod_solicitante = ?codSolicitante ");
			params.addProperty("codSolicitante", filtro.getCodSolicitante());
		}
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, SolicitudProgramacion.class);
	}

	@Override
	public List<SolicitudProgramacion> obtenerDatosCaliPre(UsuarioSolicitud filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10421SolicProgDAO - obtenerDatosCaliPre");
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT A.num_solic_prog  as numSolicitud, A.num_correl as numCorrel, A.ann_solicitud as anioSolicitud, ") 
			   .append("A.cod_uuoo as codUnidadOrganica, A.cod_solicitante as codSolicitante, B.cod_tip_interv as codTipInterv, ") 
			   .append("B.cod_tip_accion as codTipAccion, B.cod_tip_docident as codTipDocIdent, B.num_doc_ident as numDocIdent, ")
			   .append("B.nom_ape_usu as nomApeUsu FROM t10421solicprog A, t10429usuariosolic B ") 
			   .append("WHERE A.num_solic_prog=B.num_solic_prog AND  B.num_usu_solic=?numUsuSolic AND  B.ind_del = ?indDel ");
		params.addProperty("numUsuSolic", filtro.getNumUsuarioSolicitud());
		params.addProperty("indDel", filtro.getIndDel());
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, SolicitudProgramacion.class);
	}

}
