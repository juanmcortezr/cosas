package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOperacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoOperacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10405DocOperOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10405DocOperOrdenDAO extends AbstractDAOImpl<DocumentoOperacion, Long> implements T10405DocOperOrdenDAO  {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10405DocOperOrdenDAO.class);
	
	public JPAT10405DocOperOrdenDAO(){
		super(DocumentoOperacion.class);
	}
	
	@Override
	public int actualizarDocumentoOperacion(DocumentoOperacion model) {
		int resultado=0;
		
		
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
				
		builder.append("UPDATE t10405docoperorden d SET ");
		builder.append(" d.fec_modif=SYSDATE ");
		if(!MaestrosUtilidades.isEmpty(model.getCodTipoDocumentoOperacion()))builder.append(" ,d.COD_TIP_DOCOPERA = ?2");
		if(!MaestrosUtilidades.isEmpty(model.getNumDocumentoComercial()))builder.append(" ,d.NUM_DOCCOMER = ?3");
		if(model.isIndEliminar()) {
		builder.append(" ,d.IND_DEL = ?12");
		builder.append(" ,d.IND_EST = ?13");
		}
		if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,d.COD_USUMODIF = ?14");
		if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,d.DIR_IPUSUMODIF = ?15");
		if(!MaestrosUtilidades.isEmpty(model.getNumOrden())&&model.getNumOrden()>0)builder.append(" ,d.NUM_ORDEN = ?16");
		builder.append(" WHERE 1=1 ");
		if(!MaestrosUtilidades.isEmpty(model.getNumDocumentoOperacion())&&model.getNumDocumentoOperacion()>0)builder.append(" AND d.NUM_DOC_OPERORDEN = ?1 ");
		
		Query query = entityManager.createNativeQuery(builder.toString());
		
		query.setParameter(1 , model.getNumDocumentoOperacion());
		query.setParameter(2 , model.getCodTipoDocumentoOperacion());
		query.setParameter(3 , model.getNumDocumentoComercial());
		if(model.isIndEliminar()) {
		query.setParameter(12 , MaestrosConstantes.REGISTRO_ELIMINADO);
		query.setParameter(13 , MaestrosConstantes.REGISTRO_INACTIVO);
		}
		query.setParameter(14, model.getCodUsuModif());
		query.setParameter(15 , model.getDirIpusumodif());
		query.setParameter(16 , model.getNumOrden());
			
		logger.debug(String.format("JPAT10405DocOperOrdenDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10405DocOperOrdenDAO: query => %s", builder.toString()));
		
		resultado =	query.executeUpdate();
		
		return resultado;
	}
	
	
	@Override
	public List<DocumentoOperacion> listarDocumentoOperacion(DocumentoOperacion model){
		
		PropertyParams params = new PropertyParams();
		
		StringBuilder builder=new StringBuilder();
		builder.append("SELECT d.num_doc_operorden as numDocumentoOperacion, ");
		builder.append(" d.num_orden as numOrden, ");
		builder.append(" d.cod_tip_docopera as codTipoDocumentoOperacion, ");
		builder.append(" d.num_doccomer as numDocumentoComercial ");
		builder.append(" FROM t10405docoperorden d WHERE 1=1 ");
		
		
		if(!MaestrosUtilidades.isEmpty(model.getIndDel()))
			{
			builder.append(" AND d.IND_DEL = ?indDel ");
			params.addProperty("indDel", model.getIndDel());
			}
		if(!MaestrosUtilidades.isEmpty(model.getIndEst())) {
			builder.append(" AND d.IND_EST = ?indEst ");
			params.addProperty("indEst", model.getIndEst());
		}
		if(!MaestrosUtilidades.isEmpty(model.getNumDocumentoOperacion())&&model.getNumDocumentoOperacion()>0) {
			builder.append(" AND d.NUM_DOC_OPERORDEN = ?numDocumentoOperacion ");
			params.addProperty("numDocumentoOperacion", model.getNumDocumentoOperacion());
		}
		if(!MaestrosUtilidades.isEmpty(model.getNumOrden())&&model.getNumOrden()>0) {
			builder.append(" AND d.NUM_ORDEN = ?numOrden ");
			params.addProperty("numOrden", model.getNumOrden());
		}
		if(!MaestrosUtilidades.isEmpty(model.getCodTipoDocumentoOperacion())) {
			builder.append(" AND d.COD_TIP_DOCOPERA = ?codTipoDocumentoOperacion ");
			params.addProperty("codTipoDocumentoOperacion", model.getCodTipoDocumentoOperacion());
		}
		
		
		logger.debug(String.format("JPAT10405DocOperOrdenDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10405DocOperOrdenDAO: query => %s", builder.toString()));
		
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DocumentoOperacion.class);
	}
	
	
	@Override
	public List<DocumentoOperacionBean> listarDocumentoOperacionBean(DocumentoOperacion model){
		List<DocumentoOperacionBean> lstDocumentoOperacion=new ArrayList<>();
		List<DocumentoOperacion> lstModel=listarDocumentoOperacion(model);
		if(!MaestrosUtilidades.isEmpty(lstModel)&&lstModel.size()>0) {
			for(DocumentoOperacion modelTemp:lstModel) {
				DocumentoOperacionBean bean=new DocumentoOperacionBean();
				MaestrosUtilidades.copiarValoresBean(modelTemp, bean);
				lstDocumentoOperacion.add(bean);
			}
		}
		return lstDocumentoOperacion;
	}
	
	
	
}
