package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CalificacionUsuario;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10400CaliUsuaDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10400CaliUsuaDAO extends AbstractDAOImpl<CalificacionUsuario, Long> implements T10400CaliUsuaDAO  {

	public JPAT10400CaliUsuaDAO(){
		super(CalificacionUsuario.class);
	}
}
