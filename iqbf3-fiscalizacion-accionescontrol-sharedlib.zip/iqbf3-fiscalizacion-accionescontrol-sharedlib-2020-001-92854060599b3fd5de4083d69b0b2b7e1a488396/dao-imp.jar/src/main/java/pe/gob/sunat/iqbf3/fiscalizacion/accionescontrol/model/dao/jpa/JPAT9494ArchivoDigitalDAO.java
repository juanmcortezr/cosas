package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;


import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.T9494ArcDigit;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T9494ArchivoDigitalDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;


@Stateless
public class JPAT9494ArchivoDigitalDAO  extends AbstractDAOImpl<T9494ArcDigit, Long> implements T9494ArchivoDigitalDAO {
	
	public JPAT9494ArchivoDigitalDAO() {
		super(T9494ArcDigit.class);
	}
}
