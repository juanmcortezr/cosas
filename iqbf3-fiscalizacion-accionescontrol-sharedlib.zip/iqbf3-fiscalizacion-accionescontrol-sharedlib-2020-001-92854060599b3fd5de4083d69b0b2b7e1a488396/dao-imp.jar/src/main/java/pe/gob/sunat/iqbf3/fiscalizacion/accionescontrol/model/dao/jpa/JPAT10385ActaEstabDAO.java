package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActaEstablecimiento;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10385ActaEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;

@Stateless
public class JPAT10385ActaEstabDAO extends AbstractDAOImpl<ActaEstablecimiento, Long> implements T10385ActaEstabDAO {
	private static final Logger logger = LoggerFactory.getLogger(JPAT10385ActaEstabDAO.class);
	public JPAT10385ActaEstabDAO() {
		super(ActaEstablecimiento.class);
	}
	
	
	@Override
	public int actualizarActaEstab(ActaEstablecimiento model) {
		int resultado=0;
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
		builder.append(" UPDATE t10385actaestab a SET ");
		builder.append(" a.fec_modif = SYSDATE ");
		  
		  if(model.getNumEstablecimientoOrden()!=null&&model.getNumEstablecimientoOrden()>0)builder.append(" ,a.num_estab_orden = ?2 ");
		  if(model.getCodTipoActa()!=null)builder.append(" ,a.cod_tip_acta = ?3 ");
		  if(model.getNumActa()!=null)builder.append(" ,a.num_acta = ?4 ");  
		  if(model.getDesOtraActa()!=null)builder.append(" ,a.des_otra_acta = ?5 ");
		  if(model.getCodTipoDocumentoReferencia()!=null)builder.append(" ,a.cod_tip_docvin = ?6 "); 
		  if(model.getNumDocumentoVinculado()!=null)builder.append(" ,a.num_doc_vind = ?7 ");
		  if(model.getDesOtroDocumentoVinculado()!=null)builder.append(" ,a.des_otro_docvin = ?8 ");
		  if(model.getCodTipoInforme()!=null)builder.append(" ,a.cod_tip_informe = ?9 ");
		  if(model.getDesOtroInforme()!=null)builder.append(" ,a.des_otro_informe = ?10 ");
		  if(model.isIndEliminar()) {
			  builder.append(" ,a.ind_del = ?11 ");
			  builder.append(" ,a.ind_est = ?12 "); 
		  }else {
			  if(model.getIndDel()!=null) builder.append(" ,a.ind_del = ?15 ");
			  if(model.getIndEst()!=null) builder.append(" ,a.ind_est = ?16 "); 
		  }
		  if(model.getCodUsuModif()!=null)builder.append(" ,a.cod_usumodif = ?13 ");
		  if(model.getDirIpusumodif()!=null)builder.append(" ,a.dir_ipusumodif = ?14 ");  
		  
		  
		  
		  builder.append(" WHERE 1=1 ");
		  
		  if(model.getNumActaEstablecimiento()!=null&&model.getNumActaEstablecimiento()>0)builder.append(" AND num_acta_estab = ?1 ");
		  if(model.getNumEstablecimientoOrden()!=null&&model.getNumEstablecimientoOrden()>0)builder.append(" AND num_estab_orden = ?2 ");
		  
		Query query = entityManager.createNativeQuery(builder.toString());
		
		query.setParameter(1, model.getNumActaEstablecimiento());
		query.setParameter(2, model.getNumEstablecimientoOrden());
		query.setParameter(3, model.getCodTipoActa());
		query.setParameter(4, model.getNumActa());
		query.setParameter(5, model.getDesOtraActa());
		query.setParameter(6, model.getCodTipoDocumentoReferencia());
		query.setParameter(7, model.getNumDocumentoVinculado());
		query.setParameter(8, model.getDesOtroDocumentoVinculado());
		query.setParameter(9, model.getCodTipoInforme());
		query.setParameter(10, model.getDesOtroInforme());
		
		 if(model.isIndEliminar()) {
			 query.setParameter(11, MaestrosConstantes.REGISTRO_ELIMINADO);
			 query.setParameter(12, MaestrosConstantes.REGISTRO_INACTIVO);
		  }else{
			  query.setParameter(15, model.getIndDel());
			  query.setParameter(16, model.getIndEst());
		  }
		
		query.setParameter(13, model.getCodUsuModif()); 
		query.setParameter(14, model.getDirIpusumodif());
		 
		logger.debug(String.format("JPAT10408EstabOrdenDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10408EstabOrdenDAO: query => %s", builder.toString()));
		
		resultado =	query.executeUpdate();
		return resultado;
	}
}
