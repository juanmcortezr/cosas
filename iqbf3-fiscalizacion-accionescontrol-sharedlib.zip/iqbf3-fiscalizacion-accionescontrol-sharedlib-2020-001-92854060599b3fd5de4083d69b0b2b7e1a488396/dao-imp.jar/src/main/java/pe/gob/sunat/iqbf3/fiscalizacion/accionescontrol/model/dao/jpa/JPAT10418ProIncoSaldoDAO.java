package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaSaldo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10418ProIncoSaldoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10418ProIncoSaldoDAO extends AbstractDAOImpl<ProgramaIncosistenciaSaldo, Long> implements T10418ProIncoSaldoDAO{

	private static final Logger logger = LoggerFactory.getLogger(JPAT10418ProIncoSaldoDAO.class);
	
	public JPAT10418ProIncoSaldoDAO() {
		super(ProgramaIncosistenciaSaldo.class);
	}

	@Override
	public List<ProgramaIncosistenciaSaldo> listarInconsistenciaSaldo(Long numUsuarioPrograma) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10418ProIncoSaldoDAO - listarInconsistenciaSaldo");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ")
		.append(" num_inco_saldo as numIncosistemciaSaldo, ")
		.append(" num_usu_program as numUsuarioPrograma, ")
		.append(" num_reposicion as numReposicion, ")
		.append(" num_periodo as numPeriodo, ")
		.append(" num_inscab as numInsumoCabecera, ")
		.append(" cod_insumo as codInsumo, ")
		.append(" num_orden as numOrden, ")
		.append(" num_version_insu as numVersionInsumo, ")
		.append(" des_nomcomprod as desNombreComercial, ")
		.append(" des_nomprod as desNombreProducto, ")
		.append(" cod_tipprod as codTipprod, ")
		.append(" cod_um as codUnidadMedida, ")
		.append(" cod_bienfisca as codBienFiscalizado, ")
		.append(" por_min_ins as porMinInsumo, ")
		.append(" por_max_ins as porMaxInsumo, ")
		.append(" cnt_autorizada as cantidadAutorizada, ")
		.append(" cnt_consumida as cantidadConsumida, ")
		.append(" cnt_disponible as cantidadDisponible ")
		.append(" FROM t10418proincosaldo ");
		
		if (!MaestrosUtilidades.isEmpty(numUsuarioPrograma)) {
			builder.append(" WHERE num_usu_program = ?numUsuarioPrograma ");
			params.addProperty("numUsuarioPrograma", numUsuarioPrograma);
		}
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ProgramaIncosistenciaSaldo.class);
	}
}
