package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PreseleccionAsignacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10416PreseleAsigDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10416PreseleAsigDAO extends AbstractDAOImpl<PreseleccionAsignacion, Long> implements T10416PreseleAsigDAO{
	
	private static final Logger logger = LoggerFactory.getLogger(JPAT10415OrdenAccionDAO.class);

	public JPAT10416PreseleAsigDAO() {
		super(PreseleccionAsignacion.class);
	}
	
	@Override
	public List<PreseleccionAsignacion> obtenerAuditorAsignar(PreseleccionAsignacion preseleccionAsignacion){
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10416PreseleAsigDAO - obtenerAuditorAsignar");
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT A.cod_pers as codAuditor, ") 
			   .append(" (SELECT COUNT (*) FROM t10394asignausuacc D ")
			   .append(" WHERE D.cod_pers=A.cod_pers AND D.fec_fin_asignacion='') AS CargaLaboral ")
			   .append(" FROM t10416preselecasig A, t10411informeselec C ")
			   .append(" WHERE A.num_programacion = ?numProgramacion ")
			   .append(" AND C.num_inf_selecc=?numInfSelecc AND C.num_programacion=A.num_programacion ")
			   .append(" group by A.cod_pers ");

		params.addProperty("numProgramacion", preseleccionAsignacion.getNumProgramacion());
		params.addProperty("numInfSelecc", preseleccionAsignacion.getNumInfSelecc());
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				PreseleccionAsignacion.class);
	}

	
	

}
