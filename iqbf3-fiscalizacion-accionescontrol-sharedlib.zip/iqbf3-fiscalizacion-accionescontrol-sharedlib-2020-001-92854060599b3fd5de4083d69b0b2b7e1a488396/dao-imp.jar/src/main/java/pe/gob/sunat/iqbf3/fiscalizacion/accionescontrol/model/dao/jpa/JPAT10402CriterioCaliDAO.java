package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CriterioCalificacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10402CriterioCaliDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10402CriterioCaliDAO extends AbstractDAOImpl<CriterioCalificacion, Long> implements T10402CriterioCaliDAO  {

	public JPAT10402CriterioCaliDAO(){
		super(CriterioCalificacion.class);
	}
	
}
