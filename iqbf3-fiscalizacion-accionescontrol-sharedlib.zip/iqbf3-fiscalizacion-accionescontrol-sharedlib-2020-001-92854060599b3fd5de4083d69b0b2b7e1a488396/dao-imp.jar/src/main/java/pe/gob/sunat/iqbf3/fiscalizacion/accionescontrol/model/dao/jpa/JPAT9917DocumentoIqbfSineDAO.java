package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoIqbfSine;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T9917DocumentoIqbfSineDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT9917DocumentoIqbfSineDAO extends AbstractDAOImpl<DocumentoIqbfSine, Long> implements T9917DocumentoIqbfSineDAO {

	public JPAT9917DocumentoIqbfSineDAO() {
		super(DocumentoIqbfSine.class);
	}

}
