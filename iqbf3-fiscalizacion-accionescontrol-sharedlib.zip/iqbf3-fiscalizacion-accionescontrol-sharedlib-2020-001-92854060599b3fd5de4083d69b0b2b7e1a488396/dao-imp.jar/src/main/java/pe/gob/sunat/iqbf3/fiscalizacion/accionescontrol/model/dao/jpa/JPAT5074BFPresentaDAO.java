package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.RegistroPresentacionBf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5074BFPresentaDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT5074BFPresentaDAO extends AbstractDAOImpl<RegistroPresentacionBf, Long> implements T5074BFPresentaDAO{

	public JPAT5074BFPresentaDAO() {
		super(RegistroPresentacionBf.class);
	}

}
