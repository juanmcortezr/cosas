package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.CabezeraCpeBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.CabezeraCpe;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T4241CabCpeDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT4241CabCpeDAO extends AbstractDAOImpl<CabezeraCpe, Long> implements T4241CabCpeDAO  {

	private static final Logger logger = LoggerFactory.getLogger(JPAT4241CabCpeDAO.class);
	
	public JPAT4241CabCpeDAO(){
		super(CabezeraCpe.class);
	}
	
	@Override
	public List<CabezeraCpe> listarDestinatariosGreNoConfirmadas(CabezeraCpeBean cabezeraCpeBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		/**
		 * 	#cCodTipoDestinatario#= constantes.COD_TIP_DESTNATARIO
		 * 	#iCodRelacionTransportistaRemitente#= constantes.COD_RELACION_TRANSPORTISTA_REMITENTE
		 * 
		 * 	#cIndEstActivo# = constantes.REGISTRO_ACTIVO
		 * 	#cCodCPETransportista#= constantes.COD_TIP_GUIA_TRANSPORTISTA
		 * 	#cIndEstActivo#= constantes.IND_ESTADO_ACTIVO_GUIA
		 *    
		 * 
		 * cabezeraCpeBean.setCodTipoDestinatario(AccionesControlConstantes.COD_TIP_DESTNATARIO);
		5)
		cabezeraCpeBean.setCodRelacionTransportistaRemitente(AccionesControlConstantes.COD_RELACION_TRANSPORTISTA_REMITENTE);
		cabezeraCpeBean.setCodCPETransportista(AccionesControlConstantes.COD_TIP_GUIA_TRANSPORTISTA);
		cabezeraCpeBean.setCodCPEGuiaRemision(AccionesControlConstantes.COD_TIP_GUIA_REMITENTE);
		cabezeraCpeBean.setIndEstado(AccionesControlConstantes.IND_ESTADO_ACTIVO_GUIA);
		cabezeraCpeBean.setCodTipoDocumento(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC);//COD_TIP_DOCIDENT_RUC
		cabezeraCpeBean.setCodTipoTrasladoPublico(AccionesControlConstantes.COD_TIP_TRASLADO_PUBLICO);
		*/
		
		builder.append("SELECT DISTINCT ")
				.append("cb.num_ruc as numRuc,  ")
				.append("cb.num_docide_recep as numDocumentoRecepcion,  ")
				.append("cb.cod_docide_recep as codDocumenotRecepcion,  ")
				.append("cb.cod_cpe as codCpe,  ")
				.append("cb.num_serie_cpe as numSerieCpe,  ")
				.append("cb.num_cpe as numCpe,  ")// Integer
				.append("cb.fec_emision  as fecEmision ")
				.append("FROM T4241cabcpe cb ")
				.append("INNER JOIN t5228datcompleme c ")
				.append("ON cb.num_ruc = c.num_ruc   ")
				.append("AND cb.cod_cpe = c.cod_cpe  ")
				.append("AND cb.num_serie_cpe = c.num_serie_cpe  ")
				.append("AND cb.num_cpe = c.num_cpe   ")
				.append("LEFT OUTER JOIN T5257confir b   ")
				.append("ON cb. num_ruc = b. num_ruc AND cb.cod_cpe = b.cod_cpe   ")
				.append("AND cb. num_serie_cpe = b. num_serie_cpe AND cb.num_cpe = b.num_cpe   ")
				.append("AND b.num_ruc_confir =cb.num_docide_recep  ");
		
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoDestinatario())) {
			 		builder.append("AND b.cod_tipo = ?cCodTipoDestinatario  ");// --destinatario
			 		params.addProperty("cCodTipoDestinatario", cabezeraCpeBean.getCodTipoDestinatario());
				}
				
		builder.append("LEFT OUTER JOIN T4429DOCREL d   ")
				.append("ON cb.num_ruc = d.num_ruc_rel  ")
				.append("AND cb.cod_cpe = d.cod_doc_rel  ")
				.append("AND cb.num_serie_cpe = d.num_serie_doc_rel  ")
				.append("AND cb.num_cpe = d.num_doc_rel  ");

		    if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodRelacionTransportistaRemitente())) {
			 		builder.append("AND d.cod_relacion = ?iCodRelacionTransportistaRemitente  ");//-- asociado RELACION_TRANSPORTISTA_REMITENTE
			 		params.addProperty("iCodRelacionTransportistaRemitente", cabezeraCpeBean.getCodRelacionTransportistaRemitente());
				}		
	
		builder.append("LEFT JOIN T4241cabcpe t   ")//---transportitas
				.append("ON t.num_ruc = d.num_ruc  ")
				.append("AND t.cod_cpe = d.cod_cpe  ")
				.append("AND t.num_serie_cpe = d.num_serie_cpe  ")
				.append("AND t.num_cpe = d.num_cpe  ");
				
			if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getIndEstado())) {
				builder.append("AND t.ind_estado = ?cIndEstActivo   ");//---transportista emitida
				params.addProperty("cIndEstActivo", cabezeraCpeBean.getIndEstado());
			}
				
			if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodCPETransportista())) {
				builder.append("AND t.cod_cpe = ?cCodCPETransportista  "); //--transportista
				params.addProperty("cCodCPETransportista", cabezeraCpeBean.getCodCPETransportista());
			}
						
				builder.append("AND t.num_serie_cpe = 'G001' ")
				.append("WHERE b. num_ruc IS NULL  ")
				.append("AND b.cod_cpe IS NULL  ")
				.append("AND b. num_serie_cpe IS NULL  ")
				.append("AND b.num_cpe IS NULL  ");
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getIndEstado())) {
					builder.append("AND cb.ind_estado = ?cIndEstActivo  ");//----emitida
					params.addProperty("cIndEstActivo", cabezeraCpeBean.getIndEstado());
					
				}
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodCPEGuiaRemision())) {
					builder.append("AND cb.cod_cpe = ?cCodCPEGuiaRemision  ");//---- Guia remitente
					params.addProperty("cCodCPEGuiaRemision", cabezeraCpeBean.getCodCPEGuiaRemision());
				}
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoDocumento())) {
					builder.append("AND cb.cod_docide_recep = ?iTipDocRuc  ");//---solo RUC 
					params.addProperty("iTipDocRuc", cabezeraCpeBean.getCodTipoDocumento());
				}
				
				builder.append("AND cb.num_serie_cpe = 'G001'  ");
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getFecEmision())) {
					builder.append("AND TO_CHAR(cb.fec_emision,'%Y%m') >= ?fecEmision AND  TO_CHAR(cb.fec_emision,'%Y%m') <= ?fecEmision  ");
					params.addProperty("fecEmision", cabezeraCpeBean.getFecEmision());
				}
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoTrasladoPublico())) {
					builder.append("AND NOT (c.cod_tip_traslado = ?iCodTipoTrasladoPublico  ");
					params.addProperty("iCodTipoTrasladoPublico", cabezeraCpeBean.getCodTipoTrasladoPublico());
				}
				builder.append("AND t.num_ruc IS NULL AND t.cod_cpe IS NULL AND t.num_cpe IS NULL AND t.num_serie_cpe IS NULL) ");
		
		
		
	 	logger.debug(String.format("JPAT4241CabCpeDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCCPE, CabezeraCpe.class);
	}
	
	@Override
	public List<CabezeraCpe> listarTransportistasGreNoConfirmadas(CabezeraCpeBean cabezeraCpeBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		/*
		Par�metros:
			1#iCodTipoPersonaTransportista#  = C�digo del tipo de persona transportista
			2#cCodTipoTransportista# = c�digo del transportista 
			3#cIndEstActivo#   = Estado de la Guia 
			4#cCodCPEGuiaRemision# = c�digo del tipo de gu�a remitente 
			5#iCodTipoTrasladoPublico#= c�digo del tipo de traslado publico 
			6#periodoInicio#   = Periodo inicio
			7#periodoFin# = Periodo Fin 
		*/
		/*
		 * 
		 *  cabezeraCpeBean.setCodTipoTransportista(AccionesControlConstantes.COD_TIP_TRANSPORTISTA);//
	 		cabezeraCpeBean.setCodTipoPersonaTransportista(AccionesControlConstantes.COD_TIP_PERSONA_TRANSPORTISTA);//
	 		cabezeraCpeBean.setCodCPEGuiaRemision(AccionesControlConstantes.COD_TIP_GUIA_REMITENTE);//
	 		cabezeraCpeBean.setCodTipoTrasladoPublico(AccionesControlConstantes.COD_TIP_TRASLADO_PUBLICO);//
	 		cabezeraCpeBean.setIndEstado(AccionesControlConstantes.IND_ESTADO_ACTIVO_GUIA);//
	 		cabezeraCpeBean.setPeriodoInicio(MaestrosUtilidades.stringToDateDDMMYYYY(bProgramacion.getPerInicio()));
	 		cabezeraCpeBean.setPeriodoFin(MaestrosUtilidades.stringToDateDDMMYYYY(bProgramacion.getPerFin()));
		 */
	
		builder.append("SELECT ")
				.append("pr.num_doc_ident as numDocumentoVinculado,  ")
				.append("pr.cod_tip_doc_ident as tipoDocumentoVinculado ")
				.append("FROM T4241cabcpe cb  ")
				.append("INNER JOIN t5228datcompleme c ON cb.num_ruc = c.num_ruc   ")
				.append("AND cb.cod_cpe = c.cod_cpe   ")
				.append("AND cb.num_serie_cpe = c.num_serie_cpe  ")
				.append("AND cb.num_cpe = c.num_cpe  ")
				.append("INNER JOIN t5231persorelac pr ON cb.num_ruc = pr.num_ruc  ")
				.append("AND cb.cod_cpe = pr.cod_cpe   ")
				.append("AND cb.num_serie_cpe = pr.num_serie_cpe   ")
				.append("AND cb.num_cpe = pr.num_cpe  ");

				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoPersonaTransportista())) {
				  builder.append("AND pr.cod_tipo_persona =  ?iCodTipoPersonaTransportista "); //transportista
				  params.addProperty("iCodTipoPersonaTransportista", cabezeraCpeBean.getCodTipoPersonaTransportista());
				}
				
		builder.append("LEFT OUTER JOIN T5257confir b   ")
				.append("ON cb.num_ruc = b.num_ruc   ")
				.append("AND cb.cod_cpe = b.cod_cpe  ")
				.append("AND cb.num_serie_cpe = b.num_serie_cpe  ")
				.append("AND cb.num_cpe = b.num_cpe   ")
				.append("AND b.num_ruc_confir = pr.num_doc_ident "); //--ruc del transportista
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoTransportista())) {
				  builder.append("AND b.cod_tipo = ?cCodTipoTransportista "); // --transportista
				  params.addProperty("cCodTipoTransportista", cabezeraCpeBean.getCodTipoTransportista());
				}
		
		builder.append("WHERE b.num_ruc IS NULL   ")
				.append("AND b.cod_cpe IS NULL   ")
				.append("AND b.num_serie_cpe IS NULL  ")
				.append("AND b.num_cpe IS NULL  ");
		
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getIndEstado())) {
					builder.append("AND cb.ind_estado = ?cIndEstActivo ");//  --emitida
					params.addProperty("cIndEstActivo", cabezeraCpeBean.getIndEstado());
				}
				
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodCPEGuiaRemision())) {
					builder.append("AND cb.cod_cpe = ?cCodCPEGuiaRemision "); // -- Guia remitente
					params.addProperty("cCodCPEGuiaRemision", cabezeraCpeBean.getCodCPEGuiaRemision());
				}

		 builder.append("AND cb.num_serie_cpe = 'G001' ");
		 
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoTrasladoPublico())) {
				    builder.append("AND c.cod_tip_traslado = ?iCodTipoTrasladoPublico "); //-- Publico
					params.addProperty("iCodTipoTrasladoPublico", cabezeraCpeBean.getCodTipoTrasladoPublico());
				}
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getPeriodoInicio()) &&
					!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getPeriodoFin())
					)
				{
					builder.append("AND TO_CHAR(cb.fec_emision,'%Y%m') >= ?periodoInicio  ");
					params.addProperty("periodoInicio", cabezeraCpeBean.getPeriodoInicio());
					
					builder.append("AND TO_CHAR(cb.fec_emision,'%Y%m') <= ?periodoFin ");
					params.addProperty("periodoFin", cabezeraCpeBean.getPeriodoFin());
				}
						
	 	logger.debug(String.format("JPAT4241CabCpeDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCCPE, CabezeraCpe.class);
	}
	
	@Override
	public List<CabezeraCpe> listarGreNoConfirmadasPorTransportista(CabezeraCpeBean cabezeraCpeBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		/*
		Par�metros:
			#iCodTipoPersonaTransportista#  = C�digo del tipo de persona transportista
			#cCodTipoTransportista# = c�digo del transportista 
			#cIndEstActivo#   = Estado de la Guia 
			#cCodCPEGuiaRemision# = c�digo del tipo de gu�a remitente 
			#iCodTipoTrasladoPublico#= c�digo del tipo de traslado publico 
			#periodoInicio#   = Periodo inicio
			#periodoFin# = Periodo Fin 
			#numDocumento#
		*/
		/*
		 * 
		 *  cabezeraCpeBean.setCodTipoTransportista(AccionesControlConstantes.COD_TIP_TRANSPORTISTA);
	 		cabezeraCpeBean.setCodTipoPersonaTransportista(AccionesControlConstantes.COD_TIP_PERSONA_TRANSPORTISTA);
	 		cabezeraCpeBean.setCodCPEGuiaRemision(AccionesControlConstantes.COD_TIP_GUIA_REMITENTE);
	 		cabezeraCpeBean.setCodTipoTrasladoPublico(AccionesControlConstantes.COD_TIP_TRASLADO_PUBLICO);
	 		cabezeraCpeBean.setIndEstado(AccionesControlConstantes.IND_ESTADO_ACTIVO_GUIA);
	 		cabezeraCpeBean.setPeriodoInicio(MaestrosUtilidades.stringToDateDDMMYYYY(bProgramacion.getPerInicio()));
	 		cabezeraCpeBean.setPeriodoFin(MaestrosUtilidades.stringToDateDDMMYYYY(bProgramacion.getPerFin()));
	 		cabezeraCpeBean.getNumDocumentoRecepcion();
		 */
		
		builder.append("SELECT ")
				.append("cb.num_ruc as numRuc,  ")
				.append("pr.num_doc_ident as numDocumentoVinculado,  ")
				.append("pr.cod_tip_doc_ident as tipoDocumentoVinculado,  ")
				.append("cb.cod_cpe as codCpe,  ")
				.append("cb.num_serie_cpe as numSerieCpe,  ")
				.append("cb.num_cpe numCpe,  ")
				.append("cb.fec_emision as fecEmision ")
				.append("FROM T4241cabcpe cb  ")
				.append("INNER JOIN t5228datcompleme c ON cb.num_ruc = c.num_ruc   ")
				.append("AND cb.cod_cpe = c.cod_cpe   ")
				.append("AND cb.num_serie_cpe = c.num_serie_cpe  ")
				.append("AND cb.num_cpe = c.num_cpe  ")
				.append("INNER JOIN t5231persorelac pr ON cb.num_ruc = pr.num_ruc  ")
				.append("AND cb.cod_cpe = pr.cod_cpe   ")
				.append("AND cb.num_serie_cpe = pr.num_serie_cpe   ")
				.append("AND cb.num_cpe = pr.num_cpe  ");

				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoPersonaTransportista())) {
				  builder.append("AND pr.cod_tipo_persona =  ?iCodTipoPersonaTransportista "); //transportista
				  params.addProperty("iCodTipoPersonaTransportista", cabezeraCpeBean.getCodTipoPersonaTransportista());
				}
				
		builder.append("LEFT OUTER JOIN T5257confir b   ")
				.append("ON cb.num_ruc = b.num_ruc   ")
				.append("AND cb.cod_cpe = b.cod_cpe  ")
				.append("AND cb.num_serie_cpe = b.num_serie_cpe  ")
				.append("AND cb.num_cpe = b.num_cpe   ")
				.append("AND b.num_ruc_confir = pr.num_doc_ident "); //--ruc del transportista
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoTransportista())) {
				  builder.append("AND b.cod_tipo = ?cCodTipoTransportista "); // --transportista
				  params.addProperty("cCodTipoTransportista", cabezeraCpeBean.getCodTipoTransportista());
				}
		
		builder.append("WHERE b.num_ruc IS NULL   ")
				.append("AND b.cod_cpe IS NULL   ")
				.append("AND b.num_serie_cpe IS NULL  ")
				.append("AND b.num_cpe IS NULL  ");
		
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getIndEstado())) {
					builder.append("AND cb.ind_estado = ?cIndEstActivo ");//  --emitida
					params.addProperty("cIndEstActivo", cabezeraCpeBean.getIndEstado());
				}
				
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodCPEGuiaRemision())) {
					builder.append("AND cb.cod_cpe = ?cCodCPEGuiaRemision "); // -- Guia remitente
					params.addProperty("cCodCPEGuiaRemision", cabezeraCpeBean.getCodCPEGuiaRemision());
				}

		 builder.append("AND cb.num_serie_cpe = 'G001' ");
		 
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoTrasladoPublico())) {
				    builder.append("AND c.cod_tip_traslado = ?iCodTipoTrasladoPublico "); //-- Publico
					params.addProperty("iCodTipoTrasladoPublico", cabezeraCpeBean.getCodTipoTrasladoPublico());
				}
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getPeriodoInicio()) &&
					!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getPeriodoFin())
					)
				{
					builder.append("AND TO_CHAR(cb.fec_emision,'%Y%m') >= ?periodoInicio  ");
					params.addProperty("periodoInicio", cabezeraCpeBean.getPeriodoInicio());
					
					builder.append("AND TO_CHAR(cb.fec_emision,'%Y%m') <= ?periodoFin ");
					params.addProperty("periodoFin", cabezeraCpeBean.getPeriodoFin());
				}
				
		
		if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getNumDocumentoRecepcion())) {
			builder.append(" AND  pr.num_doc_ident= ?numDocumento ");
			params.addProperty("numDocumento", cabezeraCpeBean.getNumDocumentoRecepcion());
		}
		
	 	logger.debug(String.format("JPAT4241CabCpeDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, CabezeraCpe.class);
	}
	
	@Override
	public List<CabezeraCpe> listarGreNoConfirmadasPorDestinatario(CabezeraCpeBean cabezeraCpeBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		/**
		 * 	#cCodTipoDestinatario#= constantes.COD_TIP_DESTNATARIO
		 * 	#iCodRelacionTransportistaRemitente#= constantes.COD_RELACION_TRANSPORTISTA_REMITENTE
		 * 
		 * 	#cIndEstActivo# = constantes.REGISTRO_ACTIVO
		 * 	#cCodCPETransportista#= constantes.COD_TIP_GUIA_TRANSPORTISTA
		 * 	#cIndEstActivo#= constantes.IND_ESTADO_ACTIVO_GUIA
		 *    
		 * 
		 * cabezeraCpeBean.setCodTipoDestinatario(AccionesControlConstantes.COD_TIP_DESTNATARIO);
		5)
		cabezeraCpeBean.setCodRelacionTransportistaRemitente(AccionesControlConstantes.COD_RELACION_TRANSPORTISTA_REMITENTE);
		cabezeraCpeBean.setCodCPETransportista(AccionesControlConstantes.COD_TIP_GUIA_TRANSPORTISTA);
		cabezeraCpeBean.setCodCPEGuiaRemision(AccionesControlConstantes.COD_TIP_GUIA_REMITENTE);
		cabezeraCpeBean.setIndEstado(AccionesControlConstantes.IND_ESTADO_ACTIVO_GUIA);
		cabezeraCpeBean.setCodTipoDocumento(AccionesControlConstantes.COD_TIP_DOCUMENTO_IDENT_RUC);//COD_TIP_DOCIDENT_RUC
		cabezeraCpeBean.setCodTipoTrasladoPublico(AccionesControlConstantes.COD_TIP_TRASLADO_PUBLICO);
		*/
		
		
		builder.append("SELECT DISTINCT ")
				.append("cb.num_ruc as numRuc,  ")
				.append("cb.num_docide_recep as numDocumentoRecepcion,  ")
				.append("cb.cod_docide_recep as codDocumenotRecepcion,  ")
				.append("cb.cod_cpe as codCpe,  ")
				.append("cb.num_serie_cpe as numSerieCpe,  ")
				.append("cb.num_cpe as numCpe,  ")// Integer
				.append("cb.fec_emision  as fecEmision  ")
				.append("FROM T4241cabcpe cb ")
				.append("INNER JOIN t5228datcompleme c ")
				.append("ON cb.num_ruc = c.num_ruc   ")
				.append("AND cb.cod_cpe = c.cod_cpe  ")
				.append("AND cb.num_serie_cpe = c.num_serie_cpe  ")
				.append("AND cb.num_cpe = c.num_cpe   ")
				.append("LEFT OUTER JOIN T5257confir b   ")
				.append("ON cb. num_ruc = b. num_ruc AND cb.cod_cpe = b.cod_cpe   ")
				.append("AND cb. num_serie_cpe = b. num_serie_cpe AND cb.num_cpe = b.num_cpe   ")
				.append("AND b.num_ruc_confir =cb.num_docide_recep  ");
		
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoDestinatario())) {
			 		builder.append("AND b.cod_tipo = ?cCodTipoDestinatario  ");// --destinatario
			 		params.addProperty("cCodTipoDestinatario", cabezeraCpeBean.getCodTipoDestinatario());
				}
				
		builder.append("LEFT OUTER JOIN T4429DOCREL d   ")
				.append("ON cb.num_ruc = d.num_ruc_rel  ")
				.append("AND cb.cod_cpe = d.cod_doc_rel  ")
				.append("AND cb.num_serie_cpe = d.num_serie_doc_rel  ")
				.append("AND cb.num_cpe = d.num_doc_rel  ");

		    if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodRelacionTransportistaRemitente())) {
			 		builder.append("AND d.cod_relacion = ?iCodRelacionTransportistaRemitente  ");//-- asociado RELACION_TRANSPORTISTA_REMITENTE
			 		params.addProperty("iCodRelacionTransportistaRemitente", cabezeraCpeBean.getCodRelacionTransportistaRemitente());
				}		
	
		builder.append("LEFT JOIN T4241cabcpe t   ")//---transportitas
				.append("ON t.num_ruc = d.num_ruc  ")
				.append("AND t.cod_cpe = d.cod_cpe  ")
				.append("AND t.num_serie_cpe = d.num_serie_cpe  ")
				.append("AND t.num_cpe = d.num_cpe  ");
				
			if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getIndEstado())) {
				builder.append("AND t.ind_estado = ?cIndEstActivo   ");//---transportista emitida
				params.addProperty("cIndEstActivo", cabezeraCpeBean.getIndEstado());
			}
				
			if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodCPETransportista())) {
				builder.append("AND t.cod_cpe = ?cCodCPETransportista  "); //--transportista
				params.addProperty("cCodCPETransportista", cabezeraCpeBean.getCodCPETransportista());
			}
						
				builder.append("AND t.num_serie_cpe = 'G001' ")
				.append("WHERE b. num_ruc IS NULL  ")
				.append("AND b.cod_cpe IS NULL  ")
				.append("AND b. num_serie_cpe IS NULL  ")
				.append("AND b.num_cpe IS NULL  ");
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getIndEstado())) {
					builder.append("AND cb.ind_estado = ?cIndEstActivo  ");//----emitida
					params.addProperty("cIndEstActivo", cabezeraCpeBean.getIndEstado());
					
				}
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodCPEGuiaRemision())) {
					builder.append("AND cb.cod_cpe = ?cCodCPEGuiaRemision  ");//---- Guia remitente
					params.addProperty("cCodCPEGuiaRemision", cabezeraCpeBean.getCodCPEGuiaRemision());
				}
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoDocumento())) {
					builder.append("AND cb.cod_docide_recep = ?iTipDocRuc  ");//---solo RUC 
					params.addProperty("iTipDocRuc", cabezeraCpeBean.getCodTipoDocumento());
				}
				
				builder.append("AND cb.num_serie_cpe = 'G001'  ");
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getFecEmision())) {
					builder.append("AND TO_CHAR(cb.fec_emision,'%Y%m') >= ?fecEmision AND  TO_CHAR(cb.fec_emision,'%Y%m') <= ?fecEmision  ");
					params.addProperty("fecEmision", cabezeraCpeBean.getFecEmision());
				}
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getCodTipoTrasladoPublico())) {
					builder.append("AND NOT (c.cod_tip_traslado = ?iCodTipoTrasladoPublico  ");
					params.addProperty("iCodTipoTrasladoPublico", cabezeraCpeBean.getCodTipoTrasladoPublico());
				}
				builder.append("AND t.num_ruc IS NULL AND t.cod_cpe IS NULL AND t.num_cpe IS NULL AND t.num_serie_cpe IS NULL) ");
				
				
				if (!MaestrosUtilidades.isEmpty(cabezeraCpeBean.getNumDocumentoRecepcion())) {
					builder.append("AND  cb.cod_docide_recep= ?numDocumento ");
					params.addProperty("numDocumento", cabezeraCpeBean.getNumDocumentoRecepcion());
				}
		
		
	 	logger.debug(String.format("JPAT4241CabCpeDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, CabezeraCpe.class);
	}
}
