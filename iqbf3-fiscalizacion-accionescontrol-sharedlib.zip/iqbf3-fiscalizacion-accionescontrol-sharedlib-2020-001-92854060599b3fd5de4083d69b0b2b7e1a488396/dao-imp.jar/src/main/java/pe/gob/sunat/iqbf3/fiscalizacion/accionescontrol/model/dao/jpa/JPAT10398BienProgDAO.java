package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10398BienProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10398BienProgDAO extends AbstractDAOImpl<BienProgramacion, Integer> implements T10398BienProgDAO {

	public JPAT10398BienProgDAO() {
		super(BienProgramacion.class);
	}

}
