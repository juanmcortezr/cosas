package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10426TipInconSoliDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10426TipInconSoliDAO extends AbstractDAOImpl<TipoInconsistenciaSolicitud, Long> implements T10426TipInconSoliDAO{

	public JPAT10426TipInconSoliDAO() {
		super(TipoInconsistenciaSolicitud.class);
	}

	



}
