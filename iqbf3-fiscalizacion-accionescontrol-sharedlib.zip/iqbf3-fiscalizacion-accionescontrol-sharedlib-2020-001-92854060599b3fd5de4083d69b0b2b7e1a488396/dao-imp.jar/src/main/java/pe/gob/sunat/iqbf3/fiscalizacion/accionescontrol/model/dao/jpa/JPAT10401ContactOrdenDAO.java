package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ContactoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10401ContactOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10401ContactOrdenDAO extends AbstractDAOImpl<ContactoOrden, Long> implements T10401ContactOrdenDAO  {
	
	private static final Logger logger = LoggerFactory.getLogger(JPAT10401ContactOrdenDAO.class);

	public JPAT10401ContactOrdenDAO(){
		super(ContactoOrden.class);
	}

	@Override
	public List<ContactoOrden> listarContacto(Long numOrden) {
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ")
		.append(" num_contacto as numContacto, ")
		.append(" cod_tip_docident as codTipoDocumentoIdentif, ")
		.append(" num_doc_ident as numDocumentoIdentif, ")
		.append(" nom_ape_cont as nomApellidoContacto, ")
		.append(" des_cargo as desCargo, ")
		.append(" num_telefono as numTelefono, ")
		.append(" num_orden as numOrden ")
		.append(" FROM t10401contactorden ");
		
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			builder.append(" WHERE num_orden = ?numOrden ");
			params.addProperty("numOrden", numOrden);
		}
		
		builder.append(" AND ind_del = ?indDel AND ind_est = ?indEst ");
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		logger.debug(String.format("JPAT10401ContactOrdenDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ContactoOrden.class);
	}
	
	
	@Override
	public int actualizarContactoOrden(ContactoOrden contactoOrden) {
		int resultado=0;
		
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
				
		builder.append("UPDATE t10401contactorden c SET ");
		builder.append(" c.fec_modif=SYSDATE ");
		if(!MaestrosUtilidades.isEmpty(contactoOrden.getCodTipoDocumentoIdentif()))builder.append(" ,c.COD_TIP_DOCIDENT = ?3");
		if(!MaestrosUtilidades.isEmpty(contactoOrden.getDesCargo()))builder.append(" ,c.DES_CARGO = ?4");
		if(!MaestrosUtilidades.isEmpty(contactoOrden.getNomApellidoContacto()))builder.append(" ,c.NOM_APE_CONT = ?5");
		if(!MaestrosUtilidades.isEmpty(contactoOrden.getNumOrden())&&contactoOrden.getNumOrden()>0)builder.append(" ,c.NUM_ORDEN = ?6");
		if(!MaestrosUtilidades.isEmpty(contactoOrden.getNumDocumentoIdentif()))builder.append(" ,c.NUM_DOC_IDENT = ?7");
		if(!MaestrosUtilidades.isEmpty(contactoOrden.getNumTelefono()))builder.append(" ,c.NUM_TELEFONO = ?8");
		if(contactoOrden.isIndEliminar()) {
		builder.append(" ,c.IND_DEL = ?9");
		builder.append(" ,c.IND_EST = ?10");
		}
		if(!MaestrosUtilidades.isEmpty(contactoOrden.getCodUsuModif()))builder.append(" ,c.COD_USUMODIF = ?11");
		if(!MaestrosUtilidades.isEmpty(contactoOrden.getDirIpusumodif()))builder.append(" ,c.DIR_IPUSUMODIF = ?12");
		
		builder.append(" WHERE 1=1 ");
		if(!MaestrosUtilidades.isEmpty(contactoOrden.getNumContacto())&&contactoOrden.getNumContacto()>0)builder.append(" AND c.NUM_CONTACTO = ?1 ");
		
		Query query = entityManager.createNativeQuery(builder.toString());
		
		query.setParameter(1 , contactoOrden.getNumContacto());
		query.setParameter(3 , contactoOrden.getCodTipoDocumentoIdentif());
		query.setParameter(4 , contactoOrden.getDesCargo());
		query.setParameter(5 , contactoOrden.getNomApellidoContacto());
		query.setParameter(6 , contactoOrden.getNumOrden());
		query.setParameter(7 , contactoOrden.getNumDocumentoIdentif());
		query.setParameter(8 , contactoOrden.getNumTelefono());
		if(contactoOrden.isIndEliminar()) {
		query.setParameter(9 , MaestrosConstantes.REGISTRO_ELIMINADO);
		query.setParameter(10 , MaestrosConstantes.REGISTRO_INACTIVO);
		}
		query.setParameter(11, contactoOrden.getCodUsuModif());
		query.setParameter(12 , contactoOrden.getDirIpusumodif());
			
		logger.debug(String.format("JPAT10401ContactOrdenDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10401ContactOrdenDAO: query => %s", builder.toString()));
		
		resultado =	query.executeUpdate();
		
		return resultado;
	}
}
