package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DetalleResultadoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10404DetaResOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10404DetaResOrdenDAO extends AbstractDAOImpl<DetalleResultadoOrden, Long> implements T10404DetaResOrdenDAO  {
	private static final Logger logger = LoggerFactory.getLogger(JPAT10404DetaResOrdenDAO.class);
	public JPAT10404DetaResOrdenDAO(){
		super(DetalleResultadoOrden.class);
	}
	
	@Override
	public List<DetalleResultadoOrden> listarDetaResultado(DetalleResultadoOrden param) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10404DetaResOrdenDAO - listarDetaResultado");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ");
		builder.append("d.num_det_resulorden as numDetalleResultadoOrden,");
		builder.append("d.cod_resul_orden as codResulOrden,");
		builder.append("d.des_otro_resul as desOtroResultado, ");
		builder.append("d.ind_est as indEst ");
		builder.append("FROM    t10404detaresorden d ");
		builder.append(" WHERE 1=1 ");
		
		
		if (!MaestrosUtilidades.isEmpty(param.getNumOrden())) {
			builder.append("AND d.num_orden = ?numOrden ");
			params.addProperty("numOrden", param.getNumOrden());
		}
		if (!MaestrosUtilidades.isEmpty(param.getIndDel())) {
			builder.append("AND d.ind_del = ?indDel ");
			params.addProperty("indDel", param.getIndDel());
		}
		if (!MaestrosUtilidades.isEmpty(param.getIndEst())) {
			builder.append("AND d.ind_est = ?indEst ");
			params.addProperty("indEst", param.getIndEst());
		}
		
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DetalleResultadoOrden.class);
	}
	
	
	@Override
	public int actualizarDetaResultado(DetalleResultadoOrden model) {
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT10404DetaResOrdenDAO - actualizarDetaResultado");
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
			builder.append(" UPDATE t10404detaresorden d SET ");
			builder.append(" d.fec_modif = SYSDATE ");
			
			
			  if(model.getNumOrden()!=null&&model.getNumOrden()>0)builder.append(" ,d.num_orden = ?2 ");
			  if(model.getCodResulOrden()!=null)builder.append(" ,d.cod_resul_orden = ?3 ");
			  if(!MaestrosUtilidades.isEmpty(model.getIndDel()))builder.append(" ,d.ind_del = ?4 "); 
			  if(!MaestrosUtilidades.isEmpty(model.getIndEst()))builder.append(" ,d.ind_est = ?5 ");       
			  if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,d.cod_usumodif = ?6 ");
			  if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,d.dir_ipusumodif = ?7 ");
			  if(model.getDesOtroResultado()!=null)builder.append(" ,d.des_otro_resul = ?8 ");
		  	
		  builder.append(" WHERE 1=1 ");
		  
		  if(model.getNumDetalleResultadoOrden()!=null&&model.getNumDetalleResultadoOrden()>0)builder.append(" AND d.num_det_resulorden = ?1 ");
		  if(model.getNumOrden()!=null&&model.getNumOrden()>0)builder.append(" AND d.num_orden = ?2 ");
		  
		Query query = entityManager.createNativeQuery(builder.toString());
		
				query.setParameter(1, model.getNumDetalleResultadoOrden());
				query.setParameter(2, model.getNumOrden());
				query.setParameter(3, model.getCodResulOrden());
				query.setParameter(4, model.getIndDel());
				query.setParameter(5, model.getIndEst());
				query.setParameter(6, model.getCodUsuModif());
				query.setParameter(7, model.getDirIpusumodif());
				query.setParameter(8, model.getDesOtroResultado());
				
				
		logger.debug(String.format("JPAT10404DetaResOrdenDAO: query => %s", builder.toString()));
		return query.executeUpdate();
	}
	
	
}
