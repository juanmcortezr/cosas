package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10445ArcAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10445ArcAcfDAO  extends AbstractDAOImpl<ArchivoAcciones, Long> implements T10445ArcAcfDAO {

	public JPAT10445ArcAcfDAO() {
		super(ArchivoAcciones.class);
	}
	
}
