package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AccionSugeridaCalif;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10444AccSugeCalifDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10444AccSugeCalifDAO extends AbstractDAOImpl<AccionSugeridaCalif, Long> implements T10444AccSugeCalifDAO {

	public JPAT10444AccSugeCalifDAO() {
		super(AccionSugeridaCalif.class);
	}
	
	@Override
	public List<AccionSugeridaCalif> listarAccionesSugeridas(String indEst){
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT num_acc_sugerida as numAccionSugerida , des_acc_sugerida as desAccionSugerida ,cast(val_minimo as Varchar(30)) as strValMinimo, cast(val_maximo as Varchar(30)) as strValMaximo , ind_est_accsuge as indEstadoAccionSugerida FROM t10444accsugecalif WHERE ind_del=0 ");

           	if (!MaestrosUtilidades.isEmpty(indEst)) {
    			builder.append(" AND ind_est_accsuge = ?indEst ");
    			params.addProperty("indEst", indEst);
    		}
           	
           	System.out.println("10listarAccionesSugeridasJPA=> "+builder.toString());
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, AccionSugeridaCalif.class);
		
	}

}
