package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10429UsuarioSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10429UsuarioSolicDAO extends AbstractDAOImpl<UsuarioSolicitud, Long> implements T10429UsuarioSolicDAO{

	private static final Logger logger = LoggerFactory.getLogger(JPAT10429UsuarioSolicDAO.class);

	public JPAT10429UsuarioSolicDAO() {
		super(UsuarioSolicitud.class);
	}

	@Override
	public List<UsuarioSolicitud> listarUsuariosSolicitud(UsuarioSolicitud parametro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10429UsuarioSolicDAO - listarUsuariosSolicitud");
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT A.num_usu_solic as numUsuarioSolicitud, A.cod_tip_docident as codTipoDocumentoIdentif, A.num_doc_ident as numDocumentoIdentif, A.nom_ape_usu as nomApellidoUsuario,")
			   .append("A.cod_tip_docrefer as codTipoDocumentoReferencia, A.num_doc_refer as numDocumentoReferencia, A.cod_tip_interv as codTipoIntervencion, A.cod_tip_accion as codTipoAccion, ") 
			   .append("A.num_arc as numArc, (SELECT COUNT (*) FROM t10427tipinconusu  B WHERE A.num_usu_solic=B.num_usu_solic AND B.ind_del=?indDel AND B.ind_est=?indEst) as totalInconsistencia, ") 
			   .append("(SELECT COUNT (*) FROM t10397bienfiscausu C WHERE A.num_usu_solic=C.num_usu_solic AND C.ind_del=?indDel AND C.ind_est=?indEst) as totalBien, ") 
			   .append("(SELECT COUNT (*) FROM t10412medioprobusu E WHERE A.num_usu_solic=E.num_usu_solic AND E.ind_del=?indDel AND E.ind_est=?indEst) as totalMedioProbatorio, ") 
			   .append("D.val_calificacion as valCalificacionPreliminar FROM t10429usuariosolic A LEFT JOIN t10400caliusua D ON A.num_usu_solic=D.num_usu_solic ") 
			   .append("AND D.ind_tip_cali= ?indTipCali WHERE A.ind_del=?indDel AND A.num_solic_prog = ?numSolicitud ");
		params.addProperty("indDel", parametro.getIndDel());
		params.addProperty("indEst", parametro.getIndEst());
		params.addProperty("indTipCali", AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR);
		params.addProperty("numSolicitud", parametro.getNumSolicitud());
		logger.debug(String.format("listarUsuariosSolicitud:query => %s", builder.toString()));
		logger.debug(String.format("listarUsuariosSolicitud:indDel => %s",  parametro.getIndDel()));
		logger.debug(String.format("listarUsuariosSolicitud:indEst => %s",  parametro.getIndEst()));
		logger.debug(String.format("listarUsuariosSolicitud:indTipCali => %s",  AccionesControlConstantes.COD_TIP_CALI_PRELIMINAR));
		logger.debug(String.format("listarUsuariosSolicitud:numSolicitud => %d",  parametro.getNumSolicitud()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, UsuarioSolicitud.class);
	}

	@Override
	@SuppressWarnings("unchecked")
	public Integer validarTotalEstablecimientoxUsuario(UsuarioSolicitud parametro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10429UsuarioSolicDAO - validarTotalEstablecimientoxUsuario");
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("SELECT count(*) FROM t10409estabusu A, t10429usuariosolic B WHERE A.num_usu_solic=B.num_usu_solic ")
			   .append("AND B.num_solic_prog=?numSolicitud AND B.cod_tip_interv= ?codTipInterv and A.ind_del=?indDel and A.ind_est=?indEst");
		params.addProperty("codTipInterv", AccionesControlConstantes.COD_TIP_INTERVENCION_FISCALIZACION);
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		params.addProperty("numSolicitud", parametro.getNumSolicitud());

		Integer total = 0;
		List<BigDecimal> lista = (List<BigDecimal>) this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			if (!MaestrosUtilidades.isEmpty(lista.get(0))) {
				total = lista.get(0).intValue();
			}
		}
		return total;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Integer obtenerTotalUsuarioCalif(Long numSolicProg, String indTipCali) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10429UsuarioSolicDAO - obtenerTotalUsuarioCalif");
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("Select count(*) from t10421solicprog A, t10429usuariosolic B, t10400caliusua C ")
			   .append("Where  A.num_solic_prog=B.num_solic_prog AND B.num_usu_solic =C.num_usu_solic AND ") 
			   .append("A.num_solic_prog=?numSolicProg AND C.ind_tip_cali=?indTipCali");
		params.addProperty("indTipCali", indTipCali);
		params.addProperty("numSolicProg", numSolicProg);

		Integer total = 0;
		List<BigDecimal> lista = (List<BigDecimal>) this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			if (!MaestrosUtilidades.isEmpty(lista.get(0))) {
				total = lista.get(0).intValue();
			}
		}
		return total;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Integer obtenerTotalSoloUsuarioCalif(Long numSolicUsu, String indTipCali) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10429UsuarioSolicDAO - obtenerTotalSoloUsuarioCalif");
		StringBuilder builder = new StringBuilder();
		PropertyParams params = new PropertyParams();
		builder.append("Select count(*) from t10421solicprog A, t10429usuariosolic B, t10400caliusua C ")
			   .append("Where  A.num_solic_prog=B.num_solic_prog AND B.num_usu_solic =C.num_usu_solic AND ") 
			   .append("A.num_usu_solic=?numSolicUsu AND C.ind_tip_cali=?indTipCali");
		params.addProperty("indTipCali", indTipCali);
		params.addProperty("numSolicUsu", numSolicUsu);

		Integer total = 0;
		List<BigDecimal> lista = (List<BigDecimal>) this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			if (!MaestrosUtilidades.isEmpty(lista.get(0))) {
				total = lista.get(0).intValue();
			}
		}
		return total;
	}

}
