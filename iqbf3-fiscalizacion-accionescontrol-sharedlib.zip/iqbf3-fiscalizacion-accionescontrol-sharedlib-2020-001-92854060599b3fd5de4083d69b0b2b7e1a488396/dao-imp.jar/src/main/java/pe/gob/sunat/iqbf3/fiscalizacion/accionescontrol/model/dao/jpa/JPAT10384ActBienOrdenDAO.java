package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActaBienOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10384ActBienOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

@Stateless
public class JPAT10384ActBienOrdenDAO extends AbstractDAOImpl<ActaBienOrden, Integer> implements T10384ActBienOrdenDAO {
	private static final Logger logger = LoggerFactory.getLogger(JPAT10384ActBienOrdenDAO.class);
	public JPAT10384ActBienOrdenDAO() {
		super(ActaBienOrden.class);
	}

	@Override
	public int actualizarActaBien(ActaBienOrden model) {
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
		
		builder.append(" UPDATE t10384actbienorden a SET ");
		builder.append(" a.fec_modif = SYSDATE");
		  if(model.getNumBienEstablecimiento()!=null&&model.getNumBienEstablecimiento()>0)builder.append(" ,a.num_bien_estab = ?2 ");
		  if(!MaestrosUtilidades.isEmpty(model.getCodTipoActa()))builder.append(" ,a.cod_tip_acta = ?3 "); 
		  if(model.getNumActa()!=null)builder.append(" ,a.num_acta = ?4 ");   
		  if(model.getDesOtraActa()!=null)builder.append(" ,a.des_otra_acta = ?5 ");
		  if(!MaestrosUtilidades.isEmpty(model.getCodTipoDocumentoVinculado()))builder.append(" ,a.cod_tip_docvin = ?6 ");  
		  if(model.getNumDocumentoVinculado()!=null)builder.append(" ,a.num_doc_vin = ?7 "); 
		  if(model.getDesOtroDocumentoinculado()!=null)builder.append(" ,a.des_otro_docvin = ?8 ");
		  if(model.getCodTipoInforme()!=null)builder.append(" ,a.cod_tip_informe = ?9 ");
		  if(model.getDesOtroInforme()!=null)builder.append(" ,a.des_otro_informe = ?10 ");
		  if(!MaestrosUtilidades.isEmpty(model.getIndDel()))builder.append(" ,a.ind_del = ?11 ");
		  if(!MaestrosUtilidades.isEmpty(model.getIndEst()))builder.append(" ,a.ind_est = ?12 ");       
		  if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,a.cod_usumodif = ?13 ");
		  if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,a.dir_ipusumodif = ?14 ");  
		
		  builder.append(" WHERE 1=1 ");
		  
		  if(model.getNumActaBienOrden()!=null&&model.getNumActaBienOrden()>0)builder.append(" AND a.num_act_bienorden = ?1 "); 
		  if(model.getNumBienEstablecimiento()!=null&&model.getNumBienEstablecimiento()>0)builder.append(" AND a.num_bien_estab = ?2 ");
		Query query = entityManager.createNativeQuery(builder.toString());
		
		query.setParameter(1, model.getNumActaBienOrden());
		query.setParameter(2, model.getNumBienEstablecimiento());
		query.setParameter(3, model.getCodTipoActa());
		query.setParameter(4, model.getNumActa());
		query.setParameter(5, model.getDesOtraActa());
		query.setParameter(6, model.getCodTipoDocumentoVinculado());
		query.setParameter(7, model.getNumDocumentoVinculado());
		query.setParameter(8, model.getDesOtroDocumentoinculado());
		query.setParameter(9, model.getCodTipoInforme());
		query.setParameter(10, model.getDesOtroInforme());
		query.setParameter(11, model.getIndDel());
		query.setParameter(12, model.getIndEst());
		query.setParameter(13, model.getCodUsuModif());
		query.setParameter(14, model.getDirIpusumodif());
		
		
		logger.debug(String.format("JPAT10384ActBienOrdenDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10384ActBienOrdenDAO: query => %s", builder.toString()));
				
		return query.executeUpdate();
	}
	
}
