package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.HistorialEstadosPrograma;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10410HistEstadoProgDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10410HistEstadoProgDAO extends AbstractDAOImpl<HistorialEstadosPrograma, Long> implements T10410HistEstadoProgDAO  {

	public JPAT10410HistEstadoProgDAO(){
		super(HistorialEstadosPrograma.class);
	}
	
}
