package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienFiscalizadoSolicitud;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10396BienFisSolicDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT10396BienFisSolicDAO extends AbstractDAOImpl<BienFiscalizadoSolicitud, Long> implements T10396BienFisSolicDAO  {
	
	public JPAT10396BienFisSolicDAO(){
		super(BienFiscalizadoSolicitud.class);
	}

}
