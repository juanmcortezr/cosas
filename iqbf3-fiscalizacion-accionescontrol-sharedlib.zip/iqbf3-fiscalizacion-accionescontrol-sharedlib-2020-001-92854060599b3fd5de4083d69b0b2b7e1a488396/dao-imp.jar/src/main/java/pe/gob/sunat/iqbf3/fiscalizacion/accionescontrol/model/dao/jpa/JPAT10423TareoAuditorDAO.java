package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TareoAuditor;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10423TareoAuditorDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10423TareoAuditorDAO extends AbstractDAOImpl<TareoAuditor, Long> implements T10423TareoAuditorDAO{

	private static final Logger logger = LoggerFactory.getLogger(JPAT10423TareoAuditorDAO.class);
	
	public JPAT10423TareoAuditorDAO() {
		super(TareoAuditor.class);
	}

	@Override
	public List<TareoAuditor> listarTareoAuditor(TareoAuditor params) {
		
		PropertyParams param = new PropertyParams();
		StringBuilder builder =  new StringBuilder();
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10423TareoAuditorDAO - listarTareoAuditor");
		
		builder.append("SELECT ")
		.append(" num_tareo as numTareo, ")
		.append(" num_orden as numOrden, ")
		.append(" fec_actividad as fecActividad, ")
		.append(" hor_empleada as horEmpleada, ")
		.append(" des_actividad as desActividad ")
		.append(" FROM t10423tareoauditor ");
		
		if (!MaestrosUtilidades.isEmpty(params.getNumOrden())) {
			builder.append(" WHERE num_orden = ?numOrden "); //numOrden
			param.addProperty("numOrden", params.getNumOrden());
		}
		if (!MaestrosUtilidades.isEmpty(params.getIndDel())) {
			builder.append(" AND ind_del = ?indDel ");
			param.addProperty("indDel", params.getIndDel());
		}
		
		if (!MaestrosUtilidades.isEmpty(params.getIndEst())) {
			builder.append(" AND ind_est = ?indEst ");
			param.addProperty("indEst", params.getIndEst());
		}
		logger.debug(String.format("JPAT10423TareoAuditorDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), param, AccionesControlConstantes.DATASOURCE_DCSICOBF, TareoAuditor.class);
	}
	
	@Override
	public int actualizarTareoAuditor(TareoAuditor model) {
		int resultado=0;
		
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
				
		builder.append("UPDATE t10423tareoauditor t SET ");
		builder.append(" t.fec_modif=SYSDATE ");
		if(!MaestrosUtilidades.isEmpty(model.getDesActividad()))builder.append(" ,t.DES_ACTIVIDAD = ?2");
		if(!MaestrosUtilidades.isEmpty(model.getFecActividad()))builder.append(" ,t.FEC_ACTIVIDAD = ?3");
		if(!MaestrosUtilidades.isEmpty(model.getHorEmpleada()))builder.append(" ,t.HOR_EMPLEADA = ?4");
		if(model.isIndEliminar()) {
		builder.append(" ,t.IND_DEL = ?12");
		builder.append(" ,t.IND_EST = ?13");
		}
		if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,t.COD_USUMODIF = ?14");
		if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,t.DIR_IPUSUMODIF = ?15");
		if(!MaestrosUtilidades.isEmpty(model.getNumOrden())&&model.getNumOrden()>0)builder.append(" ,t.NUM_ORDEN = ?16");
		builder.append(" WHERE 1=1 ");
		if(!MaestrosUtilidades.isEmpty(model.getNumTareo())&&model.getNumTareo()>0)builder.append(" AND t.NUM_TAREO = ?1 ");
		
		Query query = entityManager.createNativeQuery(builder.toString());
		
		query.setParameter(1 , model.getNumTareo());
		query.setParameter(2 , model.getDesActividad());
		query.setParameter(3 , model.getFecActividad());
		query.setParameter(4 , model.getHorEmpleada());
		if(model.isIndEliminar()) {
		query.setParameter(12 , MaestrosConstantes.REGISTRO_ELIMINADO);
		query.setParameter(13 , MaestrosConstantes.REGISTRO_INACTIVO);
		}
		query.setParameter(14, model.getCodUsuModif());
		query.setParameter(15 , model.getDirIpusumodif());
		query.setParameter(16 , model.getNumOrden());
			
		logger.debug(String.format("JPAT10423TareoAuditorDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10423TareoAuditorDAO: query => %s", builder.toString()));
		
		resultado =	query.executeUpdate();
		
		return resultado;
	}
	
	
	
	
}
