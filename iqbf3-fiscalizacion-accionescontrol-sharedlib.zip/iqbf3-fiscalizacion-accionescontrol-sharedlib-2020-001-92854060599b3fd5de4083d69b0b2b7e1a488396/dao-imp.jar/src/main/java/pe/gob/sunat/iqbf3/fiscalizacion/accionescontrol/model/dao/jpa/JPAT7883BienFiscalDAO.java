package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienFiscal;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T7883BienFiscalDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT7883BienFiscalDAO  extends AbstractDAOImpl<BienFiscal, String> implements T7883BienFiscalDAO {

	public JPAT7883BienFiscalDAO() {
		super(BienFiscal.class);
	}

}
