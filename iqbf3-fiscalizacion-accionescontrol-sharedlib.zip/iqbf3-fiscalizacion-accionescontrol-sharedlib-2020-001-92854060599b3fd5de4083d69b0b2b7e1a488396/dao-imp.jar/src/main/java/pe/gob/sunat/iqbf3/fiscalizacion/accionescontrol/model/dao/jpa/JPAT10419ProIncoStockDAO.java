package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaStock;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10419ProIncoStockDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10419ProIncoStockDAO extends AbstractDAOImpl<ProgramaIncosistenciaStock, Long> implements T10419ProIncoStockDAO{

	private static final Logger logger = LoggerFactory.getLogger(JPAT10419ProIncoStockDAO.class);
	
	public JPAT10419ProIncoStockDAO() {
		super(ProgramaIncosistenciaStock.class);
	}

	@Override
	public List<ProgramaIncosistenciaStock> listarDetalleStockNegativo(Long numUsuarioPrograma) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10419ProIncoStockDAO - listarDetalleStockNegativo");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ")
		.append(" st.num_estab as numEstablecimiento, ")
		.append(" c.cod_ubigeo as codUbigeo, ")
		.append(" c.cod_tipvia as codTipvia, ")
		.append(" c.des_nomvia as desNomvia, ")
		.append(" c.num_numvia as numNumvia, ")
		.append(" c.num_inter1 as numInter1, ")
		.append(" c.cod_tipzon as codTipzon, ")
		.append(" c.des_nomzon as desNomzon, ")
		.append(" c.des_refer1 as desRefer1, ")
		.append(" c.num_manza as numManza, ")
		.append(" c.num_lote as numLote, ")
		.append(" c.num_kilom as numKilom, ")
		.append(" c.num_depar as numDepar, ")
		.append(" st.cod_insumo as codInsumo, ")
		.append(" st.cod_bienfisca as codBienFiscalizado, ")
		.append(" st.num_orden as numOrden, ")
		.append(" st.cod_presen as codPresen, ")
		.append(" st.num_present as numPresentacion, ")
		.append(" st.des_nomcomprod as desNombreComercial, ")
		.append(" st.des_nomprod as desNombreProducto, ")
		.append(" st.cod_uni_com as codUnidadComercial, ")
		.append(" st.cod_uni_fis as codUnidadFiscal, ")
		.append(" st.cnt_unifisica as cantidadUnidadFisica, ")
		.append(" st.cod_tipprod as codTipprod, ")
		.append(" st.por_min_ins as porMinInsumo, ")
		.append(" st.por_max_ins as porMaxInsumo, ")
		.append(" st.cod_um as codUnidadMedida, ")
		.append(" st.cnt_stock_actual as cantidadStockActual, ")
		.append(" st.num_periodo as numPeriodo, ")
		.append(" st.cnt_net_pres as cntNetPres, ")
		.append(" st.cnt_neteada as cntNeteada ")
		.append(" FROM t10419proincostock st ")
		.append(" INNER JOIN t10428usuarioprog u ")
		.append(" ON st.num_usu_program = u.num_usu_program ")
		.append(" INNER JOIN t5070bfestab c ")
		.append(" ON u.num_doc_ident = c.num_ruc ")
		.append(" AND u.num_verreg= c.num_verreg ")
		.append(" AND st.num_estab= c.num_estab ")
		.append(" AND c.num_version= st.num_version_estab ");
		
		if (!MaestrosUtilidades.isEmpty(numUsuarioPrograma)) {
			builder.append(" WHERE st.num_usu_program = ?numUsuarioPrograma ");
			params.addProperty("numUsuarioPrograma", numUsuarioPrograma);
		}
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ProgramaIncosistenciaStock.class);
	}

}
