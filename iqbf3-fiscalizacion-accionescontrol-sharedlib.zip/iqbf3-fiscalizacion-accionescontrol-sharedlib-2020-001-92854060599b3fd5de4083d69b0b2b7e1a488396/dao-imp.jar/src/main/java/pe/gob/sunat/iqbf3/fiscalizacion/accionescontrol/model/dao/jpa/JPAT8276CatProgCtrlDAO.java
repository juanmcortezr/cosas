package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8276CatProgCtrlDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT8276CatProgCtrlDAO extends AbstractDAOImpl<ProgramaControl, String> implements T8276CatProgCtrlDAO{
	private static final Logger logger = LoggerFactory.getLogger(JPAT8276CatProgCtrlDAO.class);
	public JPAT8276CatProgCtrlDAO() {
		super(ProgramaControl.class);
	}
	
	@Override
	public List<ProgramaControl> obtenerProgCtrlDefinido(ProgramaControl filtro) {
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT cod_progctrl FROM t10420programacion P");

		boolean tieneParametros = false;
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
			builder.append(" AND P.num_prog_correl = ?numProgramacion ");
			params.addProperty("numProgramacion", filtro.getNumProgramacion());
			tieneParametros = true;
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumInforme())) {
			builder.append(" AND exists ( SELECT num_programacion from t10411informeselec O WHERE O.num_programacion=P.num_programacion AND O.num_correl=?numInforme ) ");
			params.addProperty("numInforme", filtro.getNumInforme());
			tieneParametros = true;
		}

		if (!tieneParametros) {
			return new ArrayList<ProgramaControl>();
		}
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ProgramaControl.class);
	}

	@Override
	public ProgramaControl obtenerTipoProgCtrl(ProgramaControl filtro) {
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		ProgramaControl programa = new ProgramaControl();
		
		builder.append("SELECT ")
		.append(" p.cod_progctrl as codProgctrl ")
		.append(" FROM t10415ordenaccion o ")
		.append(" INNER JOIN t10428usuarioprog u ")
		.append(" ON o.num_usu_program = u.num_usu_program ")
		.append(" INNER JOIN t10420programacion p ")
		.append(" ON u.num_programacion = p.num_programacion ")
		.append(" WHERE 1=1 ");
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumOrden())) {
			builder.append(" AND o.num_orden = ?numOrden ");
			params.addProperty("numOrden", filtro.getNumOrden());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
			builder.append(" AND u.num_programacion = ?numProgramacion ");
			params.addProperty("numProgramacion", filtro.getNumProgramacion());
		}
		List<String> lista = (List<String>) this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			programa = new ProgramaControl();
			programa.setCodProgctrl(lista.get(0));
		}
		return programa;
	}
	
	public List<ProgramaControl> obtenerTipoProgCtrl(Integer numProgramacion) {
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("select a.cod_progctrl, a.cod_uuoo , a.des_denominacion, a.des_resumen, a.des_cruce, ");
		builder.append("a.des_alcance ,  a.cod_frectiempo,   a.num_plazo   , a.ind_inf_selec , a.ind_cierre  , ");
		builder.append(" a.ind_del  , a.ind_est , a.cod_usucrea  ,  a.dir_ipusucrea , a.fec_crea, a.cod_usumodif ,");
		builder.append(" a.dir_ipusumodif ,  a.fec_modif from t8276catprogctrl a inner join t10420Programacion b");
		builder.append(" on  a.cod_progctrl=b.cod_progctrl where b.num_programacion = ?numProgramacion AND a.ind_del= ?indDel");
		params.addProperty("numProgramacion",numProgramacion);
		params.addProperty("indDel",AccionesControlConstantes.COD_ESTADO_INDICADOR_ACTIVO);
		List<ProgramaControl> lst =  this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ProgramaControl.class);
		logger.debug(String.format("JPAT8276CatProgCtrlDAO: query => %s", builder.toString()));
		logger.debug(String.format("JPAT8276CatProgCtrlDAO: query => %s", lst));
		return lst;
	}
}
