package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActividadEstablecimiento;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActividadOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10386ActividEstabDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

@Stateless
public class JPAT10386ActividEstabDAO extends AbstractDAOImpl<ActividadEstablecimiento, Long> implements T10386ActividEstabDAO {
	private static final Logger logger = LoggerFactory.getLogger(JPAT10386ActividEstabDAO.class);
	public JPAT10386ActividEstabDAO() {
		super(ActividadEstablecimiento.class);
	}
	
	
	@Override
	public int actualizarActividadOrden(ActividadEstablecimiento model) {
		
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder=new StringBuilder();
		
			builder.append(" UPDATE t10386actividestab a SET ");
			builder.append(" a.fec_modif = SYSDATE ");
		  if(model.getNumEstablecimientoOrden()!=null&&model.getNumEstablecimientoOrden()>0)builder.append(" ,a.num_estab_orden = ?2 ");
		  if(!MaestrosUtilidades.isEmpty(model.getCodActividad()))builder.append(" ,a.cod_actividad = ?3 ");
		  if(!MaestrosUtilidades.isEmpty(model.getIndDel()))builder.append(" ,a.ind_del = ?4 ");
		  if(!MaestrosUtilidades.isEmpty(model.getIndEst()))builder.append(" ,a.ind_est = ?5 ");  
		  if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,a.cod_usumodif = ?6 ");
		  if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,a.dir_ipusumodif = ?7 ");
		  	builder.append(" WHERE 1=1 ");
		  if(model.getNumActividadEstablecimiento()!=null&&model.getNumActividadEstablecimiento()>0)builder.append(" AND a.num_activ_estab = ?1 ");
		  if(model.getNumEstablecimientoOrden()!=null&&model.getNumEstablecimientoOrden()>0)builder.append(" AND a.num_estab_orden = ?2 ");
		  
		Query query = entityManager.createNativeQuery(builder.toString());
		query.setParameter(1, model.getNumActividadEstablecimiento());
		query.setParameter(2, model.getNumEstablecimientoOrden());
		query.setParameter(3, model.getCodActividad());
		query.setParameter(4, model.getIndDel());
		query.setParameter(5, model.getIndEst());
		query.setParameter(6, model.getCodUsuModif());
		query.setParameter(7, model.getDirIpusumodif());
		
		
		logger.debug(String.format("JPAT10387ActividOrdenDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10387ActividOrdenDAO: query => %s", builder.toString()));
		
		return query.executeUpdate();
	}
	
	
	
}
