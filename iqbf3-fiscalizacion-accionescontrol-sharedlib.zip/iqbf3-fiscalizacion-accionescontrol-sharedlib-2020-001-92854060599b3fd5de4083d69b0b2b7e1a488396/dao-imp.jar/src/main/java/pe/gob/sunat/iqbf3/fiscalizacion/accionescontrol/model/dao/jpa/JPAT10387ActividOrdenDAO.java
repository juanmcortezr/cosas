package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActividadOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DetalleResultadoOrden;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10387ActividOrdenDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;

@Stateless
public class JPAT10387ActividOrdenDAO extends AbstractDAOImpl<ActividadOrden, Long> implements T10387ActividOrdenDAO {
	private static final Logger logger = LoggerFactory.getLogger(JPAT10387ActividOrdenDAO.class);
	public JPAT10387ActividOrdenDAO() {
		super(ActividadOrden.class);
	}
	
	@Override
	public int actualizarActividadOrden(ActividadOrden model) {
		if(logger.isDebugEnabled())
			logger.debug("Inicio JPAT10387ActividOrdenDAO - actualizarActividadOrden");
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DGSICOBF);
		StringBuilder builder = new StringBuilder();
			builder.append(" UPDATE t10387actividorden a SET ");
			builder.append(" a.fec_modif = SYSDATE ");
			
			  if(model.getNumOrden()!=null&&model.getNumOrden()>0)builder.append(" ,a.num_orden = ?2 ");
			  if(model.getCodActividad()!=null)builder.append(" ,a.cod_actividad = ?3 ");
			  if(!MaestrosUtilidades.isEmpty(model.getIndDel()))builder.append(" ,a.ind_del = ?4 ");
			  if(!MaestrosUtilidades.isEmpty(model.getIndEst()))builder.append(" ,a.ind_est = ?5 ");    
			  if(!MaestrosUtilidades.isEmpty(model.getCodUsuModif()))builder.append(" ,a.cod_usumodif = ?6 ");
			  if(!MaestrosUtilidades.isEmpty(model.getDirIpusumodif()))builder.append(" ,a.dir_ipusumodif = ?7 ");
		  	
		  builder.append(" WHERE 1=1 ");
		  
		  if(model.getNumActividadResultado()!=null&&model.getNumActividadResultado()>0)builder.append(" AND a.num_activ_resul = ?1 ");
		  if(model.getNumOrden()!=null&&model.getNumOrden()>0)builder.append(" AND a.num_orden = ?2 ");
		Query query = entityManager.createNativeQuery(builder.toString());
		
				
		logger.debug(String.format("JPAT10387ActividOrdenDAO: query => %s", builder.toString()));
		return query.executeUpdate();
	}
}
