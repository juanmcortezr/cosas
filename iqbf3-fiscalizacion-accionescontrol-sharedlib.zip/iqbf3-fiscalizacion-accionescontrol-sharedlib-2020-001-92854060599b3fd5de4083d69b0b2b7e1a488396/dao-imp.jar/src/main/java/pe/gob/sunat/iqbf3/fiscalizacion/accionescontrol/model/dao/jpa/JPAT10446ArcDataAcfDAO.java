package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.Arrays;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoDataAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10446ArcDataAcfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10446ArcDataAcfDAO extends AbstractDAOImpl<ArchivoDataAcciones, Long> implements T10446ArcDataAcfDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10446ArcDataAcfDAO.class);

	public JPAT10446ArcDataAcfDAO() {
		super(ArchivoDataAcciones.class);
	}

	@Override
	public ArchivoDataAcciones obtenerArcDataNoBytes(Long numArc) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10446ArcDataAcfDAO - obtenerArcDataNoBytes");
		String jpqQuery = "SELECT new pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoDataAcciones(a.numArchAcciones, a.dirIpusucrea, a.fecCrea, a.codUsuCrea, a.indDel, a.indEst) FROM ArchivoDataAcciones a";
		PropertyParams property = new PropertyParams();
		property.addProperty("a.numArchAcciones", numArc);
		List<ArchivoDataAcciones> data = this.findByJPQL(jpqQuery, property, AccionesControlConstantes.DATASOURCE_DCSICOBF, ArchivoDataAcciones.class);
		if (!MaestrosUtilidades.isEmpty(data)) {
			return data.get(0);
		}
		return null;
	}

}
