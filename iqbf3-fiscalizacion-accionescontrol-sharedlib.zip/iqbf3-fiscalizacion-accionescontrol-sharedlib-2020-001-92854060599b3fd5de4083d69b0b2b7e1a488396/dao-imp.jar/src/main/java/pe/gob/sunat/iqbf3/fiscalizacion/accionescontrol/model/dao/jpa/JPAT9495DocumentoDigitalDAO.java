package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;


import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.T9495DocDigit;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T9495DocumentoDigitalDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;


@Stateless
public class JPAT9495DocumentoDigitalDAO extends AbstractDAOImpl<T9495DocDigit, Long> implements T9495DocumentoDigitalDAO {
	
	public JPAT9495DocumentoDigitalDAO() {
		super(T9495DocDigit.class);
	}
}
