package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PersonaRelacionadaBf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PersonaRelacionadaBfPK;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5231PersoRelacDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT5231PersoRelacDAO extends AbstractDAOImpl<PersonaRelacionadaBf, PersonaRelacionadaBfPK> implements T5231PersoRelacDAO {

	public JPAT5231PersoRelacDAO() {
		super(PersonaRelacionadaBf.class);
	}

}
