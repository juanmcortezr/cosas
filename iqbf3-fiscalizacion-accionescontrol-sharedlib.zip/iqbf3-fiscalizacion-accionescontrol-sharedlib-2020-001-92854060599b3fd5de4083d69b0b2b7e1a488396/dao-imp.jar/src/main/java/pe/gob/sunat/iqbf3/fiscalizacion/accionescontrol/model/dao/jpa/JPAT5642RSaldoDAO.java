package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenSaldoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenSaldo;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T5642RSaldoDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT5642RSaldoDAO extends AbstractDAOImpl<ResumenSaldo, Long> implements T5642RSaldoDAO{

	private static final Logger logger = LoggerFactory.getLogger(JPAT4241CabCpeDAO.class);
	
	public JPAT5642RSaldoDAO() {
		super(ResumenSaldo.class);
	}

	@Override
	public List<ResumenSaldo> listarUsuarioSaldoNegativo(ResumenSaldoBean resumenSaldoBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		String estadoBf="";
		
		/*
		 * resumenSaldoBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		resumenSaldoBean.setNumReposicion(AccionesControlConstantes.NUM_ULTIMA_REPOSICION);
		lstEstadoRegistros = new ArrayList<>();
		lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
		lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
		resumenSaldoBean.setLstEstadoRegistros(lstEstadoRegistros);
		resumenSaldoBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);

		 */
		builder.append("SELECT  ")
		//.append("sa.num_ruc as resumenSaldoPk_numRuc, ")
		//.append("sa.cod_tipbien as resumenSaldoPk_codTipobien,  ")
		//.append("sa.num_verreg as resumenSaldoPk_numVersionRegistro,  ")
		.append("sa.num_ruc as numRuc, ")
		.append("sa.cod_tipbien as codTipobien,  ")
		.append("sa.num_verreg as numVersionRegistro,  ")
		.append("reg.fec_finvigencia as fecFinvigencia, ")
		.append("reg.cod_estado as codEstado ")
		.append("FROM t5642rsaldo sa, t5066bfcabinsumo b, t5075bfregistro reg, t5638hsaldo hsc ")
		.append("WHERE b.num_ruc = sa.num_ruc  ")
		.append("AND b.cod_tipbien = sa.cod_tipbien  ")
		.append("AND b.num_verreg = sa.num_verreg AND b.num_inscab = sa.num_inscab ");
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndCondicion())) {
			builder.append("AND b.ind_condicion = ?ind_condiciona  ");//--producto
	 		params.addProperty("ind_condiciona", resumenSaldoBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getCodEstadoItem())) {
			builder.append("AND b.cod_estado = ?cod_estado_itema  ");//'01' -- Vigente
	 		params.addProperty("cod_estado_itema", resumenSaldoBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND b.ind_del = ?ind_dela ");
	 		params.addProperty("ind_dela", resumenSaldoBean.getIndDel());
		}
		
		builder.append("AND reg.num_ruc= sa.num_ruc AND reg.num_verreg = sa.num_verreg  ")
		.append("AND reg.cod_tipbien = sa.cod_tipbien ");
		
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getLstEstadoRegistros())) {
			builder.append("AND reg.cod_estado  ");
	 		int cont = 1;
	 		for(String codEstadoBfRegistro : resumenSaldoBean.getLstEstadoRegistros()){
	 			if(cont == 1 ){
	 				estadoBf = "'" + codEstadoBfRegistro + "'";
	 				cont++;
	 			}else{
	 				estadoBf = estadoBf + ",'" + codEstadoBfRegistro + "'";
	 			}
	 		}
	 		builder.append(" IN ("+estadoBf+") ");
	    }
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND reg.ind_del = ?ind_delb ");
	 		params.addProperty("ind_delb", resumenSaldoBean.getIndDel());
		}
		
		builder.append("AND hsc.num_ruc= sa.num_ruc ")
		.append("AND hsc.cod_tipbien= sa.cod_tipbien ")
		.append("AND hsc.num_verreg = sa.num_verreg ")
		.append("AND hsc.num_inscab = sa.num_inscab ")
		.append("AND sa.num_periodo = (SELECT MIN(s.num_periodo)  ")
		.append("FROM t5642rsaldo s, t5638hsaldo hs ")
		.append("WHERE s.num_ruc = sa.num_ruc  ")
		.append("AND s.num_verreg = sa.num_verreg ")
		.append("AND s.cod_tipbien = sa.cod_tipbien ")
		.append("AND s.num_inscab = sa.num_inscab ")
		.append("AND hs.num_ruc= s.num_ruc ")
		.append("AND hs.cod_tipbien= s.cod_tipbien ")
		.append("AND hs.num_verreg = s.num_verreg ")
		.append("AND hs.num_inscab = s.num_inscab ")
		.append("AND (hs.cnt_disponible - s.cnt_consumida) < 0  ")
		.append("AND s.num_verreg = (SELECT MAX(num_verreg)  ")
		.append("FROM t5075bfregistro  ")
		.append("WHERE 1=1 ");
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getLstEstadoRegistros())) {
			builder.append("cod_estado IN ("+estadoBf+") ");
	    }
		builder.append("AND num_ruc = s.num_ruc  ");
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND ind_del = ?ind_delc ");
	 		params.addProperty("ind_delc", resumenSaldoBean.getIndDel());
		}
		builder.append("GROUP BY num_ruc) ");
		
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getNumReposicion())) {
			builder.append("AND s.num_reposicion = ?num_reposiciona ");
	 		params.addProperty("num_reposiciona", resumenSaldoBean.getNumReposicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND s.ind_del = ?ind_deld ");
	 		params.addProperty("ind_deld", resumenSaldoBean.getIndDel());
		}
		builder.append(") ");
		builder.append("AND (hsc.cnt_disponible - sa.cnt_consumida) < 0 ");
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND sa.ind_del = ?ind_dele ");
	 		params.addProperty("ind_dele", resumenSaldoBean.getIndDel());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getNumReposicion())) {
			builder.append("AND sa.num_reposicion = ?num_reposicionb  ");//--Ultima reposicion
	 		params.addProperty("num_reposicionb", resumenSaldoBean.getNumReposicion());
		}
		
		builder.append("AND hsc.num_reposicion = (SELECT MAX (rp.num_reposicion) FROM t5636bfreposicion rp ")
		.append("WHERE rp.num_ruc = hsc.num_ruc AND rp.cod_tipbien = hsc.cod_tipbien AND rp.num_verreg = hsc.num_verreg)  ");//-- Reposicion del a�o anterior
		
	 	logger.debug(String.format("JPAT5642RSaldoDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ResumenSaldo.class);
	}

	@Override
	public List<ResumenSaldo> listarSaldoNegativo(ResumenSaldoBean resumenSaldoBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		String estadoBf="";
		
		/*
		 * resumenSaldoBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		resumenSaldoBean.setNumReposicion(AccionesControlConstantes.NUM_ULTIMA_REPOSICION);
		lstEstadoRegistros = new ArrayList<>();
		lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
		lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
		resumenSaldoBean.setLstEstadoRegistros(lstEstadoRegistros);
		resumenSaldoBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);

		 */
		
		builder.append("SELECT ")
		//.append("sa.num_ruc as resumenSaldoPk_numRuc, ")
		//.append("sa.cod_tipbien as resumenSaldoPk_codTipobien,  ")
		//.append("sa.num_verreg as resumenSaldoPk_numVersionRegistro,  ")
		.append("sa.num_ruc as numRuc, ")
		.append("sa.cod_tipbien as codTipobien,  ")
		.append("sa.num_verreg as numVersionRegistro,  ")

		.append("reg.fec_finvigencia as fecFinvigencia, ")
		.append("reg.cod_estado as codEstado,  ")
		//.append("b.num_inscab as resumenSaldoPk_numInsumoCabecera,  ")
		.append("b.num_inscab as numInsumoCabecera,  ")
		.append("b.cod_insumo as codInsumo,  ")
		.append("b.num_orden as numOrden, ")
		.append("b.num_version AS numVersionIns, ")
		.append("b.cod_tipprod as codTipProd, ")
		.append("b.cod_um as codUm, ")
		.append("b.cod_bienfisca as codBienFisca, ")
		.append("b.des_nomprod as desNomProd, ")
		.append("b.des_nomcomprod as desNomComProd,  ")
		//.append("sa.num_periodo as resumenSaldoPk_numPeriodo, ")
		.append("sa.num_periodo as numPeriodo, ")
		.append("b.cnt_autorizada as cntAutorizada,  ")
		.append("(hsc.cnt_disponible - sa.cnt_consumida) as cntDisponible, ")
		.append("sa.cnt_consumida as cntConsumida, ")
		.append("NVL(b.por_max_ins,0) AS porMaxIns, ")
		.append("NVL(b.por_min_ins,0) AS porMinIns, ")
		//.append("sa.num_reposicion as resumenSaldoPk_numReposicion ")
		.append("sa.num_reposicion as numReposicion ")
		.append("FROM t5642rsaldo sa, t5066bfcabinsumo b, t5075bfregistro reg, t5638hsaldo hsc ")
		.append("WHERE b.num_ruc = sa.num_ruc  ")
		.append("AND b.cod_tipbien = sa.cod_tipbien  ")
		.append("AND b.num_verreg = sa.num_verreg AND b.num_inscab = sa.num_inscab ");
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndCondicion())) {
			builder.append("AND b.ind_condicion = ?ind_condiciona ");// --producto
	 		params.addProperty("ind_condiciona", resumenSaldoBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getCodEstadoItem())) {
			builder.append("AND b.cod_estado = ?cod_estado_itema  ");// ---'01' -- Vigente
	 		params.addProperty("cod_estado_itema", resumenSaldoBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND b.ind_del = ?ind_dela ");
	 		params.addProperty("ind_dela", resumenSaldoBean.getIndDel());
		}
		
		builder.append("AND reg.num_ruc= sa.num_ruc AND reg.num_verreg = sa.num_verreg  ")
		.append("AND reg.cod_tipbien = sa.cod_tipbien ");
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getLstEstadoRegistros())) {
			builder.append("AND reg.cod_estado  ");
	 		int cont = 1;
	 		for(String codEstadoBfRegistro : resumenSaldoBean.getLstEstadoRegistros()){
	 			if(cont == 1 ){
	 				estadoBf = "'" + codEstadoBfRegistro + "'";
	 				cont++;
	 			}else{
	 				estadoBf = estadoBf + ",'" + codEstadoBfRegistro + "'";
	 			}
	 		}
	 		builder.append(" IN ("+estadoBf+") ");
	    }
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND reg.ind_del = ?ind_delb ");
	 		params.addProperty("ind_delb", resumenSaldoBean.getIndDel());
		}
		
		builder.append("AND hsc.num_ruc= sa.num_ruc ")
		.append("AND hsc.cod_tipbien= sa.cod_tipbien ")
		.append("AND hsc.num_verreg = sa.num_verreg ")
		.append("AND hsc.num_inscab = sa.num_inscab ")
		.append("AND sa.num_periodo = (SELECT MIN(s.num_periodo)  ")
		.append("FROM t5642rsaldo s, t5638hsaldo hs ")
		.append("WHERE s.num_ruc = sa.num_ruc  ")
		.append("AND s.num_verreg = sa.num_verreg ")
		.append("AND s.cod_tipbien = sa.cod_tipbien ")
		.append("AND s.num_inscab = sa.num_inscab ")
		.append("AND hs.num_ruc= s.num_ruc ")
		.append("AND hs.cod_tipbien= s.cod_tipbien ")
		.append("AND hs.num_verreg = s.num_verreg ")
		.append("AND hs.num_inscab = s.num_inscab ")
		.append("AND (hs.cnt_disponible - s.cnt_consumida) < 0  ")
		.append("AND s.num_verreg = (SELECT MAX(num_verreg)  ")
									.append("FROM t5075bfregistro  ")
									.append("WHERE 1=1 ");
									if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getLstEstadoRegistros())) {
										builder.append("and cod_estado IN ("+estadoBf+") ");
								    }
									builder.append("AND num_ruc = s.num_ruc  ");
									if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
										builder.append("AND ind_del = ?ind_delc ");
								 		params.addProperty("ind_delc", resumenSaldoBean.getIndDel());
									}
									builder.append("GROUP BY num_ruc) ");
									
									if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getNumReposicion())) {
										builder.append("AND s.num_reposicion = ?num_reposiciona ");
								 		params.addProperty("num_reposiciona", resumenSaldoBean.getNumReposicion());
									}
									
									if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
										builder.append("AND s.ind_del = ?ind_deld ");
								 		params.addProperty("ind_deld", resumenSaldoBean.getIndDel());
									}
									
									builder.append(") ");
		builder.append("AND (hsc.cnt_disponible - sa.cnt_consumida) < 0 ");
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND sa.ind_del = ?ind_dele ");
	 		params.addProperty("ind_dele", resumenSaldoBean.getIndDel());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getNumReposicion())) {
			builder.append("AND sa.num_reposicion = ?num_reposicionb  ");//--Ultima reposicion
	 		params.addProperty("num_reposicionb", resumenSaldoBean.getNumReposicion());
		}
		
		builder.append("AND hsc.num_reposicion = (SELECT MAX (rp.num_reposicion) FROM t5636bfreposicion rp ")
								.append("WHERE rp.num_ruc = hsc.num_ruc AND rp.cod_tipbien = hsc.cod_tipbien AND rp.num_verreg = hsc.num_verreg) ");// -- Reposicion del a�o anterior�
								
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getNumRuc())) {
			builder.append("AND sa.num_ruc = ?num_ruc  ");
	 		params.addProperty("num_ruc", resumenSaldoBean.getNumRuc());
		}
		
	 	logger.debug(String.format("JPAT5642RSaldoDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ResumenSaldo.class);
	}
	
	@Override
	public List<ResumenSaldo> cntSaldoNegativo(ResumenSaldoBean resumenSaldoBean)
	{
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		String estadoBf="";
		
		/*
		 * resumenSaldoBean.setIndDel(MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		resumenSaldoBean.setNumReposicion(AccionesControlConstantes.NUM_ULTIMA_REPOSICION);
		lstEstadoRegistros = new ArrayList<>();
		lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_VIGENTE);//01
		lstEstadoRegistros.add(AccionesControlConstantes.COD_ESTADO_REGISTRO_SUSPENDIDO);//02
		resumenSaldoBean.setLstEstadoRegistros(lstEstadoRegistros);
		resumenSaldoBean.setIndCondicion(AccionesControlConstantes.IND_CONDICION_ITEM_REGISTRO);

		 */
		
		builder.append("SELECT count(*) as cntSaldoNegativo")
		.append("FROM t5642rsaldo sa, t5066bfcabinsumo b, t5075bfregistro reg, t5638hsaldo hsc ")
		.append("WHERE b.num_ruc = sa.num_ruc  ")
		.append("AND b.cod_tipbien = sa.cod_tipbien  ")
		.append("AND b.num_verreg = sa.num_verreg AND b.num_inscab = sa.num_inscab ");
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndCondicion())) {
			builder.append("AND b.ind_condicion = ?ind_condiciona ");// --producto
	 		params.addProperty("ind_condiciona", resumenSaldoBean.getIndCondicion());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getCodEstadoItem())) {
			builder.append("AND b.cod_estado = ?cod_estado_itema  ");// ---'01' -- Vigente
	 		params.addProperty("cod_estado_itema", resumenSaldoBean.getCodEstadoItem());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND b.ind_del = ?ind_dela ");
	 		params.addProperty("ind_dela", resumenSaldoBean.getIndDel());
		}
		
		builder.append("AND reg.num_ruc= sa.num_ruc AND reg.num_verreg = sa.num_verreg  ")
		.append("AND reg.cod_tipbien = sa.cod_tipbien ");
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getLstEstadoRegistros())) {
			builder.append("AND reg.cod_estado  ");
	 		int cont = 1;
	 		for(String codEstadoBfRegistro : resumenSaldoBean.getLstEstadoRegistros()){
	 			if(cont == 1 ){
	 				estadoBf = "'" + codEstadoBfRegistro + "'";
	 				cont++;
	 			}else{
	 				estadoBf = estadoBf + ",'" + codEstadoBfRegistro + "'";
	 			}
	 		}
	 		builder.append(" IN ("+estadoBf+") ");
	    }
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND reg.ind_del = ?ind_delb ");
	 		params.addProperty("ind_delb", resumenSaldoBean.getIndDel());
		}
		
		builder.append("AND hsc.num_ruc= sa.num_ruc ")
		.append("AND hsc.cod_tipbien= sa.cod_tipbien ")
		.append("AND hsc.num_verreg = sa.num_verreg ")
		.append("AND hsc.num_inscab = sa.num_inscab ")
		.append("AND sa.num_periodo = (SELECT MIN(s.num_periodo)  ")
		.append("FROM t5642rsaldo s, t5638hsaldo hs ")
		.append("WHERE s.num_ruc = sa.num_ruc  ")
		.append("AND s.num_verreg = sa.num_verreg ")
		.append("AND s.cod_tipbien = sa.cod_tipbien ")
		.append("AND s.num_inscab = sa.num_inscab ")
		.append("AND hs.num_ruc= s.num_ruc ")
		.append("AND hs.cod_tipbien= s.cod_tipbien ")
		.append("AND hs.num_verreg = s.num_verreg ")
		.append("AND hs.num_inscab = s.num_inscab ")
		.append("AND (hs.cnt_disponible - s.cnt_consumida) < 0  ")
		.append("AND s.num_verreg = (SELECT MAX(num_verreg)  ")
									.append("FROM t5075bfregistro  ")
									.append("WHERE 1=1 ");
									if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getLstEstadoRegistros())) {
										builder.append("and cod_estado IN ("+estadoBf+") ");
								    }
									builder.append("AND num_ruc = s.num_ruc  ");
									if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
										builder.append("AND ind_del = ?ind_delc ");
								 		params.addProperty("ind_delc", resumenSaldoBean.getIndDel());
									}
									builder.append("GROUP BY num_ruc) ");
									
									if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getNumReposicion())) {
										builder.append("AND s.num_reposicion = ?num_reposiciona ");
								 		params.addProperty("num_reposiciona", resumenSaldoBean.getNumReposicion());
									}
									
									if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
										builder.append("AND s.ind_del = ?ind_deld ");
								 		params.addProperty("ind_deld", resumenSaldoBean.getIndDel());
									}
									
									builder.append(") ");
		builder.append("AND (hsc.cnt_disponible - sa.cnt_consumida) < 0 ");
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getIndDel())) {
			builder.append("AND sa.ind_del = ?ind_dele ");
	 		params.addProperty("ind_dele", resumenSaldoBean.getIndDel());
		}
		
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getNumReposicion())) {
			builder.append("AND sa.num_reposicion = ?num_reposicionb  ");//--Ultima reposicion
	 		params.addProperty("num_reposicionb", resumenSaldoBean.getNumReposicion());
		}
		
		builder.append("AND hsc.num_reposicion = (SELECT MAX (rp.num_reposicion) FROM t5636bfreposicion rp ")
								.append("WHERE rp.num_ruc = hsc.num_ruc AND rp.cod_tipbien = hsc.cod_tipbien AND rp.num_verreg = hsc.num_verreg) ");// -- Reposicion del a�o anterior�
								
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getNumRuc())) {
			builder.append("AND sa.num_ruc = ?num_ruc  ");
	 		params.addProperty("num_ruc", resumenSaldoBean.getNumRuc());
		}
		
		//-----filtro dinamico solo para verificacion---
		if (!MaestrosUtilidades.isEmpty(resumenSaldoBean.getNumInsumoCabecera())) {
			builder.append("AND s.num_inscab = ?num_inscab ");
	 		params.addProperty("num_inscab", resumenSaldoBean.getNumInsumoCabecera());
		}
		
	 	logger.debug(String.format("JPAT5642RSaldoDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, ResumenSaldo.class);
	}
}
