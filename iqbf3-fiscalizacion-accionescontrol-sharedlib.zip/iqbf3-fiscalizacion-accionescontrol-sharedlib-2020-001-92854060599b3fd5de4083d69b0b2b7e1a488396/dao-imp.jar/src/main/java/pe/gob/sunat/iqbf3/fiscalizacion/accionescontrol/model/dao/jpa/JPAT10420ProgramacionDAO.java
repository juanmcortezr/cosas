package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.stream.Collectors;

import javax.ejb.Stateless;

import org.apache.poi.hpsf.Array;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienFiscalizadoSolicitudBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10420ProgramacionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.bean.DataCatalogoBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10420ProgramacionDAO extends AbstractDAOImpl<Programacion, Long> implements T10420ProgramacionDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10420ProgramacionDAO.class);

	public JPAT10420ProgramacionDAO() {
		super(Programacion.class);
	}
	
	@Override
	public List<Programacion> obtenerDatosProgramacionDefinido(Programacion filtro){
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10420ProgramacionDAO - obtenerDatosProgramacionDefinido");
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append(" SELECT  A.num_prog_correl,A.cod_progctrl,B.des_denominacion,A.num_plazo_verif, ")    
		.append(" A.des_alcance,A.cod_programador,C. cod_tip_inconsis,A.des_programacion,A.obs_programacion,        ")
		.append(" A.per_fin,A.per_inicio,D.num_correl,D.ann_informe,D.cod_uuoo,E.num_arc_doc,E.num_inf_selecc ")
		.append(" FROM t10420programacion A INNER JOIN t8276catprogctrl B ON A.cod_progctrl=B. cod_progctrl  ")
		.append(" INNER JOIN t10425tipinconprog C ON A.num_programacion= C.num_programacion ")
		.append(" LEFT JOIN t10411informeselec D ON A.num_programacion=D. num_programacion LEFT JOIN ")
		.append(" t10390arcinforme E ON D.num_inf_selecc=E.num_inf_selecc ")
		.append(" INNER JOIN t10445arcacf  F ON E. num_arc= F. num_arc AND  a.cod_tip_arc ='06'  ")
		.append(" WHERE 1=1 ");

		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
			builder.append(" AND A.num_programacion = ?numProgramacion ");
			params.addProperty("numProgramacion", filtro.getNumProgramacion());
		}		
				
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, Programacion.class);
	}
	
	
	@Override
	public List<Programacion> listarProgramaDefinido(Programacion filtro){
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10420ProgramacionDAO - listarProgramaDefinido");
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append(" SELECT A.num_programacion as numProgramacion, A.num_prog_correl as numProgramaCorrel, A.cod_progctrl as codProgctrl, (SELECT des_denominacion FROM t8276catprogctrl ")
				.append("WHERE cod_progctrl= A.cod_progctrl) as desProgctrl, A.fec_programacion as fecProgramacion, A.per_inicio as perInicio, ")
				.append(" A.per_fin as perFin, A.cod_est_program as codEstadoPrograma, X.fec_est_program as fechaIniAsignacion, (select MAX(B.num_inf_selecc) FROM ")
				.append("t10411informeselec B  WHERE A.num_programacion = B.num_programacion AND B.ind_del='0' AND B.ind_est='1') as numInforme  FROM ")
				.append(" t10420programacion A ")
				.append(" LEFT JOIN (SELECT LIMIT 1 fec_est_program, A.num_programacion FROM ")    
				.append(" t10410histestaprog A, t10420programacion B WHERE A.num_programacion=B.num_programacion) X ON ") 
				.append(" X.num_programacion=A.num_programacion WHERE 1=1 ");
				
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramaCorrel())) {
			builder.append(" AND A.num_prog_correl= ?numProgramaCorrel ");
			params.addProperty("numProgramaCorrel", filtro.getNumProgramaCorrel());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodProgctrl())) {
			builder.append(" AND A.cod_progctrl= ?codProgctrl ");
			params.addProperty("codProgctrl", filtro.getCodProgctrl());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
			builder.append(" AND A.cod_est_program= ?codEstadoPrograma ");
			params.addProperty("codEstadoPrograma", filtro.getCodEstadoPrograma());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getFechaDesde()) && !MaestrosUtilidades.isEmpty(filtro.getFechaHasta())) {
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd 23:59:59");
			
			builder.append(" AND A.fec_programacion >= ?fechaDesde  AND A.fec_programacion <= ?fechaHasta  ");
			params.addProperty("fechaDesde", sdf1.format(filtro.getFechaDesde()));
			params.addProperty("fechaHasta", sdf2.format(filtro.getFechaHasta()));
			logger.debug(sdf1.format(filtro.getFechaDesde()));
			logger.debug(sdf1.format(filtro.getFechaHasta()));
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumInforme())) {
			builder.append(" AND exists (select num_programacion  FROM  t10411informeselec B  WHERE B.num_inf_selecc=?numInforme AND A.num_programacion = B.num_programacion ) ");
			params.addProperty("numInforme", filtro.getNumInforme());
		}

		logger.debug(String.format("JPAT10420ProgramacionDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, Programacion.class);
	}

	@Override
	public Integer obtenerCorrelativoProgramacion(Integer anio) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10420ProgramacionDAO - obtenerCorrelativoProgramacion");
		String query = "SELECT MAX(a.numProgramaCorrel) FROM Programacion a WHERE a.anioProgramacion=:anioProgramacion";
		PropertyParams params = new PropertyParams();
		params.addProperty("anioProgramacion", anio);
		List<Integer> correls = this.findByJPQL(query, params, AccionesControlConstantes.DATASOURCE_DCSICOBF, Integer.class);
		Integer correlativo = 0;
		if (!MaestrosUtilidades.isEmpty(correls)) {
			if (!MaestrosUtilidades.isEmpty(correls.get(0))) {
				correlativo = correls.get(0);	
			}
		}
		return correlativo + 1;
	}

	@Override
	public List<Programacion> listarProgramacion(Programacion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10420ProgramacionDAO - listarProgramacion");

		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT p.num_programacion as numProgramacion, p.cod_progctrl as codProgctrl, g.num_grupo as numGrupo, (p.cod_progctrl||' - '||(SELECT des_denominacion FROM t8276catprogctrl WHERE cod_progctrl= p.cod_progctrl)) as desProgctrl, ")
			.append("(p.num_prog_correl ||'-'|| p.ann_programacion) as numProgramacionUnion, p.ann_programacion as anioProgramacion, p.num_prog_correl as numProgramaCorrel, ")
			.append("p.des_alcance as desAlcance, p.des_programacion as desProgramacion, p.fec_fin_proceso as fecUltimoEstado,  p.fec_programacion as fecProgramacion, ")
			.append("p.per_inicio as perInicio, p.per_fin as perFin, a.ind_tip_asignacion as indTipoAsignacion, ")
			.append("(SELECT count(*) FROM t10428usuarioprog WHERE num_programacion = p. num_programacion ")
			.append("AND ind_depuracion <> ") 
			.append(AccionesControlConstantes.COD_IND_DEPURACION_AUTOMATICA)
			.append(" AND ind_depuracion <> ") 
			.append(AccionesControlConstantes.COD_IND_DEPURACION_MANUAL)
			.append(") as cantFinalUsuario, ")
			.append("(SELECT count(*) FROM t10428usuarioprog WHERE num_programacion = p. num_programacion ")
			.append("AND ind_depuracion = ")
			.append(AccionesControlConstantes.COD_IND_DEPURACION_AUTOMATICA)
			.append("OR ind_depuracion = ")
			.append(AccionesControlConstantes.COD_IND_DEPURACION_MANUAL)
			.append(") as cantUsuariosDepurados, ")
			.append(" p.cod_programador as codProgramador, p.cod_fuente as codFuente, p.des_otra_fuente as desOtraFuente, p.cod_tip_program as codTipoProgram, p.obs_programacion as obsProgramacion,i.num_inf_selecc as numInforme, p.num_inf_cancela as numInformeCancelacion,")
			.append("p.num_plazo_verif as numPlazoVerificacion, p.ind_cierre as indCierre, p.cod_est_program as codEstadoPrograma, ")
			.append("p.cod_sub_estprogram as codSubEstadoProgram, p.cod_proceso as codProceso, p.des_sus_cancela as desSusCancela, a.fec_ini_asignacion as fecIniAsignacion, a.fec_fin_asignacion as fechaFinAsig, ")
			.append("i.cod_est_informe as codEstadoInforme, a.cod_pers as codProgramadorAdmin,  ")
			.append("('IS'||'-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) as nroInformeUnion ")
			.append("FROM t10420programacion p LEFT JOIN t10411informeselec i ON p.num_programacion = i.num_programacion AND i.ind_del = ")
			.append(AccionesControlConstantes.REGISTRO_NOELIMINADO)
			.append(" AND i.ind_est = ")
			.append(AccionesControlConstantes.REGISTRO_ACTIVO)
			.append(" LEFT JOIN t10392asignprogram a ON p.num_programacion = a.num_programacion AND a.ind_tip_asignacion = ")
			.append(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR)
			.append(" AND a.ind_est = ")
			.append(AccionesControlConstantes.REGISTRO_ACTIVO)
			.append(" LEFT JOIN t10410histestaprog h ON p.num_programacion = h.num_programacion ")
			.append("AND h.fec_est_program = (select max(fec_est_program) FROM t10410histestaprog WHERE num_programacion = p.num_programacion) ")
			.append(" LEFT JOIN t8303distrigrupo g ON p.cod_programador = g.cod_pers AND g.ind_del = ")
			.append(AccionesControlConstantes.REGISTRO_NOELIMINADO)
			.append(" AND g.ind_est = ")
			.append(AccionesControlConstantes.REGISTRO_ACTIVO)
			.append(" WHERE 1=1 ");			
		
		if (!MaestrosUtilidades.isEmpty(filtro.getDesProgctrl())) {
//			builder.append(" AND (p.cod_progctrl||' - '||(SELECT des_denominacion FROM t8276catprogctrl WHERE cod_progctrl= p.cod_progctrl)) LIKE desProgctrl ");
//			params.addProperty("desProgctrl", "%" + filtro.getDesProgctrl() + "%");
			builder.append(" AND (p.cod_progctrl||' - '||(SELECT des_denominacion FROM t8276catprogctrl WHERE cod_progctrl= p.cod_progctrl)) LIKE '%"+filtro.getDesProgctrl().trim()+"%' ");
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
//			builder.append(" AND (p.cod_progctrl||' - '||(SELECT des_denominacion FROM t8276catprogctrl WHERE cod_progctrl= p.cod_progctrl)) LIKE desProgctrl ");
//			params.addProperty("desProgctrl", "%" + filtro.getDesProgctrl() + "%");
			builder.append(" AND (p.num_prog_correl ||'-'|| p.ann_programacion) LIKE '%"+filtro.getNumProgramacionUnion().trim()+"%' ");
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNroInformeUnion())) {
//			builder.append(" AND ('IS'||'-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) LIKE nroInformeUnion ");
//			params.addProperty("nroInformeUnion", "%" + filtro.getNroInformeUnion() + "%");
			builder.append(" AND ('IS-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) LIKE '%"+filtro.getNroInformeUnion().trim()+"%' ");
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodPers())) {
			builder.append(" AND g.num_grupo = (SELECT num_grupo FROM t8303distrigrupo WHERE cod_pers = ?codPers) ");
			params.addProperty("codPers", filtro.getCodPers());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodProgctrl())) {
			builder.append(" AND p.cod_progctrl = ?codProgctrl ");
			params.addProperty("codProgctrl", filtro.getCodProgctrl());
		}
		// nroProg
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramaCorrel())) {
			builder.append(" AND p.num_prog_correl = ?numProgCorrel ");
			params.addProperty("numProgCorrel", filtro.getNumProgramaCorrel());
		}
		// alcance
		if (!MaestrosUtilidades.isEmpty(filtro.getDesAlcance())) {
			builder.append(" AND p.des_alcance = ?desAlcance ");
			params.addProperty("desAlcance", filtro.getDesAlcance());
		}
		// estadoProg
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
			builder.append(" AND p.cod_est_program = ?codEstadoPrograma ");
			params.addProperty("codEstadoPrograma", filtro.getCodEstadoPrograma());
		}
		// !fechaHasta && !fechaDesde
		if (!MaestrosUtilidades.isEmpty(filtro.getFechaDesde()) && !MaestrosUtilidades.isEmpty(filtro.getFechaHasta())) {
			builder.append(" AND ((a.fec_ini_asignacion > ?fechaInicioAsig AND a.fec_ini_asignacion <= ?fechaFinAsig)")
				   .append(" OR   (p.fec_programacion > ?fechaInicioAsig AND p.fec_programacion <= ?fechaFinAsig) ) ");
			params.addProperty("fechaInicioAsig", filtro.getFechaDesde());
			params.addProperty("fechaFinAsig", filtro.getFechaHasta());
		}
		// fechaHasta && !fechaDesde
		else if (!MaestrosUtilidades.isEmpty(filtro.getFechaDesde()) && MaestrosUtilidades.isEmpty(filtro.getFechaHasta())) {
			builder.append(" AND ((a.fec_ini_asignacion > ?fechaInicioAsig AND p.fec_programacion > ?fechaInicioAsig)) ");
			params.addProperty("fechaInicioAsig", filtro.getFechaDesde());
		}
	// !fechaHasta && fechaDesde
		else if (MaestrosUtilidades.isEmpty(filtro.getFechaDesde()) && !MaestrosUtilidades.isEmpty(filtro.getFechaHasta())) {
			builder.append(" AND ((a.fec_ini_asignacion <= ?fechaFinAsig AND p.fec_programacion <= ?fechaFinAsig)) ");
			params.addProperty("fechaFinAsig", filtro.getFechaHasta());
		}
		// nroInforme
		if (!MaestrosUtilidades.isEmpty(filtro.getNumInforme())) {
			builder.append(" AND i.num_inf_selecc = ?numInforme");
			params.addProperty("numInforme", filtro.getNumInforme());
		}
		// estadoInformeSeleccion
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstInforme())) {
			builder.append(" AND i.cod_est_informe = ?codEstadoInforme");
			params.addProperty("codEstadoInforme", filtro.getCodEstInforme());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
			builder.append(" AND p.num_programacion = ?numProgramacion ");
			params.addProperty("numProgramacion", filtro.getNumProgramacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodPers())) {
			builder.append(" AND a.cod_pers = ?codProgramadorAdmin ");
			params.addProperty("codProgramadorAdmin", filtro.getCodProgramadorAdmin());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getIndTipoAsignacion())) {
			builder.append(" AND a.ind_tip_asignacion = ?indTipoAsignacion");
			params.addProperty("indTipoAsignacion", filtro.getIndTipoAsignacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getIndDel())){
			builder.append(" AND p.ind_del = ?indDel ");
			params.addProperty("indDel", filtro.getIndDel());		 
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getIndEst())){
			builder.append(" AND p.ind_est = ?indEst ");
			params.addProperty("indEst", filtro.getIndEst());		 
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getDesAlcance())){
//			builder.append(" AND p.des_alcance  LIKE ?desAlcance ");
//			params.addProperty("desAlcance","'%".concat(filtro.getDesAlcance()).concat("%'"));
			builder.append(" AND p.des_alcance  LIKE '%"+filtro.getDesAlcance().trim()+"%' ");
		}
		
		// programadorAsignado
		//AND p.num_prog_correl = # num_prog_correl #
		//AND p.cod_progctrl = # cod_progctrl #
		//AND p.cod_programdor = # cod_programdor # 
		//AND a.cod_pers = # cod_progAdmin #

		logger.debug(String.format("JPAT10420ProgramacionDAO: query => %s", builder.toString()));		
		System.out.print(String.format("JPAT10420ProgramacionDAO: query => %s", builder.toString()));	
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, Programacion.class);
	}

	@Override
	public List<Programacion> listarConsultaProgramacion(Programacion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10420ProgramacionDAO - listarProgramacion");

		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT p.num_programacion as numProgramacion, p.num_prog_correl as numProgramaCorrel, p.cod_progctrl as codProgctrl,(SELECT des_denominacion FROM t8276catprogctrl ")
		.append("WHERE cod_progctrl= p.cod_progctrl) as desProgctrl, t.cod_tip_inconsis as codTipInconsis, o.cod_resul_inconsis as codResulInconsis, ")
		.append("o.cod_resul_incondef as codResulIncondef, p.per_inicio as perInicio, p.per_fin as perFin, u.cod_tip_docident as codTipoDocumentoIdent, ")
		.append("u.num_doc_ident as numDocumentoIdent, u.nom_ape_usu as nombApeUsuario, ")
		.append("i.cod_est_informe as codEstadoInforme, u.cod_tip_accion as codTipoAccion,  ")
		.append("o.cod_tip_orden as codTipoOrden, ")
		.append("o.cod_est_orden as codEstOrden, c.cod_pers as codPers, x.cod_pers as codPersApoyo, o.cod_resul_orden as codResOrden ")
		.append("FROM t10420programacion p ")
		.append("LEFT JOIN t10411informeselec i ON p.num_programacion = i.num_programacion ")
		.append("LEFT JOIN t10428usuarioprog u ON p.num_programacion = u.num_programacion ")
		.append("LEFT JOIN t10425tipinconprog t ON p.num_programacion = t.num_programacion ")
		.append("LEFT JOIN t10398bienprog b ON p.num_programacion = b.num_programacion ")
		.append("LEFT JOIN t10415ordenaccion o ON u.num_usu_program = o.num_usu_program ")
		.append("LEFT JOIN t10392asignprogram a ON p.num_programacion = a.num_programacion ")
		.append("LEFT JOIN t10410histestaprog h ON p.num_programacion = h.num_programacion ")
		.append("LEFT JOIN t8303distrigrupo g ON p.cod_programador = g.cod_pers ")
		.append("LEFT JOIN t10394asignausuacc c ON u.num_usu_program = c.num_usu_program ")
		.append("LEFT JOIN t10394asignausuacc x ON u.num_usu_program = x.num_usu_program WHERE 1 = 1 ");

		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodClaseAccion())) {
			params.addProperty("codClaseAccion", AccionesControlConstantes.COD_CLASE_DOCUMENTO_ACCION);
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getCodClaseVincul())) {
			params.addProperty("codClaseVincul", AccionesControlConstantes.COD_CLASE_DOCUMENTO_VINCULADO);
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNroInformeUnion())) {
//			builder.append(" AND ('IS-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) LIKE ?nroInformeUnion ");
//			params.addProperty("nroInformeUnion", "%" + filtro.getNroInformeUnion() + "%");
			builder.append(" AND ('IS-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) LIKE '%"+filtro.getNroInformeUnion().trim()+"%' ");
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocAccion())) {
			builder.append(" (SELECT ('N�-'||v.num_correl_doc||'-'||v.ann_doc||'-'||v.cod_uuoo_doc) FROM t10406documeaccion v ")
			.append(" WHERE v.num_usu_program = u.num_usu_program AND v.cod_clase= ?codClaseAccion) LIKE '%"+filtro.getNumDocAccion() + "%");
			//params.addProperty("numDocAccion", "%" + filtro.getNumDocAccion() + "%");
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumOrden())) {
			builder.append("AND (o.num_correl_orden||'-'||o.ann_orden||'-'||o.cod_uuoo_orden) LIKE ?numOrden ");
			params.addProperty("numOrden", "%" + filtro.getNumOrden() + "%");
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocVin())) {
			builder.append("(SELECT ('N�-'||v.num_correl_doc ||'-'||v.ann_doc||'-'||v.cod_uuoo_doc) ")
			.append("FROM t10406documeaccion v WHERE v.num_usu_program = u.num_usu_program AND v.cod_clase= ?codClaseVincul) LIKE '%"+ filtro.getNumDocVin() + "%");
//			params.addProperty("numDocVin", "%" + filtro.getNumDocVin() + "%");
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodCargoPrincipal())) {
			builder.append(" AND c.cod_cargo= ?codCargoPrincipal ");
			params.addProperty("codCargoPrincipal", filtro.getCodCargoPrincipal());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodCargoApoyo())) {
			builder.append(" AND c.cod_cargo= ?codCargoApoyo ");
			params.addProperty("codCargoApoyo", filtro.getCodCargoApoyo());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodProgctrl())) {
			builder.append(" AND p.cod_progctrl = ?codProgctrl ");
			params.addProperty("codProgctrl", filtro.getCodProgctrl());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoDocumentoIdent())) {
			builder.append(" AND u.cod_tip_docident = ?codTipoDocumentoIdent ");
			params.addProperty("codTipoDocumentoIdent", filtro.getCodTipoDocumentoIdent());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocumentoIdent())) {
			builder.append(" AND u.num_doc_ident = ?numDocumentoIdent ");
			params.addProperty("numDocumentoIdent", filtro.getNumDocumentoIdent());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoOrden())) {
			builder.append(" AND o.cod_tip_orden = ?codTipoOrden ");
			params.addProperty("codTipoOrden", filtro.getCodTipoOrden());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getPerInicio())) {
			builder.append(" AND p.per_inicio >= ?perInicio ");
			params.addProperty("perInicio", filtro.getPerInicio());
		}
		
		
		if (!MaestrosUtilidades.isEmpty(filtro.getPerFin())) {
			builder.append(" AND p.per_inicio <= ?perFin ");
			params.addProperty("perFin", filtro.getPerFin());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipInterv())) {
			builder.append(" AND u.cod_tip_interv = ?codTipInterv ");
			params.addProperty("codTipInterv", filtro.getCodTipInterv());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoAccion())) {
			builder.append(" AND u.cod_tip_accion = ?codTipoAccion' ");
			params.addProperty("codTipoAccion", filtro.getCodTipoAccion());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoInforme())) {
			builder.append(" AND i.cod_est_informe = ?codEstadoInforme ");
			params.addProperty("codEstadoInforme", filtro.getCodEstadoInforme());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstOrden())) {
			builder.append(" AND o.cod_est_orden = ?codEstOrden ");
			params.addProperty("codEstOrden", filtro.getCodEstOrden());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipInconsis())) {
			builder.append(" AND t.cod_tip_inconsis IN ?codTipInconsis ");
			params.addProperty("codTipInconsis", filtro.getInconsistencias().stream()
					.map(DataCatalogoBean::getCodDataCatalogo)
					.collect(Collectors.toList()));
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoBien())) {
			builder.append(" AND b.cod_tip_bien IN ?codTipoBien ");
			params.addProperty("codTipoBien", filtro.getTipoBienes().stream()
					.map(DataCatalogoBean::getCodDataCatalogo)
					.collect(Collectors.toList()));
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getBienesFiscalizados())) {
			builder.append(" AND b.cod_bien IN ?codBien ");
			params.addProperty("codBien", filtro.getBienesFiscalizados().stream()
					.map(BienFiscalizadoSolicitudBean::getCodBienFiscalizado)
					.collect(Collectors.toList()));
		}
		
		logger.debug(String.format("JPAT10420ProgramacionDAO: query => %s", builder.toString()));
	    System.out.println(String.format("JPAT10420ProgramacionDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				Programacion.class);
	}

	@Override

	public List<Programacion> listarReasignacionProgramacion(Programacion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10420ProgramacionDAO - listarProgramacion");

		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT p.num_programacion as numProgramacion, p.num_prog_correl as numProgramaCorrel, p.cod_progctrl as codProgctrl, ")
		.append("p.cod_progctrl ||' - '|| (SELECT des_denominacion FROM t8276catprogctrl WHERE cod_progctrl= p.cod_progctrl) as des_progctrl, ")
		.append("p.fec_programacion as fecProgramacion, p.per_inicio as perInicio, p.per_fin as perFin, p.cod_est_program as codEstadoPrograma, ")
		.append("h.fec_est_program as fecEstPrograma, ('IS'||'-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) as nroInformeUnion, ")
		.append("i.cod_est_informe as codEstadoInforme, i.cod_est_informe as codEstadoInforme, ")
		.append("s.cod_pers as codProgramador, a.cod_pers as codProgramadorAdmin ")
		.append("FROM t10420programacion p ")
		.append("LEFT JOIN t10411informeselec i ON p.num_programacion = i.num_programacion AND i.ind_del = ")
		.append(AccionesControlConstantes.REGISTRO_NOELIMINADO)
		.append(" LEFT JOIN t10392asignprogram s ON p.num_programacion = s.num_programacion AND s.ind_tip_asignacion = ")
		.append(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR)
		.append(" AND s.fec_ini_asignacion = (select max(fec_ini_asignacion) FROM t10392asignprogram WHERE num_programacion = p.num_programacion AND  ind_tip_asignacion = ")
		.append(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR)
		.append(" ) ")
		.append(" LEFT JOIN t10392asignprogram a ON p.num_programacion = a.num_programacion AND a.ind_tip_asignacion = ")
		.append(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR_ADMIN)
		.append(" AND a.fec_ini_asignacion = (select max(fec_ini_asignacion) FROM t10392asignprogram WHERE num_programacion = p.num_programacion AND  ind_tip_asignacion = ")
		.append(AccionesControlConstantes.COD_TIPO_ASIGNA_PROGRAMADOR_ADMIN)
		.append(" ) ")
		.append(" LEFT JOIN t10410histestaprog h ON p.num_programacion = h.num_programacion AND h.fec_est_program = (select max(fec_est_program) FROM t10410histestaprog WHERE num_programacion = p.num_programacion) WHERE 1=1 ");
	
		params.addProperty("indTipoAsignacion", filtro.getIndTipoAsignacion());
		
		if (!MaestrosUtilidades.isEmpty(filtro.getDesProgctrl())) {
//			builder.append(" AND (p.cod_progctrl||' - '||(SELECT des_denominacion FROM t8276catprogctrl WHERE cod_progctrl= p.cod_progctrl)) LIKE desProgctrl ");
//			params.addProperty("desProgctrl", "%" + filtro.getDesProgctrl() + "%");
			builder.append(" AND (p.cod_progctrl||' - '||(SELECT des_denominacion FROM t8276catprogctrl WHERE cod_progctrl= p.cod_progctrl)) LIKE '%"+filtro.getDesProgctrl().trim()+"%' ");
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNroInformeUnion())) {
//			builder.append(" AND ('IS'||'-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) LIKE nroInformeUnion ");
//			params.addProperty("nroInformeUnion", "%" + filtro.getNroInformeUnion() + "%");
			builder.append(" AND ('IS-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) LIKE '%"+filtro.getNroInformeUnion().trim()+"%' ");
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramaCorrel())) {
			builder.append(" AND p.num_programador = ?numProgramacion ");
			params.addProperty("numProgramacion", filtro.getNumProgramacion());
		}
		
		// nroProg
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramaCorrel())) {
			builder.append(" AND p.num_prog_correl = ?numProgCorrel ");
			params.addProperty("numProgCorrel", filtro.getNumProgramaCorrel());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodProgctrl())) {
			builder.append(" AND p.cod_progctrl = ?codProgctrl ");
			params.addProperty("codProgctrl", filtro.getCodProgctrl());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
			builder.append(" AND p.cod_est_program= ?codEstadoPrograma ");
			params.addProperty("codEstadoPrograma", filtro.getCodEstadoPrograma());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoPrograma())) {
			builder.append(" AND p.cod_est_program NOT IN (?codEstadoPrograma) ");
		}
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, Programacion.class);
	}	
	public Programacion obtenerResuProgramacion(Programacion filtro) {
		
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10420ProgramacionDAO - obtenerResuProgramacion");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder
		.append(" SELECT first 1 ")
		.append(" p.num_programacion, p.num_prog_correl, i.num_inf_selecc, ")
		.append(" i.num_correl, p.cod_progctrl, d.num_grupo ")
		.append(" FROM t10420programacion p ")
		.append(" LEFT JOIN t10411informeselec i ON p.num_programacion = i.num_programacion ")
		.append(" LEFT JOIN t8303distrigrupo d ON d.cod_pers = p.cod_programador ")
		.append(" AND d.ind_est=\"1\" ")
		.append(" WHERE 1=1 ");
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
			builder.append(" AND p.num_prog_correl = ?numProgramacion ");
			params.addProperty("numProgramacion", filtro.getNumProgramacion());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumInforme())) {
			builder.append(" OR i.num_correl = ?numInforme");
			params.addProperty("numInforme", filtro.getNumInforme());
		}
		
		logger.debug(String.format("JPAT10420ProgramacionDAO: query => %s", builder.toString()));
	    System.out.println(String.format("JPAT10420ProgramacionDAO: query => %s", builder.toString()));

	
		
	    return (Programacion) this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF);
	}

}
