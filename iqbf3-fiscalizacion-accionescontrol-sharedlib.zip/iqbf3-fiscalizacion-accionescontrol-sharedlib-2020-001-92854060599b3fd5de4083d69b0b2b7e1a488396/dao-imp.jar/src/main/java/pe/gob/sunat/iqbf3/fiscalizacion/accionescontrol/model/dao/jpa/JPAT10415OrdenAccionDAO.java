package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10415OrdenAccionDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10415OrdenAccionDAO extends AbstractDAOImpl<OrdenAccion, Long> implements T10415OrdenAccionDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10415OrdenAccionDAO.class);

	public JPAT10415OrdenAccionDAO() {
		super(OrdenAccion.class);
	}

	@Override
	public List<OrdenAccion> vigenciaUsuarioOrden(OrdenAccion filtro) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10415OrdenAccionDAO - vigenciaUsuarioOrden");
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT B.num_orden as numOrden, B.cod_est_orden as codEstadoOrden, C.cod_pers as codPers, C. fec_orden as fecOrden ") 
			   .append("FROM t10428usuarioprog A INNER JOIN t10415ordenaccion B ") 
			   .append("ON A.num_usu_program=B.num_usu_program INNER JOIN t10394asignausuacc C ") 
			   .append("ON A.num_usu_program=C.num_usu_program WHERE A.cod_tip_docident=?codTipDocIdent ") 
			   .append("AND A.num_doc_ident= ?numDocIdent AND B.cod_est_orden NOT IN ?estados ");
		params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
		params.addProperty("numDocIdent", filtro.getNumDocIdent());
		params.addProperty("estados", filtro.getEstados());
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				OrdenAccion.class);
	}
	
	// INI AGF
	@Override
	public List<OrdenAccion> listarOrdenGenerada(OrdenAccion filtro){
																		 
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
				
		builder.append("SELECT  o.num_orden as numOrden, ")
				.append("o.num_usu_program as numUsuarioPrograma,  ")
				.append("u.cod_est_reg as codEstadoRegistro,  ")
				.append("u.num_verreg as numVersionRegistro,  ")
				.append("p.cod_progctrl as codProgctrl,  ")
				.append("d.num_doc_accion as numDocumentoAccion,  ")
			    .append("d.fec_notificacion as fecNotificacion, ")
			    .append("d.fec_fin_subsanacio as fecFinSubsanacion, ")
			    .append("u.cod_tip_docident as codTipoDocumentoIdentif, ")
				.append("u.num_doc_ident as numDocumentoIdentif, ")
				.append("u.num_peridoomisomin as numPeridoOmisoMin, ")
				.append("u.num_peridoomisomax as numPeridoOmisoMax, ")
				.append("u.cod_tip_inconsis as codTipInconsis ")
		.append("FROM t10415ordenaccion o ")
	    .append("INNER JOIN t10406documeaccion d ")
	    .append("ON  d.num_usu_program = o.num_usu_program ") 
	    .append("AND d.ind_origen=  '1'  ")// #ind_origen#--'1' --- electronico 
	    .append("AND d.cod_clase =  '02'  ")// # cod_clase #---'02' ---documento de la acci�n 	
	    .append("INNER JOIN t10428usuarioprog u ")
	    .append("ON o.num_usu_program = u.num_usu_program ")
	    .append("INNER JOIN t10420programacion p  ")
	    .append("ON u.num_programacion = p.num_programacion ")
	    .append("WHERE 1=1 ");

		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoOrden())) {
			builder.append("and o.cod_est_orden = ?codEstadoOrden "); //cod_est_orden
			params.addProperty("codEstadoOrden", filtro.getCodEstadoOrden());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodProgCtrl())) {
			builder.append("AND p.cod_progctrl <> ?codProgCtrl ");//cod_progctrl
			params.addProperty("codProgCtrl", filtro.getCodProgCtrl());
		}
	
		logger.debug(String.format("JPAT10415OrdenAccionDAO: query => %s", builder.toString()));
		
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, OrdenAccion.class);
					   
	}

	@Override
	public List<OrdenAccion> listarOrden(OrdenAccion filtro){
		
																		 
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ")
		.append(" o.cod_tip_orden as codTipoOrden, ")
		.append(" o.num_correl_orden as numCorrel, ")
		.append("('IS'||'-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) as numInformeUnion, ")
		.append("(SELECT (p.cod_progctrl||' - '||c.des_denominacion)  FROM t8276catprogctrl ")
		.append("WHERE cod_progctrl= p.cod_progctrl) as desProgCtrl, ")
		.append(" o.ann_orden as anioOrden, ")
		.append(" o.cod_uuoo_orden as codUnidadOrganica, ")
		.append(" o.num_orden as numOrden, ")
		.append("(o.num_correl_orden||'-'||o.ann_orden||'-'||o.cod_uuoo_orden) as numOrdenUnion, ")
		.append(" u.cod_tip_docident as codTipoDocumentoIdentif, ")
		.append(" u.num_doc_ident as numDocIdent, ")
		.append(" u.nom_ape_usu as nomApellidoUsuario, ")
		.append(" u.nom_ape_usu as nomApeUsuario, ")
		.append(" p.num_prog_correl as numProgramaCorrel, ")
		.append(" p.num_programacion as numProgramacion, ")
		.append(" p.cod_progctrl as codProgCtrl, ")
		.append(" c.des_denominacion as desDenominacion, ")
		.append(" i.num_correl as informeNumCorrel, ")
		.append(" i.ann_informe as informeAnio, ")
		.append(" i.cod_uuoo as informeCodUUOO, ")
		.append(" i.cod_uuoo as codUnidadOrganicaInforme, ")
		.append(" u.cod_tip_accion as codTipAccion, ")
		.append(" d.num_documento as numDocumentoAccion, ")
		.append(" o.fec_asig_orden as fecAsigOrden, ")
		.append(" o.cod_est_orden as codEstadoOrden, ")
		.append(" o.cod_resul_orden as codResulOrden, ")
		.append(" r.num_doc as numDoc, ")
		.append(" r.num_doc as numDocumentoOrden, ")
		.append(" s.cod_pers as codPers")
		.append(" FROM t10415ordenaccion o ")
		.append(" INNER JOIN t10428usuarioprog u ")
		.append(" ON o.num_usu_program = u.num_usu_program ")
		.append(" LEFT JOIN t10407documenorden r ")
		.append(" ON o.num_orden = r.num_orden ")
		.append(" LEFT JOIN t10406documeaccion d ")
		.append(" ON u.num_usu_program = d.num_usu_program ")
		.append(" LEFT JOIN t10394asignausuacc s ")
		.append(" ON u.num_usu_program = s.num_usu_program ")
		.append(" LEFT JOIN t10420programacion p ")
		.append(" ON u.num_programacion = p.num_programacion ")
		.append(" LEFT JOIN t10411informeselec i ")
		.append(" ON p.num_programacion = i.num_programacion ")
		.append(" LEFT JOIN t8276catprogctrl c ")
		.append("  ON p.cod_progctrl = c.cod_progctrl ")
		.append(" WHERE 1=1 ");
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoOrden())) {
			builder.append(" AND o.cod_tip_orden = ?codTipoOrden ");
			params.addProperty("codTipoOrden", filtro.getCodTipoOrden());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getCodPers())) {
			builder.append(" AND g.num_grupo = (SELECT num_grupo FROM t8303distrigrupo WHERE cod_pers = ?codPers) ");
			params.addProperty("codPers", filtro.getCodPers());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
			//builder.append(" AND p.num_correl_prog=?numProg ");
			builder.append(" AND p.num_programacion=?numProg ");
			params.addProperty("numProg", filtro.getNumProgramacion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumOrden())) {
			builder.append(" AND o.num_orden = ?numOrden ");
			params.addProperty("numOrden", filtro.getNumOrden());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getFecAsigIni()) && !MaestrosUtilidades.isEmpty(filtro.getFecAsigFin())) {
			builder.append(" AND o.fec_asig_orden BETWEEN ?fecAsigIni AND ?fecAsigFin ");
			params.addProperty("fecAsigIni", filtro.getFecAsigIni());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getFecAsigIni())) {
			builder.append(" AND o.fec_asig_orden >= ?fecAsigIni ");
			params.addProperty("fecAsigIni", filtro.getFecAsigIni());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getFecAsigFin())) {
			builder.append(" AND o.fec_asig_orden <= ?fecAsigFin ");
			params.addProperty("fecAsigFin", filtro.getFecAsigFin());
		}
		
		if(!MaestrosUtilidades.isEmpty(filtro.getCodOrigen())) {
			builder.append(" AND r.cod_origen = ?codOrigen ");
			params.addProperty("codOrigen", filtro.getCodOrigen());
		}
		
//		if (!MaestrosUtilidades.isEmpty(filtro.getFecAsigIni())) {
//			builder.append(" AND a.fec_asig_orden >= ?fecAsigIni ");
//			params.addProperty("fecAsigIni", filtro.getFecAsigIni());
//		}
//		
//		if (!MaestrosUtilidades.isEmpty(filtro.getFecAsigFin())) {
//			builder.append(" AND a.fec_asig_orden <= ?fecAsigFin ");
//			params.addProperty("fecAsigFin", filtro.getFecAsigFin());
//		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipDocIdent())) {
			builder.append(" AND u.cod_tip_docident = ?codTipDocIdent ");
			params.addProperty("codTipDocIdent", filtro.getCodTipDocIdent());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND u.num_doc_ident = ?numDocIdent ");
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getNumCorrel())) {
			builder.append(" AND i.num_correl = ?numCorrel ");
			params.addProperty("numCorrel", filtro.getNumCorrel());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getNumInforResul())) {
			builder.append(" AND r.num_doc = ?numInforResul ");
			params.addProperty("numInforResul", filtro.getNumInforResul());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getCodEstadoOrden())) {
			builder.append(" AND o.cod_est_orden = ?codEstadoOrden ");
			params.addProperty("codEstadoOrden", filtro.getCodEstadoOrden());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getEstados())) {
			builder.append(" AND o.cod_est_orden in ?estados ");
			params.addProperty("estados", filtro.getEstados());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocAccion())) {
			builder.append(" AND d.num_documento = ?numDocAccion ");
			params.addProperty("numDocAccion", filtro.getNumDocAccion());
		}
		
		if (!MaestrosUtilidades.isEmpty(filtro.getCodProgCtrl())) {
			builder.append(" AND p.cod_progctrl = ?codProgCtrl ");
			params.addProperty("codProgCtrl", filtro.getCodProgCtrl());
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getNumOrdenUnion())){
			builder.append("AND (o.num_correl_orden||'-'||o.ann_orden||'-'||o.cod_uuoo_orden) LIKE '%"+filtro.getNumOrdenUnion()+"%' ");
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getNumInformeUnion())) {
//			builder.append(" AND ('IS'||'-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) LIKE nroInformeUnion ");
//			params.addProperty("nroInformeUnion", "%" + filtro.getNroInformeUnion() + "%");
			builder.append(" AND ('IS-'||i.num_correl||'-'||i.ann_informe||'-'||i.cod_uuoo) LIKE '%"+filtro.getNumInformeUnion().trim()+"%' ");
		}
		if(!MaestrosUtilidades.isEmpty(filtro.getIndDel())){
			builder.append(" AND i.ind_del = ?indDel and r.ind_del = ?indDel");
			params.addProperty("indDel", filtro.getIndDel());
		}

		if(!MaestrosUtilidades.isEmpty(filtro.getIndEst())){
			builder.append(" AND i.ind_est = ?indEst and r.ind_est = ?indEst ");
			params.addProperty("indEst", filtro.getIndEst());
		}		

		if(!MaestrosUtilidades.isEmpty(filtro.getCodCargo())){
			builder.append(" AND s.cod_cargo = ?codCargo ");
			params.addProperty("codCargo", filtro.getCodCargo());
		}	

		if(!MaestrosUtilidades.isEmpty(filtro.getCodClase())){
			builder.append(" AND d.cod_clase = ?codClase ");
			params.addProperty("codClase", filtro.getCodClase());
		}
		        //.append(" o.cod_tip_orden = # cod_tip_orden #
				//.append(" AND g.num_grupo = (SELECT num_grupo FROM t8303distrigrupo WHERE cod_pers = # cod_pers # )
				//.append(" AND a.num_orden = # num_orden #
				//.append(" AND a.cod_pers = # %nom_apel_auditor% # PENDIENTE DE CONSULTAR ANALISTA
				//.append(" AND a.fec_asig_orden >= # fec_asigini #
				//.append(" AND a.fec_asig_orden <= # fec_asigfin #
				//.append(" AND u.cod_tip_docident = # cod_tip_docident #
				//.append(" AND u.num_doc_ident = # num_doc_ident #
				//.append(" AND i.num_correl = # num_infor_selec #
				//.append(" AND d.num_doc = # num_infor_resul #
				//.append(" AND o.cod_est_orden = # cod_est_orden #
				//.append(" AND d.num_documento = # num_doc_accion #
				//.append(" AND p.cod_progctrl = # cod_prog_ctrl # 
		logger.debug(String.format("JPAT10415OrdenAccionDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, OrdenAccion.class);
	}
	
	
	@Override
	public List<OrdenAccion> obtenerResumenOrdPend(OrdenAccion filtro) {
	
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append(" SELECT C.cod_resul_inconsis as codResultadoInconsistenciaPre, COUNT (*) AS TOTAL ")
		.append(" FROM t10420programacion A, t10428usuarioprog B, t10415ordenaccion C, ") 
		.append(" t10411informeselec D ")
		.append(" WHERE A.num_programacion= B.num_programacion AND ")
		.append(" B.num_usu_program=C.num_usu_program AND A.num_prog_correl= ")          
		.append(" ?numProgCorrel AND D.num_inf_selecc= ?numInfSelecc ") 
		.append(" AND    C.cod_est_orden= ?codEstOrden AND ")           
		.append(" cod_resul_orden= ?codResulOrden AND ")
		.append(" D.num_programacion=A.num_programacion ")
		.append(" GROUP BY C.cod_resul_inconsis ")
		.append(" HAVING C.cod_resul_inconsis=?noSubSano ") 
		.append(" UNION SELECT C.cod_resul_inconsis, COUNT (*) AS TOTAL ")
		.append(" FROM t10420programacion A, t10428usuarioprog B, t10415ordenaccion C, ") 
		.append(" t10411informeselec D ")
		.append(" WHERE A.num_programacion= B.num_programacion AND ")
		.append(" B.num_usu_program=C.num_usu_program AND A.num_prog_correl=?numProgCorrel ")          
		.append(" AND D.num_inf_selecc= ?numInfSelecc  ")
		.append(" AND C.cod_est_orden= ?codEstOrden AND ")          
		.append(" cod_resul_orden= ?codResulOrden AND ")
		.append(" D.num_programacion=A.num_programacion ")
		.append(" GROUP BY C.cod_resul_inconsis ")
		.append(" HAVING C.cod_resul_inconsis=?parcialmente ");

		params.addProperty("numProgCorrel", filtro.getNumProgCorrel());
		params.addProperty("numInfSelecc", filtro.getNumInfSelecc());
		params.addProperty("noSubSano", filtro.getNoSubSano());
		params.addProperty("parcialmente", filtro.getParcialmente());
		params.addProperty("codEstOrden", filtro.getCodEstOrden());
		params.addProperty("codResulOrden", filtro.getCodResulOrden());

		logger.debug(String.format("JPAT10415OrdenAccionDAO: query => %s", builder.toString()));

		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, OrdenAccion.class);
	}

	@Override
	public OrdenAccion obtenerDatosOrden(Long numOrden, String codClase) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10415OrdenAccionDAO - vigenciaUsuarioOrden");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		OrdenAccion ordenAccion = new OrdenAccion();
		
		builder.append("SELECT ")
		.append(" o.num_orden as numOrden, ")
		.append(" o.cod_tip_orden as codTipoOrden, ")
		.append(" o.num_correl_orden as numCorrel, ")
		.append(" o.ann_orden as anioOrden, ")
		.append(" o.cod_uuoo_orden as codUnidadOrganica, ")
		.append(" o.fec_orden as fecOrden, ")
		.append(" o.fec_asig_orden as fecAsigOrden, ")
		.append(" u.num_usu_program as numUsuarioPrograma, ")
		.append(" u.cod_tip_docident as codTipoDocumentoIdentif, ")
		.append(" u.num_doc_ident as numDocumentoIdentif, ")
		.append(" u.nom_ape_usu as nomApellidoUsuario , ")
		.append(" u.cod_tip_accion as codTipoAccion , ")
		.append(" d.num_correl_doc as numCorrelDoc, ")
		.append(" d.ann_doc as annDoc, ")
		.append(" d.cod_uuoo_doc as codUuooDoc, ")
		.append(" d.num_documento as numDocumentoAccion, ")
		.append(" p.cod_progctrl as codProgCtrl, ")
		.append(" u.cod_est_reg as codEstadoRegistro, ")
		.append(" o.cod_est_orden as codEstadoOrden, ")
		.append(" o.cod_resul_orden as codResulOrden, ")
		.append(" o.cod_resul_inconsis as codResultadoInconsistenciaPre, ")
		.append(" o.cod_resul_incondef as codResultadoInconsistenciaDef, ")
		.append(" o.des_sus_resul as desSusResul, ")
		.append(" o.fec_derivacion as fecDerivacion, ")
		.append(" o.ind_realizo_accion as indRealizoAccion, ")
		.append(" o.des_sus_noaccion as desSusNoaccion, ")
		.append(" o.ind_primera_visit as indPrimeraVisit, ")
		.append(" o.ind_segunda_visit as indSegundaVisit, ")
		.append(" o.fec_primera_visit as fecPrimeraVisita, ")
		.append(" o.fec_segunda_visit as fecSegundaVisit, ")
		.append(" o.ind_solic_prorroga as indSolicProrroga, ")
		.append(" o.fec_ini_caso as fecInicioCaso, ")
		.append(" o.fec_solic_prorroga as fecSolicProrroga, ")
		.append(" o.fec_ini_casonue as fecInicioCasoNuevo, ")
		.append(" o.ind_bloq_djro as indBloqDjro, ")
		.append(" o.cod_recomendacion as codRecomendacion, ")
		.append(" o.des_recomendacion as desRecomendacion, ")
		.append(" o.obs_resultado as obsResultado, ")
		.append(" o.des_sus_cancela as desSusCancela, ")
		.append(" o.fec_cancelacion as fecCancelacion, ")
		.append(" o.num_arc as numArc, ")
		.append(" o.des_sus_devolucion as desSusDevolucion ")
		.append(" FROM t10415ordenaccion o ")
		.append(" INNER JOIN t10428usuarioprog u ")
		.append(" ON o.num_usu_program = u.num_usu_program ")
		.append(" INNER JOIN t10406documeaccion d ")
		.append(" ON o.num_usu_program = u.num_usu_program ")
		.append(" INNER JOIN t10420programacion p ")
		.append(" ON u.num_programacion = p.num_programacion ");
		
		if (!MaestrosUtilidades.isEmpty(codClase)) {
			builder.append(" AND d.cod_clase = ?codClase ");
			params.addProperty("codClase", codClase);
		}
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			builder.append(" WHERE o.num_orden = ?numOrden ");
			params.addProperty("numOrden", numOrden);
		}
		
		List<OrdenAccion> lista = this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, OrdenAccion.class);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			ordenAccion = lista.get(0);
		}
		return ordenAccion;
	}

	@Override
	public OrdenAccion obtenerDetalleInconsistencia(Long numUsuarioPrograma) {
		if (logger.isDebugEnabled())
			logger.debug("Inicio JPAT10415OrdenAccionDAO - obtenerDetalleInconsistencia");
		
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		OrdenAccion ordenAccion = new OrdenAccion();
		
		builder.append("SELECT ")
		.append(" u.num_programacion as numProgramacion, ")
		.append(" u.num_doc_ident as numDocumentoIdentif, ")
		.append(" u.nom_ape_usu as nomApellidoUsuario, ")
		.append(" u.fec_crea as fecCrea, ")
		.append(" u.cod_est_usu as codEstadoUsuario, ")
		.append(" p.per_inicio as perInicio, ")
		.append(" p.per_fin as perFin, ")
		.append(" p.num_prog_correl as numProgramaCorrel ")
		.append(" FROM t10415ordenaccion o ")
		.append(" INNER JOIN t10428usuarioprog u ")
		.append(" ON o.num_usu_program = u.num_usu_program ")
		.append(" INNER JOIN t10420programacion p ")
		.append(" ON u.num_programacion = p.num_programacion ");
		
		if (!MaestrosUtilidades.isEmpty(numUsuarioPrograma)) {
			builder.append(" WHERE o.num_usu_program = ?numUsuarioPrograma ");
			params.addProperty("numUsuarioPrograma", numUsuarioPrograma);
		}
		List<OrdenAccion> lista = this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, OrdenAccion.class);
		if (!MaestrosUtilidades.isEmpty(lista)) {
			ordenAccion = lista.get(0);
		}
		return ordenAccion;
	}

	@Override
	public List<OrdenAccion> actualizarOrden(OrdenAccion formulario) {
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
				
		builder.append("UPDATE t10415ordenaccion SET ")
		.append(" obs_resultado as obsResultado= ?obsResultado, ind_realizo_accion as indRealizoAccion = ?indRealizoAccion, fec_ini_caso as fecInicioCaso = ?fecInicioCaso, ")
		.append(" ind_solic_prorroga as indSolicProrroga = ?indSolicProrroga, fec_solic_prorroga as fecSolicProrroga = ?fecSolicProrroga, fec_ini_casonue as fecInicioCasoNuevo = ?fecInicioCasoNuevo, ")
		.append(" ind_primera_visit as indPrimeraVisit = ?indPrimeraVisit, ind_segunda_visit as indSegundaVisit = ?indSegundaVisit, fec_primera_visit as fecPrimeraVisiat = ?fecPrimeraVisiat, ")
		.append(" fec_segunda_visit as fecSegundaVisit = ?fecSegundaVisit, cod_recomendacion as codRecomendacion = ?codRecomendacion, des_recomendacion as desRecomendacion = ?desRecomendacion, ")
		.append(" cod_resul_incondef as codResultadoInconsistenciaDef = ?codResultadoInconsistenciaDef, cod_resul_orden as codResulOrden= ?codResulOrden, cod_usumodif as codUsuModif = ?codUsuModif, ")
		.append(" dir_ipusumodif as dirIpusumodif = ?dirIpusumodif, fec_modif as fecModif = ?fecModif WHERE num_orden as numOrden = ?numOrden");
		params.addProperty("obsResultado", formulario.getObsResultado());
		params.addProperty("indRealizoAccion", formulario.getIndRealizoAccion());
		params.addProperty("fecInicioCaso", formulario.getFecInicioCaso());
		params.addProperty("indSolicProrroga", formulario.getIndSolicProrroga());
		params.addProperty("fecSolicProrroga", formulario.getFecSolicProrroga());
		params.addProperty("fecInicioCasoNuevo", formulario.getFecInicioCasoNuevo());
		params.addProperty("ind_primera_visit", formulario.getIndPrimeraVisit());
		params.addProperty("ind_segunda_visit", formulario.getIndSegundaVisit());
		params.addProperty("fec_primera_visit", formulario.getFecPrimeraVisit());
		params.addProperty("fec_segunda_visit", formulario.getFecSegundaVisit());
		params.addProperty("codRecomendacion", formulario.getCodRecomendacion());
		params.addProperty("desRecomendacion", formulario.getDesRecomendacion());
		params.addProperty("codResultadoInconsistenciaDef", formulario.getCodResultadoInconsistenciaDef());
		params.addProperty("codResulOrden", formulario.getCodResulOrden());
		params.addProperty("codUsuModif", formulario.getCodUsuModif());
		params.addProperty("dirIpusumodif", formulario.getDirIpusumodif());
		params.addProperty("fecModif", formulario.getFecModif());
		params.addProperty("fecModif", formulario.getFecModif());

		
		
		logger.debug(String.format("JPAT10415OrdenAccionDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10415OrdenAccionDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				OrdenAccion.class);
		
	}

	@Override
	public List<OrdenAccion> listarOrdenDerivacion(OrdenAccion filtro) {
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT ")
		.append("   o.cod_tip_orden as codTipoOrden, ")
		.append("  (o.num_correl_orden||'-'||o.ann_orden||'-'||o.cod_uuoo_orden) as numOrdenUnion, ")
		.append("  o.num_orden as numOrden, ")		
		.append("  u.cod_tip_docident as codTipoDocumentoIdentif, ")
		.append("  u.num_doc_ident as numDocIdent, ")
		.append("  u.nom_ape_usu as nomApeUsuario, ")
		.append("  u.cod_tip_accion as codTipAccion, ")
		.append("  a.cod_pers as codPers, ")
		.append("  o.cod_est_orden as codEstadoOrden ")
		.append("  FROM t10415ordenaccion o ")
		.append("  INNER JOIN t10428usuarioprog u ON o.num_usu_program = u.num_usu_program ")
		.append("  LEFT JOIN t10394asignausuacc a ON o.num_usu_program = a.num_usu_program ")
		.append(" WHERE 1=1 ");

		if (!MaestrosUtilidades.isEmpty(filtro.getNumOrdenUnion())) {
//			boolean like=true;
			builder.append(" AND (o.num_correl_orden||'-'||o.ann_orden||'-'||o.cod_uuoo_orden) LIKE '%"+filtro.getNumOrdenUnion().trim()+"%' ");			
//			builder.append(" AND (o.num_correl_orden||'-'||o.ann_orden||'-'||o.cod_uuoo_orden) LIKE ?numOrdenUnion ");			
//			params.addProperty("numOrdenUnion",filtro.getNumOrdenUnion().trim(), like);		
		}	
		if (!MaestrosUtilidades.isEmpty(filtro.getCodTipoOrden())) {
			builder.append(" AND o.cod_tip_orden = ?codTipoOrden ");
			params.addProperty("codTipoOrden", filtro.getCodTipoOrden());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumProgramacion())) {
			builder.append(" AND u.num_programacion=?numProg ");
			params.addProperty("numProg", filtro.getNumProgramacion());
		}
		if (!MaestrosUtilidades.isEmpty(filtro.getNumOrden())) {
			builder.append(" AND o.num_orden = ?numOrden ");
			params.addProperty("numOrden", filtro.getNumOrden());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND u.num_doc_ident = ?numDocIdent ");
			params.addProperty("numDocIdent", filtro.getNumDocIdent());
		}

		if (!MaestrosUtilidades.isEmpty(filtro.getNumDocIdent())) {
			builder.append(" AND a.cod_cargo = ?codCargo ");
			params.addProperty("codCargo", filtro.getCodCargo());
		}
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, OrdenAccion.class);
	}
	
	
	@Override
	public int actualizarOrdenGeneral(OrdenAccion formulario) {
		int resultado=0;
		EntityManager entityManager= getEntityByPool(AccionesControlConstantes.DATASOURCE_DCSICOBF);
		StringBuilder builder = new StringBuilder();
				
		builder.append("UPDATE t10415ordenaccion o SET ");
		builder.append(" o.fec_modif=SYSDATE ");
		if(!MaestrosUtilidades.isEmpty(formulario.getCodUsuModif()))builder.append(" ,o.cod_usumodif = ?1");
		if(!MaestrosUtilidades.isEmpty(formulario.getDirIpusumodif()))builder.append(" ,o.dir_ipusumodif = ?2");
		if(!MaestrosUtilidades.isEmpty(formulario.getCodEstadoOrden()))builder.append(" ,o.cod_est_orden = ?3");
		if(!MaestrosUtilidades.isEmpty(formulario.getDesSusDevolucion()))builder.append(" ,o.des_sus_devolucion = ?4");
		builder.append(" WHERE 1=1 ");
		if(!MaestrosUtilidades.isEmpty(formulario.getNumOrden()))builder.append(" AND o.num_orden = ?5");
		
		Query query = entityManager.createNativeQuery(builder.toString());
		
		query.setParameter(1 , formulario.getCodUsuModif());
		query.setParameter(2 , formulario.getDirIpusumodif());
		query.setParameter(3 , formulario.getCodEstadoOrden());
		query.setParameter(4 , formulario.getDesSusDevolucion());
		query.setParameter(5 , formulario.getNumOrden());
			
		logger.debug(String.format("JPAT10415OrdenAccionDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10415OrdenAccionDAO: query => %s", builder.toString()));
		
		resultado =	query.executeUpdate();
		return resultado;
		
	}

	@Override
	public List<DocumentoAccion> listarDocuAccion(Long numOrden) {
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		
		builder.append("SELECT ")
		.append(" o.num_orden as numOrden,")
		.append(" u.num_usu_program as numUsuarioPrograma, ")
		.append(" p.num_doc_accion as numDocumentoAccion, ")
		.append(" p.cod_clase as codClase, ")
		.append(" p.cod_tip_doc as codTipoDocumento, ")
		.append(" p.num_documento as numDocumento, ")
		.append(" p.cod_est_doc as codEstadoDocumento, ")
		.append(" p.fec_emision as fecEmision, ")
		.append(" p.fec_notificacion as fecNotificacion, ")
		.append(" p.num_arc as numArc ")
		.append(" FROM t10415ordenaccion o ")
		.append(" INNER JOIN t10428usuarioprog u ")
		.append(" ON o.num_usu_program = u.num_usu_program ")
		.append(" LEFT JOIN t10406documeaccion p ")
		.append(" ON u.num_usu_program = p.num_usu_program ");
		
		if (!MaestrosUtilidades.isEmpty(numOrden)) {
			builder.append(" WHERE o.num_orden = ?numOrden ");
			params.addProperty("numOrden", numOrden);
		}
		
		builder.append(" AND o.ind_del = ?indDel AND o.ind_est = ?indEst ")
		.append(" AND u.ind_del = ?indDel AND u.ind_est = ?indEst ")
		.append(" AND p.ind_del = ?indDel AND p.ind_est = ?indEst ");
		params.addProperty("indDel", MaestrosConstantes.REGISTRO_NO_ELIMINADO);
		params.addProperty("indEst", MaestrosConstantes.REGISTRO_ACTIVO);
		
		logger.debug(String.format("JPAT10415OrdenAccionDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF, DocumentoAccion.class);
	}
}
