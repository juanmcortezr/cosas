package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoRelacionado;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T4429DocRelDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT4429DocRelDAO extends AbstractDAOImpl<DocumentoRelacionado, Long> implements T4429DocRelDAO  {

	public JPAT4429DocRelDAO(){
		super(DocumentoRelacionado.class);
	}
	
}
