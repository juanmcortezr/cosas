package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import java.util.List;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T10411InformeSelecDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AccionesControlConstantes;
import pe.gob.sunat.iqbf3.registro.maestros.utils.MaestrosUtilidades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.PropertyParams;

@Stateless
public class JPAT10411InformeSelecDAO extends AbstractDAOImpl<InformeSeleccion, Long> implements T10411InformeSelecDAO {

	private static final Logger logger = LoggerFactory.getLogger(JPAT10411InformeSelecDAO.class);

	public JPAT10411InformeSelecDAO() {
		super(InformeSeleccion.class);
	}

	@Override
	public List<InformeSeleccion> actualizarInformeSeleccion(InformeSeleccion formulario) {
				
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
				
		builder.append("UPDATE t10411informeselec SET ")
		.append(" num_programacion as numProgramacion = ?numProgramacion, num_correl as numCorrel = ?numCorrel, ann_informe as anioInforme = ?anioInforme,  ")
		.append(" cod_uuoo as codUnidadOrganica = ?codUnidadOrganica, cod_est_informe as codEstadoInforme = ?codEstadoInforme, cod_usumodif as codUsuModif = ?codUsuModif, ")
		.append(" dir_ipusumodif as dirIpusumodif = ?dirIpusumodif, fec_modif as fecModif = ?fecModif WHERE num_inf_selecc as numInformeSeleccion = ?numInformeSeleccion ");
		
		params.addProperty("numProgramacion", formulario.getNumProgramacion());
		params.addProperty("numCorrel", formulario.getNumCorrel());
		params.addProperty("anioInforme", formulario.getAnioInforme());
		params.addProperty("codUnidadOrganica", formulario.getCodUnidadOrganica());
		params.addProperty("codEstadoInforme", formulario.getCodEstadoInforme());
		params.addProperty("codUsuModif", formulario.getCodUsuModif());
		params.addProperty("dirIpusumodif", formulario.getDirIpusumodif());
		params.addProperty("fecModif", formulario.getFecModif());
		params.addProperty("numInformeSeleccion", formulario.getNumInformeSeleccion());

		logger.debug(String.format("JPAT10411InformeSelecDAO: query => %s", builder.toString()));
		System.out.println(String.format("JPAT10411InformeSelecDAO: query => %s", builder.toString()));
		return this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				InformeSeleccion.class);
	}

	@Override
	public InformeSeleccion obtenerInformeSelecccion(Long numInforme) {
		PropertyParams params = new PropertyParams();
		StringBuilder builder = new StringBuilder();
		builder.append("select num_inf_selecc  as numInformeSeleccion  ,   num_programacion  as numProgramacion ,   num_correl as numCorrel ,   ann_informe as anioInforme ,   cod_uuoo as codUnidadOrganica  , cod_est_informe as codEstadoInforme ,   ('IS'||'-'||num_correl||'-'||ann_informe||'-'||cod_uuoo) as numInformeUnion  from t10411informeselec");
		InformeSeleccion informeSeleccion= new InformeSeleccion();
		List<InformeSeleccion> lista= this.findQueryNative(builder.toString(), params, AccionesControlConstantes.DATASOURCE_DCSICOBF,
				InformeSeleccion.class);
		if(!(MaestrosUtilidades.isEmpty(lista))){
			informeSeleccion = lista.get(0);
		}
				
		 return	informeSeleccion;
	}
}
