package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.jpa;

import javax.ejb.Stateless;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MensajeIqbf;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao.T8414MensajeIqbfDAO;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.utils.AbstractDAOImpl;

@Stateless
public class JPAT8414MensajeIqbfDAO extends AbstractDAOImpl<MensajeIqbf, String> implements T8414MensajeIqbfDAO {

	public JPAT8414MensajeIqbfDAO() {
		super(MensajeIqbf.class);
	}

}
