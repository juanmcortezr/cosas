package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TareoAuditor;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10423TareoAuditorDAO extends GenericInterface<TareoAuditor, Long>{

	List<TareoAuditor> listarTareoAuditor(TareoAuditor params);
		
	int actualizarTareoAuditor(TareoAuditor model);

}
