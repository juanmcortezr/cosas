package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoSolicitud;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10414MovSolicDAO extends GenericInterface<MovimientoSolicitud, Long>{

}
