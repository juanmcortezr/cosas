package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.GrupoProceso;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T8311GrupoDAO extends GenericInterface<GrupoProceso, Long> {
	
	List<GrupoProceso> listarSupervisionAuditor(String codTipoProceso);
}
