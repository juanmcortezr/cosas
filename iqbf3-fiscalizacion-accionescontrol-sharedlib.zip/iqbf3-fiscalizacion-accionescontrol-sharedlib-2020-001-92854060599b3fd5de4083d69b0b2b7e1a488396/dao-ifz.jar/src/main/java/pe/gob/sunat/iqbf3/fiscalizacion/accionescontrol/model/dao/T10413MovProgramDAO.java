package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MovimientoProgramacion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10413MovProgramDAO extends GenericInterface<MovimientoProgramacion, Long>{

}
