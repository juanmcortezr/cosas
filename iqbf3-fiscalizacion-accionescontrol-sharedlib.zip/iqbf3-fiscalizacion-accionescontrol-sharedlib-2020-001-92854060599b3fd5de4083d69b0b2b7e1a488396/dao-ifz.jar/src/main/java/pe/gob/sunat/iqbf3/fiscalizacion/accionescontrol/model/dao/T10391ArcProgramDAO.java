package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoAcciones;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoProgramacion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10391ArcProgramDAO extends GenericInterface<ArchivoProgramacion, Integer> {

	public List<ArchivoAcciones> listarArchivosProgramacion(Long numSolicitud, String tipo);

}
