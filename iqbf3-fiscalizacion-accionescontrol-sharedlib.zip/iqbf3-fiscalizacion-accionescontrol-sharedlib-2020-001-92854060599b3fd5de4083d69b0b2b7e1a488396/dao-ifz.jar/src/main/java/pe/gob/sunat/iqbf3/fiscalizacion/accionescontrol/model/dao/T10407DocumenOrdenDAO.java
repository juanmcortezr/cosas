package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoOrden;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10407DocumenOrdenDAO extends GenericInterface<DocumentoOrden, Long> {

	List<DocumentoOrden> listarOtroDocumento(Long numOrden);
	 List<DocumentoOrden> listarOtroDocumento(DocumentoOrden param);
	 List<DocumentoOrdenBean> listarOtroDocumentoBean (DocumentoOrden param);
	 int actualizarDocumentoOrden(DocumentoOrden documentoOrden);
}
