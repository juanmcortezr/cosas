package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaPrograma;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10425TipInconProgDAO extends GenericInterface<TipoInconsistenciaPrograma, Integer> {

}
