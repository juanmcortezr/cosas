package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienFiscal;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T7883BienFiscalDAO extends GenericInterface<BienFiscal, String> {
}
