package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.EstablecimientoUsuario;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10409EstabUsuDAO extends GenericInterface<EstablecimientoUsuario, Long> {

}
