package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.SolicitudProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioSolicitud;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10421SolicProgDAO extends GenericInterface<SolicitudProgramacion, Long> {

	// Bandeja solicitud
	public List<SolicitudProgramacion> listarSolicitudProgramacion(SolicitudProgramacion filtro); 
	public Integer obtenerCorrelativoSolicitud(Integer anio);
	public List<SolicitudProgramacion> vigenciaUsuarioSolicitud(SolicitudProgramacion filtro);
	public List<SolicitudProgramacion> obtenerDatosCaliPre(UsuarioSolicitud filtro);

	// Bandeja Evaluacion Supervisor
	public List<SolicitudProgramacion> listarSolicitudSupervisorSolicitante(SolicitudProgramacion filtro);
	public List<SolicitudProgramacion> listarSolicitudSupervisorProgramador(SolicitudProgramacion filtro);

	// Consulta Solicitud
	public List<SolicitudProgramacion> listarConsultaSolicitudProgramacion(SolicitudProgramacion filtro);

	// Bandeja Asignar Calificar
	public List<SolicitudProgramacion> listarSolicitudesporAsignarCalificar(SolicitudProgramacion filtro);
	
}
