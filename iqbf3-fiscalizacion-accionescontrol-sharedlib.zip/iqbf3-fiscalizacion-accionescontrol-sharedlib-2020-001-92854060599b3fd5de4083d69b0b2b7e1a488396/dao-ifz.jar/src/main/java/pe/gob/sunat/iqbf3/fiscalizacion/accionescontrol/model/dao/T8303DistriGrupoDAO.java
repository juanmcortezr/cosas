package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaUsuarioAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DistribucionGrupo;
import java.util.ArrayList;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;


public interface T8303DistriGrupoDAO extends GenericInterface<DistribucionGrupo, Integer> {

	List<DistribucionGrupo> listarProgramador(String codCargo, String codTipProc, String indEst);
	
	//List<DistribucionGrupo> listarAuditor(final ArrayList<String> codEstOrden,final String codTipoProceso,final String numGrupo,final String codCargo,final String indEst);

	public List<AsignaUsuarioAccion> listarAuditor(AsignaUsuarioAccion filtro);
			
	String obtenerSupervisorPersonal(String codPersPersonal);

	//List<DistribucionGrupo> listarAuditorApoyo(String codCargo, String codTipProceso, String indEst);
	List<DistribucionGrupo> listarAuditorApoyo(DistribucionGrupo filtro);

	List<DistribucionGrupo> listarAuditorApoyoAccion(String numUsuarioProgram, String codCargo, String indEst);
	
	public List<DistribucionGrupo> listarAsignaProg (DistribucionGrupo filtro);

	List<DistribucionGrupo> listarProgramador(DistribucionGrupo filtro);

	List<DistribucionGrupo> listarAuditor(ArrayList<String> codEstOrden, String codTipoProceso, String numGrupo,
			String codCargo, String indEst);
	
}
