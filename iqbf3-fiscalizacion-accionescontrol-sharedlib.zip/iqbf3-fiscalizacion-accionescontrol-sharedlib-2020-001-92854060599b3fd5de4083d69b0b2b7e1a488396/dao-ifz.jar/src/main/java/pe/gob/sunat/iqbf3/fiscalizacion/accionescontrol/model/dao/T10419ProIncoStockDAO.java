package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaStock;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10419ProIncoStockDAO extends GenericInterface<ProgramaIncosistenciaStock, Long>{

	List<ProgramaIncosistenciaStock> listarDetalleStockNegativo(Long numUsuarioPrograma);
}
