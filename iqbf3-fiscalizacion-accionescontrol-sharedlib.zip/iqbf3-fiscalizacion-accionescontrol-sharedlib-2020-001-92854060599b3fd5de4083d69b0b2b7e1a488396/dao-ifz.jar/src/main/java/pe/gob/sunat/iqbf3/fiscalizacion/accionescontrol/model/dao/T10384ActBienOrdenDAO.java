package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActaBienOrden;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10384ActBienOrdenDAO extends GenericInterface<ActaBienOrden, Integer> {
	int actualizarActaBien(ActaBienOrden model);
}
