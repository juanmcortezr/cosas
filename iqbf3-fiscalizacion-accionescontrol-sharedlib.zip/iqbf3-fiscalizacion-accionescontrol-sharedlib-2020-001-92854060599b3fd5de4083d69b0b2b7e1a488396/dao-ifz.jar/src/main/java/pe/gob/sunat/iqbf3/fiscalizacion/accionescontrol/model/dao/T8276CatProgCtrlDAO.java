package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaControl;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T8276CatProgCtrlDAO extends GenericInterface<ProgramaControl, String>{
	
	public List<ProgramaControl> obtenerProgCtrlDefinido(ProgramaControl filtro);
	
	public ProgramaControl obtenerTipoProgCtrl(ProgramaControl filtro);
	
	public List<ProgramaControl> obtenerTipoProgCtrl(Integer numProgramacion);

}


