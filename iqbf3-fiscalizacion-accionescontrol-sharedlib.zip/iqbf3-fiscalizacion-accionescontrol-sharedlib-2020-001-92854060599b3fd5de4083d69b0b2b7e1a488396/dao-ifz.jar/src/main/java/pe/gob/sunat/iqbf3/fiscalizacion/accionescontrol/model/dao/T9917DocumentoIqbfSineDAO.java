package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoIqbfSine;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T9917DocumentoIqbfSineDAO extends GenericInterface<DocumentoIqbfSine, Long> {

}
