package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActividadOrden;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10387ActividOrdenDAO extends GenericInterface<ActividadOrden, Long> {
	int actualizarActividadOrden(ActividadOrden model);
}
