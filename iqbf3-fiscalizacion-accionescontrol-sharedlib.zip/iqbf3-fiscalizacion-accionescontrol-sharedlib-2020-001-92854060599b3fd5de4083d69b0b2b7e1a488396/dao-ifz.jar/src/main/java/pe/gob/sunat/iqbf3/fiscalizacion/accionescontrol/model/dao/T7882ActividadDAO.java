package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Actividades;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T7882ActividadDAO extends GenericInterface<Actividades, String> {

}
