package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.ArrayList;
import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaUsuarioAccion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10394AsignaUsuAccDAO extends GenericInterface<AsignaUsuarioAccion, Long> {
	
	public List<AsignaUsuarioAccion> listarCargaAuditorPrincipal(AsignaUsuarioAccion filtro);

	public List<AsignaUsuarioAccion> obtenerAsigUsuarioAccion(AsignaUsuarioAccion filtro);
	
	public List<AsignaUsuarioAccion> insertarAsigUsuarioAccion(AsignaUsuarioAccion filtro);
	
	public List<AsignaUsuarioAccion> listarCargaAuditorPrincipal(AsignaUsuarioAccion parametros, ArrayList<String> estadoOrden, String numProgramacion, String codTipIntControl, String codTipIntFiscalizacion);
}
