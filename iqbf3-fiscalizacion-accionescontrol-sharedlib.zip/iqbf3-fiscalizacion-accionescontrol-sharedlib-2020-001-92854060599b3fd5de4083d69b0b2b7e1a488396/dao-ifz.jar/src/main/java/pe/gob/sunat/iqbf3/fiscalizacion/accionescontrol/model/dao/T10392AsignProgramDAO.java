package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaProgramacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AsignaUsuarioAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10392AsignProgramDAO extends GenericInterface<AsignaProgramacion, Long> {

	public List<AsignaProgramacion> listarAsignaProg(AsignaProgramacion filtro);
	
	public List<AsignaProgramacion> actualizarAsignaProg(AsignaProgramacion formulario);
	
	public  AsignaProgramacion ultimoAsignaProg(AsignaProgramacion filtro);
	
	//public List<AsignaProgramacion> insertarAsignaProg(AsignaProgramacion formulario);


}
