package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.EstablecimientoOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.EstablecimientoOrden;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10408EstabOrdenDAO extends GenericInterface<EstablecimientoOrden, Long> {

	
	 List<EstablecimientoOrden> listarEstablecimientoOrden(EstablecimientoOrden model);
	 List<EstablecimientoOrdenBean> listarEstablecimientoOrdenBean(EstablecimientoOrden model);
	 int actualizarEstablecimiento(EstablecimientoOrden model);
}
