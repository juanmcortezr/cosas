package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.InformeSeleccion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10411InformeSelecDAO extends GenericInterface<InformeSeleccion, Long> {

	public List<InformeSeleccion> actualizarInformeSeleccion (InformeSeleccion formulario);
	public InformeSeleccion obtenerInformeSelecccion(Long numInforme);
}
