package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10420ProgramacionDAO extends GenericInterface<Programacion, Long> {

	public Integer obtenerCorrelativoProgramacion(Integer anio);

	public List<Programacion> listarProgramacion(Programacion filtro);

	public List<Programacion> listarReasignacionProgramacion(Programacion filtro);
	
	public List<Programacion> listarConsultaProgramacion (Programacion filtro);
	
	public List<Programacion> listarProgramaDefinido(Programacion filtro);
	
	public List<Programacion> obtenerDatosProgramacionDefinido(Programacion filtro);
	
	public Programacion obtenerResuProgramacion(Programacion filtro);
		
}
	