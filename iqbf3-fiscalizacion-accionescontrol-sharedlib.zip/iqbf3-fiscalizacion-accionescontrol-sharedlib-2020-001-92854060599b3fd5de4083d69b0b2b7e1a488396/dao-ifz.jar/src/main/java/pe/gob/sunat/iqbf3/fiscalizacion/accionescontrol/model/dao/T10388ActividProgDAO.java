package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActividadPrograma;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10388ActividProgDAO extends GenericInterface<ActividadPrograma, Integer> {

}
