package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;
import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.BienEstablecimientoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienEstablecimiento;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;
public interface T10395BienEstabDAO extends GenericInterface<BienEstablecimiento, Long> {
	List<BienEstablecimiento> listarBienEstablecimiento(BienEstablecimiento model);
	List<BienEstablecimientoBean> listarBienEstablecimientoBean(BienEstablecimiento model);
	int actualizarBienEstab(BienEstablecimiento modal);
}
