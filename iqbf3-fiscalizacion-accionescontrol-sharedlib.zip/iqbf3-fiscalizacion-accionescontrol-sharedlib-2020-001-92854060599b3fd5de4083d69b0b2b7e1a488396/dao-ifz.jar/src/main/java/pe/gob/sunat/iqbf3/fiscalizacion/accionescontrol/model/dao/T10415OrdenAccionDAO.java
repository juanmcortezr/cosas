package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10415OrdenAccionDAO  extends GenericInterface<OrdenAccion, Long> {

	public List<OrdenAccion> vigenciaUsuarioOrden(OrdenAccion filtro);
	
	public List<OrdenAccion> listarOrdenGenerada(OrdenAccion filtro);
	
	public List<OrdenAccion> listarOrden(OrdenAccion filtro);
	
	public List<OrdenAccion> obtenerResumenOrdPend(OrdenAccion filtro);
	
	public OrdenAccion obtenerDatosOrden(Long numOrden, String codClase);
	
	OrdenAccion obtenerDetalleInconsistencia(Long numUsuarioPrograma);
	
	public List<OrdenAccion> actualizarOrden(OrdenAccion formulario);

	public List<DocumentoAccion> listarDocuAccion(Long numOrden);

	public List<OrdenAccion> listarOrdenDerivacion(OrdenAccion filtro);
	
	public int actualizarOrdenGeneral(OrdenAccion formulario);
}
