package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.T9495DocDigit;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T9495DocumentoDigitalDAO extends GenericInterface<T9495DocDigit, Long> {

}
