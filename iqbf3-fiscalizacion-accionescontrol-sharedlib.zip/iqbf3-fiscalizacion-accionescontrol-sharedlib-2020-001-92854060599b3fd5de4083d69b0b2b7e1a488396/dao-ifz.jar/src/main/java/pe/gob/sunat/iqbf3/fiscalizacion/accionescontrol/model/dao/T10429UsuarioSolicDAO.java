package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioSolicitud;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10429UsuarioSolicDAO extends GenericInterface<UsuarioSolicitud, Long> {

	public List<UsuarioSolicitud> listarUsuariosSolicitud(UsuarioSolicitud parametro);
	public Integer validarTotalEstablecimientoxUsuario(UsuarioSolicitud parametro);
	public Integer obtenerTotalUsuarioCalif(Long numSolicProg, String indTipCali);
	public Integer obtenerTotalSoloUsuarioCalif(Long numSolicUsu, String indTipCali);

}
