package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;
import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.AccionSugeridaCalif;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10444AccSugeCalifDAO extends GenericInterface<AccionSugeridaCalif, Long> {
	
	List<AccionSugeridaCalif> listarAccionesSugeridas(String indEst);
	
}
