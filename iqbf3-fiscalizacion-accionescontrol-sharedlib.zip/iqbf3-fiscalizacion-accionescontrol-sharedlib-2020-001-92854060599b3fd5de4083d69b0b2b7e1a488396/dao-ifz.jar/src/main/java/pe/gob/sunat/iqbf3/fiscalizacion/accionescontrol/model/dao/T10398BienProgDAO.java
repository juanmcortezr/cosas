package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.BienProgramacion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10398BienProgDAO extends GenericInterface<BienProgramacion, Integer> {

}
