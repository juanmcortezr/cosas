package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.MedioProbatorioUsuario;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10412MedioProbUsuDAO extends GenericInterface<MedioProbatorioUsuario, Long>{

}
