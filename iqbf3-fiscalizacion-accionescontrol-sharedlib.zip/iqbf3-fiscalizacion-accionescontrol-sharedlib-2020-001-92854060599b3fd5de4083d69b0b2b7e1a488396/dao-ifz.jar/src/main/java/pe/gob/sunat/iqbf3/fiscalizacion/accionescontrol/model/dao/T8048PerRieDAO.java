package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.PerfilRiesgosBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PerfilRiesgos;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T8048PerRieDAO extends GenericInterface<PerfilRiesgos, Long> {

	public List<PerfilRiesgos> obtenerNivelRiesgo(PerfilRiesgosBean perfilRiesgosBean);
}
