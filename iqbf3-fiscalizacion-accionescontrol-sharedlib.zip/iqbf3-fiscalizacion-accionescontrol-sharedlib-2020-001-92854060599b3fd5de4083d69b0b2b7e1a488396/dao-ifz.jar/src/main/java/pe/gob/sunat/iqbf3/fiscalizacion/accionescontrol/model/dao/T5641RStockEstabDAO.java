package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenStockEstablecBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenStockEstablec;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T5641RStockEstabDAO extends GenericInterface<ResumenStockEstablec, Long>{

	public List<ResumenStockEstablec> listarUsuarioStockNegativo(ResumenStockEstablecBean resumenStockEstablecBean);
	
	public List<ResumenStockEstablec> listarStockNegativo(ResumenStockEstablecBean resumenStockEstablecBean);
	
	public List<ResumenStockEstablec> cntStockNegativoVerificacion(ResumenStockEstablecBean resumenStockEstablecBean);
	
	public List<ResumenStockEstablec> cntStockNegativoBaja(ResumenStockEstablecBean resumenStockEstablecBean);
	
	public List<ResumenStockEstablec> listarStockNegativoBaja(ResumenStockEstablecBean resumenStockEstablecBean);
	
	public List<ResumenStockEstablec> verificarSctokNegativoBaja(ResumenStockEstablecBean resumenStockEstablecBean);
}
