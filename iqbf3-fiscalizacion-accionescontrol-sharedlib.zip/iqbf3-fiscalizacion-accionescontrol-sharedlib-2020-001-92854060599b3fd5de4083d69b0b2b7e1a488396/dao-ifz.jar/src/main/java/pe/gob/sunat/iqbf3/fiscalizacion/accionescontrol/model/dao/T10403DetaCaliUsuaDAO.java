package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DetalleCalificacionUsuario;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10403DetaCaliUsuaDAO extends GenericInterface<DetalleCalificacionUsuario, Long> {

}
