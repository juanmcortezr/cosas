package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.OrdenAccion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.PreseleccionAsignacion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10416PreseleAsigDAO extends GenericInterface<PreseleccionAsignacion, Long>{
	
	public List<PreseleccionAsignacion> obtenerAuditorAsignar(PreseleccionAsignacion preseleccionAsignacion);

}
