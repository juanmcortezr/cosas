package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ConfirmacionGreBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ConfirmacionGre;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T5257ConfirDAO extends GenericInterface<ConfirmacionGre, Long> {

	public List<ConfirmacionGre> verificarGreConfirmada(ConfirmacionGreBean confirmacionGreBean);
}
