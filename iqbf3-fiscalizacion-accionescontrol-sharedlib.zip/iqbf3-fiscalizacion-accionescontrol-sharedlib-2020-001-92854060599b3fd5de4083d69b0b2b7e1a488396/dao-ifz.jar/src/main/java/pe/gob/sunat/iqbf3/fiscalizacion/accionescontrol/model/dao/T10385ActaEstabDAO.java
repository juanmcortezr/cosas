package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ActaEstablecimiento;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10385ActaEstabDAO extends GenericInterface<ActaEstablecimiento, Long> {
	int actualizarActaEstab(ActaEstablecimiento model);
}
