package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoOperacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoOperacion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10405DocOperOrdenDAO extends GenericInterface<DocumentoOperacion, Long> {
	int actualizarDocumentoOperacion(DocumentoOperacion model);
	List<DocumentoOperacion> listarDocumentoOperacion(DocumentoOperacion model);
	List<DocumentoOperacionBean> listarDocumentoOperacionBean(DocumentoOperacion model);
}
