package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;


import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAdm;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T8076DocumentoAdmDAO extends GenericInterface<DocumentoAdm, Long> {

}
