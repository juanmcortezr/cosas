package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ProgramaIncosistenciaSaldo;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10418ProIncoSaldoDAO extends GenericInterface<ProgramaIncosistenciaSaldo, Long>{

	List<ProgramaIncosistenciaSaldo> listarInconsistenciaSaldo(Long numUsuarioPrograma);
}
