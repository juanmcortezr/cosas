package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.UsuarioProgramacionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.Programacion;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.UsuarioProgramacion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10428UsuarioProgDAO extends GenericInterface<UsuarioProgramacion, Long> {

	public List<UsuarioProgramacion> verificarUsuario(UsuarioProgramacionBean usuarioProgramacionBean);
	
	public List<UsuarioProgramacion> listarUsuarioProg(UsuarioProgramacion filtro);
	
	public List<UsuarioProgramacion> validarUsuarioProg(UsuarioProgramacion filtro);
	
	public List<UsuarioProgramacion> listarCantUsuario(UsuarioProgramacion filtro);

	public List<Programacion> listarOtraAccion(UsuarioProgramacion filtro);

	public List<UsuarioProgramacion> listarUsuariosTipaccsuge(UsuarioProgramacionBean filtro);
	
	public List<UsuarioProgramacion> listarResumenAccion(String filtro);
	
}
