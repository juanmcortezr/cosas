package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DeclaracionesJuradasBfBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DeclaracionesJuradasBf;
import pe.gob.sunat.iqbf3.registro.maestros.model.BfRegistro;
import pe.gob.sunat.iqbf3.registro.maestros.bean.BfRegistroBean;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T5284BfCabJroDAO extends GenericInterface<DeclaracionesJuradasBf, Long> {

	public List<DeclaracionesJuradasBf> listarUsuariosOmisosDjRop(DeclaracionesJuradasBfBean declaracionesJuradasBfBean);
	
	public List<DeclaracionesJuradasBf> periodosOmisosPorUsuario(DeclaracionesJuradasBfBean declaracionesJuradasBfBean);
	
}
