package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ArchivoDataAcciones;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10446ArcDataAcfDAO extends GenericInterface<ArchivoDataAcciones, Long> {

	public ArchivoDataAcciones obtenerArcDataNoBytes(Long numArc);

}
