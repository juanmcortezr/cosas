package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.ResumenSaldoBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ResumenSaldo;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T5642RSaldoDAO extends GenericInterface<ResumenSaldo, Long>{

	public List<ResumenSaldo> listarUsuarioSaldoNegativo(ResumenSaldoBean resumenSaldoBean);
	
	public List<ResumenSaldo> listarSaldoNegativo(ResumenSaldoBean resumenSaldoBean);
	
	public List<ResumenSaldo> cntSaldoNegativo(ResumenSaldoBean resumenSaldoBean);
}
