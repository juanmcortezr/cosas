package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.T9494ArcDigit;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T9494ArchivoDigitalDAO extends GenericInterface<T9494ArcDigit, Long> {

}
