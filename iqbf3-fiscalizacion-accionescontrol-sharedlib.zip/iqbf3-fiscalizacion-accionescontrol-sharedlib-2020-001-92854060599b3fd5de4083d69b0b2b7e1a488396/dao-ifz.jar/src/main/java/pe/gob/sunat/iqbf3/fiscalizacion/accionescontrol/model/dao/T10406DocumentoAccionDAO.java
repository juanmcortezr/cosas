package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.DocumentoAccionBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.DocumentoAccion;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10406DocumentoAccionDAO extends GenericInterface<DocumentoAccion, Long> {

	public List<DocumentoAccion> listarDocumentoPendienteNotificacion(DocumentoAccionBean filtro);
	public int maximoDocumentoEletronico(DocumentoAccionBean filtro);
}
