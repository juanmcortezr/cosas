package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.bean.TipoInconsistenciaOrdenBean;
import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.TipoInconsistenciaOrden;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10424TipIncoOrdenDAO extends GenericInterface<TipoInconsistenciaOrden, Long>{
	List<TipoInconsistenciaOrden> listarInconsistencia(TipoInconsistenciaOrden param);
	List<TipoInconsistenciaOrdenBean> listarInconsistenciaBean(TipoInconsistenciaOrden param);
	int actualizarInconsistenciaOtro(TipoInconsistenciaOrden model);
}
