package pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.dao;

import java.util.List;

import pe.gob.sunat.iqbf3.fiscalizacion.accionescontrol.model.ContactoOrden;
import pe.gob.sunat.iqbf3.registro.maestros.utils.GenericInterface;

public interface T10401ContactOrdenDAO extends GenericInterface<ContactoOrden, Long> {

	List<ContactoOrden> listarContacto(Long numOrden);
	
	int actualizarContactoOrden(ContactoOrden contactoOrden);
}
