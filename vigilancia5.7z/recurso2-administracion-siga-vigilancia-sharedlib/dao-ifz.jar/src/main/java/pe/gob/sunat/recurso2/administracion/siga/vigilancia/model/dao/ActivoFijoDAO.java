package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActivoFijo;


/**
 * DAO para la obtencion de los bienes patrimoniales
 * @author 
 * @version 1.0
 */
public interface ActivoFijoDAO {
    

	/**
	 * Valor especifico del estado, por condicion recibida
	 * @param parametros
	 * @return
	 */
	List<ActivoFijo> selectBienPatrimonialByParameter(ActivoFijo paramActFijo);
	/**
	 * Update de los bienes asignados
	 */
	int actualizaBienAsignado(ActivoFijo codiMarqAct);
	/**
	 * resumen de los bienes de la solicitud cus010
	 */
	List<ActivoFijo> resumenBienSolicitud(ActivoFijo numSolicitudAct);
	
	/**
	 * @author arosalesa
	 * @param params
	 * @return
	 */	
	List<ActivoFijo> consultarBienesAsignados(ActivoFijo paramActFijo);
	
	List<ActivoFijo> consultarBienesActaEntrega(ActivoFijo paramActFijo);
	
	List<ActivoFijo> selectMensajeInexistenciaBienPorCodigo(ActivoFijo paramActFijo);
	
	/**
	 * @author arosalesa
	 * @param params
	 * @return
	 */	
	ActivoFijo selectByPrimaryKey(ActivoFijo paramActFijo);
	ActivoFijo selectByPrimaryKeyInventario(ActivoFijo paramActFijo);
	
	void liberarActivoFijo(ActivoFijo activoFijo);
	
	java.sql.Date obtenerDiasUtiles(Map<String, Object> record);
	
	List<ActivoFijo> listByParameter(ActivoFijo paramActFijo);
}

