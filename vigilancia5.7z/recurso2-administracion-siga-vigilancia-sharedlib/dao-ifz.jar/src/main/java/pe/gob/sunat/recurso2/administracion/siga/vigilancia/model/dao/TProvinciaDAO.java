package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Departamento;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Provincia;


/**
 * DAO para acceder a los locales
 * 
 * @author
 * @version 1.0
 */
public interface TProvinciaDAO {

	// parametros);//wrodriguez
	List<Provincia> getProvincias(String departamento);
	// boolean updateByVistaPreliminar(T5730Bean paramUpdate);//wrodriguez

}
