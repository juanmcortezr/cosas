package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.MaestroPersona;



/**
 * DAO para el maestro de personas
 * 
 * @author walter rodriguez
 * @version 1.0
 */
public interface MaestroPersonaDAO {

	List<MaestroPersona> getListPersona(MaestroPersona unidadOrganizacional);
	MaestroPersona getEmpleado(MaestroPersona unidadOrganizacional);
	MaestroPersona getEmpleadoWithRegimenAndUuoo(MaestroPersona params);
	MaestroPersona getColaboradorDestinatario(MaestroPersona registroAlterno);
	MaestroPersona getEmpleadoPorUsuario(HashMap<String,Object> paramSearch);
	List<MaestroPersona> listParamInputLog(MaestroPersona loginUsuario);//input para log 
	List<MaestroPersona> getAnioExpediente();
	MaestroPersona getCodigoEmpleado(MaestroPersona registroAlterno);
	String crearExpediente(Map<String, Object> parametros);

	/**
	 * Obtener Regimen Laboral por Codigo de Empleado Persona
	 * 
	 * @author framirez
	 * @since 29/09/2015
	 * @version 1.0
	 * @param Map parametro
	 * @return String RegimenLaboral
	 */
	String getRegimenLaboralByCodEmplPer(Map<String, Object> parametro);
	
	List<MaestroPersona> buscarMaestroPersonal(Map<String,Object> paramSearch);
	MaestroPersona obtenerPersonaxRegistro(String cod_reg);
}
