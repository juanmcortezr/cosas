package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ibatis;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Distrito;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.TDistritoDAO;

/**
 * Implementación del DAO para acceder y modificar la información de la
 * entidad locales
 * 
 * @author
 * @version 1.0
 */
public class SqlMapTDistritoDAO extends SqlMapClientDaoSupport implements
		TDistritoDAO {

	@SuppressWarnings("unchecked")
	public List<Distrito> getDistritos(Distrito distrito) {
		return (List<Distrito>) getSqlMapClientTemplate().queryForList(
				"Distrito.selectByPrimaryKey", distrito);
	}

}