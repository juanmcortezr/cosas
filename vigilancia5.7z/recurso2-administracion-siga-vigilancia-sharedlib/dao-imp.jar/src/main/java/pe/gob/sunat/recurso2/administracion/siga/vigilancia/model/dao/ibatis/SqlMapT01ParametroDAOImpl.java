package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
 
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.T01Parametro;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.T01ParametroDAO;
//ae96 : Agregar funcionalidad para el listado de anios desde parametro
public class SqlMapT01ParametroDAOImpl  extends SqlMapDAOBase  implements T01ParametroDAO   {

	@Override
	public List<T01Parametro> listarDetallesParametro(Map<String, Object> params) { 
		List<T01Parametro> lista= (List<T01Parametro> ) getSqlMapClientTemplate().queryForList("t01parametro.listDetalles", params);		
		return lista;
	}

}
