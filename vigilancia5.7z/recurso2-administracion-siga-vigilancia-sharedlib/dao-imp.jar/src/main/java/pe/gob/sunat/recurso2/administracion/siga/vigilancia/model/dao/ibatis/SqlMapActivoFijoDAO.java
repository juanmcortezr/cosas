package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ibatis;



import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActivoFijo;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.dao.ActivoFijoDAO;


/**
 * 
 * @author  walter rodriguez
 * @version 1.0
 */
public class SqlMapActivoFijoDAO extends SqlMapClientDaoSupport implements ActivoFijoDAO {
	protected final Log log = LogFactory.getLog(getClass());
    
    public SqlMapActivoFijoDAO(){
    	super();
    }

	
	@SuppressWarnings("unchecked")
	public List<ActivoFijo> selectBienPatrimonialByParameter(ActivoFijo paramActFijo) {
		List<ActivoFijo> lista=null;
		lista= (List<ActivoFijo>)getSqlMapClientTemplate().queryForList("activo.selectByParameter", paramActFijo);																	
		return lista;
	}

	
	public int actualizaBienAsignado(ActivoFijo codiMarqAct) {
		int updateBienAsignado;
		updateBienAsignado=getSqlMapClientTemplate().update("activo.actualizarBienAsignado",codiMarqAct);	
		return updateBienAsignado;
	}
	

	@SuppressWarnings("unchecked")
	public List<ActivoFijo> resumenBienSolicitud(ActivoFijo numSolicitudAct) {
		List<ActivoFijo> lista=null;
		lista= (List<ActivoFijo>)getSqlMapClientTemplate().queryForList("activo.getSolicitudResumenBien", numSolicitudAct);																	
		return lista;
	}
	

	@SuppressWarnings("unchecked")
	public List<ActivoFijo> consultarBienesAsignados(ActivoFijo paramActFijo) {
		List<ActivoFijo> lista=null;
		lista= (List<ActivoFijo>)getSqlMapClientTemplate().queryForList("activo.consultarBienesAsignados", paramActFijo);																	
		return lista;
	}
	
	public List<ActivoFijo> consultarBienesActaEntrega(ActivoFijo paramActFijo) {
		List<ActivoFijo> lista=null;
		lista= (List<ActivoFijo>)getSqlMapClientTemplate().queryForList("activo.consultarBienesActaEntrega", paramActFijo);																	
		return lista;
	}
	
	public List<ActivoFijo> listByParameter(ActivoFijo paramActFijo) 	{										  
		return (List<ActivoFijo>)getSqlMapClientTemplate().queryForList("activo.listByParameter", paramActFijo);
	}
	
	public ActivoFijo selectByPrimaryKey(ActivoFijo paramActFijo) 	{										  
		return (ActivoFijo)getSqlMapClientTemplate().queryForObject("activo.selectByPrimaryKey", paramActFijo);
	}
	
	public ActivoFijo selectByPrimaryKeyInventario(ActivoFijo paramActFijo) 	{										  
		return (ActivoFijo)getSqlMapClientTemplate().queryForObject("activo.selectByPrimaryKeyInventario", paramActFijo);
	}


	public void liberarActivoFijo(ActivoFijo activoFijo) {
		getSqlMapClientTemplate().update("activo.liberarActivoFijo", activoFijo);
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<ActivoFijo> selectMensajeInexistenciaBienPorCodigo(
			ActivoFijo paramActFijo) {
		return (List<ActivoFijo>)getSqlMapClientTemplate().queryForList("activo.selectMensajeInexistencia", paramActFijo);																	
	}

    
    public java.sql.Date obtenerDiasUtiles(Map<String, Object> record) {
    	java.sql.Date resultado = (java.sql.Date)getSqlMapClientTemplate().queryForObject("activo.obtenerDiasUtiles", record);
        return resultado;
    }
}