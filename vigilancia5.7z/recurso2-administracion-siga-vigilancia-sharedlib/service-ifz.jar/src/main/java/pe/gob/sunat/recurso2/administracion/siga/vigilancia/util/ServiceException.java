package pe.gob.sunat.recurso2.administracion.siga.vigilancia.util;

public class ServiceException extends Exception {

	private static final long serialVersionUID = -6184009478252085645L;

    public ServiceException(String message) {
        super(message);
    }
    
    public ServiceException(Exception e) {
        super(e);
    }
	
}
