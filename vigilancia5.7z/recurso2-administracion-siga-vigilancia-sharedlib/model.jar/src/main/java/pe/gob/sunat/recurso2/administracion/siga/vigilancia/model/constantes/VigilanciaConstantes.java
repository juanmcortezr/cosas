package pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.constantes;

public class VigilanciaConstantes {

	public static final String CODIGO_NOTIFICACION_CAJACHICA = "RETW00001";

	public final static String ESTADO_CONSERVACION_BUENO="B";
	public final static String ESTADO_CONSERVACION_MALO="M";
	public final static String ESTADO_CONSERVACION_PARA_BAJA="N";
	public final static String ESTADO_CONSERVACION_REGULAR="R";
	public final static String CODIGO_PARAMETRO_INDICADORES_CONFORMIDAD_BIEN_FALTANTE="3192";
	
	public static final String USUARIO_BEAN_NAME = "usuarioBean";
	public final static String ESTADO_EMPLEADO_ACTIVO = "1";
	public final static String ESTADO_EMPLEADO_INACTIVO = "0";
	
	public final static String SOLICITUD_ANULADA = "0";
	public final static String SOLICITUD_REGISTRADA = "1";
	public final static String SOLICITUD_FIRMADA = "2";
	public final static String SOLICITUD_RECHAZADA = "3";
	public final static String SOLICITUD_AUTORIZADA = "4";
	public final static String SOLICITUD_CERRADA = "5";
}
