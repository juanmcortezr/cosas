package pe.gob.sunat.recurso2.administracion.siga.vigilancia.registro.web.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.sojo.interchange.json.JsonSerializer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.administracion.siga.archivo.model.bean.RegistroArchivosFisicoBean;
import pe.gob.sunat.recurso2.administracion.siga.archivo.service.RegistroArchivosService;
import pe.gob.sunat.recurso2.administracion.siga.firma.model.bean.T5282Archbin;
import pe.gob.sunat.recurso2.administracion.siga.firma.service.ConsultaFirmaService;
import pe.gob.sunat.recurso2.administracion.siga.parametro.model.bean.T01ParametroBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.DependenciaBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.model.bean.MaestroPersonalBean;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroDependenciasService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroGeneralService;
import pe.gob.sunat.recurso2.administracion.siga.registro.service.RegistroPersonalService;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.service.GestionVigilanciaService;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.util.FormatoUtil;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.util.ServiceException;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActMovTra;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActSolTra;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActSolTraDet;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.ActivoFijo;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.InmLocalTdepe;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.MaestroPersona;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.SysRegistroArchivosFisico;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.Tdependencias;
import pe.gob.sunat.recurso2.administracion.siga.vigilancia.model.constantes.VigilanciaConstantes;

public class SolicitudVigilanciaController extends MultiActionController {
	
	private String jsonView;
	private JsonSerializer jsonSerializer;
	
	private RegistroGeneralService registroGeneralService;
	private RegistroPersonalService registroPersonalService;
	private RegistroDependenciasService registroDependenciasService;

	private RegistroArchivosService registroArchivosService;
	private GestionVigilanciaService gestionVigilanciaService;
	private ConsultaFirmaService consultaFirmaService;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	/**
     * Carga la Pagina de la consulta
     * @param HttpServletRequest request
     * @param HttpServletResponse response 
     * @return ModelAndView 
     */  
	public ModelAndView iniciarSolicitud(HttpServletRequest request, HttpServletResponse response) {
		
		log.debug("debug Inicio - ConsultaSolicitudController.iniciarConsulta");
		
		ModelAndView modelAndView;
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		String pagina = "";
		String mensajeError = "";
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		try {
			
			UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
			
			List<T01ParametroBean> listaTipoMovimiento;
			
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("cod_par", "0025");
			params.put("cod_mod", "MUEB");
			params.put("cod_tipo", "D");
			
			listaTipoMovimiento = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);

			List<T01ParametroBean> listaClaseMovimiento;
			
			params = new HashMap<String, Object>();
			params.put("cod_par", "0026");
			params.put("cod_mod", "MUEB");
			params.put("cod_tipo", "D");
			
			listaClaseMovimiento = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			
			List<T01ParametroBean> listaEstado;
			
			params = new HashMap<String, Object>();
			params.put("cod_par", "0028");
			params.put("cod_mod", "MUEB");
			params.put("cod_tipo", "D");
			
			String codEstadoInicial = VigilanciaConstantes.SOLICITUD_REGISTRADA;//registrado
			String descEstado = "";
			listaEstado = (List<T01ParametroBean>) registroGeneralService.recuperarParametroLista(params);
			for (T01ParametroBean estado : listaEstado) {
				if (codEstadoInicial.trim().equals(estado.getCod_argumento().trim())) {
					descEstado = estado.getNom_largo();
				}
			}
			
			//addOption("selEstado", 'T', "TODOS");
			
			//listaEstados = jQuery.parseJSON(listaEstadosString);
			//for (var i = 0; i < listaEstados.length; i++) {
			//	addOption("selEstado", $.trim(listaEstados[i].cod_argumento), $.trim(listaEstados[i].nom_largo));
			//}
			
			String registro = usuarioBean.getNroRegistro();
			MaestroPersonalBean colaborador = registroPersonalService.obtenerPersonaxRegistro(registro);
			DependenciaBean dependencia = registroDependenciasService.obtenerDependenciaXcod(colaborador.getCodigoDependencia());
			MaestroPersonalBean autorizador = registroPersonalService.obtenerPersonaxCodigo(dependencia.getCodEmpleado());
			
			InmLocalTdepe inmLocalTdepeParam = new InmLocalTdepe();
			inmLocalTdepeParam.setCodDepeTde(dependencia.getCod_dep());
			List<InmLocalTdepe> localesDependencia = gestionVigilanciaService.recuperarListaLocalesPorUuoo(inmLocalTdepeParam);
			
			Date fechaLimite = gestionVigilanciaService.obtenerDiasUtiles(new Date(), 2);
			Calendar calLimite = Calendar.getInstance();
			calLimite.setTime(fechaLimite);
			calLimite.set(Calendar.MILLISECOND, 0);
			calLimite.set(Calendar.MINUTE, 0);
			calLimite.set(Calendar.HOUR, 0);
			calLimite.set(Calendar.HOUR_OF_DAY, 0);
			
			Calendar calHoy = Calendar.getInstance();
			calHoy.setTime(new Date());
			calHoy.set(Calendar.MILLISECOND, 0);
			calHoy.set(Calendar.MINUTE, 0);
			calHoy.set(Calendar.HOUR, 0);
			calHoy.set(Calendar.HOUR_OF_DAY, 0);
			
			long diasLimite = (long)Math.ceil((float) (calLimite.getTimeInMillis() - calHoy.getTimeInMillis()) / (24 * 60 * 60 * 1000));
			
			if (log.isDebugEnabled())log.debug("getApeMaterno:"		+usuarioBean.getApeMaterno());
			if (log.isDebugEnabled())log.debug("getApePaterno:"		+usuarioBean.getApePaterno());
			if (log.isDebugEnabled())log.debug("getCodDepend:"		+usuarioBean.getCodDepend());
			if (log.isDebugEnabled())log.debug("getCodUO:"			+usuarioBean.getCodUO());
			if (log.isDebugEnabled())log.debug("getCorreo:"			+usuarioBean.getCorreo());
			if (log.isDebugEnabled())log.debug("getLogin:"			+usuarioBean.getLogin());
			if (log.isDebugEnabled())log.debug("getNombreCompleto:"	+usuarioBean.getNombreCompleto());
			if (log.isDebugEnabled())log.debug("getNombres:"		+usuarioBean.getNombres());
			if (log.isDebugEnabled())log.debug("getNroRegistro:"	+usuarioBean.getNroRegistro());
			if (log.isDebugEnabled())log.debug("getTicket:"			+usuarioBean.getTicket());
			
			//respuesta.put("listaTipoMovimiento", listaTipoMovimiento);
			//respuesta.put("listaTipoMovimientoString", jsonSerializer.serialize(listaTipoMovimiento));
			
			respuesta.put("colaborador", jsonSerializer.serialize(colaborador));
			respuesta.put("dependencia", jsonSerializer.serialize(dependencia));
			respuesta.put("autorizador", jsonSerializer.serialize(autorizador));
			respuesta.put("localesDependencia", jsonSerializer.serialize(localesDependencia).toString().replaceAll("\\\\", "\\\\\\\\"));
			
			respuesta.put("listaTipoMovimiento", jsonSerializer.serialize(listaTipoMovimiento));
			respuesta.put("listaClaseMovimiento", jsonSerializer.serialize(listaClaseMovimiento));
			respuesta.put("listaEstado", jsonSerializer.serialize(listaEstado));
			
			respuesta.put("codEstadoSolicitud", codEstadoInicial);
			respuesta.put("descEstadoSolicitud", descEstado);			
			respuesta.put("fechaLimite", sdf.format(fechaLimite));
			respuesta.put("diasLimite", diasLimite);
			respuesta.put("datosUsuario", jsonSerializer.serialize(usuarioBean));
			
			//var codEstadoSolicitud = '${codEstadoSolicitud}';
			//var descEstadoSolicitud = '${descEstadoSolicitud}';
			
			pagina = "paginaSolicitudVigilancia";
		}
		catch(Exception e){
			log.error(e.getMessage(), e);
			pagina = "paginaErrorSistema";
			mensajeError = "A ocurrido un inconveniente por favor comuniquese con el Administrador." + e.getMessage();
		}
		finally{
			respuesta.put("mensajeError", mensajeError);
			modelAndView = new ModelAndView(pagina,respuesta);
			log.debug("Fin ConsultaSolicitudController.iniciarConsulta");
		}
		
		return modelAndView;
	}
	
	/**
	 * @author arosalesa	
	 * @return Devuelve datos de un bien de acuerdo a su codigo patrimonial
	 * @throws Exception
	 */	 
	public ModelAndView getDetalleBienInventario(HttpServletRequest request,HttpServletResponse response) {

		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		MaestroPersona colaborador = gestionVigilanciaService.maestroPersona(usuarioBean.getNroRegistro());
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		ActivoFijo detalleBienAsignado=null;
		
		try {
			log.debug("Iniciando control patrimonial -- getDetalleBien");
			String codBienAsignado=request.getParameter("codBien");
			String flagEstadoBienConformidad=request.getParameter("flagEstadoBienConformidad");
			detalleBienAsignado = gestionVigilanciaService.selectByPrimaryKeyInventario(codBienAsignado, colaborador.getCodiEmplPer(),flagEstadoBienConformidad);
			respuesta.put("detalleBienAsignado", detalleBienAsignado);
			
		} catch (Exception e) {
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}

	/**
	 * @author arosalesa	
	 * @return Devuelve datos de un bien de acuerdo a su codigo patrimonial
	 * @throws Exception
	 */	 
	public ModelAndView registrarSolicitudVigilancia(HttpServletRequest request,HttpServletResponse response) {
		
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		MaestroPersona colaborador = gestionVigilanciaService.maestroPersona(usuarioBean.getNroRegistro());
		Map<String, Object> respuesta = new HashMap<String, Object>();
		ModelAndView viewPage = null;
		ActivoFijo detalleBienAsignado=null;
		
		JsonSerializer serializador = new JsonSerializer();
		
		String accionRegistrar = request.getParameter("accionRegistrar");
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat anioFormat = new SimpleDateFormat("yyyy");
		
		Date hoy = new Date();
		String anio = anioFormat.format(hoy);
		
		ActSolTra solicitud = new ActSolTra();
		List<ActSolTraDet> listaDetallesSolicitud = new ArrayList<ActSolTraDet>();
		
		//  --COD_TIPOMOV          CHAR(2)                         not null,
		//  --NUM_LOCALORI         INTEGER                         not null,
		//  --NUM_LOCALDES         INTEGER,
		//  --OBS_SOLICITUD        VARCHAR2(200)                   not null,
		//	--COD_DOCAUT           INTEGER,
	   	
	   	//	NUM_LOCALVIG         INTEGER,	no se llena, es el local del vigilante (puede ser distinto al local de origen, en sedes con multiples edificios)
	   	//	NUM_LOCALDES         INTEGER,	solo se llena cuando el tipo de traslado es a otro local
		//  COD_REGIAUT          CHAR(8),	no se llena, es para autorizacion por parte de gestores (citrix)
		
		solicitud.setCodEmplaut(null);
		solicitud.setIndTipoaut(null);
		solicitud.setNumLocalvig(null);
		
		solicitud.setFecRegiaut(null);
		solicitud.setCodRegiaut(null);
		solicitud.setObsAutoriza(null);
		
		solicitud.setCodEmplanu(null);
		solicitud.setFecAnula(null);
		solicitud.setObsAnula(null);
		
		solicitud.setCodUsucierra(null);
		solicitud.setFecRegiCie(null);
		solicitud.setCodDocaut(null);
		
		String numSolicitudString = request.getParameter("hdnNumSolicitud");//PONER
		BigDecimal numSolicitud = new BigDecimal(-1);
		
		try {
			numSolicitud = new BigDecimal(numSolicitudString);
		}
		catch (Exception e) {
			numSolicitud = new BigDecimal(-1);
			log.error("error de conversion numero de solicitud", e);
		}
		solicitud.setNumSolicitud(numSolicitud);
		
		solicitud.setCodUsumodif(usuarioBean.getLogin());
		solicitud.setFecModif(hoy);
		
		try {
			if ("R".equals(accionRegistrar)) {
				
				String txtFechaTraslado = request.getParameter("txtFechaTraslado");
				
				String selTipoMovimiento = request.getParameter("selTipoMovimiento");
				String hdnCodigoSolicitante = request.getParameter("hdnCodigoSolicitante");
				String hdnDependenciaSolicitante = request.getParameter("hdnDependenciaSolicitante");
				String hdnUuooSolicitante = request.getParameter("hdnUuooSolicitante");
				
				String selLocalOrigen = request.getParameter("selLocalOrigen");
				String txtLocalDestino = request.getParameter("txtLocalDestino");
				
				String hdnCodigoAsignado = request.getParameter("hdnCodigoAsignado");
				String txtConcepto = request.getParameter("txtConcepto");
				log.debug("texto concepto antes: |" + txtConcepto + "|" + "".equals(txtConcepto));
				if (txtConcepto == null || "".equals(txtConcepto))
					txtConcepto = "-";
				log.debug("texto concepto despues: |" + txtConcepto + "|" + "".equals(txtConcepto));
				
				String selAutorizador = request.getParameter("selAutorizador");
				
				String listaDetallesString = request.getParameter("listaDetallesJson");
				log.debug("listaDetallesJson: " + listaDetallesString);
				
				List<Map<String, Object>> listaDetallesParameter = new ArrayList<Map<String, Object>>();
				listaDetallesParameter = (List<Map<String, Object>>)serializador.deserialize(listaDetallesString, listaDetallesParameter.getClass());
				log.debug("lista de detalle: " +listaDetallesParameter + " " + listaDetallesParameter.size());
				
				Date fecTraslado = new Date();
				try {
					fecTraslado = sdf.parse(txtFechaTraslado);
				}
				catch (Exception e) {
					fecTraslado = new Date();
				}
				
				BigDecimal localOrigen = new BigDecimal(0);
				try {
					localOrigen = new BigDecimal(selLocalOrigen);
				}
				catch (Exception e) {
					localOrigen = new BigDecimal(0);
				}
				
				BigDecimal localDestino = new BigDecimal(0);
				try {
					localDestino = new BigDecimal(txtLocalDestino);
				}
				catch (Exception e) {
					localDestino = new BigDecimal(0);
				}
				
				Long secuencia = gestionVigilanciaService.obtenerSecuenciaSolicitud();
				
				solicitud.setNumSolicitud(new BigDecimal(secuencia));
				solicitud.setFecRegistro(hoy);
				
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("anio", anio);
				paramMap.put("uuoo", hdnUuooSolicitante);
				
				String correlativoSolicitante = gestionVigilanciaService.obtenerCodigoSolicitud(paramMap);
				//if (correlativoSolicitante == null)
				//	correlativoSolicitante = "000001";
				String codigoSolicitud = anio + hdnUuooSolicitante + correlativoSolicitante;
				solicitud.setCodSolicitud(codigoSolicitud);
				solicitud.setFecTraslado(fecTraslado);
				
				solicitud.setCodEstado(VigilanciaConstantes.SOLICITUD_REGISTRADA);
				solicitud.setCodClasemov("01");//MOVIMIENTO INTRANET
				
				solicitud.setCodEmplsol(hdnCodigoSolicitante);
				solicitud.setCodDepesol(hdnDependenciaSolicitante);
				
				solicitud.setCodTipomov(selTipoMovimiento);
				
				solicitud.setNumLocalori(localOrigen);
				solicitud.setNumLocaldes(localDestino);
				solicitud.setCodEmplasg(hdnCodigoAsignado);
				solicitud.setObsSolicitud(txtConcepto);
				
				solicitud.setCodEmplaut(selAutorizador);
				
				solicitud.setCodUsuregis(usuarioBean.getLogin());
				solicitud.setFecRegis(hoy);
				
				int numItem = 1;
				for (Map<String, Object> detalleMap : listaDetallesParameter) {
					
					ActSolTraDet detalle = new ActSolTraDet();
					detalle.setNumSolicitud(new BigDecimal(secuencia));
					detalle.setNumItem(new BigDecimal(numItem));
					detalle.setCodMarqAct((String)detalleMap.get("codiMarqAct"));
					
					detalle.setIndUsomov(null);
					detalle.setObsUsomov(null);
					detalle.setNumMovimiento(null);
					detalle.setIndMovimiento(null);
					
					detalle.setCodUsuregis(usuarioBean.getLogin());
					detalle.setFecRegis(hoy);
					detalle.setCodUsumodif(usuarioBean.getLogin());
					detalle.setFecModif(hoy);
					
					listaDetallesSolicitud.add(detalle);
					
					numItem++;
				}
				/*create table SIGA01.T9944ACTSOLTRADET  (
						   --NUM_SOLICITUD        INTEGER                         not null,
						   --NUM_ITEM             SMALLINT                        not null,
						   COD_MARQ_ACT         CHAR(12)                        not null,
						   --IND_USOMOV           CHAR(1),
						   --OBS_USOMOV           VARCHAR2(200),
						   --NUM_MOVIMIENTO       INTEGER,
						   --IND_MOVIMIENTO       CHAR(1),
						   --COD_USUREGIS         VARCHAR2(30),
						   --FEC_REGIS            DATE,
						   --COD_USUMODIF         VARCHAR2(30),
						   --FEC_MODIF            DATE
				*/
				
				gestionVigilanciaService.registrarSolicitudVigilancia(solicitud, listaDetallesSolicitud);
			}
			else if ("M".equals(accionRegistrar)) {
				
				String txtFechaTraslado = request.getParameter("txtFechaTraslado");
				
				String selTipoMovimiento = request.getParameter("selTipoMovimiento");
				String hdnCodigoSolicitante = request.getParameter("hdnCodigoSolicitante");
				String hdnDependenciaSolicitante = request.getParameter("hdnDependenciaSolicitante");
				String hdnUuooSolicitante = request.getParameter("hdnUuooSolicitante");
				
				String selLocalOrigen = request.getParameter("selLocalOrigen");
				String txtLocalDestino = request.getParameter("txtLocalDestino");
				
				String hdnCodigoAsignado = request.getParameter("hdnCodigoAsignado");
				String txtConcepto = request.getParameter("txtConcepto");
				
				String selAutorizador = request.getParameter("selAutorizador");
				
				//--Tipo Movimiento
				//--Fecha Traslado
				//--Local Destino
				//--utorizador
				//--Observaciones
				
				Date fecTraslado = new Date();
				try {
					fecTraslado = sdf.parse(txtFechaTraslado);
				}
				catch (Exception e) {
					fecTraslado = new Date();
				}
				
				BigDecimal localDestino = new BigDecimal(0);
				try {
					localDestino = new BigDecimal(txtLocalDestino);
				}
				catch (Exception e) {
					localDestino = new BigDecimal(0);
				}
				
				solicitud.setCodTipomov(selTipoMovimiento);
				solicitud.setFecTraslado(fecTraslado);
				//solicitud.setNumLocalori(localOrigen);
				solicitud.setNumLocaldes(localDestino);
				solicitud.setObsSolicitud(txtConcepto);
				
				solicitud.setCodEmplaut(selAutorizador);
				
				gestionVigilanciaService.actualizarSolicitudVigilancia(solicitud);
			}
			else if ("F".equals(accionRegistrar)) {
				
				solicitud.setCodEstado(VigilanciaConstantes.SOLICITUD_FIRMADA);
				solicitud.setCodDocaut(new BigDecimal(0)); //TODO
			}
			else if ("A".equals(accionRegistrar)) {
				
				String txtObsAnula = request.getParameter("txtObsAnula");//PONER
				String hdnCodigoAnula = request.getParameter("hdnCodigoAnula");//PONER
				
				solicitud.setCodEstado(VigilanciaConstantes.SOLICITUD_ANULADA);
				
				solicitud.setFecAnula(hoy);
				solicitud.setObsAnula(txtObsAnula);
				solicitud.setCodEmplanu(hdnCodigoAnula);
			}
			
			respuesta.put("error", "0");
			
			respuesta.put("(numSolicitud", numSolicitud);
			respuesta.put("solicitud", solicitud);
			
			log.debug("Iniciando control patrimonial -- getDetalleBien");
			String codBienAsignado=request.getParameter("codBien");
			String flagEstadoBienConformidad=request.getParameter("flagEstadoBienConformidad");
			detalleBienAsignado = gestionVigilanciaService.selectByPrimaryKeyInventario(codBienAsignado, colaborador.getCodiEmplPer(),flagEstadoBienConformidad);
			respuesta.put("detalleBienAsignado", detalleBienAsignado);
			
		} catch (Exception e) {
			respuesta.put("error", "1");
			respuesta.put("mensajeError", e.getMessage());
			log.error(e.getMessage(), e);
		}

		viewPage = new ModelAndView(getJsonView(), respuesta);
		return viewPage;
	}
	
	private Map<String, Object> armarObjetosReporteJasper(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		Map<String, Object> respuesta = new HashMap<String, Object>();
		
		/*
		--"fecRegistro" -> SOL.FEC_REGISTRO
		--"horaRegistro" -> SOL.FEC_REGISTRO
		--"numSolicitud" -> SOL.NUM_SOLICITUD
		--"registroNombreColaborador" -> SOL.COD_EMPLSOL -> MP.CODI_EMPL_PER
			MP.NOM_CORT_PER, MP.NUMERO_REGISTRO_ALTERNO
		--"descUuooColaborador" -> SOL.COD_DEPESOL -> TD.CODI_DEPE_TDE
			TD.DESC_DEPE_TDE, 
		--"codSolicitud" -> SOL.COD_SOLICITUD
		"numNomLocalOrigen"
		--"registroNombreAsignado" -> SOL.COD_EMPLASG -> MP.CODI_EMPL_PER
			MP.NOM_CORT_PER, MP.NUMERO_REGISTRO_ALTERNO
		--"tipoMovimiento" -> SOL.COD_TIPOMOV (CATALOGO T01PARAMETRO MUEB,0025)
		--"fecTraslado" -> SOL.FEC_TRASLADO
		"numNomLocalDestino"
		--"obsSolicitud" SOL.OBS_SOLICITUD
		--"nombreColaborador" -> SOL.COD_EMPLSOL -> MP.CODI_EMPL_PER
		--	MP.NOM_CORT_PER
		--"registroColaborador" -> SOL.COD_EMPLSOL -> MP.CODI_EMPL_PER
		--	MP.NUMERO_REGISTRO_ALTERNO
		"descCargoColaborador"
		"fechaFirmaColaborador"

		--"numItem" -> DET.NUM_ITEM
		--"codiMarqAct" -> DET.COD_MARQ_ACT
		"descBien"
		"numSerie"
		"marca"
		"modelo"
		"descEstado"
		*/
		
		return respuesta;
	}

	/*
	public ModelAndView descargarArchivo(HttpServletRequest request, HttpServletResponse response) throws ServiceException {

		ModelAndView modelAndView = null;
		
		if (log.isDebugEnabled()) {log.debug("debug Inicio - ConsultaSolicitudController.descargarArchivo");}
		Map<String, Object> params = new HashMap<String, Object>();
		Map <String, Object> respuesta = new HashMap<String, Object>();
		
		try {
			String numArchivo = StringUtils.trim(request.getParameter("numArchivo"));

			boolean existeArchivo = false;
			
			BigDecimal codDocautNumber;
			try {
				codDocautNumber = new BigDecimal(numArchivo);
			}
			catch (Exception e) {
				log.debug("error en conversion de numero");
				codDocautNumber = BigDecimal.valueOf(-1.0);
			}
			
			log.debug("numArchivo " + numArchivo);
			params.put("numArchivo", numArchivo);
			
			byte[] bytes = new byte[1024];
			String nombre = "";
			
			T5282Archbin archivo = consultaFirmaService.recuperarDocumentoPdfFirmado(codDocautNumber);
			bytes = archivo.getArcDatos();
			nombre = archivo.getDesNombreAlternativo();
			existeArchivo = true;
				
			log.debug("nombre del archivo: " + nombre);
			
			if (existeArchivo) {
				if (!(nombre.contains(".pdf") || nombre.contains(".PDF"))) {
					nombre = nombre + ".pdf";
				}
				
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment;filename="+nombre);
	
				OutputStream os = response.getOutputStream();
	
				os.write(bytes);
	
				os.flush();
				os.close();
			}
			
			return modelAndView;
		}
		catch(Exception ex){
			log.error("Error en ConsultaSolicitudController.descargarArchivo: " + ex.getMessage(), ex);

			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			respuesta.put("msgError", "Ocurrio un error inesperado: " + ex.getMessage());
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
			return modelAndView;
		}
		finally{
			if (log.isDebugEnabled()){ log.debug("Fin - ConsultaSolicitudController.descargarArchivo");}
		}
	}

	public ModelAndView recuperarSolicitudes(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
		
		//PARAMETRO 3280
		ModelAndView modelAndView = null;
		Map<String, Object> respuesta = new HashMap<String, Object>();
		//UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		
		try {
			log.debug(getClass().getName() + " Inicio del metodo recuperarSolicitudes");
			
			List<ReciboProvisional> listaSolicitudes = this.consultarSolicitudesRecibo(request, response);						
			respuesta.put("listaSolicitudes", listaSolicitudes);
			
			// INDICADORES QUE LA PETICION AJAX CULMINO OK SIN ERRORES
			respuesta.put("error", "0");
			respuesta.put("msgError", "");
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} catch (Exception e) {
			log.error("Error: " + e.getMessage(), e);
			
			// INDICADORES QUE LA PETICION AJAX TUVO ERROR
			respuesta.put("error", "1"); 
			respuesta.put("mensajeError", e.getMessage());
			respuesta.put("msgError", "Ocurrio un error inesperado: " + e.getMessage());
			
			modelAndView = new ModelAndView(getJsonView(), respuesta);
			
		} finally {
			log.debug(getClass().getName() + " Fin del metodo recuperarSolicitudes");
		}
		
		return modelAndView;
	}
	*/
	
	public String getJsonView() {
		return jsonView;
	}

	public void setJsonView(String jsonView) {
		this.jsonView = jsonView;
	}

	public JsonSerializer getJsonSerializer() {
		return jsonSerializer;
	}

	public void setJsonSerializer(JsonSerializer jsonSerializer) {
		this.jsonSerializer = jsonSerializer;
	}

	public RegistroGeneralService getRegistroGeneralService() {
		return registroGeneralService;
	}

	public void setRegistroGeneralService(RegistroGeneralService registroGeneralService) {
		this.registroGeneralService = registroGeneralService;
	}

	public RegistroArchivosService getRegistroArchivosService() {
		return registroArchivosService;
	}

	public void setRegistroArchivosService(
			RegistroArchivosService registroArchivosService) {
		this.registroArchivosService = registroArchivosService;
	}

	public ConsultaFirmaService getConsultaFirmaService() {
		return consultaFirmaService;
	}

	public void setConsultaFirmaService(ConsultaFirmaService consultaFirmaService) {
		this.consultaFirmaService = consultaFirmaService;
	}

	public GestionVigilanciaService getGestionVigilanciaService() {
		return gestionVigilanciaService;
	}

	public void setGestionVigilanciaService(GestionVigilanciaService gestionVigilanciaService) {
		this.gestionVigilanciaService = gestionVigilanciaService;
	}

	public RegistroPersonalService getRegistroPersonalService() {
		return registroPersonalService;
	}

	public void setRegistroPersonalService(
			RegistroPersonalService registroPersonalService) {
		this.registroPersonalService = registroPersonalService;
	}

	public RegistroDependenciasService getRegistroDependenciasService() {
		return registroDependenciasService;
	}

	public void setRegistroDependenciasService(
			RegistroDependenciasService registroDependenciasService) {
		this.registroDependenciasService = registroDependenciasService;
	}
}